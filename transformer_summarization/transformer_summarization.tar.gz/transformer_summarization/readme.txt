Changed our data in the summarize_cnn_dailymail32k problem format (Scripts in summarize_pubmed folder)

Default tensor2tensor problem: https://github.com/tensorflow/tensor2tensor#summarization 

In order to generate the data in summarize_cnn_dailymail32k format, first there are 3 folders with files in each folder (train, test and val). Run the python
script of convert_data_form.py with suitable mode to get the data in the data_dir folder. After you run the script in all the modes, we need to structure the data
in the default form as 

    .:
    all_test.txt   all_val.txt  cnndm.dev.source  cnndm.test.source  cnndm.train.source  dailymail
    all_train.txt  cnn          cnndm.dev.target  cnndm.test.target  cnndm.train.target

    ./cnn:
    stories

    ./cnn/stories:
    00b97b3cab50c8f90a08a07b3dc9d36ae584e326.story  41b929a30d7beb9e269ad674b3b5ae2fd078db2d.story .......

    ./dailymail:
    stories

    ./dailymail/stories:
    08905639fef9cd915d31adb05fc41c16fe9e6618.story  a988793552be5f517e3eee996bf9b5f6a7045d2d.story ........

like the one forms when we run the summarize_cnn_dailymail32k problem. After generating the data in their form, we can start training just as

    t2t-trainer --data_dir=/home/mainak.chain/Wikisum_dev/my_data --output_dir=/home/mainak.chain/Wikisum_dev/train --model=transformer --hparams_set=transformer_test  
    --problem=summarize_cnn_dailymail32k --tmp_dir=/home/mainak.chain/Wikisum_dev/my_t2t_datagen --generate_data


ISSUE:
The model never start training with the constructed transformer model with new data. I happen to know this by the events.out.tfevents.* files for both cases.