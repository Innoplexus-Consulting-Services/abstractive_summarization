import os
import json
import io
import re
import string
import six
import hashlib
import argparse
import tensorflow as tf
from nltk import sent_tokenize

parser = argparse.ArgumentParser()
parser.add_argument('--data_dir',
                    help='directory with all json files to convert.')
parser.add_argument('--output_dir',
                    help='directory with all .story files to store.')
parser.add_argument('--mode',
                    help='train, test or val.')

args = parser.parse_args()

def get_file_list(input_folderpath):
    path = input_folderpath + '/*'
    input_files = tf.gfile.Glob(path)
    return input_files

def get_file_data(file):
    """ reads the json file and returns the loaded data"""
    loaded_data = []
    with open(file, mode='r') as file_json:
        loaded_data = json.load(file_json)
        for document in loaded_data:
            body = re.sub(' +',' ',document['body'].strip().replace('\n',' '))
            abstract = re.sub(' +',' ',document['abstract'].strip().replace('\n',' '))
            return abstract, body

def generate_hash(inp):
    """Generate a sha1 hash to match the raw url to the filename extracted."""
    h = hashlib.sha1()
    h.update(inp)
    return h.hexdigest()

def write_files(mode, data_dir, output_dir):
    """Writes the files and corresponding hash codes in a file"""
    input_files = get_file_list(data_dir)
    hash_names = []
    for file in input_files:
        hash_name = generate_hash(file.encode('utf-8'))
        hash_names.append(hash_name)

    dup = len(set(input_files)) - len(set(hash_names))
    if dup != 0:
        tf.logging.info("{} duplicated hash codes. Exiting....See ya!".format(dup))
        exit(-1)

    with open(output_dir + '/all_' + mode + '.txt', 'w') as allf:
        for i, hash_name in enumerate(hash_names):
            allf.write(input_files[i]+ '\n')
            with open(output_dir + '/' + hash_name + '.story', 'w') as hashf:
                abstract, body = get_file_data(input_files[i])
                for sent in sent_tokenize(body):
                    hashf.write(sent + '\n')
                hashf.write("@highlight\n")
                for sent in sent_tokenize(abstract):
                    hashf.write(sent + '\n')

if __name__ == '__main__':
    data_dir = args.data_dir
    output_dir = args.output_dir
    mode = args.mode
    write_files(mode, data_dir, output_dir)
