introduction anxiety among patients is present in the operation theatre set up with a reported incidence of 60%–80%.
[12] lengthy surgical procedures, anaesthesia, unfamiliar surroundings and unexpected delays typically increase patient anxiety.
approximately, one-third of patients having surgery under regional anaesthesia are highly anxious before surgery.
[3] anxiety stimulates the activity of the sympathetic nervous system and may increase the incidence of intraoperative tachycardia, hypertension, arrhythmias, increased pain perception and requirement of anaesthetic drugs.
[3] this may decrease the overall patient satisfaction with perioperative care and may affect the process of giving informed consent.
[3] during the pre-anaesthetic check-up (pac), the anaesthesiologist counsels the patient regarding the procedure and associated anaesthetic risks.
however, this transfer of knowledge is usually limited and may not be entirely retained.
many methods to deliver this information have been tried in the form of written pamphlets and questionnaires.
in india, not all patients are literate enough to read, understand and retain this information.
multimedia information to allay patient's anxiety has been successfully tried.
[45678] we developed a short visual clip of 206 s duration depicting the procedure of spinal anaesthesia (sab).
we aimed to compare the effect of this pre-operative multimedia video information on perioperative anxiety and haemodynamic parameters in patients undergoing procedures under sab versus patients who were not provided with the video information.
our primary objectives were to measure baseline anxiety and anxiety 1 h before induction of anaesthesia using a self-reported psychological instrument, the spielberger state-trait anxiety inventory (stai) and secondary objectives were to study haemodynamic parameters such as heart rate (hr) and mean arterial pressure (map) perioperatively.
methods this was a prospective randomised controlled, single-blind study of 200 patients in groups of 100 each posted for surgery under sab over a period of 2 years.
institutional ethics committee approval was obtained for the study.
patients were enrolled during the pac a day before elective surgery.
all patients between 18 and 60 years of age of either sex undergoing elective surgery under sab were included.
all participants were literate, and only those patients who could read and fill in the questionnaire on their own in english, hindi or the local language (marathi) were included.
patients refusing to give consent for the study, having significant cardiovascular or neurological disease, on medications such as beta blockers, antidepressants, cardiac or psychiatric drugs, pregnant patients and those who had undergone procedures under sab in the past were excluded from the study.
written informed consent was obtained during the pac.
by randomly generated computerised table, patients were allotted into nonvideo group (group nv) and video group (group v).
according to this randomisation, group allocations were sealed in opaque envelopes prepared by an anaesthesiologist not involved in the study.
at no point of time was the principal investigator aware of the group allotment.
in all patients, baseline anxiety was assessed during the pac by the principal investigator using the stai-trait (stai-t) (twenty questions), the stai-state (stai-s) (twenty questions).
clear instructions on how to fill both forms were provided to the patients.
they filled up this form on their own in the language they understood.
all patients then proceeded to another room where the envelopes were opened by the second investigator and group allotment was revealed.
in group nv, the procedure of sab was explained verbally to the patients by the second investigator following which the patient was allowed to ask questions.
patients in group v were taken to the audio-visual room where they were shown a short visual clip on the method of sab using a laptop computer by an anaesthesiologist involved in the study.
verbal explanation of the anaesthetic procedure was provided to the patients in the language they understood.
patients were then allowed to ask questions.
if they wanted to watch the visual clip again, they were allowed to do so.
patients in both groups were informed about the procedure, its effects, side effects and risk of complications.
all patients were also informed that the anaesthesiologist would be with them throughout the surgery monitoring their vital parameters.
on the day of surgery, stai-s was repeated 1 h before induction by the principal investigator in both groups in the pre-operative waiting room.
the anaesthesiologist conducting the case along with the surgeon then accompanied the patients into the operation theatre.
standard monitoring devices such as pulse oximeter, noninvasive blood pressure and cardioscope were attached.
intravenous access was secured and crystalloid solution was started.
participant was placed in the sitting position and under all aseptic precautions; sab was administered with 0.5% bupivacaine using appropriate size spinal needle and appropriate drug volume by an anaesthesiologist not involved in the study.
haemodynamic parameters such as hr and map were noted during the pac (baseline) and before administration of sab (pre-sab).
a 206 s visual clip was specially prepared for this study and was shown to patients in group v. it begins with the patient entering the operation theatre with the anaesthesiologist and surgeon.
monitors are attached, and an intravenous line is secured.
it then shows the positioning of the patient followed by painting the site with antiseptic solution.
the draping is done and the anaesthesiologist feels for landmarks on the patient's back, and then administers sab.
the patient is then made to lie supine, and spinal level is checked with solvent ether.
the onset of motor blockade by inability to raise the feet was also depicted.
the film ended with the start of surgery.
this visual clip was accompanied by auditory information to the patient in one of the three languages.
sample size of 200 was estimated from a similar study[3] in which the prevalence of anxiety of patients by stai-s in low anxiety group (stai <37) was 58% in the pre-operative film group and 38% in the control group.
with type i error at 5% level of significance and 80% power of study sample size of 98 was estimated in each group.
two patients were added to each group to compensate for the possible loss of data.
data were statistically described in terms of mean ± standard deviation (sd) and percentages when appropriate.
comparison of quantitative variables between the study groups was done using student's t-test for independent samples if normally distributed.
mann–whitney u-test was used for nonnormally distributed quantitative and ordinal data.
for comparing categorical data, chi-square test was performed.
p < 0.05 was considered statistically significant.
all statistical calculations were done using microsoft excel 2007 and spss version 15 (spss inc., chicago, il, usa).
results a total of 200 subjects were randomised into the two groups.
these 200 participants provided complete data and were included in the analysis.
the study population in both groups were similar with respect to age, sex and american society of anesthesiologists physical status [table 1].
table 1 patient characteristics, spielberger state-trait anxiety inventory scores and haemodynamic parameters there was no significant difference between the two groups in terms of a-trait and a-state scores at enrolment during the pac.
group nv had significantly higher a-state scores compared to group v pre-sab [table 2 and figure 1].
table 2 prevalence of state anxiety for spinal anaesthesia in the two groups figure 1 comparison of mean values of stai scores in group nv and group v. group nv - nonvideo group, group v - video group, stai-t - spielberger state-trait anxiety inventory-trait, stai-s - spielberger state-trait anxiety inventory-state, sab - spinal anaesthesia both groups were comparable with respect to baseline hr.
the mean hr pre-sab in group nv increased 24% from baseline whereas in group v there was a 4.87% increase from baseline.
the difference in hr pre-sab between two groups was statistically significant (p < 0.001).
the pre-sab map in group nv increased by 19.79% from baseline whereas in group v it decreased by 1.96% from baseline.
the difference in map pre-sab between two groups was statistically significant (p < 0.001) [figures 2 and 3].
figure 2 changes in heart rate at various time intervals in group nv and group v. group nv - nonvideo group, group v - video group figure 3 changes in mean arterial pressure at various time intervals in group nv and group v. group nv - nonvideo group, group v - video group the prevalence of ‘high’ anxiety among patients having surgery under sab in the pac was 82% in group nv and 80% in group v. immediately before surgery; this increased to 96% in group nv and decreased to 66% in group v [table 2].
the mean a-trait scores and a-state scores for females was significantly higher than males.
females also had significantly higher levels of state anxiety scores compared to males’ pre-sab [table 3].
table 3 comparison of anxiety for spinal anaesthesia with respect to sex distribution discussion this study revealed that those patients who were not shown the multimedia information film on sab experienced a significant increase in state anxiety score from baseline to immediately before surgery (59.31 ± 8.12; mean ± sd) whereas those who were shown the video showed a significant decrease in state anxiety score pre-sab (50.46 ± 10.37; mean ± sd) (p < 0.001).
patients who were not shown the film also showed a significant increase in haemodynamic parameters compared to baseline before surgery (hr, map pre-sab, p < 0.001).
this proves that our intervention in the form of multimedia information was successful in allaying anxiety related to sab in the perioperative period.
this was in accordance with a study conducted in 2010 to determine the effect of pre-operative multimedia information on perioperative anxiety in patients undergoing procedures under regional anaesthesia.
[3] the authors demonstrated that viewing a short information film before operation reduced the anxiety of patients undergoing elective surgery under regional anaesthesia and the effect was sustained into the post-operative period.
although there are many international studies validating the effect of audiovisual information on perioperative anxiety,[45678] there are no such studies in the indian context.
this is further important because in our country not all patients may be literate and hence may be unable to read information brochures or search for information relating to anaesthesia and surgery which is frequently available to patients abroad.
stai is the ‘gold standard’ for measuring pre-operative anxiety.
[91011] it comprises separate self-report scales for measuring two distinct anxiety concepts; state anxiety and trait anxiety.
reliability and validity of the stai are well reported (cronbach's alpha = 0.896).
the stai-t scale consists of twenty statements that ask people to describe how they generally feel.
the stai-s scale also consists of twenty statements, but the instructions require subjects to indicate how they feel at a particular moment in time.
stai-s scale can be used to determine the actual levels of anxiety intensity induced by stressful procedures.
the validity of the stai rests upon the assumption that the examinee has a clear understanding of the ‘state’ and ‘trait’ instructions.
each question is rated on a four-point scale (not at all, somewhat, moderately so, very much so).
the range of possible scores for form y of the stai varies from a minimum score of 20 to a maximum score of 80 on both the stai-t and stai-s subscales.
stai scores are commonly classified as ‘no or low anxiety’ (20–37), ‘moderate anxiety’ (38–44) and ‘high anxiety’ (45–80).
we used the form y of stai in english and had it translated in hindi and marathi by an expert in the respective languages.
the translated forms were then retranslated back to english.
the retranslated sentences which most closely resembled the original english stai form y sentences were used for that language.
there are studies abroad for the use of stai in evaluating anaesthesia-related anxiety.
[31012] however, it is complex, tedious and needs a literate patient population.
this may be the limiting factor for its use in the indian set up, and hence most published indian studies have used the visual analogue scale for measurement of perioperative anxiety.
[11] this simple intervention was effective in avoiding hr and map variations perioperatively by reducing catecholamine surge.
this is because of decreased anxiety which inhibits the hypothalamic pituitary adrenal axis release of adrenocorticotrophic hormone and cortisol into the blood stream and decreased activation of sympathetic nervous system.
[13] in this study, anxiety scores were higher in female patients’ perioperatively.
women had higher baseline anxiety scores as well as higher scores pre-sab compared to men (p < 0.001).
hence, we need to focus more attention on this section of the population.
this can be easily done with the help of multimedia video information along with other relaxation and behavioural techniques.
the prevalence of ‘high’ anxiety among patients having surgery under sab was 81% preoperatively in both groups.
this shows that perioperative anxiety in the indian context is high compared to data from the british study which showed a 17% prevalence of ‘high’ anxiety for regional anaesthesia.
[3] this may highlight certain lacunae in our current system of providing perioperative information to our patients and may suggest that we need to put in more efforts to reduce this high anxiety prevalence.
there were certain limitations to this study.
as we used stai for assessment of anxiety, we could only assess scores in literate patients.
hence, a large section of patients who were illiterate could not be included in the study.
this could have been the section that would actually benefit the most from the multimedia information.
furthermore, as anxiety relating to surgery and/or anaesthesia may not be exclusive, we did not aim to separate the two entities in this study.
hence, the high prevalence of anxiety in our study population may have been attributed to anxiety for surgery.
long-term follow-up and evaluation of patients for any impact of post-anaesthesia stress disorder reduction and change in psychological behaviour was not done.
this could be a subject for a future extended study.
conclusion multimedia information in the form of a short audiovisual clip during the pac is an effective and feasible method to reduce perioperative anxiety.
we encourage anaesthesiologists to focus their attention on this mode of educating patients about the anaesthesia experience.
this may help to improve overall patient satisfaction and perioperative outcomes.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
background and aims: a high incidence of anxiety has been reported in patients in the operation theatre set up.
we developed a short visual clip of 206 s duration depicting the procedure of spinal anaesthesia (sab) and aimed to compare the effect of this video on perioperative anxiety in patients undergoing procedures under sab.
methods: a prospective randomised study of 200 patients undergoing surgery under sab was conducted.
patients were allotted to either the nonvideo group (group nv - those who were not shown the video) or the video group (group v - those who were shown the video).
anxiety was assessed using the spielberger state-trait anxiety inventory during the pre-anaesthetic check-up and before surgery.
haemodynamic parameters such as heart rate (hr) and mean arterial pressure (map) were also noted.
student's t-test was used for normally distributed and mann–whitney u-test for nonnormally distributed quantitative data.
chi-square test was used for categorical data.
results: both groups were comparable with respect to baseline anxiety scores and haemodynamic parameters.
the nonvideo group showed a significant increase in state anxiety scores before administration of sab (p < 0.001).
patients in the video group had significantly lower hr and map preoperatively (p < 0.001).
the prevalence of ‘high anxiety’ for sab was 81% in our study which decreased to 66% in the video group before surgery.
conclusion: multimedia information in the form of a short audiovisual clip is an effective and feasible method to reduce perioperative anxiety related to sab.
