introduction in recent decades, there has been a steady increase in the incidence of non-hodgkin’s lymphomas (nhl) of 2–4% per year [1, 2].
these observations have been made throughout the world [3–5].
reports from denmark suggest that in the years 1970–1985 the number of cases doubled [6].
lymphoma is a malignant lymphoproliferative disease, which is generally divided into hodgkin’s lymphomas (hl) and nhl.
according to the national cancer registry, about 2% of cancer cases in poland are nhl and about 0.5% are hl.
non-hodgkin’s lymphomas can be located in the lymph nodes or beyond them.
the second location can affect all organs.
this is most commonly the skin, stomach, central nervous system, and waldeyer’s ring.
the head and neck area is one of the most common locations of extranodal lymphomas, after the location in the gastrointestinal tract, and represents about 5% of malignant neoplasms of the head and neck [7].
according to the lugano classification for staging of nodal lymphomas from 2014, which is a modification of the ann arbor classification, the waldeyer ring, spleen, thymus, appendix, and peyer’s patches were considered as nodal tissue [8].
the authors of this publication, when describing the location of the tumour, treated the waldeyer ring (which includes the palatine, lingual, and pharyngeal tonsils), nasal cavity, and paranasal sinuses, as well as parotid glands, as being extranodal locations of lymphoma, which facilitated clinical and pathological evaluation of the location of lesions.
the 2008 who classification identified six main groups of lymphomas: precursor b-cell and nk/t-cell lymphoma, mature b-cell lymphoma, mature nk/t-cell lymphoma, post-transplantation lymphoproliferative disorders, hodgkin’s lymphoma, neoplasms of histiocytic and dendritic cells.
the group of b-cell neoplasms was divided into: aggressive lymphomas, which include diffuse large b-cell lymphoma (dlbcl) and burkitt’s lymphoma, slow lymphomas – mantle cell, follicular, and marginal zone lymphomas [9].
the vast majority of nhl cases are b-cell lymphomas preceded only by dlbcl, which according to various authors constitutes from 32.9 [9] to 71.9% [10] of all cases.
it is the most common type of lymphoma in poland [10].
alli’s observations in south african population the most common head and neck lymphomas were plasmablastic lymphoma (31.55%) and dlbcl (30.75%) [11].
the aim of the study was a retrospective analysis of cases of lymphomas within the head and neck area, and a description of their location and histological type, as well as observation of whether there has been an increase in incidence in the last decade.
material and methods a retrospective study was conducted of the medical records of patients treated in the department of otolaryngology and laryngological oncology of the upper silesian medical centre in katowice in the years 2004–2015, in whom head or neck tumours were initially diagnosed.
in the given period of time, there was no significant increase in the number of patients admitted and operated, and the diagnoses of patients did not differ from previous years and were not focused on neoplastic diseases.
the study included patients in whom, based on histopathological examination of the removed tumour, a primary lymphoma was diagnosed.
the collected data were analysed in terms of location of lesions, histological type of lymphoma, ann arbor staging, as well as the sex and age of the patients.
risk factors such as hiv infection (human immunodeficiency virus), hcv (hepatitis c virus), and hbv (hepatitis b virus) were checked.
histopathological classification was made according to the 2008 who classification of haematopoietic and lymphatic system tumours in the department of pathology of the upper silesian medical centre and was carried out by the same pathologist.
statistical evaluation of the incidence of lesions in the studied period of time was made based on regression and correlation analysis.
results seventy-seven head and neck lymphomas were diagnosed in the years 2004–2015.
in the case of 19 patients, a pathologist diagnosed lymphomas; however, to specify the type of the cell line from which it originated, it was necessary to further verify the material at the institute of oncology in gliwice, so 58 neoplasms were subjected to final analysis.
the test group was slightly dominated by women – 53.45%.
the mean age was 60.7 (±16.06) years and was lower among men (46 ±2.83) than women (63.5 ±20.5).
none of the patients had hcv, hbv, or hiv infection.
fifty-two cases (67.53%) of non-hodgkin (nhl) and six (7.79%) hodgkin’s lymphomas were identified (hl).
in each case, hl was located in the nodes.
non-hodgkin’s lymphoma in the head and neck area was usually observed in the lymph nodes, nasopharynx, and salivary glands (table 1).
all lymphomas within the sinuses were from b cells, while in the nasal cavity there was only one case of t-cell phenotype.
the most common histological types of nhl were dlbcl, representing 51.92% of the cases, and follicular lymphoma – 15.38 %, followed by t-cell and mantle cell lymphomas (9.61% each), and marginal zone lymphoma – 7.69%.
table 1 location of the primary lesion and the histological type of non-hodgkin’s lymphoma histological type of nhl location of the primary lesion nodal tonsil lingual tonsil pharyngeal tonsil parotid gland sinonasal tract total diffuse large b-cell lymphoma 14 6 0 0 3 4 27 follicular lymphoma 7 0 0 0 1 0 8 mantle cell lymphoma 2 1 0 2 0 0 5 marginal zone lymphoma 3 0 0 0 1 0 4 t-cell lymphoma 3 1 0 0 0 1 5 malt lymphoma 0 0 1 0 0 0 1 small b-cell lymphoma 1 0 0 0 0 0 1 small lymphocyticum lymphoma 0 1 0 0 0 0 1 total 30 9 1 2 5 5 52 dlbcl was the most common in both women and men, mantle cell lymphoma dominated in men, and the marginal zone and follicular lymphomas in women.
hl was observed more frequently in men.
in this analysis, there was no statistically significant difference.
the ratio of males to females in the case of mantle cells was 4 : 1, and for follicular lymphoma 2 : 5. according to ann arbor staging of lymphomas, in the test group 27 patients were stage i, 26 – stage ii, 4 – stage iii, and 1 – stage iv.
the regression and correlation analysis performed in different years showed a statistically significant increase (fig.
1) in the incidence of lymphomas, especially non-hodgkin’s type (p = 0.0169) (table 2).
the strength of the relationship between the number of nhls and subsequent years can be described as high (pearson’s correlation coefficient r = 0.7283).
on the basis of the obtained regression equation, it can be concluded that an increase of one year caused an increase in the number of nhl of 0.78 on average.
furthermore, the increase in the incidence of nhl in 53% was caused by the passage of time.
in the case of hl, there was no relation between the number of cases and subsequent years of observation.
table 2 the incidence of hodgkin’s and non-hodgkin’s lymphomas in the years 2005–2014 histological type 2005 2006 2007 2008 2009 2010 2011 2012 2013 2014 total hl 0 2 1 0 1 0 0 0 0 2 6 nhl 2 5 2 1 8 5 4 5 10 10 52 total 2 7 3 1 9 5 4 5 10 12 58 fig.
1 relationship between the number of nhl cases and the years of observation discussion the test histopathological material was dominated by nhls, whose number has increased significantly during the recent years of observation.
hls were clearly a smaller group, which is consistent with other authors’ reports [11–14].
in 2016 new data was published, which demonstrated a significant reduction in nhl morality in the us general population, which was initially due to improved survival after nhl diagnosis for the three most common subtypes (dlbcl, cll/sll, and fl) [15].
in the material, nhl lesions were usually located in the lymph nodes of the neck, which is confirmed by tusaliu’s research [14].
takano, on the other hand, reports that the mouth and throat are the most common location of lymphomas, followed by the lymph nodes [12].
according to pritinanda, almost 25% of nhls originate from tissue other than the node tissue [16].
the most common extranodal location, both in the present analysis and in the available literature, is the waldeyer ring, with 20.7% of cases.
regardless of the location of the primary lesion, the most commonly diagnosed neoplasm was dlbcl – 35.1%.
a similar result of 32.9% was reported by szumera-ciećkiewicz [10] on the basis of analysis of 11,718 cases collected from data from the national lymphoma histopathological registry.
the polish data are consistent with the results of studies published in the world [7, 12–14, 17].
the primary occupation of the parotid glands by a hyperplastic lesion of the lymphatic system was observed in 5–10% of patients, which is similar to the results of the present analysis [18, 19].
primary lesions within the salivary glands were surprisingly often (41.38%) observed by triantafillidou in a study of extranodal nhls in the oral cavity and the maxilla-facial area [20].
the most common extranodal location in the study of bagan was the oral cavity (44%), followed by the salivary gland (12.4%) and palatine tonsils (9.3%) [21].
different infectious agents and their influence on the risk of nhl are described in the literature [13, 22].
the most important include epstein-barr virus infection, particularly in favourable conditions of congenital immunodeficiency or acquired dysregulation and suppression of t lymphocytes (for example, in the course of hiv infection, after organ transplant), hh-8b virus (human herpes virus), htlv-1 (human lymphotropic virus-1), and the helicobacter pylori or borrelia burgdorferi infections [13].
the impact of hepatitis c infection on the development of b-cell nhl is also discussed [13, 23, 24].
in the case of the test group, no patient was diagnosed with hbv, hcv, or hiv infections, and other infectious risk factors were not subjected to a thorough diagnosis and analysis.
chronic inflammation associated with rheumatoid arthritis, sjögren’s syndrome, celiac disease, or thyroiditis is also considered an important risk factor in the development of proliferative diseases of the lymphatic system [13, 22].
similar observations were made in the case of nhl within the parotid glands [19].
the patients treated in our institution, in spite of the existing co-morbidities (such as coronary heart disease, hypertension), did not report the above-mentioned risk factors.
the direct causes of the increased incidence of malignant lymphomas are not fully understood, but it is probably related to the increase in exposure to the risk factors described above [21].
in conclusions, the test histopathological material was dominated by nhl, preceded only by diffuse large b-cell lymphoma.
regression and correlation analysis in different years showed a statistically significant increase in the incidence of nhl (p = 0.0169).
swollen glands in the neck were the most common first clinical symptom of a proliferative process of the lymphatic system.
the frequent presence of nhl within the palatine tonsil (40.9% of extranodal location and 54.5% of the extranodal location within the whole waldeyer ring) suggests that it should be remembered that there is a possibility of lymphoma in the area where squamous cell carcinoma is usually clinically suspected, which is the most common malignant tumour of the tonsils.
in the case of head and neck lymphomas, surgery, followed by haematology treatment, radiotherapy, and dietary and psychological actions, plays an increasingly important role in the successful treatment of the patient.
@highlight
aim of the study lymphomas are a heterogeneous group of tumours of lymphoid tissue in which there is an abnormal proliferation of cells of the lymphatic system.
the literature notes a gradual increase in the incidence of this type of cancer in the whole population.
the aim of the study was to evaluate whether the above tendency occurs in the head and neck area.
material and methods in the years 2005–2014, at the otolaryngology and laryngological oncology department of the upper silesian medical centre in katowice, 77 cases of lymphoma were recorded, 58 of which were analysed in terms of location, histological type, age and sex of the patient, and the presence of risk factors.
results the vast majority of them were non-hodgkin’s lymphomas (nhl) – 67.53%.
hodgkin’s lymphomas (hl) accounted for only a small fraction of diagnoses (7.79%).
in terms of histopathological types, in most cases of nhl, there occurred diffuse large b-cell lymphomas (dlbcl) – 51.92%.
the most common location was the lymph nodes, representing the location of the primary lesion in more than half of the cases.
as regards the extranodal location, the waldeyer ring dominated (54.54%) along with the palatal tonsil (40.90%).
there has been a significant upward trend, especially in the incidence of nhl.
