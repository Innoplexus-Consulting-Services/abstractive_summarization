introduction type 2 diabetes mellitus (t2dm) is a global healthcare concern.
about one-third of these patients are likely to develop diabetic nephropathy (dn), which is devastating in terms of clinical, economic, and ethical dimensions.
india has a large number of diabetic patients that is expected to increase to about 69.9 million by 2025.
[1] in addition, t2dm in indians occurs at least a decade earlier than europeans thus increasing the possibility of microvascular complications, especially of renal origin.
the rising trend in the incidence of dn, requiring renal replacement therapy is an economic burden that cannot be met by most nations.
there is a global need to implement diagnostic and management strategies, especially in india to reduce the risk factors for the development of dn.
[2] presence of albumin in the urine is considered predictive of development and progression of dn in t2dm patients,[3] but it is not a precise marker of dn.
these facts indicate a need for an in-depth investigation of urine samples to identify novel protein candidates for clinical use as diagnostic and/or predictive biomarkers.
several attempts have been made earlier to analyze urine samples to identify such biomarkers.
the first human urinary proteome map generated about a decade back on acetone-precipitated urine samples from healthy subjects identified only 67 proteins.
[4] subsequently, various techniques have been used to investigate urine samples, but most of them have identified <100 proteins that are different between t2dm and dn patients.
[5678910] taken together, a small number of proteins have been reported so far in the urine samples of dn patients and the majority of them are abundant plasma proteins that are repeatedly identified in different studies, thus compromising their utility as potential biomarkers.
recent advent of high throughput proteomic technologies has paved the way toward identification of large number of proteins in biological fluids such as blood, saliva, and urine.
[11121314] in the background of above, we investigated urine proteome of t2dm patients with and without evidence of renal damage and compared it with normal individuals.
we have identified novel proteins associated with different stages of diabetic kidney disease and also identified pathways that may be altered under these conditions.
materials and method selection of patients we recruited three groups of t2dm patients from department of nephrology at nizam's institute of medical sciences at hyderabad, india [table 1].
this included 10 patients each with normoalbuminuria, micro- and macro-albuminuria (urinary albumin = 3–30, 30–300, and >300 mg/dl, respectively).
all patients met inclusion criteria of t2dm with and without history of proteinuria.
the exclusion criteria were type 1 diabetes, history of hematuria, pregnant or lactating women, malignancy, and liver diseases.
ten healthy individuals from the same population, matched for age, sex, and socioeconomic status and in steady state conditions (defined as the lack of clinical events during the past 6 months to 1 year), were included as controls.
they had normal renal function and blood pressure, no proteinuria, and normal urinary sediment and none of them were under any medication.
all subjects signed written informed consent.
institutional ethics committees of both participating institutions approved the study.
table 1 clinical and biochemical characteristics of the study population collection, purification, and concentration of urine samples approximately, 50 ml of second-morning urine samples were collected using consistent procedures for sample collection, storage, and transportation (www.molmeth.org/protocols/mf43xa).
the samples were centrifuged, and supernatant was stored at −80°c until further processing.
desalting and concentration of urinary proteins were done using 3 kda molecular weight cut-off spin column (amicon ultra-15 device, millipore, billerica, macroalbuminuria) by centrifugation at 4000 × g at 4°c.
the protein content was estimated by the bradford method.
immunodepletion of urine samples of six abundant proteins equal amount of proteins from the concentrated urine samples from healthy individuals and patients from each group was pooled and processed for depletion as per manufacturer's instructions.
urine samples were pooled to avoid the heterogeneity of samples between the patients and ignore the individual differences.
we pooled the samples to differentiating each group of patients rather than individuals.
briefly, human six immunoaffinity multiple affinity removal system (mars column, 4.6 mm × 100 mm, agilent technologies, santa clara, ca, usa) was connected to a high-performance liquid chromatography system and equilibrated with agilent buffer-a.
we loaded 4 mg of urinary protein from each group onto the column to deplete six abundant proteins (albumin, igg, iga, antitrypsin, transferrin, and haptoglobin).
flow-through fractions were collected, concentrated and desalted using 5 kda molecular weight cut-off spin column (agilent, palo alto, ca).
we determined the protein concentration using bradford assay.
sodium dodecyl sulfate polyacrylamide gel electrophoresis prefractionation and tryptic digestion urinary proteins were reduced with 10 mm dithiothreitol at 60°c for 45 min, followed by alkylation with 50 mm iodoacetamide in 25 mm ammonium bicarbonate at room temperature for 1 h. urinary proteins were prefractionated on 4–20% gradient precast sodium dodecyl sulfate polyacrylamide gel electrophoresis (sds-page) gels (tris-glycine midi gels, invitrogen, ca).
based on molecular weight, the gel was divided into seven parts and sliced manually and destained with destaining solution (50% acetonitrile [acn] in 50 mm ammonium bicarbonate).
gel pieces were dehydrated with 100% acn, lyophilized, and digested with trypsin solution (promega, madison, wi, usa; 20 ng/μl) at 37°c for 16 h. tryptic peptide mixtures were extracted using 0.3% trifluoroacetic acid in 50% acn solution and lyophilized.
a total of seven peptide fractions were made each for patient and control groups.
liquid chromatography-tandem mass spectrometry analysis we performed nanoflow electrospray ionization and tandem mass spectrometric analysis of peptide samples using linear trap quadrupole (ltq)-orbitrap velos (thermo scientific, bremen, germany) interfaced with nanoflow liquid chromatography (lc) system.
each peptide fraction was separated on a bio basic c18 picofrit nanocapillary column (75 μm × 10 cm; new objective, ma, usa) using a 90 min linear gradient of the mobile phase (5% acn containing 0.1% formic acid [buffer-a] and 95% acn containing 0.1% formic acid [buffer-b]) at a flow rate of 200 nl/min and analyzed on ltq orbitrap mass spectrometer.
the voltage applied for ionization was 1.7 kv.
full scan ms spectra (from m/z 300–2000) were acquired after accumulation to a target value of 10−6 in the fourier transform (ft).
resolution in the ft was set to r = 60,000 at ms level.
the 20 most intense peptide ions with charge states ≥2 were sequentially isolated to a target value of 5000 and fragmented in linear ion-trap (it) by collision-induced dissociation (cid) with normalized collision energy of 35% and wideband-activation enabled.
the resulting fragment ions were scanned out in the low-pressure it at the “normal scan rate” (33,333 amu/s) and recorded with the secondary electron multipliers.
ion selection threshold was set at 500 counts for ms/ms and the maximum allowed ion accumulation times were 500 ms (mille second) for full scans and 25 ms for cid-ms/ms measurements in the ltq-orbitrap velos.
an activation q = 0.25 and activation time of 10 ms were used.
each fraction was run in duplicate resulting in generation of 56 raw files from all the four groups, which were searched against protein database.
identification of proteins and analysis of urine proteome dataset in different groups we analyzed the data files using sequest search algorithm in proteome discoverer (thermo fisher scientific, beta version 1.3.0.339, bremen, germany) against the human international protein index database (version ipihumanv378fasta).
search parameters included trypsin as the enzyme with two missed cleavages allowed, oxidation of methionine as a dynamic modification and carbamidomethylation of cysteine as static modification.
precursor and fragment mass tolerance were set to 10 ppm and 0.8 da respectively.
the peptide and protein identifications were obtained using high peptide confidence and top one peptide rank filters.
the false discovery rate (fdr) was calculated by enabling the peptide sequence analysis using a decoy database and high confidence peptide identifications were obtained by setting a target fdr threshold of 1% at the peptide level.
the proteins thus obtained were analyzed for its gene ontological distribution such as biological processes, molecular function, cellular localization, and associated molecular pathways and cellular networks using genego metacore software analysis (www.genego.com).
results in the present study, we used sds-page prefractionation followed by liquid chromatography-tandem mass spectrometry (lc-ms/ms) approach to generate and compare the proteome of urine samples of normal subjects and t2dm patients with and without renal complications.
the workflow of the study is shown in supplementary figure 1. supplementary figure 1 experimental work-flow chart click here for additional data file.
clinical data the clinical and biochemical characteristics of the study subjects are given in table 1. the age and sex distribution of patients were comparable in all the groups.
diabetic patients (normoalbuminuria and microalbuminuria) had higher body mass index and waist to hip ratio as well as higher systolic and diastolic blood pressure compared to normal healthy subjects.
we noted a progressive increase in serum creatinine, 24 h urinary total proteins, urinary albumin and a reduction in estimated glomerular filtration rate (all p < 0.001) from normoalbuminuria to micro- and macro-albuminuria group of patients indicating progressive decline in renal function with advanced disease.
the glycemic control as indicated by glycosylated hemoglobin (hb) and serum lipid levels also worsened from normoalbuminuria to micro- and macro-albuminuria group of t2dm patients.
thus, all patient groups exhibited metabolic abnormalities as well as evidence of progressive development of nephropathy from normoalbuminuria group to micro- and macro-albuminuria groups.
proteome profiling of urine samples from diabetic and control groups all urine samples were efficiently depleted of the six abundant proteins [supplementary figure 2].
analysis of the ms/ms spectra on proteome discoverer using sequest search engine against ipihumanv378.fasta database identified 1208, 1924, 1964, and 1752 peptides which mapped to 274, 505, 468, and 320 proteins in control, normoalbuminuria, micro- and macro-albuminuria groups, respectively [supplementary tables 1–4].
more than two-third of the proteins were identified with multiple peptides.
supplementary figure 2 differential displays of sodium dodecyl sulfate polyacrylamide gel electrophoresis gels before (a) and after (b) the depletion of six urinary proteins by agilent (hu6) column.
the gels were visualized with coomassie brilliant blue r-250.
m, marker; (1) control, (2) normoalbuminuria, (3) microalbuminuria, and (4) macroalbuminuria click here for additional data file.
supplementary table 1 list of total proteins identified in control group by lc-ms/ms using orbitrap click here for additional data file.
supplementary table 2 list of total proteins identified in na group by lc-ms/ms using orbitrap click here for additional data file.
supplementary table 3 list of total proteins identified in microalbuminuriamia group by lc-ms/ms using orbitrap click here for additional data file.
supplementary table 4 list of total proteins identified in macroalbuminuria group by lc-ms/ms using orbitrap click here for additional data file.
cellular and functional classification of identified urinary proteins we classified the identified proteins according to gene ontology, which allowed annotation of close to 75% proteins [figure 1].
based on sub-cellular localization, the majority of the proteins in the macroalbuminuria group were extracellular and membrane-related [43%; [figure 1a].
classification on the basis of molecular functions revealed that one-third fraction (33%) were proteins that bind sugar, polysaccharide, glycosaminoglycan, nucleic acids, etc., and a near equal fraction (28%) was involved in catalytic and enzyme regulatory activity [figure 1b].
based on biological activity, the majority of the proteins (34%) were noted to be involved in metabolic processes such as carbohydrate and lipid metabolism and others were involved in cellular and developmental processes, biological regulation, and immune response [figure 1c].
similar results were observed in other two diabetic groups [figure 2].
thus, the majority of the identified proteins belonged to membrane and extracellular class were functionally binding proteins and biologically involved in various metabolic processes.
figure 1 gene ontology-based classification of urinary proteins identified in macroalbuminuria group.
(a) sub-cellular localization, (b) molecular function, and (c) biological process figure 2 comparison of gene ontology-based classification of urinary proteins among different groups.
(a) sub-cellular localization, (b) molecular function, and (c) biological process comparison of urine proteome profile of diabetic patient groups with the control group and among individual diabetic groups on comparison of the proteome from each patient group independently with the controls, we detected 315, 294, and 218 proteins unique to normoalbuminuria, micro- and macro-albuminuria groups, respectively [figure 3].
further comparison among three diabetic groups identified 169, 129, and 132 proteins, respectively in normoalbuminuria, micro- and macro-albuminuria groups only [figure 4 and supplementary tables 5–7].
figure 3 venn diagram representing comparison of urinary proteins identified in various diabetic groups with the control group.
numbers in parentheses represent proteins identified in each group, whereas those within circle represent proteins unique to the specific group.
the intersect region of the circles shows proteins common to two comparison groups figure 4 venn diagram representing comparison of urinary proteome studies of all four groups.
numbers in parentheses represent proteins identified in each group, whereas those within circle represent proteins unique to the specific group.
the intersect region of the circles shows proteins common to all diabetic groups supplementary table 5 list of unique proteins identified in normoalbuminuriana group compared to control, microalbuminuriamia and macroalbuminuriama groups click here for additional data file.
supplementary table 6 list of unique proteins identified in mia group compared to control, na and ma groups click here for additional data file.
supplementary table 7 list of unique proteins identified in ma group compared to control, na and mia groups click here for additional data file.
we detected the majority of proteins commonly reported in the urine of macroalbuminuria patients.
this includes proteins such as hemopexin, zinc-α2 -glycoprotein, α-1-antichymotrypsin, α-1-microglobulin, α-2-hs-glycoprotein, afamin, apolipoprotein (apo) a-i, β-2-microglobulin, and vitamin d binding protein.
in addition, several novel proteins including extracellular matrix protein 1 (ecm1), complement factor h, myoglobin, kininogens, and galectin-3 were also identified.
we detected more than 200 low molecular weight (lmw) proteins, of which many have so far not been reported in the urine of macroalbuminuria patients [supplementary table 4].
these include proteins such as histidine-rich glycoprotein, kallikrein, fibrinogen beta chain, α-2-antiplasmin, dipeptidyl peptidase 1, lumican, apo-f, and heat shock protein β-2.
we identified several proteins in microalbuminuria group including α-1-acid glycoprotein, α-1b-glycoprotein, α-2-hs-glycoprotein, basement membrane-specific heparan sulfate proteoglycan core protein, β-2-microglobulin, cystatin-b, and transthyretin, which are similar to a large fraction of proteins identified by andersen et al.
[15] in addition, 129 unique proteins such as calreticulin, cartilage intermediate layer protein, cd2-associated protein, guanylate cyclase activator 2b, tubulin β-2c chain, acyl-coa-binding protein, fatty acid binding protein 1, gastricsin, and desmoglein-2 were also observed in the microalbuminuria group [supplementary table 6].
we identified 169 unique proteins in normoalbuminuria and several of them such as superoxide dismutase, α-l-fucosidase, complement factor b, galectin-3-binding protein, primary amine oxidase, matrix metalloproteinase-9, isoform five of prominin-1, mucin-6, tenascin xb, and annexin a5 have not been reported earlier [supplementary table 5].
we also identified reported proteins, which include n-acetyl-α-d-glucosaminidase, β2 -glycoprotein, retinol binding protein, transthyretin, α-1-microglobulin, zinc-α2 -glycoprotein, and e-cadherin in the urine of normoalbuminuria patients.
[1617] in addition to the unique proteins, we also observed proteins not present in healthy control group but present in all three diabetic groups and found that 53 proteins were common among three patient groups and were absent in the control group [figure 4].
we observed that several proteins such as zinc-α2 -glycoprotein, α-1-microglobulin, α-2-hs-glycoprotein, β-2-microglobulin, transthyretin, apo a-i, and ceruloplasmin are excreted in all patients groups [table 2].
this may be attributed to loss of negative charge and hyperfiltration of glomerular basement membrane in t2dm.
these proteins might have some predictive values and need to study further to qualify for diagnosis of dn.
until that time, this is a descriptive study.
table 2 list of total proteins identified in all type 2 diabetes groups furthermore, we compared normoalbuminuric with proteinuric (micro- and macro-albuminuria) individuals and found 303 proteins were unique to proteinuric group [supplementary table 8].
the identified proteins were including apo a-ii, cathepsin-d, ephrin-b2, guanylin and superoxide dismutase (cu-zn).
even though we identified several novel proteins at this stage, this is discovery phase study, and more validations are required before implementing their clinical utility.
supplementary table 8 unique proteome of proteinuric group (mia and ma) group when compared to na group click here for additional data file.
we have also done an independent urinary proteomic study on nondiabetic chronic kidney disease (minimal change disease, membranous glomerulonephritis, focal segmental glomerulosclerosis, and lupus nephritis) and compared the dn proteome data.
those observations are very different and found 96 proteins unique to dn only [supplementary table 9].
supplementary table 9 diabetic nephropathy unique proteins when compared with non diaaibetic glomerular diseases (mcd, fsgs, mgn and ln) click here for additional data file.
network and pathway analysis we could map close to 80% of the identified proteome for different molecular and biological network pathways.
alternate complement and blood coagulation network pathways characterized by 25 and 20 proteins, respectively, were most significantly associated with the urine proteome dataset [supplementary figure 3].
except cd59 glycoprotein, which was present in all urine samples, several proteins such as c3, c3a, c3b, ic3b, c3c, c3dg, factor d, c3bbb, c9, and membrane attack complex (mac) proteins of the alternate complement pathway were identified only in diabetic urine samples irrespective of the extent of renal damage.
however, proteins such as factor b, factor ba, factor bb, c6, c7, and c8 gamma proteins were detected both in micro- and macro-albuminuria groups while several other proteins of this pathway c5, c5a, c5b, factor h, c8α, and c8β proteins were exclusively observed in the macroalbuminuria patients [supplementary figure 3a].
we identified proteins such as antithrombin iii, fibrinogen alpha, fibrin, bradykinin, kininogen, and protein c inhibitor of the blood coagulation pathway in all urine samples while several others such as alpha-1 antitrypsin, fibrinogen beta, and alpha-2 macroglobulin were present in all diabetic patients but not in normal subjects.
proteins such as coagulation factor x and xii, protein s, plau, plasminogen, serpinf2, plasmin, and heparin cofactor two were found expressed only in macroalbuminuria subjects [supplementary figure 3b].
supplementary figure 3 genego-based pathway analysis of identified proteins from all groups.
(a) immune response based on alternative complement pathway map, (b) blood coagulation pathway.
presence of specific proteins is shown by red color thermometer bar with numbers representing specific groups as (1) control, (2) normoalbuminuria, (3) microalbuminuria, and (4) macroalbuminuria click here for additional data file.
discussion analysis of urine proteome is increasingly used for clinical investigation of various diseases.
it is well known that tubulo-interstitial changes occur as frequently as glomerular involvement in the diabetic kidney and the disease usually progresses from normoalbuminuria to micro- and macro-albuminuria.
[1819] currently, microalbuminuria is considered the best predictor of subsequent development of nephropathy in t2dm patients, but it is often induced by arterial hypertension or heart failure in older patients.
[20] in addition, it has also been observed in the progression of some diabetic patients to chronic kidney disease without evidence of albuminuria.
[2122] therefore, additional markers are needed to identify diabetic patients at a high risk of developing dn.
in the present study, we generated urine proteome of control and all three diabetic groups with high confidence.
subsequent comparisons (a) between the control and diabetic groups and (b) among the diabetic groups have identified proteins associated with each diabetic group, which could be explored further for clinical utility.
comparison with the published literature several studies have used various proteomic techniques to generate urinary proteome in dn but due to their limited sensitivity, the number of identified proteins is small.
[8910] to our knowledge, this is one of the high throughput proteomic studies that has identified large number of urinary proteins in well-defined clinical samples of t2dm patients with and without kidney complications.
in earlier studies, sharma et al.
identified 99 significantly altered spots in the urine of dn patients by employing two-dimensional differential gel electrophoresis (2de).
[5] using 2de, matrix-assisted laser desorption/ionization time-of-flight ms (tof) technique, jain et al., identified five altered proteins in the urine of diabetic patients compared to control subjects.
[7] in relatively recent studies on macroalbuminuria patients, rao et al.
identified 62 proteins using difference gel electrophoresis and lc-ms/ms approach[13] while bellei et al.
reported 54 proteins by 2de and electrospray ionization-q-tof ms/ms analysis.
[23] compared to their urinary protein profile, we detected 273 proteins that were not reported by either of them [supplementary figure 4].
we found 34 proteins common with the dataset of rao et al., of which 16 proteins had differential levels on comparison of controls and normoalbuminuria subjects.
similarly, 33 proteins were also reported by bellei et al., of which six proteins were altered in macroalbuminuria patients [table 3].
interestingly, we also detected 11 of the 19 altered proteins reported in differential serum protein analysis of dn patients[11] [supplementary table 10].
three proteins, pigment epithelium-derived factor, glutathione peroxidase, and apo e proteins that have been reported as potential serum markers were identified in the present study, suggesting their possible role as diagnostic markers for dn.
supplementary figure 4 venn diagram representing comparison of various urinary proteome studies on macroalbuminuria.
protein identifications from the current study were compared with two other studies that were carried out using high-resolution mass spectrometers (rao et al.
2007 and bellei et al.
2008).
a total of 273 proteins were unique to this study, whereas 21 and 14 proteins were unique to rao et al.
and bellei et al.
respectively click here for additional data file.
table 3 details of urinary proteins identified in ma patients and common to earlier studies supplementary table 10 urinary proteins identified in macroalbuminuria patients that also detected in serum by kim et al.
click here for additional data file.
identification of reported proteins such as α2-hs-glycoprotein precursor (fetuin a), zinc-α2 -glycoprotein, hemopexin, and vitamin d binding protein in different diabetic groups adds strength to the results from this study.
fetuin a is the most potent circulating inhibitor of calcium phosphorus precipitation and thus contributes to vascular calcification in dn.
[24] it is also an important mediator of insulin resistance, thus it is possible that in the presence of nephropathy, fetuin-a exacerbates insulin resistance and thus, worsens the pro-atherogenic milieu among t2dm patients.
zinc-α2 -glycoprotein has been reported as one of the most abundant urinary proteins in macroalbuminuria and also associated with glomerular lesions.
[13232526] higher levels of plasma hemopexin have been reported in type 2 diabetes, and they are postulated to cause glomerular inflammation and proteinuria by altering glomerular filtration barrier.
[2728] vitamin d binding protein has been consistently associated with type 2 diabetes, glucose intolerance, insulin secretion and/or resistance, and pregnancy associated-diabetes.
[2930313233] it is reported to be responsible for immunopathogenesis and progression of the dn.
[13] identification of novel urinary proteins and their possible role we also identified large number of novel proteins whose function is still not well understood.
however, the majority of them belonged to the category of binding proteins and were involved in biological activities related to carbohydrate and lipid metabolism.
several unique proteins were exclusively detected in different diabetic groups.
one such interesting protein identified only in macroalbuminuria was ecm1 that has been implicated in cell proliferation, angiogenesis, and differentiation.
hyperglycemia is known to stimulate ecm1 synthesis in mesangial and endothelial cells through generation of reactive oxygen species, and dn is characterized by excessive accumulation of extracellular matrix in the kidney.
[3435] its relevance is further strengthened with identification of complement factor h, which is a member of the regulators of complement activation family and is associated with obesity and metabolic disorders.
[36] factor h along with adrenomedullin is known to inhibit glucose-induced over-expression of ecm1 in mesangial cells induced, and thus discharge renoprotective functions.
thus, ecm1 may act as a marker of glomerular and tubulointerstitial damage.
we also detected myoglobin in macroalbuminuria patients, which is known to circulate freely in diabetic patients.
uncontrolled diabetes may induce its glycation, which is known to stimulate increased generation of free radicals and consequent renal damage.
[37] we identified both high and lmw kininogens, which are established cofactors for coagulation and inflammation and components of the kallikrein-kinin system (kks).
the kks regulates podocyte apoptosis, and thus glomerular hemodynamics and tubular function.
[38] other proteins such as immunoglobulin k-light chains (klc) and β-2-microglobulin increase in urine as a result of proximal tubular dysfunction.1939] similarly, collagen fragments identified in early renal damage in t2dm patients may help in the prognosis and monitoring of dn.
[1040] overall, it may not be unreasonable to speculate that urinary levels of lmw proteins may help in early diagnosis and work better than urine albumin levels in predicting risk of macroalbuminuria.
of many novel proteins detected exclusively in microalbuminuria patients, cd2-associated protein (cd2ap) has interesting antecedents.
a defective expression of cd2ap has been reported in dn and congenital nephrotic syndrome confirming its role in maintaining normal slit diaphragm function.
[414243] even urinary mrna levels for cd2ap are reported to be significantly higher in dn and positively correlated with urinary albumin excretion, blood urea nitrogen, and serum creatinine.
[44] another protein is cartilage intermediate layer protein, which is known to participate in extracellular matrix structure and remodeling and thus influence insulin sensitivity.
[45] we also identified many novel proteins such as klc, transthyretin, and retinol binding protein in urine of normoalbuminuric individuals.
the current assumption is that release of these proteins may be due to disturbance of tubular function in diabetes, and hence their importance is a matter of speculation.
network pathway analysis of proteome dataset identifies stage-specific proteins network and pathway analysis of the urinary proteome identified alternative complement and blood coagulation as two major pathways likely to be involved in the pathogenesis of renal complications of type 2 diabetes.
identification of common complement factors in micro- and macro-albuminuria indicates their potential role in initiation of renal complications in type 2 diabetes patients.
cd59 is known to restrict mac assembly by interacting with the terminal complement proteins c8 and c9 and thus protect kidney from complement-mediated attacks.
inactivation of cd59 due to glycation makes kidneys susceptible to increased mac deposition and contributes to extensive microvascular damage, development of atherosclerosis, and diabetic complications.
[4647] in fact, glycated human cd59 has been identified in urine of diabetic patients and correlates with the levels of glycated hb.
[48] presence of cd59 in all the groups but absence of mac in control group indicates loss of cd59 due to glycation and might predict development of kidney disease in diabetes.
subsequent progression to microalbuminuria or macroalbuminuria may depend on interaction of specific complement factors such as c5 and c8 groups, which control local pro-inflammatory response and mac assembly.
[49] these proteins and factor h were identified exclusively in macroalbuminuria patients, suggesting their importance as stage-specific markers.
in addition to its influence on extracellular matrix, complement factor h is known to accelerate the destructive action of factor i, which is a regulator molecular of the alternative pathway for immune responses.
it was equally interesting to have similar observations in the blood coagulation pathway.
presence of fibrinogen beta, bradykinin, and alpha-1 antitrypsin indicates activated extrinsic and intrinsic coagulation pathways in diabetes.
however, occurrence of clotting factors such as thrombin and fibrinogen in both micro- and macro-albuminuria suggests hypercoagulable state that is characteristic of renal complications of diabetes.
further progression to macroalbuminuria is related to dysregulation of balance between blood coagulation and fibrinolysis.
this state is exemplified by exclusive expression of factor x that participates in the formation of prothrombinase complex, and that cleaves prekallikrein to kallikrein, which catalyzes bradykinin formation and of plasminogen, serpinf2 which resulting in formation of protease-inhibitor complexes in the macroalbuminuric patients.
further quantitative analyses may help to understand whether their levels correlate with the intensity of renal damage.
this study has several strengths and few limitations.
first, we used urine samples from well-characterized t2dm patients followed over last few years.
second, the analysis used the most sensitive tools, which allowed us to identify large number of proteins with high confidence.
finally, we identified several proteins, which were reported earlier in dn patients and thus built confidence in the overall urinary proteome dataset.
one of the limitations is the absence of validation of these results and the lack of quantitative analysis of these proteins.
in spite of using very high throughput technology, we paved with few limitations.
we pooled urine samples to overcome sample preparation and lc-ms/ms analysis costs.
in the pooled samples, the biological variance between pools is reduced compared with individual samples, but practical consequence of this is that power could be reduced.
as we did not validate our identifications, we cannot say that those proteins can be used as predictive biomarkers unless they are validated in large sample size.
in summary, this study reaffirms the role of several established proteins in the pathogenesis of dn and also identifies large number of novel proteins, specific to different stages of dn.
we propose an important role of alternate complement and blood coagulation pathways, which fits with the currently existing hypothesis in the development of microvascular complications of diabetes.
this study provides a resource useful for further exploration of these proteins as markers for various stages of diabetes.
financial support and sponsorship the funds for this study were provided by the council of scientific and industrial research (csir), ministry of science and technology, government of india, india under xii 5-year plan grant thunder (to grc).
conflicts of interest there are no conflicts of interest.
@highlight
diabetic nephropathy (dn) is the most common cause of chronic kidney disease.
although several parameters are used to evaluate renal damage, in many instances, there is no pathological change until damage is already advanced.
mass spectrometry-based proteomics is a novel tool to identify newer diagnostic markers.
to identify urinary proteins associated with renal complications in diabetes, we collected urine samples from 10 type 2 diabetes patients each with normoalbuminuria, micro- and macro-albuminuria and compared their urinary proteome with that of 10 healthy individuals.
urinary proteins were concentrated, depleted of albumin and five other abundant plasma proteins and in-gel trypsin digested after prefractionation on sodium dodecyl sulfate polyacrylamide gel electrophoresis.
the peptides were analyzed using a nanoflow reverse phase liquid chromatography system coupled to linear trap quadrupole-orbitrap mass spectrometer.
we identified large number of proteins in each group, of which many were exclusively present in individual patient groups.
a total of 53 proteins were common in all patients but were absent in the controls.
the majority of the proteins were functionally binding, biologically involved in metabolic processes, and showed enrichment of alternative complement and blood coagulation pathways.
in addition to identifying reported proteins such as α2-hs-glycoprotein and vitamin d binding protein, we detected novel proteins such as cd59, extracellular matrix protein 1 (ecm1), factor h, and myoglobin in the urine of macroalbuminuria patients.
ecm1 and factor h are known to influence mesangial cell proliferation, and cd59 causes microvascular damage by influencing membrane attack complex deposition, suggestive their biological relevance to dn.
thus, we have developed a proteome database where various proteins exclusively present in the patients may be further investigated for their role as stage-specific markers and possible therapeutic targets.
