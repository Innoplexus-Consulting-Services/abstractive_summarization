1 background cancer is a complex and multifactorial disease.
although its malignant features have been known for centuries, it was not until the advent of modern biology that the molecular determinants of cancer transformation have been elucidated.
in 1911, pioneering work from peyton rous showed that avian sarcomas were transmissible to other healthy fowls through a filtrate of the tumours devoid of cells [1], [2].
later on, the agent present in those extracts and responsible for tumour formation was identified as a retrovirus, later called rous sarcoma virus.
this important discovery started the field of tumour virology and led to the identification of the oncogene v-src [3], [4], [5], [6], first in retroviruses and then in normal avian dna [7].
the emerging idea was that cancer was caused by alterations of the genome.
since then, other oncogenes, including myc, ras, erbb, pi3k [2], [6] and the first tumour suppressor gene rb1 [8], [9] were discovered.
the causative role of rb1 inactivation in retinoblastoma formation reinforced the concept of cancer initiation driven by genomic alterations.
these discoveries led knudson and colleagues to hypothesise a “multiple-hit” model of tumorigenesis, where multiple genetic alterations are required to achieve full blown transformation [8].
we now know that tumorigenesis requires the acquisition of multiple enabling features, the hallmarks of cancer, among which metabolic rewiring is becoming increasingly recognised [10], [11].
in a seminal paper, shim et al.
showed that lactate dehydrogenase a (ldha) is a target of the proto-oncogene myc and is required for myc-induced anchorage-independent growth in both human and mouse cellular models [12].
since then, scientists have uncovered several aspects of the metabolic reprogramming of cancer, and realised that not only dysregulated metabolism is required to sustain proliferation but it also affects tumour microenvironment and the immune response [11].
the discovery that mutations in the metabolic genes fumarate hydratase (fh) [13], succinate dehydrogenase (sdh) [14], [15], [16], [17] (idh) [18], [19], [20], [21] lead to cancer further supported a primary role of metabolic alterations in tumorigenesis.
thanks to these discoveries, a novel paradigm is emerging whereby mitochondrial metabolites that accumulate in these conditions act as oncogenic signalling molecules, becoming bona fide oncometabolites.
recent data suggest that reprogramming of cellular metabolism occurs both as direct and indirect consequence of oncogenic mutations and that environmental cues, such as hypoxia, could affect the metabolic phenotype of cancer cells and the abundance of oncometabolites, amplifying oncogenic cascades.
in this review we describe the main oncogenic functions of oncometabolites and how their abundance can be affected by genetic mutations and environmental cues.
2 tca cycle enzymes mutations and the emerging paradigm of oncometabolite-driven tumorigenesis sdh was the first mitochondrial enzyme found mutated in cancer [14].
it was the first time that mutations of a mitochondrial enzyme, once thought to be incompatible with life [22], were linked to tumour predisposition.
this and the subsequent discovery of fh mutations in renal cancer catalysed a substantial effort to elucidate the molecular links between mitochondrial dysfunction and tumorigenesis.
these major findings are reported below.
2.1 succinate dehydrogenase (sdh) sdh is an enzyme of the tca cycle involved in the conversion of succinate to fumarate and a key component of the mitochondrial respiratory chain.
this enzyme is composed of four subunits, sdha, sdhb, sdhc, sdhd; and two assembly factors, sdhf1 and sdhf2 [23].
mutations in sdh are found in familial paraganglioma and pheochromocytoma [14], [15], [16], [17], [24], [25], renal carcinomas [26], t-cell leukaemia [27], and gastrointestinal stromal tumours [28].
sdh deficiency causes profound metabolic changes.
recent work showed that mouse sdh-deficient cells have a high demand of extracellular pyruvate and utilise glucose-derived carbons for aspartate biosynthesis through pyruvate carboxylation [29], [30].
interestingly, this metabolic rewiring could be used to selectively target sdhb-/- cells [29].
one of the most striking features of sdh-deficient cells is the accumulation of succinate [31], a metabolite implicated in tumorigenesis and, for this reasons, recently defined an oncometabolite [32].
among its many functions, succinate is a competitive inhibitor of α-ketoglutarate (akg)-dependent dioxygenases (akgdd), a class of enzymes involved in a plethora of biological processes.
for instance, succinate inhibits prolyl-hydroxylases (phds), akgdds involved in the degradation of hypoxia inducible factor (hif), leading to the aberrant stabilisation of hifs even when oxygen is abundant, a condition called pseudohypoxia [33].
succinate inhibits other akgdds, including ten-eleven translocation proteins (tets), enzymes involved in dna demethylation [34], [35], leading to cpg island hypermethylation [36].
succinate also causes the inhibition of histone lysine demethylases (kdms), akgdds involved in histone demethylation [34], causing even further epigenetic changes [36], [37].
interestingly, dna hypermethylation phenotype was associated with dedifferentiation and increased invasion potential of sdh-deficient tumours [36], [38].
however, the molecular mechanisms behind this phenotypic switch are still under investigation.
2.2 fumarate hydratase fh is an enzyme of the tca cycle that converts fumarate to malate.
whilst homozygous fh mutations cause fumaric aciduria, a condition associated with infantile encephalopathy and brain malformations [39], heterozygous fh mutations followed by the loss of heterozygosity of the second allele cause hereditary leiomyomatosis and renal cell cancer (hlrcc) [13], [40].
fh is also mutated in paraganglioma, pheochromocytoma [41], [42], downregulated in sporadic clear cell carcinomas [43] and deleted in neuroblastoma [44].
cristal structure of human fh showed that clinically-relevant mutations affect evolutionary conserved regions involved in either the catalytic activity or the folding and stability of the protein [45], leading to abnormal accumulation of fumarate [46], [47], [48].
loss of fh also leads to a complex rewiring of cell metabolism.
for instance, fh loss leads to an increased uptake of glutamine that is diverted into haem synthesis and bilirubin excretion to maintain mitochondrial nadh production and mitochondrial potential.
also, the accumulation of fumarate in fh-deficient cells leads to the reversal of the urea cycle enzyme argininosuccinate lyase (asl), causing the production of argininosuccinate from fumarate and arginine [47], [48].
this metabolic rewiring makes fh-deficient cells auxotrophic for arginine and sensitive to arginine-depriving agents such as arginine deiminase [48].
interestingly, arginine depletion has been proposed as therapeutic intervention for renal cell carcinoma [49].
however, in this case, arginine auxotrophy is caused by inactivation of argininosuccinate synthase (ass1), the urea cycle enzyme that converts aspartate and citrulline to argininosuccinate, which is then converted to arginine and fumarate by asl.
inactivation of ass1 has been shown to allow the diversion of aspartate from the urea cycle to pyrimidine biosynthesis, favouring tumour growth [50].
it is tempting to speculate that in fh-deficient cells the activity of ass1 is inhibited by the accumulation of argininosuccinate, leading to increased pyrimidine biosynthesis.
consistent with an increased utilisation of aspartate, the intracellular levels of this metabolite are very low in fh-deficient cells [48].
however, the rate of pyrimidine synthesis is these cells has not been assessed yet.
fumarate has been implicated in tumorigenesis of hlrcc and, for this reason, included in the list of oncometabolites [51].
similarly to succinate, fumarate inhibits several akgdds, including phds, leading to pseudohypoxia [52].
of note, the non-canonical activation of nf-kb signalling by fumarate also contributes to the pseudohypoxic phenotype in fh-deficient cells [53].
although pseudohypoxia has been considered an important driver of tumorigenesis, recent data showed that hifs are dispensable for the formation of benign pre-tumorigenic lesions in fh1-deficient mice [54].
therefore, other mechanisms have been proposed to explain fumarate-dependent tumorigenesis.
for instance, recent findings identified the abelson murine leukemia viral oncogene homolog 1 (abl-1) as potential driver in fumarate-dependent tumorigenesis [55].
interestingly, abl-1 inhibitors suppress the invasion properties of fh-deficient cells both in vitro and in vivo.
mechanistically, through abl-1 activation, fumarate stimulates an antioxidant response mediated by transcription factor nfe2-related factor 2 (nrf2), and a metabolic rewiring through activation of mammalian target of rapamycin (mtor)-hif axis [55].
fumarate was also shown to promote broad epigenetic changes [56], caused by inhibition of histone and dna demethylases [34], [35].
however, the relevance of these epigenetic changes in tumorigenesis is still under investigation.
finally, fumarate, a mild electrophilic molecule, was demonstrated to react with thiol residues of proteins through a process called succination [57], [58], [59], [60].
this post-translational modification is a distinctive feature of fh-deficient tumours and now used for diagnostic purposes [58].
although several succinated proteins have been identified in fh-deficient cells [60], [61], the biological roles of this process are still under investigation.
it was recently reported that succination of mitochondrial aconitase (aco2) impairs its enzymatic activity [61] and succination of kelch-like ech-associated protein-1 (keap-1) inhibits its negative modulatory effect on the transcription factor nrf2 [54], [62].
although nrf2 activation has been previously reported as pro-tumorigenic event [63], its role in fh-deficient tumours is still debated.
the thiol residue of the antioxidant tripeptide glutathione (gsh) is also subject of succination [64], [65] and its depletion causes oxidative stress, which induces senescence in primary fh-deficient kidney cells.
of note, genetic ablation of p21, a major player in senescence induction, induces transformation of benign cysts in fh-deficient mice indicating the tumour-suppressive role of senescence in fh-mediated tumorigenesis [65].
besides revealing potential mechanisms of tumorigenesis caused by loss of fh, these works led to the identification of fumarate as important regulator of redox homeostasis, which goes beyond fh deficiency.
for instance, jin et al.
showed that fumarate generated within the tca cycle can regulate the activity of the antioxidant protein glutathione peroxidase (gpx), modulating the antioxidant capacity of the cell.
of note, this function of fumarate is not caused by succination but, rather, by the binding of fumarate to the protein [66].
2.3 isocitrate dehydrogenase (idh1/idh2) isocitrate dehydrogenases (idhs) are homodimeric enzymes responsible for the reversible oxidative decarboxylation of isocitrate to akg.
three different isoforms of idh have been described, which have distinct subcellular compartmentalisation.
idh3 is a nad+-dependent mitochondrial enzyme, core component of the tca cycle.
the other two idh isoforms (idh1 and idh2) are nadp+-dependent proteins expressed respectively in cytosol and mitochondria [25], [67].
heterozygous missense mutations affecting idh1 and idh2 were found in gliomas [18], [19] and in acute myeloid leukaemia (aml) [20], [21].
at odds with sdh and fh, idh mutations are gain-of-function mutations and confer to the enzyme the ability to produce the oncometabolite d-2-hydroxyglutarate (d-2hg) [68], [69].
2hg, the reduced form of akg, is naturally present in two optic isomers,d-2hg and l-2hg.
in normal cells, 2hg is a minor by-product of metabolism and its levels are kept low by the activity of a conserved family of proteins, the l/d-2-hydroxyglutarate dehydrogenases (l2hgdh and d2hgdh) [70], [71], which convert 2hg to akg.
homozygous germline mutations in these two enzymes are responsible for a severe form of 2hg aciduria characterised by developmental abnormalities and premature death in children [71], [72].
moreover, mutations in l2hgdh have been associated with brain tumours [73] and, recently, with kidney cancer [74].
both isomers of 2hg can affect the enzymatic activity of akgdd.
whilst the role of d-2hg in phd inhibition and hif stabilisation is still controversial [75], this metabolite was shown to inhibit both tets and kdms [76], [77].
consistently, idh1-mutant tumours exhibit dna hypermethylation in gliomas [78] and leukemia [79], and histone hypermethylation [80].
evidence that tet2 and idh1/2 mutations are mutually exclusive in aml tumours [79] supports the notion that tets inhibition and the ensuing dna hypermethylation are instrumental to idh-driven tumorigenesis.
this hypothesis has been recently corroborated by the finding that dna hypermethylation causes reduced ccctc-binding factor (ctcf) binding to dna, leading to aberrant activation of the oncogene platelet-derived growth factor receptor (pdgfra) [81] in gliomas.
other mechanisms have been proposed to contribute to 2hg-dependent tumorigenesis in idh-mutant tumours.
for instance, 2hg accumulation inhibits atp synthase within the mitochondria activating a series of downstream signals that involve mtor suppression [82].
regardless the molecular underpinnings, research on idh-mutant tumours uncovered an unexpected but powerful role of 2hg as oncogenic molecule.
in support of this role, it was demonstrated that the incubation of cells with d-2hg promotes cytokine independence and alters differentiation in hematopoietic cells, proving compelling evidence that a small molecule is sufficient to transform cells [83].
interestingly, the role of 2hg in tumorigenesis goes beyond idh-mutant tumours.
for instance, 2hg accumulation can be driven by a metabolic reprogramming caused by myc activation in aggressive breast cancer, leading to dna hypermethylation akin to that observed in idh mutant tumours [84].
also, 2hg can be produced by the promiscuous activity of the enzyme phosphoglycerate dehydrogenase, another important oncogene in breast cancer [85].
3 succinate, fumarate, and 2hg: overlapping and distinct functions the brief description above suggests that signalling cascades elicited by fumarate, succinate, and 2hg, share some common targets but also exhibit distinct features, which can explain the different types of tumours associated with their accumulation (fig.
1).
the converging signatures, mostly mediated by akgdd inhibition, include pseudohypoxia and broad epigenetic changes, such as dna and histones hypermethylation.
interestingly, recent studies showed that pseudohypoxic genes, besides being regulated by hifs, are also transcriptionally controlled by tets.
therefore, epigenetic changes are required for a full pseudohypoxic response triggered by these metabolites.
however, these metabolites have different ic50 for tets and kdms [35], suggesting that their epigenetic effect might have different outcomes, with fumarate being the most effective tets inhibitor and 2hg the poorest.
these metabolites exert other distinct biological functions.
as indicated above, fumarate accumulation leads to protein succination, triggering a plethora of biological changes that may synergise with or counteract akgdds inhibition.
also, accumulation of 2hg has been shown to increase protein succinylation via inhibition of sdh and subsequent accumulation of succinyl-coa [86].
this post translation modification leads to a reprogramming of mitochondrial function and induces resistance to apoptosis.
finally, fumarate and 2hg elicit opposite effects on mtor signalling, with important consequences for the development of specific tumour types [55], [82].
therefore, although characterised by a very similar chemical structure, succinate, fumarate, and 2hg, appear to have distinct biological roles, well beyond inhibition of akgdds.
4 environmental cues regulates oncometabolite production the observation that 2hg is sufficient to promote tumorigenesis [83] raised the possibility that environmental cues that increase this metabolite could contribute to tumorigenesis, without underpinning idh mutations.
in support to this hypothesis, it has been shown that hypoxia leads to the production of 2hg (fig.
2), either via reductive carboxylation [87] or via promiscuous substrate usage of ldha [88] and malic dehydrogenase 1/2 [89].
since hypoxia is a common feature of solid tumours [90] it is possible that hypoxia-driven production of 2hg elicits (epi)genetic changes that drive or amplify the process of tumorigenesis.
2-hg is not the only oncometabolite whose levels are altered by hypoxia.
during ischemia, succinate significantly accumulates in multiple organs and its oxidation is responsible for ros generation during reperfusion [91].
succinate was also shown to increase under hypoxic conditions, in cancer cells cultured in 3d scaffolds [92], consistent with its role as hypoxia sensing molecule.
other cues trigger oncometabolite accumulation.
for instance, fumarate was shown to accumulate in hyperglycemic conditions [59], [93] (fig.
2), likely as a consequence of mitochondrial dysfunction caused by glucose accumulation [94], [95].
we hypothesise that fumarate accumulation observed in diabetes [93], [95], could, at least in part, explain the increase cancer risk in these patients.
together, these studies seem to suggest that environmental or nutritional cues may cause dysregulation of mitochondrial function, leading to oncometabolite accumulation in the absence of underpinning oncogenic mutations.
5 future perspectives oncometabolites are emerging as key components of the communication between mitochondria and the nucleus.
chronic accumulation of these small molecules triggered by genetic or environmental cues may alter the epigenetic landscape of the cell eliciting oncogenic signalling cascades.
this new paradigm of tumorigenesis challenges the role of gene mutations as the exclusive driving mechanism of tumorigenesis and suggests that the latter may be only one of the possible mechanisms that lead to transformation.
competing interests the authors declare no competing interests.
authors’ contribution ms and cf jointly wrote the manuscript.
authors’ information ms is a research associate in the laboratory of cf.
cf is a group leader at the mrc cancer unit, university of cambridge, cambridge, uk.
ms and cf are funded by an mrc core funding to the mrc cancer unit.
@highlight
cancer is a complex and heterogeneous disease thought to be caused by multiple genetic lesions.
the recent finding that enzymes of the tricarboxylic acid (tca) cycle are mutated in cancer rekindled the hypothesis that altered metabolism might also have a role in cellular transformation.
attempts to link mitochondrial dysfunction to cancer uncovered the unexpected role of small molecule metabolites, now known as oncometabolites, in tumorigenesis.
in this review, we describe how oncometabolites can contribute to tumorigenesis.
we propose that lesions of oncogenes and tumour suppressors are only one of the possible routes to tumorigenesis, which include accumulation of oncometabolites triggered by environmental cues.
