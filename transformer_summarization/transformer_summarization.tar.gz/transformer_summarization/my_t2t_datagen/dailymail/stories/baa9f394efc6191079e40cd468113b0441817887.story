1 introduction populations are ageing in industrialized societies across the world: it is forecast that, by 2020, there will be as many people over 60 years old as people under 15 years old in the global population (harper, 2014).
among many challenges, this demographic shift brings with it a greater proportion of the population in cognitive decline, one of the most feared—and economically costly—sequela of ageing (wimo, jönsson, bond, prince, & winblad, 2013).
cognitive decline is pervasive even in healthy older adults without dementia (boyle et al., 2013), and is associated with a reduction in the ability to perform everyday functions, make important decisions, and thus live independently (boyle et al., 2012, tucker-drob, 2011a).
consequently, research efforts to understand, and thus potentially mitigate, the effects of normal cognitive decline are of great practical importance.
a fundamental question in the field of cognitive ageing, addressed in this study, asks: why do some people's cognitive abilities decline more steeply than others'?
many risk and protective factors for cognitive ageing have been proposed, both by epidemiological researchers and in the popular media.
they span genetic, health, physical, lifestyle, and socio-demographic contributors (e.g.
brunner, 2005, salthouse, 2014).
a systematic review of the literature (plassman, williams, burke, holsinger, & benjamin, 2010) concluded that factors such as smoking status, diabetes mellitus, and the apoe e4 genotype were associated with more cognitive decline, whereas better physical health and some kinds of cognitive training were protective against it.
however, the often-contradictory studies meant that the overall evidence was rarely assessed to be strong in either direction.
importantly, variables that are known to affect the intercept or starting point of cognitive decline (such as education, which has been suggested to boost cognitive ability levels into later life; banks and mazzonna, 2012, clouston et al., 2012, stern, 2002) do not necessarily affect its rate of progression (tucker-drob, johnson, & jones, 2009).
this lack of consistent findings may stem from the fact that each individual study only examined a small number of potential correlates.
due to mutual intercorrelations, correlations involving some putative risk factors may be partially or fully artefacts of associations driven by other, often unmeasured, factors.
if only small numbers of predictors are included in a study, these confounding relations will be missed.
studies that simultaneously include a large number of potential predictors can more effectively reduce this type of confounding.
for the present analysis, we took a multivariate approach, examining a detailed longitudinal dataset.
we included a cross-cutting, yet carefully selected, set of potential socio-economic, somatic fitness, health, and genetic predictors of cognitive ageing, all of which had previously been investigated in the literature.
many—though by no means all—previous studies have also been limited by small cognitive batteries, often with single indicators of cognitive domains.
sometimes, tests that are intended to screen for dementia, such as the mini-mental state examination (folstein, folstein, & mchugh, 1975) are used to indicate cognitive function.
such tests are less sensitive to subclinical levels of, and changes in, cognitive functions.
the reliance on such instruments can attenuate, obscure, or even reverse the sign of associations with cognitive change (wang, zhang, mcardle, & salthouse, 2009).
moreover, the reliance on changes in specific cognitive tests, rather than more general factors, limits generalizability: it is unclear whether the test-specific results obtained will hold for other tests or domains.
this may also be a source of inconsistency across studies, if risk factors associate with decline in some cognitive tests or skills, but not others.
the current study estimated latent factors of cognitive levels and cognitive changes from a broad assortment of highly sensitive cognitive tests developed to capture both normal range and clinical-range variation in four distinct domains: visuospatial ability, memory, crystallized ability, and processing speed (tucker-drob, briley, starr, & deary, 2014).
these latent factors represent shared variation among different cognitive abilities, and shared variation in their changes across time.
by examining changes in latent factors, rather than in individual tests, we ensured that our results pertained to the theoretical cognitive constructs in which we were interested, rather than to idiosyncratic aspects of specific tests.
we also examined correlates of a general factor of cognitive change, which previous research has found to account for between approximately one half and two-thirds of the variance in later-life cognitive decline across many tests (e.g.
ghisletta et al., 2012, lindenberger and ghisletta, 2009, reynolds et al., 2002, tucker-drob, 2011b, tucker-drob et al., 2014).
we report findings from the lothian birth cohort 1936 (lbc1936), a sample of older individuals (initial n = 1091) recruited at mean age 70 years who had taken an intelligence test at mean age 11 in 1947. they were tested on a varied battery of cognitive tests at age 70, and these were repeated at ages 73 and 76. the eighth decade of life is an important time for studying cognitive ageing, because of the doubling in the risk of dementia that occurs across it (matthews & brayne, 2005).
we modelled many potentially predictive factors first individually, and then in concert.
these included socio-demographic (sex, education, parental occupational status, own occupational status, deprivation of the residential area), physical fitness (lung function, walking speed, and grip strength), genetic (apoe e4 status), lifestyle (smoking and body mass index), and health (cardiovascular disease, hypertension, and diabetes) variables, as well as childhood cognitive ability.
by including this latter variable in the model, we were able to test the extent to which any associations of the covariates with later-life cognitive ability were confounded by prior ability.
to assess change within old age, we used a ‘factors of curves’ model (mcardle, 1988), which involved modeling the slope of longitudinal change in each test in a latent growth curve model, then loading these slopes onto cognitive domains (visuospatial ability, crystallized ability, memory, and speed), which are themselves loaded onto the general factor of cognitive change (fig.
1).
the predictors were tested for their associations with this general factor, and with the domain factors.
note that a previous study (tucker-drob, briley, et al., 2014) examined a similar set of questions in data from the lbc1936, but was limited by the inclusion of only two waves of testing (subsequent data were not available at that time).
it could not, therefore, use growth curve modeling, relying instead on latent change score modeling.
the present study thus doubles the time-frame of the previous paper (from approximately three to six years).
it includes two extra potential predictors (body mass index and alcohol consumption).
it assesses the associations of the potential predictors with general factors of level and change, in addition to the domain-level factors that were investigated in the previous paper.
it also includes a set of four sensitivity analyses—ruling out potential confounders such as dementia status and mood state—that were not included in the previous paper.
thus, with our combination of a ‘factors of curves’ model and a wide range of covariates, our study was able simultaneously to address the following two questions.
first, to what extent do different domains of cognitive ability age together, or seperately?
second, which, if any, variables predict between-person variation in cognitive changes, both in the specific cognitive ability domains and more generally across all cognitive abilities, from age 70 to 76, even after multivariate statistical control for a host of covariates?
2 method 2.1 participants three waves of data in older age were available for members of the lothian birth cohort 1936 (lbc1936; deary et al., 2007, deary et al., 2012), a narrow-age sample of community-dwelling individuals, living mostly in the edinburgh and lothians area of scotland, uk.
all of the participants were born in 1936 and were aged approximately 11 years at the time of the scottish mental survey of 1947, in which most completed the same group test of general intelligence (scottish council for research in education, 1949).
they were followed up in 2004–2007 (wave 1: mean age 69.53 years, sd = 0.83; n = 1091, 543 female), again in 2007–2011 (wave 2: mean age 72.49 years, sd = 0.71 n = 866, 418 female), and again in 2011–2014 (wave 3: mean age 76.25 years, sd = 0.68; n = 697, 337 female).
for the present study, 552 participants contributed data on all cognitive tests and all covariates at all three waves, though the models took into account all the available data (see statistical analysis, below).
the mean time between waves 1 and 2 was 2.98 years (sd = 0.28), and between waves 2 and 3 was 3.77 years (sd = 0.28).
from waves 1 to 3, the mean time lag was 6.75 years (sd = 0.31), with a minimum of 5.12 years and a maximum of 8.98 years.
the youngest participant at wave 1 was aged 67.61 years, and the oldest participant at wave 3 was aged 77.70 years.
before participation, all cohort members completed a written consent form.
the study was approved by the multi-centre research ethics committee for scotland (mrec/01/0/56; 07/mre00/58) and the lothian research ethics committee (lrec/2003/2/29).
2.2 measures 2.2.1 cognitive tests 2.2.1.1 later-life cognitive ability the participants completed a battery of thirteen individually-administered cognitive tests in the same location, and using the same equipment and instructions, at all three waves (deary et al., 2007).
following previous analyses on this battery of cognitive tests (tucker-drob, briley, et al., 2014), we hypothesized that the tests' scores were grouped into the following four domains.
visuospatial ability consisted of two subtests from the wechsler adult intelligence scale, 3rd uk edition (wais-iiiuk; wechsler, 1998a): matrix reasoning and block design.
it also included the spatial span (forward and backward) subtest from the wechsler memory scale, 3rd uk edition (wms-iiiuk; wechsler, 1998b).
the spatial span score used here was an average of forward and backward performance.
processing speed was measured using two pencil-and-paper tests from the wais-iiiuk (symbol search and digit-symbol substitution), and two tests using dedicated instruments: four-choice reaction time, where participants have to press one of four buttons indicated by a number from 1 to 4 flashed up on an lcd screen (deary, der, & ford, 2001), and inspection time, where participants must discriminate between two figures flashed on a computer screen for a variety of durations from 200 ms to 6 ms, then immediately backward-masked.
there were 150 inspection time trials (10 at each of 15 durations), and the measure we used was the total number of correct responses (deary et al., 2004).
verbal memory was measured using two subtests from the wms-iiiuk (verbal paired associates and logical memory), and the digit span backward subtest of the wais-iiiuk.
crystallized ability was measured by two tests that involved the participant reading aloud a list of irregular words of decreasing linguistic frequency (and thus increasing difficulty): the national adult reading test (nart; nelson & willison, 1991), and the wechsler test of adult reading (wtar; wechsler, 2001).
we also included a test of phonemic verbal fluency (lezak, 2004).
2.2.1.2 age 11 cognitive ability most participants had completed the moray house test no.
12, at mean age 11 (scottish council for research in education, 1949).
it is a group-administered, general intelligence/iq-type test, with a 45-minute time limit.
it has a preponderance of verbal reasoning items, and also some numerical and other items.
in concurrent validity testing, it correlated about r = 0.8 in childhood with the individually-administered stanford-binet test (deary, whalley, lemmon, crawford, & starr, 2000).
2.2.2 covariates a variety of socio-demographic, physical fitness, genetic, lifestyle, health, and mood covariates were measured at wave 1 (in the case of mood, also at waves 2 and 3).
all had previously been linked to cognitive ageing, though never all together in the same model.
2.2.2.1 socio-demographic number of years of formal, full-time education was reported at interview at the first testing wave.
in addition, three measures of socioeconomic status (ses) were recorded.
first, we noted the occupational class of the participant's father's job, rated on a 5-point scale from class i (professional) to class v (unskilled; office of population censuses and surveys, 1951).
second, we noted the occupational class of the participant's own most prestigious job before retirement (on a similar scale with an extra distinction between manual and non-manual work in class iii; office of population censuses and surveys, 1980).
third, for each person's small area of residence in later life, we obtained a score using the scottish index of multiple deprivation (scottish executive, 2006), a neighborhood-level measure of ses that ranked 6505 geographic areas in scotland from most to least deprived, based on income, employment, health, crime, and other socio-demographic indicators.
this measure was split into eight groupings for the purposes of the current analysis, with higher numbers indicating less deprivation.
2.2.2.2 physical fitness three measures of physical function were taken at the first testing wave.
first, lung function was indexed by forced expiratory volume (fev) in one second (best of three attempts), measured using a micro medical spirometer.
second, time to walk 6 m was recorded.
third, grip strength was measured using a north coast hydraulic hand dynamometer for the left and right hands, and averaged into an overall index.
2.2.2.3 genetic the participants provided samples of blood for dna extraction.
each participant's apolipoprotein e (apoe) e4 status (either one or two e4 alleles present vs. no e4 alleles) was genotyped using taqman technology at the wellcome trust clinical research facility genetics core at the western general hospital, edinburgh.
2.2.2.4 lifestyle smoking status (current smoker/ever smoked vs. never smoked), was also recorded at interview.
alcohol consumption (in grams per week) was recorded from a food frequency questionnaire taken at age 70, as described by corley et al.
(2011).
2.2.2.5 health body mass index was calculated in the standard fashion, by dividing the participant's weight (in kg) by their height (in m) squared.
self-reported diagnosis history of three illnesses potentially related to cognitive ageing—cardiovascular disease, hypertension, and diabetes—was recorded at interview as a dichotomous variable (presence vs. absence of the illness).
2.2.2.6 mood mood was measured using the hospital anxiety and depression scale (hads; zigmond & snaith, 1983), a questionnaire that was completed by the participants at all three waves.
the scale includes 7 anxiety-related items (e.g.
“i feel tense or ‘wound up’”), and 7 depression-related items (e.g.
“i look forward with enjoyment to things”; negatively scored).
the participants rated their agreement with each item, or how often they had the particular experience mentioned in the item, on a 4-point scale.
these items were summed into a total hads score at each of the waves that was used in our sensitivity analysis as a time-varying covariate.
2.3 statistical analysis data were analyzed using a multivariate latent growth curve approach (mcardle, 2009), implemented in mplus v7.3 (muthén & muthén, 1998–2014) using full-information maximum likelihood (fiml) estimation to take all data into account.
the model estimates the overall level of each cognitive test (in effect, the intercept at mean age 70 years) and the slope of its change across the three measurement waves (in effect, the trajectory between age 70 and 76 years).
we used the average time lag between the waves (2.98 years from waves 1 to 2, and 6.75 years from waves 1 to 3) as the path weights for calculation of the slope factor, with the path from the slope factor to the initial wave's test score being set to zero.
the resulting latent level and slope factors can then be analyzed as if they were directly measured variables: their organization into higher-order factor structures can be investigated (for this reason, the analysis is known as a ‘factor of curves’ model (mcardle, 1988; fig.
1)), as can their relations with covariates.
see the supplementary method section for a description of our calculations of the percentage variance explained at each level of the model.
we first fit a model in which growth curves were estimated for each individual test, while estimating an unstructured covariance matrix in which all levels and all slopes were allowed to correlate with one another.
as this model is the least constrained model possible, we used it as a baseline against which to judge the fit of the more parsimonious factors of curves models.
next, we estimated a single general factor from the growth curve levels for each test.
we tested whether it was possible to extract a similar general factor of cognitive change from the growth curve slopes.
we tested whether this ‘general factors only’ model had good fit to the data.
we then tested whether better model fit could be achieved with a hierarchical structure, in which intermediate domain-specific factors were modelled, first for the levels, and then for the slopes.
model fit was tested using four absolute fit indices: root mean square error of approximation (rmsea; values < 0.06 considered acceptable), comparative fit index (cfi; values > 0.95 considered acceptable), tucker-lewis index (tli; values > 0.95 considered acceptable), and standardized root mean square residual (srmr; values < 0.08 considered acceptable).
models were compared using the chi-square test and by comparing two relative fit indices: akaike information criterion (aic) and bayesian information criterion (bic).
the large number of significance tests in our analyses increases the chance of a false positive result.
for that reason, we corrected the p-values in our two main models (the models with simultaneous covariate associations with general factors—36 tests—and domain factors—144 tests—respectively) for multiple comparisons using hochberg's false discovery rate (fdr) correction (benjamini & hochberg, 1995).
below, we report the results with and without this correction.
3 results 3.1 ageing-related change in cognitive tests descriptive information about the cognitive tests and the covariates, and their zero-order relations with one another, is provided in the supplemental materials document (tables s1–s3).
we first tested whether there was significant ageing-related mean change in each of the cognitive tests from age 70 to 76. in the baseline model in which all levels and slopes were free to covary, there was a significant, negative mean slope across the three waves in ten of the thirteen cognitive measures.
the trajectories for each test (slope means) are detailed, alongside the means and variances for the intercepts, in table 1, taken as a difference from each individual's baseline score.
they are illustrated (purely descriptively, for each individual) in fig.
2. the three tests that did not show significant mean decline were the national adult reading test, verbal fluency, and logical memory, the latter of which had a positive (though non-significant) mean slope.
3.2 prediction of study (non-)attendance as noted above, we used fiml estimation to reduce bias due to missing data.
this operated under a ‘missing at random’ assumption (rubin, 1976), that patterns of missingness in the data were not systematically related to the missing scores themselves, but could be accounted for by other data within the model.
to test the extent to which the other variables accounted for study attendance at the two follow-up waves, we ran two logistic regression models with attendance/non-attendance at age 73 and age 76 as the outcome variables, respectively, and all of the predictor variables described above as predictors (we did not include the time lag between waves as a predictor in these models as this information is undefined for participants who did not return).
from these models, we produced the roc curves shown in fig.
s1 in supplementary materials.
the area under the curve estimates (where 1.00 indicates perfect prediction and 0.50 indicates prediction that is no better than random chance) were 0.644 for wave 2 attendance and wave 2 and 0.640 for attendance at wave 3. nagelkerke's r2 showed that the logistic regression model accounted for 6.9% of the variance at wave 2 and 7.5% of the variance at wave 3. thus, the predictions of attendance were weak, but the predictors did provide a modest amount of additional information which could be used by the fiml algorithm to reduce bias.
we thus included all the potential predictors as ‘auxiliary’ variables (e.g.
muthén & muthén, 1998–2014, p.389) in the models below that estimated the structure of cognitive change.
auxiliary variables are taken into account by fiml even though they are not explicitly included as covariates in the model.
3.3 structure of cognitive change we compared the fit of alternative models of the structure of cognitive ability levels and changes to one another and to the baseline model of unstructured level-change covariance.
in many of our factor models, six of the tests' slopes had specific variances that were near-zero and were thus sometimes estimated as negative, indicating that all variance in change on that test was shared with the domain above them (i.e.
they have a standardized loading of 1.0).
therefore, to allow the models to converge on within-bounds estimates, we fixed the specific variance of these six slopes (spatial span, wtar, verbal fluency, verbal paired associates, digit-symbol substitution, choice reaction time) to zero in our factor models.
table 2 reports model fit comparisons of alternative factor models of levels and changes.
as is the case for most applications of factor analysis, there was a significant increase in χ2 misfit associated with all factor models relative to the unstructured (level and slope) covariance matrices (all p-values < 0.001).
all models, however, fit well by rmsea, cfi, and tli indices relative to the covariance matrix of the raw data.
in order to gauge local fit of the factor models of levels relative to an unstructured level covariance matrix, and local fit of the factor models of the slopes relative to an unstructured slope covariance matrix, we also calculated rmsea indices for these comparisons (rightmost column of table 2).
the rmsea for a general factor model of the levels (model 2), with no domain-specific group factors, compared to an unstructured level covariance matrix (model 1) was unacceptable (rmsea = 0.102), whereas the rmsea for a hierarchical factor model of the levels (model 3), compared to the same unstructured level covariance matrix, was good (rmsea = 0.049).
chi square, aic, and bic comparisons also indicated that the hierarchical structure of levels (model 3) had superior fit to a model with only a general factor of levels (model 2; χ2(4) = 1541.51, p < 0.001; δaic = 2031.43, δbic = 2011.46).
we went on to make analogous comparisons for the covariance structure of the slopes.
rmsea for a general factor model of the slopes (model 4), with no domain-specific group factors, relative to a model with an unstructured slope covariance matrix (model 3), was good (rmsea = 0.041), but the rmsea for a hierarchical factor model of the slopes (model 5) relative to this same unstructured slope covariance matrix was even better (rmsea = 0.035).
χ2, aic, and bic comparisons also indicated that the hierarchical factor model of the slopes (model 5) fit the data better than a model with only a general factor of slopes (model 4; χ2(8) = 58.07, p < 0.001; δaic = 42.07; δbic = 2.12), though the difference in bic, which penalizes more heavily for more complex models, was not as substantial as that for the difference in aic.
thus, we proceeded with the fully hierarchical model (model 5) of both levels and slopes for the analyses below.
for cognitive levels, an average of 40% of the variance in performance on each of the 13 cognitive tests was explained at the general latent trait level, 23% at the domain level, and the remaining 37% at the level of individual tests.
individual tests had high loadings (from 0.57 to 0.98, mean = 0.78) on the latent traits of their respective domains.
all four latent cognitive domains had high loadings on the latent general cognitive level factor (from 0.71 to 0.89, mean = 0.81).
for cognitive slopes from age 70 to 76, an average of 48% of the variance in declines in performance on 13 cognitive tests was explained at the general level, 26% at the domain-specific level, and 26% at the test-specific level (fig.
3).
the general factors of both level and change accounted for substantial proportions of variance: not only are cognitive ability levels in large part explained by a large general factor, almost half of cognitive change variance between age 70 and 76 was shared: that is, much of the change in the thirteen cognitive tests was due to changes in general cognitive function.
3.4 predictors of cognitive level and change we next sought to identify predictors of individual differences in cognitive level and cognitive slope, at the level of, first, the general factors and, second, the cognitive domains.
to begin with, we regressed just the general factors of cognitive level and slope on all of the covariates individually.
this was repeated with all the covariates included simultaneously.
3.4.1 correlates of later-life cognitive ability level next, we addressed the question of what might contribute to differences in cognitive ability level at age 70. the covariates were entered individually alongside the basic factors of age and sex.
all of the covariates except sex, time lag between testing, and apoe e4 status were significantly associated with the general level of cognitive ability (all results are shown in table s4 in supplemental materials).
those lbc1936 participants with better general cognitive function at age 70 were younger when tested, had higher childhood intelligence, were more educated, were from more professional occupational classes, lived in more affluent areas, were fitter (on all three performance indicators), had lower bmi, were less likely to smoke, and were less likely to have cardio-metabolic illness.
the four cognitive domains showed a similar pattern of results, with the additional finding that carriers of the apoe e4 allele also performed less well on the visuospatial and speed domains.
the three illnesses had little association with the verbal memory and crystallized domains levels.
we next ran an intermediate analysis where we entered each covariate alongside age, sex, and age 11 cognitive ability.
this model, wherein older age cognitive level was adjusted for childhood cognitive ability (which correlated r = 0.786, p < 0.001 with later-life general cognitive ability in this intermediate model), effectively tested whether each of the predictors were associated with cognitive change between age 11 and age 70 (at least to the extent to which there was shared variance between the early- and later-life abilities being tested).
many significant predictors of cognitive level in the univariate models were no longer significant (even before correction for multiple comparisons) in this adjusted model, potentially due to their associations with age 11 ability (see supplementary table s5).
the effect sizes of the covariate associations with the general factor of level were attenuated by an average of 61% (with the largest amount of attenuation—90%—being found for cardiovascular disease), implying a great deal of confounding.
the average amounts of attenuation in the domains model ranged from 47% to 64%; supplementary table s6 shows the effect size attenuations for each individual covariate.
despite these effect size attenuations, all of the socioeconomic and physical variables retained significant relations with later-life cognitive ability.
after the inclusion of all the covariates, only age, sex, age 11 iq, education, and forced expiratory volume remained significant correlates of general cognitive ability level (see table 3 and for full results, table s7).
in the domains model, apoe e4 status was significantly negatively associated with speed, and bmi was positively associated with visuospatial ability (this latter effect, which was in an unexpected direction, was modest, β = 0.132).
none of the social or health variables remained significantly associated with cognitive ability level after including all the other variables as covariates and correcting for multiple comparisons.
3.4.2 predictors of later-life cognitive change which variables predict differences in cognitive ageing between age 70 and 76?
first, we entered covariates individually (alongside age and sex).
those who declined less in general cognitive function from 70 to 76 were less likely to carry the apoe e4 allele, and were fitter as assessed using measures of lung function, walking time, and grip strength (see table s4 in supplementary materials for all effect sizes).
there were small associations suggesting that those with higher childhood cognitive ability and more education had steeper declines.
we next examined the ageing slopes of the four cognitive domains.
carriers of the apoe e4 allele declined more steeply in visuospatial ability, speed, and verbal memory.
again, there were associations indicating that physically fitter individuals—especially those with greater grip strength—declined less in cognitive ability, especially in speed.
there was a strong association between better grip strength and maintenance of crystallized ability with age.
we then tested these associations with cognitive change between age 70 and 76 in the fully-adjusted model, where all covariates were added in concert.
importantly, a large number of the significant associations from the previous model did not survive this mutual adjustment for all other variables.
even fewer survived correction for multiple comparisons.
for instance, associations between cognitive change and childhood ses and diabetes were only just below the p < 0.05 threshold for statistical significance and thus did not survive adjustment and fdr correction.
this was also the case for three associations with change in visuospatial ability (fev, walk time, and bmi), four associations with change in verbal memory (baseline age, sex, childhood ses, and grip strength) and one association with change in speed (sex).
results that were significant before fdr correction are indicated in table s7.
the few surviving associations are shown in table 3, with the full results shown in table s7 in supplementary materials.
carrying the apoe e4 allele was associated with more decline in general cognitive ability (effect size d = − 0.499, corrected p = 0.001), as well as speed (d = − 0.440, p = 0.013) and verbal memory (d = − 0.357, p = 0.031).
women tended to decline less in general cognitive ability (d = 0.578, p = 0.022), and this appeared driven by protective associations with crystallized ability (d = 1.162, p = 0.002).
there was also an association of grip strength with decline in general cognitive ability (standardized β = 0.262, p = 0.022)—those with stronger grip declined less, and this was again likely driven by associations with decline in crystallized ability (standardized β = 0.492, p = 0.013)—but not with any of the other cognitive factors.
the model r2 values showed that all the predictors together accounted for 80.5% of the variance in cognitive level, and 16.1% of the variance in general cognitive decline.
3.5 sensitivity analyses we conducted a series of sensitivity analyses to test the robustness of our results for cognitive level and cognitive slope.
first, since it has been suggested that effects of apoe e4 on cognitive decline may be due only to dementia pathology (bunce et al., 2014), we removed individuals with possible dementia in two different ways (using a dementia screening instrument [folstein et al., 1975] and using dementia ascertainment via medical records).
next, we adjusted for low mood at the time of testing—which may result in the appearance of additional cognitive decline—by using the hads, measuring anxiety and depression as a time-varying covariate.
these initial three sensitivity analyses, which are detailed in supplementary materials, made little difference to the results reported above.
in a fourth and final sensitivity analysis, however, we did find an important difference from our main analysis.
here, instead of including all three of the physical fitness variables (lung function, grip strength, and walk speed) separately in the model, we created a unit-weighted composite of the three variables by summing their z-scores.
this resulted in an ‘overall fitness’ variable, which was entered as a covariate after removing the individual fitness variables from the model.
in the model with general factors, we found that higher scores on this variable were associated with both higher level (standardized β = 0.161, p = 0.007) and less decline (β = 0.368, p < 0.001) of cognitive ability; both of the relations survived fdr correction.
in the domains model, the ‘overall fitness’ variable was associated with the level of both visuospatial ability (β = 0.225, p = 0.004) and speed (β = 0.271, p < 0.001), and these survived fdr correction.
there were no significant associations with the level of verbal memory or crystallized ability (absolute βs < 0.08 ps > 0.20).
in terms of slope, there were significant associations between overall fitness and the slopes of speed and crystallized ability (βs = 0.303 and 0.394, respectively; ps < 0.003), but the associations with visuospatial ability and verbal memory, while significant in the uncorrected model, did not survive fdr correction (βs > 0.225).
overall, more relations with physical fitness were found when using an overall fitness variable.
indeed, using this latent variable, the r2 value indicated little change in the variance accounted for in cognitive level (81.0%), but a substantial increase in the variance accounted for in cognitive change: 32.0%.
potential explanations for this finding are discussed below.
4 discussion this study verified the structure of cognitive ageing in the eighth decade of life, and attempted to disentangle the associations with many of its potential predictors.
we found that a substantial proportion (48%) of the variation in cognitive decline across thirteen different tests is shared, and that a well-fitting model can be estimated that groups this slope variance into a hierarchy including variance due to individual tests, cognitive domains, and the general factor of cognitive change (the general factor implies that, to a considerable extent, it "all goes together when it goes"; rabbitt, 1993).
after mutually controlling for all the covariates, there were very few associations between the potential predictors and both domain-general and domain-specific ageing-related cognitive declines.
this was not the case for cognitive levels: a very large proportion of the variance in the levels could be explained by all the predictors in concert.
thus, our results underscore the difficulty in finding predictors of differences in cognitive ageing, even when using variables that are strong correlates of baseline cognitive ability.
we found a great deal of confounding of possible contributors to levels of cognitive abilities at age 70 years by prior cognitive ability at age 11 years.
early life cognitive ability was not related to cognitive change within the eighth decade (tables 2 and s8).
we tested here for possible ‘differential preservation’ (between-person differences in the gradient of the ageing trajectory) of cognitive functions by a large number of covariates and, though we found this to a small degree, there was much more evidence for ‘preserved differentiation’ (pre-existing between-person differences preserved into later life) of cognitive ability between childhood and older age (salthouse et al., 1990, salthouse, 2006).
that is, as shown in some previous analyses of this cohort (deary et al., 2012), brighter children become brighter, healthier, and fitter older adults.
this ‘preserved differentiation’ appeared to last into the eighth decade of life.
the most robust and consistent predictor of cognitive change within old age, even after control for all the other variables, was the presence of the apoe e4 allele.
apoe e4 carriers showed over half a standard deviation more general cognitive decline compared to non-carriers, with particularly pronounced decline in their speed and numerically smaller, but still significant, declines in their verbal memory.
the mechanism by which apoe e4 may have its effects is currently unclear, but the presence of the allele has been linked to neural characteristics including reduced cerebral blood flow (thambisetty, beason-held, an, kraut, & resnick, 2010), hippocampal atrophy (den heijer et al., 2002), and a thinner frontal cortex (fennema-notestine et al., 2011).
our sensitivity analysis indicated that these effects were independent of dementia pathology: that is, the apoe e4 allele appeared to relate to normal, not just pathological, cognitive ageing.
another variable associated with cognitive decline was sex.
the previous literature is unclear as to the existence and direction of sex differences in cognitive decline (barnes et al., 2003, karlamangla et al., 2009); we found that women had significantly less general cognitive decline than men, mainly centered on crystallized ability.
unexpectedly, we found that individuals who were older (within the narrow age range) at the initial testing wave tended to age more healthily in terms of their visuospatial ability across the subsequent six years.
there is no obvious explanation for this result, but given the very narrow age range of the sample, we would caution against drawing strong inferences about this effect.
one potential explanation is sample selectivity; that is, we may have missed unhealthy older individuals as they were less likely to volunteer for the study, meaning that the oldest individuals who were recruited tended to be healthier.
in addition, having a higher age 11 iq was predictive of more decline in visuospatial abilities in the fully-adjusted model.
this may reflect the ‘law of initial value’, whereby those with initially higher abilities decline faster as there is more ‘room’ for them to do so (wilder, 1957).
a similar explanation may apply to the finding that individuals who had undergone more education showed greater decline in their crystallized abilities, though this finding was no longer significant after adjustment for multiple comparisons.
the relation of physical fitness to later-life cognitive change was ambiguous in our analysis.
when entered individually, the three fitness predictors (lung function, grip strength, and walk speed) showed few associations with cognitive change.
however, when an ‘overall fitness’ variable was estimated across all three fitness indicators, larger associations with cognitive decline were found.
this may indicate that broad measures of fitness, reducing the measurement error specific to each individual indicator, are required to detect substantive relations with cognitive function; higher general fitness, and not necessarily scores on specific measures of physical function, may be what is protective against cognitive decline.
physical function measures are among the most potentially modifiable of the covariates we studied.
admittedly, since our results are from observational data, they could not (even if strongly positive) be used to infer that improving physical function, e.g.
via exercise, would have concomitant, causal benefits for cognitive ageing (the ostensibly protective effect may be due to individuals having genes that give them both healthy bodily and cognitive systems in old age, for example).
nevertheless, it is of interest to compare these results to the growing body of evidence—some from randomized controlled trials—suggesting protective effects of exercise and physical activity on cognitive change in later life (lövdén et al., 2013, sofi et al., 2011; though see young, angevaren, rusted, & tabet, 2015).
contrary to some conceptions of ‘cognitive reserve’ (stern, 2002), we found no evidence for a relation between education (or social class) and the slope of any of the cognitive factors.
our results are therefore in line with some previous analyses that suggest education may contribute to the level, but not to the slope, of ageing-related cognitive decline (gottesman et al., 2014, tucker-drob et al., 2009, zahodne et al., 2011).
we did, however, find an association between earlier cognitive ability and cognitive decline, in that those with higher childhood ability tended to decline more in visuospatial ability.
there was no significant effect of earlier cognitive ability on the slopes of all the remaining cognitive measures.
thus, our results were a further test of the previously-asked question regarding whether ‘age is kinder to the initially more able’ (gow et al., 2012).
the answer, from our fully-adjusted model, is ‘no’.
even with a more liberal significance threshold—that is, without controlling our main analysis for multiple comparisons with the fdr correction—there were still very few significant predictors of ageing-related cognitive change (in the general-factors model, there were 4 significant predictors of change before correction and 3 afterwards; in the domain-factors model, the respective numbers were 14 and 5).
without correction, some variables, including fev and childhood ses, appeared relevant for some areas of cognitive ageing.
after correction, they did not relate to any of the slope factors.
overall, however, it is important to note that our interpretation—that it is difficult to observe predictors of cognitive decline—was not contingent on our strategy of fdr correction: after mutual inclusion in the model, there were very few significant predictors to begin with.
one plausible explanation for our failure to discover a sizable number of predictors of cognitive decline is statistical power.
the pattern of our results, where many predictor associations were found with intercept and few with slope, is predicted by simulation studies such as that of hertzog, lindenberger, ghisletta, and von oertzen (2006), which showed that very high reliabilities and large numbers of measurement occasions, in addition to the well-known sample size issues, are required to achieve adequate statistical power in longitudinal studies.
we note that the simulations in that study referred to tests for correlated change, but the same argument applies to the current study.
even though von oertzen, hertzog, lindenberger, and ghisletta (2010) have shown that including multiple indicators of a latent construct increases a study's power—the current study used a thirteen-test cognitive battery to estimate variation in general cognitive change—it may still have been the case that, had our study been larger in sample size, been carried out across a larger number of measurement waves, or had even greater variance in the change measures, we would have been able to detect other, smaller associations with the predictors.
strengths and limitations the lbc1936 is a narrow-age cohort; this removes the troublesome effect of chronological age that hampers making conclusions about what affects within-person cognitive ageing (hofer & sliwinski, 2001).
the participants are generally healthy, as well as ethnically, geographically, and culturally homogeneous, and our study thus avoids the possible confounding effects of acute inter-current illness and population stratification.
our study includes a comprehensive range of cognitive tests and covariates, and uses latent cognitive factors to diminish the influence of measurement error.
the above factors improve the robustness of our results, but nevertheless, there are a number of limitations that may affect their generalizability.
the sample was somewhat restricted in cognitive ability range and social status, and thus some effect sizes might be under-estimates.
the higher social class of our participants means that they were healthier than the general population: it is possible that this explains the lack of any relations of health or lifestyle variables to cognitive change in our sample, though none of these effects were even close to statistically significant in the fully-adjusted model.
none of the participants were acutely ill, so the results do not describe cognitive decrements caused by current illnesses.
the geographical- and age-specific nature of the sample also means that we should be cautious about generalizing to other groups.
repeated measurements over time are what enable longitudinal studies to track within-person changes over time, but they also result in accumulating familiarity both with the testing material and with the more general testing situation that may produce practice (retest) effects.
practice effects may have masked some of the cognitive decline that participants experienced.
such practice effects are likely responsible for the slight, non-significant, increase in logical memory score across age, as the same story was used at each of the waves and the participants may have remembered aspects of it from the previous wave.
indeed, in a study of short-term retests effect, in which actual cognitive changes are guaranteed to be highly trivial, salthouse and tucker-drob (2008) report the largest retest effects of repeated administrations of episodic memory tests, including logical memory.
importantly, although studies that have implemented methods for formally estimating practice effects have found that practice effects are moderate-to-large on average, they indicate that between-person variation in practice effects tends to be minimal (for a review, see tucker-drob & salthouse, 2011).
this suggests that correlates of longitudinal changes in cognitive test performance primarily reflect correlates of ageing-related changes in cognitive abilities, rather than correlates of practice-related learning.
in addition, the present study will have missed cognitive decline that occurred up to age 70; it is possible that declines over this period are associated more strongly with some of the proposed predictors.
finally, we used a fiml algorithm in order to use all of the available data under the ‘missing at random’ assumption (rubin, 1976) that, conditional on the available non-missing data, the pattern of missingness was not systematically related to the unobserved scores on the cognitive tests under study.
our analysis of predictors of dropout indicated that the baseline covariates did not fully account for the patterns of study dropout at subsequent waves (fig.
s1).
with fiml, estimates from growth curve models are not expected to be biased as long as the remaining heterogeneity (not accounted for by these covariates) in dropout was either entirely random, or nonrandom but unrelated to the missing cognitive tests scores post-dropout.
however, if residual heterogeneity in dropout was either due to the cognitive decline that we were not able to observe (due to the dropout) or due to a set of third variables that are themselves associated with cognitive decline post-dropout the estimates reported here may be biased.
study attrition is, of course, a pervasive problem in ageing research.
conclusion the broad answer to why some people's cognitive skills age better than others is still elusive.
outside of acute illness, dementia, the apoe e4 allele, and overall physical fitness, healthy cognitive ageing is likely either to involve factors not studied here, or to be—by analogy with the ‘polygenic’ model of the genetics of complex traits (e.g.
yang et al., 2011)—a multivariate accumulation of small influences.
consistent with this latter possibility, the r2 of all covariates combined was appreciable, even though very few individual predictors were significantly related to the cognitive changes.
to detect specific effects that are individually small, but together combine to account for sizable proportions of variance, future research will likely require longitudinal samples that are many times larger than the one reported here.
@highlight
it is critical to discover why some people's cognitive abilities age better than others'.
we applied multivariate growth curve models to data from a narrow-age cohort measured on a multi-domain iq measure at age 11 years and a comprehensive battery of thirteen measures of visuospatial, memory, crystallized, and processing speed abilities at ages 70, 73, and 76 years (n = 1091 at age 70).
we found that 48% of the variance in change in performance on the thirteen cognitive measures was shared across all measures, an additional 26% was specific to the four ability domains, and 26% was test-specific.
we tested the association of a wide variety of sociodemographic, fitness, health, and genetic variables with each of these cognitive change factors.
models that simultaneously included all covariates accounted for appreciable proportions of variance in the cognitive change factors (e.g.
approximately one third of the variance in general cognitive change).
however, beyond physical fitness and possession of the apoe e4 allele, very few predictors were incrementally associated with cognitive change at statistically significant levels.
the results highlight a small number of factors that predict differences in cognitive ageing, and underscore that correlates of cognitive level are not necessarily predictors of decline.
even larger samples will likely be required to identify additional variables with more modest associations with normal-range heterogeneity in aging-related cognitive declines.
