introduction endodontic success depends primarily on proper instrumentation and shaping.
overlooking this step may lead to failure of endodontic treatment.
[1] glide path (gp) is one of the most important steps, which determines the canal patency from the canal orifice and follows the smooth canal walls uninterrupted to the apex.
[23] the technique of creation of the gp would reduce instrument failure by reducing frictional forces, can have a great impact on the endodontic success.
manufacturers have recommended that performing preflaring and the preparation of gp are must before the introduction of any rotary system in the root canal.
[45] various instruments have been used to create gp like hand stainless steel k-flex files and nickel-titanium (niti) rotary files.
advantages of using stainless steel files for gp are it provides a better tactile sensation and also alerts the clinicians about the canal curvatures present in the canal.
however, the disadvantages of using stainless steel files are it creates canal abnormalities such as elbows and zipping.
to overcome the disadvantages of stainless steel hand files, the niti rotary path files were introduced in 2009 for the purpose of gp.
the previous studies have shown the influence of gp on the canal anatomy;[6] however, till date, no study has been carried out for testing its influence on the surface of the subsequent rotary instrument used.
hence, the purpose of the present study was to evaluate the influence of manual versus mechanical gp on the surface changes of two different niti rotary instruments in root canal therapy in a moderately curved root canal.
rationale the objective of this in vivo study is to evaluate the effect of creating a gp either manually or mechanically on the surface changes of two different niti rotary instruments in a moderately curved root canal by scanning electron microscope.
materials and methods sixty systemically healthy controls aged 18–40 years referred to the department of conservative dentistry and endodontics were selected for the study.
patients were selected on the basis of following inclusion criteria, i.e., patients aged 25–35 years, moderate degree of curvature (20°–30°), and the mesiobuccal root of mandibular first molars indicated for root canal treatment and exclusion criteria being calcified canals, root resorption, retreatment cases, immature root formation.
all the endodontic files were preexamined under scanning electron microscope and those with any defect were not included in the study.
then, these selected samples were allocated randomly into four study groups: group 1 (n = 15): manual gp followed by race rotary instruments (25/0.04)group 2 (n = 15): manual gp followed by hyflex rotary instruments (25/0.04)group 3 (n = 15): mechanical gp followed by race rotary instruments (25/0.04)group 4 (n = 15): mechanical gp followed by hyflex rotary instruments (25/0.04) patients consent was taken before any start of the treatment.
all teeth were anesthetized with 2% lignocaine with 1:100,000 adrenaline followed by rubber dam isolation, and access cavity was prepared with an access opening bur no 3 (dentsply tulsa dental, new york, pa, usa).
a stainless steel k-file no.
10 (mani, japan) was used as patency file.
working length (wl) was then determined with #15 k-file (mani, japan) and the use of an electronic apex locator (rootzxll; j. morita, tokyo, japan).
wl was confirmed with an x-ray using the parallel technique using rinn endo ray ii ring (dentsply tulsa dental, new york, pa, usa).
all the samples having a moderate degree of curvature were selected (20°–30°).
the curvature of the teeth was calculated by schneider's method.
canal preparation was performed according to the manufacturer's recommendations for both the instruments, i.e., the race and hyflex.
in the order of clinical use, before using each set of hyflex and race instruments of the following sizes 25, 0.04 taper, size, manual, and rotary gp were prepared with stainless steel hand files no 15, 20 and rotary path files[7] no 13, 16, 19 (dentsply maillefer, usa), respectively.
rotary files were used in an electric motor (x-smart endo motor, dentsply tulsa dental specialities, usa) with a 16:1 reduction handpiece (dentsply tulsa dental specialities, usa) at a setting and speed recommended by the manufacturer (at 500 rpm).
in groups 1 and 2, a manual gp was created before using rotary files.
in groups 3 and 4, a mechanical gp was created before using rotary path files.
all canals were irrigated with 1 ml of 3% sodium hypochlorite (vensons india, bangalore) using a 27-gauge (unolok; hindustan syringes and medical devices ltd., faridabad, india).
statistical analysis was done using chi-squared test and the statistical software used was r 3.0 (vienna, austria).
scanning electron microscope examination after the preparation of the canal according to the allotted group, the niti rotary instruments (race and hyflex) were cleaned with acetone, and gold sputtering was done before the evaluation of any surface defect in the standard error mean chamber with the help of file holder and observed at ×100 to ×250.
photomicrographs were taken in the middle and apical third of the file and scored according to the following criteria given by eggert et al.
[8] - score 1 - no visible defect, score 2 - pitting, score 3 - fretting, score 4 - microfractures, score 5 - complete fracture, score 6 -metal flash, score 7 - metal strips, score 8 - blunt cutting edges, score 9 - disruption of cutting edge, score 10 - corrosion, score 11 - debris.
results table 1a and b and graph 1 show the presence of surface defects and it was found that there was no significant difference between the groups, however, experimental results showed more number of surface defects in group 2 (hand gp followed by hyflex rotary instruments) and group 4 (mechanical gp followed by hyflex rotary instruments), followed by group 1 (hand gp followed by race rotary instruments) and group 4 (mechanical gp followed by race rotary instruments).
table 1a presence of surface defects in apical third (chi-squared test) table 1b presence of surface defects in middle third (chi-squared test) graph 1 the percentage distribution of surface defects on without use and first use in different groups at middle one-third and apical one-third in table 2a and b, it shows the presence of fretting in apical one-third and middle one-third, respectively, and it was found that the overall fretting defect seen in group 2 (hand gp hyflex) and group 4 (mechanical gp hyflex) was highest (100%) compared to the other groups.
it was also noted that defects such as fretting are present in hyflex rotary system even without the first use [graph 2].
table 2a presence of fretting in apical third (chi-squared test) table 2b presence of fretting in middle third (no statistical test is applied as the number of samples is same in both groups in each usage time) graph 2 the percentage distribution of fretting on without use and first use in different groups at middle one-third and apical one-third in table 3a and b, it shows the presence of pitting in apical one-third and middle one-third, respectively, and it was found that table 3a shows that total pitting defects only observed in group 2 (hand gp hyflex) and group 4 (mechanical gp hyflex) were 7%, on the other hand, table 3b shows that middle third was free from any pitting defect.
however, no statistical significance was seen between the groups [graph 3].
table 3a presence of pitting in apical third (no statistical analysis is carried out due to low sample size) table 3b presence of pitting in middle third graph 3 the percentage distribution of pitting on without use and first use in different groups at middle one-third and apical one-third in table 4a and b, it shows the presence of blunting cutting edges in apical one-third and middle one-third, respectively, and it was found that table 4a shows that apical third had no defects in any group, whereas table 4b shows that blunt cutting edges observed in group 3 (mechanical gp race) and group 4 (mechanical gp hyflex) were 7% in the middle third portion of the instrument, whereas other groups showed no such defects.
however, no significant associations were found between the groups [graph 4].
table 4a presence of blunt cutting in apical third table 4b presence of blunt cutting in middle third graph 4 the percentage distribution of blunt cutting edges on without use and first use in different groups at middle one-third and apical one-third in table 5a and b, it shows the presence of disruption of the cutting edges in apical one-third and middle one-third, respectively, and it was found that disruption of cutting edges was seen in group 2 (hand gp hyflex) and group 4 (mechanical gp hyflex), i.e., 27% and 40%, respectively, on the apical third, and 20% was seen in group 4 on the middle third whereas other groups of instruments, i.e., race rotary instruments, did not show any sign of disruption.
however, no significant association was found between the groups [graph 5].
table 5a presence of disruption of cutting edge in apical third table 5b presence of disruption of cutting edge in middle third graph 5 the percentage disruption of cutting edges on without use and first use in different groups at middle one-third and apical one-third in table 6a and b, it shows the presence of debris in apical one-third and middle one-third, respectively, and it was found that debris was observed in all the groups.
the highest was seen in group 4 (mechanical gp hyflex), i.e., 91.7% which can be due to the presence of the rough surface of hyflex rotary instrument produced during milling and followed by the other groups.
no significant association was observed between the groups and the usage (p > 0.05) with respect to debris [graph 6].
table 6a presence of debris in apical third (chi-squared test) table 6b presence of debris in middle third (chi-squared test) graph 6 the percentage disruption of debris on without use and first use in different groups at middle one-third and apical one-third discussion endodontic success depends primarily on proper instrumentation and shaping.
this is essential because canal preparation determines the efficacy of all subsequent procedures and includes mechanical debridement, creation of space for medicament delivery, and optimized canal geometries for adequate obturation.
[9] curved canals are the most common entity found in the root canal system of the tooth.
[10] to prepare a curved canal, the instruments with a low modulus of elasticity are required thereby maintaining the original canal curvature.
niti alloy was developed by w.f buehler in the late 1960s.
the two most distinctive properties of this alloy are shape memory and superelasticity.
[10] in the present study, two different rotary file systems are being used, i.e., hyflex and race, as the preparation of the curved canals is challenging.
however, the major deferent factor with these niti instruments is that they undergo unexpected fracture without warning.
[11] coronal enlargement and gp have been shown to be fundamental for safer use of niti rotary instrumentation.
according to west, a gp is defined as a smooth radicular tunnel from the canal orifice of the canal to the physiologic terminus of the root canal.
[2] this confirms that there is a pathway for rotary instruments to passively follow in the canal.
the results of the present study showed that all the instruments used in the study showed some or the other signs of defects after a single use.
the most commonly found defect was fretting in group 2. the probable reason of the presence of fretting before use can be due to the mechanical milling of the hyflex file system,[12] whereas in race system, fretting was seen after the first use of about 13% in both groups as preoperatively no fretting was present on the files.
pitting was also the defects seen in groups 2 and 4, i.e., hyflex system.
it was only seen in the apical third of the groups as it undergoes more friction.
none of the groups showed microfracture, complete fracture, metal strip, metal flash, and corrosion.
blunt cutting edges were present in groups 3 and 4, i.e., 7% approx., whereas it was absent in groups 1 and 2. disruption of cutting edge is a loss of the regular continuous shape of the blades.
groups 2 and 4 showed the maximum defects, i.e., 27% and 40%, respectively, as the hyflex instruments are used with more torque, thereby causing more defects whereas it was relatively absent in groups 1 and 3, as these race files having a positive rake angle leading it to cut the dentine at right angles and application of controlled force and speed of the instrument.
debris is dentin chips which are embedded on the instrument.
groups 2 and 4 showed the maximum and least were seen in groups 1 and 3 indicating that as the instruments having a smooth surface, the debris accumulation was less and in case of hyflex instruments as it had preoperative fretting present, the debris accumulation was more.
in the present study, rotary files were viewed under scanning electron microscope at ×100–×400 magnification and files without visible manufacturing defects were selected because manufacturing defects can cause fracture of a new instrument even during the first use [figure 1].
[13] scanning electron microscope was chosen in the present study to evaluate the surface defects accurately, where the conventional methods failed to identify the surface defects of the instruments.
figure 1 postoperative standard error mean picture showing defects conclusion within the limitations of this study, the following conclusions were drawn: there is no effect of manual or mechanical gp on the surface defects of subsequent file system usedsurface defects such as fretting were observed more in hyflex files both preoperatively and after its first useapical third of the files showed more number of the surface defects than the middle third.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
aim: the aim of this study was to evaluate the influence of manual versus mechanical glide path (gp) on the surface changes of two different nickel-titanium rotary instruments used during root canal therapy in a moderately curved root canal.
materials and methods: sixty systemically healthy controls were selected for the study.
controls were divided randomly into four groups: group 1: manual gp followed by race rotary instruments, group 2: manual gp followed by hyflex rotary instruments, group 3: mechanical gp followed by race rotary instruments, group 4: mechanical gp followed by hyflex rotary instruments.
after access opening, gp was prepared and rotary instruments were used according to manufacturer's instructions.
all instruments were evaluated for defects under standard error mean before their use and after a single use.
the scorings for the files were given at apical and middle third.
statistical analysis used: chi-squared test was used.
results: the results showed that there is no statistical difference between any of the groups.
irrespective of the gp and rotary files used, more defects were present in the apical third when compared to middle third of the rotary instrument.
conclusion: within the limitations of this study, it can be concluded that there was no effect of manual or mechanical gp on surface defects of subsequent rotary file system used.
