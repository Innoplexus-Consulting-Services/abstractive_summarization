introduction what was known?
lichen planus pigmentosus usually presents as diffuse grayish hyperpigmented macules over the trunk and flexure aspects of extremities, but reticular, blotchy, and perifollicular forms are also seen.
lichen planus pigmentosus is seen in indian, latin-american, and other dark-skinned populations, presenting as ill-defined, grayish hyperpigmented macules commonly affecting the face and neck.
we report a case of an elderly woman, who presented with generalized reticulate pigmentation and scarring alopecia, in which a diagnosis of poikilodermatous lichen planus pigmentosus was established on the basis of dermoscopic and histological findings.
case report a 70-year-old woman presented with a 25-year history of reticulate pigmentation over the trunk and extremities.
for the past 20 years, she also complained of erythema and burning sensation on exposure to sunlight.
she also developed a loss of hair from the scalp and eyebrows with few itchy violaceous scaly plaques over the trunk and extremities in the past 10 years.
there was no history of muscle weakness, oral ulcers, and joint pain.
on examination, there was brownish reticulate pigmentation in a generalized distribution involving the trunk and extremities, sparing the mid-face.
there were few skip areas on the chest [figure 1a].
she also had scarring alopecia of the frontoparietal scalp and nonscarring alopecia of the eyebrows, axilla, and groin [figure 1b].
in addition, there were multiple, discrete, well-defined, 3–4 cm-sized, violaceous, scaly plaques over the trunk and forearm [figure 1c].
oral cavity, palms, soles, nails, and genitals were found to be normal.
figure 1 (a) generalized brownish reticulate pigmentation involving the trunk and extremities with few skip areas on the chest.
(b) reticulate pigmentation also extending to the scalp associated with scarring alopecia.
(c) multiple, discrete, well-defined, 3–4 cm-sized, violaceous, scaly plaques over the trunk and forearm, resolving with reticulate pigmentation her routine hematological and biochemical investigations were within normal limits.
antinuclear antibodies, anti-double-stranded dna antibodies, muscle enzymes, 24 h urine protein analysis, and computed tomography scan of the chest and abdomen were found to be normal.
her skin biopsy from the reticulate hyperpigmented plaque showed atrophic epidermis and multiple dilated, congested capillaries in the papillary dermis [figure 2a].
biopsy from the alopecic patch over the scalp revealed epidermal atrophy and papillary dermal sclerosis with pigment incontinence.
a skin biopsy from violaceous plaque showed compact hyperkeratosis, parakeratosis, irregular acanthosis, and mild papillary dermal fibrosis.
a band-like lichenoid infiltrate was seen in the upper dermis at one end of the section.
there was basal cell damage in this area with occasional necrotic keratinocytes and dermal melanophages.
there were dilated capillaries in the papillary dermis [figure 2b and c].
direct immunofluorescence test was negative.
dermoscopic evaluation (heine mini 3000, nonpolarized, model no.-d-886.11.021, germany) of the reticulate plaque over the chest showed the presence of dots and globules in a reticular pattern with the presence of atrophy and multiple telangiectasias [figure 2d].
based on the clinical, histological, and dermoscopic findings, a final diagnosis of poikiloderma due to lichen planus pigmentosus was made, and she was administered oral prednisolone (40 mg) which resulted in a significant improvement in pruritus and visible flattening of violaceous plaques within 1 month of the treatment.
prednisolone was gradually tapered after an improvement was seen in itchy plaques, and to some extent in hair growth, however, poikiloderma continued to persist.
figure 2 hematoxylin and eosin stain of the skin biopsy (a, ×200) from the reticulate pigmentation over the back showed epidermal atrophy and multiple, dilated, congested capillaries (b, ×200), (c, ×400) from the violaceous plaque over the back showed basal cell damage, pigment incontinence, and lichenoid infiltrate in the papillary dermis.
(d) dermoscopy (heine mini 3000, nonpolarized, ×10) of the reticulate plaque showed reticulate pigmentation, atrophy, and telangiectasias discussion the most common pattern described for lichen planus pigmentosus is diffuse grayish hyperpigmented macules over the trunk and flexure aspects of extremities, but reticular, blotchy, and perifollicular forms are also seen.
[1] the poikilodermatous form of lichen planus pigmentosus is rarely described.
our patient presented with generalized reticulate pigmentation over the face, trunk, and extremities associated with scarring alopecia of the scalp and nonscarring alopecia of the body hairs.
we considered an initial clinical diagnosis of poikiloderma due to cutaneous t-cell lymphoma, which was ruled out on the basis of histological and dermoscopic findings.
similarly, poikiloderma due to connective tissue disease was thought as a second differential diagnosis, but was not supported by the investigations.
graham little–piccardi–lassueur syndrome was considered due to the presence of scarring alopecia of the scalp and nonscarring alopecia of the body, but follicular keratosis pilaris-like lesions were not seen.
the presence of violaceous itchy plaques over the trunk, lichenoid changes in the histopathology, dermoscopic evaluation of the reticulate plaques showing reticular pigmentation, and atrophy with telangiectasia helped us to confirm our diagnosis.
association of these three presentations of lichen planus is rare where typical lichen planus lesions were seen in addition to the poikilodermatous lesions of lichen planus pigmentosus and cicatricial alopecia.
[2345] our case showed the presence of reticulate pigmentation; atrophy and telangiectasia could be demonstrated with the dermoscopic and histological evaluation.
this finding is similar to the cases reported by sinha et al.
and lin et al., where clinically, reticulate pigmentation was seen in the absence of atrophy and telangiectasia.
[23] involvement of the scalp in the form of diffuse scarring alopecia with this cutaneous presentation is rarely reported.
[3] conclusion thus, poikiloderma is an atypical presentation of lichen planus pigmentosus.
histological and dermoscopic evaluation is essential to arrive at the diagnosis.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
what is new?
poikilodermatous form of lichen planus pigmentosus, associated with typical lichen planus lesions and cicatricial alopecia, is rare.
@highlight
a 70-year-old woman presented with generalized reticulate pigmentation, scarring alopecia, and few discrete, violaceous plaques over the trunk and forearm.
dermoscopic evaluation of the reticulate plaque showed reticulate hyperpigmentation with multiple telangiectasias, and skin biopsy showed lichenoid interface dermatitis with marked pigment incontinence.
thus, a final diagnosis of poikiloderma due to lichen planus pigmentosus was considered.
