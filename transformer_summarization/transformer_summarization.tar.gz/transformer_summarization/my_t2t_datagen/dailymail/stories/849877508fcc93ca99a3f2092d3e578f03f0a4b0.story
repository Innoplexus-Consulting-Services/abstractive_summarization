introduction intertrochanteric fracture is an important cause of mortality and morbidity in elderly individuals.
early mobilization and stable fixation with anatomic reduction are the main goals in the treatment.1 several surgical methods have been used for treating intertrochanteric fractures.
the current widely used treatment methods for intertrochanteric hip fractures include intramedullary nailing or dynamic hip screw.12 external fixation, however, became a valuable alternative method for high risk elderly patients.
since, in the external fixation method, operation time is shorter and blood loss and tissue damage are lessened.12 in 1957, scott used an external fixator for the treatment of intertrochanteric fractures 1st time.
many complications were reported, such as pin loosening, infection, and mechanical failure of the fixator.2 we have lately started to use a new cannulated compression pin that can be adapted to all fixators.
this study investigated the effect of this pin on stability and healing of the fracture.
materials and methods patients with intertrochanteric hip fractures treated by external fixation between january 2009 and july 2014 were retrospectively evaluated.
patients considered having a higher operation risk were included in the study, if they were treated with a proximal femoral nail or sliding hip screw.
since this study aimed to evaluate the effectivity of compression pin, the patients who could not tolerate partial weight bearing after the operation were excluded.
the institutional review board approved this study and an informed consent was obtained from all the patients before treatment.
orthopaedic trauma association fracture classification system (ao/ota) was used and the severity of osteoporosis was graded according to the singh index grading system.
patients were operated at the most optimal time after stabilization of the medical condition.
compression pin is designed for improving stability and it is 9.5 mm in diameter [figure 1].
in the compression pin fixation method, one 9.5 mm cannulated compression pin and one standard pin were used for fixation.
in the standard pin method, three standard pins were used for fixation.
standard pins were either 5 or 6 mm.
short-segment fixation was aimed in both methods by inserting two additional pins to the femoral shaft as proximal as possible.
patients were placed on a translucent table under fluoroscopy control during the operation.
a scrubbed assistant fixed the hip in the proper position as traction table was not available.
in the compression pin group, first a k-wire was placed in the middle-inferior femoral neck at an angle of approximately 130° [figure 2a].
compression pin was placed 5 mm beneath the chondral surface [figure 2b].
then, compression was applied slowly under the control of fluoroscopy [figure 2c].
we avoided injuring the lateral cortex of the proximal femur during the compression process.
then, a 5 or 6 mm self-tapping pin was placed above the compression pin [figures 2d and 3].
in the standard pin method, three self-tapping pins were used for the fixation of the intertrochanteric fracture.
then, in both methods, two 5 mm self-tapping pins were placed on the femoral shaft [figure 4].
patients were evaluated according to age, gender, duration of preoperative period, duration of operation time, american society of anesthesiologists (asa) scores, and immediate postoperative and final femoral neck angle measurements.
the femoral neck angles were measured on plain radiographs.
the accuracy of the plain radiographs and whether the angles were properly positioned were determined for each patient.
the stability of the fixation was evaluated by calculating the secondary varus angulation after weight bearing.
figure 1 compression pin and nut figure 2 schematic diagram of application of compression pin (a) application of a k-wire, (b) placement of the pin with the guidance of k-wire, (c) compression procedure, (d) application of second pin above compression pin and two pins on femoral shaft figure 3 x-ray of hip joint with proximal thigh anteroposterior views left side in a 84 year old patient showing (a) intertrochanteric fracture femur (b) postoperative x-ray after compression pin fixator application (c) after removal of fixator showing union (d and e) clinical photographs of the patient showing range of motion figure 4 x-ray (r) hip joint with thigh anteroposterior views showing (a) intertrochanteric fracture (b) postoperative x-ray after application of compression pin and fixator (c) after removal of fixator showing union (d and e) clinical photographs of the patient showing range of motion patients were seated in bed or at the bedside on the 1st postoperative day for as long as they could tolerate.
after the 2nd day, the patients were encouraged to walk with partial weight bearing using a walking frame, and weight bearing was increased progressively every day.
a proper physiotherapy program was applied to the knee and hip joints.
we defined healing based on clinical findings, particularly painless full-weight bearing and radiographic findings of trabecular bridging and callus formation.
the external fixators were removed in the outpatient clinic at 12–14 weeks.
statistical analysis the spss software, version 21 (armonk, ny: ibm corp. chicago, il, usa) was used.
the shapiro–wilk test was used to determine whether the data were normally distributed.
wilcoxon's signed rank test was used to compare the differences between the immediate and final varus angulations in each group separately.
secondary varus angulations after weight bearing were compared with the mann–whitney u-test (p < 0.05 was considered significant).
results in the compression pin group, 31 patients (16 females and 15 males) were included and the mean age was 82.1 ± 6.1 years (range 75–98 years).
in the standard pin group, 36 patients (17 females and 19 males) were included and the mean age was 83.33 ± 6.24 years (range 75–99 years).
the mean followup period was 18.9 ± 11.4 (9–50) months in the compressive pin group and 17.8 ± 11.7 (range 9–53 months) months for the standard pin group.
all of the fractures were classified as ao/ota 31a1 or 31a2.
all of the fractures were osteoporotic and were classified as grade 3 or lower according to the singh index.
these fractures resulted from low energy trauma.
the asa scores were similar (3 or 4) in each group.
we administered regional anesthesia in 29 of 31 patients and general anesthesia in 2 of 31 patients in the compression pin group.
we administered regional anesthesia in 35 of 36 patients and general anesthesia in 1 of 36 patients in the standard pin group.
the delay in surgical period (from trauma to surgery) was 2.1 (range 1–7 days) days in the compression pin group and 2.8 (range 1–10 days) days in the standard pin group.
the operation time was 24.2 (range 18–31 min) min in the compression pin group and 22.1 (range 17–28 min) min in the standard pin group.
at least one comorbid disease was present in all of the patients [table 1].
table 1 associated of comorbid diseases on the 1st postoperative day, the varus angulation was 3.4 ± 2.8° (range 0–10°) in the compression pin group and 4 ± 2.1° (range 0–8°) in the standard pin group.
the immediate postoperative varus angulations were not significantly different between groups (p = 0.13).
after fracture healing at the end of the 3rd month, the final varus angulation was 4.4 ± 3.1° (range 0–10°) in the compression pin group and 6.5 ± 2.4° (range 0–12°) in the standard pin group (significantly different [p = 0.003]).
from the time of weight bearing to healing, there was 1 ± 1.25° (range 0–4°) of secondary varus angulation in the compression screw pin group and 2.5 ± 1.8° (range 0–9°) of secondary varus angulation in the standard pin group.
the secondary varus angulation was significantly different between groups (p = 0.000).
six of 31 (20%) patients in the compression pin group and 13 of 36 (36%) patients in the standard pin group had >5° of varus angulation, while 3 of 31 (10%) in the compression screw group and 7 of 36 (20%) in the standard pin group had >8° of varus angulation at the final femoral neckangle measurement.
with weight bearing, 2 of 31 (6%) patients in the compression screw group and 9 of 36 (29%) in the standard pin group had >4° of secondary varus angulation.
in the compression pin group, 13 patients had displaced fractures considered unstable, and only 2 (15%) of them had >4° of secondary varus angulation.
in the standard pin group, 19 fractures were considered unstable, and 7 (37%) of them had >4° of secondary varus angulation.
we used 4° as the cutoff point because the greatest secondary varus angulation in the compression pin group was 4°.
pin tract infection was observed in 55% (17/31) of patients in the compression pin group and 58% (21/36) of patients in the standard pin group.
these were minor grade infections seen as increased redness of the skin, serous, or purulent discharge.
pin tract infections were treated with increased local pin site care and sometimes antibiotics no pin loosening occurred in either group.
nonunion or delayed union was not observed.
clinically important rotational deformities or fixation failures were not observed.
patients were mobilized during the 1st week (postoperative days 2–5) in both groups.
fracture healing was defined as trabecular bridging and callus formation as observed on plain radiographs and painless movement of the hip joint and painless full-weight bearing.
the mean fracture healing time was 11.6 ± 1.7 weeks in the compression pin group and 11.9 ± 1.5 weeks in the standard pin group, respectively.
the fracture healing time did not differ between groups (p > 0.05).
all of the fixators were removed during the 12th to 14th postoperative weeks in the outpatient clinic.
refractures were not observed in both groups at least 6 months after the removal of the fixator.
discussion treatment of intertrochanteric fractures can be challenging under some conditions, especially for very elderly, severely osteoporotic patients.
sliding hip screws and intramedullary hip screws fixation are commonly used for the treatment of intertrochanteric fractures, although the reported high rates of fixation failures cannot be ignored.1345 for the treatment selection of the intertrochanteric fracture, age, general condition, comorbid diseases, bone quality, and fracture type should be taken into consideration.6 regularly these fractures are treated with proximal intramedullary nail and sometimes with dynamic hip screw in our clinic.
but in very elderly, high-risk patients who could not tolerate long operation times or significant blood loss; external fixation methods were preferred as an alternative method which reduces surgery stress.
the external fixation method fixes a reduced fracture without preventing biological healing and provides early mobilization.7 it has been reported that compressive pins for the fixation of intertrochanteric hip fractures can increase stability.8 therefore, we prefer to use compression pins for the external fixation of intertrochanteric hip fractures.
in the compression pin group, the duration of operation time was prolonged some 2 min on average.
the immediate postoperative femoral neckangle reduction was similar between the groups, indicating that there was no difference regarding reduction capability between the methods.
however, only two pins were used in the compression pin group, while three pins were used in the standard pin group.
intertrochanteric fracture healing time was reported between 11th and 14th weeks for external fixation method.7 in the present study, all patients in the both groups healed up to the end of 14th week.
moreover, it has been reported that nonunion is not a commonly seen complication.1910 in addition, fracture healing time was not different between both groups.
karn et al.1 reported that patients treated with external fixator displayed more varus deformities than patients who treated with sliding hip screws.
these authors reported >5° of varus angulation in nine of thirty (30%) patients.
we measured >5° of varus deformity in 6 of 31 (20%) patients in the compression pin group and 13 of 36 (36%) in the standard pin group.
vossinakis and badras9 reported that >10° of varus deformity in 12 of 50 patients (25%).
we observed >8° of varus angulation in 3 of 31 patients (10%) in the compression pin group and 7 of 36 (20%) in the standard pin group.
after fracture healing, the secondary angular loss was significantly different between the groups.
this finding demonstrated that our compression pin maintained fixation better than standard pins after weight bearing and the compression pin offered the advantage of fracture compression, which enhanced healing and increased stability.
although the difference in secondary varus angulations between the groups was statistically significant, the 2° mean difference seemed to have little clinical importance.
in contrast, beginning with weight bearing, 2 of 31 (6%) patients in the compression pin group had >4° of secondary varus angulation compared to 9 of 36 patients in the standard pin group (25%).
in the compression pin group, 13 patients had displaced, unstable fractures and only 2 (15%) of them had >4° of secondary varus angulation.
in the standard pin group, there were 19 unstable fractures, and 7 (37%) of them had >4° of secondary varus angulation.
hydroxyapatite-coated pins may be used effectively in the treatment of intertrochanteric fractures.11 compression pin can be coated with hydroxyapatite.
however, tight integration can occur between the bone and pin.
than removing tightly integrated compression pin could be difficult and may require general or regional anesthesia.
normally, we remove the pins in the outpatient clinic.
pin tract infections occur in 30–60% of cases.1912 in the present study, although the pin tract infections were observed at a rate of 55% (17/31) in the compression pin group and 58% (21/36) in the standard pin group all of the infections were minor grade and none of them necessitated pin removal.
because low-speed drills or t-handles were used while placing the pins, osteolysis around the pins was not observed in either group.
the fixators were removed in the outpatient clinic.
after removing the compression pin, one suture was placed under local anesthesia.
the present study had some limitations.
comorbidities in these elderly patients made the postoperative rehabilitation period difficult.
since the goal of this study was to evaluate stability of compression pin after weight bearing and to investigate the effect of compression pin on intertrochanteric fracture healing, only the patients who could tolerate partial weight bearing during the 1st week of postoperative period and who returned for followups were included in this study.
the patients who could not be mobilized or who died during this period were excluded.
patients included in the present study had multiple comorbidities but they were the ones who could be followed at least 6 months after removal of the fixators.
conclusions treatment of very elderly, high-risk patients with external fixation is an effective method.
compression pins maintained stability better than standard pins after weight bearing, particularly in unstable intertrochanteric fractures.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
background: external fixation is a well-known procedure for the management of intertrochanteric fractures in very elderly high-risk patients.
a new compression pin that can be adapted to all fixators was designed to provide inter fragmentary compression.
in the present study, its effects on the fracture stability and healing were evaluated.
materials and methods: thirty-one patients treated using compression pin and thirty-six patients treated using standard pins were evaluated retrospectively between january 2009 and july 2014. patients were evaluated according to age, gender, duration of preoperative period, duration of operation time, american society of anesthesiologists (asa) scores, and immediate postoperative and final femoral neck angle measurements.
the stability of the fixation was evaluated by calculating the secondary varus angulation after weight bearing.
results: thirty one patients (82.1 ± 6.1 years old) comprised the compression pin group, and 36 patients (83.33 ± 6.24 years old) comprised the standard pin group.
from the time of weight bearing to healing time, 1.0 ± 1.25° (0–4) and 2.5 ± 1.8° (0–9) of secondary varus angulation in the compression pin and standard pin groups were measured, respectively (p = 0.000).
with weight bearing, 2 of 31 (6%) and 9 of 36 (25%) patients in the compression and standard pin groups, respectively, had >4° of secondary varus angulation.
in the compression pin group, 13 fractures were unstable, but only 2 (15%) of them had >4° of secondary varus angulation.
in the standard pin group, 19 fractures were unstable, and 7 (37%) of them had >4° of secondary varus angulation.
conclusions: treatment of very elderly, high risk patients’ with intertrochanteric fractures with external fixation is effective.
compression pin maintained stability better than standard pins after weight bearing, especially for unstable intertrochanteric fractures.
