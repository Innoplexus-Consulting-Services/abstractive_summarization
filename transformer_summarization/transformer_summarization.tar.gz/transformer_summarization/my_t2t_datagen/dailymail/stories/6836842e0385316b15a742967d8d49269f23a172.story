introduction over 95% of pancreatic cancers are pancreatic ductal adenocarcinomas (pda).
pancreatic ductal adenocarcinoma is the most lethal cancer, and more than 60% of pda patients die within a few months.
only about 30% patients with pda live up to one year.
pda patients have the best five-year survival if surgery, chemotherapy, and radiation are performed in the first or second pre-metastatic stage of development.
when pda spreads to other organs, as in stage iv, the five-year survival rate is below 2%.
unfortunately, more than 50% of pda patients are diagnosed in stage iv [1].
worldwide pda is the fourth leading cause of cancer-related mortality.
approximately 270,000 new pda cases are diagnosed worldwide, and 260,000 patients die each year.
in 2013 there were more than 45,000 pda cases reported, and almost 38,500 people died from pda in the united states [2, 3].
pancreatic ductal adenocarcinoma is associated with diabetes mellitus type 2 (t2dm), and pda risk is higher in the first year after confirmation of diabetes.
diabetes mellitus type 2 is associated with a two-fold increase in the risk of liver, pancreatic, and endometrial cancers.
in diabetes mellitus type 2, the patient’s cancer risk is increased almost two-fold for breast, colorectal, kidney, and bladder cancer [4].
pancreatic ductal adenocarcinoma and biliary tract cancers (btc), with similar clinical presentation, are diagnosed mostly at incurable stage iii and iv.
in the united kingdom (uk) pancreatic cancer is ninth on the list of leading cancers, amounting to 8000 cases of pda and 2000 cases of btc each year [5].
obesity is a risk factor for pancreatic cancer as well as increased risk for cardiovascular diseases.
obesity is a modifiable risk factor.
almost 34% of the adult population in the usa are obese.
obesity is associated with increased incidence and prevalence of pancreatic cancer [6].
in the usa, obesity concerns mostly women as well as non-hispanic and afro-american populations.
despite being unsolved and poorly understood, some risk factors are mentioned in recent papers, including demographic factors like old age, ethnic origin, and the highest mortality seen in the afro-american population [7].
concerning europe, the incidence of pda between 2005 and 2007 was highest in men from the baltic countries, followed by the czech republic, hungary, slovakia, and slovenia.
northern european countries like finland and denmark also had higher incidence rates in comparison to the average incidence in europe.
the lowest mortality rates in the world (caused by pda/btc) were noted in latin america.
the pda/btc mortality rates in women were the highest in some central/eastern and northern european countries, and the lowest were in latin america [8].
in 2007 norwegian pda/btc mortality was higher in women than in men (8), and the incidence of pancreatic cancer over the last two decades has levelled off [9].
familial cancer conditions cannot be ruled out as a possible risk factor of pad/btc.
genetic predisposition has been found for liver cancer, as well as for pancreatic cancer [10].
the main problem with pda/btc is diagnosis being made too late, because most patients visit their doctors at advanced stages (iii, iv) of pda/btc.
however, even for those who are in the first two stages with the possibility of surgery, prognosis is also poor [9, 11].
in 2012, there were 211,500 cases of pda/btc worldwide, and despite progress in its pathophysiology, morbidity and mortality due to pda/btc have not changed much in recent years [12].
in japan, where mortality and morbidity due to pda/btc is the lowest in the world, the incidence of pda/btc has increased in the past four decades and is the fifth leading cause of death in men and the sixth in women [13].
smoking is the most considering and well-documented risk factor for pancreatic cancer, being responsible for about 25% cases of pda/btc, commonly in western countries, and is still rising in developing countries [14].
cancer mortality in europe is highest in russia, romania, and in eastern europe, due to their greatest consumption of tobacco.
in others parts of western europe with improved smoking cessation processes, mortality and morbidity due to pancreatic cancer are less common than in eastern europe [15].
in many countries, mostly in the western hemisphere, the populations are living longer than ever, with the longest recorded life span in japan, creating concerns of rising incidence of many kinds of cancer, including pda.
aging correlates well with the incidence of pda/btc, and it is the most recognised risk factor; pda/btc is most often diagnosed between 60 and 80 years of age.
pda/btc is rare below age 45 years.
during the almost 40 years since the second world war, the incidence of pc tripled [16, 17].
in poland, after cardio-vascular diseases, cancers are the second overall cause of death, with the highest mortality before the age of 65 years.
in poland, in 2010, most cancer-related deaths were caused by the following cancers: lung, colon, stomach, breast, pancreas.
as smoking is one of the main cancer risk factors, and more than 30% of the polish population smokes cigarettes, it will be difficult to diminish the incidence rate of cancer in poland [14, 18].
risk factors although pda accounts 95% of all pancreatic cancers, screening of the general population for pda is still not validated [19].
that is why risk factors for pda are an important issue.
it appears, from descriptive and retrospective studies, that tobacco smoking and aging are seriously involved in the development of pancreatic cancer [1, 2, 6, 7, 14, 18, 19].
it was reported that smoking is responsible for nearly 25% of pda, and that carbon monoxide, benzene, vinyl chloride, and many other compounds play a destructive role not only in the development, but also in the progression of pda.
it was proven that tobacco smoking renders cancer cells more metastatic; nicotine stimulates tumour growth and invasion, which causes cancer cells to be more metastatic and resistant to drugs.
patients who smoke decrease their own survival rate because tobacco directly and negatively interferes with chemotherapy.
the protective role against cancers played by oestrogens, helping cells to survive hypoxia, caused by side effects of a smoking habit [20].
demographic factors, as progress in age, mostly at old age, are not modifiable.
ethnicity indicates that the afro-american population is more vulnerable to pda than white populations.
african american and ashkenazic jewish races have more significant risk of pda than the general white population [2, 7].
occupational exposures for chlorinated hydrocarbons and aliphatic solvents, nickel and chromium compounds, polycyclic aromatic hydrocarbons, and organochlorine insecticides are implicated in the development of pancreatic cancer [2], despite some studies that deny occupation as a major risk factor [14].
it was reported that the risk of pancreatic cancer was associated with genetic predisposition; however, genetics account for only a small proportion of pdas [19].
mutation of genes in people with a predisposition to genetic mutations significantly increases the risk of pda, causing hereditary pancreatitis (hp) [3, 14].
other inherited genetic disorders that are thought to create pda cover include [10]: peutz-jeghers, ataxia-telangiectasia, familial atypical multiple mole melanoma, nonpolyposis colorectal cancer, hereditary breast and ovarian cancer, which cause about 10% of all pancreatic cancers [14].
people suffering from genetic predisposition to mutations like familial pancreatic cancer (fpc) with unknown gene but strong relative risk or hereditary pancreatitis (prs51 gene) have a five- to ten-fold increased risk of pda [3].
one of the most convincing risk factors of pancreatic cancer is weight, particularly obesity.
it was reported that: body fatness increases pda risk from 20 to 50% as compared to people with normal bmi; obese people are often diagnosed with pda one year earlier than the average population; individuals with abdominal fatness are more susceptible to pda than individuals with fatness of other body parts; obesity increases the risk of mortality not only from pancreatic cancer but also from some other cancers; higher bmi causes more frequent inflammation and hormonal disruption than normal bmi, creating greater chances for carcinogens, because the rise of bmi is also due to reduced physical activity, which is another risk factor for cancer; obesity, associated with insulin resistance, increases insulin concentration in tissues and blood, which can increase tumour growth promotion.
some authors suggest that the increase in adipokines, leptin, and adiponectin in visceral adipose tissue can increase risk of pancreatic cancer.
in europe and economically developed countries of the world, people consume about 2600 calories per day, excluding japan, where caloric consumption is lower (not exceeding 1800 calories per day).
that is why our weight is one of the most important factors of our health.
if we are becoming overweight earlier in life, we have a greater risk of consuming carcinogenic substances, energy imbalance, and inflammation [1, 3, 4, 6, 8, 15, 18].
type 2 diabetes mellitus (t2dm) increases the risk of liver, pancreatic, and endometrial cancers by a factor of approximately two, and the risk of breast, colorectal, kidney, and bladder cancer by a factor of less than two.
evidence suggests that overweight/obesity with consequent insulin resistance and hyperinsulinaemia is the main risk of pancreatic cancer.
the risk of pda was higher in the first year after t2dm diagnosis and also higher in the subsequent years of observation in patients with diabetes mellitus, when compare to non-diabetics.
many studies suggest that pancreatic cancer can initiate and promote t2dm, and diabetes mellitus does not cause pda.
there were also suggestions of a higher incidence rate of pancreatic cancer during the first year of t2dm diagnosis.
a positive correlation has been found between glucose-lowering drugs and pancreatic cancer.
it is commonly believed that unfavourable dietary habits such as saturated fat, alcohol consumption, and high salt intake can lead to diabetes mellitus [4, 5, 8, 10, 13, 15, 16].
a two-fold increased risk of pancreatic cancer is seen among patients with diabetic type ii, but not with type i diabetes [14].
alcohol consumption is also a risk factor of pancreatic cancer.
heavy drinkers are more prone to pda.
a three-fold increase in gene mutations was reported in alcohol drinking and smoking persons, in comparison to persons with moderate consumption of alcohol and non-smokers.
however, some studies have failed to prove a relation between alcohol consumption and pancreatic cancer, except a relation of chronic drinking with chronic alcoholic pancreatitis.
all alcoholic beverages are cancerogenic when consumed in excess and it is advised that people should drink alcoholic beverages in a moderate pattern.
small portions of alcohol (one drink per day) seem unlikely to pose a risk of pda and remain inconclusive as a risk measure.
it was reported that people who drink six or more alcoholic drinks per day for many years have a higher risk of pda than people drinking in moderation.
increased risk of pda concerns mostly persons with a previous history of chronic pancreatitis [3, 7, 10, 13, 14, 16–18].
some other risk factors that can play a distinct role in the creation of pda are frequently described in the literature but are still not sufficiently proven in medical research.
as long as our data are not conclusive in aetiology and there is a lack of early screening of pancreatic cancer, it is very important to highlight the role of lifestyle factors and education in the prevention of pda.
the risk of pda decreases by more than 50% among higher educated people [6, 13].
physical activity is a statistically significant protective factor for pda, decreasing the risk of pancreatic cancer by 12–37%.
to diminish the risk of pda, leisure-time activities are more important than occupational activities.
however, many epidemiological studies concerning the relationship between physical activity and pda are not consistent.
some authors hypothesise that physical activity reduces glucose levels and unhealthy triglycerols, and prevent type 2 diabetes mellitus, which can reduce pda thereafter.
it was proven that physical exercise protects against being overweight and obese, and can reduce insulin resistance [1, 6, 10, 13].
summarised risk factors of pancreatic cancer in recent decades, a great deal of medical scientific literature has been aimed at establishing a better understanding the aetiology of pda, to reduce the incidence of pancreatic cancer, and to provide screening programmes for persons with relative risk.
it is still not well defined who should be under early surveillance [3].
as in western countries, pancreatic cancer is the fourth leading cause of mortality, which shows an increasing trend in morbidity and mortality, some individuals with leading risk factors are invited to participate in screening programs.
the most convincing or probable risk factors that should be included in pda screening programs are [2, 3, 10]: chronic pancreatitis, familial atypical mole-multiple, intraductal papillary mucinous neoplasm (ipmn), mucinous cystic neoplasia (mcn), pancreatic cystic neoplasm (pcn), chronic pancreatitis, hereditary conditions – peutz-jeghers syndrom, hereditary pancreatitis, body fatness, high bmi, greater than average childhood growth, any individuals with a five-fold or more relative risk.
the literature points to many others suggestive, non-conclusive, or potential risk factors predisposing to pda and mostly focused on lifestyle factors like: smoking, lack of physical activity, and poor diet.
several studies show that high bioavailability of statins significantly reduces the risk of pancreatic cancer.
the use of statins for more than one year was associated with a 34% reduction in the risk of pda, and use of statins for more than 10 years caused an almost 50% reduction in pda risk [2].
there is also a growing demand for prophylaxis of pda by using pre-emptive pancreatic surgery with a minimally invasive approach.
however, total pancreatic surgery is sometimes necessary due to the protective action against malignant transformation and resection of a precancerous lesion [3].
intraductal papillary mucinous neoplasm and mucinous cystic neoplasia are the most prone to becoming malignant, and preventive surgery is strongly recommended in such cases.
rarely, lesions of the pancreas may be diagnosed as pda by prophylactic measures (ultrasound, magnetic resonance imaging, computerised tomography).
then the pancreas should be removed before spreading to nearby organs, causing pda recovery.
individuals at high or even modest risk of pancreatic cancer with hereditary conditions and other predisposition for pda should be under surveillance or screening [3, 5, 19].
pancreatic cancers are usually diagnosed in their advanced stages, disseminated to adjacent and distant organs, when surgical treatment is not recommended.
symptoms of pda include [17]: abdominal pain, jaundice, change in bowel habit, back pain, dyspepsia/reflux, nausea and vomiting, weight loss, lethargy.
any of the above symptoms can bring people to medical facilities due to the probability of diagnosis of pda.
the first pda symptoms include abdominal pain and/or back pain, later pda patients report jaundice, when the pancreatic-head tumour is small.
diabetes mellitus is associated with other signs mentioned above.
in pancreatic-tail tumours, pain is limited to the left side of the abdomen.
unfortunately, the pain is usually too late as a warning symptom because it appears when the cancer is spreading to nearby tissues.
it is also often seen that very early signs and symptoms of pda occur for a short period of time and stop thereafter, reassuring patients that nothing wrong is happening.
when pda symptoms become severe and chronic, patients visit family doctors.
unfortunately, the above listed symptoms are mostly reported after diagnosis of pancreatic cancer.
therefore, new guidelines are needed to start investigation of at-risk subjects [5, 7].
screening for early pancreatic ductal adenocarcinoma detection screening for pda males and females over 50 years old, with higher risk factors, substantially benefits predisposed individuals.
although only 56 cancers in men and 58 in women per 100,000 screened persons are diagnosed, it results in 38 cancer deaths averted [19].
computerised tomography (ct) of abdomen is the first diagnostic procedure followed by endoscopic retrograde cholangiopancreatography.
magnetic resonance imaging (mri) and use of endoscopic ultrasound device are very accurate in subgroups enrolled for screening.
if pancreatic cancer is found, further diagnostic procedures should be taken, including fine-needle aspiration (fna) to obtain a tissue for diagnosis and management, or endoscopic ultrasound-guided biopsy to confirm neoplasm histologically.
ct is not always recommended for diagnosis of pda due to radiation exposure, but the use of endoscopic ultrasound (eus) is increasing [3, 7, 9].
screening individuals with a relative risk of pc can give greater life expectancy than in the general population.
some individuals with little risk should not be screened due to false-positive results and subsequent unnecessary surgery, complications, and deaths from surgical interventions [19].
primary pancreatic ductal adenocarcinoma prevention surgical resection, radiotherapy, and chemotherapy remain the best options for patients with pancreatic cancer to improve outcome [9].
due to an asymptomatic or insufficiently symptomatic process, pda disseminates and progresses early to force patients to visit family doctors [17].
so, do we have any strategy to protect the population against pc?
for some experts, primary prevention of the pc is not available [3].
for others, modifiable risk factors are crucial enough to establish prophylactic programs in the general population.
in our opinion, effective primary prevention of pda should be started with tobacco cessation because cigarette smoking is one of the modifiable pc risk factors [12].
cigarette smoking accounts for 25–29% of pancreatic cancer incidence [14].
five years after cigarette smoking withdrawal, the risk for pc is the same as in the general population [1, 3, 7, 8, 10].
nicotine can stimulate pc tumour growth, making cancer more metastatic and less responsive to therapy, and reducing the survival rate of pda patients [2].
it was reported that cigarette smoking increases the risk of pancreatic cancer by a factor of two [14].
cancer mortality in recent decades has generally declined in western europe, including pda, mostly due to cessation of cigarette smoking, but has remained constant in eastern europe.
countries like russia, romania, and poland have high rates of tobacco consumption and incidence of pda, which has not declined yet [15, 18].
unfortunately, tobacco consumption is on the rise in central and eastern europe [8].
we also have suggestive and modifiable risk factors of pancreatic cancer other than smoking.
however, more studies are needed, particularly randomised studies, to establish “links” between lifestyle factors and pda.
many of the risk factors other than smoking are reversible, without side effects, for example: maintaining proper bmi, drinking alcohol in a moderate manner, or to improving physical activities.
many authors consider how to correct unhealthy human habits to improve quality of life, extending life expectancy, and avoiding pancreatic cancer.
modifiable pda risk factors [1, 6–8, 10, 13, 14, 16–18] include: smoking, obesity/body fatness, adiposity, high bmi, poor diet as: red meat, processed food, saturated fatty acids, high cholesterol diet, fructose, heavy alcohol drinking /alcohol abuse, small consumption of vegetables and fruits, more than four cups of coffee a day, low-fibre diet, high consumption of sodium salts, smoked meat, food preservatives and additives, type 2 diabetes, hyperglycaemia, lack of systematic physical activity, lack of secondary and/or tertiary education.
eating plenty of healthy grains, vegetables, and fish, as well as limiting red meat and sweets, has been shown to lower the risk of pda among people with higher risk of pda.
tomatoes, broccoli, spinach, and blueberries are considered to have a prophylactic effect on cancers.
a growing body of research suggests that people who eat more protein from animal sources have four times increased risk of dying from cancer, as compared to people who consume proteins from fish, fowl, and plant sources like whole grains or nuts.
we should focus on monounsaturated fats which control insulin level and blood glucose and can be helpful to people suffering from type 2 diabetes.
deep ocean fish, including salmon, mackerel, sardine, and tuna are major sources of long-chain omega-3 fatty acids, which help to maintain anti-inflammatory processes and have been shown to have some anticancer properties.
chemicals known as heterocyclic amines, nitrates, and heme iron, found in foods, are capable of damaging cells and dna, influencing cancerogenic processes, and triggering cancers of the pancreas, prostate, and colon [7, 10, 13, 16, 20].
a healthy diet, when food intake does not exceed 2000 calories daily, and regular physical activity, account for 2/3 of our lifespan.
the five-year survival rate of all cancers taken together has increased in the past three decades due to massive screening programs, sophisticated treatment, and common preventive practice.
if we are able to stop people smoking, we can reduce by more than 80% the incidence of lung cancer and diminish substantially the incidence of pancreatic cancer [7, 8, 18, 20].
aging is considered as a non-modifiable risk factor, characterised by a high incidence of pancreatic cancer in the elderly.
however, it was reported that healthy lifestyle, including regular physical activity and healthy diet, can help to avoid diabetes type 2 and obesity, and can slow aging processes and increase longevity.
several studies have shown that the reduction in diabetes type 2 incidence after changing lifestyle habits is related to the decrease of incidence of pda [1, 6, 8, 10].
eating charred, processed foods, drinking alcohol in excess, and accumulating excessive amounts of carcinogenic substances in our body are more important predictors of carcinogenesis than the process of aging.
our physiological/biological age can differ from our calendar age, giving a possibility to live longer without debilitating diseases.
conclusions in the world, pancreatic cancer is a rare but fatal disease, with few established risk factors, including: smoking, genetic predisposition, and increasing age [3, 6, 10].
recent literature has found modern advances in pda treatment and prophylaxis.
as long as pancreatic cancers are mostly diagnosed too late, the most important task for every individual on the planet is to take a healthy approach and to stave off death in the short term [2, 6, 7].
lifestyle changes could play a crucial role in reducing the incidence of pancreatic cancer, without negative adverse effects [20].
lifestyle changes may also allow us to stay healthier throughout our life with better wellbeing.
lifestyle changes need broader knowledge and creative support from healthcare workers and society.
it does not create additional individual cost to be in good shape, slim, physically active, without smoking, with moderate alcohol consumption, with reduced amounts of products preserved with sodium, and lowered consumption of red meat/processed meat, and eating more vegetables and fruit or being vaccinated to protect against diseases that potentially influence carcinogenesis.
@highlight
pancreatic ductal adenocarcinoma (pda) accounts for 95% of all pancreatic cancers.
about 230,000 pda cases are diagnosed worldwide each year.
pda has the lowest five-year survival rate as compared to others cancers.
pda in poland is the fifth leading cause of death after lung, stomach, colon and breast cancer.
in our paper we have analysed the newest epidemiological research, some of it controversial, to establish the best practical solution for pancreatic cancer prevention in the healthy population as well as treatment for patients already diagnosed with pancreatic cancer.
we found that pda occurs quite frequently but is usually diagnosed too late, at its advanced stage.
screening for pda is not very well defined except in subgroups of high-risk individuals with genetic disorders or with chronic pancreatitis.
we present convincing, probable, and suggestive risk factors associated with pancreatic cancer, many of which are modifiable and should be introduced and implemented in our society.
