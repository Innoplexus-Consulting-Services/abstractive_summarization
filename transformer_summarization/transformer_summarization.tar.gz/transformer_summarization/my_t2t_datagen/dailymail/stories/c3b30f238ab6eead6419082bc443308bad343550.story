1. introduction hyperuricemia is a condition with an abnormally high concentration of uric acid in the blood.
it can be caused by regular intake of purine-rich food and invariably accompanied by gout, chronic kidney disease, and/or other metabolic syndrome [1].
xanthine oxidase (xo) catalyzes the oxidation of hypoxanthine and xanthine to uric acid.
it can generate reactive oxygen species (ros) [2].
uric acid, the final oxidation product of purine metabolism, is eliminated mainly via urinary excretion from the kidney.
xo-mediated overproduction of uric acid can lead to hyperuricemia, a major cause of gout.
hyperuricemia is associated with increased risk of cardiovascular disorder, nephrolithiasis, and diabetes [3].
gout is a metabolic disorder characterized by marked hyperuricemia with the deposition of urate monohydrate crystals in joints and kidneys, resulting in gouty arthritis and uric acid nephrolithiasis [4].
it has been reported that one million people in the united states and 0.3 million people in south korea suffer from gouty arthritis [5].
moreover, xo-mediated excessive production of ros can increase the level of oxidative stress, resulting in several pathological processes such as inflammation, atherosclerosis, cancer, and aging [6, 7].
thus, monitoring the level of xo is often an important part in the prevention and treatment for hyperuricemia and other diseases caused by oxidative stress.
one of the therapeutic approaches to treat and prevent hyperuricemia is to use xo inhibitors that can block the final step of xo reaction to synthesize uric acid, thus reducing the levels of uric acid.
allopurinol is the only xo inhibitor approved for clinical use.
however, it can cause several side effects such as hypersensitivity reactions, nephropathy, fetal liver necrosis, and enhancement of 6-mercaptopurine toxicity [8, 9].
therefore, it is important and necessary to search for safe herbal preparations and phytochemicals that are effective for hyperuricemia and gout [10, 11].
in the “dongui bogam” which is regarded as one of the most important classics of oriental medicine today, three plants (i.e., carthamus tinctorius, prunus persica, and angelica gigas) were reported to be effective for the prevention and anesis of gout (dongui bogam: japbyeongpyeon, hanbulhakyesa, seoul, republic of korea, 2016).
therefore, we preliminarily screened in vitro xanthine oxidase (xo) inhibitory activity of extracts from 229 dietary and/or medicinal plants including the three plants mentioned above.
however, unfortunately, the xo inhibitory activity of the three plant extracts was not so high, while, unexpectedly, an extract from the leaf of quercus acuta thunb.
(fagaceae) (qa) showed profoundly higher activity compared to the other plant extracts (data not shown).
based on these preliminary results, we designed the present study on qa, which could contribute to developing a novel complementary and alternative medicine for treating hyperuricemia or gout.
qa is cultivated as a dietary and ornamental plant in china, japan, south korea, and taiwan [12].
the fruit of qa (acorn) has been widely used as the main ingredient of acorn tofu, a traditional food in china and south korea [13].
to date, only one research paper has been found in the literature with two compounds identified from the trunk of qa.
the two compounds have been reported to possess antimicrobial properties [12].
however, to the best of our knowledge, there have been no published reports on the active constituents and biological activity of extract of qa leaf (qale).
therefore, the objective of this study was to determine antioxidant, xo inhibitory activity, and antihyperuricemic activities of the qale and identify its major active phytochemicals.
gas chromatography-mass spectrometry (gc-ms) and liquid chromatography analyses were performed for chemical profiling.
in vitro dpph free radical assay was used to determine antioxidant activity.
xo inhibitory and antihyperuricemic activities were assessed in potassium oxonate-induced hyperuricemic mice.
2. materials and methods 2.1. plant materials qa leaves were collected from the wando arboretum (wando, republic of korea) and identified by dr. deuk-sil oh affiliated to the wando arboretum.
a voucher specimen (mnucss-qa-01) was deposited at mokpo national university (muan, republic of korea).
air-dried and powdered qa leaves (10 g) were extracted twice with ethyl acetate (100 ml) at room temperature for 3 days.
the resultant ethyl acetate solution was evaporated, dried, and stored at −50°c.
it was used for further in vitro and in vivo experiments.
2.2. animals male icr mice (4-weeks old) were purchased from orient bio, co. (seongnam, republic of korea).
they were retained in a clean room at a temperature of 20–23°c with 12 h light (07:00–19:00) and dark (19:00–07:00) cycles at relative humidity of 50 ± 5%.
mice were housed in ventilated mice cages (tecniplast usa, inc.) with filtered and pathogen-free air.
food (agribrands purina korea, inc.) and water were provided ad libitum.
all animal experiments were carried out in accordance with the guidelines of the animal investigation committee of jeonnam bioindustry foundation (naju, republic of korea) with approval number of jinr1517.
2.3. chemical profiling by gc-ms analysis gc-ms analysis was conducted using a previously reported method with slight modifications [14].
briefly, agilent 7890 gas chromatograph system was used to analyze scanned organic compound.
it was coupled to a quadrupole agilent 5975c electron ionization (70 ev) mass spectrometric detector (agilent technologies, palo alto, ca, usa) equipped with a agilent hp-5ms fused silica capillary column (30 mm l. × 0.25 mm i.d., 0.25-μm film thickness).
gc-ms was tuned using perfluorotributylamine (pftba) with mass fragments of 69.0, 219.0, and 502.0 m/z under electron ionization (ei) conditions.
gc oven was heated using the following program: isothermal at 65°c for 10 min and 10 min−1 to 300 with helium (he) as carrier gas.
transfer line was heated at 300°c.
the mass spectrometer was operated in scan mode of 50–550 amu.
all mass spectra were compared to the data system library (nist 2008).
the operation parameters for the gc were shown in table 1.
2.4. constituents profiling by lc analysis constituent profiling of qale was performed with hplc.
previously, we purified and identified the three minor constituents, namely, quercetin, luteolin, and apigenin using column chromatography and preparative thin layer chromatography.
all hplc analyses were performed using alliance 2695 hplc system (waters, millford, ma, usa) equipped with a photodiode array detector.
agilent zorbax extended c18 (5 μm, 150 mm l. × 5 mm i.d.)
analytical column was used with a mobile phase consisting of solvent a (acetonitrile) and solvent b (water containing 0.2% phosphoric acid).
gradient elution (from 10/90 to 100/0, v/v) was performed at flow rate of 1.0 ml/min (table 1).
column temperature was maintained at 25°c.
the detection wavelength was set at 270 nm for quercetin, luteolin, and apigenin.
solvent was filtered through 0.22 μm filter and degassed.
the sample injection volume was 10 μl.
2.5. dpph free radical assay antioxidant activity of qale was determined using 2,2-diphenyl-1-picrylhydrazyl (dpph) radical scavenging assay.
dpph radicals with the maximum absorbance at 517 nm will disappear when they are reduced by antioxidant compound.
qale solution (1 ml) containing 1 to 20 mg of qale was added to 0.4 mm dpph qale solution (1 ml) and mixed.
the mixture was allowed to react at room temperature in the dark for 10 min.
absorbance value at 517 nm was measured using a microplate reader (perkin elmer, waltham, ma, usa).
the radical scavenging activity was calculated as a percentage using the following equation:(1)dpph  radical  scavenging  activity  %  =  1−asampleablank×100.the dpph free radical scavenging activities of samples were compared in terms of their ic50 (μg/ml) values [15].
the reducing power of qale was determined using a modified reducing power assay method.
the sample (0.1 ml) was added to 0.2 m sodium phosphate buffer (0.5 ml) and 1% potassium ferricyanide (0.5 ml) followed by incubation at 50°c for 20 min.
after the incubation, 10% trichloroacetic acid solution (0.5 ml) was added to the reaction mixture followed by centrifugation at 12000 rpm for 10 min.
the supernatant was mixed with distilled water (0.5 ml) and 0.1% iron (iii) chloride solution (0.1 ml).
absorbance value of the resulting solution was measured at 700 nm.
reducing powers of samples were expressed as vitamin c equivalents [15].
2.6. determination of total phenolic content the total phenolic content was determined using folin-ciocalteu assay [15].
water solution (1 ml) containing 5 mg of qale or standard was mixed with 1 ml of 2% sodium carbonate solution and 1 ml of 10% folin-ciocalteu's phenol reagent.
after incubating the mixture at room temperature for 10 min, its absorbance was measured at 750 nm using a microplate reader (perkin elmer) and compared to the calibration curve of gallic acid.
results were expressed as milligrams of gallic acid equivalents per gram of sample [15].
2.7. determination of total flavonoids total flavonoid content was determined with previously reported colorimetric method [15].
briefly, 0.5 ml of sample solution was mixed with distilled water (2 ml) and 5% nano2 solution (0.15 ml).
after incubation for 5 min, 0.15 ml of 10% alcl3 solution was added to the mixture.
after incubation at room temperature for 5 min, 4% naoh solution (2 ml) was added to the mixture.
after bringing the final volume to 5 ml with water, the mixture was thoroughly mixed and allowed to stand at room temperature for 15 min.
the absorbance value of the resultant mixture was measured at 415 nm.
total flavonoid content was expressed as amount (mg) of flavonoid (quercetin) per amount of extract (g).
2.8. determination of in vitro xanthine oxidase (xo) inhibitory activity xo inhibitory activity was measured by monitoring uric acid formation in xanthine oxidase system as described previously [16].
the assay system consisted of 0.6 ml phosphate buffer (100 mm; ph 7.4), 0.1 ml sample, 0.1 ml xo (0.2 u/ml), and 0.2 ml xanthine (1 mm; dissolved in 0.1 n naoh).
the reaction was initiated by adding the enzyme with or without inhibitors.
changes in absorbance of the mixture at 290 nm for 15 min compared to the absorbance of reagent blank were determined.
a 0.2 ml aliquot of 1 n hcl was used to stop the enzymatic reaction.
allopurinol was used as positive control.
2.9. pretreatment and hyperuricemia induction in mice the qale or alp was dissolved in 0.3% cmc-na aqueous solution.
five groups of mice (n = 5 for each group) were pretreated once daily for 7 days as follows: mice in two negative control groups (nor and hu groups) received 0.3% cmc-na aqueous solution; mice in the positive control group (alp group) received alp solution at a dose of 10 mg/kg; mice in qa50 and qa250 groups received the qale solution at doses of 50 and 250 mg/kg, respectively.
hyperuricemia was induced in mice by potassium oxonate, a uricase inhibitor as described previously [17].
potassium oxonate (dissolved in pbs; 250 mg/kg) was administered to all mice except those in the nor group intraperitoneally, 1 h before the last pretreatment on the 7th day (mice in the nor group received pbs instead of potassium oxonate).
finally, 1 h after the last pretreatment on the 7th day, approximately 0.5 ml blood samples were collected via the tail vein, allowed to clot for 1 h at 4°c, and centrifuged at 10000g for 15 min to obtain serum.
the resultant serum samples were stored at −80°c until further analysis.
2.10. determination of in vivo uric acid concentration and xo activity serum uric acid concentration was measured using standard diagnostic kits (abcam; cambridge, uk).
each assay was performed in triplicate.
the residual activity of xo in mouse liver and serum were spectrophotometrically determined by monitoring uric acid formation from xanthine [18].
mice livers (0.5 g) were homogenized in 1 ml of 50 mm sodium phosphate buffer (ph 7.4).
the homogenates were centrifuged at 3000g for 10 min at 4°c.
after removing lipid layer, supernatant was centrifuged at 10000g for 60 min at 4°c.
the resultant supernatant was used to determine xo residual activity and total protein concentration.
a 0.12 ml aliquot of xanthine solution (250 mm) was added to a test tube containing 10 μl liver homogenate and 0.54 ml potassium oxonate solution (1 mm) in 50-mm sodium phosphate buffer (ph 7.4) that was previously incubated at 35°c for 15 min.
the reaction was stopped after 0 and 30 min of reaction by adding 0.1 ml of 0.6 m hcl.
thereafter, the test tube was centrifuged at 3000g for 5 min.
the absorbance value of the supernatant was measured at 295 nm using a uv/vis spectrophotometer.
total protein concentration was determined spectrophotometrically with bradford method [19].
xo activity was expressed as micromoles of uric acid formed per minute (u) per milligram protein.
2.11. statistical analysis all data were expressed as mean ± standard deviation and rounded to have three significant figures.
for difference between two means for unpaired data, t-test was performed.
for difference among three or more means for unpaired data, analysis of variance (post hoc test: tukeyʼs multiple range test) was performed.
a p value less than 0.05 was considered to be statistically significant.
3. results 3.1. in vitro antioxidant activity the in vitro antioxidant activity of qale was determined with the dpph and reducing power assays.
the dpph free radical scavenging assay is a widely used method to evaluate free radical scavenging ability of plant extracts.
as a result, a relatively low ic50 value (10.6 ± 0.5 μg/ml) of qale was observed in the dpph radical scavenging assay (table 2).
to determine the reducing capability of qale, the transformation of fe3+ to fe2+ was measured in the presence of the extract.
the reducing power of 50-μg qale was determined to be equivalent to that of a relatively high amount of ascorbic acid (36.3 ± 3.5 μg).
3.2. total phenolic and flavonoid contents total phenolic content of qale was measured with gallic acid equivalence method using folin-ciocalteu's reagent (standard curve equation: y = 0.023x + 0.124, r2 = 0.999) [15].
the total phenolic content of qale was determined to be 126 ± 2 mg/g eq.
gallic acid (table 2).
the total flavonoid content of qale was measured with quercetin equivalence method (standard curve equation: y = 6.694x + 0.035, r2 = 0.999).
as shown in table 2, total flavonoid content of qale was determined to be 27.6 ± 1.4 mg/g eq.
quercetin.
3.3. in vitro xo inhibitory activity the xo inhibitory activity of qale was expressed as a suppression rate of uric acid production.
allopurinol (positive control) at concentration of 30 μg/ml significantly inhibited the activity of xo (by 64.55 ± 2.55%).
results of the in vitro xo inhibitory activity of qale are shown in figure 1. the relative xo activity of qale at concentrations of 250 μg/ml or higher was significantly higher than that of control group (without qale) in a dose-dependent manner.
the qale at concentration of 1 mg/ml showed the highest xo inhibitory activity (by 44.0 ± 0.3%).
3.4. in vivo antihyperuricemic effect of qale on serum uric acid levels the effect of qale on serum uric acid levels in potassium oxonate-induced hyperuricemic mice is shown in figure 2. serum uric acid concentrations in the hyperuricemic mice (hu group) at 1 h after intraperitoneal injection of potassium oxonate, a urate oxidase inhibitor, were significantly higher than those in normal mice, indicating that the mouse model of hyperuricemia was successfully established, consistent with a previous report [17].
the serum uric acid concentrations in the hu group were significantly reduced by oral pretreatment of allopurinol (hu + alp) or qale at doses of 50 and 250 mg/kg (hu + qa50 and hu + qa250) over 7 days.
3.5. in vivo antihyperuricemic effect of qale on hepatic and serum xo activity the effects of qale on hepatic and serum xo activity in potassium oxonate-induced hyperuricemic mice are shown in figures 3 and 4. hepatic xo activity in hyperuricemic mice was significantly reduced by one week of oral pretreatment of allopurinol (by 46.0%) or qale at doses of 50 and 250 mg/kg (by 46.3 and 32.0%, resp.
), as shown in figure 3. similarly, serum xo activity in hyperuricemic mice was significantly reduced by one week of oral pretreatment of allopurinol (by 25.1%) or qale at doses of 50 and 250 mg/kg (by 35.8 and 33.5%, resp.
), as shown in figure 4. however, there was no significant difference in hepatic or serum xo activity between normal mice and hyperuricemic control mice.
3.6. identification of active constituents gc-ms and hplc analyses were performed to identify active constituents from qale with antioxidant and xo inhibitory activities.
typical gc-ms and hplc chromatograms of phytochemical contents and their retention times are shown in figures 5 and 6. nine compounds [i.e., vitamin e (28.6%), loliolide (0.38%), neophytadiene (2.36%), stigmasterol (11.2%), palmitic acid (1.55%), α-amyrin (3.96%), linolenic acid (0.94%), friedelin (2.97%), and all-trans-squalene (4.13%)] were identified by gc-ms analysis.
additionally, three compounds [i.e., quercetin (0.212%), luteolin (0.0279%), and apigenin (0.0426%)] were identified by hplc analysis.
4. discussion this study aimed to determine the antioxidant, xo inhibitory, and antihyperuricemic activities of qale and identify its active constituents.
in our preliminary study, air-dried powder of qa leaf was extracted with various solvents (such as hexane, ethyl acetate, ethanol, and water) and the ethyl acetate extract was found to possess higher xo inhibitory, dpph free radical scavenging activity, and reducing power than other extracts (data not shown).
the ethyl acetate extraction condition was then optimized with respect to its antioxidant and xo inhibitory activity (data not shown).
based on these results, the ethyl acetate extract was selected for further in vitro and in vivo characterization.
our present results clearly indicate that the qale is enriched with phenols and flavonoids (table 2).
polyphenols and flavonoids of natural resources are widely known to possess various biological activities [20, 21].
several phenols and flavonoids have been shown to possess antioxidant and xo inhibitory activity with ability to decrease serum uric acid levels [21, 22].
therefore, serum uric acid level and hepatic xanthine oxidase activity were evaluated in this study to determine the antihyperuricemic effect of qale.
as shown in figures 2–4, qale significantly reduced serum uric acid levels and inhibited the activity of hepatic and serum xo even at a relatively low oral dose (50 mg/kg).
these results clearly indicate that one week of oral administration with qale can markedly alleviate the hyperuricemic state in mice.
there was no significant difference in hepatic or serum xo activity between the normal mice group and hyperuricemic control mice group, suggesting that intraperitoneal pretreatment with potassium oxonate, a known uricase inhibitor, does not affect the xo activity in mice.
as shown in figure 5, we identified several bioactive markers related to antioxidant and antihyperuricemic properties, including vitamin e, loliolide, neophytadiene, stigmasterol, palmitic acid, α-amyrin, linolenic acid, friedelin, and all-trans-squalene by gc-ms analysis.
a previous study using vitamin e-deficient rabbits has reported that deficiency of vitamin e could be responsible for increased accumulation of hepatic xo [23].
moreover, oral supplementation with palm vitamin e has been reported to be able to reduce gastric xo activity in rats exposed to water-immersion restraint stress [24].
stigmasterol has also been reported to be able to inhibit hepatic lipid peroxidation and induce catalase and superoxide dismutase activities, suggesting its antioxidant property [25].
α-amyrin has been shown to exert anti-inflammatory effect by reducing the levels of prostaglandin e2 and cox-2 expression in mice with 12-o-tetradecanoylphorbol-acetate- (tpa-) induced skin inflammation [26].
squalene also possesses antioxidant property with ability to prevent lipid peroxidation in human skin surface exposed to oxidative stress such as sunlight exposure [27].
friedelin and loliolide are also well known antioxidant agents with scavenging effects on dpph, nitric oxide, and/or superoxide radicals [28, 29].
friedelin also has potent suppressive effect on lipid peroxidation [28].
similarly, palmitic acid has been reported to be able to significantly reduce h2o2 generation both by neutrophils and in the xo system [30].
linolenic acid is known to be able to downregulate inducible nitric oxide synthase (inos) and cyclooxygenase-2 (cox-2) expression, thereby reducing nitric oxide (no) and prostaglandin e2 production in lipopolysaccharide- (lps-) activated raw264.7 cells with anti-inflammatory activity [31].
additionally, three known xo inhibitors were further identified in hplc analysis (figure 6).
previous studies have reported that luteolin and quercetin can inhibit xo activity in a competitive manner, while apigenin can inhibit it in a mixed manner [17, 32].
taken together, the present study shows that qale possesses antioxidant, xo inhibitory, and antihyperuricemic activities.
in addition, several phytochemicals identified from the qale might be responsible for its biological activities.
this study provides a good basis for future development of qa-based dietary or medicinal preparations as an alternative to allopurinol.
5. conclusions the present study investigated the antioxidant and antihyperuricemic effects of qale and identified major active phytochemicals therein.
the ethyl acetate extract of qa leaf was shown to possess potent in vitro antioxidant and xo inhibitory activities.
our in vivo mouse study demonstrated that qale at a relatively low oral dose (50 mg/kg) could inhibit hepatic xo activity and significantly alleviate hyperuricemia to the extent comparable to allopurinol.
several active compounds including vitamin e known to possess xo inhibitory activity were identified from qale by gs-ms and hplc analyses.
to the best of our knowledge, this is the first study that reports the active constituents and antihyperuricemic effects of qa.
our results suggest that it might be feasible to use qale as a food therapy or alternative medicine to alleviate hyperuricemia and gout.
@highlight
quercus acuta thunb.
(fagaceae) (qa) is cultivated as a dietary and ornamental plant in china, japan, south korea, and taiwan.
it has been widely used as the main ingredient of acorn tofu, a traditional food in china and south korea.
the aim of this study was to determine in vitro and in vivo xanthine oxidase (xo) inhibitory and antihyperuricemic activities of an ethyl acetate extract of qa leaf (qale) and identify its active phytochemicals using gas chromatography-mass spectrometry (gc-ms) and liquid chromatography (lc) systems.
the qale was found to possess potent in vitro antioxidant and xo inhibitory activities.
in vivo study using hyperuricemic mice induced with potassium oxonate demonstrated that the qale could inhibit hepatic xo activity at a relatively low oral dose (50 mg/kg) and significantly alleviate hyperuricemia to a similar extent as allopurinol.
several active compounds including vitamin e known to possess xo inhibitory activity were identified from the qale.
to the best of our knowledge, this is the first study that reports the active constituents and antihyperuricemic effect of qa, suggesting that it is feasible to use qale as a food therapy or alternative medicine for alleviating hyperuricemia and gout.
