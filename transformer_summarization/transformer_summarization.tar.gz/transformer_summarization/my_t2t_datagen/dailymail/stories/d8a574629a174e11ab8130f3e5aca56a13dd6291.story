1. introduction despite efforts to raise awareness towards both the correct use of sunscreens and the risks of excessive sun exposure, skin cancer cases have risen in recent years [1–3].
according to the world health organization, 2–3 million non-melanoma and 132 000 melanoma skin cancers occur per year worldwide (as of 2003), which translates to one in every three cancers diagnosed being a skin cancer [1].
in the uk alone, 12 800 people were diagnosed with malignant melanoma (the most serious type of skin cancer) in 2010, rising to 14 509 new cases reported in 2013 [3].
the cost of skin cancer treatment in england in 2008 was estimated to be in the range of £106–112 million and is predicted to increase to approximately £180 million by 2020 [4].
the increase in skin cancer incidence is thought to be, in part, related to a cultural tendency for more sun exposure, as well as the increased use of sunbeds and, importantly, the inadequate use of sunscreen lotions [3,5].
like all other types of cancer, skin cancer is a complex problem, the causes of which are not yet fully understood.
nevertheless, ultraviolet (uv) radiation has been consistently shown to be a carcinogen, involved in both direct and indirect dna damage [6–10], despite its essential role in maintaining plant and animal life on the earth [11].
uv radiation is classified according to wavelength as uva (400–315 nm), uvb (315–280 nm) or uvc (280–100 nm), as represented in figure 1 [13].
while the amount of uvc that reaches the earth is negligible [12], as it is absorbed by the ozone layer in the stratosphere [14], the amount of uva and uvb radiation at the earth's surface (approx.
220 µw cm−2 on a cloudless day, globally) is chemically significant [15,16].
figure 1.wavelength regions of uva (green), uvb (blue) and uvc (violet) radiation in the standard solar spectrum (black line) and the solar spectrum at the earth's surface, after atmosphere effects (red line).
the inset shows the total solar spectrum, with the uv region highlighted (grey shading).
solar spectra raw data obtained from the national renewable energy laboratory (nrel) website [12].
(online version in colour.)
both uva and uvb are capable of causing erythema (sunburn), which in itself is thought to be triggered by dna damage.
it is estimated, however, that approximately 1000 times more uva radiation is necessary to cause the same level of damage as compared with uvb [17].
despite being more prominent at ground level (as it is not absorbed as efficiently as uvb by the atmosphere) [18,19], uva radiation is considered to be less carcinogenic than uvb radiation, because it does not interact with dna as extensively [20–23].
uvb radiation can be directly absorbed by dna [21], producing highly mutagenic photolesions, such as cyclobutane pyrimidine dimers and pyrimidine 6–4 photoproducts [20,24].
even though these errors in the dna sequence can be repaired by excision repair pathways [20], those which fail to be repaired will result in uv signature mutations and, potentially, carcinogenesis [25,26].
uvb is, therefore, considered to be the most significant type of radiation in the induction of skin cancers [27,28].
while there are natural protection mechanisms against uv-induced dna damage (vide infra), the prevalence of skin cancer cases makes it clear that artificial enhancement of these mechanisms through man-made sunscreens is necessary.
the active agents present in current sunscreens can be categorized into two main groups: physical blockers and chemical absorbers [29].
physical blockers are substances which reflect or scatter uva/uvb, such as titanium dioxide and zinc oxide nanoparticles (which, however, also absorb uv radiation) [30].
these species are usually regarded as inert and non-toxic [31], but they are also used in other industries as photocatalysts (for example, in water treatment) [29].
photocatalytic activity could potentially present a problem in sunscreen formulations and, therefore, there are certain methods designed to reduce it.
however, the effectiveness of these methods has yet to be established and their implications on sunscreen safety have not been explored [29].
while this is a considerable problem that requires addressing, this review will focus on the chemical absorbers: molecules which absorb uva/uvb radiation and thus supplement the skin's own sunscreen molecules, such as melanin pigments.
the chemical absorbers commonly used in the sunscreen industry fit roughly into the seven categories shown in figure 2 (alongside representative sunscreen filter molecules): these are (i) para-aminobenzoate derivatives, (ii) cinnamate derivatives, (iii) salicylate derivatives, (iv) anthranilate derivatives, (v) camphor derivatives, (vi) dibenzoyl methane derivatives, and (vii) benzophenone derivatives [29,32,33].
the conjugated systems present in all these molecules allow for strong uv absorption [34–36].
however, no single molecule will provide photoprotection across the entire uva and uvb range, so chemical absorbers are usually used in conjunction with each other [37] in order to ensure that the sunscreen complies with established regulations, such as sun protecting factor (spf) values and uva/uvb absorption ratios [38,39].
figure 2.
(a–g) the seven main categories of most sunscreen active absorbing ingredients and representative examples of each.
sunscreen formulations are tested for their photoprotective capability by measuring how long they delay the appearance of erythema in treated skin when compared with an untreated sample [40,41].
in addition, and as with any other cosmetic product, sunscreen lotions are tested for dermatological compatibility, in terms of their allergenic and photoallergenic potential [42,43].
it has been reported that organic sunscreen filters can act as photosensitizers, i.e.
induce an allergic reaction after absorption of uv radiation; however, the exact mechanisms of photoallergy are still unknown [43].
particularly in the context of sunscreen development, it is also informative to analyse the mechanisms responsible for photoprotection in natural sunscreens.
in much the same way that human skin requires melanin pigments to provide protection against uv damage [44], other living organisms also have an intrinsic need for photoprotection and hence have developed their own photoprotective mechanisms [45,46].
in plant species, uvb radiation was found to have a number of damaging effects, such as growth inhibition, disruption to photosynthesis and transpiration, and general damage to dna, proteins and membranes [47,48].
in addition, studies have found that plants which lack the ability to efficiently produce certain phenolic molecules, such as sinapate esters and flavonoids (figure 3), are more vulnerable to uvb-induced damage [49].
these molecules are, therefore, believed to provide photoprotection to plant species [50,51].
for example, in arabidopsis thaliana (brassicaceae), sinapate esters were found to play a major role in the attenuation of the adverse effects caused by excess uvb radiation [52].
the intrinsic photoprotective properties of these molecules may be instructive towards the design of the next generation of artificial sunscreens; hence, understanding their photodynamics is of particular relevance.
as such, a discussion of these chemical absorbers will also feature herein.
figure 3.two main types of plant sunscreen: (a) sinapate derivatives and flavonoids, of which (b) flavonol is an example.
the phenomena, occurring at a molecular level in synthetic and natural sunscreen species upon absorption of uv radiation, which are overlooked by the current sunscreen testing methods, could not only lead to photoproducts but also result in long-lived excited states, both of which have the potential to trigger photosensitivity [53].
unravelling the photodynamics occurring in sunscreen molecules upon uv absorption will provide insight into their photochemistry and photophysics.
this information may then help to identify and assess potentially harmful relaxation pathways and aid a guided development of a new generation of more efficient sunscreens.
upon absorption of uv radiation, a sunscreen will be photoexcited to a higher energy and potentially reactive electronic state [54].
over time, the system will relax back to the ground (lowest energy) electronic and vibrational state via a number of photochemical/photophysical processes [55,56], such as intramolecular vibrational redistribution (ivr) [57], internal conversion (ic) [58], intersystem crossing (isc) [58], fluorescence [59] or phosphorescence [60], as summarized in figure 4, where only the photophysical processes are shown for simplicity.
some of these processes may induce damage to the skin if, for example, they result in the production of free radicals or other harmful photoproducts [29,61].
an ideal chemical absorber for a sunscreen lotion should not only strongly absorb uva/uvb, but should also be capable of dissipating the excess energy gained via mechanisms that cause no chemical change to occur, reforming the molecule in its original state without forming any potentially harmful species.
figure 4.simplified jablonski diagram showing some of the possible photophysical processes undergone by a sunscreen molecule after uv absorption.
(online version in colour.)
the more efficient the mechanism by which the molecule returns to its ground electronic state, the less the chance of undesirable photochemistry taking place [62].
the fastest of these relaxation mechanisms typically occur within femtoseconds (fs, 10−15 s) or picoseconds (ps, 10−12 s) [63]: the timescales of nuclear motion and the breaking (or creating) of chemical bonds.
however, other photophysical processes (fluorescence, for example) can take place on the nanosecond (ns, 10−9 s) timescale, while phosphorescence can take up to seconds [64].
in these cases, the excited states will persist long enough that there is a higher chance for detrimental photochemistry to occur.
an in-depth study on these excited-state decay mechanisms has the potential to unveil any harmful photochemistry that might not be detectable at a macroscopic level if, for example, any long-lived excess energy facilitates damage to dna.
in the remainder of this review, we will explore the spectroscopic techniques that have recently been utilized in gas-phase studies to initiate this stepwise approach towards unravelling the photochemistry and photophysics of sunscreen filter molecules, as well as providing a synopsis of the contemporary information gathered on this subject to date.
these studies provide the initial ground work for an exciting field of research where much is yet to be unravelled, which we briefly expand on in the summary and outlook.
2. methodologies: frequency- and time-resolved spectroscopy in the gas phase the advances in laser technology over the past few decades [65] have allowed for the development of a plethora of spectroscopic techniques [66] which enable one to experimentally obtain information on electronic structure and excited-state dynamics which could not be gathered previously.
however, owing to the molecular complexity of sunscreen molecules, performing frequency- and time-resolved spectroscopic measurements on them often yields rather intricate spectra and dynamics which may not be unambiguously analysed.
therefore, it is advantageous to employ a bottom-up approach [67,68], wherein a complex system, for example, a large sunscreen molecule, is broken down into its component parts.
these components are then studied in the interaction-free environment offered by in vacuo gas-phase experiments in order of increasing molecular complexity, building up to the large sunscreen molecule of interest.
these studies are then extended into a more real-world scenario [69] by the inclusion of solvents through micro-solvation (gas-phase cluster studies) and solvation (solution phase) as well as increasing the number of interacting species.
this bottom-up approach has proved very useful in providing insight, for example into the photostability of dna/rna nucleobases and their corresponding chromophore (i.e.
uv absorbing) subunits [70–72].
this stepwise approach yields a comprehensive understanding of the photochemistry and photophysics of sunscreen molecules following uv radiation absorption.
this section gives a brief overview of the techniques which have been employed as outlined above to study the sunscreen molecules to be discussed in the exemplar case studies presented in §3.
(a) frequency-resolved spectroscopy a molecule's photochemistry and photophysics are highly dependent not only on the arrangement of its constituent atoms, but also on its electronic and vibrational energy structure, termed vibronic structure herein [73].
therefore, an understanding of a molecule's vibronic structure aids the interpretation of that molecule's photoreactivity [73].
frequency-resolved spectroscopy techniques can provide a picture of the vibronic structure of a given system by photoexciting molecules to specific vibrational levels and then using various methods to probe these excited states.
high-frequency resolution is provided by narrow bandwidth lasers.
the spectral bandwidth of a laser pulse, δν, is related to its temporal full width at half maximum (δt) by the following [74]: 2.1δν≥kδt.
in the above equation, k is a constant which depends on the profile of the pulse.
to achieve the sub-wavenumber resolution necessary to resolve vibronic (and in some cases rovibronic) states, nanosecond pulses are required [75–78].
frequency-resolved techniques can be improved by the use of molecular beam technology, which is the current standard for gas-phase experiments [65,66,79].
by seeding molecules in a buffer gas, such as a noble gas, they are collisionally cooled to a vibrational temperature of just a few kelvins [66].
rapid expansion of the molecules into vacuum ‘freezes’ the sample at these temperatures and a skimmer removes the outer ‘hot’ region of the beam produced.
the skimmer, a cone-shaped orifice (see figure 7 for details), separates the source region (where the gas is introduced into vacuum) from the interaction region (where the gas, in the form of a molecular beam, interacts with the laser pulses).
this generates a directed flow of cold molecules with a narrow velocity distribution, effectively reducing the doppler effect [80], resulting in spectral lines with a small doppler width and hence improving resolution [66].
the main difference between the various frequency-resolved spectroscopic techniques lies in the method used for the detection of the excited states.
some of the possible experimental arrangements are briefly reviewed in the following sub-sections.
(i) laser-induced fluorescence spectroscopy in laser-induced fluorescence (lif) [81,82] spectroscopy, a molecule, initially in its ground vibronic state (s0), is photoexcited by a pump photon, hνpu, of variable wavelength, so that specific vibronic excited states are accessed, e.g.
in the first excited electronic state (s1), as represented in figure 5a.
the radiative decay of these excited states will then result in a fluorescence signal which is collected by a photomultiplier or similar photodetector.
from this, a plot of fluorescence intensity versus excitation wavelength, or the excitation spectrum, is produced.
alternatively, hνpu may be fixed to a wavelength resonant with a specific vibronic excited state.
the resulting fluorescence signal is then dispersed by a grating onto a photodetector so that fluorescence from this state onto the several vibrational levels of the ground electronic state is monitored, as depicted in figure 5b [83–85].
this is referred to as dispersed fluorescence (dfl).
fluorescence lifetimes can be measured with either of these set-ups, simply by monitoring the fluorescence signal following photoexcitation over time [86,87].
the temporal resolution of these experiments is then limited by detector response times which, for many common photomultiplier tubes, is approximately 1–10 ns [88].
figure 5.schematic of lif (a) and dfl (b).
in lif, hνpu is scanned so that when it is resonant with a certain vibronic state, this state may radiatively decay to any vibrational level in the ground electronic state (s0, represented by thick gradient arrow).
the fluorescence signal is then collected by a photomultiplier.
in dfl, on the other hand, hνpu is set to a particular vibronic state, from which population may fluoresce to any accessible vibrational level of the s0 state.
the total fluorescence signal is dispersed by a monochromator in order to deconvolute the information on the vibrational levels of the s0 state, and again collected by a photomultiplier.
(online version in colour.)
the high signal-to-noise levels of this technique, afforded by detecting a bright signal on a dark background, coupled with the high intensity of the lasers utilized, afford a sensitivity not achievable in absorption spectroscopy [81].
as fluorescence intensity is proportional to the population of the emitting state, lif can provide information on the relative population of excited states [82].
however, as lif is a one-photon process, it is limited by the efficiency of the transitions involved, in both excitation and fluorescence, which are governed by the same symmetry and spin selection rules of any one-photon vibronic transition [34].
as shall become clear in §3, lif and dfl can be successfully applied to the study of sunscreen molecules in the gas phase, providing valuable insight into their electronic structure.
(ii) resonance-enhanced multiphoton ionization spectroscopy resonance-enhanced multiphoton ionization (rempi) is a photoionization technique by which multiple photons are used to first resonantly excite (pump) and then ionize (probe) the molecule of interest [76,89].
rempi schemes are usually referred to as n + m, where n and m are integers which correspond to the number of photons, of a single colour, used to pump and probe the system of interest, respectively [89–91].
when different colours are used for the pump and probe steps, this is referred to as n + m′ [92,93].
while excited states can usually be accessed and probed simply with a (1 + 1) rempi scheme, also referred to as resonant two-photon ionization, or r2pi, as shown in figure 6, there are cases in which several photons need to be absorbed simultaneously to reach a certain electronic excited state.
these multiphoton absorption processes follow an in power dependence on laser intensity (i), where n corresponds to the number of photons absorbed [94,95], and they therefore require the high photon densities achievable with lasers.
figure 6.schematic showing the basic concept behind r2pi.
as hνpu is scanned, each vibronic state is individually accessed.
these states are probed by a second photon, hνpr, and resulting ions are directed to an appropriate detector (see main text).
(online version in colour.)
regardless of the specific ionization scheme, in a rempi experiment, the ions produced by the ionization step are monitored as a function of excitation wavelength.
this produces spectral lines as each new vibronic excited state is accessed, thus revealing the molecule's vibronic structure.
the total ion signal, as a function of probe wavelength, can also be monitored in order to calculate the ionization potential (ip, figure 6) of the molecule under study—the cut-off point, where no ion signal is observed, indicates the point at which the total energy provided to the molecule is no longer sufficient to ionize it [96].
ion detection is usually achieved using a time-of-flight (tof) spectrometer, as shown in figure 7 [97,98].
in simple terms, a tof spectrometer consists of a vacuum chamber with an ion source at one end, where a molecular beam interacts with the laser pulses, and an ion detector at the other.
ions are accelerated towards the detector by one or more electric fields (continuous or pulsed).
before they reach the detector, the ions go through a field-free flight path, i.e.
a region in which no forces are applied, so that the velocity of the ions in this area is dependent on their mass-to-charge (m/z) ratio.
a tof trace can then be constructed of ion signal against arrival time at the detector.
the use of a tof spectrometer in combination with rempi spectroscopy thus provides some mass selectivity [89], which allows for contamination from absorbing species other than the molecule of interest that might be present in the molecular beam to be supressed.
like lif, rempi spectroscopy benefits from high sensitivity which in this case arises due to the capability to detect all the ions produced by photoionization.
in addition, the ionization (probe) step is not as constrained by symmetry selection rules as fluorescence, as photoelectrons will adopt the symmetry required for ionization to take place [99,100].
figure 7.diagram of a typical gas-phase experimental apparatus, including both a molecular beam and a tof mass spectrometer.
the molecular beam interacts with the laser pulses employed in the experiment.
for example, for 1 + 1 rempi, pump, hνpu, and probe, hνpr, laser pulses are necessary, as represented by the red and blue arrows, respectively.
the resulting ions are accelerated towards the detector by a set of ion optics.
the last section of this set-up consists of a field-free flight tube (see main text), so that ions reach the detector at different times depending on their m/z ratio.
(online version in colour.)
by careful selection of the temporal pulse width of the lasers used, frequency-resolved (as described above) or time-resolved experiments can be performed in order to gather dynamical information, as shown by the pulse sequences used in figure 7, where the pump and probe are temporally delayed by δt.
this is discussed in greater detail in §2b(i).
some examples of how rempi spectroscopy, both in a frequency- and a time-resolved context, can be successfully applied to sunscreen molecules will be given in §3.
(iii) double resonance spectroscopy double resonance techniques, such as hole burning (hb) or depletion (ion dip) spectroscopies, are useful when the possibility of contributions to the measured spectra from different conformers needs to be taken into account, as r2pi's mass selectivity cannot help distinguish these [89].
in certain cases, contributions from different conformers in vibrational spectra can be distinguished by the analysis of their rotational structure [101–104].
however, especially for larger molecules, the typical resolution achieved with these techniques (vide supra) is not always enough to resolve closely spaced rotational energy levels [34,79,105].
the ability to distinguish between conformers is particularly relevant when dealing with large molecules, such as the ones discussed herein.
double resonance spectroscopy requires the use of three pulses: an excitation, hνpu, and ionization, hνpr, laser pulse (as for r2pi) and an extra ‘holeburn’ laser pulse, hνhb [89,106].
the term ‘holeburn’ refers to the creation of a population hole in a certain state (e.g.
ground electronic state) by exciting the population to a higher vibronic state [106].
at energies close to the excited-state origin, a wavelength that is resonant with a specific transition in conformer a will likely not be so for a second conformer b. hence, with reference to figure 8, if the wavelength of hνhb is set to be resonant with a transition in conformer a, thus depopulating its ground state, the r2pi signal will be reduced when hνpu coincides with a resonance in this conformer; however, no analogous signal difference will be observed for conformer b [89].
if the total r2pi spectrum is subtracted from the resulting hole-burning spectrum, the contribution from conformer a can be isolated, with the resulting spectrum consisting of negative peaks.
figure 8.schematic of hb spectroscopy.
the hb laser creates a population hole in the ground state of one of the conformers, so that its contribution to the r2pi spectrum is decreased.
subtracting the total r2pi spectrum from the hb spectrum, therefore, yields the isolated contribution from the selected conformer in the form of negative peaks.
multiple headed purple arrows denote the wavelength scanning of the hνpu laser pulse.
various detection techniques (ionization, fluorescence, etc.)
can be used.
(online version in colour.)
the same principles apply for depletion spectroscopy, for which the wavelength of hνhb is scanned, with hνpu fixed on a single transition in one conformer [107–109].
in this case, there will be a reduction in the detected signal whenever hνhb is resonant with a vibronic state in this conformer.
these techniques, therefore, provide complementary information although one must note that there are differences in the factors that influence ion signal intensities.
depletion spectroscopy monitors changes in ion intensity (as hνhb is scanned) compared with a constant pump–probe signal.
as such, the signal intensity depends on the absorption cross section of the transition accessed by hνhb.
in hb spectroscopy, on the other hand, as it is the excited state leading to ionization that is being varied, the signal intensity depends on both absorption cross section and also on excited-state dynamics.
it is also worth briefly noting that, for both hb and depletion spectroscopy, it is assumed that after photoexcitation by the holeburn laser pulse, population will not return to the lower energy state within the timescale of pump–probe irradiation [110–114].
the hb spectroscopy technique described in figure 8 uses uv radiation in both the hole-burning and pump steps, and is therefore commonly referred to as uv–uv hb spectroscopy.
however, as will be demonstrated by the case studies in §3, infrared (ir) radiation can also be used in double resonance techniques, providing conformer selective infrared spectra [112,115].
(b) time-resolved spectroscopy important photochemical and photophysical processes happen very shortly after the absorption of uv radiation, typically on timescales of the order of femtoseconds to picoseconds (fs–ps, where 1 fs = 10−15 s and 1 ps = 10−12 s) [34].
the study of such ultrafast phenomena is usually referred to as femtochemistry, a term largely disseminated by the nobel laureate ahmed h. zewail [116].
these ultrafast dynamics may be used to infer how effectively a sunscreen molecule dissipates excess energy and hence its adequacy for use as a photoprotecting molecule.
in order to be able to follow these dynamical processes, a laser temporal pulse width on the order of femtoseconds is needed and currently the technology to generate laser pulses with less than 50 fs pulse duration is widely available [117–119].
however, a higher time resolution can be achieved only at the expense of reduced frequency resolution and such laser pulses are generally incapable of resolving individual vibronic states.
nevertheless, the obvious strength of time-resolved techniques lies in the ability to follow the molecular dynamics occurring immediately after excitation in real-time, achieved by varying the time delay, δt, between the pump and probe laser pulses, as will be explored further in the next section.
(i) time-resolved ion yield spectroscopy time-resolved ion yield (tr-iy) is a technique used to study the dynamics following photoexcitation to an excited electronic state, by monitoring the ion signal resulting from ionization of the excited molecule over time.
to achieve this, tr-iy follows the pump–probe scheme detailed, for example, by zewail and co-workers (e.g.
[116]), which, in fact, resembles an r2pi scheme (vide supra).
initially, the molecule of interest, seeded into a molecular beam, is photoexcited to an excited electronic state by a pump laser and the system is then allowed to evolve freely over time.
after the initial excitation, a probe laser interacts with the photoexcited molecules over a number of time delays, δt.
as the molecule relaxes from its excited electronic state (by any feasible photochemical or photophysical pathway), the population of this state and hence the corresponding parent cation signal will change.
ion detection in tr-iy is carried out as previously described for rempi experiments, using a tof mass spectrometer, enabling one to gate on the parent cation (figure 7).
by plotting the parent cation signal as a function of time delay, a tr-iy transient is obtained from which the lifetime of the excited electronic state can be extracted.
importantly, by integrating over different mass channels, tr-iy transients of photofragments can also be obtained and the dynamics of their formation extracted.
utilizing such mass selectivity enables one to begin to build up a comprehensive picture of the excited-state decay pathways in operation in a given molecule [68].
the dynamical information obtained from tr-iy thus nicely complements the information gathered from frequency-resolved techniques (and vice versa).
it is worth recalling, however, that while frequency-resolved techniques have sufficient resolution to individually access single vibronic states, it is inevitable that the much broader pump pulses used in time-resolved techniques will access several vibrational states within an electronic state.
the dynamics and extracted lifetimes correspond, therefore, to a convolution of superposed vibronic states.
finally, it should be briefly noted that both types of experiment (frequency- and time-resolved) will benefit from insights provided by computational methods [120].
while the specific details of computational studies will not be discussed in the present review, their results will be referred to, where appropriate, in order to inform the discussion of the case studies explored hereafter.
3. case studies the interest in the excited-state dynamics of uv absorber molecules in a sunscreen context has only recently gained momentum, but there is already a significant collection of important works reported on this subject.
this section will comprise an overview of a sample of the recent work carried out on various sunscreen molecules using the gas-phase methodologies described in §2.
the authors acknowledge, however, that there are other works which are also relevant to this field of research but were not discussed in this review for the sake of brevity [121].
similarly, there is the literature describing work carried out on sunscreen molecules and their precursors using the techniques mentioned in this review, but for which the results were not interpreted in a sunscreen context [122].
these studies were, therefore, not included in this review, but they do provide powerful insight towards an understanding of the photophysics of the artificial and natural sunscreen species we will discuss in §3a and b, respectively.
(a) cinnamate derivatives (i) methoxycinnamates ehmc/mmc.
many commercial sunscreen lotions use various cinnamate derivatives (figure 2b) as uv absorbing species.
in fact, one of the most widely used sunscreen agents, 2-ethylhexyl-4-methoxycinnamate (ehmc, figure 9) [123], falls within this category.
however, apart from its wide application as a sunscreen, ehmc has been found to undergo potentially harmful chemistry upon uv radiation absorption, such as photoisomerization and release of reactive oxygen species [124–126].
figure 9.molecular structures of different rotamers of 2-ethylhexyl-4-methoxycinnamate (ehmc) and methyl-4-methoxycinnamate (mmc).
the cis/trans isomerization occurs around c8–c9, while the syn/anti isomerization occurs around c4-och3.
e/z isomerization occurs around c7=c8.
tan et al.
[127] studied ehmc in the gas phase using frequency-resolved r2pi and uv–uv depletion spectroscopy.
in the same paper, the authors report studies on methyl-4-methoxycinnamate (mmc, figure 9), a simplified version of ehmc, in keeping with a bottom-up approach.
the r2pi spectra of both mmc and ehmc are presented in figure 10. computational simulations were also performed in order to identify the vertical excitation energies and characteristics of the relevant electronic excited states.
figure 10.
(1 + 1′) r2pi excitation spectra for mmc (a, solid black line) and ehmc (b, solid black line), where 1 corresponds to the uv excitation pulse and 1′ to a 193 nm ionization pulse.
solid red and blue lines correspond to the separate uv–uv depletion spectra from the cis and trans rotamers of each molecule, respectively.
the arrows indicate the origin bands for each rotamer, to which the molecules were photoexcited when acquiring depletion spectra.
reproduced with permission from reference [127].
(online version in colour.)
depletion spectroscopy measurements by tan et al.
shown in figure 10, suggest that, under the conditions of these experiments, two rotamers of both mmc and ehmc were present: cis and trans with respect to rotation around the c8–c9 single bond (figure 9).
the syn and anti pairs are also possible for both mmc and ehmc, with respect to rotation around the c4-och3 single bond, but these were not considered in this work.
both the cis/trans and syn/anti pairs mentioned are specifically referred to as rotamers, because they interconvert around a single bond and are only distinguishable under conditions of a molecular beam [128–130].
for the benefit of later discussion, it is worthy of note that these molecules can also exist as their corresponding e/z stereoisomers (cf.
rotamers) with respect to rotation around the c7=c8 double bond (figure 9).
the origin bands of the lowest 1ππ* (s1) state of mmc were found to be located at 32 328 and 32 667 cm−1 for the cis and trans rotamers, respectively.
in ehmc, these bands are located at 32 258 and 32 562 cm−1 for the cis and trans rotamers, respectively.
it was also noted that the r2pi spectrum of mmc is more structured than that of ehmc, which was attributed to the increased molecular complexity of ehmc, due to the addition of an ethylhexyl chain.
tan et al.
were able to extract the excited-state lifetimes of the 1ππ* states for both rotamers of mmc by fitting the r2pi peaks corresponding to the origin bands of each rotamer with a lorentzian profile.
analysis of these peak-linewidths yielded a reported excited-state lifetime of mmc of 2.9 ps for the cis rotamer and 2.0 ps for the trans rotamer [127].
the authors noted, however, that these values are lower limits owing to rotational broadening in their experiments.
for ehmc, the broad onset of absorption and lack of structure in the r2pi spectrum make the analogous measurements more challenging.
nevertheless, rough estimates of the linewidths of the origin bands in the r2pi of ehmc place its excited-state lifetimes in the sub-picosecond range, which is supported by solution-phase fluorescence lifetime measurements of similar systems reported in the literature [131].
in an attempt to corroborate these excited-state lifetimes, the authors monitored the time-resolved r2pi signal from mmc and ehmc by varying the time delay between the uv excitation and 193 nm ionization pulses with a time resolution of nanoseconds (figure 11).
the recorded tr-iy transients were fit with a mono-exponential function yielding time constants of 24.0 ± 0.2 ns for mmc, and 17.7 ± 0.7 ns for ehmc; much longer than the lifetimes anticipated from linewidth measurements.
the observation of two such different time constants in these experiments suggests that two photophysical processes might be occurring in both mmc and ehmc.
while the 1ππ* states of each of these molecules were found to have a picosecond lifetime, an excited state(s) evidently persists for several nanoseconds.
based on the predictions by other authors [132], tan et al.
assigned this nanosecond time constant to a long-lived 1nπ* state.
this was also reconciled through computational work by the same authors, which places the 1nπ* state adiabatically lower in energy than the 1ππ* state, in accordance with other cinnamate derivatives [132].
figure 11.tr–iy of (a) ehmc photoexcited at 32 526 cm−1 and (b) mmc photoexcited at 32 667 cm−1.
reproduced with permission from reference [127].
(online version in colour.)
the findings by tan et al.
regarding mmc [127] were expanded on by an independent study by miyazaki et al.
[133], who performed similar r2pi and depletion spectroscopy measurements and complemented their interpretation of these results with theoretical studies.
apart from the cis and trans rotamers previously reported by tan et al.
[127], miyazaki et al.
[133] were also able to identify the syn and anti rotamers of mmc (see figure 9 for structures) with the aid of computational studies.
as shown in figure 12, miyazaki et al.
assigned the experimental bands at 32 328 and 32 667 cm−1 to the cis/syn (figure 9a) and cis/anti (figure 9c) rotamers, respectively (cf.
assignments by tan et al.
[127]).
in addition, while the peak observed at 32 587 cm−1 is assigned to the trans/syn conformer, the peak that might be expected to correspond to the trans/anti conformer was not observed experimentally.
figure 12.
(a) lif, (b) r2pi and (c–e) depletion spectra of mmc under molecular beam conditions.
asterisks (*) in (b) indicate hot bands.
calculated electronic transition energies of the different possible conformers (f) were also included for comparison with experimental data.
data collected by miyazaki et al.
reproduced with permission from reference [133].
(online version in colour.)
the time-resolved r2pi signal of mmc following photoexcitation to its s1 origin was also measured by miyazaki et al.
[133] with picosecond resolution (cf.
nanosecond resolution in tan et al.
's results [127]), yielding an s1 lifetime of 280 and 80 ps for rotamers a and c, respectively.
the tr-iy transients are presented in figure 13. in addition, the authors also reported these lifetimes to be dependent on excess energy, becoming shorter with increasing excitation energy in s1 (for each rotamer).
while the authors did not reconcile the discrepancies between these results and those from tan et al.
's work, namely in terms of much longer initial time constants and the lack of a long-lived state (vide supra), the latter is very likely owing to a difference in probe wavelength.
miyazaki et al.
probed for [mmc]+ with 315 nm and measured the ip of mmc to be 63 427 cm−1 (t ebata 2016, personal communication).
therefore, the total energy provided to the system (approx.
64 000 cm−1) might not be sufficient to ionize from the long-lived, adiabatically lower lying 1nπ* state as observed with the 193 nm probe used by tan et al.
[127].
nevertheless, the excess energy dependence of the s1 lifetimes measured by miyazaki et al.
suggests the existence of a potential energy barrier for non-radiative decay via 1ππ* → 1nπ* ic.
importantly, miyazaki et al.
have also suggested e/z photoisomerization to be a viable non-radiative decay pathway for mmc, occurring in competition with ic from 1ππ* → 1nπ*.
figure 13.pump–probe ion signal (circles) and kinetic fits (solid line) of mmc photoexcited to various vibronic levels of the cis/syn, trans/syn and cis/anti conformers and ionized with 315 nm light.
data collected by miyazaki et al.
reproduced with permission from reference [133].
in summary, both studies (tan et al.
[127] and miyazaki et al.
[133]) are in general agreement with regard to the photophysical processes occurring in mmc in the gas phase, despite understandable discrepancies in the measured time constants; the time-resolution and probe energies of their respective experiments being probable frontline causes.
as a final note, it is also important to discuss a most recent study where yamazaki et al.
[134] have presented both experimental and computational data which strongly implicates that triplet states might also be involved in the photophysics of mmc.
the authors propose that, upon absorption of uv radiation, and in addition to the aforementioned ic from the bright 1ππ* state to the 1nπ* state, mmc undergoes isc from both the 1ππ* and 1nπ* states into a manifold of triplet states.
the long lifetimes of mmc observed by tan et al.
[127] could then, according to yamazaki et al.
[134], also correspond to the population trapped in these triplet states.
these results highlight the role of triplet states in the photophysics of sunscreen molecules, which will be explored later in this review.
mmc-h2o.
the lifetimes of the 1nπ* states reported by tan et al.
for both mmc and ehmc in the gas phase [127] are orders of magnitude longer than the excited-state lifetimes of eumelanin, one of the skin's natural photoprotective molecules [135].
this would suggest that neither mmc nor ehmc behaves as an ideal sunscreen molecule.
however, as sunscreens are administered as lotions, solvent interactions need to be considered.
in order to evaluate how the gas-phase spectroscopy and excited-state lifetimes for these molecules might be affected in the presence of solvents, tan et al.
[127] preformed micro-solvation studies on mmc, using the same methods described previously.
the r2pi excitation spectrum, obtained by tan et al.
resulting from excitation to the origin of the first 1ππ* state of the mmc-h2o cluster, revealed the presence of four different conformers with origins at 32 106, 32 129, 32 390 and 32 529 cm−1, the molecular structures of which were not determined.
from the measured linewidths of the bands in the r2pi spectra, there is a factor of two increase from the approximately 2.5 ps 1ππ* state lifetime observed for isolated mmc.
however, the nanosecond lifetime attributed to the 1nπ* state was not observed in the tr-iy measurements of the mmc-h2o cluster (cf.
isolated mmc), with any dynamics now occurring within the instrument response.
from these results, tan et al.
concluded that ic via 1ππ* → 1nπ* is no longer an active relaxation pathway for the mmc-h2o cluster, and that non-radiative decay to the ground state, mediated by e/z photoisomerization is likely the dominant pathway.
recent theoretical work on mmc by chang et al.
[136], as well as on related systems [132,137], has also shown e/z isomerization to be the dominant relaxation pathway in mmc-h2o clusters, while mmc undergoes ic via a 1ππ* → 1nπ* transition instead.
it is well known that polar solvents will significantly destabilize 1nπ* states while also possibly stabilizing 1ππ* states, resulting in a net increase in the energy difference between these two states [138,139].
tan et al., therefore, proposed that micro-solvation of mmc is likely to reverse the ordering of its electronic states, effectively inhibiting ic from 1ππ* → 1nπ*.
even though the same studies were not performed for ehmc, it is likely that these observations would still be valid owing to the relatively unperturbing nature of ehmc's extended hydrocarbon chain.
if this is the case, then ehmc would undergo fast relaxation to its ground state by dissipating excess energy into its surroundings, justifying its effectiveness as a sunscreen molecule.
miyazaki et al.
[133] also studied the mmc-h2o cluster to complement the findings of tan et al.
[127].
their r2pi spectrum of mmc-h2o revealed that the lowest energy s1 ← s0 transition is approximately 200 cm−1 lower in energy than that of isolated mmc, being located at 32 106 cm−1, labelled b and a′.
another prominent peak, b and b′, was observed in the r2pi spectrum of mmc-h2o at 32 529 cm−1.
comparison between ir–uv depletion spectroscopy measurements (where the hole-burning laser pulse is an ir pulse) and calculated oh vibrational frequencies suggested two conformers of the mmc-h2o cluster were present, the first corresponding to a water molecule bridging the carbonyl oxygen and a vinyl hydrogen (b and a′), the second corresponding to a water molecule bridging the carbonyl oxygen and methyl hydrogen (b and b′).
miyazaki et al.
[133] performed picosecond tr-iy experiments on the mmc-h2o cluster using the same methodology as discussed for the isolated mmc molecule (vide supra).
these measurements were taken after excitation to band a′ and b and b′, with both transients modelled with a function consisting of two exponential decays, as shown in figure 14. for band a′, the two time constants extracted were 21 and 150 ps, while for band b′ the time constants were 35 and 150 ps.
importantly, the shorter time components extracted from the tr-iy transients of both conformers of mmc-h2o were shorter than the corresponding time constants for all conformers of the isolated mmc molecule.
these observations are in general agreement with the results by tan et al.
[127], which showed that micro-solvation of mmc accelerates its relaxation to the ground state.
also in accordance with the suggestions by tan et al.
[127], computational work carried out by miyazaki et al.
[133] revealed that the micro-solvation of mmc lowers the energy of the 1ππ* state and increases that of the 1nπ* state.
this inversion of electronic states causes the observed red shift in the s1 ← s0 transition of the mmc-h2o cluster when compared with isolated mmc, as well as the increase of the potential energy barrier for 1ππ* → 1nπ* ic, which now becomes an unfavourable decay pathway.
potential energy curves also revealed that the energy of the mmc-h2o system decreases with increasing dihedral angle towards e/z isomerization.
e/z isomerization is, therefore, the likely relaxation mechanism for mmc-h2o, as tan et al.
[127] had previously suggested.
figure 14.tr–iy (dotted circles) and kinetic fits (black line—total fit, red and blue lines—components) of the mmc-h2o complex photoexcited at 32 106 cm−1 (a) and 32 529 cm−1 (b), ionized with a 315 nm probe.
data collected by miyazaki et al.
reproduced with permission from reference [133].
(online version in colour.)
as a final note, we briefly refer to another conclusion drawn from miyazaki et al.
's work [133].
while the discussion so far has related specifically to para-mmc, in which the methoxy group is positioned in the para position with respect to the long side chain, miyazaki et al.
[133] also studied ortho- and meta- mmc (which are not used in commercial sunscreens) in order to evaluate the impact of the substituent position in the photodynamics of mmc.
these studies revealed that a radiative decay pathway is now preferred for both ortho- and meta- mmc [133].
this demonstrates how substituent position may affect the ultrafast dynamics of uv absorbers and, indeed, how an understanding of the photophysics of these systems may help tailor an efficient sunscreen molecule.
(ii) ethyl ferulate continuing with cinnamate derivatives, ethyl 4-hydroxy-3-methoxycinnamate (ethyl ferulate, ef, figure 15c), a naturally occurring plant product, is another example of a strong uv absorber molecule which is used in commercial sunscreens.
rodrigues et al.
[140] studied this sunscreen filter molecule using frequency- and time-resolved techniques as well as computational methods.
in keeping with a bottom-up approach, two precursor molecules, 3-methoxy-1-vinylphenol (mvp, figure 15a) and 4-hydroxy-3-methoxycinnamyl alcohol (coniferyl alcohol, cona, figure 15b), were also studied.
figure 15.3-methoxy-1-vinylphenol (mvp, (a)), 4-hydroxy-3-methoxycinnamyl alcohol (coniferyl alcohol, cona, (b)) and ethyl 4-hydroxy-3-methoxycinnamate (ethyl ferulate, ef, (c)).
the blue dashed lines represent the h-bonds between the adjacent hydroxy and methoxy substituent groups.
(online version in colour.)
frequency-resolved r2pi and uv–uv hb spectroscopy measurements carried out for mvp and cona by rodrigo et al.
[141] found that both mvp and cona are present in two different rotamers, labelled a and b. the two rotamers of mvp have s1 origins at 32 802 cm−1 (a) and 33 525 cm−1 (b), while for cona these origins are located at 32 640 cm−1 (a) and 33 445 cm−1 (b).
comparison of experimental data with computational results suggests that rotamers a and b for both mvp and cona correspond to their respective syn and anti pairs, with respect to the relative positions of the oh substituent group on c4 and the vinyl group on c1.
the tr-iy studies by rodrigues et al.
[140] showed that photoexcitation to the s1(v = 0) origin band of the syn rotamers of both mvp and cona directly accesses a long-lived state.
this is evidenced by the plateau in the tr-iy transients for mvp+ and cona+, figure 16a,b respectively, which extend beyond the experimental time window of their measurements (more than 900 ps).
the gas-phase studies alone, therefore, suggest that neither of these precursor molecules behave as ideal sunscreens.
in ef, however, the addition of the carbonyl moiety was shown to significantly change the behaviour of this molecule when compared with its precursors (figure 16c and below).
to investigate this further, r2pi and uv–uv hb spectroscopy were performed on ef by rodrigues et al.
[140], revealing the existence of two conformers with s1(v = 0) origin bands located at 31 491 and 31 507 cm−1.
the bandwidth of the laser used for the tr-iy measurements encompasses both conformers (cf.
single conformer excitation in mvp and cona [140,141]), thus conformer-specific dynamics could not be obtained and assignment of the bands was not attempted.
figure 16.tr–iy (hollow points) and associated kinetic fits of (a) mvp, (b) cona and (c) ef.
each molecule was excited at the s1 origin and probed with 200 nm light.
data collected by rodrigues et al.
reproduced with permission from reference [140].
(online version in colour.)
using the r2pi and uv–uv hb spectroscopy data, rodrigues et al.
[140] then carried out tr-iy experiments by photoexciting ef with 317.5 nm (approx.
31 500 cm−1) radiation and tracking the excited-state dynamics with a 200 nm probe, the transient of which is shown in figure 16c.
the ef+ transient was modelled with a function consisting three exponential decays, returning time constants of τ1 = 15 ± 4 ps, τ2 = 148 ± 47 ps and τ3 > 900 ps.
as an accurate lifetime for the long-lived electronic state (τ3) could not be obtained with the tr-iy set-up used in these experiments, fluorescence lifetime measurements were taken, revealing a lifetime of 6.9 ± 0.1 ns.
dfl spectra after excitation to the electronic origin of each conformer were consistent with emission from the s1 origin.
in the light of these results, computational methods were employed to evaluate possible relaxation pathways for ef.
while results from mmc and ehmc (vide supra) would suggest that an e/z isomerization pathway is likely involved in the excited-state dynamics of ef, calculations suggest a very large barrier to such isomerization (approx.
8800 cm−1), as shown in figure 17a.
similarly, while calculations suggest that an 1nπ* state is accessible from the s1 origin (figure 17b), transition into this state would likely result in two lifetimes, as seen in mmc and ehmc (vide supra), rather than the three observed in ef.
figure 17.results of the computational work by rodrigues et al.
(a) potential energy cuts (pecs) of the s0 (black line), s1(11ππ*) (red line), s2(11nπ*) (blue line) and s3(21ππ*) (green line) states of ef along the e/z isomerization coordinate are shown.
optimized ground state geometries for each isomer and at the s0/s3 conical intersection (ci) are also presented.
(b) pecs of the s0 (black line), s1(11ππ*) (red line), s2(11nπ*) (blue line) and s3(21ππ*) (green line) states of ef along linearly interpolated internal coordinates (liics).
the blue and grey shaded areas represent the s0 to s1 and s1 to s2 (via s1/s2 ci) liics, respectively.
optimized geometries and molecular orbitals for the s1 and s2 states are also presented.
reproduced with permission from reference [140].
(online version in colour.)
guided by the previous literature, which suggests that the photochemistry of carbonyl compounds is closely linked with the existence of triplet states [54,127,142–149], rodrigues et al.
used computational methods to search for such states in ef.
these studies revealed three near isoenergetic triplet states approximately 2000 cm−1 lower in energy than the s2(11nπ*) energy minimum (t2(23ππ*), t3(33ππ*) and t4(13nπ*)) and a fourth, lying approximately 10 500 cm−1 below these (t1(13ππ*)).
apart from being close in energy to both the s1(11ππ*) and s2(11nπ*) energy minima, these triplet states are also the correct orbital type for favourable isc, according to el-sayed's rule; isc is most efficient for transitions where there is a change in orbital type [150].
the complexity of the system under study hindered the unequivocal assignment of time constants to a specific photophysical process.
instead, rodrigues et al.
proposed a scenario where multiple processes occur simultaneously, so that the observed time constants correspond to a convolution of relaxation pathways, as illustrated in figure 18. the authors proposed that photoexcitation of ef at 317.5 nm (approx.
s1 origin of both conformers) results in wave packet bifurcation [151,152] to populate both the s1(11ππ*) and s2(11nπ*) states, followed by ivr to the respective energy minima of each state and/or isc into the triplet state manifold.
the convolution of these processes, in competition with one another, would then correspond to τ1 = 15 ± 4 ps.
from here, the system evolves via two parallel mechanisms: (i) a convolution of ivr and ic down the ladder of triplet states, happening within τ2 = 148 ± 47 ps, and (ii) radiative decay of population trapped in the energy well of the s1(11ππ*) state, corresponding to the measured fluorescence lifetime of 6.9 ± 0.1 ns.
rodrigues et al.
point out, however, that this is not a unique solution to the assignment of the time constants observed, and that contributions from multiple conformers or photofragmentation pathways cannot be ruled out.
figure 18.schematic of the proposed decay mechanisms for excited-state relaxation in ef.
relaxation refers to isc or phosphorescence back to the ground state; reaction encompasses such mechanisms as photofragmentation/photocyclization.
note that ‘reaction’ has been omitted from s1 for clarity, although it is still a valid pathway.
reproduced with permission from reference [140].
(online version in colour.)
while the authors could not reach a concrete conclusion regarding the relaxation pathways of ef upon uv radiation absorption, this case study serves to demonstrate a number of interesting points.
first, these studies suggest that, in the gas phase, ef does not behave as an ideal sunscreen species (nor its precursors mvp and cona), given the presence of a long-lived excited electronic state.
as with the previous case studies involving mmc and ehmc, it is likely that solvent interaction will change this; therefore, solution-phase studies on ef would be highly relevant.
moreover, the case of ef illustrates the complexity of the photophysical processes responsible for the efficiency of sunscreen molecules.
when ef is compared with both mvp and cona, it becomes clear how a simple molecular change can impact the deactivation pathways of a molecule.
this also demonstrates how important it is to be able to identify the molecular structures primarily responsible for the dissipation of excess energy, so that future sunscreen species can be tailored for maximum efficiency.
(b) sinapate derivatives the term ‘sinapate derivatives’ refers to a group of molecules structurally related to sinapic acid, as shown in figure 19. sinapate derivatives are ubiquitous in nature, being found in fruits, vegetables, grains and oilseed crops, for example, where they exhibit diverse bioactivity [153].
more importantly for the purpose of this review, these species have an important role in plant photoprotection, as discussed in §1.
for example, sinapoyl malate (sm), one of the most complex sinapate derivatives, studied by dean et al.
[142] is found in the epidermis of arabidopsis plant leaves [154] and it has been shown to be involved in plant photoprotection mechanisms following exposure to uvb radiation [155].
in keeping with a bottom-up approach, dean et al.
[142] studied a series of sinapate derivatives of increasing molecular complexity, as shown in figure 19. these molecules were studied with a combination of spectroscopies, including r2pi (one and two colour), uv–uv hb and dfl, as well as computational methods [142].
the following paragraphs present a summary of the results obtained, focusing mainly on sm owing to its prevalence in plant photoprotection.
figure 19.the sinapate series studied by dean et al.
[142].
in the lower right corner, marked with a box, is sm, on which this section will mainly focus owing to its role as a natural sunscreen found in the leaf epidermis of certain plant species.
(online version in colour.)
all of the sinapate species studied show strong uvb absorption, i.e.
all have large oscillator strengths for the s1(1ππ*) ← s0 transition.
the striking differences between the malate containing species, sm and sdm, and the rest of the sinapate series are immediately evident when comparing their corresponding r2pi spectra, as shown in figure 20. while increased molecular complexity results in increasingly congested spectra, as would be expected, the extensive spectral broadening in both sm and sdm appears to be a unique characteristic in this series.
the very broad spectra observed for these two species imply effective absorption of radiation across much of the uvb region, which, at first glance, justifies their sunscreen capabilities.
moreover, such spectral broadness may be linked with short-lived excited-state lifetimes, absent in the simpler derivatives studied.
assuming that sm's dynamics involve a fast relaxation to its ground electronic state, this may also justify sm's efficacy as a sunscreen.
therefore, the origins of the unique spectral broadening in sm are of the utmost interest if its sunscreening capabilities at a molecular level are to be understood.
this extensive broadening, however, results in featureless spectra that hinder any reliable vibronic analysis; therefore, extracting information from sm's spectra is not straightforward.
figure 20.r2pi spectra for the sinapate derivatives studied by dean et al.
[142].
while simpler molecules show clearly resolved spectra, increasing molecular complexity introduces vibronic congestion.
in the case of sm and sdm, the extensive spectral broadening and congestion results in complete loss of vibronic resolution.
reproduced with permission from reference [142].
while many non-dynamical effects can be responsible for spectral broadening, such as increased molecular complexity or multiple stable conformers leading to congested vibronic spectra, upon comparison with the other sinapate derivatives studied, dean et al.
disregarded such reasoning for the featureless spectra in sm and sdm.
the less extensive broadening in the structurally similar sml and smb led dean et al.
to rule out ivr as a potential source of the broadening in sm and sdm.
comparison with theoretical calculations also caused the authors to dismiss franck–condon activity and/or molecular complexity arguments as viable explanations for these featureless spectra, while ir ion-dip measurements ruled out absorptions from multiple conformers.
as such, an alternative explanation for the observed results was sought.
it is well-documented that locally excited states, such as a 1ππ* state, can couple with nearby charge–transfer states [156,157].
this can lead to complete spectral broadening by virtue of coupling to a manifold of vibronic levels belonging to the adiabatically lower energy charge–transfer state.
in essence, the oscillator strength of the optically bright locally excited state is dispersed across the neighbouring charge–transfer levels.
dean et al.
[142] carried out theoretical calculations to compute electron density difference maps (eddms) of the main singlet excited states of sm.
these eddms showed that the 1nπ* state in sm has partial charge–transfer character, involving a shift of electron density localized around the first carboxylic acid of the malate group and the antibonding orbital on the ring.
the existence of a charge–transfer state in sm is supported by fluorescence measurements carried out by dean et al.
[142].
these measurements, which were performed in aqueous solution for both sa and sm for comparison, showed a considerable stokes shift in the emission peak of sm when compared with sa.
this suggests that the emitting state is stabilized in a polar solvent, which is a general observation for charge–transfer states, as reported in the literature [158,159].
the fluorescence spectra of sm, therefore, support the existence of a charge–transfer state, as proposed by dean et al.
[142].
despite not having collected any evidence for the existence of long-lived triplet states in sm (owing to experimental constraints), dean et al.
also point out the possibility of isc being involved in its photodynamics.
as discussed in previous sections, triplet states have been reported to be active in the excited-state dynamics of carbonyl-containing species [54], and indeed it has been suggested by rodrigues et al.
[140] that such states are likely to play an important role in the photodynamics of the natural sunscreen molecule, ethyl ferulate (see §3a(ii)).
as triplet states have also been linked to the formation of singlet oxygen [160,161], which would be detrimental to sm's performance as a safe uvb sunscreen, this is another aspect of this molecule's spectroscopy which requires further study.
in conclusion, dean et al.
found that, as expected, sm, an important sunscreen molecule in certain plant species, absorbs strongly and broadly across the uvb region.
the remarkable broadening of the absorption spectrum of sm was tentatively attributed to a mixing of 1ππ* and 1nπ* electronic states, the latter having some charge-transfer character.
the very low fluorescence quantum yields obtained in solution for sa and sm suggest that non-radiative pathways dominate the excited-state dynamics.
these authors encourage the importance of future studies aimed at characterizing the intermediate and final states involved in these dynamics, both in the gas- and solution phase.
4. summary and outlook while the field of photodynamics of sunscreen molecules is still in its infancy, the work carried out thus far, in both the frequency- and time-domain, has highlighted the wealth of information that may still be gathered, as well as the potential impact of such research to the sunscreen industry.
the three case studies reported in this review have revealed a wide range of research opportunities and are likely to encourage further work on the subject.
for example, the work by baker et al.
[162], which demonstrates how gas-phase studies may be extended into the solution-phase, offers a tantalizing prospect of a plethora of future studies in environments that more closely mimic the surroundings in which these sunscreen molecules are found.
baker et al.
[162] photoexcited and probed the excited-state dynamics of sa, ms and sm (figure 19) using transient electronic absorption spectroscopy (teas) [162–164], in both a non-polar and polar solvent (cf.
the gas-phase studies by dean et al.
[142], §3b).
while frequency-resolved gas-phase studies [142] revealed marked differences in the spectra of these molecules, with sm yielding an exceptionally broadened r2pi spectrum when compared with simpler analogues, the teas studies showed remarkably similar data for sa, ms and sm.
importantly, it had been concluded from gas-phase studies that an effective non-radiative process was likely to be responsible for sm's sunscreen properties, but a photoprotection mechanism could not be drawn from the data available.
the teas studies by baker et al.
[162] (guided by the theoretical work of karsili et al.
[137] for similar systems) were able to expand on this prediction and provide a detailed picture of the excited-state dynamics occurring in sa, ms and sm.
for all three molecules, baker et al.
suggest that, after initial photoexcitation to the 11ππ* electronic state, ic to a second 21ππ* state occurs via a 11ππ*/21ππ* conical intersection (ci).
this, in turn, is followed by the formation of either the e or z conformer of the molecule in the ground state via a second 21ππ*/s0 ci.
importantly, for all three molecules and in both non-polar and polar solvents, the molecules return to their ground electronic states in tens of picoseconds, making all three good candidates for photoprotection.
however, only sm is used in nature as a photoprotective agent, which highlights that there may be other factors that govern the selection of sm as a natural sunscreen agent over the biological precursor sa.
although the information on the photodynamics of individual sunscreen molecules is valuable (as discussed), commercially available sunscreen lotions are a complex mixture of components (absorbers, scatterers, photostabilizers, fragrances to name but a few).
therefore, the next step within the bottom-up approach would be to evaluate how interactions within such mixtures affect the photodynamics of, say, a sunscreen filter molecule.
this would be particularly important for sunscreen filter molecules which populate long-lived states upon absorption of uv radiation when studied in isolation.
in a mixture, such long-lived states could be reactive.
indeed, it is well known that some sunscreen blends incorporate the use of photostabilizers [165,166] to counter this.
it is, therefore, crucial to explore these types of interactions.
in conclusion, we have seen how frequency- and time-resolved studies in both the gas- and solution phase, as well as computational work, all have the potential to provide crucial insight into the photodynamics of sunscreen molecules.
indeed, as mentioned in the introduction to this review, these techniques (and in particular the bottom-up approach) are also useful in the study of any such photoabsorbing species such as dna and other biomolecules [70–72].
this information, in turn, can aid in the development of a new generation of sunscreens, tailor-made in order to maximize their efficiency and safety, to make them capable of more effectively tackling the increasing risks of uv radiation exposure in today's society.
@highlight
the relationship between exposure to ultraviolet (uv) radiation and skin cancer urges the need for extra photoprotection, which is presently provided by widespread commercially available sunscreen lotions.
apart from having a large absorption cross section in the uva and uvb regions of the electromagnetic spectrum, the chemical absorbers in these photoprotective products should also be able to dissipate the excess energy in a safe way, i.e.
without releasing photoproducts or inducing any further, harmful, photochemistry.
while sunscreens are tested for both their photoprotective capability and dermatological compatibility, phenomena occurring at the molecular level upon absorption of uv radiation are largely overlooked.
to date, there is only a limited amount of information regarding the photochemistry and photophysics of these sunscreen molecules.
however, a thorough understanding of the intrinsic mechanisms by which popular sunscreen molecular constituents dissipate excess energy has the potential to aid in the design of more efficient, safer sunscreens.
in this review, we explore the potential of using gas-phase frequency- and time-resolved spectroscopies in an effort to better understand the photoinduced excited-state dynamics, or photodynamics, of sunscreen molecules.
complementary computational studies are also briefly discussed.
finally, the future outlook of expanding these gas-phase studies into the solution phase is considered.
