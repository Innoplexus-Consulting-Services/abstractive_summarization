introduction bscl2 (berardinelli-seip congenital lipo-dystrophy 2; omim: 606158) was first identified in bscl2 patients in 2001 [1].
the gene, which is also called seipin, is located on chromosome 11q13 and contains 11 exons.
it has been revealed through northern blot analysis that bscl2/seipin produces three transcripts of 2.2 kb, 1.8 and 1.6 kb.
the 1.8-kb mrna is only expressed in brain and testis but the two other transcripts are expressed ubiquitously[2].
seipin protein has three isoforms (1-3) that are 462, 398, and 287 amino acids long, respectively[3].
all three isoforms contain two hydrophobic amino acid regions predicted to be transmembrane domains.
seipin can anchor to membranes through hydrophobic interactions using these regions.
in fact, seipin resides in endoplasmic reticulum where these two trans-membrane domains are buried in endoplasmic reticulum membrane.
the middle part of the protein, which is conserved during evolution, is located inside the endoplasmic reticulum lumen, and both n-terminal and c-terminal domains face cytoplasm[2,4-7].
although the function of seipin is not completely elucidated, some researchers have shown that the protein has a role in adipogenesis, biogenesis of lipid droplets and metabolism of lipids[8-14].
however, others have depicted a potential neural involvement[15-18].
mutations in bscl2/seipin cause two distinct phenotypes.
loss-of-function mutations are responsible for congenital generalized lipodystrophy type 2 (berardinelli-seip syndrome type 2; omim: 269700).
gain-of-function mutations or gain-of-toxic function mutations in seipin gene result in neurological disorders like silver syndrome/spastic paraplegia 17 (omim: 270685) and distal hereditary motor neuropathy type v (omim: 600794).
these disorders are currently being referred to as “seipinopathies”.
patients with seipinopathies have heterogeneous symptoms and manifest both upper and lower motor neuron disruptions[19].
recently, a new seipin-associated neurodegenerative syndrome has been introduced by guillén-navarro et al.
[20], known as progressive encephalopathy with or without lipodystrophy (peld; omim: 615924).
they found six children affected with severe, progressive encephalopathy from four apparently unrelated families.
all of the patients were from murica in southeastern spain, and the transmission pattern of the disorder was compatible with autosomal recessive inheritance.
whole exome sequencing (wes) is an innovative exome-targeted technique that utilizes sequence capture technology to selectively capture the exome region within the whole genome, followed by target fragments enrichment and high-throughput sequencing.
here, we present an iranian patient carrying the r329x mutation in the bscl2, whose diagnosis was difficult, and finally clinical wes confirms the diagnosis of peld.
materials and methods subjects and clinical assessment the research was reviewed and approved by a duly constituted ethics committee of tehran university of medical sciences (tehran, iran).
a written informed consent was obtained from parents of the patient.
blood samples from the proband and his parents were collected and processed.
clinical evaluations included standard history, physical examination, brain mri, brain ct-scan, and metabolic profiling.
dna extraction genomic dna was extracted from the blood leucocytes of the proband and his parents using the qiaamp blood kit (qiagen, hilden, germany) according to the manufacturer’s protocols.
whole exome sequencing wes was performed by bgi shenzhen (beijing genome institute, shenzhen, china).
exons of dna samples were captured using the in-solution sureselect target enrichment system (agilent, human all exon kits v2; agilent technologies, inc., santa clara, ca, usa), followed by a paired-end high-throughput sequencing on reads of 75 bp using illumina hiseq 2000 (illumine inc., san diego, ca, usa).
a 23-giga base sequence was generated with at least 98.08% coverage for 4×, 91.86% for 20×, and 85.66% for 30× of the sample.
the coverage of the target region was 98.93%, and the mean depth was 90.58×.
sanger sequencing was performed to confirm the candidate variants found in wes as well as segregation analysis of the candidate variants within the family.
in silico pathogenicity assessment of variants non-exonic and synonymous variants were removed.
the process was followed by the removal of common variants (i.e., minor allele frequency >0.02) reported in the single nucleotide polymorphism database (dbsnp), the 1-k human genome, the esp6500 and bgi in house databases.
to evaluate the pathogenicity of the novel variants, we analyzed the potential impact of a given variant on the function or structure of the encoded protein.
the analysis was carried out based on conservation, physical properties of the amino acids or possible occurrence in regulatory or splicing motifs using bioinformatic tools sift (sift.jcvi.org), polyphen-2 (http://genetics.bwh.harvard.edu/pph2), combined annotation dependent depletion[21], and mutationtaster[22].
among the prioritized variants, truncating mutations or mutations predicted to be damaging were considered to be the most promising candidates.
pubmed and omim were reviewed for previous publications regarding candidate genes as well as functional and expression data.
results clinical findings the proband was a boy born at term via cesarean section (due to fetal distress) from a 25-year-old mother.
the parents were first-degree cousins.
family history was unremarkable for genetic or metabolic disorders (fig.
1).
his birth measurements (weight: 3000 g, head circumference: 36 cm and length: 49 cm) and the neonatal history were normal.
due to poor weight gain at early infancy, soy-based, lactose free formula was added to the breast feeding.
he was operated for inguinal hernia at 4th month of age and was hospitalized one more time due to pneumonia at 6th month of age.
his growth was within the acceptable range.
the motor and cognitive developmental milestones were within the acceptable range until two years but the speech and social skills were delayed.
at 2.5 years of age, ritalin was prescribed for hyperactivity.
afterwards, other developmental milestones, especially motor skills, regressed significantly.
when ritalin was discontinued, his skills improved slightly but the regression continued later.
fig.
1 pedigree of the iranian family with progressive encephalopathy with or without lipodystrophy.
electroencephalography demonstrated the presence of non-convulsive status epilepticus, which was intractable to anti-epileptic drugs.
convulsive epilepsy appeared later.
his weight gain was poor but the height growth was normal (weight: 14 kg and height: 117 cm at 7.5 years of age).
he had a history of a dry skin with excessive sweating of hand and palm.
there was a generalized loss of skin fat, especially in the facial skin.
in addition, there was a generalized hypertrichosis with low frontal hairline.
the neurological examination showed an autistic child with repetitive and stereotypic hand movements, repetitive upward staring, ataxia, generalized hypertonia, and severe global developmental delay.
fundoscopic examination was normal.
however, the death occurred at the age of eight following an episode of status epilepticus.
the brain ct-scan and mri in the 3rd year of age showed only an arachnoid cyst in the left hippocampus.
evaluation of plasma biochemical metabolites, including glucose, calcium, urea, creatinine, ammonia, lactate, blood gas, aminoacid profile, and acylcarnitine profile demonstrated no pathologic finding.
liver and thyroid function tests were also normal.
genetic findings totally, 131811 snps and 17317 indel variations were detected in the exome analysis (table 1).
to identify the pathogenic mutation, the exome data sequence variants were filtered step-by-step to reduce the number of potentially pathogenic variants as described above.
finally, we sorted the filtered variants according to the zygocity and combined annotation dependent depletion-phred score (cut-off=15).
seven homozygous variants were found in genes like bscl2, cep164, hps5, pex16, and chrna3 (table 2).
only the mutation in the bscl2, which causes peld syndrome, was compatible with the clinical findings of the proband.
the bscl2 mutation was a nonsense mutation in exon 7 of the gene (nm_001122955.3:c.985c>t[p.r329x]).
table 1 summary of variants detected through whole exome sequencing variant types proband total number of variants obtained 149128 total indel variants 17317 exonic non-synonymous variants* 226 exonic non-synonymous homozygous variants* 14 coding indel* 22 frame shift* 3 nonsense* 1 splice site* 1 * minor allele frequency (maf)<0.02 table 2 exonic homozygous variants (maf<0.02) with high cadd score gene name transcript* dna change amino acid change fr.
1 fr.
2 fr.
3 fr.
4 raw score phred v1.3 bscl2 nm_001122955.3 c.985c>t p.arg329* .
.
.
0 9.94193 36 cep164 nm_014956.4 c.1246c>t p.arg416cys .
.
.
0 5.40362 26 hps5 nm_181507.1 c.2866t>c p.tyr956his 0.000693 .
0.000693 0 5.0166 25.2 hps5 nm_181507.1 c.1685c>t p.thr562met 0.0005 0.0005 .
0.0002 2.18428 17.41 pex16 nm_057174.2 c.760g>c p.val254leu 0.014096 0.0101 0.018712 0.0101 1.98294 16.1 ddhd1 nm_001160148.1 c.336_337insggcggc p.gly112_ser113insglygly 0 .
.
.
1.95542 15.93 chrna3 nm_000743.4 c.67_69delctg p.leu23 del 0 .
.
.
1.88124 15.47 *all rare variants in omim disease (less than 2% in 1k human genome, dbsnp, esp6500 or bgi in house database) are listed in this table.
*the report is based on omim database updated on 19 january 2015.
*transcript, the id of mrna transcript of the gene.
mostly, we choose the longest one; fr.1, dbsnp allele frequency; fr.2, 1k-genome database frequency; fr.3, esp6500 frequency; fr.4, bgi in-house database frequency.
maf: minor allele frequency, cadd: combined annotation dependent depletion.
mutationtaster predicts this variant to be disease causing.
this mutation was not present in dbsnp, the 1k human genome, the esp6500 and bgi in house databases.
sanger sequencing confirmed the wes results.
the proband carried the mutation homozygously, and unaffected parents were found to be heterozygous for the mutation (fig.
2).
fig.
2 sequencing chromatograms of the proband and his parents.
discussion peld is a severe neurodegenerative disorder characterized by developmental regression of motor and cognitive skills in the first years of life and often results in patient’s death in the first decade of life.
clinical features include psychomotor regression, loss of speech, poor motor coordination with increased muscle tonicity, spasticity, ataxia, tremor, myoclonus-dystonia and seizures.
a mild lipodystrophic phenotype with a lipoatrophic appearance can be found in most of the patients.
some of the affected people may have hypertriglyceridemia and hepatomegaly[20].
the iranian patient had almost all of these clinical findings, as mentioned above.
in this study, we presented a proband with neuro-developmental regression, in which extensive neurologic and metabolic evaluations were not sufficiently specific for the diagnosis.
we decided to perform wes on the affected patient in search for homozygous and potentially damaging gene variants.
analysis of wes revealed a known homozygous sanger validated nonsense mutation c.985c>t (p.r329x) in exon 7 of the bscl2 gene related to peld.
based on the deleteriousness of the variant and the overlap between clinical features of the iranian patient with the patients in whom the mutation was originally found, this variant was considered to be the most likely pathogenic candidate variant of the ones identified by wes.
the variant is segregating in the family.
peld is an extremely rare condition; only six cases have been reported in scientific literature so far[20] and, to our knowledge, this is the first report of a peld patient from iranian population.
identification of pathogenic mutation in rare mendelian disorders could increase the quality of clinical diagnosis, patients management, and family counseling[23].
however, the establishment of a molecular diagnosis is particularly difficult in case of rare syndromes, in diseases with very high degrees of genetic and/or clinical heterogeneity and when clinical information in patients is limited or unspecific to reach to a conclusive diagnosis.
multiple studies have shown that wes technology can be beneficial to delineate the cause of the disease at dna level and expedite the process of final clinical decision-making in situations of this nature[24,32].
in the present study, we have elucidated the genetic cause of peld in an iranian patient.
we have also demonstrated the usefulness of wes in identifying the causative variant.
this study illustrates how wes can be used in a clinical setting to identify pathogenic mutations in search for a specific diagnosis.
furthermore, wes can be used to accelerate clinical investigations of heterogeneous mendelian traits as yet inconclusive cases.
@highlight
background: progressive encephalopathy with or without lipodystrophy is a rare autosomal recessive childhood-onset seipin-associated neurodegenerative syndrome, leading to developmental regression of motor and cognitive skills.
in this study, we introduce a patient with developmental regression and autism.
the causative mutation was found by exome sequencing.
methods: the proband showed a generalized hypertonia and regression of all developmental milestones.
based on the advantages of next-generation sequencing (ngs), whole exome sequencing (wes) was requested.
the functional significance of variants was evaluated by ngs-specific prediction servers.
sanger sequencing was used for segregation analysis in the family.
results: there was no specific sign in the clinical and paraclinical investigations of the patient to establish a conclusive clinical diagnosis.
wes detected a known homozygous nonsense mutation in bscl2 (nm_001122955.3:c. 985c>t; p.arg329*).
the variant is segregating in the pedigree with an autosomal recessive pattern.
conclusion: exome sequencing is a robust method for identifying the candidate gene variants in mendelian traits.
