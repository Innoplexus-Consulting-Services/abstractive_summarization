esophageal cancer has been identified by cruk as a cancer of unmet need, due to a persistent low 5-year survival rate (13%).
in 2010, 8500 people were diagnosed with esophageal cancer in the uk and in 2011 there were 7600 deaths, making it the 4th most common cause of death in males.
in recent decades the incidence of esophageal cancer has risen in western populations and there has been a shift in histology from squamous cell carcinoma (scc) to adenocarcinoma (aca).
tumors are commonly localized to the lower esophagus and gastro-esophageal junction.
at presentation the majority of patients are unsuitable for surgery and have locally advanced or metastatic disease irrespective of histologic type.
platinum-based chemotherapy regimens (cisplatin, carboplatin, oxaliplatin) are the mainstay of treatment for esophageal cancer.
definitive chemo-radiotherapy (dcrt) is a treatment option in patients with localized inoperable disease and pre-operative (neo-adjuvant) chemoradiotherapy (ncrt) is increasingly becoming an established standard worldwide for operable patients.
however, cures remain elusive and there is an urgent need to develop agents that can enhance the outcomes from the currently available treatment options [1].
atr (atm and rad 3-related), is an essential phosphatidylinositol 3-kinase (pi3k)-like kinase which responds to replication stress and dna damage by initiating extensive downstream signaling to protect the cell from genome instability [2].
once activated atr can induce cell cycle arrest, inhibit replication origin firing, protect stalled replication forks and initiate dna repair.
an atr inhibitor can potentiate the anti-cancer activity of dna damaging agents (which include cisplatin, carboplatin and radiation).
recently, potent selective inhibitors of atr (as opposed to the broad-spectrum inhibitors of other pi3k-related kinases) have been developed [3], [4].
there is a strong scientific rationale for combining atr inhibitors with platinum based chemotherapy and radiation, the standard therapies for esophageal cancer, although in vitro and in vivo experiments using esophageal cell lines have not been previously reported.
in other tumor sites, concurrent atr inhibition has been shown in vitro to improve the response to cisplatin and radiation, both of which are key therapeutics in the treatment of esophageal cancer [5], [6].
in addition, atr inhibition has been shown to be particularly cytotoxic to tumor cells with a deficiency in the atm or p53 pathway [3], [7].
esophageal cancers have a high incidence of p53 mutations (∼89.9% in scc of the esophagus and ∼72% in aca) [8].
finally, regions of tumor hypoxia occur within esophageal cancers and hif-1α overexpression has been shown to correlate with chemoresistance and poor patient prognosis [9], [10], [11], [12].
significant levels of tumor hypoxia suggest that esophageal cancers may also experience high levels of replication stress therefore making them sensitive to atr inhibition [13].
here, we demonstrate that the addition of the atr inhibitor vx-970 both chemo and radio-sensitizes esophageal cancer cell lines in vitro and most importantly, that this translates to a significant tumor growth delay when combined with radiation in an in vivo model.
materials and methods cell lines and reagents oe21, oe33 (both scc) and flo-1 (aca) cells were obtained from phe culture collections.
oe21 and oe33 cells were cultured in rpmi, while flo-1 were grown in dmem, all supplemented with 10% fbs.
cells were routinely tested for mycoplasma and found to be negative.
cisplatin, 5-fluorouracil (5-fu), paclitaxel (sigma–aldrich) and carboplatin (tocris bioscience) were used as indicated in individual experiments.
hypoxia treatment cell migration assays using the xcelligence equipment were carried out in a humidified incubator set to 2% o2.
other hypoxic treatments were carried out in a bactron chamber (shel lab) at <0.1% o2 or in a don whitley h35 hypoxystation at 2% o2.
immunoblotting the antibodies used were atr-t1989 (millipore), chk1-s317, chk1-s345, kap1-s824 (cell signaling technology), kap1-s473 (biolegend), kap1 (bethyl/universal biologicals cambridge), chk1, atr, β -actin (santa cruz biotechnology), hif-2α (novus biologicals), hif-1α(bd biosciences) and gapdh (stratech scientific).
xcelligence assay real-time monitoring of oe21 cell migration was performed using the xcelligence rtca dp instrument with the cim-plate 16 (roche) according to the manufacturer’s instructions.
cells were seeded at a density of 40,000 cells/well and 10% fcs was used as chemo-attractant.
colony survival for the combination of vx-970 and chemotherapeutic drugs, the cells were seeded and 4 h later pre-treated with dmso or vx-970 for 2 h. subsequently cisplatin, carboplatin, 5-fu or paclitaxel were added.
for the cisplatin treatment the media was unchanged while colonies formed, while for the carboplatin, 5-fu and paclitaxel treatment the medium was replaced with drug-free media after 24 h of treatment.
for the combination of radiation and hypoxia, cells were treated with vx-970 and exposed to <0.1% o2 for 6 h followed by radiation treatment.
in each case colonies of more than 50 formed over a period of 7–10 days.
colonies were stained with crystal violet and the data analyzed as described previously [14].
radiation treatment cells were irradiated with γ-rays from a cs-137 irradiator (gsr d1 gamma-service medical gmbh, germany; dose rate 1.7 gy/min).
for irradiation in hypoxic conditions, cells were sealed inside the hypoxia chamber in purpose built airtight boxes and then transported to the irradiator.
dosimetry was performed using ebt2 film (isp technologies inc., nj, usa) irradiated in the position of cells.
the exposed ebt2 film strips were scanned and the optical density values corrected as recommended by the manufacturer and converted to dose using a calibration curve obtained from previously scanned film strips, irradiated with a range of known doses using 60co γ-rays.
xenograft tumors all animal procedures were performed in accordance with current uk legislation and were approved by the university of oxford biomedical services ethical review committee, oxford, uk.
oe21 cells were grown as xenograft tumors as previously described [15].
6–8 week old female cd-1 nude mice (charles river, uk) were injected subcutaneously into the flank with 5 × 106 oe21 cells in 50% (v/v) matrigel and serum-free rpmi.
animal groups received either vehicle (10% vitamin e d-alpha tocopherol polyethylene glycol 1000 succinate) or 60 mg/kg of vx-970 orally on 5 subsequent days.
2 groups received a single dose of radiotherapy (10 gy) 2 h after the second vehicle or vx-970 treatment.
an additional 3 animals per each group were harvested one day after radiation for ihc and atr inhibition analysis.
2 h before the tumor was harvested, mice were injected intraperitoneally with 60 mg/kg of pimonidazole.
hypoxic regions were visualized by pimonidazole staining with hypoxyprobe 1 antibody (clone 4.3.11.3, hypoxyprobe) after dewaxing and antigen retrieval with 10 mm sodium citrate buffer (ph 6.0).
alternatively sections were stained for 53bp1 (nb100-904, novus biologicals) or atr-t1989 (abe462, millipore), all followed by hrp-conjugated secondary antibody incubation.
staining was developed with 3,3′-diaminobenzidine (dab, vector labs), and nuclei were counterstained with hematoxylin.
images were obtained using an aperio scanner (leica biosystems).
statistical analysis statistical analysis was performed using graphpad prism 6 software (graphpad software inc.).
for the cell migration, colony survival assays and tumor growth analysis the 2-way anova test was used.
for the analysis of 53bp1 and atr-t1989 one-way anova test was used, followed by student t test for each comparison.
tumor growth curves were analyzed with two-way anova between individual groups.
p values of less than 0.05 considered as significant (*p < 0.05; **p < 0.01; ***p < 0.001; ****p < 0.0001; ns non-significant).
results to determine if inhibition of atr using vx-970 inhibits atr-mediated signaling in esophageal cancer we treated oe21 cells with the inhibitor and then exposed them to hypoxia (<0.1% o2) in order to induce atr activity [16].
as expected an increase in phosphorylated chk1 at both residues s317 and s345 was observed in response to hypoxia and this was decreased in the presence of vx-970.
for the first time, we also observed an induction of phosphorylated atr at t1989 in response to hypoxia and this was also inhibited by vx-970 (fig.
1a).
in addition, we verified that vx-970 treatment did not inhibit hypoxia-induced atm mediated signaling by investigating kap-1 phosphorylation in hypoxia.
oe21 cells were treated with either vx-970 or the well-established atm inhibitor, ku-55933, and exposed to hypoxia.
vx-970 decreased the levels of the atr-chk1 dependent phosphorylation site s473 on kap-1 while not effecting s824 (a site phosphorylated predominantly by atm) (fig.
1b) [16], [17].
together, these data verify that vx-970 specifically and effectively inhibits hypoxia-induced atr signaling in esophageal cancer cells.
in accordance with previous reports, we also observed a reduction in hif-1α stabilization when the atr inhibitor was present (fig.
1a) [5], [18].
interestingly, the level of hif-2α stabilization in response to hypoxia was also decreased by the addition of vx-970.
as hif is also stabilized at higher oxygen concentrations than those required to induce atr activity, we exposed oe21 cells to a milder level of hypoxia (2% o2) and measured hif-1α and hif-2α stability.
in both cases these transcription factors were stabilized slightly less in the presence of the atr inhibitor (fig.
s1).
it is unclear if this difference would be significant enough to affect the hif mediated biological response to hypoxia.
however, we noted that the cells treated with vx-970 in mild hypoxia had a more rounded appearance with an accumulation of the actin cytoskeleton at the cell edges (visualized with f-actin staining), in comparison to cells that were treated with dmso (fig.
1c).
the appearance of the cells suggested to us that they might be less motile in the presence of vx-970 and so this hypothesis was tested using the xcelligence assay [19].
oe21 cells were incubated in hypoxic conditions (2% o2) in the presence of vx-970 or dmso as a control and cell motility was measured over 36 h (fig.
1d).
cells became significantly less motile in hypoxia in the presence of the atr inhibitor.
these data are supportive of a role for atr in hif stabilization and consequently hif-mediated motility but do not rule out a hif-independent effect of atr on cell migration.
we carried out preclinical testing of vx-970 in combination with standard therapies and in conditions which mimic the tumor microenvironment.
initially, we considered the efficacy of combining vx-970 with cisplatin and carboplatin as both these agents induce dna damage and are used to treat esophageal cancer.
oe21 and flo-1 cells were exposed to a range of doses of cisplatin or carboplatin plus vx-970 (50 nm) or a dmso control and colony survival assays were carried out (fig.
2).
in each case the addition of the atr inhibitor proved to significantly increase the loss of viability observed in response to the chemotherapeutic agent.
a similar response was also observed in oe33 cells exposed to cisplatin plus vx-970 (fig.
s2).
in contrast, we did not observe a significant increase in loss of viability when vx-970 was used in combination with 5-fu or paclitaxel in oe21 or flo-1 cells (fig.
s3).
next we investigated the combination of vx-970 and radiation in esophageal cell lines.
the addition of vx-970 significantly increased radiation-induced loss of viability as determined by colony survival assay in oe21, flo-1 (fig.
3a/b) and oe33 cells (fig.
s4a).
to explore this effect further we repeated these experiments in hypoxic conditions to mimic the radiation resistance of tumor cells in vivo.
oe21, flo-1 and oe33 cells were significantly radiosensitized by vx-970 in hypoxic conditions (<0.1% o2) (fig.
3c/d, s4b).
subsequently, we grew xenograft tumors from oe21 cells and investigated the combination of atr inhibitor and radiation in vivo.
oe21 cells formed tumors, which upon analysis of pimonizadole staining could be seen to contain widespread regions of hypoxia (fig.
s5a).
representative tumors from each treatment group were harvested one day after radiation and protein extracts prepared to verify that the atr inhibitor had been effective.
a clear decrease in the levels of both phosphorylated atr and chk1 were observed in a tumor treated with vx-970 (fig.
s5b).
vx-970 mediated inhibition of atr-t1989 was also determined by immunohistochemistry on harvested tumor sections (fig.
4a and s5c).
in addition we stained tumor sections for 53bp1 and observed the expected increase in 53bp1 foci in tumors treated with radiation.
however, using the tumors harvested and analyzed at this point in the treatment schedule there was no significant vx-970 mediated decrease in 53bp1 foci formation (fig.
4b and s5d).
tumor volume was measured over a thirty day period and demonstrated a significant growth delay in those treated with vx-970 and radiation compared to either agent alone (fig.
4c).
further growth delay was observed over 50 days in the combined treatment group (fig.
s6).
discussion we have shown in three esophageal cancer cell lines (two scc and one aca) that the addition of the atr inhibitor vx-970 increases loss of viability in response to cisplatin, carboplatin and radiation.
in the case of radiation we also demonstrate that this combination is still effective in hypoxic conditions which mimic the radiation-resistant fraction of esophageal tumors.
furthermore, we show that vx-970 radiosensitizes tumors grown from the oe21 cell line in vivo.
this preclinical evidence strongly suggests that the addition of vx-970 could be an effective strategy to improve treatment response to esophageal cancer.
in addition, we also highlight the possibility that atr inhibition may also be beneficial due to roles outside of the dna damage response.
the data presented suggest that effects on cell motility and hif-1/2 signaling should be evaluated during further preclinical testing of atr inhibitors.
one possible hypothesis to explain the decreased motility observed is that hif/vegf dependent signaling to rho gtpases is reduced as a result of atr inhibition [20].
our study also suggests that atr-t1989 and kap1-s473 should be further investigated as potential biomarkers for inhibition of atr.
understanding biology is key to the successful development of new treatment strategies for esophageal cancer.
the only biomarker driven therapy in clinical practice to date is trastuzumab, a humanized monoclonal antibody against her2 [21] which is amplified in 15–25% of adenocarcinomas of the esophagus; future treatment strategies should increasingly incorporate drugs that exploit aberrations in specific signaling pathways (in this case, atr inhibition in a p53 mutated tumor).
radiotherapy combined with cisplatin and a fluoropyrimidine (5-fu or capecitabine) is the treatment of choice for patients with localized disease who are unsuitable for surgery and it is being increasingly considered as an alternative to surgery in patients with scc histology.
survival outcomes from esophageal cancer remain poor with less than 20% of patients being suitable for surgery due to disease extent or co-morbidities; even in surgically treated patients median survival is reported to be 24 months [22].
in the uk the scope1 trial failed to show benefit from adding cetuximab to standard dcrt regimen, but did show an unprecedented survival in the standard arm [23].
more recently, the combination of carboplatin with paclitaxel with radiation has been shown to be an effective modality in the pre-operative setting with one phase iii trial showing a doubling of median survival from 24 to 48 months, with low incidence of grade 3–4 treatment associated toxicity and no increase in peri-operative mortality [24].
these studies suggest that further enhancing radiosensitivity may potentially result in improving cure rates in this disease.
our data show that the addition of an atr inhibitor to these regimens can be a potentially effective strategy to improve cure rates in this disease or spare morbid surgery from which patients may take up to 2 years to regain their former quality of life [25].
the combination of vx-970 with radiotherapy alone and with cisplatin-capecitabine based chemoradiation will be tested in chariot, a phase i trial, which will open shortly in the uk (eudract number: 2015-003965-27).
conflict of interest none.
@highlight
background and purpose esophageal cancer has a persistently low 5-year survival rate and has recently been classified as a cancer of unmet need by cancer research uk.
consequently, new approaches to therapy are urgently required.
here, we tested the hypothesis that an atr inhibitor, vx-970, used in combination with standard therapies for esophageal cancer could improve treatment outcome.
material and methods using esophageal cancer cell lines we evaluated the efficacy of combining vx-970 with cisplatin and carboplatin in vitro and with radiation in vitro and in vivo.
radiation experiments were also carried out in hypoxic conditions to mimic the tumor microenvironment.
results combining vx-970 with cisplatin, carboplatin and radiation increased tumor cell kill in vitro.
a significant tumor growth delay was observed when vx-970 was combined with radiotherapy in vivo.
conclusions vx-970 is an effective chemo/radiosensitizer which could be readily integrated in the current treatment paradigm to improve the treatment response in esophageal cancer and we plan to test it prospectively in the forthcoming phase i dose escalation safety study combining the atr inhibitor vx-970 with chemoradiotherapy in esophageal cancer (eudract number: 2015-003965-27).
