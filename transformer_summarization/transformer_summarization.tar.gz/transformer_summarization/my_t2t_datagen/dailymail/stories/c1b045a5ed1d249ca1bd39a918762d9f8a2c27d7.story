1 introduction one of the pathological characteristics of alzheimer's disease (ad) is degeneration of cholinergic neurons of the basal forebrain (davies and maloney, 1976, whitehouse et al., 1982) and acetylcholine is central to a myriad of brain functions including learning and memory (hasselmo, 2006), attention (himmelheber et al., 2000, klinkenberg et al., 2011), and the sleep-wake cycle (lee et al., 2005).
as memory is a key cognitive domain that is impaired in ad, the cholinergic hypothesis was proposed as a key pathophysiological mechanism (bartus et al., 1982).
this remains at the heart of symptomatic management of ad, with widespread use of acetylcholinesterase inhibitors as principal first-line treatment, despite the variability in response and often limited benefits (zemek et al., 2014).
it is, therefore, important to continue to interrogate the role of cholinergic networks in ad in order to improve our understanding of these systems and to drive development of optimal therapeutic interventions in this condition.
cholinergic neurotransmission in the brain is mediated by ionotropic nicotinic acetylcholine receptors (nachrs) and metabotropic muscarinic receptors (machrs), both of which have been implicated in the cognitive deficits in ad (petersen, 1977, sarter and paolone, 2011).
the nachr, which is the focus of this study, consists of 8α (α2–α7, α9, and α10) and 3β (β2–β4) subunits.
these may assemble in different combinations to generate nachr subtypes with varying electrophysiological properties and brain distribution (albuquerque et al., 2009, lindstrom et al., 1995), with the most abundant varieties in humans being α4β2 and α7.
there is now increasing evidence that decreased network connectivity is associated with aging and that this process is accelerated in ad, with specific systems such as the default mode network (dmn) particularly affected (dennis and thompson, 2014).
abnormalities of this and other distributed networks contribute to the ad symptomatology including memory changes (he et al., 2009, sperling et al., 2010) and neuropsychiatric features (rosenberg et al., 2015).
however, what is less appreciated is the role the cholinergic system exerts on some of these key functional networks in ad.
one way to examine network connectivity is by spatial covariance analysis.
in ad, such procedures have previously been investigated with glucose metabolism positron emission tomography and perfusion single photon emission computed tomography (spect) imaging (habeck et al., 2005, johnson et al., 1998, scarmeas et al., 2004).
indeed, we recently successfully applied the technique to 123i-iodo-quinuclidinyl-benzilate spect in ad, deriving an m1/m4 machr spatial covariance pattern (scp) that characterized the receptor changes to cholinergic depletion (colloby et al., 2015).
in the present study, we applied spatial covariance analysis to 123i-5ia-85380 spect scans, a ligand with high affinity for α4β2 nachrs, in a sample of ad patients and healthy similar aged controls (o'brien et al., 2007), to investigate disease-related α4β2 nachr cholinergic networks.
since interpretation of 123i-5ia-85380 images in isolation is difficult due to uncertainty over the effects of cell loss, we also studied the corresponding perfusion resting-state networks.
2 methods 2.1 subjects the sample consisted of 29 nonsmoking (>10 years) subjects (13 ad and 16 healthy elderly controls).
patients with ad were recruited from a community-dwelling population following referral to local old-age psychiatry services.
normal controls were recruited from friends and spouses of patients included in this and other research studies.
all subjects underwent 123i-5ia-85380 and 99mtc-exametazime spect scanning, with scans undertaken within 3 months of each other.
the study was approved by the newcastle, north tyneside, and northumberland local research ethics committee and the uk department of health's administration of radioactive substances advisory committee (arsac).
all participants and/or nearest relative (for patients who lacked capacity) gave informed written consent.
2.2 assessments and diagnosis subjects underwent physical, neurological, and neuropsychiatric assessments, including mental state, history, physical examination, and for patients, blood screen with b12 and folate levels.
the study battery administered included the mini-mental state examination (mmse) (folstein et al., 1975), neuropsychiatric inventory (cummings et al., 1994), cambridge cognitive examination (camcog) (roth et al., 1986) with memory and executive function subscales (camcogmemory, camcogexec).
diagnosis was made by consensus between 2 experienced clinicians using the national institute of neurological and communicative disorders and stroke/alzheimer's disease and related disorders association (nincds/adrda) criteria for ad (mckhann et al., 1984).
all ad subjects met criteria for probable ad.
controls had no signs or symptoms of cognitive disturbance and did not meet criteria for mild cognitive impairment, and all scored within the normal range of cognitive tests; ≥27 on mmse, ≥90 on camcog, and >2 standard deviations (sds) above cutoff scores denoting cognitive impairment.
clinicopathological diagnosis was confirmed for 3 cases that subsequently died (1 control, 2 ad).
2.3 radiochemistry radiosynthesis of 123i-5ia-85380 was produced form the corresponding stanyl precursor, 5-snbu3-a85380, by electrophilic iododestanylation and performed according to details previously described (o'brien et al., 2007).
2.4 acquisition subjects were scanned with a triple-headed rotating gamma camera (picker 3000xp), 2 hours post injection of 185 mbq of 123i-5ia-85380 using a previously reported imaging protocol (o'brien et al., 2007).
within 3 months of 123i-5ia-85380 scanning, all subjects underwent 99mtc-exametazime regional cerebral blood flow (rcbf) spect in accordance with methods described in an earlier study (colloby et al., 2008).
2.5 spatial preprocessing all spect scans were spatially normalized to match, as appropriate, a 123i-5ia-85380 or 99mtc-exametazime spect template in standard stereotactic space using linear image registration software (flirt: http://www.fmrib.ox.ac.uk/fsl/flirt/index.html).
generation of the template images has been described (colloby et al., 2008, o'brien et al., 2007).
the spatially transformed images were then smoothed with a 10-mm full width at half maximum 3d gaussian filter.
2.6 spatial covariance analysis principal component (pc) analysis was applied on a voxel basis to all processed 123i-5ia-85380 spect images using covariance analysis software (http://www.nitrc.org/projects/gcva_pca/) (habeck et al., 2005), producing a series of pc images.
for each pc image, voxels had either positive or negative weights that represent the sign and strength of covariance between voxels.
in this study, voxels with positive and negative weights were viewed as concurrently preserved/increased and decreased α4β2 binding, respectively.
the extent to which an individual expressed the pc image was by way of a subject scaling factor (ssf) for that pc, calculated by superimposing the pc image onto an individual's processed 123i-5ia-85380 scan by computation of a “dot product,” which involves image multiplication on a voxel basis followed by summation of the products generating a score.
higher ssf scores for an individual for that pc image represents greater increased binding in voxels with positive weights and greater concurrent decreased binding in voxels with negative weights.
to identify the 123i-5ia-85380 scp that distinguished ad from controls, each individual ssf was entered into a linear regression model as explanatory variables with group as the dependent parameter.
akaike's information criteria (aics) determined how many pcs should be included to reach optimal bias-variance trade-off (burnham and anderson, 2002).
seven pcs (1, 3, 4, 5, 6, 7, 10) yielded the lowest aic value and were used to derive the scp5ia.
the degree to which each subject expressed the scp5ia was by way of the ssf5ia.
the same approach was applied to the 99mtc-exametazime spect scans.
therefore, positive and negative weights were interpreted as concurrent increased and decreased rcbf, respectively.
five pcs (1, 2, 3, 4, 12) yielded the lowest aic value and were used to generate the scprcbf that best separated ad from controls, while each subject expressed the scprcbf by their ssfrcbf.
stability and reliability of the scps were assessed by bootstrap resampling (1000 iterations), to identify areas that contributed to the patterns with high confidence.
this transforms the voxel weights of each scp into z maps, computed as the ratio of voxel weight and bootstrap standard deviation.
the z-statistic follows roughly a standard normal distribution where a one-tailed p ≤ 0.05 infers a threshold of |z| ≥ 1.64 (habeck et al., 2010).
anatomical labeling of the z maps was performed using the image visualization software “fslview” (http://fsl.fmrib.ox.ac.uk/fsl/fslview/), which contains various anatomical brain atlases from which the labels were reported from.
2.7 statistical analyses continuous variables were tested for normality using visual inspection of histograms and shapiro-wilk test.
demographic, clinical, and imaging measures were assessed, where applicable, using parametric (analysis of variance) and nonparametric χ2 tests.
correlations were performed using pearson's r coefficients.
statistical tests were interpreted as significant if p ≤ 0.05. data analysis used the statistical package for social sciences software (spss version 22.0, http://www-01.ibm.com/software/analytics/spss/products/statistics/).
3 results 3.1 subject demographics and clinical characteristics patient demographic and clinical characteristics are reported in table 1. ad subjects and controls were similar with respect to gender, although there was a small difference in age with ad patients being slightly older than controls.
as expected, ad subjects were impaired on all cognitive measures compared to controls (p < 0.001).
two patients were receiving cholinesterase treatment (donepezil, standard daily clinical dose 10 mg) (for >3 months) at the time of the study.
3.2 spatial covariance the α4β2 nachr voxel scp5ia that distinguished ad from controls is shown in fig.
1a and b. ssf5ia scores, representing the extent to which subjects expressed the topography, were higher in ad than controls (mean ± sd; ad = 9.3 ± 2.0, controls = 2.6 ± 1.4, t27 = 10.8, p < 0.001, fig.
1c).
the pattern was mainly characterized by relative decreases in α4β2 binding (blue) in basal forebrain, pedunculopontine, thalamus, limbic, parietal, and frontal regions together with relative preserved or increased binding (red) in midbrain, pallidum, cerebellum, occipital, and pre/post central gyri.
table 2 depicts details of specific regions contributing to the α4β2 disease-related pattern with high confidence (|z| ≥ 1.64, p ≤ 0.05).
the associated rcbf scprcbf that differentiated ad from controls is depicted in fig.
2a and b, where ssfrcbf scores differed between groups (mean ± sd; ad = 10.0 ± 1.9, controls = 3.2 ± 1.5, t27 = 10.6, p < 0.001, fig.
2c).
the pattern mainly comprised of relative decreased rcbf (blue) in thalamus, cingulate, parietal, and prefrontal areas with relative increases (red) in cerebellum, lentiform nucleus, lingual gyrus, and precentral regions.
table 3 depicts details of specific regions significantly contributing to the rcbf disease–related pattern (|z| ≥ 1.64, p ≤ 0.05).
relationship between scp expressions and age, mmse, camcog, camcogmemory, and camcogexec were investigated in ad.
trends were observed in camcog (r = −0.52, p = 0.03), camcogmemory (r = −0.51, p = 0.04), and mmse (r = −0.54, p = 0.03) with ssf5ia but not age and camcogexec (|r| ≤ 0.37, p ≥ 0.11).
for ssfrcbf, camcog (r = −0.47, p = 0.05) and mmse (r = −0.52, p = 0.04) correlated, while for all other measures (|r| ≤ 0.42, p ≥ 0.08).
it was evident that there was some degree of similarity between the nicotinic and rcbf patterns, supported by the significant correlations that were observed between the ssf5ia and ssfrcbf scores in controls (r = 0.61, p = 0.006) and ad (r = 0.74, p = 0.002).
we, therefore, sought to explore in a descriptive sense, regions that differed between the 2 patterns by subtraction of their respective bootstrapped spatial covariance z maps.
fig.
3 shows the difference in image (scp5ia − scprcbf), where the blue and red regions represent (z5ia − zrcbf) ≤ −2.0 and (z5ia − zrcbf) ≥ 2.0, respectively.
the difference image showed deviations in pedunculopontine nucleus, insula, anterior cingulate, putamen, thalamus, and frontal regions (blue) along with precuneus, lateral occipital, temporal, and parietal areas (red).
blue regions characterize greater negative weights in the nicotinic pattern relative to rcbf or where voxel weightings are of opposite sign (nicotinic −ve, rcbf +ve), whereas red regions describe greater positive weights in the nicotinic pattern relative to rcbf or where voxel weightings are of opposite sign (nicotinic +ve, rcbf −ve).
table 4 presents details of specific regions contributing to the difference pattern.
4 discussion we undertook a multivariate network perspective of 123i-5ia-85380 spect, a α4β2 nachr ligand in ad.
we derived disease-related α4β2 nachr and rcbf patterns of spatial covariance, which implies the presence of several dysfunctional cholinergic and perfusion networks in ad.
these findings represent the first attempt to differentiate ad from controls through spatial covariance analysis of cholinergic nicotinic receptor activity and/or availability, and follow our multivariate assessment of m1/m4 machr binding in ad (colloby et al., 2015).
the nachr covariance pattern comprised of decreased and preserved and/or increased activity in a number of concomitant brain areas.
the covariant negative-weighted pattern converged on various subcortical and neocortical regions, implicating a number of cholinergic networks.
in particular, the basal forebrain–neocortex and hippocampus system appeared to be affected, and this network is widely recognized as a significant contributor to memory and learning processes.
the brainstem system which may mediate the sleep-wake cycle also appears to be involved with relative reduced uptake in pedunculopontine nucleus and thalamus.
this observation is in keeping with clinical observations that sleep-wake disturbances are highly prevalent and often a disabling feature in ad (lim et al., 2014), although in the present study we did not have data on the nature or severity of any sleep disturbances in our patient group to clarify any specific clinical relationships.
we also observed a relative decreased binding which mapped onto dmn hubs, namely, medial prefrontal, posterior cingulate, precuneus, and inferior parietal.
this network is active during rest and deactivates during goal-directed behaviors (raichle et al., 2001), where evidence has shown reduced dmn activity in ad (greicius et al., 2004, simic et al., 2014) and its contribution to cognitive decline (seeley et al., 2009).
one study reported convergences of amyloid deposition, metabolic disruption, and atrophy of the dmn in ad (buckner et al., 2005), suggesting that the relative decreased pattern within this network could be in fact characterizing these pathological and/or functional deficits, although an element of concomitant dmn cholinergic dysfunction cannot be excluded.
reduced dmn activity of nachrs was consistent with our previous findings of reduced m1/m4 machr expressions within similar regions (colloby et al., 2015), highlighting the potential role of both types of receptors in ad and that the cholinergic system may have a more fundamental role in the normal functioning of the dmn.
other mappings onto established resting-state networks, included the anterior insula and anterior cingulate, which are key nodes of the “salience network,” for initiation of cognitive control and switching networks to aid access to working memory and attention resources (menon and uddin, 2010, seeley et al., 2009).
networks involving the insula have also been shown to play a role in episodic memory (xie et al., 2012).
furthermore, regions also mapped onto the papez circuit, a limbic network incorporating the thalamus, hippocampus, and cingulate cortex (papez, 1937).
its function lies in emotional processing and memory, where numerous studies have demonstrated its dysfunction and atrophy in ad (allen et al., 2007, jones et al., 2006, smith, 2002).
the associated rcbf pattern largely comprised of relative decreases in thalamus, cingulate, parietal, and prefrontal areas with relative increases in cerebellum, lentiform nucleus, lingual gyrus, and precentral regions, indicating impairment in a number of functional networks.
regions that were concomitantly reduced appear to involve hubs of the dmn and frontoparietal attention (inferior parietal, dorsolateral prefrontal cortex) networks (markett et al., 2014); the latter finding chimes with a recent study depicting dorsal and ventral attention systems dysfunction in ad and amnestic mild cognitive impairment (zhang et al., 2015).
the covariant pattern was also broadly consistent to previous spatial covariance studies in ad using h215o positron emission tomography (scarmeas et al., 2004) and arterial spin labeling perfusion magnetic resonance imaging (asllani et al., 2008).
differences in results between these studies were likely attributed to variations in image modality and/or in ad populations.
as an exploratory analysis, we examined correlations between the cholinergic and perfusion covariance pattern expressions and measures of cognition in ad.
although results were not corrected for multiple tests, negative trends were observed with camcog and mmse scores, suggesting the cholinergic and/or perfusion patterns and the various networks they represented were similarly related to global cognition and/or dementia severity.
memory scores (camcogmemory) only appeared to be associated with the cholinergic pattern which is not unexpected given the observed deficits to spatial networks involving the medial temporal lobe structures, and the putative role of acetylcholine on learning and memory (hasselmo, 2006, mcgaughy et al., 2000), as well as the established therapeutic efficacy of cholinesterase inhibitors in ameliorating cognitive symptoms in ad (zemek et al., 2014).
although our ad group was relatively small, these results highlight that a larger-scale covariance study may be useful to investigate specific correlates between the clinical phenotype of ad and cholinergic network dysfunction.
although we used stratified bootstrap resampling to verify the stability and reliability of the scps, the results were nonetheless obtained from small samples and as a consequence may not be generalizable and as such were a major drawback of this study.
another study limitation was a minority of autopsy-confirmed diagnoses and a relatively moderate demented patient group.
it was also difficult to establish whether the observed cholinergic networks were attributed exclusively to changes in nicotinic receptor expression or to some extent by the functional rcbf changes.
although descriptive and not rigorously inferential, we investigated differences between the nicotinic and rcbf patterns in order to identify areas of relative variation.
the deviation map suggests that brainstem system and salience networks were perhaps more associated with nicotinic receptor expression, whereas for dmn and papez circuits suggest that this was less clear.
receptor availability and rcbf were also influenced by atrophy and partial volume effects, so both types of scans were likely to be equally affected by neural degeneration.
thus, common regions of relative decreased uptake that are susceptible to ad pathology may indicate atrophic effects rather than receptor or functional changes.
in addition, although there was a small age difference between the groups, there were no significant correlations between age and the nicotinic and rcbf subject scores in controls or ad and therefore, unlikely to affect the discriminant patterns.
strengths of this study were in examining ad patients that were mainly free from any cholinergic medications as well as having both nicotinic and perfusion spect scans available for all subjects.
5 conclusions the multivariate perspective provides further insights into the pathophysiological changes in ad.
the scp not only suggests basal and brainstem cholinergic system deficits, but dmn, salience and papez cholinergic circuits may also be vulnerable, and that the cholinergic system might have a more fundamental role in the normal functioning of these networks in ad.
future studies could examine the cholinergic network profiles that are associated with positive treatment outcomes from therapies aimed at improving cholinergic neurotransmission.
disclosure statement dr colloby, dr field, and professor wyper report no disclosures.
professor o'brien has been a consultant for ge healthcare, lilly, bayer healthcare, taurx, and nutricia and has received honoraria for talks from ge healthcare, lilly, and novartis.
dr taylor has been a consultant of lundbeck and received honoraria for talks from ge healthcare and flynn pharmaceuticals.
@highlight
alzheimer's disease (ad) is characterized by widespread degeneration of cholinergic neurons, particularly in the basal forebrain.
however, the pattern of these deficits and relationship with known brain networks is unknown.
in this study, we sought to clarify this and used 123i-5-iodo-3-[2(s)-2-azetidinylmethoxy] pyridine (1235ia-85380) single photon emission computed tomography to investigate spatial covariance of α4β2 nicotinic acetylcholine receptors in ad and healthy controls.
thirteen ad and 16 controls underwent 1235ia-85380 and regional cerebral blood flow (99mtc-exametazime) single photon emission computed tomography scanning.
we applied voxel principal component (pc) analysis, generating series of principal component images representing common intercorrelated voxels across subjects.
linear regression generated specific α4β2 and regional cerebral blood flow covariance patterns that differentiated ad from controls.
the α4β2 pattern showed relative decreased uptake in numerous brain regions implicating several networks including default mode, salience, and papez hubs.
thus, as well as basal forebrain and brainstem cholinergic system dysfunction, cholinergic deficits mediated through nicotinic acetylcholine receptors could be evident within key networks in ad.
these findings may be important for the pathophysiology of ad and its associated cognitive and behavioral phenotypes.
