what was known?
atopic dermatitis is a chronic relapsing inflammatory skin disorder seen more commonly in children than adults.
atopic dermatitis (ad) or atopic eczema is an itchy, inflammatory skin condition with a predilection for the skin flexures.
it is characterized by poorly defined erythema with edema, vesicles, and weeping in the acute stage and skin thickening (lichenification) in the chronic stage.
the term adult-onset ad was coined by bannister and freeman in 2000[1] when they observed that 10% of the cases seen in a hospital setting were adults.
after the initial description, few reports and series have been reported from other parts of the world.
however, there are no clinicoepidemiological studies from india.
it is probably due to lack of the concept of adult-onset ad.
it is also due to the fact that clinical picture of ad in adults is not classical in the sense that only the flexures are involved.
different patterns of involvement and atypical morphologies such as nummular (discoid), prurigo-like, follicular, and seborrheic dermatitis may be present.
[2] erythroderma is commonly seen, and flexural lichenification is uncommon.
[34] with the increase in the prevalence of ad over the past few decades, the prevalence of adult-onset ad has also increased, and its prevalence ranged from 1% to 3% in different populations.
studies from singapore, australia, and nigeria reported that 13.6%, 9%, and 24.5%, respectively, of their ad patients had onset after 18 years of age.
[567] even though there are a number of reports of adult-onset ad, dermatologists are more comfortable in making a diagnosis of allergic contact dermatitis or airborne contact dermatitis (abcd) rather than adult-onset ad in an adult coming with an eczematous condition.
it is important to remember that the diagnostic criteria of hanifin and rajka are the gold standard and should be used to diagnose ad in adults.
abcd or parthenium dermatitis is often indistinguishable from adult-onset ad as it also involves face, neck, and flexures.
in such a scenario, patch testing is helpful in excluding the diagnosis of abcd.
it should, however, be kept in mind that ad is a risk factor for allergic contact sensitization, and contact allergy increases with age in atopic dermatitis.
extrinsic ad is more common in adults than children, and both immediate and delayed hypersensitivity play a role in parthenium-associated ad.
in some of these patients with positive parthenium contact sensitivity, the disease persists despite the removal of allergen, and it can also be hypothesized that these may be atopic dermatitis where inhalation of aeroallergens has exacerbated the ad or it may be an apparent superimposed contact dermatitis.
in a study from postgraduate institute of medical education and research (pgimer), chandigarh, 18% of the adult patients referred to contact dermatitis clinic over a period of 1 year fulfilled the hannifin and rajka criteria for ad.
a total number of 36 cases of adult ad (22 women and 14 men) were identified.
five (13.8%) of them were classified into the intrinsic group (non-ige allergic) and 31 (86.1%) were classified into extrinsic group (ige-allergic).
all these patients were patch test-negative to the indian standard series; they had a long history (>3 years) of lesions and had elevated serum ige levels.
facial and hand dermatitis were the two most common findings in these patients.
it is possible that smoking is an important factor in adult-onset ad.
lee ch et al.
[8] suggested that childhood exposure to passive smoking or environmental tobacco smoke increases the risk factor for ad in adulthood by three times, and the association is cumulative.
they observed that patients with ad were significantly more likely to be current or ever smokers than individuals without ad at 53% versus 18%.
adult ad tends to persist, but its severity decreases over the years.
head and neck eczema, high values of serum ige, and a long duration of eczema are poor prognostic factors predicting eczema persisting for longer period.
the increased prevalence of ad in children and the observation that ad in most adults continues for many years suggest that it is very likely that we will be seeing many older patients with ad in the future.
treatment of adult-onset ad is essentially the same as childhood ad and involves appropriate skin care, moisturization, and avoidance of triggers.
in adult ad, complex psychoneuroimmunological interactions assume a major role in initiating and perpetuating ad.
stress reduction is, therefore, important.
among topical therapy, corticosteroids are number one.
corticosteroids have immunosuppressive, anti-inflammatory, antiproliferative, and vasoconstrictive effects that have been shown to reduce itching and improve the appearance of skin and quality of life.
these are the first line of therapy.
when choosing topical steroids, their potency and vehicles (ointments, creams, lotions, or foams) should be chosen depending on the sites and types of eczema.
once-daily application in the evening and continued use until complete resolution of lesions is a preferred method.
topical antibiotics, i.e., fusidic acid and mupirocin, are indicated for the treatment of a monofocal bacterial superinfection (2–3 applications/day for 7–10 days).
topical calcineurin inhibitors are the second-line therapy for ad.
tacrolimus 0.1% formulation is used for adult ad.
topical tacrolimus is more effective than pimecrolimus in adults with moderate to severe ad.
in patients with extensive and severe dermatitis, topical therapy may be insufficient.
such patients require either phototherapy or systemic therapy.
phototherapy is a good option but can be time consuming and may interfere with daily routine.
systemic immunosuppressive agents are commonly prescribed for adults with severe and extensive disease.
systemic corticosteroids are the most frequently prescribed.
however, their side effects should be watched as some of the elderly patients with ad may be hypertensive or diabetic.
most severely affected patients show responses to cyclosporine, azathioprine, mycophenolate mofetil, or methotrexate.
recently, low-dose methotrexate has been found to be effective in adult-onset ad.
[9] adult-onset ad is an important subgroup of ad with a broad range of onset varying from 18 to 71 years.
its recognition from other eczematous disorders is important.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
what is new?
there is increase in the prevalence of adult atopic dermatitis.
clinical features of adult onset atopic dermatitis are not classical and present with atypical morphology.
@highlight
adult-onset atopic dermatitis is still an under recognized condition as there are only few studies regarding this entity.
as compared to childhood onset atopic dermatitis, clinical features of adult onset atopic dermatitis are still not categorized.
adult atopic dermatitis can present for the first time in adult age with atypical morphology or may progress from childhood onset.
this article reviews the characteristic clinical features of adult atopic dermatitis, associated risk factors and management.
