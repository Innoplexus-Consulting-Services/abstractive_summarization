introduction rhabdomyolysis (rhabdo - striated, myo - muscle, lysis - break down) refers to clinical and biochemical syndrome due to skeletal muscle injury and spillage of large quantities of intracellular contents in to circulation.
[1] there are more than 100 causes with different mechanisms that can damage the skeletal muscle leading to rhabdomyolysis.
the incidence varies with underlying cause and increased incidence seen after earth quake and war zones.
exertional rhabdomyolysis is seen in weight lifting, marathon race, and military basic training.
[2] nontraumatic rhabdomyolysis is 5 times more common than traumatic rhabdomyolysis.
[3] knochel called exercise induced rhabdomyolysis as white collar rhabdomyolysis because of increased incidence noted in educated and professionals who are not accustomed to strenuous exercise.
[4] it may present as asymptomatic illness with elevated creatine kinase to life-threatening complications such as cardiac arrhythmias, cardiac arrest, compartment syndrome, disseminated intravascular clotting, and acute kidney injury (aki).
[5] myalgia, weakness, and tea-colored urine are triad symptoms of rhabdomyolysis.
muscles of lower back, lower limbs (postural muscles) are affected.
50% of the patients may not complain myalgia or weakness.
[5] the only clue is tea-colored urine.
[6] the diagnosis is based on the inciting event, myoglobinuria, and serum creatine kinase levels more than 5 times the reference value.
[57] case report a 26-year-old female presented with history pain in the back, lower limbs, decreased urine output, and dysuria of 3 days duration.
two days before the present complaints, she had performed sit-ups while holding her ears (super yoga brain) for 108 times in a temple.
on examination, she was afebrile, no icterus, pulse rate 120/min, blood pressure 100/80 mmhg.
marked tenderness over back and lower limbs present.
systemic examination normal.
investigations revealed myoglobinuria, total leukocyte count 9.3 × 103 /μl, hemoglobin 11.5 g/dl, platelet count 283 × 103 /μl, urine sodium 48 meq/l, fena 2.08, tests for hiv, hepatitis b and c are negative.
urine and blood cultures were negative.
electrocardiogram showed sinus tachycardia.
computer tomogram of the abdomen showed normal sized kidneys and free fluid in the pelvis.
rhabdomyolysis diagnostic profile, renal parameters, and blood gas analyses are shown in tables 1–3].
table 1 rhabdomyolysis diagnostic profile table 2 renal parameters table 3 arterial blood gas analyses discussion the national hospital discharge survey report 26,000 cases of rhabdomyolysis every year in usa.
[8] among 337 military recruits olerud et al.
noted rhabdomyolysis in 40% of cadets during first 6 days of intense physical training.
[9] excessive physical exertion of any kind can cause exertional rhabdomyolysis, especially in untrained individuals in hot or humid climate and accounts for one-third of all causes of rhabdomyolysis.
[710] incidence of aki is less (19.1%) in exertional rhabdomyolysis compared to rhabdomyolysis due to other causes (34.2%).
[10] rhabdomyolysis accounts 7-10% of all causes of aki in usa but may be as high as 50%.
[11] a variety of insults with different pathogenic mechanisms are involved in muscle injury but the final common pathway is increased intra cytoplasmic calcium which activates proteases, phospholipase, nucleases and release of oxygen free radical causes myocyte disintegration[12] and spillage of intracellular contents in to circulation resulting in electrolytes disturbances, metabolic acidosis, hypotension, clotting abnormality, and aki.
hyperkalemia is not consistently present in nontraumatic rhabdomyolysis.
[12] traumatic and nontraumatic rhabdomyolysis are the leading causes of aki.
[13] myoglobinuria is a key player in the complex pathogenesis of aki only in presence of hypovolemia, hypotension, and aciduria (nephrotoxic factors).
[13] sinert et al.
reported that aki is not observed when nephrotoxic cofactors are absent.
[14] the 3 different pathological mechanisms involved in the development of aki are: (1) renal hypo perfusion resulting from hypovolemia-induced renal vasoconstriction and myoglobin scavenging of nitric oxide.
(2) heme protein exerts direct toxicity on tubular epithelial cells and free radical release by myoglobin causes oxidative injury to the tubular epithelial cells.
(3) the precipitated myoglobin, tamm–horsfall protein, uric acid crystals in presence of acidic urine causes tubular obstruction and decreases glomerular filtration rate.
[15] eccentric exercise causes more muscle injury than concentric exercise.
[15] this patient performed sit-ups for 108 times which is a form of eccentric exercise that has caused severe muscle injury.
she presented with typical features and investigations revealed myoglobinuria, hypocalcemia, elevated serum creatine kinase, phosphate, uric acid, liver enzymes, lactate dehydrogenase, renal parameters and fena >1, metabolic acidosis confirming exercise induced rhabdomyolysis and aki.
in this case serum potassium is normal.
patient was taken up for hemodialysis on alternate days initially for 2 weeks and then thrice a week for another 2 weeks.
patient's urine color, output, and all the deranged parameters returned to normal by 4 weeks.
conclusion rhabdomyolysis is not an uncommon condition and the gravity of this condition is not appreciated and adequate attention is not given.
both traumatic and nontraumatic rhabdomyolysis causes aki.
it has characteristic clinical, laboratory features but high index of suspicion is important for early diagnosis.
history of inciting event, elevated serum creatine kinase levels more than 5 times the reference value, myoglobinuria are confirmatory for diagnosis of rhabdomyolysis.
early aggressive fluid resuscitation is crucial to prevent life-threatening complications.
the renal outcome depends on quick and aggressive management but not on creatine kinase levels.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
rhabdomyolysis is a clinical syndrome resulting from the disintegration of muscle cell and spillage of toxic intracellular contents into circulation.
strenuous, unaccustomed exercise leads to exertional rhabdomyolysis and cause aki.
we report a 26-year-old female who developed white collar rhabdomyolysis with aki after performing sit-ups (super yoga brain) for 108 times in temple.
she was managed with hemodialysis and supporting therapy.
she made a full recovery after 4 weeks.
awareness of this condition and early diagnosis is highlighted.
