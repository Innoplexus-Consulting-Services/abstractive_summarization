introduction surgical management of anterior cruciate ligament (acl) deficient knee has progressed from the earlier primary repair to extra capsular augmentation to acl reconstructions (aclr) utilizing tendon grafts.
the autograft arthroscopic single-bundle surgery is considered the “gold standard” for aclr.1 femoral tunnel placement has been considered to be the most critical step in aclr.
it has been postulated that traditional single-bundle transtibial (tt) reconstructions have placed grafts in an isometric location relative to the true acl insertion sites.23 recent studies advocate the use of an accessory medial portal for more accurate placement of the femoral tunnel.3 tompkins et al.
reported that accessory medial portal technique placed the femoral tunnel close to the native femoral footprint, as compared to the tt technique.
anatomic placement of the graft closer to the femoral footprint has been shown to enhance the rotational stability of the knee.23 the accessory anteromedial portal (aamp) is located approximately 2.5 cm medial to the standard anteromedial (am) portal near the anterior edge of the tibial collateral ligament.4 the aamp approach allows the femoral tunnel to be drilled in the correct angle with avoidance of injury to the cartilage of the medial femoral condyle.
this will allow better visualization of both tibial and femoral anatomic insertions of acl and prevent nonanatomical tunnel position during aclr.2 the potential advantages of a separate aamp drilling are that the femoral and tibial tunnels are placed independently of each other.
the femoral tunnel when drilled with knee in hyperflexion reduces the risk of posterior blow out.
the femoral tunnel is placed more anatomically on the acl femoral insertion site.
the aamp allows the femoral tunneling to be performed without interference with visualization of the lateral femoral condyle by using am portal as the viewing portal.5 it also allows the femoral tunnel to be created close to the lateral wall of the notch by adjusting the obliquity compared to the am portal.5 in a biomechanical study on cadavers loh et al.
concluded that horizontal drilling of femoral tunnel of the single-bundle aclr had better rotatory stability when compared to the almost vertical position of femoral tunnels.6 we hypothesized that there will be no correlation between the tunnel positions placed using an aamp and the functional outcome after aclr.
materials and methods 41 patients who underwent anatomic aclr between 2011 and 2013 in our department were included in this prospective cohort study.
our inclusion criteria were patients between the age group 18–50 years with isolated acl injuries and acl tears with associated meniscal injuries.
we excluded patients with associated posterior cruciate ligament injury, and medial and lateral collateral ligament injuries, acl reinjuries; patients with periarticular fractures or cartilage injuries.
associated meniscal tears were balanced or repaired.
the minimum time duration between injury and reconstruction was 1 month.
the study was approved by the institutional ethics committee.
informed and written consent were taken from individual patients before participation in the study.
all the patients were operated by two senior authors (r.s and g.s).
the primary outcome involved the documentation of femoral and tibial tunnel positions and tunnel diameters with volume rendering imaging using a three-dimensional computed tomography (3d-ct) at the end of 1 year (bright speed ge-16 slice) and software (ge workstation volume viewer 4.3, voxtool 6.11.2).
it was decided to do ct evaluation at end of 1 year as tunnel widening affecting the tunnel diameter is a well known phenomenon.
however, we did not evaluate its effect on functional outcome measures.
the tunnel position evaluations from the ct images were performed by an independent observer specializing in radiodiagnosis who was not aware of the surgical technique specific to drilling of the tunnels.
as a secondary objective, functional outcome measures were documented; which included pre- and postoperative lysholm and international knee documentation committee (ikdc) subjective scores documented by an orthopedic surgeon who was not involved in the surgical procedure.
postoperatively, tunnel positions were compared with ikdc (subjective) and lysholm score using pearson's correlation coefficient.
the results were considered statistically significant if the p value was <0.05.
the statistical data were analyzed using spss version 18 software spss inc. (chicago, united states).
operative procedure ipsilateral side semitendinosus-gracilis tendons were harvested, and quadrupled graft was prepared and mounted on a tension board.
the knee was positioned between 100 and 110° flexion and through the aamp, a guide wire was passed into the intercondylar notch as close to the femoral footprint of native acl as possible.
when the femoral footprint was not visible, the resident's ridge was used as a landmark to place the femoral tunnel.7 after confirming the guide wire position through the viewing portal, the femoral tunnel was drilled via the aamp.
the length of the femoral tunnel was measured with depth gauge, and the femoral tunnel was drilled according to the measured thickness of the harvested graft.
a vicryl number 1 suture loop was placed through the aamp to the femoral tunnel and secured over the knee with a hemostat.
as a standard procedure, the tibial tunnel was drilled with the help of a tibial guide set at 55° placed at the tibial footprint of acl.
a depth gauge was used to retrieve one end of the vicryl loop into the tibial tunnel, the graft was then shuttled through the tibial and femoral tunnels with the help of the vicryl loop.
on femoral side, endobutton (smith and nephew, usa) was used for fixation while the fixation on the tibial side was achieved with bio absorbable screw (arthrex, usa).
postsurgery, a supervised rehabilitation program was prescribed; it involved early weight bearing, early emphasis on extension range of movement, and early return to functional activities.
the rehabilitation program was identical for all patients except in patients with meniscal repairs where appropriate range of movement and weight bearing restrictions were applied.
clinical outcome measures included lachman test, anterior drawer test, pivot shift test, ikdc score (subjective), lysholm scoring.
functional comparison of pre- and postoperative ikdc (subjective), and lysholm score was done at end of 1 year.
at 1 year followup, all patients underwent ct of the reconstructed knee and tunnel positions were calculated using 3d-ct with volume rendering image technique (ge workstation volume viewer 4.3, voxtool 6.11.2 ge healthcare, little chalfont, united kingdom).
although the quadrant method described by bernard et al.8 is the ideal method of tunnel position assessment, we employed a method where in the tunnel positions are quantified in absolute numbers in millimeters from a fixed bony landmark.
the position of the tibial tunnel was calculated based on the distance from the anterior margin of the tibial plateau and the center of the tibial tunnel [figure 1].
the position of the femoral tunnel was calculated based on the distance from the posterior lip of the medial surface of the lateral femoral condyle to the center of the femoral tunnel in a midsagittal ct section.
similarly, the distance from the inferior lip of the medial surface of the lateral femoral condyle to the center of femoral tunnel in a midsagittal ct section was taken [figure 2].
figure 1 tibial tunnel assessment in our study figure 2 femoral tunnel assessment in our study results there were a total of 34 male and 7 females who fulfilled the inclusion criteria.
the mean age of the subjects was 31.34 years (sd = 7.53).
the average tibial tunnel distance was found to be 15.5 mm (sd = 2.52) from the anterior margin of the tibial plateau.
the average femoral tunnel distance was found to be 14.33 mm (sd = 2.66) from the inferior margin or border of the medial surface of lateral femoral condyle and 13.72 mm (sd = 2.87) from the posterior margin of the medial surface of lateral femoral condyle.
the average tibia tunnel diameter was found to be 7.9 mm (sd = 0.72), and average femoral tunnel diameter was 8.6 mm (sd = 1.07) [table 1].
table 1 tunnel position and diameter in mm we further examined the subset of 16 patients who had a postoperative ikdc subjective score >80.
the average tibial tunnel distance was found to be 14.4 mm (sd = 1.6) which indicated a better ikdc score with decreased tibial tunnel distance from the anterior margin of the tibial plateau.
similarly, average tibial tunnel distance for subset of 5 patients with ikdc subjective score <65 was found to be 16.28 mm (sd = 3.17).
however, both the observations were not statistically significant.
the lysholm score preoperatively was calculated based on set questions and points given against each of them.
the scores were graded from poor to excellent based on a predescribed criteria.9 scores <65 were graded poor.
scores of range 65–83 and 84–90 were graded fair and good, respectively.
scores >90 were excellent.9 the mean preoperative lysholm score for these subjects were 74.6 (sd = 7.6).
however, postoperatively, the mean lysholm score improved to 81.1 (sd = 7.5).
while most patients were classified under fair grade based on their lysholm scores both pre- (33 patients) and postoperatively (28 patients), the number of patients with good to excellent grade was better postoperatively (4 patients preoperative vs. 13 patients postoperative).
the pre- and postoperative scores were compared using paired t-test, and a statistically significant difference in the scores was observed with a p < 0.001 [table 2].
table 2 comparison of pre-and post-operative international knee documentation committee and lysholm score similarly, the ikdc subjective scores were calculated preoperatively and postoperatively and was compared using paired t-test.
the mean ikdc score preoperatively was 63.48 (sd = 9.78).
the mean postoperative ikdc score was 75.9 (sd = 8.8).
the difference in mean was 12.5 with a 95% confidence interval of 9–16.
the comparison of pre- and postoperative ikdc score was statistically significant with a p < 0.001 [table 2].
discussion freddie et al.1 and lee et al.10 reported better functional outcomes with independent drilling of the femoral tunnel.
our study also revealed good functional outcomes following aclr using aamp in terms of ikdc and lysholm scores.
this could be attributed to the independent drilling of the femoral tunnel.
however, in absence of comparative group employing a different technique for tunnel placement, the improvements in functional outcomes could be attributed to other factors as well.
we evaluated the tibial and femoral tunnel positions of the reconstructed acl in our subjects.
our study had the center of the tibial tunnel as 15.5 mm (sd = 2.52) from anterior tibial margin.
tunnels placed close to the native footprints of the acl are considered ideal.
a previous study that investigated the acl foot prints using 3d-ct found the tibial origin of acl to vary between 9.3 and 13.1 mm as measured from tibial inter tubercle ridge to the anterior fibers of the acl.11 while our values are found to be different from the above study, the difference in values could be attributed to the differences in reference point of measurements.
we measured the tibial foot print of acl from the anterior tibial margin as we found this reference point to be consistently identifiable each time.
stäubli et al.
also used anterior tibial margin as the reference point and found the anterior limit of acl foot print to be at an average of 15.2 mm in men and 13.4 mm in women12 which closely matches the findings of our study.
lee et al.
conducted an in vivo 3d evaluation of tunnel position after single bundle aclr using aamp.10 the quadrant method for evaluation of height and depth of the tunnels was used in the above study and the center of the tibial tunnel in their study was located at 44.6% ± 2.5% from the anterior margin and 48.0% ± 3.0% from the medial margin.
in a recent study, yang et al.
found the tibial tunnel to be located at 45.43% ± 4.81% from the anterior margin of the tibia.13 while both the above studies reported similar results with regard to the depth of tibial tunnel positions, we could not compare these results with our study as we did not employ the quadrant method to describe the tunnel position depth.
an ideal tibial tunnel should be at the center of the native acl footprint.
despite the efforts to place the tibial tunnel in this ideal position, it is possible that the tibial tunnel could be placed either anterior or posterior in relation to the native footprint.
in our study, we observed an inverse relationship between the tibial tunnel distance as measured from anterior margin of the tibial plateau and ikdc scores; anteriorly placed tibial tunnels within the anatomical tibial footprint site were associated with better ikdc scores.
in a biomechanical study investigating the effects of tibial tunnel positions, bedi et al.14 demonstrated that anterior positioning of the tibial tunnel either in the over the top position or at the anterior foot print produced favorable kinematics than posterior positioning of the tibial tunnel.
in a recent anatomical study, tensho et al.
explored the relationship of tibial footprint with surrounding bony landmarks and bony prominences.
findings of the study suggested that the tibial footprint was present as an oval bony prominence in 58% and triangular in 42% of the knees investigated; hence, the authors recommended that the tibial bone tunnel could be placed anteromedially within the anatomic footprint during aclr.15 while the above studies could possibly explain the positive functional outcomes in ikdc scores with an anteriorly placed tibial tunnel in our study, our intention was to place the tibial tunnel to the center of the native acl foot print in all the cases.
while there may be an anatomical or biomechanical advantage in terms of joint stability for an anteriorly placed tibial tunnel, clinical studies have reported complications such as graft impingement, loss of knee extension, and anterior knee pain with an anteriorly placed tibial tunnel.1617 the am portal technique allows more anatomic femoral tunnel position when compared to the tt technique.18 in a single-bundle aclr as the one we used in our study, the goal is to place the tunnels at center of the acl footprints which is assumed to be located in the middle between the am bundle and the posterolateral (pl) bundle.
in our study, the femoral acl center was found to be 13.72 mm (sd = 2.87) from the posterior cartilage margin and 14.33 mm (sd = 2.66) from the distal cartilage margin.
in a recent cadaveric study, ziegler et al.
quantified the central points of attachment of acl and its bundles in relation to arthroscopically pertinent bony and soft tissue landmarks of the knee.19 the above study found overall acl attachment center to be 14.7 mm proximal to the distal cartilage margin with the am bundle femoral attachment center at 18.6 mm and the pl bundle attachment center 10.7 mm proximal to the distal cartilage margin.
while the findings of our study are in agreement with ziegler et al.
with regard to this measurement, it would be useful to know the center of femoral tunnel from multiple land marks as employed in the above study.
quadrant method is the most commonly used method in the literature to assess femoral tunnel position.8 in a recent study, lee et al.
assessed the femoral tunnel drilled utilizing aamp and reported the femoral tunnel to be at 26.7% ± 2.7% from the deepest subchondral contour of the lateral femoral condyle and at 30.0% ± 2.9% from the blumensaat's line.10 their values were in agreement with most of the studies that used the quadrant method to quantify the femoral tunnels.2021 while we could infer that the use of accessory am portal to drill the femoral tunnel could have resulted in similar placement of the tunnels, a direct comparison of the results is not possible since we did not use the quadrant method to quantify the tunnels.
our study did not find any significant correlations between the position of femoral tunnels drilled utilizing the aamp and the functional outcomes over 1-year followup.
various studies report excellent short term outcomes as measured by ikdc, lysholm, and knee stability tests with anatomical tunnels placed with am portal technique.2223 however, there is still debate as to whether this changes the long term clinical outcomes for the patients, as a recent cohort study with 5 years followup found no significant difference in terms of long term function between tt and am portal drilling of the tunnels.24 several methods of evaluation of tunnel positions have been described in literature which includes the quadrant method,8 watanabe method,25 and takahashi's method.26 we employed measuring the tunnel position in millimeters from identifiable bony landmarks rather than expressing it as a ratio.
this made direct comparison of our results with several existing literature difficult.
however, we believe that employing bony landmarks as reference points to quantify tunnel positions could be more useful clinically and easy to reproduce intraoperatively.
our study had the following limitations; relatively small sample size, aclr done by two senior arthroscopic surgeons.
subjects were from different socioeconomic strata with different activity levels which would affect the ikdc and lysholm scores.
the followup was for a limited period (1 year).
conclusion our study found that aamp technique could be used to place the femoral tunnel close to the center of the native acl foot prints as documented by 3d-ct; however, the influence of this tunnel placement on long term functional outcomes of aclr needs to be assessed on a large cohort of patients.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
background: an accessory anteromedial portal (aamp) has been shown to be effective in placing an anatomically ideal femoral tunnel.
it is well known that this is due to the independent femoral drilling which is possible with the aamp.
however very little is known regarding the significance of this reconstruction technique in influencing the functional outcomes of anatomic anterior cruciate ligament reconstruction (aclr).
this study documents the influence of tibial and femoral tunnel positions on functional outcomes of anatomic aclr using the aamp.
materials and methods: 41 patients who underwent anatomic aclr between 2011 and 2013 were included in this prospective cohort study.
the primary outcome involved the documentation of femoral and tibial tunnel positions with volume rendering imaging using a three-dimensional computed tomography (3d-ct) done at the end of 1 year.
the tunnel position evaluations from the ct images were performed by an independent observer specializing in radiodiagnosis.
functional outcome measures included preoperative and postoperative lysholm and international knee documentation committee (ikdc) scores (subjective) documented by an independent investigator who was not involved with the surgical procedure, at the end of 1 year.
results: the minimum followup was 1 year.
all patients achieved good clinical and functional outcomes postoperatively with no reported complications.
tunnel position evaluations with 3d-ct revealed the average tibial tunnel distance to be 15.5 mm (standard deviation [sd] =2.52) from the anterior border of the tibial plateau and the average femoral tunnel distance to be 14.33 mm (sd = 2.6) from the inferior margin of the medial surface of lateral femoral condyle and 13.72 mm (sd = 2.8) from the posterior margin of the medial surface of lateral femoral condyle.
the average tunnel diameters were found to be 7.9 mm (sd = 0.72) for the tibial tunnels and 8.6 mm (sd = 1.07) for the femoral tunnels.
statistically significant correlation between the tibial tunnel distance and the ikdc scores with anterior placement of tibial tunnel were found; however, no such statistical relationship were found between the femoral tunnel positions and the functional outcome measures.
conclusion: aamp gives an ideal approach to drill the femoral tunnel independently.
however, the influence of this tunnel placement on long term functional outcomes of aclr needs to be assessed on larger cohort of patients.
