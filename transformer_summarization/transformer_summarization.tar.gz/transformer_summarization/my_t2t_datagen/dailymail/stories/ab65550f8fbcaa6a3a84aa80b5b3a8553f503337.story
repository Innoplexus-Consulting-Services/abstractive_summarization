1. introduction the atmospheric boundary layer (abl), an atmospheric region near the earth’s surface, is affected by surface forcing, ranging from 100 m to a few kilometers and plays an important role in the exchange of matter and energy between the surface and the free atmosphere [1].
the top of the boundary layer exhibits a blocking effect on surface pollutant dispersion, resulting in high concentrations of near-surface contaminants [2,3,4].
therefore, an accurate study of the abl height on diurnal, seasonal, and inter-annual timescales is significant for the study of air quality, climate, and weather forecasts [5,6].
however, the abl structure is affected by topography [7], surface, season, day, night, and weather [8].
moreover, the nocturnal urban boundary layer is difficult to measure because the urban heat island delays surface cooling [9,10].
several tools, such as radiosonde (rs) [8,11], microwave radiometer [12,13], and light detection and ranging (lidar) [14,15,16], are applied to estimate the abl height (ablh).
rs can accurately measure the profiles of moisture and temperature.
however, sounding balloons are costly and typically launched only twice a day [17].
a microwave radiometer can also obtain the profiles of moisture and temperature, but has a low vertical resolution.
an elastic backscatter lidar exhibits high spatial and temporal resolution and is widely used in research of atmospheric aerosol, air pollutant, atmospheric composition, and cloud [17,18,19,20].
continuous elastic backscatter lidar measurements with high time resolution are employed to characterize the ablh.
numerous papers reported lidar observations of processes in the ablh [6,14,21].
yan et al.
[22] shows that mixed layer depth is driven by the convective air motions and strongly correlated with the aerosol diurnal changes which tend to fall during the night and rise during the day by using an eye-safe micro-pulsed mie-scattering lidar system.
the relationships between ablh and air pollution and between ablh and weather conditions in china have been the focus of studies in the past decade [23,24].
kong and yi [25] suggest that the seasonal behavior of the surface fine particle concentration mainly depends on the seasonal variation in available volume (determined by the ablh) for aerosol dispersion.
the relationship between the daytime ablh and the near-surface thermodynamic parameters has also been assessed; such a relationship determines meteorological processes governing the daytime ablh variability [26].
however, these studies emphasize the abl during the day.
therefore, the nocturnal boundary layer height (nblh) should be analyzed in a particular region, especially if it is an urban zone with a large population.
in this study, an elastic backscatter lidar system for long-term nblh detection is operated in wuhan from 5 december 2012–17 june 2016. three typical methods, namely, ideal profile fitting (ideal), gradient (grad), and wavelet covariance transform (wct) methods, are applied to evaluate nblh with vertical range-corrected signal (rcs) measured by an elastic lidar.
the influences of near-surface parameters (e.g., sensible heat flux (shf), temperature, wind speed, and relative humidity (rh)) on nbl variability are assessed.
moreover, we investigate the influence of nblh variation on surface particulate matter (pm).
2. experimental site and methods 2.1. experimental site and meteorological data wuhan is the largest, densely-populated city in central china, with a population of 10.38 million (2014).
this city has an area of more than 8494 km2 and is one of the most rapidly developing and heavily industrialized regions in central china.
both the yangtze and han rivers traverse across the main city.
wuhan experiences a typical north subtropical humid monsoon climate, with an annual average temperature of 15.8–17.5 °c and an annual average rainfall of 1050–2000 mm [27,28].
wuhan is located in the jianghan plain, which is a river alluvial plain.
most areas in wuhan are below 50 m above the sea level.
figure 1 illustrates the location and terrain of wuhan.
an elastic lidar system is operated at the top of the liesmars building (30°32′ n, 114°21′ e, and 30 m above sea level) of wuhan university at wuhan (figure 1b).
an elastic lidar determines the nocturnal profiles of particle backscatter coefficient, particle extinction coefficient, and cloud information [19,29,30].
the pm data used are measured from donghu liyuan (30°34′ n, 114°22′ e), which is about 4 km northwest from the lidar site.
the meteorological datasets with a 1 h timestep (including temperature and rh) are derived from a shared weather website [31].
the shf data with a 6 h timestep is obtained from the reanalysis dataset of the national center for environmental prediction.
2.2. methods an elastic backscatter lidar exhibits high spatial and temporal resolution and is widely employed to characterize the ablh.
aerosol vertical distribution is strongly influenced by abl thermal structures.
the aerosol loading in the mixing layer is higher than that in the upper layer, leading to a sharp gradient near the mixing layer top.
three different methods, namely, ideal, grad, and wct, are applied to determine the ablh with the rcs derived from the present elastic lidar observations.
calculation theory for these methods is discussed in previous studies [2,14,21].
ideal method is used to obtain boundary layer parameters by fitting elastic lidar-measured rcs and deriving the ablh [32].
the grad method determines the ablh as the gradient maximum of the elastic lidar signal profile [3,6,33].
the wct method analyzes the vertical gradients of aerosols and the rapid temporal changes in the signal time series as a function of height; this method is less affected by signal noise compared with gradient methods [14,34,35].
the overlap of the lidar system causes some difficulties in monitoring the shallow abl, particularly the nocturnal boundary layer (nbl) [36].
the effect of incomplete overlap should be avoided to accurately estimate the ablh by using a lidar system.
the configurations of our elastic lidar vary at different nights because it is a self-developing lidar.
the complete overlap heights range from 0.1–0.4 km.
to ensure that the overlap minimally influences the estimation of the nbl height, we choose these cases with a complete overlap height lower than 0.15 km.
thus, the shallow nbl (below 0.15 km) cannot be determined in the present study.
aerosol optical depth (aod) is defined as the integral of the particle extinction coefficient along the optical path from 0–3 km [17].
the particle extinction coefficient can be retrieved by the fernald method [37] with a fix lidar ratio (50 sr).
we use the particle extinction coefficient at a complete overlap height (about 0.15 km) to replace the values with incomplete overlap (below 0.15 km) and, thus, avoid the overlap effects.
3. analysis and discussion data for analysis were obtained by elastic lidar at no-rain night time (i.e., 20:00–05:00 cst) from 5 december 2012–17 june 2016. the temporal resolution of the retrieved results is 15 min, and 261 days are available for the entire measured period.
in this study, we only analyze the signal with obvious nblh.
therefore, the statistical results may not completely represent the true results because of inadequate measurement data.
3.1. case analysis we selected a case observed from 19:40 (chinese standard time, cst) on 11 may 2016 to 05:20 the next day.
surface temperatures vary between 20 °c and 25 °c at night.
nblh presents a slight downward trend.
the variations in wind speed may minimally affect ablh for the entire night.
as shown in figure 2c, pm2.5 (pm10) increases rapidly from 50 (90) μg/m3 to 100 (145) μg/m3 and aods slightly decrease from 0.37 to 0.22, respectively.
thus, the declining nblh (from 370 m to 270 m) may indicate that the abl-dilution/abl-accumulation effect partly contributes to the increasing pm value.
at relatively high nbl, particulate near the surface can be diluted by escaping to a large volume.
by contrast, the low ablh compresses the escaping volume of particulate, resulting in increased pm10 and pm2.5 near the surface.
3.2. comparison of nblhs obtained from different methods figure 3 shows the relationships of nblhs, which were obtained through the three different methods, to rcs.
the statistical parameters (i.e., correlation coefficient (r), number of comparisons (n), and bias) are plotted on top of each subfigure.
r refers to the correlation coefficient between the x-variable and the y-variable.
n is the valid number for comparison and defined as the range of the ablh from 0.1 km to 1 km.
the different colors in figure 3 represent the data distribution density; red presents the maximum density, and blue shows the minimum density.
most of the ablhs are less than 0.5 km, and the maximum density is at about 0.3 km.
the high correlation coefficients (0.93, 0.92, and 0.97) and slight bias (−20.8 ± 54.1 m, −17.5 ± 56.9 m, and 1.9 ± 33.3 m) demonstrate that the results from different solutions are consistent with one another (figure 3a–c).
3.3. interannual variability of ablh the mean diurnal cycles for each season, march–may (mam) (spring), june–august (jja) (summer), september–november (son) (autumn), and december–february (djf) (winter), are analyzed.
figure 4a shows the quarterly mean nblhs derived using the three different approaches with elastic lidar measurements in wuhan during the entire study period.
the quarterly day numbers of the available results are plotted in figure 4d.
the error bars in figure 4a represent the corresponding standard deviations.
the three sets of results are consistent with one another.
a clear ablh seasonal cycle is found through statistical analysis of long-term survey data, with a maximum mean height in summer and a minimum mean nblh in winter.
a previous study showed that shf and rh may significantly influence the variations in ablh [26].
figure 4b displays the seasonal mean shf (left y-axis) and rh (right y-axis) near the surface for each quarter.
the measured times are the same as those of the elastic lidar.
the quarterly variations in the mean shf and rh near the surface coincide with the variation in nblh in each quarter [1,25].
negative shf at night time describes the exchange of heat from the atmosphere to the surface.
the consistent variations in nblh and shf may indicate that the atmosphere convective motions become frequent and intense because of a slight heat exchange in summer.
therefore, the ablhs during this season are higher than those in cold months.
some studies reported a high (low) ablh for warmer and drier (cooler and moister) areas [26,38].
however, a reverse relationship between the quarterly variations in rh and nblh is presented in the current study.
we will explain the discrepancy in the next section.
a high (low) ablh can diffuse (accumulate) surface aerosol particles and pollutants [25].
figure 4c refers to the corresponding quarterly average of pm2.5 (left y-axis) and pm 10 (right y-axis).
the trend of these pm values indicates that high pollution appears from 2012 to 2013. a negative correlation is found between pm values and nblh.
when high ablh exists, relatively low pollution levels appear.
however, the correlation is not evident, especially from 2013 to 2014. both positive and negative correlations between abl and fine particle concentration near the surface at day time were reported in previous studies [25,39].
thus, the fine particle concentration near the surface generally exhibits a complex diurnal cycle.
the observed turbulent mixing parameters are weaker in 2013 than those in the other years, probably resulting in inter-annual variability.
data on 2013 are distinct from those of the other years because the former presents a high-frequency heavy pollution condition (figure 4c), resulting in low downwelling solar radiation on the surface during the day and a high heat exchange from the atmosphere to the surface at night.
these results may explain the shallower nblh in 2013 than those in the other years.
3.4. dependence of nblh on near-surface meteorological parameters nblhs from the ideal method are applied in the following analysis because elastic lidar-derived nblhs from the three methods are consistent.
in this section, we will analyze the long-term influences of the relationship between nblhs and near-surface meteorological parameters in wuhan.
3.4.1. seasonal variability using frequency distribution analyses of nblhs, we investigated the boundary layer regimes and relevant nblh variability for the entire period.
standardized nblh frequencies for the four seasons were considered using an nblh bin size of 30 m (figure 5).
the summer nblh frequency ranges from 200 m to 800 m, with the highest frequency occurring at ~350 m, which is mainly characterized with a high number of cases with deep nblh (mean value is 473 ± 154 m).
by contrast, the autumn nblh frequency exhibits a broad and flat distribution with a wide nblh range from 200–700 m and a mean value at 383 ± 137 m. in winter, a relatively high (low) number of cases were observed for small (large) nblh bins.
additionally, the winter frequency distribution ranges from 150–600 m, with a mean value at 309 ± 94 m. nevertheless, the frequency distributions yield a clear seasonal variability with the highest (lowest) mean of nblh of 473 m (309 m) in summer (winter).
the frequency distributions of nblh differ significantly among different seasons, as indicated by the standard deviation values (figure 5).
these results are slightly higher than the recently reported measures of nblh variability in different seasons at a rural site in france [40].
in this study, a clear seasonal dependence is found, indicating relatively higher number of cases with shallow nblh (<200 m) in winter (67.3%) than those in summer (33.9%) and spring (54.5%).
the higher results in the present study may be due to the inability to obtain the nblh below 150 m. figure 6 presents different aspects of near-surface forcing on nblh variability at seasonal timescales.
we consider near-surface meteorological parameters including shf (w·m−2), rh (%), wind speed (m·s−1), and temperature (°c).
we performed box-and-whisker analyses to represent the seasonal variations in nblh and these near-surface meteorological parameters.
all parameters exhibit a clear seasonal variability and cyclic behavior, indicating high (low) temperature of nblh in summer (winter) months.
additionally, the annual cycle is evident for shf, with mean values reaching the maximum in spring and summer and the minimum during winter months.
the rh parameter features a clear seasonal cycle, that is, wet condition in summer and dry condition in winter (figure 6d) are due to high amounts of precipitation and temperature in summer than those in winter months at wuhan.
overall, the three datasets (shf, temp, rh, and nblh) show good agreement and seasonal similarities.
however, rh shows an opposite annual cycle compared with those in the other studies which suggest higher (lower) ablh in drier (moister) areas [26,38].
the inconsistent results could be due to the fact that previous studies were performed during the day, whereas the present study was conducted at night.
moreover, perhaps near-surface rh may not be a crucial factor for nblh variation.
using the daily 20:00 cst radiosonde-derived profiles of horizontal wind speed within the lidar-derived nblh, we quantified the dependence of variability of nblh on mean wind speed.
wind speed is an important parameter used to investigate detailed eddy structures and scaling turbulence estimating cbl height [1,26].
we estimated the average wind speed within altitudes between 50 m and the middle of the nblh obtained with radiosonde measurements; the method is similar to that reported in a previous study [26].
a clear wind speed seasonal cycle is usually found through analysis of long-term survey data, with a maximum mean wind speed in summer and a minimum mean wind speed during winter.
we also plotted the quarterly variations in pm2.5 (μg/m3) in figure 6f to investigate the relationship of nblh and near-surface pollution level.
the seasonal mean values of aod at 500 nm obtained from sun photometer on 2007–2013 in wuhan are 1.03 ± 0.52, 1.13 ± 0.71, 1.07 ± 0.75, and 1.05 ± 0.60 for spring, summer, autumn, and winter, respectively [27].
hence, a deep (shallow) seasonal mean nbl is consistent with a small (large) seasonal mean pm2.5 near the surface.
the opposite seasonal variations in aod and pm2.5 may partly explain the nocturnal abl-dilution/abl-accumulation effect on surface particle concentration.
3.4.2. dependence of nblh on near-surface parameters on seasonal scale the relationship between nblh and shf must be investigated to elucidate physical processes governing seasonal variability [26].
the scatterplots illustrate the regression analyses for the entire measured period (figure 7a).
the relationships between nblh and the other parameters (temperature, rh and wind speed) are plotted in the same figure.
the colors of the circles in each panel mark different seasons.
the relationship between nblh and shf (r = 0.72) is not fully linear, particularly during summer when the nblh values are the highest; by contrast, shf values remain in the same range among all seasons.
these results are similar to the findings reported by other researchers [26].
monthly mean nocturnal shfs vary from −37 (winter) to −25 (summer) w/m2.
seasonal separation is unclear for different seasons.
autumn and winter shfs are close (ranging from −60 to 0 w/m2).
spring shf ranges from −85 w/m2 to 0 w/m2, whereas winter shf ranges from −40 w/m2 to 0 w/m2.
thus, in spite of highest shf in summer, the linearity between shf and nblh is not well developed (r = 0.72).
in summer, in spite of the limited shf, nblh reaches higher altitudes than that in spring, which could be attributed to other sources that influence nblh.
these sources may include advection of different air masses from adjacent areas, presence of clouds, and temporal shift in the times of nblh and shf [26].
yi et al.
[41] discussed the relationship between shf and abl variability, in which abl increases for more than 3 h even after the shf reached the daytime peak value.
additionally, some errors in measurement of shf and nblh may influence the result.
the relationship between nblh and surface temperature is shown in figure 7b.
the positive correlation (r = 0.68) indicates that high (low) nblh corresponds warm (cool) condition.
similarly, the relationship between nblh and surface rh exhibits a slight positive correlation (r = 0.52; figure 7c).
other studies reported the dependence of ablh on surface temperature and moisture.
for example, molod et al.
investigated spatial variability of ablh via noaa wind profiler network data [38].
pal et al.
reported the dependences of ablh on surface temperature and moisture at different time scales [21]; in this study, high (low) ablh was observed for warm and dry (cool and moist) areas.
therefore, the relationship between nblh and surface temperature reported in previous studies coincides with the present analysis, but the relationship between nblh and surface rh is inconsistent.
thus, rh may play an opposite or insignificant influence on variations in nblh in wuhan.
shf is an important surface-based driver of ablh but is not the sole driver that generating day-to-day variability in ablh.
vilà-guerau de arellano et al.
investigated the roles of abl wind speed in modulating abl growth in the morning [42].
pal et al.
suggested that ablhs are correlated with shf under low wind speed conditions [26].
in the present analysis, the weak positive correlation (r = 0.38) between nblh and wind speed inside nbl is shown in figure 7d.
the result implies that wind speed is not a crucial direct driver that governs the seasonal variability of nblh.
4. conclusions we present a long-term analysis on the variability of main parameters of the nblh diurnal cycle.
a long-term dataset of nblh was obtained by applying three detection methods on the lidar-derived backscatter profiles from 5 december 2012–17 june 2016. we also explored the mechanism through which other parameters may affect the variability of abl parameters and the influence of nblh on surface pm at seasonal and inter-annual timescales in wuhan.
analyses were conducted using atmospheric parameters including nblh, shf, temperature and rh, nbl mean wind speed, and pm value.
by analyzing the composites of nblh and different meteorological parameters, we pointed out that the near-surface thermodynamics plays an integral role in governing nblh at seasonal and inter-annual timescales.
the seasonal variations of nblh, aod and pm2.5 display a deep (shallow) seasonal mean nbl, consistent with a low (high) seasonal mean pm2.5 near the surface.
seasonal variability of nblh is partly linearly correlated with shf on the surface (r = 0.72).
linear regression analyses between nblh and other parameters show the following: (1) the positive correlation (r = 0.68) between nblh and surface temperature indicates that high (low) nblh corresponds to warm (cool) condition; (2) similar slight positive correlation (r = 0.52) between nblh and surface relative humidity in wuhan; and (3) the weak positive correlation (r = 0.38) between nblh and wind speed inside nbl may imply that wind speed is not a crucial direct driver that governs the seasonal variability of nblh.
our analysis indicates that the nbl is difficult to quantitatively characterize.
future studies should determine nblh by using several tools, such as wind lidar, radiosonde, and satellite-based lidar.
the relationship between nblh and other optical parameters or synoptic conditions requires an in-depth study.
@highlight
the atmospheric boundary layer (abl), an atmospheric region near the earth’s surface, is affected by surface forcing and is important for studying air quality, climate, and weather forecasts.
in this study, long-term urban nocturnal boundary layers (nbls) were estimated by an elastic backscatter light detection and ranging (lidar) with various methods in wuhan (30.5° n, 114.4° e), a city in central china.
this study aims to explore two abl research topics: (1) the relationship between nbl height (nblh) and near-surface parameters (e.g., sensible heat flux, temperature, wind speed, and relative humidity) to elucidate meteorological processes governing nbl variability; and (2) the influence of nblh variations in surface particulate matter (pm) in wuhan.
we analyzed the nocturnal abl-dilution/abl-accumulation effect on surface particle concentration by using a typical case.
a long-term analysis was then performed from 5 december 2012–17 june 2016. results reveal that the seasonal averages of nocturnal (from 20:00 to 05:00 next day, chinese standard time) nblhs are 386 ± 161 m in spring, 473 ± 154 m in summer, 383 ± 137 m in autumn, and 309 ± 94 m in winter.
the seasonal variations in nblh, aod, and pm2.5 display a deep (shallow) seasonal mean nbl, consistent with a small (larger) seasonal mean pm2.5 near the surface.
seasonal variability of nblh is partly linearly correlated with sensible heat flux at the surface (r = 0.72).
linear regression analyses between nblh and other parameters show the following: (1) the positive correlation (r = 0.68) between nblh and surface temperature indicates high (low) nblh corresponding to warm (cool) conditions; (2) the slight positive correlation (r = 0.52) between nblh and surface relative humidity in wuhan; and (3) the weak positive correlation (r = 0.38) between nblh and wind speed inside the nbl may imply that the latter is not an important direct driver that governs the seasonal variability of nblh.
