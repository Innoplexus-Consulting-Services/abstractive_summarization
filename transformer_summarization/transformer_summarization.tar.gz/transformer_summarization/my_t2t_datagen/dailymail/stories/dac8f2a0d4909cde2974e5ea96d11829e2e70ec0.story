1 introduction fluorescence microscopy is a key tool in the study of bacterial cell biology and host-pathogen interactions.
a multitude of different fluorescent proteins have now been developed, and these enable both the tracking of bacterial populations over time, and the tagging of specific proteins of interest to study their subcellular localisation and dynamics (landgraf et al., 2012, shaner et al., 2008).
these powerful approaches, however, are limited to those bacterial species for which genetic manipulation is possible.
relative to the wealth and diversity of known bacterial species, the number of genetically tractable model organisms is miniscule.
fluorescent proteins are also limited by their inability to label molecular species that are not directly genomically encoded, such as the peptidoglycan cell wall and lipid bilayers.
small fluorescent probes that are able to diffuse into living cells and label specific components are powerful alternative tools.
a large collection of probes have been developed for use in mammalian cells, including those with the ability to label generic molecules such as free amines or lipid bilayers (brown and london, 1998), and those that target specific cellular structures such as lysosomes (pol et al., 2001, peng et al., 2010), the endoplasmic reticulum, or the actin or microtubule cytoskeleton (belin et al., 2014).
comparatively few have been developed specifically for bacterial targets with the notable exception of peptidoglycan (shieh et al., 2014, kuru et al., 2015).
many of the probes developed for use in mammalian cells have not been tested in bacteria (boleti et al., 2000).
an ideal fluorescent probe would be incorporated into cells using a minimally invasive protocol, would be photostable and long-lasting, would exhibit minimal detachment from its molecular target and have little or no effect on bacterial viability.
all criteria may not always be fulfilled, and certain compromises may be acceptable depending on the specific scientific question being addressed.
orientia tsutsugamushi is an obligate intracellular bacterium, and the mite-borne causative agent of the severe human disease scrub typhus (watt and parola, 2003, rajapakse et al., 2012, seong et al., 2001).
whilst this disease has an untreated mortality rate of between 1 and 40%, and is predicted to affect at least 1 million people annually (watt and parola, 2003), comparatively little is known about its mechanisms of host cell invasion and pathogenesis (paris et al., 2013).
there are currently no genetic tools available, and like all obligate intracellular bacteria, such as the chlamydiales and the rickettsiales, these organisms are osmotically sensitive and experimentally difficult to manipulate.
the availability of experimentally validated fluorescent probes to label o. tsutsugamushi would enable live cell imaging experiments to study its host cell infection cycle in detail.
here, we have tested the application of a panel of fluorescent probes in o. tsutsugamushi and discuss their suitability for future cell biology experiments.
2 results and discussion 2.1 carboxyfluorescein succinimidyl ester (cfse) can be used to label the cytoplasm of o. tsutsugamushi carboxyfluorescein succinimidyl ester is a fluorescent dye that is used to label mainly proteins in the cytoplasm of living cells.
the non-fluorescent compound carboxyfluorescein diacetate succinimidyl ester (cfda-se) is added to living cells, and diffuses freely across the cell membrane (bronner-fraser, 1985, nose and takeichi, 1986, the molecular probes handbook, n.d).
intracellular esterases cleave the two acetate groups to form fluorescent cfse, which is not membrane-permeable and is thus confined to the cytoplasm.
this compound reacts to form a covalent bond with lysines and other primary amines via its succinimidyl group, resulting in covalently labelled fluorescent proteins in the cellular cytoplasm.
cfse is extremely photostable and is commonly used as a long-term cell tracer in immunological studies of migration and proliferation in lymphocytes (parish, 1999, parish and warren, 2002), and occasionally in experiments with bacteria (obradovic et al., 2016, tuominen-gustafsson et al., 2006).
various derivatives of cfse have been developed with different fluorescent properties, including a far red variant, which is used in this study.
we tested the ability of (green) cfse and (red) celltrace farred (ct farred) to label o. tsutsugamushi cells and found that the bacteria could be clearly labelled with the dyes at 5 μm (fig.
1a).
o. tsutsugamushi labelled with these dyes appeared as circles or coccobacilli of around 1–2 μm in diameter, which would be expected from cytoplasmic labelling of these cells.
these dyes are reported to be amenable to fixation with aldehydes (molecular probes, usa) but in our hands the labelling could not be properly retained after fixation with either paraformaldehyde or acetone (fig.
1a).
we measured the effect of cfse and ct far red on the growth of o. tsutsugamushi and found no detectable reduction in growth after 7 days compared with untreated and mock-treated bacteria (fig.
1b and supplementary fig.
1).
we tested whether we could follow bacterial attachment and entry into host cells using these dyes, and found that cfse- and ct farred-labelled bacteria could be clearly observed when added to a monolayer of mammalian cells (fig.
1c and movie 1).
labelling with these dyes is performed on bacteria that have been isolated from host cells, and residual cfda-se is washed away after labelling.
therefore the fluorescent background in host cells from non-specific cfse labelling is negligible.
these results show that these dyes can be used to track the early events of bacteria attachment and entry.
2.2 cfse can be used to follow bacterial division the covalent attachment of cfse to cytoplasmic free amines means that the dye should be stably maintained within the cytoplasm and any reduction in fluorescence intensity should be largely due to cell division.
the decrease in fluorescence intensity over time can therefore be used to quantify cell division.
this principle has been used to track motility and proliferation of immune cells using cfse (parish, 1999, parish and warren, 2002), and also cell division and differentiation into non-dividing persistor cells in salmonella using genomically-encoded fluorescent proteins (helaine et al., 2010).
in order to determine whether cfse could be used to quantify bacterial cell division in o. tsutsugamushi over time we quantified the fluorescence intensity of individual cfse-labelled bacterial cells over 7 days.
separate glass slides with coverslip bases were used for each time point, in order to avoid reductions in fluorescence due to photobleaching from previous measurements or effects on bacterial growth due to extended periods of time on the microscope incubation chamber.
in order to confirm that cfse-labelling had no effect on bacterial morphology or the infection cycle, we performed this time course in parallel with samples that were fixed and immunolabelled using conventional methods.
we fixed samples that had either been cfse-labelled, or unlabelled.
fig.
2a shows a reduction in cfse fluorescence over time (top row).
the laser was increased in order to optimise image acquisition in these images, but during acquisition of images for quantification of fluorescence intensity the laser strength and gain parameters were kept constant.
the middle row and lower row show a typical field of infected cells at each time point, where bacteria had (middle row) or had not (lower row) been labelled with cfse.
the estimated multiplicity of infection (moi) was 100:1 bacteria:host but it should be noted that due to difficulties in rapid quantification of isolated orientia this could not be measured precisely and there were unavoidable variations in moi between conditions.
these experiments were only used to perform qualitative analysis of bacterial growth.
the infection cycle of o. tsutsugamushi is known to involve translocation to the nucleus after 24–48 h followed by bacterial replication.
the patterns of bacterial localisation and replication in both time courses were comparable, and similar to large numbers of other time courses performed in our laboratory with this strain and cell line.
therefore we concluded that cfse labelling did not significantly affect the typical infection cycle of o. tsutsugamushi.
at each time point images of live bacteria were acquired and 10 bacteria were randomly selected for quantification.
the highest pixel intensity within each bacterium (which typically covered ~ 5–10 pixels) was measured and recorded.
this experiment was performed 3 separate times.
as a comparison, cfse-labelled bacteria that were not added to host cells and therefore not able to divide were quantified in the same way.
fig.
2b shows that average the fluorescence intensity of o. tsutsugamushi decreased rapidly between 48 and 96 h. in comparison, bacteria that had been stored in the absence of host cells showed no decrease in fluorescence (fig.
2c) indicating that the reduction in fluorescence was due to bacterial growth and division rather than reduction in fluorescence intensity of the probe.
the timing of the decrease in cfse fluorescence correlates closely with the known replication time of o. tsutsugamushi as measured by qpcr (giengkam et al., 2015).
one limitation of qpcr is that it measures genome copy number rather than cell number.
since it is known that some bacteria can carry more than one genome copy per cell this may not be an accurate representation of cell division, and the decrease in cfse intensity offers an independent measure of bacterial replication.
a small number of bacteria with high cfse levels could be detected up to 7 days after infection (fig.
2b), indicating a sub-population of cells that are either dead or only slowly dividing.
this may represent a persistent population as has been reported for other intracellular bacteria (helaine et al., 2014).
one limitation of our approach is that we cannot distinguish between reductions in fluorescence due to bacterial division and reductions due to secretion of effector proteins.
whilst we expect the total number of secreted proteins as a factor of the total proteome to be small enough not to affect the cytoplasmic cfse level dramatically, this has not been experimentally verified.
2.3 syto9 can be used to label nucleic acids in live o. tsutsugamushi syto9 is a green-fluorescent dye that is freely permeable to cell membranes and undergoes a large increase in fluorescence upon binding to nucleic acids.
syto9 is a component of the popular live/dead viability kit, in which it is combined with a second nucleic acid binding dye, propridium iodide, that cannot cross intact membranes and therefore only labels dead cells in which the membrane is disrupted (maurer and dougherty, 2001).
we tested whether syto9 could be used to label intact, live o. tsutsugamushi cells.
we found that addition of 5 nm syto9 resulted in bright and clearly labelled bacterial cells, which could be observed almost immediately after addition (fig.
3a).
the labelling procedure was extremely straightforward, with dmso-solubilised probe being added directly to living cells.
since the dye is not fluorescent until bound to nucleic acids, further washing steps are not required.
similar to cfse and ct farred, we found that syto9 fluorescence was not retained after fixation with paraformaldehyde or acetone (fig.
3a).
we tested the effect of syto9-labelling on bacterial growth and found that it resulted in a reproducible reduction in growth over 7 days, although this was not statistically significant (fig.
3b).
we also determined the effect of dmso on bacterial growth, since this is a common solvent for many chemical compounds, and found no effect on bacterial growth when added at a dilution of 1/100 or 1/1000 (fig.
3b).
the concentration used in the syto9 labelling was 1/1000.
o. tsutsugamushi exhibits a long cellular infection cycle in vitro, lasting 7 days or more (seong et al., 2001, moree and hanson, 1992).
whilst cfse provided a powerful tool for monitoring the early stages of bacterial attachment and entry, the fact that bacteria could only be labelled at the start of infection made it difficult to study processes occurring after one or two rounds of bacterial division using this dye.
we therefore wondered whether we could use syto9 to label bacteria inside cells that had already been infected for several days.
this would enable studies of bacterial localisation and motility during periods of rapid replication and host cell exit.
syto9 labels nucleic acids non-discriminately and therefore host cell nuclei, mitochondria and cytoplasmic rna will also be labelled.
in spite of this we found that fluorescently labelled o. tsutsugamushi could be clearly identified against this background due to their number, perinuclear localisation and rapid motility (fig.
3c and movie 2).
given the observed effect on bacterial replication over time, this dye is not suitable for long term imaging studies.
however, it promises to be a powerful tool in the study of motility of intracellular pathogens.
it also provides an alternative and rapid method for the quantification of bacteria in infected cultured cells.
2.4 the dii, dio and did vybrant dyes can be used to label the membrane of o. tsutsugamushi clear labelling of bacterial membranes enables analysis of bacterial cell shape as well as a study of the formation of outer membrane vesicles.
the styryl dye fm 4–64 is commonly used to label the membranes of bacterial cells (pogliano et al., 1999), but labelling efficiency is species-specific and we found it labelled o. tsutsugamushi poorly (data not shown).
furthermore, whilst this dye only exhibits fluorescence when inserted in a lipid bilayer, it has the property of reversibly diffusing in and out of membranes, resulting in a secondary labelling of nearby cells (betz and bewick, 1992).
this inability to be retained within a specific subpopulation of cells limits it use in host-pathogen cell biology experiments.
the vybrant dye collection comprises a range of highly lipophilic compounds that exhibit a range of fluorescent colours upon insertion into lipid membranes (molecular probes, usa).
unlike the fm collection, they exhibit lateral diffusion within their target membrane but no soluble diffusion to nearby cells in which membranes are not contiguous (the molecular probes handbook, n.d.).
this property makes it possible to label a distinct population of cells at the beginning of an experiment and follow this population over time.
we found that o. tsutsugamushi could be clearly labelled with the vybrant dye did, dii and dio, revealing a range of bacterial structures (fig.
4a shows bacteria labelled with did; dii and dio gave similar patterns of labelling).
did labelling was not retained after fixation with paraformaldehyde or acetone.
the procedure for did labelling involves resuspension of cells in a specific buffer (optimem) and we found that this affected bacterial growth over time (fig.
4b).
this effect could potentially be mediated by the development of alternative buffers.
the additional reduction in bacterial growth caused by the vybrant dyes added at 100 μm was minimal (fig.
4b).
when membrane-labelled o. tsutsugamushi was added to unlabelled host cells there was no detectable background and the bacteria could be followed during attachment and entry into host cells (fig.
4c).
one potential application of this dye is in the study of generation and localisation of bacterial-derived outer membrane vesicles.
2.5 hada can be used to label the peptidoglycan cell wall of o. tsutsugamushi peptidoglycan is a bacteria-specific molecule that is essential for most bacteria and that confers cell strength and rigidity (turner et al., 2014, vollmer et al., 2008) it is typically composed of a large structure that is positioned between the two membranes of gram negative bacteria or outside the cell membrane of gram positive bacteria, and that is comprised of a polymerised glycan backbone cross-linked through short peptide side chains.
o. tsutsugamushi has always been reported to lack this macromolecule (amano et al., 1987), but we recently showed that it is indeed present in these cells (manuscript submitted).
a number of probes have been developed that specifically label bacterial peptidoglycan and these are based on fluorescent derivatives of the peptidoglycan-binding drug vancomycin (turner et al., 2013), or the peptidoglycan-unique amino acid d-alanine (kuru et al., 2015).
of these, the hcc-amino-d-alanine (hada) probe can be used to image live cells and therefore we used this in the current study.
addition of hada to o. tsutsugamushi yielded blue spots (live imaging, fig.
5a, c and movie 3) or clearly discernable rings corresponding to the bacterial cell wall (pfa-fixed, fig.
5a).
there was a high background from host cells as has been reported previously (kuru et al., 2015) unlike the other probes reported here, hada-labelled o. tsutsugamushi could be fixed with paraformaldehyde, which will enable correlative studies combining live and fixed microscopy.
we measured the growth of o. tsutsugamushi in the presence of hada and found no significant effect on bacterial growth (fig.
5b).
3 conclusion here we describe the use of fluorescent dyes to label four distinct compartments of living bacterial cells: the cytoplasm, nucleic acids, cell membrane and the cell wall (summarised in table 1).
the ability to track living cells over time will enable the study of processes such as bacterial attachment and entry into host cells, bacterial cell division over time, and bacterial cell motility.
the ability to label different components of the bacterial cell will enable the analysis of fundamental processes in bacterial cell biology such as growth and elongation, cytokinesis, and the generation of outer membrane vesicles.
the methods described here will allow host-pathogen cell biology experiments to be performed in poorly characterised model systems, typical of neglected and emerging pathogens, fastidious organisms, or newly-isolated clinical or environmental strains.
4 materials and methods 4.1 cell culture and bacterial growth all experiments were performed using the karp-like ut76 strain of orientia tsutsugamushi and the mouse fibroblast cell line l929.
l929 cells were grown in 25 cm2 plastic flasks at 37 °c and 5% co2, using dmem or rpmi media supplemented with 10% fbs.
for all experiments bacteria were isolated from l929 cells 7 days after infection and purified as described previously (giengkam et al., 2015).
briefly, the supernatant was removed, the adherent cells were detached by mechanical scraping, the mammalian cells were lysed by mechanical force (bullet blender, nextadvance usa, power 8 for 1 min) and the bacteria were filtered using a 2 μm filter.
4.2 quantification of bacterial growth by qpcr the effect of dyes on bacterial viability was measured by growing bacteria in l929 cells in 24-well tissue culture plates (corning, usa) in the presence or absence of dyes or mock-labelling conditions.
identical triplicate wells were used.
after 7 days growth at 35 °c + 5% co2, bacterial dna was isolated and the genome copy number was determined using qpcr against the sta47 gene (ott_1319) as described previously (giengkam et al., 2015).
results are shown as the absolute bacterial genome copy number per well of a 24 well plate (1.9 cm2) and the inoculum added per well is given in the figure legend.
note that the inoculum is not the same as the number of bacteria taken up by cells, which is typically 1–100 times lower.
unbound bacteria were washed away 3 h after inoculation and prior to incubation for 7 days.
4.3 immunofluorescence labelling and confocal microscopy for live imaging or fixed sample preparation of bacteria inside l929 host cells, l929 cells were grown directly on chambered coverslip slides (ibidi, usa).
these were infected with labelled or unlabelled bacteria and either imaged live or fixed and processed for labelling with fluorescently-conjugated antibodies.
samples were fixed with 4% paraformaldehyde for 10 min at room temperature, and then washed three times with pbs.
samples were permeabilised using 0.5% triton x on ice for ten minutes, and then washed three times with pbs.
immunofluorescent labelling was performed using a rat monoclonal antibody against the tsa56 gene diluted to 1/200, followed by an alexa 488-conjugated secondary anti-rat antibody diluted to 1/1000 (thermofisher scientific, uk).
incubations were performed for 30–60 min at room temperature, and washed three times with pbs in between.
samples were mounted using hardset mounting media (vectashield, vector laboratories, usa).
imaging was performed using a zeiss lsm 7000 equipped with a 63 × 1.4 na objective lens (carl zeiss, usa).
4.4 cfse and celltrace farred labelling purified bacteria were labelled with cfse and ct farred as follows (catalog numbers c34554 and c34564 from lifetechnologies, usa).
5 mm aliquots of dye dissolved in dmso were stored in 1 μl volumes at − 20 °c.
for labelling, one aliquot was thawed to room temperature.
this was diluted to a 5 μm working dilution in pbs containing 2% bsa.
purified bacteria were pelleted at 20,238 × g at room temperature, then resuspended in the 5 μm dye solution.
samples were incubated for 15 min at 37 °c or 30 min at room temperature, in the dark.
bacteria were then pelleted and resuspended in rpmi + 5% fbs and incubated at room temperature for 30 min to quench remaining dye.
bacteria were repelleted and resuspended in fresh media, and were then ready for use.
4.5 cfse quantification cfse-labelled bacteria were added to growing l929 cells or cell-free media, in chambered coverglass slides, then imaged by confocal microscopy at various times up to 7 days.
at each time point, images were recorded using identical laser strength and gain parameters.
ten bacteria were randomly selected and the maximum pixel intensity within the bacteria was recorded.
this experiment was repeated three independent times and the same trend observed each time.
4.6 syto9 labelling the dye syto9 (catalog number s34854, invitrogen, usa) was dissolved to 5 μm in dmso and stored in 5 μl aliquots at − 20 °c.
purified bacteria or bacteria in l929 cells were labelled with syto9 by adding the dye directly to samples at a dilution of 1/1000, which was equivalent to 5 nm.
4.7 vybrant dye labelling the vybrant dyes dii, did and dio (catalog number v22889, lifetechnologies, usa) were used to label purified bacteria.
the dyes were stored in their commercial buffers at 4 °c.
purified bacteria were resuspended in 100 μl of the commercial opti-mem buffer (catalog number 31985062, thermofisher scientific, uk), and the dye was added at a dilution of 1/100 (final concentration of 100 μm).
samples were incubated at 35 °c for 30 min, then washed by pelleting two times and then resuspended in dmem + 5% fbs.
4.8 hada labelling hada was used to label purified bacteria or bacteria growing in l929 cells.
hcc-amino-d-alanine (hada, synthesised by michael vannieuwenhze, university of indiana, usa) was stored in 5 μl aliquots at 10 mm in dmso at − 20 °c.
for labelling, hada was dissolved in growth media at a dilution of 1/100 (final concentration of 100 μm).
bacteria were washed and resuspended in hada + growth media (to label purified bacteria) or the media was removed and replace with hada + growth media (bacteria in l929 cells).
samples were incubated at 35 °c for 3 h, then either imaged live or washed three times in pbs and fixed before imaging.
4.9 statistical analysis statistical analysis was performed using graphpad prism software (graphpad).
one-way anova analysis was used.
the following are the supplementary data related to this article.movie 1cfse-labelled bacteria entering l929 cells.
scale bar = 10 μm.
time elapsed is shown in the top left hand corner.movie 1movie 2syto9-labelled bacteria inside l929 cells.
scale bar = 10 μm.
time elapsed is shown in the top left hand corner.movie 2movie 3hada-labelled bacteria entering l929 cells.
scale bar = 10 μm.
time elapsed is shown in the top left hand corner.movie 3supplementary fig.
1graph showing the growth of orientia in l929 cells over 7 days.
prior to infection, bacteria were treated with no label, mock label or ct farred label.
bacterial copy number per well was determined by qpcr and biological triplicate values are plotted.supplementary fig.
1 glossary hada hcc-amino-d-alanine cfse carboxyfluorescein succinimidyl ester cfda-se carboxyfluorescein diacetate succinimidyl ester
@highlight
our understanding of the molecular mechanisms of bacterial infection and pathogenesis are disproportionally derived from a small number of well-characterised species and strains.
one reason for this is the enormous time and resources required to develop a new organism into experimental system that can be interrogated at the molecular level, in particular with regards to the development of genetic tools.
live cell imaging by fluorescence microscopy is a powerful technique to study biological processes such as bacterial motility, host cell invasion, and bacterial growth and division.
in the absence of genetic tools that enable exogenous expression of fluorescent proteins, fluorescent chemical probes can be used to label and track living cells.
a large number of fluorescent chemical probes are commercially available, but these have overwhelmingly been applied to the study of eukaryotic cell systems.
here, we present a methodical analysis of four different classes of probes, which can be used to delineate the cytoplasm, nucleic acids, cell membrane or peptidoglycan of living bacterial cells.
we have tested these in the context of the important but neglected human pathogen orientia tsutsugamushi but expect that the methodology would be broadly applicable to other bacterial species.
