introduction cell-based approaches in tissue engineering require rapid and stable vascularization of biomaterials to regenerate tissues with high oxygen demand.
however, clinical applications of cell-based approaches have been primarily limited to relatively avascular cartilage1 or thin skin.2 well-developed vasculature is essential for almost all engineered tissues and is particularly challenging in thick tissues.3 researchers have investigated a number of different strategies to establish vascular networks within biomaterials.
these include: (i) optimizing design of physical and chemical scaffold architecture to enable or even enhance vessel growth, (ii) delivery of angiogenic factors to stimulate vessel growth from host tissue, and (iii) building vascular networks within the scaffold before implantation (in vitro prevascularization).4,5 for the first strategy, a broad range of physical properties of the scaffold can result in biomaterials that are more permissive for directed and rapid vessel invasion.6–10 not only does pore size and porosity influence angiogenesis but also interconnectivity of the porous structure influences the rate of angiogenesis.11 delivery of angiogenic factors to target microenvironments in scaffolds to stimulate cell migration and proliferation can enhance vascularization.12–15 a variety of angiogenic factors such as vascular endothelial growth factor (vegf), basic fibroblast growth factor (bfgf), and/or platelet-derived growth factor (pdgf) have been delivered from scaffolds, aiming to enhance the vascularization process.16–19 however, the typical approach to deliver growth factors (gfs) from scaffolds does not allow precise control over spatiotemporal release and often results in inadequate vascularization.
spatial and temporal gradients of gf affect the direction, structure, rate of cell invasion, and vascularization.20,21 while promising results are being obtained using these approaches, the depth of vascularization may not be sufficient to reach the cells located in deeper parts of larger scaffolds.
in addition, the newly formed capillaries induced by external gfs may be unstable and regress after the gf withdrawal.22 prevascularization is another approach that interests tissue engineers to promote rapid vascularization.23 in this approach, a partial capillary network is established within an implantable scaffold before implantation,24 so that new blood vessels that grow from host vessels can make connections with these preexisting capillaries and establish blood flow more rapidly to deeper regions of the biomaterial.
studies have shown that preformed microvascular networks were successfully perfused after implantation and gave rise to functioning networks.25,26 systematic evaluation of these approaches strictly through in vivo or in vitro experimentation is costly and a single experiment can take several months depending on the application.
moreover, understanding interactions of different components, explaining the causes for possible outcomes, and predicting future events may not be possible with experimentation alone.
the need for computational modeling in tissue engineering field is therefore well recognized.27 angiogenesis in tissue-engineered constructs has been simulated using various computational approaches to investigate the effects of mechanical stresses, exogenous delivery of an angiogenic gf,28 seeding the scaffold with vascular cells,29 and manipulating pore structure.30,31 agent-based models (abms) have been used successfully in recent years for modeling biological systems.32–34 unlike traditional modeling approaches, abms simulate the changes in the behavior of individual agents instead of, or in combination with, system level variables.
agents behave based on simple rules that originate from knowledge of the system under study.
an abm was developed in our group previously to simulate the effects of biomaterial pore structure on angiogenesis, focusing on the endothelial cell (ec) (the cells lining the walls of the blood vessels) behavior.30,31 this model has been modified and extended to study the effects of strategies, including gf release and prevascularization of biomaterials on angiogenesis.
the results will focus on the investigation of the impact of: (i) scaffold architectural design, (ii) gradient and gf release, and (iii) prevascularization on scaffold vascularization and comparison of simulation results with relevant experimental studies.
materials and methods abm of angiogenesis and endothelial cell agent the angiogenesis simulation model is constructed based on the actions of ec in response to the presence of soluble factors and the biomaterial microenvironment.
ec behavior was abstracted into a rule-base (fig.
1) based on knowledge of the real angiogenesis process observed in experimental studies from ourselves and others.
ecs become activated when the gf concentration reaches a threshold in the local environment.
the activated ecs (tip cells) migrate up the gf gradient.
while the tip cell is migrating, stalk cells elongate until they reach a maximum size.
subsequent elongation results from the proliferation of new ecs (stalk cells).
gfs are also needed for newly formed capillary survival since ecs undergo apoptosis in regions of gf deficiency resulting in capillary regression.22 a minimum threshold is used in the abm to identify the point where capillary regression would occur.
anastomosis occurs when two elongating ec agents from different capillaries are within a defined distance from each other.
the two sprouts will connect to form a stable blood vessel, which is assumed to allow blood flow; pressure gradient necessary for flow is not considered.
ecs cannot invade nondegraded scaffolds.
when an ec encounters part of a scaffold, it searches new routes to keep moving through the gradient.
parameters and detailed rule base governing the ec behavior are derived from the literature and have been reported elsewhere.31 fig.
1. abstracted rule-base governing the behavior of each endothelial cell agent.
model scaffolds three-dimensional models of scaffolds with spherical and rectangular pores were generated computationally to study the effect of biomaterial pore interconnectivity on vascularization as described previously.11 the interconnectivity of the scaffolds is defined as the mean diameter of the opening between adjacent pores.
normalized pore connectivity (npc) is calculated for each scaffold as the ratio of the mean pore interconnectivity to the mean pore diameter.
the scaffolds were initiated by specifying a random pore location.
subsequent pore locations were generated by searching all locations within the scaffold that would satisfy the condition of the specified interconnectivity.
once the locations met the criteria, the pores were placed followed by, again, searching locations from displaced pores that would satisfy the interconnectivity criterion.
these processes were repeated until no locations within the scaffold were able to satisfy the specified interconnectivity.
for scaffolds with a constant pore size, porosity is dependent on the pore interconnectivity.
bulk and interface porosity of the lower (npc 0.25) and the higher (npc 0.45) pore throat diameter are reported.
three-dimensional renderings of spherical scaffolds with corresponding interface are shown in figure 2a, c. fig.
2. images of the bulk scaffold structures (a, b) and interfaces (c, d) for spherical (a, c) and rectangular pores (b, d).
scaffolds were also modeled with rectangular pores to approximate salt-leached scaffolds with the salt crystal size range consistent with experiments, 300–500 μm.
similar to spherical scaffolds, pore locations were determined randomly within a matrix.
subsequent pore locations were determined based on amount of overlap between neighboring pores.
once all locations within matrix were determined, rectangular pores were added to the matrix.
each rectangular pore was randomly rotated, fixed at its center, for the x, y, and z dimensions between 0° and 360° in intervals of 10°.
these processes were repeated until a desired porosity was reached.
in these experiments, we used 64.4%, which is based on experimental values of salt-leached hydrogels fabricated experimentally.
three-dimensional renderings of cylindrical scaffolds with corresponding interface are shown in figure 2b, d. growth factor release profiles for gradient studies, the models of salt-leached scaffolds were used, and a gradient of an angiogenic gf, platelet derived growth factor-bb (pdgf-bb), was added to the structure.20 a layer of degradable hydrogel containing microspheres (distal layer) is placed on the surface of a porous fibrin/poly (ethylene glycol) (peg) composite scaffold.
pdgf-bb was encapsulated into degradable microspheres (poly (lactic-co-glycolic acid)) (plga) and microspheres and placed at the top of the scaffold within the degradable polymer.
scaffolds were kept in cylindrically shaped shells, and host vasculature was located at the bottom of the scaffold to approximate one-dimensional diffusion (y-direction).
pdgf-bb gradients through the porous hydrogel system due to degradation of microspheres and diffusion in the hydrogel structure were modeled in matlab based on fick's second law.
in the model, diffusion is assumed as the only mechanism of transport.
boundary condition at the distal layer was adapted from the experimental release kinetics data, and the surrounding tissue was modeled as infinite sink pdgf-bb, which has a low affinity for fibrin within the porous structure.35,36 hence, it was assumed that pdgf-bb did not interact with the scaffold.
the effective diffusion coefficient within the scaffold was calculated by fitting the model to experimental results to account for both steric effects of the scaffold structure and any binding to fibrin.
the experimental release findings and details of the diffusion model were reported previously20 six different concentration cases were generated to run in the abm to investigate the effects of varying release rates on angiogenesis.
case a indicates the concentration profile studied in the current experimental system.
cases b, c, d, e, and f indicate 20%, 50%, 200%, 300%, and 500% slower release rate than case a (fig.
3).
to generate slower release conditions, diffusion profiles were expanded by increasing time ticks in the solver.
the concentration data were then multiplied by a correction factor to keep the total pdgf-bb dose (200 ng) the same for all cases.
fig.
3. different release speed of gf from distal layer of biomaterial.
concentration profile within (a) current experimental system (case a), (b)%20 slower (case b), (c)%50 slower (case c), (d)%200 slower (case d), (e)%300 slower (case e), (f)%500 slower (case f).
gf, growth factor.
prevascularized scaffolds capillary segments are replaced into the porous media of modeled scaffolds to create in silico a prevascularized scaffold.
ec agents are randomly located as initial source to start the capillary segments.
ecs are continuously added to the end of capillary chain until the randomly selected location is not a part of the scaffold.
if no pore location is found after several trials, the algorithm stops the capillary chain.
these random stops cause a variation in capillary length within the scaffolds.
experimental studies preparation of gradient scaffolds porous gradient scaffolds were formed using either poly (methyl methacrylate) (pmma) with a sphere templating method (for interconnectivity studies) or salt-leaching method for gf release studies.
details of the methods for scaffold preparation were explained previously.20 briefly, peg (250 mg/ml, mw ∼8000) was dissolved in deionized (di) water containing 0.5% w/v irgacure 1173 (sigma aldrich, st. louis, mo) to prepare hydrogel precursors for both methods.
thrombin (100 u/ml) (sigma aldrich, st. louis, mo) was added to precursor for salt-leaching technique.
templates using pmma microspheres (106–125 μm diameter) (cospheric, santa barbara, ca) were created to make hydrogels with varying npc.
the hydrogel precursor was poured over pmma templates and polymerized under uv light (365 nm) for 5 min.
the hydrogels were washed with acetone several times and incubated in acetone overnight to remove the pmma microspheres.
the hydrogels were then incubated in di water for 2 days.
the resulting hydrogels had a npc of 0.24 and 0.42. for the salt-leached gels, 200 μl of hydrogel precursor was mixed with 400 mg sieved salt crystals (300–500 diameter) and polymerized under uv light (365 nm) for 5 min to generate hydrogels.
hydrogels were incubated in di water overnight to leach out salt crystals.
to generate gf gradients within the scaffolds, pdgf-bb loaded plga microspheres were placed at the top of the hydrogels within a degradable hydrogel layer (poly (ethylene glycol l- lactic acid) (peg-plla)).
different gf concentrations (1, 10, and 100 μg/ml) were encapsulated into plga microspheres and combined with scaffolds.
three hundred microliters of a fibrinogen solution (40 mg/ml in saline) was added dropwise into the pores of the hydrogel.37 then, the gel was incubated at room temperature for 30 min to allow interaction of fibrinogen with thrombin to form the fibrin.
in vivo testing animal experiments were performed at edward hines, jr. va hospital with procedures approved by the institutional animal care and use committee.
the scaffolds were placed in poly(propylene) shells that allowed orientation of the gf source distal to the surrounding tissue.
the opposite end of the scaffold is open to the tissue below (fig.
4).
sterile scaffolds with low (0.24) and high (0.42) interconnectivity, and salt-leached scaffolds with varying gf concentrations (1, 10, 100 μg/ml) were implanted into rodents using a subcutaneous implantation model.20 implants were harvested at 3 and 6 weeks (n = 5 animals for each time point).
hematoxylin and eosin stained sections were imaged using an axiovert 200 inverted microscope (5× objective, 1.10 mm/pixel).
tissue invasion depth was measured as the straight-line distance from the host tissue to the deepest tissue location where tissue could be identified within the scaffold.
fig.
4. formation of multilayer scaffold system.
(a) schematic representation of the gradient scaffold.
(b) gross image of the gradient scaffold.
(c) confocal image of a vertical section of the gradient scaffold indicating presence of the distal layer containing the plga microspheres (blue), underlying porous scaffold structure (green), and fibrin (red) loaded within the pores.
scale bar is 100 μm (with permission from [20]).
plga, poly (lactic-co-glycolic acid).
model evaluation 3d virtual scaffold is assumed to be sliced into three vertical pieces, and the results are averaged over these pieces and reported.
normalized vessel invasion is defined as the distance between host and the deepest part of the scaffold that blood vessels reached over total size of the scaffold in that direction.
normalized anastomosed vessel invasion is defined similarly; however, only blood vessels that were anastomosed and stable were taken into account for calculation.
total capillary length is calculated within the model considering the length of each ec contribution to the blood vessel network.
comparison with experimental data was performed assuming that tissue invasion is equivalent to blood vessel invasion in the model since tissue formation is not explicitly modeled in this study.
statistical analysis statistical analysis was conducted to compare simulation predictions with experimental results for high interconnectivity and high gf concentration cases.
paired student's t-test was used for comparison of normalized invasion depth between different time points in simulation and experiment results, respectively.
unpaired student's t-test was used for comparison of normalized invasion depth between simulation results and experimental data at different time points.
statistical data are expressed as mean ± standard deviation.
values of p < 0.05 were considered statistically significant.
results effect of pore interconnectivity on vascularization simulation results of vessel invasion and anastomosis depth in scaffolds with different interconnectivities indicate that high interconnectivity scaffolds have twice as much vessel invasion compared to low interconnectivity scaffolds (fig.
5).
both high and low interconnectivity had increasing vessel invasion up to week 4. due to decreasing gf levels after the fourth week, the invaded capillaries began to regress and a significant reduction in vessel invasion depth was observed.
the results of anastomosed invasion depth were similar comparing to that of vessel invasion depth until week 4. however, the anastomosed invasion depth remained constant after that.
this is because anastomosed invasion depth represents the invasion of stable vessels that are assumed to establish blood flow and not prone to regression.
after blood flow is maintained, the vessels are treated as independent of gf levels.
no additional sprouting occurred after 4 weeks due to the low gf concentration.
however, capillary regression did not occur and the anastomosed invasion depth remained constant.
in high interconnectivity scaffolds, around 50% of the scaffolds were vascularized by stable vessels by the fourth week, whereas this value is around 30% for lower interconnectivity scaffolds.
the results demonstrated that pore interconnectivity has a significant impact on vessel invasion.
higher npc scaffolds are more permissive for vessels to invade into deeper parts, whereas lower npc scaffolds result in a significant spatial hindrance to vessel invasion.
fig.
5.
(a) normalized vessel invasion and (b) normalized anastomosed vessel invasion depth for biomaterials with low and high interconnectivity.
total blood vessel length observed in both interconnectivities was not significantly different from each other (fig.
6).
this indicated that approximately the same number of capillaries formed in both scaffolds, and the lower interconnectivity scaffolds resulted with higher blood vessel density closer to interface.
fig.
6. total blood vessel length for biomaterials with low and high interconnectivity.
simulation results for vessel invasion depth were compared to experimental studies (fig.
7).
simulation results follow the experimental findings in terms of both absolute value and trends.
there was no significant difference (p > 0.05) in normalized vessel invasion depth at week 3 between the simulation results (0.8289 ± 0.0721) and experimental data (0.8888 ± 0.0719).
same conclusion can be made for week 6. capillary regression was observed for both simulations and experiments from week 3 to 6, which resulted in significant decrease (p < 0.001) of normalized vessel invasion depth (0.7274 ± 0.0587 for experiments and 0.5689 ± 0.0470 for simulations).
fig.
7. comparison of simulation predictions with experimental results for high interconnectivity scaffolds.
**p < 0.05. gradient growth factor delivery the abm model was also used to investigate the effects of different total dose (2, 20, and 200 ng) of gf on vascularization within porous scaffolds.
these total doses of gf correspond to 1, 10, and 100 μg/ml loading concentrations in experimental conditions, respectively.
scaffolds are assumed to have a distal layer that is composed of gf encapsulated microspheres within a degradable layer.
the dynamic concentration gradient was generated based on known gf release kinetics from the degrading microspheres followed by diffusion through the porous polymer scaffolds.
simulations were performed within scaffolds (loaded with 1, 10, and 100 μg/ml of gf) for 6 weeks.
dimensions of the scaffolds used in this study were 4 mm height and 10 mm diameter, consistent with a typical experiment.
scaffold has a heterogeneous pore shape.
the pore size of the scaffold varied between 300 and500 microns, and the porosity was 0.64 ± 0.64si.20 the interconnectivity was not controlled within the scaffold.
figure 8 illustrates the effects of gf concentration on vessel invasion within the scaffold.
the highest concentration (100 μg/ml) resulted in the deepest vessel invasion for all time points.
capillary regression was observed after the fourth week with 100 μg/ml case, whereas regression started immediately after the first week in the 10 and 1 μg/ml cases.
no significant changes in vascularization behavior were observed after the first week in lower concentration gradients.
fig.
8. normalized vessel and anastomosed vessel invasion depth with varying gf concentrations.
different gf concentrations affected total blood vessel length as well (fig.
9).
the highest total blood vessel length was observed in the highest gf concentration.
the slight reduction in capillary length began after the fourth week with the 100 μg/ml case, whereas it happened immediately after the first week with lower gf concentrations.
fig.
9. simulated total blood vessel length with varying total dose of gf concentrations.
the model results were compared with experimental results using peg/fibrin composite hydrogels with increasing concentrations (0, 1, 10, and 100 μg/ml) of pdgf-bb.
the comparison of simulation and experimental results for vessel invasion at the highest gf concentration (100 μg/ml) is presented in figure 10. simulation results showed good agreement with experimental studies and both suggest that gf gradients rapidly accelerated vascularization into the porous scaffolds.
there was significant difference (p < 0.001) in normalized vessel invasion depth in week 3 between the simulation results (0.7202 ± 0.1342) and experimental data (0.4502 ± 0.0337).
capillary regression was observed for both simulations and experiments from week 3 to 6, which resulted in significant decrease (p < 0.001) of normalized vessel invasion depth (0.3788 ± 0.0200 for experiments and 0.4736 ± 0.1147 for simulations).
fig.
10. comparison of simulation predictions with experimental results for 100 μg/ml gf loaded scaffolds.
**p < 0.05. even with the highest concentration case (100 μg/ml), blood vessel regression is observed due to gf reduction at later time points.
previous studies reported that the minimum gf concentration required for cell activation is in the order of 1 ng/ml.36 since this threshold value was implemented into abm, blood vessel regression period was successfully predicted within scaffolds, which mimic the current experimental system.
furthermore, we have investigated varying release rates within the system to eliminate/decrease vessel regression.
the diffusion model was modified to generate concentration profiles with altered release kinetics compared to the currently investigated experimental scaffold.
simulation results of vessel invasion and anastomosis depth for computationally generated slower growth release cases (b, c, d, e, f), but at the same total dose (100 μg/ml), are illustrated.
(fig.
11).
fig.
11. normalized vessel (a) and anastomosed (b) invasion depth for delayed release conditions.
for the control case, vessel invasion depth reached its highest value at around the fourth week and then started to regress.
for the 20% (case b) and 50% (case c), slower release rate did not significantly affect the regression point.
however, 200% slower release resulted in regression occurring after 5 weeks.
the regression time was postponed if we decreased gf release rate, and there is no vessel regression in 300% slower (case e) and 500% slower (case f) even after sixth week.
the initial vessel invasion depth in the slower gf release cases is slightly smaller compared to the control case due to the decreased burst release in the early time points.
however, blood vessel regression was limited in these cases due to the sustained release of gf, which eventually resulted in a larger invasion depth.
the results showed that capillary growth and regression varied significantly with the different release rate of gf and that sustained release promotes scaffold vascularization.
prevascularized scaffolds prevascularized scaffolds can be formed in vitro from seeded ecs before in vivo implantation.38 in this article, we have simulated angiogenesis after the implantation of prevascularized scaffolds.
three configurations of prevascularized biomaterials were generated (fig.
12).
in the first case, the entire scaffold medium was filled with capillary segments.
in the second and third cases, either the bottom or top half part of scaffolds in y-dimension was prevascularized, respectively.
vascularization was investigated in all structures, and results were compared with a control case where there were no preformed capillaries (fig.
13).
simulation runs were performed under high gf (100 μg/ml) concentration and scaffolds with higher interconnectivity.
fig.
12. normalized anastomosed vessel (a) and vessel invasion depth (b) for prevascularized scaffolds.
fig.
13. simulation interface for homogeneous (left), top half (middle), and lower half (right) prevascularized scaffolds.
entirely prevascularized (homogeneous) scaffolds showed highest and fastest final vessel invasion.
top-half prevascularized structures showed slightly lower and initially slower vessel invasion compared to homogeneous case.
bottom-half prevascularized case resulted in high initial invasion, but after second week it was only slightly better than the control case.
over 50% of the scaffold was vascularized with anastomosed vessels in top and entirely prevascularized cases within the first 2 weeks, whereas in the control and lower prevascularized cases, this took 6 weeks.
the connection between the preformed vessels and the capillaries from the host enabled more blood flow circulation through the vessels, resulting in stable vessels that resist regression.
regression was reduced significantly after fourth week in top and entirely prevascularized scaffolds.
discussion the aim of this study was to develop a computational framework for studying the combined effects of scaffold design, gf release kinetics, and use of preformed capillaries on biomaterial vascularization.
simulation results were compared with experimental findings.
both simulation runs and experimental studies showed that properly designed scaffolds can lead to well-vascularized scaffolds.
vascularization is greatly influenced by pore interconnectivity, with smaller openings between pores hindering blood vessel invasion into the scaffolds.
controlled gf release is a common approach to engineer tissues.
many in vivo experiments have shown that gfs can enhance scaffold vascularization in a variety of ways.39–42 we analyzed both the effect of magnitude and release kinetics of gfs on scaffold vascularization.
the invasion depth was influenced by the total dose.
higher concentration (100 μg/ml) resulted in greater vessel invasion compared to lower doses (1 and 10 μg/ml).
even with the highest concentration case (100 μg/ml), endothelial capillary regression is observed due to the gf reduction at later time points.
furthermore, we investigated the role of release rates within the system on vascularization.
scaffolds were generated with gfs at the same dose, but slower release kinetics.
the comparison between control case (matched to experimental conditions) and slower release cases demonstrates that sustained slower release can promote more persistent vessel networks, deeper vessel invasion, longer total blood vessel length, and larger anastomosed depth.
although diffusion profiles were created computationally, these results can guide experimental studies.
gf release can be varied by modifying degradable layer of the scaffold in future experiments.
even though scaffolds with high interconnectivity, higher gf dose, and sustained gf release showed better vascularization results, the rate of vascularization was still limited relative to engineering large volume tissues.
at the end of 6 weeks, only ∼50% of the scaffold was vascularized.
in these systems, vascularization depends on mainly gf concentration, physical structure of the scaffold, and host vasculature.
however, the presence of preformed networks within the scaffold may enhance vascularization.
the prevascularized scaffold strategy was added to the model.
the presence of preformed capillary segments significantly improved the rate of vascularization.
over 50% of the scaffold was vascularized within the first 2 weeks, and almost 80% of scaffold was vascularized by the end of the sixth week.
the results were consistent with the finding from the literature that reported that preformed capillaries were connected to the host microvasculature and established of blood perfusion significantly faster compared with controls.43 abm is also used to simulate experimentally not tested cases such as top and bottom only prevascularized scaffolds and suggested that when the top half is prevascularized, final vessel invasion can reach to deeper parts in the scaffold.
conclusion success in tissue regeneration is inherently linked with successful vascularization.
the model developed in this study allows researchers to screen various hypotheses rapidly and explore alternative strategies to enhance vascularization.
simulation results were supported with experimental findings and suggested optimal designs and conditions for vascularization of engineered biomaterials.
@highlight
abstract stable and extensive blood vessel networks are required for cell function and survival in engineered tissues.
a number of different strategies are currently being investigated to enhance biomaterial vascularization with screening primarily through extensive in vitro and in vivo experiments.
in this article, we describe an agent-based model (abm) developed to evaluate various strategies in silico, including design of optimal biomaterial structure, delivery of angiogenic factors, and application of prevascularized biomaterials.
the model predictions are evaluated using experimental data.
the abm developed provides insight into different strategies currently applied for scaffold vascularization and will enable researchers to rapidly screen new hypotheses and explore alternative strategies for enhancing vascularization.
