1. introduction plants possess a number of biological and pharmacological activities including anticancer, anti-inflammatory, diuretic, oxytocic, laxative, antispasmodic, antihypertensive, antidiabetic, and antimicrobial functions.
numerous biological active products have been extracted from plants and have been used extensively as drugs, additives, flavours, insecticides, colorants, and fragrances [1].
in addition, the use of plants and plant-derived compounds for medicinal purposes is attracting interest as complementary and alternative therapies in many developed countries [2].
the plant with the tapered dark-colored roots, glossostemon bruguieri (known as moghat in egypt), is a shrub, briefly mentioned in avicenna's the cannon of medicine, and one of the members of the cacao family sterculiaceae [3].
g. bruguieri grows wild in iraq and iran from where it was imported and introduced to egypt in 1932 [4].
the hot syrup prepared from powdered moghat peeled roots is used for the treatment of spasms and as a mucoprotective agent [5].
due to its high content of mucilage (35%), the syrup is customarily used by nursing mothers to induce lactation [6].
other constituents isolated from moghat include proteins [7], estrone [8], amino acids, scopoletin [9], and the flavonoid takakin 8-o-glucoside [10].
moreover, 80% of the total fatty acids extracted from moghat roots are oleic and linolenic acids.
in addition, the roots possess major minerals (iron, calcium, and magnesium) and minor minerals (copper, zinc, and manganese) [11].
it is understandable that very few studies have investigated the biological effects of moghat root extract (mre) since the plant is not well known in western countries.
in addition, as far as we know, reported studies did not include any investigation of the effect of mre on different cancers.
it was reported that mre can lower the blood glucose level in diabetic rats by 54.5% in 15 days [9].
in addition, mre decreased osteoclastic resorption and increased osteoblastic formation markers in rats with juvenile osteopenia [12].
furthermore, emodin, a natural product from g. bruguieri, inhibited tnf-induced nf-kb activation, ikba degradation, and expression of cell surface adhesion proteins in human vascular endothelial cells [13].
hepatocellular carcinoma (hcc) has increased threefold during the last fifteen years in egypt and topped the mortality statistics for cancers (23.2%) [14].
more than 500,000 individuals suffer from this disease annually and the front-line treatment for hcc is liver transplantation or resection [15].
despite surgical or locoregional therapies, prognosis remains poor because of high tumor recurrence or tumor progression.
taking this into account and from the rationale that the uncommon ethnopharmacological uses of g. bruguieri deserve further study to investigate its biological activities, we aimed to evaluate the effect of mre on hcc cells and hepg2 and hep3b cell lines.
in addition, we investigated the possible pathways by which mre induces apoptosis in hcc cells.
2. material and methods 2.1. materials all the general purpose chemicals were purchased from sigma-aldrich, thermo fisher scientific, and bdh analar unless otherwise stated.
general cell culture reagents were purchased from lonza (verviers, belgium).
fbs was purchased from hyclone (thermo fisher scientific).
hepg2 cell line was purchased from the american type culture collection (rockville, md, usa).
moghat roots (glossostemon bruguieri) were purchased from egyptian local herbal market and authenticated by professor m. ibrahim, botany and microbiology department, faculty of science, alexandria university, egypt.
2.2. methods 2.2.1. preparation of moghat roots extracts moghat roots extract (mre) preparation.
moghat roots were screened manually to remove bad ones.
the dry roots were ground three times using an electric grinder.
the powder was extracted in boiled sterilized distilled water, filtered, and concentrated with minor modification [16].
the extract was reconstituted in dimethyl sulfoxide (dmso) to a working stock concentration of 50 mg/ml for further in vitro experiments.
moghat roots organic extract preparation for gc-ms analysis.
20 gm of the power-driven screened dry moghat roots was successively extracted with n-hexane, chloroform, ethyl acetate, and alcohol (95%) separately using soxhlet apparatus.
the extracts were collected and concentrated in vacuum in a rotary evaporator at 50°c, and 2 μl of the extract, containing both polar and nonpolar compounds, was used in gc-ms analysis.
2.2.2. cell culture hepg2 and hep3b cells were maintained in dmem supplemented with fbs (10%, v/v), penicillin (100 u/ml), and streptomycin (100 μg/ml).
cells were maintained in 5% co2 at 37°c.
the confluent cells were passaged with trypsin-edta.
untreated medium containing vehicle dmso was used as a negative control.
normal liver specimens were collected with the informed consent of the patients, according to georgetown university institutional review board (washington, dc) protocols.
normal primary liver human hepatocytes were established as previously reported [17] with some modifications (sultan and albanese; data under publication) to indefinitely extend the life span of primary human keratinocytes, using a rho-associated kinase (rock) inhibitor, y-27632 [18], with no feeder cells.
epithelial cells were cocultivated in f medium [3 : 1 (v/v) f-12 nutrient mixture (ham)-dulbecco's modified eagle's medium (invitrogen), 5% fetal bovine serum, 0.4 μg/ml hydrocortisone (sigma-aldrich), 5 μg/ml insulin (sigma-aldrich), 8.4 ng/ml cholera toxin (sigma-aldrich), 10 ng/ml epidermal growth factor (invitrogen), and 24 μg/ml adenine (sigma-aldrich)] with addition of 5 to 10 μmol/l y-27632 (enzo life sciences).
2.2.3. mtt assay hepg2 and hep3b cells were cultured till midlog phase in a 96-well plate at a density of 2 × 104 cells/well for 24 h prior to treatment with different concentrations (0 to 2000 μg/ml) of mre (control cells with vehicle only).
the cells were washed twice with pbs after 48 h of incubation.
then mtt reagent (20 μl of 5 mg/ml) (promega, madison, wi, usa) was added to each well.
after 4 h incubation at 37°c, the medium was discarded and cells were incubated with 100 μl of dmso.
the plate was shaken on a microvibrator for 5 min and the absorbance was measured at 570 nm.
in order to achieve significant quantitative analysis, experiments were repeated at least 3 times in triplicate and compared with untreated control experiments.
2.2.4. cell morphological analysis hepg2 cells were seeded into 12-well culture plates at a density of 2 × 105 cells.
after 24 h, cells were treated with fresh medium containing either 1/10 or 1/2 the calculated ic50 for mre and incubated in 5% co2 at 37°c.
the mock sample received equal volume of medium with dmso.
after 48 h, treated and untreated cells were examined and cell images were taken using an inverted phase contrast microscope (optika, italy) at 200x magnification.
2.2.5. enzyme linked immunosorbent apoptosis assay 2 × 104 cells were seeded in a 96-well plate for 24 h. media were changed to media containing mre dose (1/10 or 1/2 the ic50).
cells were incubated for extra 24 h. to measure histone release from fragmented dna in apoptosing cells cell death detection elisa plus kit (roche-applied science, indianapolis, usa) was used.
cells were lysed with 200 μl lysis buffer for 30 min at rt.
the lysates were subjected to 10 min spin and 200 μl of supernatant was collected, of which 20 μl was incubated with antihistone biotin and anti-dna peroxidase for 2 h at rt.
after three washes with incubation buffer, 100 μl of substrate solution 2,2′azino-di (3-ethylbenzthiazolin-sulphuric acid) was added to each well and incubated for 15–20 min at rt.
the absorbance was measured using an elisa reader (jenway spectrophotometer, uk) at 405 nm.
each assay was done in triplicate and the standard deviation was calculated.
2.2.6. caspase-3 activity caspase-3 activity was assayed according to manufacturer's protocol (assay designs, usa).
5 × 106 cells were lysed in 100 μl lysis buffer containing 10 mm hepes (4-(2-hydroxyethyl)-1-piperazineethanesulfonic acid), ph 7.4, 2 mm edta, 0.1% chaps 3-[(3-cholamidopropyl)dimethylammonio]-1-propanesulfonic acid, 5 mm, 350 μg/ml pmsf (phenylmethanesulfonylfluoride), and 5 mm dtt (dithiothreitol).
cells were homogenized by three cycles of freezing and thawing and then centrifuged to remove cellular debris.
each sample was incubated in buffer containing 10 mm hepes, ph 7.4, 2 mm edta, 0.1% chaps, and 5 mm edta supplemented with its substrate (ac-asp-glu-val-asp-afc) ac-devd-afc for 1 h at room temperature and then the reaction was stopped with 1 n hcl.
the absorbance at 405 was measured using a spectrophotometer (jenway spectrophotometer, uk).
each assay was done in triplicate.
2.2.7. western blot analysis hepg2 and hep3b cells were seeded into 6-well plates and were treated with fresh medium containing either 1/10 or 1/2 the calculated ic50 for mre and incubated in 5% co2 at 37°c.
the mock sample received equal volume of medium with dmso.
after 48 h, cells were lysed in ice-cold ripa lysis buffer supplemented with 1x protease inhibitors cocktail (complete mini®, roche, germany) and phosphatase inhibitors (sigma) for 45 min on ice, followed by centrifugation at 10,000 g for 15 min at 4°c.
the supernatant was harvested, and the protein concentrations were determined using the bca assay (pierce).
samples were mixed in a ratio of 1 : 2 in loading buffer and denatured by heating at 98°c for 5 min.
50 μg/μl of total proteins was separated on 10% tris-sds-page gels (bio-rad laboratories, usa) at 100 v for 1 h. the separated proteins were transferred to pvdf membrane (bio-rad laboratories, usa) at 380 ma for 1 h. the membranes were blocked for 1 hour at room temperature with 5% skimmed milk in tbs (20 mm tris-hcl, ph 7.6, and 137 mm nacl) and probed overnight with the primary antibodies (1 : 1000) at 4°c.
the following antibodies were used: p53, pcna, p21, fas, bax, and parp (santa cruz biotechnology, ca, usa) and β-actin (sigma).
blots were washed and incubated with horseradish peroxidase-conjugated secondary antibodies (santa cruz biotechnology, ca, usa) for 1 h at room temperature.
the immunoreactive bands of proteins were detected using ecl kit according to the manufacturer's instructions (amersham, uk).
protein bands were quantified using quantity one software (bio-rad laboratories, usa).
protein levels were normalized against untreated control and β-actin.
2.2.8. gas chromatography-mass spectrometry (gc-ms) analysis the gc-ms analysis of the alcoholic extract of g. bruguieri roots was carried out using a perkin-elmer gc clarus 500 system (autosystem xl) comprising a gas chromatograph interfaced to a turbo-mass gold-perkin-elmer mass-detector (gc-ms) equipped with elite-1ms (100% dimethyl polysiloxane) fused capillary column (30 m × 0.25 mm id × 1 μm).
for gc-ms detection, an electron ionization system was operated in electron impact mode with ionization energy of 70 ev.
99.99% helium gas was used as a carrier gas at a constant flow rate of 1 ml/min, and the injection volume was employed at a split ratio of 10 : 1. the injector temperature was maintained at 250°c, the ion-source temperature was 200°c, and the oven temperature was programmed from 110°c (isothermal for 2 min), with an increase of 5°c/min to 280°c, ending with a 9 min isothermal at 280°c.
mass spectra were taken at 70 ev and the mass spectral scan range was set at 45–450 (m/z).
the relative percentage of each component was calculated by equating its average peak area to the total areas.
turbo-mass ver-5.2 software was adopted to handle mass spectra and chromatograms.
2.2.9. identification of phytocompounds the database of wiley 275.1 ms library was used for interpretation on mass-spectrum of gc-ms. the spectrum of the unknown components was compared with the spectrum of known components stored in the wiley 275.1 ms library.
the name, molecular weight, and formula of the components of mre were determined.
2.3. statistical analysis the results were presented as the mean ± sd of at least three independent experiments.
a one-way analysis of variance (anova) was performed using the prism statistical package (graphpad software, usa).
p value was calculated versus control cells: #p < 0.01 and ∗p < 0.001 were considered statistically significant.
3. results 3.1. mre inhibited growth and proliferation of hepg2 and hep3b cells but not normal human hepatocytes to explore the growth-inhibitory potency of mre on hepatocellular cells, cell proliferation was determined by mtt assay.
the cytotoxic effects of mre on hepg2 and hep3b cells were determined by treating cells with varying concentrations of mre (0–2000 μg/ml) for 48 hrs.
in addition, normal liver hepatocytes were treated with different concentrations of mre (0–10 mg/ml) for 48 hrs.
the data indicate that treatment of cells with increasing concentrations of mre resulted in significant inhibition of cell viability in a dose-dependent manner when compared to untreated controls (figure 1(a)).
mre was found to inhibit the proliferation of hepg2 and hep3b cells in a dose-dependent manner.
after 48 hours of exposure to mre, 65% of the hepg2 cells and 70% of the hep3b cells were observed to be dead at the highest concentration (2 mg/μl).
growth was inhibited even at lower concentrations of mre.
the concentration at which 50% inhibition of cell viability (ic50) was calculated using semilogarithmic plotting of the percentage of cell viability versus concentration used for mre.
the ic50 of mre for hepg2 (910 ± 6 μg/ml) and for hep3b (1510 ± 5 μg/ml) induced a significant decrease in survival of both cell lines when compared to untreated control after 48 hrs treatment (figure 1(b)).
normal hepatocytes showed no significant antiproliferative effect for mre treatment (figure 1(c)).
for subsequent experiments two different concentrations for mre will be employed as follows: 91 and 455 μg/ml for hepg2 cells and 151 and 755 μg/ml for hep3b cells, which represent 1/10 and 1/2 mre ic50, respectively.
3.2. mre induced morphological changes in hepg2 cells to examine the effect of mre on the morphology of hepg2 cells, cells were cultured and treated for 48 hrs with 91 or 455 μg/ml mre.
as shown in figure 2, microscopic examination of the treated cells showed that the treatment with the higher concentration of mre resulted in dramatic morphological changes in hepg2 cells.
we observed changes in the morphology of cells from elongated and spindle shape to rounded and epithelial-like shape.
the monolayer cells became rounded up, lost contact with neighboring cells, and were largely detaching from culture plate.
48 hrs posttreatment, cells showed altered normal morphology, shrinkage, tendency to float in the medium, and reduction in size in comparison to the untreated controls that were well spread with a flattened morphology.
taken together mre induced morphological changes in the hepatocellular carcinoma hepg2 cell line.
3.3. apoptosis is induced in mre-treated hepg2 cells our data indicated that mre significantly decreased cell viability and significantly altered the morphology of hepg2 cells after mre treatment compared to control untreated cells (figures 1 and 2).
to investigate if the decrease in the viability of cells was due to induced-apoptosis, enzyme linked immunosorbent apoptosis assay was performed, which detects histone release from apoptotic cells.
as shown in figure 3(a), 48 hrs treatment of hepg2 with either 91 or 455 μg/ml mre confirmed that the tested mre-induced cell death was due to apoptosis as indicated by histone release when compared to untreated control cells.
3.4. mre induced caspase-3 activation in hepg2 cells our data indicated that caspase-3 activity was significantly increased in mre-treated hepg2 cells when compared to control cells.
as shown in figure 3(b), mre at the apoptosis-inducing concentrations (91 and 455 μg/ml) significantly induced caspase-3-like activity in hepg2 cells.
these results demonstrate that the active tested mre induced apoptosis of hepg2 cells in a caspase-dependent manner.
3.5. mre induced g1 phase arrest in hepg2 cells to determine whether mre's growth-inhibitory effect was caused by specifically perturbing cell cycle-related events, cell cycle analysis by flow cytometry analysis was carried out.
figure 4 shows the relative percentages of hepg2 cells in each phase of the cell cycle, following 48 hrs treatment with different mre concentrations.
mre treatment induced the accumulation of g1 phase of cell cycle in a concentration-dependent manner in hepg2 cells with increase of subg1 population after mre treatment with 1/10 and 1/2 mre ic50, respectively.
this data suggested that the growth inhibition of hepg2 cells was the result of a g1 phase arrest and through apoptosis induction.
3.6. mre induced p21 and g1 arrest in hepg2 in a p53-dependent manner since it was reported that the tumor-suppressor p53 regulates a dna-damage-triggered g1 checkpoint by upregulation of cdk inhibitor p21, we examined the expression patterns of p53 and p21 after mre treatment.
as shown in figure 5, hepg2 (wild-type p53) cells treated with mre showed an increase in the protein expression of p53 and p21 in a concentration-dependent manner.
in contrast, hep3b cells treated with mre showed no p53 protein expression with no changes in the protein levels of p21 after 48 hrs.
in addition, the protein expression levels of pcna were examined by western blot analysis in mre-treated hepg2 cells.
pcna protein expression was upregulated only in hepg2 cells with the treatment with the higher concentration of mre (455 μg/ml), but there was no changes in the protein expression levels of pcna in case of hep3b cells.
the inhibitory effect of mre treatment on hep3b cells may involve another mechanism rather than p53 and p21.
3.7. mre triggered apoptosis in hep3b in a p53-independent manner we investigated whether the expressions of fas, bax, and parp were modulated by mre treatment.
the treatment of hep3b cells (expressing no p53) with mre resulted in a concentration-dependent increase in the expression of fas, but not in hepg2 cells.
in addition, mre treatment significantly increased bax expression in a concentration-dependent manner in both hepg2 and hep3b cells.
parp cleavage was also measured in mre-treated hcc cells.
a significant increase of cleavage forms of parp was observed in both cell lines in a concentration-dependent manner (figure 5).
3.8. gc-ms analysis of glossostemon bruguieri roots organic extract the gc-ms analysis of the organic extract of g. bruguieri roots is resolved into 21 peaks.
as shown in figure 6, in terms of percentage peak area, ten major peaks were determined in the gc-ms chromatogram.
the compounds, corresponding to the 21 peaks, were compared with wiley 275.1 ms library and the compounds' name, retention time, molecular formula, molecular weight, and concentration (peak area%) are presented in table 1. these compounds were mostly flavonoids (38.9%), terpenoids (26.15%), and fatty acid derivatives (16.2%).
two major constituents were identified in the extract: the flavonoid apigenin (17.04%) and the terpenoid squalene (11.32%).
the remaining components were considered as minor constituents and ranged between 0.8% for the phenolic compound chlorogenic acid and 6.49% for the flavonoid kaempferol.
4. discussion currently there is a mounting interest in the use of phytocompounds to develop safe and more effective therapeutic agents for cancer treatment [19, 20].
phytochemicals are a promising group of potential cancer chemopreventive agents because of their low toxicity and their important role in treatment and prevention of human diseases [21, 22].
phytochemical antioxidative and anti-inflammatory activities have demonstrated potent anticancer activity in multistage carcinogenesis [23].
g. bruguieri (moghat), family sterculiaceae, grows wild in iraq and iran from where it was imported and introduced to egypt in 1932 [24].
it is considered as a remarkable food supplement and possesses significant hypoglycemic activity [9].
on the basis of dry matter, moghat roots contain 35% mucilage, 24% starch, 5.5% protein, 5% fats, 5% pectin, 3% sugars, and amino acids (majorly aspartic and glutamic acids) [25].
they also contain major minerals (calcium, iron, and magnesium) and minor minerals (zinc, copper, and manganese), as well as high amounts of oleic and linolenic acids [11].
in egypt, sundried, powdered moghat roots are given in the form of hot syrup to nursing mothers as a nutritive and demulcent drink to stimulate lactation.
the powdered roots are cooked with butter, sugars, nuts, and coconut in boiling water [6].
it was reported that the powder and alcoholic extract of g. bruguieri roots when administrated orally to mice proved to be nontoxic up to 2500 mg/kg body weight [9].
also, the acute and subchronic toxicity of the aqueous moghat extract were evaluated.
the ld50 was higher than 10 g/kg in an acute toxicity study.
in a subchronic toxicity study, doses of 200–1000 mg/ml had no hepato- and/or nephrotoxicity while the dose of 2000 mg/ml showed slight hepato- and nephrotoxicity [12].
to our knowledge, the antineoplastic effects of moghat root extracts (mre) are not well documented, and this is the first study to demonstrate mre apoptotic effects on hcc cells.
in the present study, we investigated the role of mre on cell death for two hcc cell lines, hepg2 and hep3b cells.
mre induced g1 cell cycle arrest and cell proliferation inhibition in hcc cells.
our data showed that the viability of hepg2 and hep3b cells was significantly reduced in a concentration-dependent manner after mre treatment.
mre treatment exhibited significant cytotoxicity reaching the maximum effect with treatment with the highest concentration of mre (65% and 70% death in hepg2 and hep3b cells, resp.).
no cytotoxic effect on normal human hepatocytes was observed.
the results of the enzyme linked immunosorbent apoptosis assay on hcc cells after mre treatment revealed significant induction of apoptosis.
the activation of caspases, intracellular cysteine proteases, is one of the key events in apoptosis [26].
the typical morphological and biochemical characteristics observed in apoptosis are attributed in part to the cleavage of various substrates by caspases.
caspase-3 is a general mediator of physiological and stress-induced apoptosis [27].
here, the activity of caspase-3 increased significantly in mre-treated hcc cells.
in agreement, the phytochemical diosgenin showed a chemopreventive effect against several human cancer cells via the activation of p53 and the modulation of caspase-3 activity [28].
in addition, the methanolic extract of black cumin (nigella sativa) induced apoptosis in breast cancer cell line via p53 and caspases [29] and induced cytotoxicity against lung cancer cell line [30].
furthermore, diosgenin and the phytochemical thymoquinone isolated from fenugreek (trigonella foenum-graecum) and nigella sativa, respectively, induced activation of caspase-3 through the stimulation of mitochondrial cytochrome c release in squamous cell carcinoma [31].
the same observations were reported in hl60 cells undergoing thymoquinone-induced apoptosis [32].
taken together, these results demonstrate that the active tested mre induced apoptosis in hcc cells in a caspase-dependent manner.
being equipped with the tumor-suppressor and transcription factor activities explains the critical role of p53 in many cellular processes including dna-damage response, genomic stability, cell cycle control, and apoptosis.
p53 inhibits the growth of dna-damaged cells and cancer cells by inducing apoptosis through activating the transcription of downstream apoptosis-related genes such as p21cip1/waf1 and bax [33].
many studies reported the treatment with phytochemicals, in different experimental model systems, such as the green tea polyphenol and epigallocatechin-3-gallate (egcg) in hepg2 cells and lncap cells [34, 35], curcumin in human breast cancer cells and neuroblastoma [36, 37], resveratrol in neuroblastoma and thyroid carcinoma cell lines [37, 38], and diosgenin in human colon and lung cancer cell lines [39, 40].
these phytochemicals have been shown to suppress cell progression and induce apoptosis mainly by increasing the expression of p53 protein.
since p53 has been shown to be upregulated in different tumor cells after treatment with phytochemicals, we examined whether mre could affect the expression of p53.
in agreement with earlier reports, we found that mre upregulated p53 protein level after treatment for 48 h, suggesting that p53 upregulation may be responsible for the inhibition of cell viability and apoptosis induction in treated hepg2 cells which in turn could be associated with the regulation of cell cycle-related p53 gene.
in disagreement with our result and although curcumin is a powerful inhibitor of tumor cell proliferation, however, it induced growth arrest and apoptosis of b cell lymphoma and human melanoma cells by downregulating p53 (p53-independent mechanism) [41].
as reported previously, hepg2 cells exhibit a wild-type inducible p53 activity [42], which in turn may explain the involvement of the upregulation of p53 in the mre-induced apoptosis in hepg2 cells.
interestingly, despite the foregoing, treatment with mre has an inhibitory effect on hep3b cells, the inhibitory mechanism may not involve the p53/p21 axis, and another mechanism may be involved in the inhibitory process.
our data demonstrated that p53 and p21 might be crucial for mre-induced apoptosis in hepg2 but not in hep3b cells.
the results from the comparative study between hepg2 and hep3b cells suggested that mre induced cell death through p53-dependent mechanism in hepg2 cells.
this was not the case for hep3b cells that showed no p53 expression, and in turn the expression level of p21 was not altered despite significant increases in bax and parp expression levels.
this suggests that mre may be able to induce cell death and apoptosis in hep3b cells through a p53-independent mechanism.
pcna is a crucial factor in maintaining the balance between survival and cell death [43].
here in this study we aimed to compare the total protein levels of pcna and the proliferative states of mre-treated cells with the untreated control cells.
the results here show that mre-treated hepg2 exhibited upregulated expression of p53, p21, and pcna when compared to the untreated controls.
interestingly, hep3b cells exhibited no alteration in pcna expression levels after mre treatment.
pcna is involved in dna repair and serves as a cofactor in s-phase for dna polymerase delta [44].
pcna has been reported to participate in the regulation of apoptosis, either by suppressing antiapoptotic proteins, including the gadd45 family (gadd45, myd118, and cr6) in somatic cells, or by promoting proapoptotic proteins, such as ing1 [45–47].
the competitive binding of ing1 to pcna through a site used by growth regulatory and dna-damage proteins has been shown to induce apoptosis [46].
although mcl1 (ml1 myeloid cell leukemia 1) is known to function as an antiapoptotic protein, it was demonstrated that the overexpression of mcl1, the only bcl-2 family protein to interact with pcna, decreased brdurd uptake, in hela cells, in a pcna-dependent fashion.
in this context, the upregulation of mcl1 arrested cell cycle progression via interaction with pcna and prevented cells from replicating altered dna.
the mechanism may involve the use of a different region within the mlc1 molecule to facilitate apoptosis [48].
moreover, the reduction in the pcna content by sirna significantly reduced the levels of pcna–mutsα–mutlα protein complex that form on damaged dna in human cells exposed to alkylating agents.
pcna sirna treatment suppressed the increase in the caspase-3 activity, a hallmark for the induction of apoptosis [49].
additionally, pcna gene expression was upregulated in immortalized human endothelial cells undergoing p53-mediated apoptosis [50].
other studies reported the involvement of the upregulation of pcna with apoptosis in normal cells.
when the expressions of apoptosis-related genes, after pcna rnai in mouse oocytes, were investigated, the mrna levels of bax, caspase-3, and tnfα decreased significantly accompanied by increased expression of bcl-2.
also, all the autophagy markers that were tested (lc3i, lc3ii, atg5, and becn1) did not show any changes after pcna rnai.
these results indicated that the increase in oocytes in pcna rnai ovaries resulted from decreased oocyte apoptosis rather than autophagy [51].
p21 is p53 inducible and is a general cyclin-dependent protein kinase inhibitor [33].
in addition, it was reported that the human pcna promoter can be transactivated by the wild-type p53 [52].
p21 is capable of competing with pcna-binding proteins to disrupt dna replication/repair machinery and to inhibit cell proliferation [53].
the p21-pcna association does not affect the overall structure of pcna or the pcna-dna association [54].
the binding of p21 to pcna would interfere with the function of pcna to synthesize dna effectively, thereby impeding cell cycle progression [55].
other studies have suggested that p21 is required to assist disassembly of pcna from repair sites [56].
p21 inhibits dna synthesis not only by binding to pcna [55, 57] but also by binding to the cdks [58].
it was shown that the base excision repair (ber) activity was induced and accompanied by the upregulation of p53 and pcna in human colon cancer cell lines treated with the naturally occurring selenomethionine.
the mechanism is p53-dependent and requires the binding of gadd45a with pcna and the endonuclease ape1/ref-1 [59].
gadd45a, the growth arrest and dna-damage-inducible protein 45a, is one of the p53-activated downstream genes [60].
the activity of gadd45a can be decided by its binding partners, and the binding of either pcna/cdc2 or p21 to gadd45a can mediate cell cycle arrest or dna repair, respectively [61].
additionally, the human p57 protein, like p21, contains a pcna-binding domain within its c terminus.
the p57-pcna complex can prevent dna replication in vitro and s-phase entry in vivo.
thus, the control of cell cycle by p57 requires pcna inhibitory activity, and disruption of this function may lead to uncontrolled cell growth [62].
to explore the possible apoptotic mechanism induced by mre in hep3b cells, we investigated the expression pattern of fas, bax, and parp proteins in hepg2 and hep3b cells after mre treatment.
we found that mre-induced apoptosis was associated with mitochondria-mediated pathway in hep3b including the upregulation of bax, caspase-3 activation, and parp.
additionally, mre also activated fas-mediated apoptosis pathway as evident by upregulation in fas expression in hep3b, not in hepg2 cells.
mre may have induced the release of cytochrome c and caspase-3 activation as reported previously [63].
activated caspase-3 subsequently cleaves parp, which serves as a hallmark of apoptosis [64].
these results suggest that mre induced apoptosis of hep3b cells via a mitochondria-mediated intrinsic apoptosis pathway.
it was reported that the binding of fas receptor to its ligand and the activation of caspases, including caspase-3, forms a death-inducing signal complex efficient in killing tumor cells and inducing apoptosis [65, 66].
the present study showed that the protein expression of fas was upregulated and caspase-3 was activated with mre treatment.
these results suggest that a fas-mediated extrinsic pathway might play a critical role in mre-induced apoptosis in hep3b cells.
taken together, these data suggest that mre could induce apoptosis of hep3b cells through mitochondria- and fas-mediated caspase-dependent pathways.
these mechanisms have been reported previously using different agents to induce apoptosis of hcc cells [67–69].
venturi et al.
reported the detection of two pcna expression patterns in human liver tumors and cell lines [70].
the different pools of pcna might act together and at the same time to carry out different functions within different signaling pathways, as reported previously [71].
taken together, during cell cycle arrest, pcna protein may form complexes with several proteins (p21, p57, gadd45, myd118, cr6, ing1, mcl1, mutsα, and mutlα).
pcna functions and interactions are modulated by posttranslational regulation which is thought to guide pcna to the correct partner protein at the correct time to perform a specific function [70].
studies suggest that pcna is the supervisory molecule in life of the cell, forcing it to replicate dna, arrest the cell in g1 or g2 phase, repair damaged dna, or obligate the cell to apoptosis, based on the interactions with a plethora of proteins [72].
it was speculated that an increase in the expression of pcna may create a disorder in the signals involved with dna synthesis.
this disorder may result in mitotic catastrophe and induction of apoptosis [73].
mechanistically, it was reported that the histone lysine methyltransferase setd8 promoted carcinogenesis by deregulating pcna expression [43].
furthermore, pcna-mutsα-mediated binding of mutlα to replicative dna with mismatched bases to induce apoptosis, a mechanism that may explain how p21 retained its function of cell cycle arrest while pcna is occupied by the interaction with another protein partner and preventing cells from replicating altered dna.
how does pcna fulfill its function as an executor of apoptosis?
how the complexes that form between different binding partners and pcna are recognized by the cell?
and many more questions when answered will shed more light on pcna regulation on the global cell life.
based on the high antiproliferative activity of mre against hcc cells, the organic extract of moghat roots was subjected to gc-ms analysis to analyze its constituents.
21 compounds have been identified from the organic extract of g. bruguieri roots by gc-ms analysis.
the prevalent compounds were flavonoids, terpenoids, and fatty acid derivatives.
two major constituents were identified from the gc-ms results: apigenin and squalene.
very recently, a number of studies have focused on the activity of apigenin.
these studies reported different activities for the flavonoid: antileukemic activities [74], increased chemosensitivity of cancer cells to drugs [75], anti-inflammatory activities [76], inhibition of nitric oxide production [77], and immune balance during inflammation [78].
in addition, apigenin was presented as a promising molecule for cancer prevention [79].
furthermore, apigenin possesses antiatherogenic and vasoprotective properties [80, 81].
for squalene, it is known to be involved in the biosynthesis of phytosterol or cholesterol in plants or animals [82].
it was reported that squalene enhances the adaptive immune responses, as an adjuvant, by helping to generate antigen-specific t cells via antigen-carrying neutrophils and il-18 [83].
in addition, it was reported that, after oral administration of 100 mg/kg flos chrysanthemi extract in rats, apigenin exhibited auc(0–12), t1/2z, and cmax equal to 36.25 ± 16 mg/lh, 18.44 ± 12 h, and 3.310 ± 0.73 mg/l, respectively [84].
squalene, in a vaccine formulation, can assist in eliciting a stronger immune response while maintaining an adequate reactogenicity and safety profile [85].
recently squalene-containing oil-in-water emulsion adjuvants have been approved for use in certain influenza vaccines [86].
in addition, squalene was also reported to have chemopreventive, antioxidant, pesticide, and sunscreen activities [87].
also, it was reported that 60–85% of dietary squalene can be absorbed from an oral dose.
up to 90% of the postabsorptive dose is transported in serum until it is distributed ubiquitously in human tissue [88].
rather than their therapeutic effects, plants are mostly used for food consumption.
the phytochemical content of a particular plant, although it is genetically determined, also very much depends on the growing environment [89].
it must be noted that the phytochemical extraction protocol could affect the activity of extracted constituents according to previous observations.
in the same context, some of the compounds of the hexane extract of fenugreek have been found to be more active in intrinsic apoptotic pathway rather than extrinsic pathway, which might be due to the presence/absence of methanolic soluble compounds [90].
5. conclusions overall, our study demonstrates that mre induced g1 phase arrest and apoptosis induction through p53/p21 axis and upregulation of pcna signaling in a caspase-dependent manner in hepg2 cells, suggesting that p53/p21 might be a key axis in the g1 cell cycle arrest of hepg2 cells but not in hep3b cells (with no p53 expression).
in addition, fas- and mitochondria-mediated pathways were found to be involved in mre-induced apoptosis in hep3b cells.
our findings suggest that moghat roots may have some active constituents that may have a potential antitumor effect, and further investigations on the phytoconstituents identified in the organic extract of g. bruguieri roots may add new knowledge to prove the medicinal importance of this plant in the future.
in addition, the gc-ms analysis of moghat roots organic extract identified some constituents that were previously reported to possess an antitumor effect.
we also aimed in this study to prepare the plant extract by the same method customarily used by nursing mothers in egypt.
how much of the moghat dietary constituents are absorbed and how they are metabolized and excreted need more investigation.
phytochemicals hold promise for cancer chemoprevention, but it must be noted that it is difficult to theorize and generalize data obtained from one study to another because the concentration of active constituents in any extract prepared from plants will differ according to a number of factors like geographical region, condition of soil, harvest season, degree of maturation of the plant, extraction protocol, and so forth [91].
to our knowledge, there is no single study on the liver cancer inhibitory properties of mre constituents.
the findings here along with future studies may introduce moghat roots as herbals with anticancer properties.
@highlight
glossostemon bruguieri (moghat) is used as a nutritive and demulcent drink.
this study was performed to investigate the antiproliferative effects of moghat root extract (mre) and its apoptotic mechanism in hepatocellular carcinoma (hcc) cells, hepg2 and hep3b.
mtt assay, morphological changes, apoptosis enzyme linked immunosorbent assay, caspase and apoptotic activation, flow cytometry, and immunoblot analysis were employed.
the ic50 of mre for hepg2 (910 ± 6 μg/ml) and for hep3b (1510 ± 5 μg/ml) induced significant growth-inhibitory effects against hcc cells, with no cytotoxic effect on normal hepatocytes.
mre treatment induced apoptotic effects to hepg2 cells in a caspase-dependent manner and via upregulating p53/p21 and pcna.
the upregulation of p21 was controlled by p53 expression in hepg2 but not in hep3b despite upregulation of bax protein in both cell lines.
interestingly, p21 may be a remarkable switch to g1 arrest in hepg2 cells, but not in hep3b cells.
in addition, fas- and mitochondria-mediated pathways were found to be involved in mre-induced apoptosis in hep3b cells.
the gc-ms analysis of mre revealed two major constituents of pharmaceutical importance: the flavonoid apigenin (17.04%) and the terpenoid squalene (11.32%).
the data presented in this paper introduces g. bruguieri as a promising nontoxic herb with therapeutic potential for hcc.
to the authors' knowledge, the present study provides the first report on the anticancer activity of mre on hcc cells.
