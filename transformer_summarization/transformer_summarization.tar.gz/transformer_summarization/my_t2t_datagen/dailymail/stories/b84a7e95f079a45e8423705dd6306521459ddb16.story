introduction although both subclinical and clinical pregnancy losses occur, the majority of failed ivf-et cycles exhibit lack of implantation.
implantation failure may occur repeatedly.
these patients are challenges for the infertility specialist (1, 2).
endometrial function and receptive endometrium are essential for implantation (3, 4).
repeated implantation failure (rif) was defined as pregnancy failure after 2-6 times with at least 10 high quality embryos transferred into the uterus (5).
about 40% of ivf cycles will be failed following one ivf cycle.
ivf failure is caused by either failure in early stage of implantation or early abortion.
major causes of ivf failure may be related to embryo quality and implantation failure (6-11).
granulocyte colony stimulating factor (gcsf) is synthesized in the reproductive tract naturally.
gcsf stimulate neutrophilic granulocyte proliferation and differentiation, which act on macrophages of decidual cells, and finally affect implantation (12-14).
the recruitment of dendritic cells, th-2 cytokine secretion and activation of t regulatory cells are the others immune effects of gcsf.
the cytokine increase the proportion of embryos that develop to the blastocyst stage from 30-76%.
also gcsf supplemented to the embryo culture medium improves implantation rate.
combination of follicular gcsf and il-15 is an effective method to define oocyte component for successful conception in ivf/icsi cycles (15-17).
most important role of gcsf is improving blastocyst development, aid to embryo implantation and improving devolvement of fetus and placenta (15, 16).
gcsf can be effective treatment in patient with history of implantation failure and can improve endometrium growth.
also gcsf may increase pregnancy rate especially in women with thin endometrium (18, 19).
gcsf is a glycoprotein that stimulates cytokine growth factor inducing immune system.
gcsf stimulates the proliferation and differentiation of endometrial cells by camp increase in stromal cell through paracrine and autocrine signaling pathways (20).
the aim of this study was to evaluate gcsf ability to improve pregnancy rate in women with history of implantation failure.
materials and methods this randomized controlled trial (rct) was performed at yazd research and clinical center for infertility, shahid sadoughi university of medical sciences between october 2014 and february 2015. the study was approved by the ethics committee of the university.
informed written consent was obtained from all couples.
women between 20-40 yrs old with history of at least two implantation failures were included.
participants with sickle cell disease, chronic neutropenia, malignancy history, renal failure, congenital fructose intolerance, respiratory infection, endometriosis and sever male factor were excluded.
a total of 90 eligible women were randomly allocated in two equal groups; intervention and control.
the patient randomized by random allocation software.
treatment protocol the patients received 150 iu/day gonal f (serono labratories, aubonne, switzerland) starting on day 2 and 0.25 mg cetrorelix (cetrotide; asta medica, frankfurt, germany) administered daily when one or more follicles reached 13-14 mm in diameter.
the doses of recombinant fsh have been adjusted according to the ovarian response for both groups.
urinary hcg 10000 iu (pregnyle, nv organon, oss, netherlands) was administered when at least two leading follicles reached a mean diameter of 17 mm and the serum e2 concentration was >500 pg/ml.
transvaginal oocyte retrieval was scheduled 36 hr after hcg injection.
45 patients in interventional group received uterine infusion of 300 µg (0.5ml) recombinant human gcsf (300 µg, zahravi co., tehran, iran) by the use of iui catheter after ovarian puncture under general anesthesia, while the standard treatment was continued in the 45 patients (control group) and did not receive gcsf treatment.
following oocyte retrieval, metaphase ii oocytes were reviewed and good-quality embryos (grade a: uniform or slightly uneven with fragmentation of <10%; grade b: the blastomeres size uniform or non-uniform, fragmentation amount of 10-20%) were transferred on day 3 for all patients.
following embryo transfer (et), all patients received cyclogest® vaginal pessaries (cox pharmaceuticals, barnstaple, uk) 400 mg twice daily until menstruation or for 8 wks after et procedure in case of clinical pregnancy.
clinical pregnancy was defined as the presence of gestational sac with fetal heartbeat by ultrasound 4 wks following the et.
the implantation rate was defined as the ratio of gestational sac determination on transvaginal ultrasonography to the number of transferred embryos.
statistical analysis all of statistical analysis was done by spss 20 (spss, chicago, il).
with 95% confidence level, power of 80%, pr1r=20%, pr2r=45% and the sample size=45 in each group was considered.
the normal distribution of data was checked.
the normal distribution of data was checked.
mean±sd were calculated for descriptive analysis.
independent t-test and 2 were used.
the statistical significances considered as p˂0.05.
all of analyses were based on intention to treat analysis.
results totally 90 patients were included in this study (figure 1).
the mean age of participants was 31.95±4.71 years old (32.55±4.61 in gcsf and 31.75±5.16 in control group).
the mean of fsh level in third day was 7.14±4.16 in gcsf group and 5.17±2.31 in controls.
demographic characteristics of participants and art characteristics are shown in tables i and ii respectively.
there were no significant differences in female age, infertility duration, third day fsh, number of art cycles, number of embryos and endometrial thickness between groups (p>0.05).
the pregnancy rate in gcsf group was improved significantly.
thirteen women (28.88%) in gcsf group and 6 (13.3%) in control group were clinical pregnant (p=0.043).
table i demographic characteristics of participants variables gcsf group control group the significance age (year) 32.55 ± 4.61 31.75 ± 5.16 0.44 infertility duration (year) 9.2 ± 4.31 8.6 ± 7.22 0.63 num of pervious failed art 2.57 ± 1.69 3.41 ± 1.54 0.055 third day fsh (m iu/ml) 7.14 ± 4.16 5.17 ± 2.31 0.059 *data are presented as mean±sd.
# student t-test *#basal fsh level (day 3 fsh) (iu/l) table ii cycle characteristics of participants variables gcsf group control group p-value gonal-f (iu)* # 1791 ± 546.75 1647 ± 570.75 0.168 cycle duration (day) * # 11.59 ± 2.46 10.75 ± 1.46 0.056 num of retrieved oocyte * # 11.36 ± 6.03 14.53 ± 7.34 0.029 num of oocyte (m ii) * # 9.6 ± 6.6 12.46 ± 6.28 0.033 num of embryos * # 7.04 ± 5.71 7.02 ± 4.29 0.983 num of transferred embryos * # 2.11 ± 0.77 2.35 ± 0.71 0.123 embryo quality*$ a 27 (61.4%) 26 (57.8%) 0.830 b 17 (38.6%) 19 (42.2%) endometrial thickness in in hcg triggering day (mm) * # 9.13 ± 1.45 8.79 ± 1.65 0.306 implementation rate**# 16.67% 5.04% 0.0151 clinical pregnancy**$ 13 (28.88%) 6 (13.3%) 0.043 data presented as mean±sd.
(n=45) $ data presented as n (%) # data presented as mean±sd.
* comparison was done by independent t-test.
** the comparison was done by ². figure 1 consort flow chart discussion the endometrial receptivity and thickness play essential role in implantation phase (18, 20, 21).
based on our study, clinical pregnancy rate was improved by gcsf intrauterine infusion on ovarian puncture day.
similar to previous studies that indicated g-csf administration may have beneficial effect on clinical pregnancy outcome after art our findings showed that intrauterine infusion significantly improves the clinical pregnancy rate (22).
one of the first studies of gcsf was a prospective cohort study on 4 patients to evaluate the effect of gcsf on thin endometrium.
these cohort findings represented gcsf is a new treatment of thin endometrium (18).
after the pilot study barad et al studied the gcsf effect on endometrium and clinical pregnancy rate in a parallel double blinded placebo-controlled clinical trial with 141 consecutive, unselected, consenting women with no history of renal disease, sickle cell disease, or malignancy who were undergoing ivf, in this study gcsf does not improve endometrial thickness or pregnancy rate (23).
the other study on 37 patients with thin endometrium demonstrated that infusion of gcsf improves the endometrial thickness (24).
eftekhar et al also in an interventional study on 67 infertile women showed although gcsf did not improve endometrial thickness but significantly increased the pregnancy rate in women with thin endometrium (20).
but most of the previous studies reported the gcsf role on endometrial thickness improvement (24, 25).
the useful role of gcsf on implantation was overlooked.
in spite of lesser follicles and metaphase ii oocytes in gcsf group (statistics significance), implantation and pregnancy rate were higher than control.
our study findings showed that clinical and chemical pregnancy rate were improved by gcsf intrauterine infusion on the day of ovarian puncture.
the point of gcsf effect may be endometrial-embryo interaction which should be added to many positive influences of gcsf such as effect on ovarian function, granulose cell function, human decidual macrophages, ovulation and reduction of unexplained repeated abortion (14, 16).
the most important limitation of the rare studies about the role of gcsf on implantation was limited sample size but in our study this limitation was satisfied.
although the mechanism of intrauterine infusion of gcsf is not found by details but since intrauterine gcsf decreases cd16 and cd56 and also increases lif significantly, so the chances of getting pregnant will be improved (23).
as noted in some studies exogenous gcsf intrauterine infusion as chemical and mechanical stimuli can improve the implantation and pregnancy outcomes.
the considered mechanism is that gcsf may induce secretion of endogenous cytokines activating the endocrine pathway (14, 20, 23-25).
although our sample size was adequate but there were no blinding in our study.
conclusion as a conclusion intrauterine infusion of gcsf in infertile women with history of implantation failure is an effective treatment and can improve the pregnancy outcome.
@highlight
background: although pregnancy rate in in vitro fertilization-embryo transfer (ivf-et) cycles has been increased over the preceding years, but the majority of ivf-et cycles still fail.
granulocyte colony stimulating factor (gcsf) is a glycoprotein that stimulates cytokine growth factor and induces immune system which may improve pregnancy rate in women with history of implantation failure.
objective: the aim of this study was to evaluate gcsf ability to improve pregnancy rate in women with history of implantation failure materials and methods: 0.5 ml (300 µg/ml) gcsf was infused intrauterine in intervention group.
pregnancy outcomes were assessed based on clinical pregnancy.
results: the mean age of participants was 31.95±4.71 years old.
there were no significant differences between demographic characteristics in two groups (p>0.05).
the pregnancy outcome in gcsf group was improved significantly (p=0.043).
conclusion: gcsf can improve pregnancy outcome in patients with history of implantation failure.
