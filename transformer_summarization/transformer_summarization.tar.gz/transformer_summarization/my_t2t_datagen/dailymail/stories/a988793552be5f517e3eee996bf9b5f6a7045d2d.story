introduction contraceptive implants have been licensed in over 60 countries in the world and used by millions of women for over four decades.1 they are highly effective and safe with evidence suggesting that women do not experience serious health events at rates higher than those who use nonhormonal methods or women in the general population.12 other benefits of the implants include their ease of use, long duration of action, noninterference with intercourse, little ongoing attention, and immediate return to fertility after removal.23456 disruption of the menstrual bleeding pattern, especially in the early months after insertion, is their major drawback, a problem they share with all other progestin-only contraceptives2 and account for the most number of early discontinuations.45678910 this unpredictability of the bleeding pattern causes immense nuisance and negatively affects women's daily lives and restricts their social, sexual, community, and religious activities in many climes.10 in addition, initiation and discontinuation of implants including jadelle are provider dependent, a factor that can open users to abuse and coercive prescribing by providers.2310 jadelle contains levonorgestrel just like the 6-rod norplant but has the comparative advantage of containing only two rods, which makes both insertion and removal a lot easier.10 the literature demonstrates that jadelle and norplant are similar in many respects, except in the higher incidence of removal-related adverse events that occurred more with norplant.101112 the main contraceptive mechanism of these implants is the inhibition of ovulation through the suppression of the luteinizing hormone surge.
other secondary mechanisms are the increase in the viscosity of the cervical mucus making it impenetrable to spermatozoa and the thinning out of the endometrial lining making it atrophic.410 jadelle was introduced into the contraceptive method mix of the jos university teaching hospital in october 2007. our facility has had experience with two different implants before this time: norplant which was introduced in our center in 1985 and implanon in may 2006. norplant was subsequently withdrawn.
there was therefore the need to understand the use-dynamics of jadelle after the withdrawal of norplant.
besides, there are generally limited data on the pattern of use, continuation rates, and reasons for discontinuation of jadelle in northern nigeria.
the objective of the study therefore was to determine the sociodemographic profiles of acceptors of jadelle and the reasons for discontinuation in a region with a high fertility rate.
materials and methods this was a retrospective chart review carried out at the family planning clinic of the jos university teaching hospital between october 2007 and october 2013 among women who accepted jadelle a levonorgestrel-containing contraceptive implant.
all women who opted for and had jadelle inserted after counseling were included in the study.
high body weight, elevated blood pressure, or the presence of any chronic medical conditions did not constitute any reason to preclude the insertion of the implant.
the only exclusion criteria were known or suspected pregnancy, hypersensitivity to levonorgestrel, or being <6 weeks postpartum.
all contraceptive methods including jadelle were provided free to clients in our unit although a surcharge of 1000 naira was collected for consumables.
data on the sociodemographic characteristics, reproductive history, medical history, presence of any chronic condition, and previous experience with contraceptives were extracted from the charts.
the dates of insertion and removal of the implant were noted as well as the presence of any complication and/or adverse effect from the use of the contraceptive method.
for those who had their jadelle removed during the study period, the length of implant use in months was noted in addition to the reason for the discontinuation.
a urine pregnancy test was usually carried out to rule out any existing pregnancy before insertion.
this was also repeated once there was any suspicion of a pregnancy with the implant in situ.
if the pregnancy test became positive while using the implant, an ultrasound scan was carried out to date the pregnancy.
after insertion, the women were followed up with yearly visits to the clinic.
they were however advised to return to the clinic any time they experienced any untoward effect with the method or they wanted it removed.
during each follow-up visit, the subjects were asked about the presence of any adverse effect from the use of the implant.
those women who did not come for any of the yearly visits and were not seen thereafter were classified as lost to follow-up.
the contraceptive efficacy of jadelle was determined by the number of in-treatment pregnancies that occurred.
statistical analyses this was a chart review and therefore the sample size was based on clinical feasibility and not any formal statistical power calculation.
every woman who initiated jadelle had her profile included in the analysis of the sociodemographic characteristics.
descriptive and analytic statistics were carried out on all data where appropriate using epi info version 3.5.1 (cdc, atlanta, ga, usa).
the descriptive statistics were frequency and percentage for categorical variables while mean, median, standard deviation, and interquartile range were used for noncategorical variables.
results during the study period, 1401 women accepted jadelle as family planning methods in the family planning clinic of the jos university teaching hospital, jos nigeria.
the sociodemographic profiles of these women are shown in table 1. table 1 sociodemographic characteristics of jadelle acceptors women from all but four states (bayelsa, kebbi, lagos, rivers) of the federal republic of nigeria accepted jadelle during the study period with 4 states (plateau [66.4%], kaduna [4.4%], benue [3.7%], and nasarawa [2.3%]), constituting at least 2% of the acceptors.
about 132 different ethnic groups across nigeria were represented with about a dozen ethnic groups accounting for over three-quarters (75.8%) of the acceptors: berom (26.8%), afizere (6.4%), hausa (5.8%), yoruba (5.5%), mwaghavul (5.1%), ron (4.5%), igbo (4.2%), irigwe (4.2%), ngas (3.8%), rukuba (2.7%), idoma (2.7%), taroh (2.1%), and fulani (2.0%).
the mode of delivery in the last confinement before initiating jadelle is depicted in figure 1. figure 1 also shows the number of women whose delivery was attended by a complication.
figure 1 the mode of delivery/presence of complication in the most recent pregnancy the mean parity of the subjects who initiated the jadelle implant was 4.1 ± 1.9. the parity and other components of the reproductive history of the women are summarized in table 2. table 2 reproductive history of jadelle acceptors about 90% of all the women who opted for jadelle as a contraceptive method had regular menstrual cycles at the time of accepting the method.
this is diagrammatically shown in the pie chart [figure 2].
figure 2 percentage of women with regular and irregular menstruation at insertion of jadelle just under half of the women (49.5%) were breastfeeding and over half (55.9%) had future fertility desires at the time of commencing the use of jadelle.
about 82% had some experience with other contraceptive methods with only 18% starting jadelle as the first-ever contraceptive method.
figure 3 shows the proportion of the women breastfeeding at the time of initiating jadelle and their future reproductive intentions.
it also presents the proportion of women with previous contraceptive experience, while figure 4 shows the percentages of the different types of contraceptive methods used by the women previously.
figure 3 proportion of subjects that were breastfeeding, had previously used contraceptives and their future fertility desires at insertion of jadelle figure 4 types of contraceptives and percentages of jadelle acceptors that had used each previously about 42 women had jadelle reinserted after the expiration of the first one.
further, during the study period, 337 women discontinued the implant for different reasons.
these reasons are shown in table 3. most women discontinued the jadelle so as to fulfill a further fertility desire after using the implant for an average of 29.6 months.
however, menstrual irregularity accounted for 34.6% of the discontinuation in the first 6 months of use.
two women had their jadelle removed, following its failure to protect them against pregnancy; the first after 26 months of use while she was 37 years and weighed 67 kg and the second after 55 months of use at 32 years and she weighed 88 kg at the time of the failure.
the average period of use of the implant generally in this study was 28.8 months.
table 3 reasons for the discontinuation of jadelle among the study subjects discussion during the study period, 1401 women accepted jadelle.
the mean age of the women was 33.4 ± 5.9 years.
there were only five teenagers which accounted for <0.5% of those who accepted the method.
the use of family planning clinics by adolescents in nigeria is poor.
even worse is the initiation of long-acting reversible contraceptives (larcs) by this age group.1314 lack of access to larc method is one of the reasons advanced by adolescents for not using them.13 in nigeria, family planning clinics are not adolescent-friendly, especially for unmarried adolescents, since it is regarded as the exclusive preserve of the married.131516 this situation is much different from many climes in europe and america where teenagers constitute a significant proportion of users of family planning clinics and larc methods including implants.171819 over 73% of the jadelle initiators had at least secondary school education or more while 88.8% were christians.
education and religion in nigeria are important predictors of the use of modern contraceptives.202122 in a representative sample of nigerian women, it was found out that women with tertiary education were 2.10 times more likely to have ever used modern contraceptives than women with no formal education.
in addition, christians were 1.41 times more likely than their muslim counterparts to have used a modern contraceptive method.20 the means of parity, number of children born alive, and number of children still alive to women in this study at baseline were 4.1, 4.1, and 3.8, respectively.
despite these figures, over half of the women (55.9%) still had desires to have more children in future.
this is an attestation to the high total fertility rate (tfr) in nigeria put at 5.7. tfr is higher in northern nigeria than in the southern part of the country.1623 the contraceptive prevalence rate in nigeria is generally low.1624 however, majority (82%) of the women in this study had used at least one form of modern contraceptive in the past.
figure 4 shows that there was an overrepresentation of the short-acting methods such as injectables, oral contraceptive pills, and condoms in the women's previous contraceptive experience.
previous research had shown that in sub-saharan africa, the contraceptive method mix practiced by women was mostly dominated by the less effective short-acting methods such as pills and injectables.2526 majority of women in our study discontinued the implant to fulfill a further desire to have more children.
these women used jadelle for an average of 29.6 months before planning the next pregnancy.
this was not surprising since 55.9% of the women had expressed a desire for more children at baseline.
about 41% of the women at baseline accepted jadelle even though they felt that they had completed their family size.
ozumba et al.
have shown that in some nigerian cultures, sterilization is associated with loss of vitality and related to sterility in the “afterlife” and therefore, larcs are a viable alternative to bilateral tubal ligation.27 menstrual irregularities account for most early discontinuation of implants in many series.45678910 our study has also reconfirmed this finding.
over one-third (34.6%) of the discontinuation of jadelle within 6 months of use was as a result of menstrual pattern disruption.
over the course of the entire study, however, menstrual disruption accounted for only 11.3% of the reasons women discontinued jadelle.
disruption of vaginal bleeding pattern is almost inevitable with contraceptive implants, especially in the early months.10 while these bleeding disturbances are not known to threaten the lives of the women, it may however lead to an increase in investigations for cervical or endometrial pathologies.10 it also leads to disruption of the daily lives of the women and affects their social, sexual and religious practice (praying, fasting, attending funerals, going to places of worship).6 wearing a pad or tampon because of prolonged bleeding is not only uncomfortable but also comes with some cost.10 preinsertion counseling on menstrual pattern disruption is therefore a sine qua non for the provision of quality services for all progestin-only implants since this is the most likely reason to prompt early discontinuation.6 this is because women choosing and continuing a contraceptive method are actually making a trade-off between its perceived advantages and disadvantages.6 other nonmenstrual adverse effects that resulted in the removal of jadelle in this study were weight gain, elevated blood pressure, and headache.
each of these resulted in the discontinuation of jadelle for <5% of the entire reasons for the removal of jadelle.
these nonmenstrual reasons for removal of jadelle are similar to other studies of discontinuation of contraceptive implants.611 two women had a method failure with jadelle in our series.
these two failures were not in keeping with the well-documented efficacy of jadelle in clinical trials.1314 these women had used jadelle for 26 and 55 months, respectively.
these are likely to be proper method failures because they happened quite remote from the time of insertion and are not likely to be preexisting pregnancies that predated the insertion.
this study bears some methodological limitations.
it is a retrospective chart audit which relied heavily on information already obtained within the setting of clinical consultation.
some of the data entries were missing and this may have biased the outcome of the study.
however, the results of this study have improved our understanding of the profile of those women who accepted jadelle as one of the larc methods and the reasons for its discontinuation.
this information will be useful for further research that is aimed at targeting the underserved members of the community.
conclusion jadelle is used by diverse ethnic groups in nigeria especially by women who were very educated.
the main reason for discontinuation was to have more children although menstrual pattern disruptions accounted for earlier removals.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
background: contraceptive implants (including jadelle) are highly effective, safe, and easy to use and have a long duration of action.
they do not interfere with intercourse with immediate return to fertility after removal.
however, disruption of the menstrual bleeding pattern is almost inevitable and coercive prescription may be a problem because insertion and removal of implants are provider dependent.
the objective of this study was to determine the sociodemographic profiles of acceptors of jadelle and the reasons for discontinuation in jos, nigeria.
materials and methods: this was a 6-year retrospective chart review carried out at the jos university teaching hospital.
results: about 1401 women accepted jadelle with a mean (±standard deviation) of 33.4 ± 5.9 years.
about 88% of the women were christians and almost three-quarters (73.5%) had at least secondary school education.
the means of parity and number of children still alive at the time of accepting jadelle were 4.1 and 3.8, respectively.
half of the women (49.5%) were breastfeeding and over half (55.9%) had future fertility desires at the time of commencing jadelle.
about 82% had previously used other contraceptives (mostly short-acting methods such as injectables, pills, and condoms), with only 18% starting jadelle as the first-ever contraceptive method.
about 90% of the women had regular menstrual cycles.
the major reason for discontinuation of jadelle was desire for pregnancy although menstrual pattern disruption was the most common reason for removal in the first 6 months of use.
conclusion: the main reason for discontinuation of jadelle was to have more children although menstrual pattern disruptions accounted for earlier discontinuation.
