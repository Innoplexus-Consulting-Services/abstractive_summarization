introduction spontaneous abortion is the most common adverse pregnancy outcomes occuring in approximately between 12 and 15% of clinically recognized pregnancies (1).
the main reasons of early pregnancy loss are still unknown.
although a number of spontaneous abortions are caused by chromosomal abnormalities, maternal factors including nutritional status, also may contribute to this occurrence.
the presence of appreciable amount of folic acid and vitamins has been reported to be essential for normal embryogenesis (1-3).
there is reliable evidence indicating that maternal micronutrient status contributes to pregnancy outcome (4-9).
a possible link has been suggested between nutrient deficiencies and reproductive risk factors.
interest has focused mainly on the risk of malformations.
an association between intake of micronutrients, such as folic acid and zinc, magnesium and iron, and pregnancy outcome has been investigated (1-9).
in addition, reduced consumption of animal fats, carotene and proteins have been associated with the risk of hydatiform mole (10).
although the effects of maternal nutrition on fetal development and birth outcomes have been obviously demonstrated in animal studies, the findings of studies in humans inconsistent.
due to influences of health eating habits on early phases of conception and pregnancy, we aimed to explore the association between nutrient deficiencies and the risk of spontaneous abortion.
materials and methods this case-control study was carried out in tehran-iran.
the case group (n=331) experienced a spontaneous abortion before 14 weeks of pregnancy, while the control group (n=331) were healthy pregnant women over 14 weeks of pregnancy.
cluster sampling was used for selection of participations.
in this method, ten regions were picked out randomly from 22 regions of tehran, one public hospital was selected randomly from each picked region, and 331 cases was recruited randomly from these ten hospitals.
each case was assigned one control from these ten hospitals matched on maternal age, duration from last delivery in multiparous women, body mass index (bmi), occupation, and educational status.
inclusion criteria were as follow: i. singleton pregnancy, ii.
18-35 years of age, iii.
no history of chronic diseases, such as diabetes, hypertension, cardiovascular diseases and thyroid dysfunction, iv.
no history of any congenital or karyotypic abnormalities in the woman, her husband or one of the immediate relatives, v. pregnancy without use of assisted reproductive technology (art), vi.
no vaginal bleeding in the first trimester of pregnancy in the control group, vii.
lack of fetal malformations in the current pregnancy, viii.
no smoking during pregnancy.
the study was approved by the ethical committee of tarbiat modares university and a written informed consent was obtained from the participants.
at enrollment, the interviewers administered a questionnaire to the women to collect baseline information on socio demographic, and obstetrics history.
then, case group filled out dietary information after abortion in the hospital while the control group completed the same questionnaire.
dietary assessment the assessment of dietary intake was performed using food frequency questionnaire (ffq) which was previously validated on the adult population of the city of tehran, iran (11).
this questionnaire assesses 168 food items consumed in the preceding three months.
this version of ffq consists of a list of foods with a standard serving size commonly consumed by iranian.
for validity and reliability of ffq, mirmiran et al.
(11) compared the dietary data collected monthly by means of twelve 24 hour dietary/recalls (24hdr) and biochemical markers with data collected from ffq.
the exact agreement rate was reasonable.
the participants were taught the food portion sizes using food photographs and measuring containers and given instructions for recording their dietary intake by a registered dietitian.
the following food items were evaluated: fruits, vegetables, breads and cereals, dairy products, meat, poultry, fish, eggs, dry beans, and fats, oils, sweet.
due to presence of fats in above mentioned groups, dietary intake was calculated based on following information: 8 g fat in each ounce of sheep; 3 g fat in each ounces of veal meat; 1 g fat in each portion of bread and cereal; 5 g fat in each portion of low fat milk; 8 g fat in each portion of high fat milk .these amounts of fats were then added to the fat and oil group.
participants were asked to report their frequency of consumption of a given serving size of each food item during the past three months, on a daily, weekly or monthly basis.
the reported frequency for each food item was converted to a daily intake.
portion sizes of consumed food were then converted to gram using household measures.
also, the number of the women who consumed different numbers of food serving portion was compared between the two groups.
for assessment of micronutrients intake mosbys nutria trace nutrition analysis software was used.
statistical analysis the sample size was estimated based on a pilot study, considering a power of 80% and alpha of 5%.
overall comparisons between two groups were performed using t test or ϰ2 test.
we computed the odds ratio (or), as estimators of risks of spontaneous abortion, for the various parameters, with an approximate 95% confidence interval (ci).
all statistical tests were two sided tests and were performed using a 5% significance level.
the statistical package for the social sciences (spss, spss inc, usa) version 20 was used for all statistical analysis.
results table 1 shows the characteristics of the cases and controls.
there are no significant differences between the two groups regarding maternal age, duration from last delivery in multiparous women, bmi, occupation, and educational status.
there are significant differences between the two groups regarding consumed servings/day of vegetables, bread and cereal, meat, poultry, fish, eggs, dry beans, nuts, fats, oils, sweet and dairy products (p=0.012, p<0.001, p=0.004, p<0.001, p0.019, respectively) (table 2).
table 1 comparison of demographics and obstetric characteristics between women with and without clinical spontaneous abortion variables case group (n=331) control group (n=331) p value maternal age (y)* 27.79 ± 5.30 27.31 ± 4.37 n.s duration from last delivery(months)* 41.78 ± 50.31 49.76 ± 45.97 n.s bmi* 24.95 ± 6.72 24.25 ± 4.63 n.s occupation** n.s   housewife 293 (88.5) 308 (93.1)   employed 38 (11.5) 23 (6.9) educational status** n.s   lower than university 267 (80.7) 275 (83.1)   university 64 (19.3) 56 (16.9) *; values are given as mean ± sd using student’s t test, **; values are given as number (%) using chi-squared test (χ2), n.s; not significant, and bmi; body mass index.
table 2 comparison of daily intake of food items between women with and without clinical spontaneous abortion.
values are given as number (%) ϰ2 test food items, portion per day case group (n=331) control group (n=331) p value vegetables 0.012   (<3 parts) 282 (85.2) 253 (76.4)   (3-5 parts) 49 (14.8) 77 (23.3)   (>5 parts) 0 (0) 1 (0.3) fruits 0.055   (<2 parts) 152 (45.9) 122 (36.9)   (2-4 parts) 169 (51.1) 195 (58.9)   (>4 parts) 10 (3) 14 (4.2) breads and cereals <0.001   (<6 parts) 129 (39) 88 (26.6)   (6-11 parts) 199 (60.1) 208 (62.8)   (>11 parts) 3 (0.9) 35 (10.6) meat and beans 0.004   (<2parts) 268 (81.0) 232 (70.1)   (2-3 parts) 63 (19.0) 98 (29.6)   (>3 parts) 0 (0) 1 (0.3) dairy products <0.001   (<2 parts) 173 (52.3) 120 (36.3)   (2-3 parts) 151 (45.6) 190 (57.4)   (>3 parts) 7 (2.1) 21 (6.3) fats and oils 0.019   (<55 g) 77 (23.3) 50 (15.1)   (55-66 g) 113 (34.1) 114 (34.4)   (>66 g) 141 (42.6) 167 (50.5) in addition, there are significant differences between the two groups in terms of all micronutrient factors including folic acid, iron, vitamin c, vitamin b6, vitamin b12 and zinc (table 3).
table 3 comparison of daily intake of micronutrients between women with and without clinical spontaneous abortion* variables case group (n=331) control group (n=331) folic acid(µg) 416.09 ± 94.36 526.49 ± 73.41 fe(mg) 19.29 ± 4.83 22.16 ± 4.03 vitamin c (mg) 75.63 ± 7.62 78.06 ± 5.91 vitamin b6 (mg) 1.12 ± 0.46 1.55 ± 0.33 vitamin b12 (µg) 2.10 ± 0.39 2.32 ± 0.25 zn (mg) 8.06 ± 1.50 9.93 ± 0.87 values are given as mean ± sd by the independent t student test.
*; p<0.001.
table 4 depicts the or and the 95% ci of logistic regression models for spontaneous abortion and consumption of micronutrients.
for the women consuming the micronutrients or of spontaneous abortion was significant in acid folic (0.986, 0.984-0.988), iron (0.868, 0.837-0.900), vitamin c (0.949, 0.928-0.971), vitamin b6 (0.096, 0.064-0.144), vitamin b12 (0.129, 0.076-0.218), and zinc (0.288, 0.237-0.349).
table 4 logistic regression models of the association between micronutrients and spontaneous abortion* variables or (95% ci) folic acid 0.986 (0.984-0.988) fe 0.868 (0.837-0.900) vitamin c 0.949 (0.928-0.971) vitamin b6 0.096 (0.064-0.144) vitamin b12 0.129 (0.076-0.218) zn 0.288 (0.237-0.349) or; odds ratio, ci; confidence interval, and *; p<0.001.
discussion our findings indicated that there are significant differences between the two groups in number of the women who consumed servings/day of vegetables, breads and cereals, meat, poultry, fish, eggs, dry beans, nuts, fats, oils, sweet and dairy products.
the incidence of pregnancy wastage is high in women from poor socio-economic groups.
maternal malnutrition is considered to be an important factor contributing to spontaneous abortions by way of altering the germ cell morphology; however, the relation between maternal nutrition and spontaneous abortion is complex and influenced by several biologic, socioeconomic, and lifestyle factors, which vary extremely in different populations (12, 13).
during pregnancy, there is an increased nutritional demand for both mother and fetus.
maternal under nutrition probably increases the risk of intrauterine death and abortion (14-17), possibly due to cellular dysfunction.
maternal nutritional deficiencies also cause serious damages on different stages of fetal development.
a number of experimental animal studies and observational human studies have mentioned the consequences of malnutrition at the very earliest embryonic stages that affected fetal growth and birth outcomes (13, 18).
furthermore, evidence from animal studies have indicated that fetal growth is mostly affected by maternal under nutrition during the peri-implantation stage and the stage of rapid placental development (19, 20).
the maternal nutrition is more likely to be affected by socioeconomic and lifestyle factors in various ways.
socioeconomic status influences pregnancy dietary intake that results in multiple rather than single nutrient deficiencies.
it has been also reported that cultural factors play a major role in maternal age at initiation of childbearing and interval between delivery (13, 16, 18, 21).
karmer et al.
(22) has stated that the countries with lowest rates of adverse birth outcomes had done so not through health care interventions but rather by reducing the prevalence of socioeconomic disadvantage and poverty.
according to the results of this study, the average of all micronutrients which was consumed by the case group was significantly lower than in the control group.
the observed association in our study is in agreement with the findings of several previous studies.
optimal pregnancy outcomes are dependent upon the intake of adequate nutrients, and malnutrition results from inadequate diet, is synonymous with growth failure, especially during the rapid growth phases of fetus.
it was recognized that poor pregnancy outcomes results not only from a deficiency of protein and macronutrient but also from inadequate intake of micronutrients that are vital during pregnancy (15-17).
folate deficiency during pregnancy is also associated with numerous adverse pregnancy outcomes, including spontaneous abortions.
a number of studies have indicated that suboptimal vitamin b6 status and elevated plasma total homocysteine concentrations a marker of poor folate or vitamin b12 status, may increase the risk of spontaneous abortion (1, 2, 6, 23, 24), although the association is still unknown.
elevated plasma total homocysteine concentrations are caused by genetic abnormalities or suboptimal folate, vitamin b12, and/or vitamin b6 status.
we also found lower consumption of vitamin c in the women with spontaneous abortion.
in a report based on the women with recurrent abortion by vural et al.
(25), they have found that antioxidant elements including vitamin c decreased in case group in comparison with healthy pregnant women.
in the present study, women with spontaneous abortion had lower consumption of iron and zinc as compared to the control women.
this is consistent with other studies, in which they have found an association between poor zinc status and adverse pregnancy outcomes (22, 26-29) the present study had several limitations.
a major limitation of this study was the self-report of dietary data and the lack of precise estimation of micronutrients and macronutrients consumption.
another limitation of our study was that neither embryos nor parents were karyotyped.
aneuploidy is a common cause of spontaneous abortion and that was not excluded in our study.
the third limitation was that any hospital-based case-control study on abortion includes only women with spontaneous abortion requiring hospital admission, with the consequent exclusion of women with subclinical abortions or very early pregnancy losses.
a strength of the current study was dietary data were collected approximately at same gestational ages in cases and controls groups; meaning the case group was interviewed in hospital and the control group in prenatal clinics.
further, the differences observed could not be explained by some confounding factors because these parameters were matched as far as possible between the two groups.
conclusion despite potential limitations and difficulties in the interpretation, our findings illustrated that a diet poor in several nutrients may increase risk of spontaneous abortion.
@highlight
background spontaneous abortion is the most common adverse pregnancy outcome.
we aimed to investigate a possible link between nutrient deficiencies and the risk of spontaneous abortion.
materials and methods this case-control study included the case group (n=331) experiencing a spontaneous abortion before 14 weeks of pregnancy and the control group (n=331) who were healthy pregnant women over 14 weeks of pregnancy.
the participants filled out food frequency questionnaire (ffq), in which they reported their frequency of consumption for a given serving of each food item during the past three months, on a daily, weekly or monthly basis.
the reported frequency for each food item was converted to a daily intake.
then, consumption of nutrients was compared between the two groups.
results there are significant differences between the two groups regarding consumed servings/day of vegetables, bread and cereal, meat, poultry, fish, eggs, beans, fats, oils and dairy products (p=0.012, p<0.001, p=0.004, p<0.001, p=0.019, respectively).
there are significant differences between the two groups in all micronutrient including folic acid, iron, vitamin c, vitamin b6, vitamin b12 and zinc (p<0.001).
conclusion poor nutrientions may be correlated with increased risk of spontaneous abortion.
