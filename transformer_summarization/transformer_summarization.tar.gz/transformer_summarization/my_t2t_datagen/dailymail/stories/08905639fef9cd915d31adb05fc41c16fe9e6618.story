1 introduction when reaching to grasp an object, we have an exquisite ability to precisely shape our hand according to the object's three-dimensional structure.
such skilled hand movements require the brain to perform a complex transformation of the object's visual properties into a grasp-specific motor command acting on the hand muscles.
several lines of evidence implicate a cortical grasping circuit in this visuomotor transformation, including the anterior intraparietal area (aip), ventral premotor cortex (pmv) and primary motor cortex (m1) (davare et al., 2011, davare et al., 2010, janssen and scherberger, 2015, jeannerod et al., 1995, murata et al., 2000, nelissen and vanduffel, 2011).
typically, when the object geometry requires either a precision grip (pg) or whole hand grasp (whg), the excitability of cortical muscle representations increases in a grasp-specific fashion.
this was first unveiled by probing excitability changes during grasping preparation and execution in intracortical circuits (late i-wave pathways) within m1 (cattaneo et al., 2005), which probably reflected cortico–cortical interactions between pmv and m1 (davare et al., 2008, davare et al., 2009).
selective activation of the motor system is not only critical for performing actions, but can also be detected when the individual passively looks at an action being performed by another.
indeed, action observation modulates motor evoked potentials (meps), elicited by transcranial magnetic stimulation (tms) of m1, in muscles that human observers recruit during the actual performance of the same action (alaerts et al., 2010a, fadiga et al., 1995, mccabe et al., 2015, urgesi et al., 2006), a phenomenon known as motor resonance.
this resonance has been proposed to result from the human mirror system, supposed to include homologues of areas f5 and aip, housing mirror neurons in monkeys (gallese et al., 1996, maeda et al., 2015, nelissen et al., 2011, pani et al., 2014).
since no direct recording has so far been obtained from these regions in humans for technical reasons (mukamel, ekstrom, kaplan, iacoboni, & fried, 2010), the similarity between motor resonance and excitability changes in m1 during action preparation and execution have been cited as evidence in favour of the existence of mirror neurons in humans (fadiga et al., 1995).
while a number of reports have suggested similar changes in m1 excitability during both action observation and execution (cattaneo et al., 2009, fadiga et al., 2005, senot et al., 2011), to date, only muscle-specific resonance has been reported (catmur et al., 2007, cavallo et al., 2012, mccabe et al., 2015, strafella and paus, 2000, urgesi et al., 2006).
since motor resonance supposedly depends on premotor inputs to m1, an additional condition to be met by motor resonance is to reflect the properties of these inputs.
it has been shown that static images of an action, because they may imply motion, increase m1 excitability (urgesi et al., 2006).
yet, recently a study showed that the human homologues of f5 subsectors respond more to action videos than static images, even those taken close to the moment of contact (ferri et al., 2015).
hence, one can predict that motor resonance should not only be grasp-specific but this pattern should be clearer for action videos rather than static frames taken from the video.
finally, the latter study (ferri et al., 2015) has also shown that different parts of pmv [i.e., putative human area f5a (phf5a), phf5p and phf5c] react differentially to action videos depending on the visibility of the actor being observed.
that is, phf5c was active when the actor was fully visible to the observer but not when only the hand was visible, leaving the other subsectors of pmv to transmit visuomotor information about the latter (hand only) condition.
hence, by manipulating visibility of the observer, we can effectively activate or deactivate the output of phf5c in order to test how phf5c contributes to motor resonance.
therefore, we manipulated four factors (3 visual and 1 muscle) in the first tms experiment: muscle [first dorsal interosseous (fdi) and abductor digiti minimi (adm)] and grasp (precision grip and whole hand grasp) to document the grasp specificity, type of visual stimulus (video vs static image) and view (with whole actor visible vs hand alone).
we hypothesised that, similar to action execution, fdi meps would show greater modulation during observation of precision grip compared to adm and adm meps would show greater modulation during observation of whole hand grasp compared to precision grip.
in addition we expected that if inputs to m1 from phf5c affect motor resonance, greater changes would be seen when observing an actor performing grasping actions compared with observation of the hand alone.
alternatively, if observation of the hand alone results in significant changes in motor resonance, inputs from other sub-regions of pmv might be more important.
observing a whole person in an image of equal size to that of the hand alone images and videos would invariably result in the hand being smaller in the whole person visual stimuli, thus the relative size of the hand is an uncontrolled variable that could contribute to results in the above experiment.
we therefore carried out a second experiment investigating whether hand size was important in grasp-specific motor resonance.
2 methods 2.1 subjects thirty-two healthy subjects participated in the present study (mean age: 26.5 ± 5.0 years; 19 females).
twenty subjects participated in experiment 1 and 15 subjects participated in experiment 2, 3 subjects participated in both experiments.
experiment 1 and 2 were performed several weeks apart, therefore reducing any possible carry-over effects in the latter 3 subjects.
all subjects were right-handed (self-reported via screening questionnaire), with normal, or corrected to normal vision and gave informed consent.
none of the subjects had a history of neurological disease.
potential risks of adverse reactions to tms were evaluated by the tms adult safety screen questionnaire (keel, smith, & wassermann, 2001).
the experimental procedures were approved by the ethics committee of university college london.
2.2 experimental setup participants were seated comfortably in a chair in a darkened room in front of a 17-inch computer (1280 × 1024 pixels; 60 hz) screen located at a distance of 54 cm.
subjects' right hand rested comfortably on a pillow in front of them in a prone position and their left hand rested on a computer keyboard.
a chin rest was used to stabilise the head.
2.3 stimuli the visual stimuli consisted of videos clips and images of a right hand (and forearm) and the full view of a person grasping objects with the right hand.
the stimuli were presented from a lateral left-sided viewpoint, whereby the inner, radial side of the hand, arm and body were visible to the observer.
this view was used in order to provide the observer with the most complete view of the body and the object, including kinematics of the hand and arm, during the grasping cycle.
the disembodied hand stimuli were derived from the whole body stimuli by zooming in on the hand and arm.
one video cycle lasted 4.5 sec (frame rate 20/sec), the static images were presented for the same amount of time (4.5 sec).
presented images and videos were subtended to a visual angle of approximately 10° by 10°.
during observation of the stimuli the visual angle of the hand during grasping in the hand alone, the whole person, and the ‘small’ hand alone (see experiment 2 below) conditions was 2.76°, 1.06° and 1.06°, respectively.
2.4 recordings digital conversion and timing of the tms pulses were performed with a micro 1401mk2 unit (cambridge electronic design, cambridge, uk) controlled by a custom written matlab script.
electromyographical (emg) recordings were made from the first dorsal interosseous (fdi) and abductor digiti minimi (adm) of the right hand with surface electrodes (ag—agcl, 10 mm diameter).
the emg signal was amplified 1000×, high-pass filtered at 3 hz, sampled at 5 khz and stored for off-line analysis (ced 1401 with spike and signal software, cambridge electronic design, cambridge, uk).
eye position was recorded via an infrared camera (thomas recordings, giessen, germany), separate x and y axis signals were sampled at 5 khz and stored for off-line analysis.
2.5 transcranial magnetic stimulation single-pulse tms was applied using a magstim 200 stimulator (magstim, whitland, uk) connected to a standard 9 cm figure-of-eight coil.
the coil was applied tangentially to the scalp with the handle pointing backwards and laterally with a 45° angle to the midline.
the coil was systematically moved over the scalp until the optimal hotspot for evoking responses in both fdi and adm muscles was found.
at the beginning of each experiment, the resting motor threshold (rmt), defined as the minimum intensity that induced motor evoked potentials (meps) of ≥50 μv in 5 out of 10 responses (rossini et al., 2015, rothwell et al., 1999), was determined for the fdi muscle (rmt: 41.7 ± 7.3%).
the stimulus intensity was set to obtain motor-evoked potentials (meps) at rest of an approximate amplitude of 1 mv, on average, from the fdi muscle (117.9 ± 7.6% of rmt).
2.6 experimental procedure 2.6.1 experiment 1 the first experiment aimed to determine whether observing the whole person or the hand alone performing a grasp differentially modulated meps recorded in muscles related to the task being observed.
here, subjects sat at rest while they observed a series of videos and static images of a ‘disembodied’ hand alone grasping an apple (whole hand grasp), a ‘disembodied’ hand alone grasping a peanut (precision grip), whole person grasping an apple (whole hand grasp) and whole person grasping a peanut (precision grip; fig.
1a experiment 1).
a baseline of meps without visual stimuli was taken prior to each observation block (15 meps for fdi and adm; fig.
1b).
the start of each observation block consisted of a red fixation dot that appeared in the centre of a black screen for 2s (fig.
1c).
subsequently, subjects observed the videos and static images.
six visual conditions were presented in a 2 × 2 × 2 factorial design: 2 grasps (precision grip vs whole hand grasp) × 2 observation views (hand only vs whole person) × 2 visual stimuli type (videos vs static images).
the videos and images were randomised; tms pulses were given with each visual presentation (5 meps per condition; 40 per block; fig.
1c).
after each image or video an inter-trial-interval (iti) was presented, this consisted of a black screen with the red fixation dot (fig.
1c).
a single block consisted of 40 itis, a tms pulse was given randomly during 15 of the itis.
the baseline without visual stimuli and observation block was repeated 4 times.
the final block was followed by a final baseline without visual stimuli (15 meps; fig.
1b).
thus, in total an experiment consisted of 75 meps without visual stimuli (15 × 5 blocks; fig.
1b), 20 mep per observation condition (20 × 8 observation conditions: 160 meps in total for each muscle) and 60 iti meps (15 × 4 blocks; fig.
1b).
whilst attending to the presented visual stimuli, subjects were asked to continue to fixate the red dot, which was present throughout the presentation of visual stimuli.
2.6.2 experiment 2 experiment 2 was performed to determine whether the size of the hand being observed was the contributing factor to the changes in motor resonance seen in experiment 1. in this experiment, the procedure was the same except that subjects observed a series of videos and static images of a ‘disembodied’ hand alone grasping an apple (whole hand grasp), a ‘disembodied’ hand alone grasping a peanut (precision grip; as in expt.
1), a small ‘disembodied’ hand alone grasping an apple (whole hand grasp) and a small ‘disembodied’ hand alone grasping a peanut (precision grip; fig.
1a experiment 2).
therefore, six visual conditions were presented in a 2 × 2 × 2 factorial design: 2 grasps (precision grip vs whole hand grasp) × 2 observation views (hand alone vs small hand alone) × 2 visual stimuli type (videos vs static images).
in total, an experiment consisted of 75 meps without visual stimuli, 20 mep per observation condition (160 in total for each muscle) and 60 iti meps.
subjects were instructed to fixate on the red dot throughout.
in both experiments, tms was triggered at first contact of the hand with the object (i.e., the apple or peanut; fig.
1c) during the videos.
therefore, tms was triggered at 2.5 sec from the start of the presentation for whole hand grasp and at 3 sec for precision grip.
during the static image presentation, tms was triggered at an averaged time of the 2 object contact times (2.75 sec) after the image was first presented.
each visual stimulus was preceded by an iti, which consisted of the red fixation dot on a black screen (fig.
1c).
if tms was triggered during the iti the duration of these trials was 7 sec, where tms was delivered at 1.5 sec from the beginning of the iti.
trials with itis in which tms was not given lasted 4.5 sec.
to maintain the subjects' attention during the presentation, the fixation dot would dim (i.e., change from bright red to dark red) randomly in 13% of the trials.
dimming occurred at a random time between 3.4 and 4.3 sec after the start of the visual stimuli.
subjects were instructed to press a key on a keyboard with their left hand when they observed dimming of the fixation dot and to relax immediately after the key press.
dimming trials were never followed by tms pulses.
additionally, in half of the subjects for experiment 1, eye position was monitored to ensure subjects were fixating the red dot and to ensure visual stimuli were located on the right visual hemifield.
2.7 data analysis the peak-to-peak amplitude of each individual mep was measured during the baseline without visual stimuli and each condition during the observation blocks.
meps were excluded from analysis if they were preceded by a background mean rectified emg activity greater than the resting baseline mean + 2sd [expt.
1: 1.88 ± 1.10% (mean ± standard deviation) of trials; expt.
2: .74 ± .73% of trials].
in addition, in order to ensure meps included in the analysis were recorded during full alertness we excluded meps that were less than 50 μv [expt.
1: 1.01 ± 1.71% of trials; expt.
2: 1.87 ± 2.21% of trials (catmur, mars, rushworth, & heyes, 2011)].
we also excluded meps that we considered to be extreme outliers, therefore meps greater than the mean + 3sd were excluded [expt.
1: 1.70 ± 1.73% of trials; expt.
2: 3.79 ± 1.27% of trials (alaerts et al., 2010a, alaerts et al., 2010b)].
blocks were removed if subjects made 3 or more errors on the attentional tasks (i.e., they failed to make a key press on a dimming trial).
for experiment 1, a repeated-measures 4 factor anova (combining the 3 stimulus factors and the muscle factor) was performed to determine the effect of view (hand alone vs whole person), visual stimuli (videos vs static images), grasp (precision grip vs whole hand grasp) and muscle (fdi vs adm) on normalised mep amplitude.
bonferroni-corrected t-tests were used for post-hoc analysis of significant interactions where appropriate.
for experiment 2, a repeated-measures 4 factor anova was performed to determine the effect of hand size (hand vs small hand), visual stimuli (videos vs static images), grasp (precision grip vs whole hand grasp) and muscle (fdi vs adm) on normalised mep amplitude.
bonferroni-corrected t-tests were used for post-hoc analysis of significant interactions where appropriate.
for both experiments, 2-factor repeated-measures anovas were also performed to test the effect of grasp (precision grip vs whole hand grasp) and muscle (fdi vs adm) on mep amplitude for different conditions.
the paired t-test statistic was used to analyse the mep amplitude during rest and iti baselines and fdi and adm mep amplitude across grasp (precision grip vs whole hand grasp).
3 results 3.1 experiment 1 corticospinal output was investigated via single pulse tms over the m1 hand representation at rest during the observation of static images and videos of different grasping actions.
fig.
2 shows the group mean baseline mep amplitudes in the fdi and adm without visual stimuli prior to and during each action observation block (iti).
note how meps recorded during the iti were larger across all blocks than meps recorded while subjects were resting and not attending to any visual stimulus.
indeed, the averaged iti baseline mep was significantly larger than without visual stimuli in both the fdi [iti: 1.50 ± .11 mv (mean ± standard error), rest: 1.18 ± .07 mv; t(19) = −3.83, p = .001] and adm muscles [iti: .68 ± .06 mv, rest: .54 ± .04 mv; t(19) = −3.23, p = .004].
importantly, this suggests a general and non-specific task arousal effect on corticospinal excitability.
consequently, to reveal the net action observation effect on mep amplitude, we normalised the amplitude of meps recorded during the observation conditions to those recorded during the iti (fig.
3a, b).
we also normalised the amplitude of these meps to those recorded without visual stimuli (fig.
3c, d).
a four-factor repeated-measures anova was used to test whether the observation conditions of view, visual stimuli, grasp type and muscle differentially affected mep size.
the results of the main anova and the partial eta squared for each statistic are presented in table 1. the anova yielded two significant 3-way interactions, these are described in the following section.
fig.
3 shows the normalised fdi and adm meps during observation of videos (fig.
3a, c) and static images (fig.
3b, d) for precision grip and whole hand grasp.
meps were normalised to the iti baseline (fig.
3a, b, top) and to the baseline without visual stimuli taken before each observation block (fig.
3c, d, bottom).
overall, both fdi and adm mep amplitudes during action observation were decreased compared with iti mep amplitude (below 1, p < .022; fig.
3a, b).
conversely, when compared with the baseline without visual stimuli, mep amplitude was larger during observation trials, showing an overall facilitation of the mep (above 1, p < .022; fig.
3c, d).
note that grasp × muscle-specific effects were only present during observation of videos.
specifically, the main anova revealed a significant triple interaction between visual stimuli, grasp and muscle [iti normalised: f(1,19) = 9.69, p = .006, fig.
3a, b; without visual stimuli normalised: f(1,19) = 8.64, p = .008, fig.
3c, d].
post-hoc analysis revealed that this interaction was driven by fdi meps being significantly larger during observation of precision grip videos compared to images (iti: p = .004; without visual stimuli: p = .042) and videos of precision grip compared to whole hand grasp (iti: p = .010 without visual stimuli: p = .040).
in addition, fdi meps were larger than adm meps when observing precision grip videos (iti: p = .005; without visual stimuli: p = .038).
in order to specifically test grasp × muscle interactions we performed further repeated-measures anovas, they revealed a significant double interaction between grasp and muscle during observation of videos [iti normalised: f(1,19) = 10.48, p = .004, fig.
3a; without visual stimuli normalised: f(1,19) = 8.80, p = .008, fig.
3c], but not static images [iti normalised: f(1,19) = 3.02, p = .099; fig.
3b; without visual stimuli normalised: f(1,19) = 3.21, p = .089, fig.
3d].
thus, the observation of videos of actions rather than static images is critical for grasp/muscle-specific changes in mep size.
fig.
4 shows fdi and adm meps (normalised to iti) during observation of only the hand or the whole person during precision grip and whole hand grasp.
note that only during observation of the hand alone were grasp × muscle-specific effects present.
during whole actor observation, while fdi meps were similar across conditions, adm meps showed a reversed pattern effect.
the main anova revealed a significant triple interaction between view, grasp and muscle [iti normalised: f(1,19) = 5.41, p = .031, fig.
4a, b].
post-hoc analysis revealed that this interaction was driven by a trend for fdi meps to be significantly larger when observing the hand perform precision grip compared to a whole hand grasp (p = .062), whilst fdi meps were also significantly larger than adm meps during observation of the hand perform precision grips (p = .047).
importantly, the observation of the hand alone [f(1,19) = 4.94, p = .039; fig.
4a], but not the person [f(1,19) = .40, p = .534; fig.
4b], resulted in a grasp × muscle interaction.
these results show that observation of the hand alone was important in revealing grasp/muscle-specific changes in mep size, changes that were absent when the whole person was observed.
to specifically address the question of whether view (person vs hand alone) is important for grasp specific changes in motor resonance during the observation of video actions we performed a 2 factor (grasp, muscle) repeated-measures anovas on the video condition separately.
fig.
5 shows normalised (iti) fdi and adm meps during observation of only the hand or the whole person during precision grip and whole hand grasp videos.
note that there was a crossed pattern of effect when observing the hand alone, whereby fdi meps were larger during precision grip compared with during whole hand grasp, while adm meps were larger during whole hand grasp compared with precision grip.
indeed, when the person and hand conditions were separated a significant grasp × muscle interaction was found for observation of the hand alone [f(1,19) = 20.96, p < .001; fig.
5a], but not the whole person [f(1,19) = 2.23, p = .151; fig.
5b].
in line with the main anova post-hoc test, the grasp × muscle interaction during observation of the hand is driven mainly by fdi meps, as fdi meps were significantly different across grasp [t(19) = 2.25, p = .036], whereas adm meps were not [t(23) = −1.58, p = .131].
overall, these findings show that the observation of hand alone videos mediates differential changes in corticospinal excitability of muscles that are specific to the type of grasping being observed.
3.2 experiment 2 in the light of these findings, we were aware that the size of the hand in the whole person visual stimuli was less than half that of the hand in the hand alone visual stimuli (visual angle: 1.06° vs 2.76°, respectively).
since observing the kinematics of the grasp is important for motor resonance, it could be hypothesised that a lack of grasp-specific motor resonance seen for the whole person visual stimuli was due to the small size of the hand being observed (i.e., poor visibility of the hand).
therefore, we tested whether hand size was a confounding variable in our results for experiment 1. here, the whole person videos and images were replaced by videos and images of the hand alone with the same visual angle (1.06°), these were compared to the previous hand alone visual stimuli (visual angle: 2.76°).
a four-factor repeated-measures anova was used to test whether the conditions of hand size, visual stimuli, grasp type and muscle differentially affected mep size.
the results of the main anova and the partial eta squared for each statistic are presented in table 2. the anova yielded a trend for a significant grasp × muscle interaction [f(1,14) = 4.43, p = .054].
a significant visual stimuli × muscle interaction [f(1,14) = 4.93, p = .043], where post-hoc analysis reveals that fdi meps were larger during observation of the standard hand compared to the small hand (p = .042).
finally, a significant triple interaction between visual stimuli, grasp and muscle [f(1,14) = 6.82, p = .021] on mep size.
post-hoc analysis revealed that this interaction was driven by fdi meps being significantly larger when observing the standard hand perform precision grip compared to the small hand (p = .028) and during observation of the standard hand performing a precision grip fdi meps were significantly larger than adm meps (p = .048).
there was a trend for fdi meps during observation of the standard hand to be larger when the actor performed a precision grip compared to a whole hand grasp, but this did not quite reach significance (p = .075).
these results reinforce the findings from experiment 1 and show again that observing videos of the grasps is crucial for grasp-muscle specific motor resonance.
importantly, we did not find a significant interaction between hand size, grasp and muscle [f(1,14) = .01, p = .970], suggesting that hand size is unlikely to contribute to grasp-specific motor resonance.
we investigated this further by analysing the effect of observing the standard size hand and small hand during precision grip and whole hand grasp on mep size in the videos alone.
fig.
6 shows the normalised (iti) fdi and adm meps during observation of the standard and small hand alone during precision grip and whole hand grasp videos.
note that there is a crossed pattern effect for both the standard hand and the small hand.
indeed, a significant interaction was found between grasp and muscle for the standard hand [f(1,14) = 6.76, p = .021; fig.
6a] and the small hand condition [f(1,14) = 4.81, p = .046; fig.
6b].
overall, this data reveals that grasp-muscle specific modulation of the corticospinal output when observing different grasping actions is not dependent on the size of the hand being observed.
4 discussion this is the first study to report that changes in m1 corticospinal excitability underlying grasp-specific ‘motor resonance’ can be affected by the visibility of the observed grasp.
fdi and adm muscle responses were differentially modulated depending on the type of dynamic grasp being observed (i.e., precision grip vs whole hand grasp) when subjects viewed the hand only, but not the person.
thus, grasp-specificity of mep amplitude was sensitive to the kinematic information available in the videos, since the visibility of the actor altered the interaction pattern of motor resonance.
our control experiment further reveals that this effect was unlikely to be due to the size of the hand being observed.
interestingly, we show that this grasp-specific motor resonance is modulated by dynamic aspects of actions since videos, but not static images, led to a distinct interaction grasp × muscle interaction.
a fourth important finding is that a large part of the motor resonance effects are not task-specific.
this is evident when we remove the arousal effect from the global motor resonance.
specifically, we have found that baseline meps recorded within the observation block (iti) were significantly larger than those recorded during periods without visual stimuli.
using the iti baseline to normalise meps recorded during action observation revealed that grasp-specific modulation of corticospinal excitability occurred in the inhibition rather than in the facilitation domain.
this is an important finding as it seems action observation mimics mechanisms of surround inhibition seen during actual action preparation and execution (kassavetis et al., 2014, sohn and hallett, 2004), hence further strengthening the link between neural processes underlying action observation and execution.
grasp-specific muscle activation has been found when an individual executes a grasping movement (cattaneo et al., 2005, davare et al., 2009, prabhu et al., 2007).
for example, this can be seen when subjects are presented with two different objects, a pen or a disc, which they have to lift with a precision grip or whole hand grasp, respectively.
execution of precision grip requires more activity in the fdi muscle than for the whole-hand grasp.
conversely, there is more adm muscle activity for a whole hand grasp than a precision grip (cattaneo et al., 2005, davare et al., 2009, prabhu et al., 2007).
this pattern is expected because fdi is a prime mover in precision grip, whereas the adm abducts the little finger during the opening of the hand for whole-hand grasp.
the present study shows that observing a hand (alone) performing a precision grip or whole hand grasp has a similar differential effect on corticospinal excitability.
this may suggest a common neural mechanism underlying both action execution and action observation.
in line with this, studies have shown that changes in corticospinal excitability during observation of specific hand movements are similar to changes in emg patterns during execution of the same movement (alaerts et al., 2010a, fadiga et al., 1995, mccabe et al., 2015, urgesi et al., 2006).
previous action observation studies have shown changes in corticospinal excitability in muscles specific to the task being observed (catmur et al., 2007, cavallo et al., 2012, mccabe et al., 2015, strafella and paus, 2000).
specifically, sartori, bucchioni, and castiello (2012) showed that fdi meps were larger whilst subjects observed a precision grip compared to whole hand grasp and adm meps were larger during observation of whole hand grasp compared to precision grip.
since the authors analysed the muscles independently it is unknown if these effects were powerful enough to produce a significant grasp-muscle interaction.
it could be argued that motor resonance during action observation is similar to motor imagery, as corticospinal excitability also increases during mental rehearsal of an action (fadiga et al., 1999).
indeed, clark, tremblay, and ste-marie (2004) showed that hand muscle meps were equally increased during observation and imagery of a simple hand action.
however, action observation (sartori et al., 2012), grasp execution and preparation all show grasp specificity, whereas motor imagery does not (cattaneo et al., 2005) and therefore may not use the same neural network as action observation.
interestingly, in our study, although the observer watching the whole person videos could see which of the two grasps was being performed, this did not result in any significant grasp-specificity of meps.
the results confirm our prediction that stimuli driving f5c or other regions of pmv influence motor resonance differently.
area f5c responds only to the observation of an acting person but other regions of pmv respond to both observation of a hand alone and the whole person (ferri et al., 2015).
thus, when we probed cse during observation of ‘hand alone’ movements, it seems likely that salient effects on m1 cse came mainly from f5a and other regions of pmv.
however, when probing cse during observation of ‘whole person’ movements, signals from both f5c and other regions of pmv interacted within m1 and biassed cse in a way that abolished grasp-specific effects.
it is important to highlight that cse represents the endpoint measure of a complex circuit which is sensitive to inputs from pmv and other areas.
it is probable that these inputs directly influence discharge in corticospinal neurons, since, at least in the monkey, these neurons can show mirror-like properties (vigneswaran, philipp, lemon, & kraskov, 2013).
in this respect, the resonance during static image presentation may result from the effects of canonical neurons present in f5.
it must be noted that it is possible these results could be due other confounding variables.
for instance, it is possible that the abolition of the grasp × muscle interaction is due to predominance in attending to the moving body, head and eyes.
since seeing a face looking at an object can cause rapid spontaneous shifts in spatial attention towards the same object (langton, o'donnell, riby, & ballantyne, 2006), attention or even overt gaze shifting between the body and the object could diminish these interactions.
however, in the current experiment subjects were instructed to maintain their gaze on the red dot in the centre of the screen whilst observing the actions and attention to the fixation dot was maintained by the dimming task.
additionally, the size of the images and videos were as such that the observer could attend to the whole person without attention or gaze shifts, therefore it is less likely that attention or gaze shifts influenced our results.
it could be argued that the findings from experiment 1, rather than demonstrating specific inputs from pmv, could be a result of the visibility of the grasp since the hand is larger in the hand alone visual stimuli.
thus, if the system is unable to match grasp action observation with execution then motor resonance may be reduced.
however, previous evidence shows that hand size does not prevent subject's grasp perception, indeed psychophysical discrimination experiments show subjects can distinguish types of grasp within this range (orban & platonov, 2015).
to further these results experiment 2 now shows that grasp-specific motor resonance is present irrespective of the size of the hand being observed.
we note that the pattern of the effect is similar when comparing the whole person videos with the small hand videos.
nonetheless, this does not negate the fact that the greater variability within the whole person videos (possibly due to a noisier output from all pmv subsectors) lead to a non-significant grasp-muscle interaction.
thus, the lack of grasp-specific motor resonance whilst observing a whole person is less likely to be due to the relative size of hand.
overall motor resonance was less evident in the adm muscle than in fdi in subjects observing the hand alone and whole person (expt.
1) or small hand alone (expt.
2).
notably, the adm motor resonance was similar when observing the whole person and small hand alone, although less variable in the latter condition.
this might be because the ulnar side of the hand was obscured in the lateral views of the grasps that were presented, particularly in those views in which the hand was smaller.
this could suggest that even though action observation relies on similar mechanisms to action execution, continuous online inputs about kinematics are important to mediate motor resonance.
indeed, evidence from monkey studies shows that neuronal responses evoked by performed actions are dependent on the viewpoint of the observing monkey (caggiano, fogassi, rizzolatti, thier, & casile, 2009).
in humans, studies have demonstrated that the view of the hand when observing actions can be important in motor resonance (alaerts, heremans, swinnen, & wenderoth, 2009; maeda et al., 2002, sartori et al., 2012, urgesi et al., 2006).
specifically, sartori et al.
(2012) revealed stronger motor resonance in the adm than fdi in which subjects viewed grasps from a frontal view.
while the fdi action is more clearly visible than the adm action in the lateral view as in the current experiment, the opposite is true for the frontal view.
as in previous imaging studies (ferri et al., 2015, gazzola et al., 2007, jastorff et al., 2010), it is important to differentiate motor resonance effects following observation of videos from those following observation of static pictures.
the motor resonance we found during viewing of dynamic actions was clearly decreased when observing static pictures.
similarly, revealed greater motor resonance during precision grip action observation compared with its static image counterpart.
however, loporto, mcallister, edwards, wright, and holmes (2012) presented only a single action pinching a big ball in lateral view and hence were unable to document the absence of muscle–grasp interaction for static images.
these differential motor resonance and mr activation patterns of action videos and static frames are consistent with a recent psychophysical study (orban & platonov, 2015) indicating that discrimination thresholds are much lower for action videos than static frames.
a final point is that grasp-specific motor resonance does not modulate cse in the facilitation domain, but rather in the inhibition domain.
this is evident when we subtract the general effect of task arousal to reveal the net action observation effect which is suppressed compared with baseline.
in addition, a similar mechanism has been found during action execution, called surround inhibition, in which muscles that are not involved in the movement will be suppressed (kassavetis et al., 2014, sohn and hallett, 2004).
indeed, many pyramidal tract “mirror” neurons within f5 have demonstrated a complete suppression of discharge during action observation (kraskov, dancause, quallo, shepherd, & lemon, 2009).
but more importantly, vigneswaran et al.
(2013) later found that some corticospinal mirror neurons identified within m1 could also be suppressed during action observation.
this effect could be part of the same mechanism as the one described above, i.e., suppression of unwanted muscle activity during observation, which may be the rule rather than the exception.
5 conclusions in conclusion, we show grasp-specific modulation of corticospinal excitability when the observer views a video of a hand performing an action, which is abolished when the actor is fully visible or when viewing static images taken from the videos.
although we cannot completely exclude other effects on cse that might be produced by viewing videos of the complete actor, the most likely explanation of our results is that such stimuli, driving f5c (ferri et al.
2015), influence motor resonance differently from other subdivisions of f5.
this result underlines the importance of the kinematics of the observed action and indicates significant suppressive rather than facilitatory effects.
we would also like to emphasise the importance of baseline choice when analysing tms data.
for instance, it would be misleading to use terms such “motor facilitation” when referring to action observation motor resonance, as this can entirely depend on the baseline used.
@highlight
motor resonance is the modulation of m1 corticospinal excitability induced by observation of others' actions.
recent brain imaging studies have revealed that viewing videos of grasping actions led to a differential activation of the ventral premotor cortex depending on whether the entire person is viewed versus only their disembodied hand.
here we used transcranial magnetic stimulation (tms) to examine motor evoked potentials (meps) in the first dorsal interosseous (fdi) and abductor digiti minimi (adm) during observation of videos or static images in which a whole person or merely the hand was seen reaching and grasping a peanut (precision grip) or an apple (whole hand grasp).
participants were presented with six visual conditions in which visual stimuli (video vs static image), view (whole person vs hand) and grasp (precision grip vs whole hand grasp) were varied in a 2 × 2 × 2 factorial design.
observing videos, but not static images, of a hand grasping different objects resulted in a grasp-specific interaction, such that fdi and adm meps were differentially modulated depending on the type of grasp being observed (precision grip vs whole hand grasp).
this interaction was present when observing the hand acting, but not when observing the whole person acting.
additional experiments revealed that these results were unlikely to be due to the relative size of the hand being observed.
our results suggest that observation of videos rather than static images is critical for motor resonance.
importantly, observing the whole person performing the action abolished the grasp-specific effect, which could be due to a variety of pmv inputs converging on m1.
