introduction unintended pregnancies are pregnancies that are either unwanted (i.e., they occur when no children or no more children are desired) or mistimed (i.e., they occur earlier than desired).12 unplanned pregnancy is a concept related to unintended pregnancy.
it is said to occur either when a woman used a contraceptive method or when she did not desire to become pregnant but did not use a method.1 in contrast, pregnancies are described as intended if they are reported to have happened at the right time or later than desired (because of infertility or difficulties in conceiving).13 unintended pregnancy mainly results from lack of, inconsistent or incorrect use of effective contraceptive methods2 although pregnancy unintendedness is seen as a complex concept as pregnancy intentions are increasingly viewed as encompassing effective cognitive, cultural, and contextual dimensions.14 the cost of unintended pregnancy is high because the woman has an option of either carrying the pregnancy to term and keep the baby, decide for an adoption, or have an induced abortion.56 nigeria has restrictive abortion laws and that can compound the problem of unintended pregnancies.
births that are unintended by the mother are at elevated risks of adverse social, economic, and health outcomes for the mother and the child.789101112 according to the nigeria demographic and health survey of 2013, total fertility rate is 5.5 children.
nearly one-quarter (23%) of adolescent women aged 15–19 years are already mothers.
young motherhood is highest in the northwest zone (36%).
maternal mortality is high at 576 deaths per 100,000 live births while contraceptive usage among married women was 15%.13 a community survey from northwest part of nigeria showed that majority of young woman aged 15–20 years had given birth to at least one child, with 35% reported have had at least three or more children and 13% reported have had six children.
among women aged 21–24 years, 11% reported having given birth seven times.14 this suggested that closely spaced pregnancies are common possibly due to low contraceptive usage.
unintended pregnancies may therefore be common.
recent data from the united states showed that 49% of pregnancies are unintended.5 in a study among antenatal women in dublin, ireland, the second pregnancy was unplanned in 20.3% of them.15 a similar study among antenatal women in scotland showed that 8.6% of them had unintended pregnancy.16 findings from other parts of the world showed a very high rate of unintended pregnancy among antenatal women, ranging from 49.4% in papua new guinea to 65% in argentina and 65.2% in thailand.171819 in the middle east and north africa, between 15% and 58% of pregnancies were unintended.20 in other parts of africa, unintended pregnancies among antenatal women ranged from 27.9% in eastern ethiopia to 45.5% in central kenyan province.212223 in nigeria, there is a paucity of data on unintended pregnancies among antenatal women.
because of the high fertility rate, closely spaced pregnancies, and low contraceptive usage, there is a need to take a further look at unintended pregnancies.
abuja is cosmopolitan and also the federal capital territory of nigeria.
the population is a representation of the people of nigeria, and therefore, there is the need to conduct this study in abuja.
materials and methods this study is a descriptive, cross-sectional, questionnaire-based survey conducted among women attending antenatal clinic at the university of abuja teaching hospital, gwagwalada, abuja.
a sample size of 254 was arrived at using the formula, n = z2 pq/d2.
where n = desired sample size; z = standard normal deviation = 1.96 at 95% confidence interval; p = prevalence of unintended pregnancy among patients attending antenatal clinic which was 21% from study conducted in lagos;24 q = i– p; d = degree of accuracy desired = 0.05. adding 10% attrition, it was rounded up to 300. three hundred antenatal attendees were randomly recruited into the study between august 2014 and february 2015 after obtaining consent.
semi-structural pretested questionnaires containing both open- and close-ended questions were administered to them by interviewer method.
the questionnaire contained questions on sociodemographic variables, knowledge and practice of contraceptive methods, and social habits such as smoking and taking of alcoholic beverages.
questions on pregnancy intention and history of intimate partner violence were also asked.
data obtained were analyzed using ibm spss statistics for windows version 20 software, usa.
chi-square test was used for tests of associations for categorical variables, and the level of significance was set at p < 0.05. results three hundred women responded to the questionnaire.
table 1 shows the sociodemographic structure of the respondents.
the age range was between 19 and 45 years, with the average of 30.3 ± 4.7 years.
there were more respondents between the age range of 25–34 years (216, 72%).
literacy level was high as 100 (33.3%) and 175 (58.3%) had secondary and tertiary levels of education, respectively.
table 1 also shows that majority of them (95, 31.7%) were into business as occupation while 82 (27.3%) were homemakers and had nothing else doing.
seventy-three (24.3%) were civil servants.
one hundred and sixty-three (54.3%) were multipara while 17 (5.7%) were grand multipara.
table 1 sociodemographic characteristic of the respondents (n=300) all the respondents were married, and the average gestational age at booking was 20.4 ± 7.6 weeks.
two hundred and twelve (70.7%) were christians while 88 (29.3%) were muslims.
table 2 shows that 259 (86.3%) of the respondents were aware of one form of contraception or the other while 41 (13.7%) were not.
despite this level of awareness, 192 (61.9%) had not used any form of contraceptives previously.
among those who had used contraceptives before, condoms (30, 9.7%), injectables (25, 8.1%), and combined oral contraceptive pills were the most common methods used.
table 2 contraceptive awareness and previous usage (n=300) table 3 shows the reasons for not using contraceptives among the 192 respondents.
out of them, 41 (21.3%, n = 192) had no knowledge of contraceptives, 100 (52.1%) did not give any specific reason for not having practiced contraception before while 7 (3.6%) cited husband's dislike for contraceptives as the reason.
five (2.6%) cited religious belief while 9 (4.7%) had preference for natural method.
some of the respondents (3, 1.6%) were afraid of side effects while another 3 (1.6%) did not know how to access them.
table 3 reasons for not using contraceptives (n=192) pregnancy intention is shown in table 4. at the time of conception, the pregnancy was desired in 212 (70.2%) of them.
thirty-five (11.7%) had desired the pregnancy earlier than the time it occurred while 34 (11.3%) had wanted it later.
fourteen (4.7%) never wanted the pregnancy at all while 5 (1.7%) were ambivalent in their response.
those who had desired it later (mistimed) and those who never wanted it at all constituted unintended pregnancy (48, 16%).
table 4 pregnancy intention at the time of conception of current pregnancy (n=300) test of association using chi-square showed significant association between age and unwanted pregnancy (χ2 = 68.56, p < 0.001).
there was no significant association between age and pregnancy desirability at the time of conception (χ2 = 24.46, p = 0.44).
there was no significant association between educational status and unwanted pregnancy (χ2 = 4.20, p = 0.24).
however, there was significant association between parity and unwanted pregnancy (χ2 = 39.92, p < 0.001).
discussion unintended pregnancy is often used as a proxy indicator of poor sexual health, and reducing it is a policy aim of many countries around the world.25 the unintended pregnancy rate of 16.0% found in this study is slightly lower than 21% reported from lagos, nigeria, in a similar study.24 it is also lower than 26% reported from ethiopia.26 much higher figures have been reported from papua new guinea (49.4%), argentina (65%), and thailand (65.2%).171819 it is however higher than 8.6% found among antenatal women in scotland.16 all these studies were carried out among antenatal women.
the issue of unintended pregnancy is a challenge in many countries.18 it is also a social issue because of the adverse health outcomes and risk factors for poor health outcomes for both the baby and the mother.1227 assessing whether or not a pregnancy is unintended is a complex task.
it involves well-known methodological problems.428293031 a woman's risk of unintended pregnancy depends on varying degrees of her socio-economic status and the community where she lives.20 some of the risk factors include extremes of age, educational status, and marital status.
others are access to family planning services and her family's and community attitudes toward family size and contraceptive use.620 older women generally have at least one child, and many may have achieved their desired family size.
they are therefore more likely than the younger ones to report the current pregnancy as unintended.20 in the middle east and north african countries, younger married women have the highest pregnancy rates, and because they make up a large number of all married women of childbearing age, they have the largest number of intended pregnancies.20 a study from the northwestern part of nigeria also showed marriage at young ages where about 93% of women aged 15–20 years had been pregnant, with almost 46% having been pregnant three to four times.14 majority of the respondents in this study were between the age group of 25–34 years.
the statistical analysis, however, showed a significant association between age and unintended pregnancy and also between parity and unintended pregnancy.
lower educational status has been associated with unintended pregnancy.620 the test of association between educational status and unintended pregnancy in this study was not significant.
this could be due to the fact that the educational level among the respondents was high, and hence, they were in a proper position to decide about pregnancy desirability.
despite the high awareness about contraceptives, majority of the respondents had never used any form of contraception.
low level of contraceptive use was also reported by tayo et al.
from lagos.24 in nigeria, contraceptive usage among married women is generally low (15%).13 in developing countries, the most important determinant of declining fertility is the effective use of contraceptives.3233 a large number of those who had not used contraceptives before did not give any specific reason.
others stated lack of awareness while a few sited husband's dislike, religious beliefs, fear of side effects, and nonaccess to contraceptives.
in egypt, infrequent sex, fear of side effects, and health concerns were the main reasons for not using contraceptives.34 in argentina, reasons that have been adduced for nonuse of contraceptives among pregnant women include cost, attitudes of service providers, and lack of information.18 more than 40% of women whose pregnancies were unintended from a study in argentina reported that they had not been using contraceptive methods because they were unaware that they needed contraception.18 conclusion in the federal capital territory of nigeria, unintended pregnancy among married women is high.
despite the high awareness of contraceptives and high educational status, the utilization of contraceptive services is low.
the reason why a good number of them do not utilize family planning services is not known.
effective use of contraceptives can prevent unintended pregnancies.
there is, therefore, need to ensure women's access to quality family planning information and services.
adequate information, education, and communication materials for contraceptives could be provided during antenatal health talk and community advocacy.
this will contribute to the reduction of unintended pregnancies among married women in our society.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
background: unintended pregnancy is a pregnancy that is either unwanted or mistimed.
the objectives of this study were to determine the prevalence of unintended pregnancy as well as to document the determinant factors among pregnant women attending antenatal clinic at the university of abuja teaching hospital, gwagwalada, abuja, nigeria.
materials and methods: this was a descriptive, cross-sectional study of 300 women attending the antenatal clinic of the teaching hospital.
information on sociodemographic characteristics, desirability of the current pregnancy at the time of conception, and knowledge and practice of contraceptive methods were collected using a pretested questionnaire.
the data obtained were analyzed using spss version 20. chi-square test was used for tests of associations with the level of significance set at p < 0.05. results: the average age of the respondents was 30.0 ± 4.7 years.
overall, 33.3% and 58.3% of the respondents attained secondary and tertiary levels of education, respectively.
the prevalence rate of unintended pregnancy was 16%.
contraceptive awareness was quite high (259, 86.3%).
however, contraceptive usage was low as 192 (61.9%) had never used any form of contraceptives.
univariate analysis using chi-square test showed a statistically significant association between age and unwanted pregnancy (χ2 = 68.56, p < 0.001), as well as between parity and unwanted pregnancy (χ2 = 39.92, p < 0.001).
conclusion: the prevalence of unintended pregnancy among women attending antenatal clinic is high, possibly due to low contraceptive usage.
adequate information, education, and communication materials should be provided during antenatal health talks.
advocacy visits for community sensitization should also be increased.
