introduction chronic myeloid leukemia (cml) originates from a pluripotent hematopoietic stem cell (hsc) that acquires the t(9;22)(q34;q11) translocation, i.e.
the hallmark cytogenetic aberration of cml.
this translocation, commonly referred to as the philadelphia (ph1) chromosome, leads to a fusion protein, where the 5′ part of the bcr gene is fused to the 3′ part of the abl1 gene1–4, results in significantly increased tyrosine kinase activity and cell proliferation.
while more than 95% of cml patients carry the bcr-abl1 fusion gene5, a minor proportion of acute lymphocytic leukemias (all) and acute myeloid leukemias (aml) may also harbor the bcr-abl1 fusion6.
the characteristic t(9;22) translocation is detected by routine cytogenetics through karyotyping or fluorescence in situ hybridization (fish)7, or the bcr-abl1 fusion transcript can be demonstrated by real-time quantitative pcr (rq-pcr)8, 9. due to various possible breakpoints of the bcr-abl1 fusion in different patients, rq-pcr must encompass the most common variants, i.e.
the major variant (210 kda) and the minor variant (190 kda)10, where the former is predominant in cml11, 12. today’s successful treatment of cml patients is based on blocking of the atp-binding site in the abl1 domain, hence inhibiting its tyrosine kinase activity13.
tyrosine kinase inhibitors (tkis) such as imatinib and nilotinib efficiently inhibit the oncogenic effects of the bcr-abl1 fusion protein.
the current gold standard method for monitoring therapy responses in cml is based on rq-pcr of the bcr-abl1 transcripts to determine whether the patient achieves and remains in molecular remission (<0.1%) or if bcr-abl1 positive cells still persist, i.e.
minimal residual disease (mrd).
due to the risk of developing resistance mutations in the abl1 domain, bcr-abl1 transcript levels are monitored every third month to get early indications of any increased mrd levels signifying an impending clinical relapse.
in recent years, attempts have been made to discontinue therapy in cml patients in longstanding molecular remission14, 15. however, even patients with complete molecular responses to tkis may relapse after discontinuing treatment as a consequence of small numbers of remaining leukemic stem cells (cd34+/cd38−)14–17.
although rq-pcr is a powerful method for routine diagnostics used worldwide, the possibility to apply sensitive, flow cytometry to detect cells expressing bcr-abl1 fusion proteins could prove convenient both at diagnosis and at follow-up.
accordingly, we describe a novel approach to monitor cml patients by quantifying leukocytes harboring the bcr-abl1 fusion at the protein level.
this method, herein called pla-flow, uses the in situ proximity ligation assay (in situ pla)18, 19 to detect the bcr-abl1 fusion protein inside cells (fig.
1).
the pla-flow protocol uses one antibody directed against the bcr part of the fusion protein and another one against the abl1 part; each antibody carries a dna oligonucleotide that, once in proximity, guide the formation of a dna circle upon hybridization and ligation of two subsequently added dna oligonucleotides.
the ligated dna circle can then be amplified by rolling circle amplification (rca) and the localized rca products are detected by hybridization of fluorophore-coupled oligonucleotides.
finally, the fluorescence intensity of individual cells is measured by flow cytometry.
we demonstrate that pla-flow is a rapid, sensitive and specific method with results that correlate well with those of rq-pcr for the fusion transcript.
in addition, usage of flow cytometry gives the advantage of simultaneously investigation of surface markers commonly applied in the clinical routine setting.figure 1detection of cells expressing bcr-abl1 with pla-flow.
the assay employs a pair of oligonucleotide-conjugated antibodies (pla probes) with affinity for the bcr and abl1 domains of the fusion protein in fixed and permeabilized cells (a).
the oligonucleotides on pla probes remaining in close proximity after washes serve as templates for hybridization of two additional dna oligonucleotides, guiding their ligation into dna circles (b).
after ligation, the dna circles are locally amplified by rolling circle amplification (rca) to generate rca products that are visualized and detected by addition of complementary fluorophore-labeled oligonucleotides (c), followed by detection of labeled cells via flow cytometry.
results establishing the flow cytometry-based pla assay conditions for detecting bcr-abl1 fusion proteins through in situ pla with flow cytometry as readout, pla-flow (fig.
1), were established using k562 cells that carry the bcr-abl1 fusion, while the bcr-abl1 negative cell line u937 was used as a negative control.
briefly, cells to be analyzed were fixed and permeabilized before being subjected to reagents for pla-flow, followed by detection of labeled cells by microscopy or flow cytometry.
the k562 cell line exhibited brightly positive staining in the bcr-abl1 assay, whereas u937 cells were negative, confirming the selectivity of the assay.
similarly, cells positive for the bcr-abl1 fusion protein were detected in samples from cml patients, while healthy control samples lacked specifically labeled cells (fig.
2).figure 2 in situ pla detection by fluorescence microscopy of bcr-abl1 fusion protein.
(a) detection of the bcr-abl1 positive cell line k562, (b) detection of the bcr-abl1 negative cell line u937, (c) cells from a patient treated for cml, (d) nucleated blood cells from a healthy individual.
signals were recorded using (e) pla-flow for detection of bcr-abl1 in the bcr-abl1 negative cell line u937 compared to (f) the bcr-abl1 positive cell line k562.
experiments were repeated more than three times.
once the staining protocol was established, the pla-flow assay was applied to analyze nucleated cells in blood samples from five patients with newly diagnosed with cml and five samples from cml patients under treatment.
the samples were tested on the same day at the clinical laboratory using the standard rq-pcr method for bcr-abl1 major detection8.
for each cml sample analyzed, a negative control with blood from an age-matched healthy individual was also analyzed, and as a technical negative control the proximity probes were omitted from cml patient samples.
overall, the pla-flow gave results similar to those from rq-pcr, with minor differences observed in some patients (fig.
3).figure 3pla-flow detection of bcr-abl1 positive cells from patients diagnosed with cml and normal controls.
the top row dot-plots are examples from analysis with pla-flow of newly diagnosed patients, while the middle row represents patients previously treated or under treatment.
at the time for sample collection, patients 7 and 9 were treated with imatinib, patient 10 did not receive any treatment and patients 14 and 17 were treated with dasatinib.
the cells were gated first for side and forward scatter and then a positive gate was placed around cells that were considered positive compared to a negative control.
the negative control used for gating was a patient sample that was not subjected to any pla probes.
the bottom row displays examples of the negative controls, i.e.
two samples from healthy individuals and one sample from a patient where no pla probes were added.
the patient samples were also analyzed with rq-pcr to estimate bcr-abl1 transcript levels.
results from both analyses are indicated below each plot where applicable.
in addition, both pb and bone marrow cells from two cml patient samples, one newly diagnosed with a high number of bcr-abl1 transcripts and one treated patient with a low number of bcr-abl1 transcripts, were analyzed by pla-flow.
the results were comparable with a higher number of positive cells in the pb sample for both patients (supplemental table s1).
applying pla-flow for mrd detection since monitoring mrd is crucial during treatment of cml patients, we followed two cml patients with pla-flow and rq-pcr at the time of diagnosis and at three-month intervals for nine months, and the two methods revealed consistent results (fig.
4).
we next investigated the sensitivity of pla-flow by spiking blood from a newly diagnosed cml patient with 19.3% bcr-abl1-positive cells in blood samples from healthy donors in a dilution series.
while the pla-flow could clearly detect positive cells at a dilution of 1:1000, some bcr-abl1-positive cells were also seen above background at a dilution of 1:10,000 (fig.
5).figure 4long-term follow-up of newly diagnosed patients.
two cml patients were followed from the time of initial diagnosis, by measuring bcr-abl1 positive cells using pla-flow and bcr-abl1 transcript levels using rq-pcr, every 3 months over a period of 9 months.
(a and b) display results for patient 1 and 2, respectively, analyzed with pla-flow (diamonds) and rq-pcr (circles).
figure 5demonstration of the sensitivity of pla-flow.
blood from a newly diagnosed cml patient was spiked in blood from a healthy individual in a ten-fold dilution series.
samples were analyzed with pla-flow to detect positive cells expressing the fusion protein bcr-abl1.
the x-axis indicates the dilutions, while the y-axis displays percentages of cells expressing bcr-abl1.
error bars represent standard deviation (sd).
to further compare the performance of pla-flow with rq-pcr, and to see how well suited pla-flow is for mrd quantification in a routine setting, we assessed an extended series of 81 samples from 36 cml patients, all positive for the bcr-abl1 major variant, both newly diagnosed (n = 7) and patients that at the time of sampling were under treatment with tkis, such as imatinib, dasatinib, nilotinib and ponatinib, or had previously undergone tki treatment (n = 29; supplementary table s2).
as seen in fig.
6, a strong correlation of levels was demonstrated between the two methods; ρ = 0.93 (p = 0.0067) for samples taken at diagnosis, and ρ = 0.7 (p = <0.001) for follow-up samples.
in the 51 samples with rq-pcr values <0.1%, 43 samples showed concordant results (31 samples were positive and 12 negative with both techniques), while discordant results were observed in eight samples (five samples were positive by rq-pcr only and three samples by pla-flow only).
hence, pla-flow detected most samples with mrd levels below 0.1% as determined by rq-pcr, although discrepancies were observed.
there was a strong concordance for detection via rq-pcr versus pla-flow among the patients.
however, the levels measured by the two assays were not strictly correlated.
this is not surprising since total rna levels on the one hand, and numbers of cells positive for the fusion protein on the other, may well vary independently if numbers of transcripts per cell vary in different patients.
we are currently planning single cell analyses of rna and protein levels in patients to investigate if such variation can be demonstrated between individual patients, and perhaps as an effect of therapy.figure 6correlation of bcr-abl1 fusion protein positive cells as determined by pla-flow and bcr-abl1 fusion transcript levels as determined by rq-pcr.
a total of 81 samples from 36 different patients were analyzed and compared; seven samples (indicated with red circles) represented samples analyzed before initiation of therapy, whereas the remaining samples were collected at follow-up.
two correlations were performed, one for follow-up samples (ρ = 0.7) and one for diagnostic samples (ρ = 0.93).
patient numbers and numbers of samples investigated for each patient is indicated with different colors/symbols.
combining pla-flow and cd34 staining analysis of blood cells from cml patients by pla-flow provides an attractive opportunity to simultaneously analyze other cellular markers.
to explore this we used immunofluorescence staining with antibodies directed against the stem cell and progenitor marker cd34, applied before the pla reaction.
the flow cytometric analysis revealed populations of malignant cells expressing only the bcr-abl1 fusion protein or that were double positive for bcr-abl1 and cd34 (fig.
7).
the results underscore the potential of this technique to further characterize malignant cells expressing fusion proteins.figure 7simultaneous staining of cml cells for bcr-abl1 and for cd34.
(a) the image displays simultaneous immunofluorescence staining for cd34 during bcr-abl1 pla-flow in a newly diagnosed cml patient.
three distinct populations were observed: a major population negative for both bcr-abl1 and cd34, one subpopulation (13.8%) expressing bcr-abl1 but not cd34, and one subpopulation (1.8%) positive for both cd34 and bcr-abl1.
(b) the same experiment was performed on a healthy individual as a negative control.
the x-axes represent intensity of staining against bcr-abl1 and the y-axes reflect the cd34 staining.
discussion cml is currently diagnosed and monitored over time using rq-pcr in routine practice.
this standardized assay provides quantitative measurement of number of transcripts of the bcr-abl1 fusion gene in pb cells.
the assay is known to reflect the level of residual tumor cells in patients undergoing tki treatment8.
here, we present a novel approach for directly detecting and counting individual cells that carry the bcr-abl1 fusion protein through a procedure we call pla-flow.
similar to rq-pcr, the pla-flow method demonstrated a high sensitivity and specificity, hence highlighting its potential suitability for routine diagnostic testing and mrd measurements.
in many hematological malignancies, flow cytometry is the method of choice for diagnosis and monitoring the course of disease.
however, to date, no method has been available to identify and quantify bcr-abl1-positive cells using flow cytometry, at least to our knowledge.
the present approach combines the advantage of flow cytometry with specific and sensitive detection of the bcr-abl1 positive leukemic cells using the in situ pla.
the assay provides rapid detection of bcr-abl1 using flow cytometry, particularly attractive in the diagnostic setting, and it represents a novel tool for identification and enumeration of bcr-abl1-positive cells that can easily be incorporated in the current diagnostic set-up for cml and other types of leukemia along with routine morphologic and phenotypic assessment.
taking a step further, we investigated if the pla-flow assay could be combined with detection of other surface markers, as this would enable characterization of subpopulations among cells expressing the bcr-abl1 protein in a patient sample.
in fact, by parallel immunostaining for the stem-cell marker cd34, we detected distinct subpopulations among cells expressing the bcr-abl1 fusion protein, according to whether or not they also expressed the cell surface marker cd34.
this combined approach can thus offer novel insights into cellular dynamics involved in disease progression in patients, and in their responses to tki treatment.
this was illustrated in a recent study demonstrating that flow cytometry after immune-staining of membrane markers for aberrant cells served to predict early blast transformation in cml20.
for monitoring therapy response in cml, it is of outmost importance to be able to quantify also very low levels of bcr-abl1 positive cells, also to get an early indication of increasing bcr-abl1 levels and an impending relapse.
we followed two patients over nine months from diagnosis, with similar results over time for pla-flow and rq-pcr.
in a broader investigation, we directly compared pla-flow and the routinely used rq-pcr in 81 diagnostic and follow-up samples, again demonstrating a high concordance between the two methods.
considering the 51 samples that had rq-pcr values below 0.1%, representing the clinically relevant cut-off level for a major molecular response (mmr) in cml, pla-flow showed concordant results to rq-pcr in the majority of samples (86%).
however, in five samples only rq-pcr was able to detect positive cells, while in another three samples only pla-flow gave positive results.
it is quite possible that the percentages reported for rq-pcr cannot be directly translated to tumor cell percentages, since numbers of fusion transcript and fusion protein per cell may differ within and between different patients with cml.
it remains to be determined if and how the prognostic value of the two assays may differ, but the ability to simultaneously assess other markers present on the leukemic cells can present a fuller picture of the patients’ malignancy.
in conclusion, we present the pla-flow method, serving to detect and enumerate cells expressing the bcr-abl1 fusion protein via flow cytometry, also enabling simultaneous immunostaining of other markers.
considerably larger patient series, including serial samples, will need to be analyzed to evaluate the relative merits of the pla-flow method versus the established rq-pcr technique, and to determine the mmr cut-off for pla-flow.
nonetheless, this new tool holds significant potential for routine diagnostics, eventually as a stand-alone test without the need for cytogenetics, fish or rq-pcr.
this novel technique also opens up the opportunity to study specific cell populations involved in disease progression in cml.
methods patients and healthy controls peripheral blood (pb) samples were obtained from 36 cml patients.
seven samples were collected at diagnosis prior to any drug treatment, while 74 follow-up samples were collected during treatment or after treatment was terminated (supplementary table s2).
pb samples were also obtained from age-matched healthy individuals.
bone marrow samples were obtained from one patient at diagnosis and one at follow-up during treatment.
the study was approved by the regional ethics committee in uppsala (dnr.
2010/198 u-can), and was conducted in accordance with the declaration of helsinki.
informed consent was obtained from all subjects.
preparation of samples from patients and healthy controls freshly collected whole blood was mixed with 1–2x the blood volume of 1x bd-pharm lyse (bd biosciences, san jose, usa) to lyse red blood cells.
the samples were vortexed and incubated for 5 min at room temperature (rt), followed by a 3 min centrifugation at 1,200 r.p.m, after which the cell pellets were mixed with 1.5x the starting blood volume of 1x bd-pharm lyse, vortexed and centrifuged again for 3 min at 1,200 r.p.m.
bone marrow samples were treated as the peripheral blood (pb) samples.
the cells were washed in 1x pbs, and after another centrifugation the cells were fixated and permeabilized as described below.
pb from a newly diagnosed cml patient was spiked into pb from healthy individuals.
the pb samples were first mixed in a serial dilution, and then the red blood cells were lysed, followed by fixation and permeabilization and then in situ pla.
cell culture, fixation and permeabilization k562 and u937 cell lines, positive and negative for the bcr-abl1 fusion protein, respectively, and commercially available from atcc, were used to establish parameters for the assay.
the cells were tested for mycoplasma using mycoplasma detection kit-quick test (biotool).
both cell lines, negative for mycoplasma contamination, were grown in rpmi 1640 medium supplemented with 10% fetal bovine serum (fbs), 2 mm l-glutamine and 100 u/ml-100 µg/ml penicillin-streptomycin (sigma-aldrich, st. louis, usa).
cells were collected and fixated by adding formaldehyde (sigma-aldrich) directly to the medium to a final concentration of 1% and incubated for 10 min at rt.
the cells were pelleted and vigorously vortexed in 2 ml ice cold meoh (sigma-aldrich) and incubated for 10 min at 4 °c, followed by 2 washes with 1x pbs + 1% bsa (new england biolabs, boston, usa), before continuing with the pla-flow protocol.
during the development of the final protocol for pla-flow several conditions of fixation and permeabilization methods were tested.
the final and optimized protocol described here is suitable for both cell lines and patient material.
antibodies for detection of the bcr-abl1 fusion protein to demonstrate the fusion proteins, we used a polyclonal sheep igg-anti-human bcr antibody, directed against lys174-asp331 at the n-terminus of the bcr protein, and a polyclonal goat igg-anti-human abl antibody directed against ala941-val1140 at the c-terminus of the abl protein.
these two target domains are expected to be present in all variants of the fusion protein.
the antibodies were both purchased from r&d systems, minneapolis, usa.
simultaneous staining for cd34 during pla-flow a pacific blue anti-human cd34 antibody (cat.
no.
343512) was purchased from biolegend, san diego, usa.
antibodies against the cell surface protein cd34 were added to the blood samples after fixation and a brief wash with 1x pbs.
2 µl of the cd34 antibody, starting concentration 0.1 mg/ml, was added directly to the cell pellet.
after 30 min incubation at rt in the dark, 1% formaldehyde was added for another fixation for 10 min at rt.
the cells were then washed, followed by permeabilization and application of the pla-flow protocol.
flow cytometry readout of pla-based detection reactions cells were washed by centrifugation, unless stated otherwise.
centrifugation was carried out at 1,200 r.p.m for 3 min.
all pla-flow reaction steps were performed in a volume of 100 µl.
antibodies directed against bcr and abl1 were conjugated to oligonucleotides using duolink in situ probemaker (sigma-aldrich), according to the manufacturer’s instructions.
a minimum of 5 × 106 cells was used for each pla-flow reaction.
blocking was performed in 500 µl blocking buffer (odyssey blocking buffer, li-cor-tbs, lincoln, usa) for 45 min at 37 °c.
after a brief centrifugation the blocking agent was decanted and pla probes, diluted 1:50 in duolink in situ antibody dilution mix (sigma-aldrich), were added to the cells for a 90 min incubation at 37 °c, or overnight at 4 °c.
cells were then washed in 1x tris-buffered saline (tbs) with 0.05% tween20 (sigma-aldrich) (tbst).
hybridization of the circularization oligonucleotides and ligation were carried out by incubating the cells with 125 nm circularization oligonucleotides in ligation buffer (10 mm tris acetate, 10 mm magnesium acetate, 50 mm potassium acetate, 12.5 mm nacl, ph 7.5), 0.125 µg/µl bsa (new england biolabs), 0.025% tween 20, 0.5 mm atp (fermentas, waltman, usa), 0.02 u/µl t4 dna ligase (fermentas) for 30 min at 37 °c.
after one wash with tbst, the cells were incubated with the reagents for rca.
0.5 u/µl phi-29 dna polymerase (fermentas) was mixed with rca buffer (2x phi-29 dna polymerase-buffer, ph 7.5 (fermentas), 0.25 µg/µl bsa, 0.5 mm dntp (thermo fisher scientific)) and incubated for 90 min at 37 °c.
cells were washed once with tbst and incubated for 15 min at 37 °c with 10 nm bodipytr-fluorophore-coupled oligonucleotides in hybridization buffer (20 mm tris-hydrochloride, 20 mm edta, 1% tween 20, 1 m nacl).
after one wash with tbst the cells were placed in pbs and analyzed with a bd lsrii or bd fortessa flow cytometer.
the gating of the samples was first performed by placing a gate around the white blood cells using fsc and ssc.
thereafter, gates were placed around the positive events, representing cells positive for bcr-abl1, and counted.
data analysis was performed using bd facsdiva software version 8.0 (bd biosciences).
spearman’s rank correlation coefficient was applied to test correlation.
all relevant data are available from the authors.
the rq-pcr method in routine analysis were performed as previously described by van dongen et al.8.
electronic supplementary material supplementary info
@highlight
chronic myeloid leukemia (cml) is characterized in the majority of cases by a t(9;22)(q34;q11) translocation, also called the philadelphia chromosome, giving rise to the bcr-abl1 fusion protein.
current treatment with tyrosine kinase inhibitors is directed against the constitutively active abl1 domain of the fusion protein, and minimal residual disease (mrd) after therapy is monitored by real-time quantitative pcr (rq-pcr) of the fusion transcript.
here, we describe a novel approach to detect and enumerate cells positive for the bcr-abl1 fusion protein by combining the in situ proximity ligation assay with flow cytometry as readout (pla-flow).
by targeting of the bcr and abl1 parts of the fusion protein with one antibody each, and creating strong fluorescent signals through rolling circle amplification, pla-flow allowed sensitive detection of cells positive for the bcr-abl1 fusion at frequencies as low as one in 10,000. importantly, the flow cytometric results correlated strongly to those of rq-pcr, both in diagnostic testing and for mrd measurements over time.
in summary, we believe this flow cytometry-based method can serve as an attractive approach for routine measurement of cells harboring bcr-abl1 fusions, also allowing simultaneously assessment of other cell surface markers as well as sensitive longitudinal follow-up.
