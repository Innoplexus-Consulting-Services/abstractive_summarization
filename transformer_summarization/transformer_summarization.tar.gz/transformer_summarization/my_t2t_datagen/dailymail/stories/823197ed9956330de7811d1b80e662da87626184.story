the global increase in resistance to the third-generation cephalosporins and fluoroquinolones among extraintestinal pathogenic escherichia coli (expec) is a public health concern because of the importance of these drugs in treating serious infections (1).
the extended-spectrum β-lactamases (esbls), especially ctx-m types, contribute to third-generation cephalosporin resistance among expec, and specific mutations in quinolone resistance–determining regions in gyra and parc mainly contribute to fluoroquinolone resistance (2).
the increase in resistance among expec has resulted mainly from the recent expansion of a pandemic clonal group known as e. coli sequence type (st) 131, which is usually multidrug resistant and is associated with ctx-m-15, the most prevalent β-lactamase among esbl-producing expec (2).
st131 harbors more virulence factors than other antimicrobial-resistant expec and can cause severe infections (2,3).
recent studies using whole-genome sequencing (wgs) analysis revealed that st131 comprises different lineages or clades (4,5).
price et al.
found a dominant fluoroquinolone-resistant lineage (named h30r) in north america that contains the fimh 30 allele and was associated with characteristic quinolone resistance–determining region mutations (2,4).
st131 with the blactx-m-15 gene formed a distinct cluster within the h30r lineage, referred to as the h30rx clade (4).
petty et al.
confirmed these findings using a collection of strains from 6 countries (5).
in their study, h30r and h30rx clades correspond to clade c and clade c2 (subset of clade c), respectively.
the other clade c subset, clade c1, included st131 isolates with different ctx-ms than blactx-m-15.
globally, the ctx-m-15–producing c2/h30rx clade is mostly responsible for the pandemic of expec with esbls (2), but in japan, expec with blactx-m-15 is rare despite the predominance of st131 among esbl-producing isolates (6).
before 2005, st131 c1/h30r negative for rx containing blactx-m-14 predominated among japanese st131 (6).
in 2006, st131 c1/h30r with blactx-m-27 was detected in japan, and the numbers of this lineage escalated since 2010 and are responsible for the substantial increase of esbl-producing expec in japan (6).
moreover, blactx-m-27 is confined to st131, whereas other ctx-ms, such as blactx-m-14 and blactx-m-15, are equally present among st131 and non-st131 e. coli isolates (3).
blactx-m-27 is an infrequent global blactx-m allele that differs by only 1 nt from blactx-m-14, which results in 1 aa change at position 240 (1,6).
st131 with ctx-m-27 had previously been reported from other countries, such as korea (isolation year 2008), china (2013–2014), australia (2009–2010), nepal (2013–2014), cambodia (2004–2005), israel (2008–2009), czech republic (2008–2011), switzerland (2011), spain (2012), france (2012), portugal (2013–2014), netherlands (2011), canada (2005), and united states (2013) (2, 5–15).
because of the rapid increase of ctx-m-27–producing st131 in japan since 2010 (6), we designed a study to characterize these isolates using wgs techniques.
materials and methods bacterial isolates we selected 43 nonduplicate st131 clinical isolates collected from 2 multicenter surveillance programs in japan for wgs to represent 3 major esbl-producing st131 (ctx-m-27–producing h30r, 13 isolates; ctx-m-14–producing h30r, 9 isolates; ctx-m-15–producing h30rx, 11 isolates) and other st131 (ctx-m-14+ctx-m-15–producing h30rx, 2 isolates; ctx-m-14–producing h30rx, 1 isolate; ctx-m-14–producing h22, 1 isolate; ctx-m-2–producing h22, 1 isolate; tem-producing h30, 2 isolates; non–esbl-producing h30r, 3 isolates) in japan (6) (table).
one of the surveillance programs collected esbl-producing e. coli isolates during 2001–2010 at 10 acute-care hospitals in the kyoto and shiga prefectures of japan (6); the other program collected all e. coli isolates during december 2014 at 10 acute-care hospitals in the 5 prefectures in central japan.
st131 isolates were identified by pcr specific for mdh and gyrb alleles, o25b or o16 rfb variants, fimh allele, and h30rx status (6).
the selection process of the japanese st131 ensured equal representation by geographic location, specimen type, and date of isolation.
table escherichia coli st131 isolates included in study of the global expansion of a single clade* type of esbl country/prefecture of isolation (no.
isolates; year) h30 h22, n = 2 h30r h30, n = 2 h30r, n = 39 h30rx, n = 18 ctx-m-27, n = 21 japan/kyoto, shiga, aichi (13; 2004–2014), australia (3; 2009, 2010),† united states (2; 2013, 2014),‡ canada (1; 2008), thailand (1; 2013), vietnam (1; 2011) ctx-m-14, n = 17 japan/kyoto, shiga, hyogo (9; 2002–2014), canada (2; 2005, 2009),† france (1; 2008), new zealand (1; 2010), south africa (1; 2008), united states (1; 2008) japan/kyoto (1; 2009) japan/kyoto (1; 2007) ctx-m-15, n = 15 japan/kyoto, shiga, osaka (11; 2006–2014), canada (2; 2009), uk (1; 2005),§ united states (1; 2008)¶ ctx-m-14 and ctx-m-15, n = 2 japan/kyoto (2; 2010, 2014) ctx-m-2, n = 1 japan/kyoto (1; 2004) tem, n = 2 japan/kyoto  (2; 2005, 2009) negative, n = 3 japan/shiga, hyogo, osaka  (3; 2014) *esbl, extended-spectrum β-lactamase; st, sequence type.
†raw reads were downloaded from european nucleotide archive (accession no.
era118286) for 3 isolates from australia (s100ec, s107ec, s108ec) and 1 isolate from canada (s135ec).
‡mrsn17749 draft genome (genbank assembly accession no.
gca_000770275.1) and ieh71520 draft genome (genbank assembly accession no.
gca_000681435.1).
§ec958 complete genome (genbank assembly accession no.
gca_000285655.3).
¶jj1886 complete genome (genbank assembly accession no.
gca_000493755.1).
in addition to isolates from japan, we obtained 10 ctx-m–producing st131 isolates from global collections that previously had been characterized by multilocus sequence typing (mlst) (table; technical appendix table 1).
we selected all of the ctx-m-27 producers, 1 ctx-m-14 producer per country, and 2 ctx-m-15 producers.
we also sought public databases for st131 h30 and included sequence data for 8 isolates from countries other than japan: ctx-m-27 producers (3 raw reads, 2 draft genomes); ctx-m-14 producer (1 raw read); and ctx-m-15–producing c2/h30rx (2 complete genomes) (table; technical appendix table 1) (5,9,16–18).
wgs we used the nextera xt dna sample preparation kit (illumina, san diego, ca, usa) to prepare libraries for sequencing.
samples were multiplexed and sequenced on an illumina miseq for 600 cycles (300-bp paired-end) or nextseq500 for 300 cycles (151-bp paired-end).
the st131 genomes were sequenced at an average depth of 44.03 (sd ± 14.70) and an average coverage of 97.73% (sd ± 0.93%) using the 5,109,767-bp ec958 chromosome as previously described (16).
core genome analysis we used a core genome single-nucleotide polymorphism (snp)–based approach to create a phylogenetic tree.
we identified snps using raw read mapping followed by duplicate read removal, realignment, quality score recalibration, and variant filtering (technical appendix).
reads from 53 isolates sequenced in this study and 4 isolates (s100ec, s107ec, s108ec, and s135ec) (5) were aligned against a reference genome of ec958, and snps were called.
the remaining 4 draft or complete genomes underwent whole-genome alignment against ec958 to make ec958-like pseudo-chromosomes that contained only snps.
the snp-only core genome was identified as the blocks of >500 bp common to all 61 study isolates to ensure that each block represented a common segment from good alignment in each isolate and that the block had enough length to enable identification (5).
a maximum-likelihood tree was built using raxml (19).
a recombination-free tree was also build by excluding recombination sites identified using a bayesian analysis software bratnextgen (20).
comparative genomic analysis to define presence of genes and their alleles, we used srst2 with trimmed reads or blast+ (executables [http://blast.ncbi.nlm.nih.gov/]) with assembled draft genomes and following databases or typing schemes: resfinder antimicrobial resistance gene database, vfdb and virulencefinder virulence gene databases, serotypefinder o:h typing database, plasmidfinder plasmid replicon database, mlst (http://mlst.ucc.ie/mlst/dbs/ecoli), plasmid mlst, fimh typing, gyra/parc typing, st131 virotyping, and detection of h30rx-specific ybbw snps, plasmid addiction systems, and blactx-m genetic environment (online technical appendix).
we used pangenome analysis to identify clade specific segments among draft or complete genomes.
brig was used to visualize similarity of genomes to st131 genomic islands (16) and to the st131 reference plasmid pec958 (21).
statistical analysis and sequence data accession numbers we compared categorical variables using fisher exact test.
a p value <0.05 was considered statistically significant.
we conducted our statistical analysis using stata, version 13.1 (statacorp, college station, tx, usa).
the sequences were deposited in the ddbj sequence read archive database (accession no.
dra004266 and dra004267).
results bacterial isolates the study comprised 60 clinical and 1 environmental st131 isolates (table; technical appendix table 1).
we confirmed the types of β-lactamase genes, st131 status, fimh allele numbers, and h30rx status using draft genomes.
core genome snp-based phylogenetic tree we identified a 4,086,650-bp core genome that included 5,280 snps by mapping and alignment of the 61 study isolates to ec958 (figure 1).
the ciprofloxacin-resistant isolates with gyra 1ab and parc 1aab alleles formed the c/h30r cluster that comprised the c2/h30rx and c1/h30r clades.
the c2/h30rx clade included isolates with blactx-m-15 (n = 15) and blactx-m-14 (n = 1) and isolates with both blactx-m-15 and blactx-m-14 (n = 2) (figure 1).
the c1/h30r clade included isolates with blactx-m-27 (n = 21) and blactx-m-14 (n = 14) and isolates without esbls (n = 3) (figure 1).
within the c1/h30r clade, 19 of 21 ctx-m-27–producing isolates clustered into a distinct group, named the c1-m27 clade (figure 1).
e. coli st131 c1-m27 comprised isolates from japan (n = 13; isolation years 2004–2014), australia (n = 2; 2009–2010), united states (n = 2; 2013–2014), canada (n = 1, 2008), and thailand (n = 1, 2013).
figure 1 core genome single-nucleotide polymorphism (snp)–based phylogenetic tree of escherichia coli sequence type (st) 131 isolates.
this maximum-likelihood phylogram is based on a 4,086,650-bp core genome and a total of 5,280 snps.
the tree is rooted by using the outgroup h22 isolates, and asterisks indicate bootstrap support >90% from 100 replicates.
strains that had previously been sequenced are in bold.
the country columns indicate places of isolation: ja to jw, japan (a to w indicates hospitals); au, australia; ca canada; fr, france; nz, new zealand; sa, south africa; th, thailand; uk, united kingdom; us, united states; vi, vietnam.
environment column shows a type of genetic environment of esbl genes (technical appendix table 2).
fq columns indicate ciprofloxacin susceptibilities (s, susceptible; r, resistant).
ksec7 had a parc 1ae allele including g250a (s80k) mutation in addition to a 1a allele.
the ciprofloxacin-resistant c/h30r cluster comprised the c2/h30rx and c1/h30r clades.
all of the h30rx isolates belonged to the c2/h30rx clade.
the c1/h30r clade included ctx-m-14–producing h30r, non–esbl-producing h30r, and ctx-m-27–producing h30r isolates.
ctx-m-27–producing isolates belonged to the c1-m27 clade within the c1/h30r clade except 2 isolates (s100ec and ec# 584).
the bootstrap value for the root of the c1-m27 clade was 64%.
an average of 68 snps was found among the c1-m27 clade, whereas an average of 158 snps was found between the c1-m27 clade and 2 non–c1-m27 clade isolates with blactx-m-27.
scale bar indicates 100 snps.
analysis of the core genome showed that 79 segments (i.e., 304,782 bp, including 3,453 snps) were associated with recombination sites (technical appendix figure 1).
this finding suggests that recombinant segments contained 65% of snps with subsequent higher frequency of snps compared with nonrecombinant regions (average 11 vs. 0.48 snps/kb, respectively).
the phylogenetic tree created without recombination sites showed the same results as the phylogenetic tree obtained with recombination sites (technical appendix figure 2).
in addition to the core genome–based phylogeny with or without recombination sites, the c1-m27 clade was defined by a unique accessory genome of the m27pp1.
the c1-m27 clade–specific region the pangenome analysis of genomes from all the isolates identified an 11,894-bp region named m27pp1 that was specific to all the isolates from the c1-m27 clade.
further analysis using the blast database and sanger sequencing for gap filling showed that this region was identical to a prophage-like genomic island (genbank accession no.
cp006632) in e. coli pcn033 that belonged to phylogenetic group d and was isolated from a pig in china.
the blast database also identified 2 similar sequences (i.e., 99.9% homology): a cmy-2 containing plasmid peq011 (genbank accession no.
nc_023315) in an e. coli isolate from a horse in ireland (22) and a multidrug-resistant plasmid psd853_88 (genbank accession no.
jf267652) found in a bovine salmonella enterica isolate in the united states.
m27pp1 was inserted into chromosome creating a 7-bp direct repeat region (figure 2).
pcn033 had the same flanking structure as the m27pp1, whereas the 2 plasmids (peq011, psd853_89) contained only a 44-bp similar segment at 5′ side and other parts of these plasmids were not found in the c1-m27 clade isolates.
figure 2 genetic environments of the c1-m27 clade–specific region of escherichia coli.
all isolates other than the c1-m27 clade isolates had the type a structure in their chromosome (red arrows; gene locus tags shown in the bottom are annotated according to ec958).
the c1-m27 clade isolates except 2 isolates (kun5781 and ec 24) had the type b structure.
a 11,894-bp region (m27pp1; predicted genes shown in light blue arrows) is inserted into the type a structure creating the 7-bp direct repeat (ccgttct; yellow triangle).
the inserted sequence m27pp1 is identical to a prophage-like genomic island in e. coli pcn033 chromosome (genbank accession no.
cp006632), which had the similar flanking structure (structure c, 98.8% similarity).
m27pp1 included phage-like integrase and recombinase.
the identical m27pp1 sequence was found in all of the c1-m27 isolates with the use of additional sanger sequencing.
only the draft genome of ieh71520 had 98.7% coverage to the m27pp1 sequence because of contig discontinuity.
kun5781 and ec 24 had the type d structure, of which an additional 19,352-bp region (m27pp2) is inserted into the type b structure by creating the same 7-bp direct repeat (yellow triangle).
the m27pp2 includes a total of 15,555-bp region (genes shown in orange arrows), which was 88.9% similar to a prophage-like region in γ proteobacterium hdn1 chromosome (genbank accession no.
fp929140) and a following 1,221-bp region is 99.8% similar to issen4 (purple box).
code to gene locus tags: 1, 958rs23365; 2, 958rs23370; 3, hdn1f03950; 4, hdn1f03970; 5, hdn1f04000; 6, hdn1f04010; 7, hdn1f04020; 8, hdn1f04030; 9, hdn1f04040; 10, issen4; 11, 033rs22420; 12, 033rs22425; 13, 033rs22430; 14, 033rs22440; 15, 033rs22450; 16, 958rs23380.
two e. coli st131 c1-m27 isolates (i.e., kun5781 and ec 24) had an additional insertion region of 19,352 bp, named m27pp2, situated upstream of m27pp1.
m27pp2 was accommodated within the same 7-bp direct repeat region (figure 2).
m27pp2 included a 15,555-bp region that showed 88.9% homology to a prophage-like sequence in the chromosome of the γ proteobacterium hdn1 (genbank accession no.
fp929140) and 99.8% homology to the insertion element issen4.
genomic comparison of the st131 genomic islands and virulence genes the sequences of the study isolates were similar to the st131 genomic islands in ec958 and jj1886 (a ctx-m-15–producing c2/h30rx strain obtained in the united states from a patient with fatal urosepsis) (figure 3) (17).
the c1-m27 clade isolates lacked the prophage 1 region present in ec958 (figure 3).
this prophage 1 region, specific for st131, was present among the non–c1-m27 st131 isolates in this study, except for brg23 and ecsa01.
the presence of expec-associated virulence genes is shown in technical appendix figure 3. the senb enterotoxin gene was more common in c1/h30r (than in c2/h30rx).
no significant differences existed in the distribution of virulence genes between e. coli st131 c1-m27 and other isolates.
figure 3 genome similarities to the escherichia coli sequence type (st) 131 genomic islands and the c1-m27 clade–specific region.
rings drawn by brig show the presence of these regions.
colored segments indicate >90% similarity and gray segments indicate >70% similarity by blast comparison between the regions of interest and each genome.
extended-spectrum β-lactamase types are indicated in parentheses of type column.
the regions from flag2 to gi-luex were found in ec958, the prophage 8 region was found in jj1886, and the m27pp1 and m27pp2 were found as the c1-m27 clade–specific regions in this study.
prophage 6, capsule, gi-selc, and prophage 8 regions were present in some c2/h30rx isolates but were absent in c1/h30r isolates.
plasmid replicons, addiction systems, and antimicrobial drug resistance genes we compared the study isolates with pec958, the plasmid present in ec958 that carries blactx-m-15 (technical appendix figure 4).
the c1-m27 clade lacked the first part of the transfer region (tra) present in pec958.
some regions common to both c2/h30rx and c1/h30r clades were present in pec958.
the c1/h30r clade producing ctx-m-27 or ctx-m-14 (including c1-m27) contained mostly f1:a2:b20 replicons, whereas the c2/h30rx clade producing ctx-m-15 contained mainly f2:a1:b- replicons (technical appendix figure 5).
the c1-m27 clade was negative for tn2 containing blatem-1.
two c1-m27 isolates from thailand and the united states were also positive for blandm-1 (technical appendix figure 5).
discussion a previously unreported clade named c1-m27 within c1/h30r clade is responsible for the epidemic of esbl-producing expec in japan and has already been disseminated to 5 countries on 3 continents.
st131 containing blactx-m-27 responsible for human infections has been reported from various continents (2) and is especially common among esbl-producing expec in certain countries, such as israel, the czech republic, and switzerland (2,13,14).
ctx-m-27–producing st131 also is present among nonclinical and nonhuman e. coli isolates, including fecal specimens of healthy children attending day care centers in france; fecal specimens of healthy adults in china, portugal, and the netherlands; samples from sick dogs and cats in japan; samples from water birds from central europe and swiss rivers and lakes; and samples of well water from china (2,10,11,15,23–25).
the most common esbl among e. coli st131 in nonhuman samples is ctx-m-27 (2,23–25).
st131 with blactxm-15 is rare among animal and environmental e. coli isolates (26).
our analysis of ieh71520, an e. coli isolate from vacuum cleaner dust in the united states (15), showed that this st131 isolate belong to the c1-m27 clade.
the c1-m27 clade is likely to be present among animal and environmental st131, and such isolates might act as a hidden reservoir for the introduction of st131 containing blactx-m-27 into human medicine.
e. coli st131 c1-m27 had an additional, unique prophage-like region (m27pp1) within its chromosome, lacked the prophage 1 genomic island previously identified in st131 c2/h30rx, and were negative for the transposon tn2 containing blatem-1 (figure 3; technical appendix figure 5).
the direct flanking repeat sequences surrounding m27pp1 suggest that this region was introduced into e. coli st131 c1/h30r with blactx-m-27 by a recombination event that was then followed by the clonal expansion of the c1-m27 clade.
recent studies focusing on evolutionary history of st131 suggested that c1/h30r and c2/h30rx clades emerged ≈30 years ago, after their acquisition of gyra-1ab and parc-1aab alleles from c0/h30 (non-r) clade (27,28).
the phylogeny and smaller numbers of snps in the c1-m27 clade (figure 1) suggest that this clade was recently diverged from the c1/h30r.
in the time-scaled phylogeny presented by stoesser et al.
(27), a cluster that included 6 ctx-m-27–producing isolates from cambodia, thailand, and laos in 2007–2011 was present within the c1/h30r clade.
this cluster, supposed to be the c1-m27 clade, diverged in the early 2000s, supporting our hypothesis.
ctx-m-27–producing st131 that belongs to the h41 lineage previously had been described from japan (6) and china (15).
the characterization of the japanese st131 h41 isolates showed different genetic structures flanking the blactx-m-27 from those structures present in e. coli st131 h30r (6).
the flanking regions previously characterized in st131 h41 were identical to the flanking regions in st131 non–c1-m27 from this study.
it seems there are 2 types of structures flanking the blactx-m-27 among e. coli st131; 1 type is confined to clade c1-m27 (i.e., 208 bp of δisecp1 upstream and δis903d downstream), whereas another structure (i.e., 388 bp of δisecp1 upstream and full is903d downstream) is distributed among non–c1-m27 isolates, including st131 h41 (6).
therefore, st131 h41, through horizontal transfer of blactx-m-27, is unlikely to have played a substantial role in the emergence of the c1-m27 clade.
two st131 isolates with blactx-m-27 from australia and vietnam did not belong to the c1-m27 clade (figure 1).
these 2 isolates differ from the c1-m27 clade in that their core genomes had more snps (158 vs. 68), contained the prophage 1 st131-specific region, and lacked the m27pp1 and m27pp2 elements.
moreover, the genetic environment surrounding the blactx-m-27 differed from e. coli st131 c1-m27 (as described previously).
the isolate from vietnam lacked mph(a)-mrx-mphr, tetr-tet(a), sul2-stra-strb, and in54 resistance genes, compared with the c1-m27 clade (technical appendix figure 5).
these differences indicate that some st131 isolates might acquire blactx-m-27 independently from the c1-m27 clade.
our study has several limitations.
most isolates originated from japan.
however, we were able to include st131 c1-m27 isolates from 5 countries on 3 continents and c1/h30r isolates producing ctx-m-14 or ctx-m-15 from 6 countries on 4 continents.
another limitation was that we were able to obtain only 1environmental st131 isolate with blactx-m-27 (ieh71520).
future studies that include environmental isolates will provide additional insights into molecular epidemiology and evolutionary history of the c1-m27 clade.
we could not analyze plasmid contents of blactx-m-27 because blactx-m-27–containing contigs were too short.
the sequencing of plasmids that contain blactx-m-27 obtained from various st131 clades (including the c1-m27 clade) should also be undertaken.
in conclusion, we showed that the recent increase in esbl-producing e. coli from japan resulted from emergence of a st131 c1/h30r subclade with blactx-m-27.
this clade, named c1-m27, had unique genomic characteristics and was present in st131 from thailand, australia, canada, and the united states.
our findings suggest that the c1-m27 clade is contributing to the global success of st131.
e. coli st131 c1-m27 poses a major new public health threat because of its global distribution and association with the very dominant c/h30 lineage.
we urgently need rapid cost-effective detection methods for e. coli st131 c1-m27 and well-designed epidemiologic and molecular studies to understand the dynamics of transmission, risk factors, and reservoirs for st131 c1-m27.
these efforts will provide insight into the emergence and spread of this multidrug-resistant clade that will lead to information essential for preventing the spread of st131.
technical appendix supplementary methods, strain information, mapping, assembly statistics, genetic structures recombinant regions and other details of escherichia coli sequence type 131 isolates.
@highlight
increased extended-spectrum β-lactamase–producing e. coli in japan resulted mainly from a clade containing this gene.
