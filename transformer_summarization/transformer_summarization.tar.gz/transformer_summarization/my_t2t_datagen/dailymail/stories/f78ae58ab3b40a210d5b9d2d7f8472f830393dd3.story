introduction one of the main characteristics of biodiversity data is its cross-disciplinary character and the extremely broad range of data types, structures, and semantic concepts that it encompasses.
even if we focus on the data of a specific area (i.e.
greece), they remain widely distributed and unconnected.
for example occurrence records in csv format may be stored in the university of thessaloniki, dna sequencing fasta files can be stored in the university of patras and microct scanning images may be stored in the hcmr's databases.
for this purpose our idea was to: (a) extract information about the events that are explicitly or implicitly contained in the datasets, (b) model the different concepts and entities of the biodiversity domain and (c) take advantage of the semantic graph’s capabilities to navigate efficiently through the different contents and discover data of interest.
this approach provides the means of making high level, abstract, queries without having full knowledge about the domain, the schema or even the presence of the data, and easily discovering data resources that contain (or are) the results of such queries.
as regards the extraction of information about events, it is evident that an expedition dataset contains information about a number of sub-events such as occurrence or identification events (fig.
1).
so, apart from the metadata of the dataset that can be stored in a registry, information about the sub-events can be extracted, modeled and used to assist the discovery of data resources.
in the context of lifewatchgreece research infrastructure we designed and implemented a set of data services that aim to: i) support cataloguing and publishing all the relevant metadata information of the greek biodiversity domain, ii) integrate data from heterogeneous sources by supporting the definitions of appropriate models, iii) efficiently discover biodiversity data of interest and enable the answering of complex queries that could not be answered from the individual sources.
the aforementioned services allow the providers to express their metadata in a schema agnostic way; the provider is able to submit metadata according to their local format (e.g.
darwin core) and these are automatically transformed with respect to the underlying centralized schemata of the infrastructure for gaining the advantages that semantic models offer.
particular focus was given on the architecture and the contents of the infrastructure for being able to serve clients, even if some of its parts are temporarily inaccessible.
project description design description the activities have been split in three different phases, namely: the requirements/specification phase, the design phase and the implementation phase.
below we will describe each one of them in details along with the web application that has been developed and a real usage scenario example that demonstrates the data services capabilities.
requirements/specification phase the requirements/specification phase contained all the activities as regards the data analysis and collection of requirements.
specifically, the first step of the requirements/specification phase was the definition of the functional requirements of the infrastructure.
after the collection and the analysis of the functional requirements it was clear that there was a need for creating a number of e-services that will assist the data providers to submit their metadata and data to the lifewatchgreece research infrastructure by providing functionalities of: a) transformation of the metadata from the provider’s schema to the centralized semantic schema of the infrastructure, b) ingestion of the metadata and data to lifewatchgreece research infrastructure, c) publishing of the datasets by providing information on how to access the datasets and how to communicate with the datasets’ creator/curator, d) querying in order to gain information on how to access the datasets and how to communicate with the curator/creator, e) quality improvement of the datasets that the data providers will publish to the infrastructure.
the next step was to design the data workflow based on the synergy reference model for data provisioning and aggregation.
to evaluate the representation needs of the biodiversity domain it was essential to collect and analyze a significant number of datasets coming from the community.
more than 50 datasets coming from different sections of the broader biodiversity domain were collected.
following this activity, the collected datasets were analyzed, categorized and the mandatory metadata were identified and extracted.
the step that followed the collection and analysis of the datasets was the collection of the competency queries.
these queries are derived from the domain experts, express the final expectation of the user from the system and are used for defining the main functional requirements as well as the final evaluation of the services.
they are essential for the design and the evaluation of the ontology and the definition of the main scientific questions that should be answered.
more than 70 competency queries were collected from the domain experts.
an indicative example of a competency query is: find all taxonomic names and their associated authorities that have ever been placed in genus x (even if now they are in another genus), including information on the locality, habitat and depth / elevation of the type specimen for each of those species.
moreover, the analysis of the greek biodiversity community’s datasets and metadata led to the identification of fourteen (14) main metadata categories than can cover the full set of metadata that should be kept in the metadata catalogue.
these categories are: occurrences identifications taxonomy naming microct scannings environmental specimens specimen collections data collections genetics morphometrics morphological characteristics statistical occurrence statistics a metadata catalogue was created, documenting for each metadata category a set of mandatory metadata.
in order to avoid duplications and assist the data integration process we decided to model these metadata with respect to a set of semantic models.
specifically, we designed a new model for the purposes of the lifewatch greece project that was inspired from cidoc crm [doerr 2003​], and its extensions crm dig [theodoridou et al.
2010, crm sci, cmr geo and marinetlo [tzitzikas et al.
2013][tzitzikas et al.
2016].
the catalogue contains more than 200 metadata fields descriptions, 300 examples, and more than 100 mappings to the semantic models.
a few mapping examples between dwc and our models is shown in table 1. the next step was the definition of the mappings between the source’s schemata and the centralized schema of the infrastructure.
table 1 shows an example of a high level mapping between darwincore (dwc) and the central semantic model of the infrastructure.
it is evident from the example that our modelling is more expressive and allows preserving more information about the events.
a few modeling examples of some meaningful biodiversity concepts (i.e.
species taxonomy and occurrence) are shown in fig.
2 and fig.
3. furthermore, in rich semantic networks, where the information is constructed using a schema of high complexity, useful deductions are created.
in such semantic networks that provide a great level of detail a keyword based querying system or a system based on explicitly defined relationships would be insufficient.
using a specific keyword or just a flat relationship for querying would result in low recall rates, as the system would ignore all the essential information that is hidden behind deductions of relationships linking and reasoning.
the proposal was not to simplify the schema for constructing the semantic network, but the schema for querying the complex semantic network.
to realize this, we modeled the biodiversity domain in 5 fundamental categories and we defined certain generic fundamental relationships: 1. thing (specimens, individuals, publications etc) 2. actor (scientists, authors, institutions ect) 3. place (ecosystemenvironment, country, waterarea etc) 4. event (identification, occurrence, scanning etc) 5. dimension (length, weight, salinity etc) design phase the first step of the design phase was the design of the architecture, taking into account that the main goals of the data services of the infrastructure are i) the discovery of registered resources within an information community and ii) the return of information that allows a user to locate and access the resource and its curator/creator.
this is a tricky task since several issues may occur; for instance resources might not be available online (technical failure/access rights/data policies), or they might be widely distributed/stored or the information of how to access the dataset/collection might be incomplete or missing.
in order to achieve this goal, to fulfill the functional requirements and to overcome these issues a new prototypical architecture comprising of 3 main components was designed and implemented.
the 3 main components are the directory, the metadata repository and the content storage and they can operate independently of each other, and provide different levels of querying capabilities.
they are loosely-coupled complements and are linked exclusively by the uri of the results achieving at the same time conceptual and semantic linking and functionality independence (fig.
4).
also, by adopting this architecture we achieve: (a) a separation between domain specific and domain-independent information, (b) the ability to answer queries even if one of the components fail and (c) the ability to re-create the components in case of failure.
the role of the directory is to support the discovery of registered resources within an information community and return information that allows a user to locate and access the resource and its curator/creator.
specifically it provides the means to create, edit, update, search information about providers, collections (datasets) and the means to communicate and access with them.
the directory holds information that are independent of the domain.
some indicative queries that can be answered by the directory are the following: which institution hosts the dataset with title “thunnus occurences” and how can i have access to it?
return all the datasets that have been created from hcmr.
the data are physically stored in a triple store.
an example illustrating part of the schema of the directory is shown in fig.
5. the metadata repository is domain dependent and assists dataset discovery by modelling in a rich semantically way part of them.
it is also responsible for storing, updating and querying the metadata that the providers would like to be public.
it aids information integration and inference.
all the metadata that are provided by the data providers are stored into the metadata repository, after they are mapped to the centralized schema of the infrastructure.
furthermore, the semantic models, the inferred triples, the materialization rules products and the instance matching products are stored in the metadata repository.
the queries that are executed by the users exploit the metadata repository and return the datasets that contain the related information.
some indicative queries that can be answered by the metadata repository are: find all datasets about scans depicting marine species.
find all datasets about species that have been originally described from greece the content storage stores any raw data / datasets that the data providers upload to the system (i.e.
datasets, images, dna sequence files, analysis products, etc.).
the raw data are linked with the metadata into the metadata repository and the directory entries by using the dataset’s uri.
an important step that followed the design of the main components was the definition of the policies regarding some important processes such as updating, recovering from failures etc.
most of these policies were designed from scratch for the needs of lifewatch greece and have been applied for the first time in the project.
specifically these policies include the publishing policy, as shown in fig.
6, the updating policy, the versioning policy, the recovery policy and the uri policies.
regarding the uri creation policy of the infrastructure it was decided that the uris should be human readable, and to provide information on the type of the entity that they identify.
the format of the uris that are automatically created is: www.lifewatchgreece.eu/entity/ + entitytype/ + entityid_trimed_inlowercase web location (uris) homepage: http://metacatalogue.portal.lifewatchgreece.eu/ technical specification platform: http://metacatalogue.portal.lifewatchgreece.eu/ programming language: java interface language: html5, jsp, javascript service endpoint: http://metadator.her.hcmr.gr/dataservices-middleware/ repository type: git browse uri: https://github.com/isl/lifewatch_greece usage rights use license creative commons cczero ip rights notes to access the data-services web application the users must register to the lifewatch greece portal.
implementation implements specification implementation phase the first step of the implementation phase was the implementation of the data services api and the soap web services (fig.
7).
these products are the basis of the front-end implementation of the data services infrastructure and are being used for the development of the data services web application (fig.
8) of the lifewatch greece portal and by a number of other e-services and v-labs of the infrastructure.
they are publicly available to users and developers and can be reused for the creation of new applications and infrastructures, and also be exploited by the other partners of the lifewatch europe project [basset and los 2012].
the main functionalities that are provided by the data services api offer the following functions: triple store operations: for the underlying storage of the directory and the metadata repository, we have used a triple store (in our case a virtuoso triple store).
to this end, we have implemented a set of operations to: a) connect to a semantic triple store b) import data to the triple store c) update the triple store contents d) delete data from the triple store e) query the triple store biodiversity data transformation: the data services api contains a number of functions that transform biodiversity data from csv format to rdf.
the code takes as input specific csv templates that are filled with biodiversity data, and transforms it to rdf format based on event centric semantic model of the infrastructure.
the produced triples can be imported to a triple store.
biodiversity data querying: the data services api, beside the generic querying functionalities, includes a number of biodiversity domain specific querying functions that return biodiversity data which is stored in triple stores and belongs to one of the main metadata categories.
furthermore, offset and limit parameters can be used to limit the number of returned results enabling, for example, pagination implementations.
uri creation: the api offers three different functions for uri creation.
these functions can create uris that are a concatenation of the prefix, the type of the entity and the id of the entity, or a concatenation of the prefix and the id of the entity, or a hash code.
browsing semantic graphs: two functions for browsing the semantic graphs have been created.
the one returns all the outgoing nodes, and their types, of an entity and the other all the incoming nodes, and their types, to an entity.
similar to the querying functions the offset and limit option is provided to limit the number of the returned results.
materialization rules execution: in many cases the contents of a semantic graph need to be materialized based on a number of rules.
for this reason the data services api offers a materialization function that takes as input the sparql rules from an external folder and executes them importing the materialized triples to the triple store.
textual description production: the data services api contains a function that takes as input the scientific name of a species and by using standard templates, produces a textual (wikipage like) description, integrating information coming from different datasets and providers.
the web services that were developed to expose the infrastructure functionalities have been packaged into a middleware (the dataservices-middleware) that contains three main services and a number of sub-services.
the services use soap as a protocol for exchanging messages with clients.
the services are: 1. directory web service searching [directoryservice_search] adding [directoryservice_insert] updating [directoryservice_update] deleting [directoryservice_delete] 2. metadata repository web service searching [metadatarepository_search] adding [metadatarepository _insert] updating [metadatarepository _update] deleting [metadatarepository _delete] browsing [metadatarepository _select] producing text [metadatarepository _text] ​3.
fundamental categories web service besides the main soap services a rest service was developed to allow the annotations of a species uris using the morphological traits contained in the polytraits database (faulwetter et al.
2014).
web application to expose to the users of lifewatch greece the functionalities of the data services, a web application (fig.
8) has been developed using the data services api and has been integrated to the portal of the infrastructure.
the providers can publish their data and their metadata through the data services web application.
moreover, the web application provides a number of search capabilities to the users.
these are the basic search, which is actually a search on the directory, the advanced search which gives the capability to the users to search on the metadata repository by selecting a metadata category, the fundamental search, which exposes the fundamental relationships/categories querying mechanisms, the browsing which takes as input a uri and enables a semantic graph navigation and the sparql querying execution on the sparql endpoint.
almost every result that is returned by the search functions is a link.
these links are created by using the unique identifiers that we produced and by using a number of browsing functions that we implemented.
by clicking the link someone can find more information about the entity and navigate the semantic graph.
by using standard templates it was made possible to return information about a specific concept in natural language (fig.
9).
the user can insert a scientific name and take back as a story or as a wikipedia entry the aggregated information.
all this text is produced automatically.
for example if a user enters the name "alburnus thessalicus" the result that is shown in fig.
9, will be returned.
every link is an entity that is extracted by the underlying triple stores and is clickable allowing browsing on the semantic graph.
furthermore, users are able to create, retrieve and delete polytrait and free-text annotations over the available species uris through special widgets that can be activated through a button in the results page of the advanced search > occurrence search type facility.
when the annotation mode has been activated all the available species uris can be annotated and their respective annotations can be retrieved/deleted (fig.
10).
to assist the administrator with tasks such as the managing of the infrastructure’s main components, configuring the system, recovering from failures, materializing the triple stores, and furthermore to make the infrastructure as generic as possibly, decoupled from the underlying components, a number of pages visible exclusively to the administrators have been included in the web application.
the data services web application that has been integrated in the lifewatch greece portal have been populated with datasets and metadata coming from the greek biodiversity community.
this was the main scalability and functionality test of the data services.
specifically the infrastructure, that is continuously being populated, contains information about almost: 100 datasets 700 occurrence events 100 identification events 100 micro ct scannings 100 micro ct reconstructions 50 micro ct posprocessings 100 specimens 30 environmental measurement events 200 common names 100 scientific names 200 taxonomic classifications 170 synonyms and a small number of genetic sampling and sequencing events, occurrence statistics, statistical evaluations, morphometric measurements, morphological characteristic assignments and specimen collections.
information integration example the following example demonstrates the innovative work done in lifewatch greece by exploiting the data services capabilities to discover data resources.
the scenario includes a user that searches for datasets that contain information about occurrences of species in the mediterranean sea.
the first action of the user is the selection of occurrence metadata category on the advanced search form and the filling of mediterranean sea in the location field (fig.
11).
a list of all the occurrence events that took place in mediterranean sea are returned (fig.
12).
we suppose that the user is interested in the "polycirrus aurantiacus" occurrence event so by clicking "more info", more information about the event is returned to the user.
by clicking on the view dataset the user will be redirected to the directory entry, find more information about the dataset that this event is described to and download it or access the curators/creators (fig.
13).
we further suppose that the user is also interested in the individual that was found during the occurrence event.
so by clicking on its identifier (polycirrus_aurantiacus_1981_15) the user is being directed to the entities browsing page (fig.
14).
more data related to the individual is returned, such as other events that it participated.
but the user is interested in a transformation event that the individual had participated.
by clicking it the user is directed to a page about this event (fig.
15).
the user notices that the individual was transformed into a specimen by using a preservation in ethanol method and the new name is mct-00038.
by clicking on the specimen’s id the user finds out that it was scanned by a skyscann microct tomograph by sarah faulwetter in 2012 and a dataset was produced.
the user can retrieve information about this dataset and download it (fig.
16).
summarizing, the user initially desired to find datasets that contain information about occurrence events of species in the mediterranean sea.
he was able to easily discover the requested information but also by browsing the semantic network the user was able to find microct scannings about the species of interest that come from a different institution, dataset and time, that the user was probably not aware of.
this was just a simple example of information integration, navigation to the semantic graph, unique identifier assignment and efficient discovery of dataset that we achieve in lifewatch greece data services.
technologies the data services api has been developed in java.
the web services follow the soap and rest protocols while the web application is mainly developed using java servlets, jsp, jquery and bootstrap, deployed on a glassfish server.
rdf [erling and mikhailov 2009] has been chosen for the data representation and the semantic models have been implemented in rdfs and owl.
sparql is the main querying language, but also mysql has been used for the needs of the web application.
openlink virtuoso which is a general purpose rdf triple store with extensive sparql and rdf support [8], has been used for the storage needs of the metadata repository and the directory.
irods [rajasekar et al.
2010], which is a federated file system, has been chosen for the content storage requirements, and idrop is the administrative user interface that has been used on top of it.
the fundamental query user interface was a results of the tight cooperation of forth and metaphacts and has been implemented mainly in java and reactjs.
the implementation of the morphological annotation rest api uses the anno4j library for accessing the annotations.
the implemented annotation services exploit the blazegraph triple-store.
finally, biovel’s data refinement workflow has been used for the data-refinement of the datasets.
@highlight
abstract background biodiversity data is characterized by its cross-disciplinary character, the extremely broad range of data types and structures, and the variety of semantic concepts that it encompasses.
furthermore there is a plethora of different data sources providing resources for the same piece of information in a heterogeneous way.
even if we restrict our attention to greek biodiversity domain, it is easy to see that biodiversity data remains unconnected and widely distributed among different sources.
new information to cope with these issues, in the context of the lifewatch greece project, i) we supported cataloguing and publishing of all the relevant metadata information of the greek biodiversity domain, ii) we integrated data from heterogeneous sources by supporting the definitions of appropriate models, iii) we provided means for efficiently discovering biodiversity data of interest and iv) we enabled the answering of complex queries that could not be answered from the individual sources.
this work has been exploited, evaluated and scientificaly confirmed by the biodiversity community through the services provided by the lifewatch greece portal.
