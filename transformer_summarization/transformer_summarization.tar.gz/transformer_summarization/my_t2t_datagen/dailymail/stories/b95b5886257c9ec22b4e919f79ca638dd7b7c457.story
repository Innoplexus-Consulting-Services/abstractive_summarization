introduction what was known?
synovial sarcoma is a common soft tissue sarcoma.
synovial sarcoma is a rare malignancy but one of the common soft tissue sarcomas with two histologic subtypes, monophasic and biphasic which usually occurs in adolescent with predilection for lower extremity.
[1] its histogenesis is unclear, and in contrast to its name, it does not arise from synovial cells.
[2] the upper extremity is not frequently involved by the tumor.
although rare, unusual places for tumor growth including mediastinum, heart, lung, or small intestinal mesentery have been reported,[3456] but superficial synovial sarcoma is extremely rare with only one report within literature.
[7] here, we report another case of superficial synovial sarcoma arising in the superficial layer of the skin of lower extremity around the knee without involvement of knee joint synovium.
case report a 30-year-old woman referred to our center with an asymptomatic erythematous mass-like lesion on the medial aspect of her left thigh 2 years ago.
the initial presentation was an erythematous slow-growing papule during the past 2 years.
the patient mentioned enlargement of the lesion during her pregnancy period.
the physical examination revealed a solid ulcerated subcutaneous nodule on the medial aspect of the left knee.
the mass was not tender and had some prominent vessels on its surface.
the patient underwent a biopsy, and an elliptical piece of skin and subcutaneous tissue measuring 3 cm × 2.5 cm was sent for histological examination with differential diagnosis of pyogenic granuloma and vascular neoplasms.
histopathological and immunohistochemical findings on gross examination, there was a protruding mass on the skin surface measuring 2.5 cm × 1.5 cm × 1.5 cm [figure 1], with soft to elastic consistency.
on the surface of the mass, telangiectatic vessels, ecchymotic areas, and focal ulceration were noted.
the cut surface of the mass was tan, soft, and homogenous.
microscopic examination showed a rather well-circumscribed dermal neoplasm with extension to subcutaneous tissue surrounded by a thin pseudocapsule [figures 2 and 3].
the neoplasm is composed of compact lobules separated by thin fibrous septae.
the neoplastic cells had high nuclear/cytoplasmic ratio, scant cytoplasm, small-to-medium sized round nuclei, inconspicuous nucleoli, and high mitotic activity.
the epidermis was unaffected except focal ulceration.
immunohistochemical (ihc) study showed negative staining for cd45, hmb45, s-100, cd34, smooth muscle actin, desmin, synaptophysin, chromogranin, cytokeratin (ck) 7, ck20, cd31, epithelial membrane antigen (ema), and neuron-specific enolase.
a few scattered cells showed weak cytoplasmic staining for ck ae1/ae3 [figure 4].
tumor cells were strongly positive for vimentin, cd99, and bcl-2.
mib-1 proliferation index was about 30%.
the overall histopathologic and ihc study results were consistent with the poorly differentiated synovial sarcoma.
the radiologic findings by magnetic resonance imaging showed a cutaneous mass without any connection to the underlying joint.
because of involvement of the tumor margins, the patient underwent the second surgery 2 months later following an orthopedic consult.
the specimen was sent for frozen section diagnosis by an expert dermatopathologist to obtain free surgical margins.
deep margin and deep soft tissues were free of tumor.
figure 1 photograph of the mass on the patient's leg around her knee joint figure 2 low magnitude image of the tumor showing rather well-defined proliferation of neoplastic cell.
the epidermis is unaffected (h and e, ×10) figure 3 higher magnitude of figure 2 showing the sheets of epithelioid neoplastic cells with pleomorphic nuclei and indistinct nucleoli (h and e, ×40) figure 4 immunohistochemical staining shows focal positivity for cytokeratin (×40) discussion synovial sarcomas are not common malignant tumors historically, but they have specific value due to their high metastatic risk.
it stands in the fourth place among soft tissue tumors.
this tumor has a unique anatomic distribution as it has a tendency for articular regions (more prevalent in the lower extremities compared with the upper extremities).
[28] it can be seen in other locations such as abdominal wall, lung, heart, and esophagus.
[910] the most commonly affected individuals are adolescents and young adults, and the most commonly seen clinical presentation is deep-seated swelling or less commonly painful mass.
to the best of our knowledge, it is the second report of superficial synovial sarcoma, the first report is a classic biphasic type, but our case is a poorly differentiated variant.
[7] our case was composed of malignant epithelioid cells which were positive for ck ae1/ae3, vimentin, and bcl-2 and negative for various mesenchymal markers leading to the diagnosis of poorly differentiated synovial sarcoma.
the chromosomal translocation t(x; 18) (p11, q11) has been described in most cases.
the tumor typically presents a biphasic pattern, including an epithelioid cell component forming glandular spaces and a uniform, small, spindle cell component resembling fibrosarcoma.
monophasic synovial sarcoma is composed usually only of spindle cells such as monophasic fibrous variant, monophasic epithelial variant, and poorly differentiated variant.
the poorly differentiated variant usually poses diagnostic difficulty and has an aggressive behavior.
it may have three histologic patterns:[8] a large cell or epithelioid pattern,[2] a small cell pattern, and[9] a high-grade spindle cell pattern.
these tumors often have a rich vascularity composed of dilated thin-walled vessels which may resemble malignant hemangiopericytoma.
most tumors express ema and low and high molecular weight cks, including cks 7 and 19. definite diagnosis is based on morphologic and ancillary studies including ihc.
chromosomal study can be also helpful.
the main part of the treatment is surgery and removing the tumor completely with free margins.
chemotherapy also might be indicated in metastatic disease.
for deep-seated tumors, good prognostic factors include: tumor size <5 cm, biphasic histologic pattern, and younger patients.
there are differential diagnoses for superficial synovial sarcoma including various soft tissue sarcomas or malignant epithelioid cells depending on the morphologic subtype of the tumor.
we excluded all the differential diagnoses using various ihc markers.
positivity for ck ae1/ae3 and negativity for neural, vascular, muscular, and lymphoid markers will lead to the correct diagnosis.
conclusion we report an extremely rare case of a 30-year-old woman with poorly differentiated synovial sarcoma, presented with primary superficial cutaneous lesion.
to the best of our knowledge, this is the second report of primary superficial synovial sarcoma.
therefore, synovial sarcoma should be considered in the differential diagnosis of skin tumors.
because of its high metastatic risk and better prognosis in early diagnosed lesions, awareness of the entity and considering the tumor in differential diagnosis are of a great value.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
what is new?
synovial sarcoma can occur in superficial areas, and our report is the second report of this kind.
hence, synovial sarcoma should be considered in the differential diagnosis of superficial masses.
@highlight
synovial sarcoma is a type of malignancy which usually occurs near the joints of the arm, neck, or leg.
it is a sarcoma of soft tissue and accounts for 5–10% of all adult soft tissue sarcomas in the world.
we present a case with primary superficial cutaneous synovial sarcoma without involvement of the underlying knee joint.
it is a very rare condition, and to the best of our knowledge, it is the second report of this topic.
although it is rare among soft tissue tumors, the dermatologists should have precise attention to this skin tumor, as early diagnosis is associated with lower metastatic rate and therefore better prognosis.
