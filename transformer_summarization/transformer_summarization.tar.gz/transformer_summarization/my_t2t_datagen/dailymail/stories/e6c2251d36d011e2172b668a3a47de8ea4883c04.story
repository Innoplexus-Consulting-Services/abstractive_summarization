introduction endometriosis is defined as an estrogen-dependent, benign inflammatory disease characterized by the presence of ectopic endometrial implants.1 endometriosis affects 10%–15% of reproductive-aged women.23 the most common sites of endometriosis, in decreasing order, are the ovaries, anterior/posterior cul-de-sac, broad and uterosacral ligaments, uterus, fallopian tubes, sigmoid colon, and appendix.4 abdominal wall endometrioma (awe) being a rare entity is a benign tumor defined as ectopic functional, endometrial tissue located in the abdominal wall.
subjects and methods a retrospective study of 23 female patients treated with awe in four departments of three centers in vladimir city, russia, from january 2010 to december 2014 was performed.
the main inclusion criterion was histologically confirmed definitive diagnosis of awe after its excision.
data collected include age, time from previous operation, type of previous operation, size of excised endometrioma, clinical presentation, recurrence, and postoperative course.
data were collected and analyzed using statistica 6.0 (statsoft inc., tulsa, ok, usa, 2001).
mean, standard deviation (mean ± standard deviation), and percentage became the descriptive statistics of the presented data.
results twenty-three female patients at the age of 21–42 years with awe were treated in four departments (three departments of surgery and a department of gynecology) of three clinics.
the mean age of the patients appeared to be 32.1 ± 5.16 years.
all patients were previously operated: 18 patients (78.2%) had previously undergone cesarean section and 5 patients (21.7%) – gynecologic procedures.
the approach in all patients was pfannenstiel incision.
the mean time from the previous operation to the onset of awe appeared to be 2.6 ± 1.3 years (from 1 to 6 years).
positive correlation between the age and the time from previous surgery to the onset of awe was found [figure 1].
figure 1 the interval from index surgery to the presentation of symptoms related to age in twenty patients (87%), awe was symptomatic, and in three patients (13%), awe was asymptomatic.
esquivel triad including tumor, periodic pain associated with menses, and cesarean section was considered to be the main clinical symptom complex in our patients.5 esquivel triad presented in 17 patients (74%).
three of the remaining six patients were asymptomatic and three had undergone a gynecologic procedure previously.
we modified esquivel triad adding gynecological procedures to cesarean section.
modified esquivel triad existed in 20 patients (87%).
all 23 patients were operated, and awe excision was performed.
in twenty patients, the anesthesia was local and the extent of surgery was limited to tumor excision; in three patients, the anesthesia was spinal and the extent of surgery emerged to be abdominal wall autoplasty in one case and alloplasty using polypropylene hernia mesh in two cases after tumor excision.
all excised tumors were sent to histology, and the diagnosis of awe was confirmed in all patients.
the size of endometrioma differed from 1.5 to 6 cm.
in 17 patients, the size of awe was small, that is, 0–3 cm [figure 2]; in 5 patients, medium – 3.1–5 cm [figure 3]; in one patient, large – 6 cm.
positive correlation between the age, the time from previous surgery to the onset of awe, and the size of awe exists as shown in figure 4. there were no major complications in the postoperative period.
five patients (21.7%) had postoperative pain at the site of surgery for more than 7 days.
they experienced the relief of pain with hormonal therapy; however, the pain was waxing with withdrawal of medication.
postoperatively, ultrasonography (usg) was performed to all patients.
in seven patients (30.4%), seroma was identified.
and, in three of these seven patients, seroma was associated with postoperative pain.
figure 2 (a) the specimen of small abdominal wall endometrioma.
(b) histology of endometrioma showing endometrial glands and stroma figure 3 (a) the specimen of medium abdominal wall endometrioma.
(b) histology of abdominal wall endometrioma showing endometrial glands and stroma figure 4 the correlation between the interval from index surgery to the onset of abdominal wall endometrioma, the age, and the size of endometrioma recurrence recurrence occurred in four cases (17.4%).
all patients had symptomatic awe.
the demographic and clinical data of the patients with recurrence are shown in table 1. all patients with recurrent awe had postoperative pain longer than seven days and three of them had seromas on usg.
awe recurred within the first postoperative 3 months in these patients.
hence, postoperative pain and seroma could be the result of nonadequate extent of awe excision.
table 1 demographic and clinical data of the patients with recurrence (n=4) discussion endometriosis is the presence of functioning endometrial tissue outside the uterine cavity, whereas endometrioma is its well-circumscribed mass.6 the incidence of awe varies from 0.03% to 0.8%.78 several theories of endometrioma formation were proposed which include hematogenous, lymphatic, and iatrogenic spread of endometrial cells, metaplastic change of pluripotent cells at any site to endometrial cells, retrograde spread of endometrial cells to the pelvis during menstruation, and immune system dysfunction.910 scar endometrioses are believed to be the result of direct inoculation of the abdominal fascia or subcutaneous tissue with endometrial cells during surgical intervention and subsequently stimulated by estrogen to produce endometrioses.
this theory is convincingly demonstrated by experiments, in which normal menstrual effluent transplanted to the abdominal wall resulted in subcutaneous endometriosis.61112 the first risk factor is a previous cesarean section which is strongly supported by the theory of iatrogenic spread.13 furthermore, other risk factors include an early hysterotomy in pregnancy, increased menstrual flow, and alcohol consumption.
high parity has been shown to be a protecting factor against awe.1415 the clinical presentation of awe is varicolored.
the most common symptoms include mass sensation, pain, bleeding, dysmenorrhea, and dyspareunia.1617 some patients can be asymptomatic that is painless palpable tumor.
in our series, 3 out of 23 patients (13%) were asymptomatic.
palpable mass presents in 96% of patients.18 the visual appearance also varies depending on the depth of awe: from nonvisible (only palpable) mass to black nodular swelling.19 pain presents in the vast majority of patients with awe; however, the characteristic of pain can be different.
bektas et al.
have shown the pain to be cyclic in 40% and noncyclic in 45% of patients.20 however, zhao et al.
have reported 87.5% among the reviewed 64 patients to have cyclic pain.21 in our series, 20 out of 23 patients (87%) presented with cyclic pain.
esquivel-estrada et al.
have described the clinical symptom complex, that is, esquivel triad, which includes palpable tumor, cyclic pain, and the history of cesarean section.5 in our patient series, esquivel triad presented in 17 patients (74%).
however, when we modified esquivel triad by adding gynecological procedures to cesarean section, the triad became more sensitive.
the modified esquivel triad presented in twenty patients (87%).
the mean age of the patients at the time of symptom presentation has been shown to be 31.4 years, and the interval from index surgery to the presentation of awe has been shown to be 3.6 years.18 in our patient series, they appeared to be 32.1 and 2.6 years, respectively.
the diagnosis of awe is mostly clinical when the patients are presented with esquivel triad.
however, cases with asymptomatic palpable tumor or tumor with noncyclic pain can bear a suspicion to various conditions.
therefore, the preoperative diagnosis in these patients can be different: from incisional hernia22 to metastatic cancer.23 this is also the reason why these patients are frequently presented to the attention of general surgeons.
in cases with nonclassic presentation of awe, radiologic evaluation is beneficial.
although the sensitivity of radiologic modalities is high, they are not able to distinguish among several types of masses of abdominal wall.
usg shows awe as a solid, hypoechoic lesion containing internal vascularity on power doppler examination.
in some cases, these lesions can contain cystic areas.24 hensen et al.
have shown the sensitivity of usg to be 92%.8 knowledge of the specific sonographic features of awe would help differentiate awe from other abdominal wall masses, such as hernias, hematomas, lymphomas, lipomas, and subcutaneous cysts.25 computerized tomography (ct) findings may help diagnose, exclude, or suggest the presence of a mass and define its extent and nature.
awe may be hyperattenuating compared with muscle, mild to moderate enhancement is seen with contrast.26 magnetic resonance imaging provides better contrast resolution than ct and usg and is superior to ct for depicting the delineation between muscles and abdominal subcutaneous tissues and infiltration of abdominal and pelvic wall structures.
it depicts small lesions and may be used to identify hemorrhage associated with endometriotic lesions.2627 fine-needle aspiration cytology has been shown to be a fast, accurate, and inexpensive method to make diagnosis before surgery.28 the most specific findings are endometrial-like epithelial cells, stromal cells, and hemosiderin-laden macrophages.29 because needle tract endometriosis has been reported, it is advisable to include the site of aspiration in the surgical resection field.1029 several treatment options have been reported including pharmacological and surgical treatment.
medical treatment with the use of progestogens, oral contraceptive pills, and danazol is not effective and gives only partial relief in symptoms and does not ablate the lesion.6 moreover, due to side effects such as amenorrhea, weight gain, hirsutism, and acne, compliance is unlikely.6 rivlin et al.
used leuprolide acetate, a gonadotropin agonist, in the treatment of awe.30 although it improved the symptoms, it has been shown not to influence the tumor size.30 bozkurt et al.
reported a case of successful treatment of intramuscular awe using ultrasound-guided intralesional ethanol injection, followed by medical treatment using oral contraceptives for 3 months.31 the definitive treatment of awe and the gold standard is wide surgical excision.1021 moazeni-bistgani recommends either irrigation of the wound with high-jet saline solution before wound closure or repair of peritoneum at the time of cesarean section as a preventive measure.32 the rate of recurrence of awe after surgical excision is various.
ecker et al.
have reported recurrence in 7.7%,17 and bektas et al.
in 9.1% of cases.20 horton et al.
have shown the rate of recurrence to be 4.3% in the review of 455 patients.18 in our patient series, the rate of recurrence appeared to be high (17.4%).
in all patients, the recurrence was associated with postoperative pain more than 7 days and seroma on usg.
we believe that these symptoms are the manifestation of the residual endometrial tissue, and in these cases, the recurrence was associated with nonadequate extent of surgery.
the most significant complication of awe is malignant transformation which is likely to occur in 0.3%–1% of cases.3334 the principal risk factors of malignant transformation of endometriosis include advanced age of the patient, if they are postmenopausal, and if the tumor diameter of an endometriotic lesion is >9 cm.3536 conclusion esquivel triad is a clinical symptom complex specific for awe; however, it requires modification, that is, addition of gynecological procedures to cesarean section.
postoperative pain longer than 7 days and seroma are the results of nonradical excision of awe and seem to be associated with the recurrence of awe.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
background: endometriosis is defined as an estrogen-dependent, benign inflammatory disease characterized by the presence of ectopic endometrial implants.
abdominal wall endometrioma (awe) being a rare entity is a benign tumor defined as ectopic functional, endometrial tissue located in the abdominal wall.
subjects and methods: a retrospective study of 23 female patients treated with awe in four departments of three centers in vladimir city, russia, from january 2010 to december 2014 was performed.
results: in twenty patients (87%), awe was symptomatic, and in three patients (13%), awe was asymptomatic.
esquivel triad presented in 17 patients (74%), and modified esquivel triad existed in 20 patients (87%).
all 23 patients were operated, and awe excision was performed.
recurrence occurred in 4 cases (17.4%) and was associated with postoperative pain and seroma.
conclusion: postoperative pain for more than 7 days and seroma (on ultrasonography) seem to be associated with recurrence of awe.
