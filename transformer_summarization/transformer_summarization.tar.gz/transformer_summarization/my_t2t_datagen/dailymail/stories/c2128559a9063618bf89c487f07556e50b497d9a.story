introduction the goal of restorative therapy is not only to restore the tooth to proper form and function but also aims to preserve the pulp vitality.
vital pulp has several important functions which include induction, formation, nutrition, defense, and sensation.
vital pulp possesses the capacity to produce secondary, tertiary, and reparative dentin to the external stimuli.
[12] pulp exposure can occur due to caries process, trauma or accidentally in an operative procedure.
in response to these stimuli, at the exposure site, a new odontoblast-like cells are recruited and differentiated to synthesize reparative dentin.
[134] the objectives of direct pulp capping (dpc) are to seal the pulp against bacterial penetration, to encourage the pulp to wall of the exposure by forming a dentine bridge and to maintain healthy pulp tissue.
[14] a wide variety of materials has been advised for the dpc.
[5] many studies have indicated that calcium hydroxide (ca[oh]2) and mineral trioxide aggregate (mta) are the gold standard materials for dpc.
[67] however, ca(oh)2 have certain limitations such as the presence of tunnels in the dentine barrier, pulp chamber obliteration, solubility in oral fluids, degradation after acid etching, and lack of adhesion.
[8] the performance of mta as a dpc agent was evaluated by several authors and found to be significantly superior than ca(oh)2.
[79] although several case reports and clinical studies have evaluated the effect of mta for pulp capping, very few histologic studies have been conducted.
[891011] on the other hand, emdogain (emd) enamel matrix derivative induces mesenchymal cell differentiation imitating odontogenesis.
[12] therefore, emd serves as a biologically active pulp capping agent specifically inducing pulpal repair and hard tissue formation.
[13] hence, the purpose of this study was to evaluate the histological response of pulp tissue to mta, emd, and combination of mta/emd.
materials and methods this study design was approved by the institutional ethical committee.
sixty healthy human premolar teeth scheduled to be extracted for orthodontic treatment were selected from twenty individuals ranging from 15 to 25 years old.
the subjects and parents were explained about the clinical procedures and risks associated with the study and written consents were obtained.
inclusion criteria were subjects having at least three premolar teeth with closed apices that needed extraction for orthodontic reasons.
the teeth with pulp involvement, developmental defects, and no response to vitality tests were excluded from the study.
operative procedure all the clinical procedures were performed by the same author.
the teeth were anesthetized with lignox 2% a (lignocaine with adrenaline 1:80,000, indoco remedies ltd., mumbai, india) and occlusal cavities were prepared by sterile diamond burs (no.
330 diatech) at high speed under rubber dam.
a standard pulpal exposure of 1–1.5 mm was made, and hemostasis was obtained with cotton moistened with sterile saline.
the exposed area was capped with mta (proroot mta, dentsply caulk, milford, de, usa), emd (straumann ab, sweden), and combination of mta/emd.
after placing mta, a wet cotton pellet was placed over mta, till its initial set and restored with resin-modified glass ionomer cement (rmgic) (gc fuji ii lc, gc corporation tokyo, japan).
emd gel was placed on the exposed site and restored with rmgic.
a drop of emd was placed over exposed site after that mta was mixed according to manufacturer's instructions, and the cavities were restored with rmgic.
thirty teeth (ten teeth per group) were extracted atraumatically at 15 and 45 days, respectively.
after extraction, the apical third of all teeth were sectioned and fixed in 10% formalin.
the teeth were decalcified and then dehydrated in ascending grades of n-butyl alcohol and embedded in paraffin.
serial sections of 4 μm were cut using soft tissue microtome (microm hm 340e, thermo scientific, india) in a buccolingual plane and stained with hematoxylin and eosin.
the sections were blindly evaluated by oral pathologists and calibrated according to the criteria given by cox et al.
[14] inflammatory cell response grade 1: absent or very few inflammatory cells.
grade 2: mild or average number <10 inflammatory cells.
grade 3: severe inflammatory lesion appearing as an abscess or dense infiltrate involving one-third or more of the coronal pulp.
grade 4: completely necrotic pulp.
dentine bridge formation grade 1: presence of a calcific bridge directly adjacent to some portion of the medicament interface.
grade 2: presence of a calcific bridge distant from the medicament interface.
grade 3: no evidence of any calcific bridge formation in any sections.
the scores were subjected to chi-square test for data analysis and statistically analyzed through spss 13.0 version (spss inc., chicago, usa).
p < 0.05 was established to state the statistically significant difference.
results histological evaluation the specimens with mta showed thin strands of collagen fibers, dilated blood vessels, newly formed odontoblast cells with mild inflammatory cell infiltrate and thin calcific bridge after 15 days [figure 1a].
after 45 days, the specimens with mta showed the formation of thick calcific bridge without any inflammatory cell infiltrate [figure 1d].
figure 1 photomicrographic images of histologic sections.
(a-c) pulpal response of mineral trioxide aggregate, emdogain, mineral trioxide aggregate/emdogain combination after 15 days’ time interval, respectively.
(d-f) pulpal response of mineral trioxide aggregate, emd, mineral trioxide aggregate/emdogain combination after 45 days’ time interval, respectively the specimens with emd showed bundles of collagen fibers and dilated blood vessels with areas of calcified material [figure 1b].
after 45 days, the emd formed calcific material present above the pulpal floor with numerous new blood vessels.
chronic inflammatory cell infiltration predominantly lymphocytes were also observed [figure 1e].
few specimens showed moderate to severe inflammatory cell infiltrate after 15 and 45 days.
the specimens with a combination of mta and emd showed the formation of new odontoblasts, collagen fibers, and numerous new blood vessels with areas of calcification barrier after 15 days [figure 1c].
the same combination after 45 days showed prominent odontoblastic layer and pulp chamber with collagen fibers and areas of calcification [figure 1f].
the inflammatory response between the study materials concluded that emd showed more inflammatory response compared to other groups after 15 and 45 days which was statistically significant [table 1].
table 1 statistical analysis of samples showing inflammatory cell response the calcific bridge formation was prominent in mta and mta/emd combination when compared with emd after 15 and 45 days which was statistically significant.
no significant difference was found between mta and mta/emd [table 2].
table 2 statistical analysis of samples showing calcific bridge formation discussion in spite of a wide research made in the field of pulp physiology, there is no single gold standard regimen for dpc that can achieve reliable and predictable goals of preserving tooth vitality and tooth function.
the ideal pulp capping material should be biocompatible, prevent bacterial leakage provide a biological seal and stimulate dentin bridge formation.
[1] different authors proposed various criteria to characterize the success of dpc.
tooth that is asymptomatic, responds to sensibility tests and has normal radiographic appearance after pulp capping is said to be clinically successful by many authors.
however, several authors agree that clinical criterion is insufficient to evaluate the long-term prognosis of pulp capping procedures.
the teeth in which healing is complicated by inflammation are impossible to clinically diagnose.
therefore, a critical evaluation of the results can only be made histologically.
[1615] in the present study, the teeth were extracted after 15 and 45 days to observe the early as well as advanced pulpal response.
[41216] clinical studies have demonstrated induction of an early calcific tissue formation with mta after 1 and 2 weeks.
[469] studies suggest that mild inflammation of pulp with mta is due to high alkalinity and is a reversible process.
[24789] mta induces dentin bridge formation, remineralization, and production of transforming growth factor-β1 due to the bioactivity.
[469] paranjpe et al.
in a cell culture study observed an upregulation of important odontogenic genes such as osteocalcin (ocn) and dentin sialoprotein (dsp) and also increased secretion of vascular endothelial growth factor when mta placed in direct contact with dental pulp cells.
[17] several authors believe calcific bridge formation of mta is similar to ca(oh)2 along with good sealing properties and biocompatibility.
[9] in vivo studies showed, less tunnel defects, thicker dentin bridge formation, and less inflammation with mta when compared with traditionally used ca(oh)2.
[479] in the present study, calcific bridge with mild inflammation was observed in teeth that were capped with mta.
results of the present study were in corroboration with the previous studies regarding the pulpal response of mta after 15 and 45 days.
[46789] emd contains amelogenin and enamelin, is used for treating periodontitis to induce cementogenesis.
[18] in an in vivo study conducted in dog teeth concluded that emd is effective in periodontal regeneration.
[19] nakamura et al.
have observed reparative dentin formation by emd on pig incisors.
[12] olsson et al.
in their histological study capped experimentally exposed human pulp with emd (with propylene glycol vehicle) observed formation of thick dentin bridge and fewer postoperative symptoms after 12 weeks when compared to dycal.
[13] in the present study, thin and irregular dentin bridge were formed and few specimens showed moderate to severe inflammation with emd this can be due to the presence of acetic acid and direct contact of rmgic with the exposed pulp.
darwish et al.
have stated that jelly-like consistency of emd could allow direct contact between the glass ionomer base and the exposed pulpal tissues inducing further pulpal inflammation.
[18] he et al.
observed that emd promotes the proliferation and differentiation of mc3t3-e1 cells and inhibits osteoclastogenesis and osteoclast function by stimulating the expression of osteoprotegerin.
[19] weishaupt et al.
observed that emd stimulates osteoblasts and increases the expression of specific mineralization markers like dsp.
[20] in the present study, thick uniform calcific barrier with minimal or no inflammatory response was observed with mta/emd specimens.
results of the present study were in corroboration with the results of the histomorphometric and microcomputed tomography analysis conducted by al-hezaimi et al.
observed dentin bridge formation with no tunnel defects after 4 months in baboon teeth when capped with combination of mta.
the formation of atubular osteodentin was noticed with this hybrid approach of pulp capping procedure.
[21] min et al., by reverse transcriptase polymerase chain reaction found higher level of alkaline phosphatase activity, upregulation of dsp and bone sialoprotien (bsp) with mta/emd treated cells than mta-treated cells.
dsp and bs are noncollagenous proteins synthesized during odontogenesis that are secreted into dentin extracellular matrix.
increased mineralization was found with mta/emd treated on the 7th day than mta-treated cells when stained for calcium deposits with alzarin red.
[22] the presence of inflammatory cells in pulps capped with mta and mta/emd may also result from the restoration of the cavity with rmgic.
microleakage leads to ingress of bacteria which may increase the pulpal inflammation.
[1] rmgic has good sealing properties and is recommended as material of choice in restoring teeth for vital pulp therapy.
[23] similar to the current study, many in vivo and animal studies used rmgic as final restoration over mta, emd, and mta/emd.
[41221] the histologic data of the present study demonstrated, a thick calcific barrier surrounded by well-organized odontoblastic layer and less or minimal inflammation in teeth capped with mta and mta/emd specimens whereas teeth that were capped with emd formed focal areas of calcific bridge with moderate inflammation.
some of the emd specimens failed to form a calcific bridge and had moderate to severe inflammation after 45 days.
garrocho-rangel et al.
and kiatwateeratana also failed to observe improvement in the hard tissue barrier formation in a randomized controlled clinical trial when emd was used as dpc agent and partial pulpotomy procedures respectively in primary molars.
[2425] limitations this histologic study did not emphasize on nature and type of dentin bridge formed.
the study was done over a short-time period and teeth were healthy and free of caries.
therefore, future research should be aimed to evaluate the quality of dentin bridge with large sample size, extended time period, and pulp response on carious affected teeth.
conclusions within the limitations and based on the results of the present histologic study, mta and the synergistic effect of mta and emd induces calcific barrier and less inflammatory response when placed on pulp exposure site.
further research is needed to support these findings.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
aim: the aim of this study is to evaluate the response of human pulp tissue to mineral trioxide aggregate (mta), emdogain (emd), and combination of mta/emd.
materials and methods: this study was performed on sixty intact first and second premolars of human maxillary and mandibular teeth.
a standard pulpal exposure was done on all the teeth and was divided into three groups of twenty teeth each and was capped with mta, emd, and mta/emd combination.
the final restoration was done with resin-modified glass ionomer cement.
the teeth were then extracted on the 15th or 45th day and histological evaluation done.
results: differences in inflammatory response and thickness of dentin bridge formation of the exposed pulp to the three different groups were statistically evaluated using chi-square and mann–whitney tests and were found to be significant.
no significant difference was found between mta/emd and mta in terms of calcified bridge formation and pulp inflammatory response to the capping materials.
conclusions: mta and mta/emd combination produced a better quality hard tissue response compared with the use of emd.
