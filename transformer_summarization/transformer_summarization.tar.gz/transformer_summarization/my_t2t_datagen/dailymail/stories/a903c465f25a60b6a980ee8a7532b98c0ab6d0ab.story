1. introduction abdominal pain, a common complaint during pregnancy, has a broad differential diagnosis which includes spontaneous adrenal hemorrhage (sah).
while autopsy reports reveal that between 0.03 and 1.8% of unselected cases demonstrate adrenal hemorrhage, the incidence among pregnant women is unknown [1].
a high index of suspicion is necessary to diagnose sah as most patients present with nonspecific symptoms including abdominal or flank pain and fever [2, 3].
rarely, patients can develop massive retroperitoneal bleeding and present with hemodynamic instability [1, 4, 5].
if bilateral, sah can lead to adrenal crisis and shock necessitating emergency laparotomy and adrenalectomy [2, 5].
we present two cases of symptomatic sah in the third trimester of pregnancy with successful conservative management.
2. case presentation 2.1. case #1 a 35-year-old nulliparous patient at 36 weeks of gestation presented to labor and delivery complaining of sudden onset, left sided back pain which radiated anteriorly.
she denied any other gastrointestinal or urinary symptoms.
the patient had a past medical history significant only for chronic hypertension and a past surgical history of laparoscopic roux en y gastric bypass two years priorly.
she denied any prior complications related to this surgical history.
the pregnancy was further complicated by gestational diabetes class a1.
on presentation the patient had a blood pressure of 162/80 and heart rate of 70 beats per minute and was saturating 99% on room air.
initial exam revealed the abdomen to be tender to palpation in left upper quadrant with no guarding and no peritoneal signs.
there were no symptoms of labor and fetal status was reassuring.
complete blood count, coagulation studies, liver function tests, amylase, and lipase were all within normal limits with a hemoglobin of 12.4 g/dl.
a urinalysis demonstrated rare bacteria and calcium oxalate crystals, but no blood.
a renal ultrasound showed no evidence of hydronephrosis, mass, or stone.
an obstetrical ultrasound revealed a live singleton fetus with a normal appearing anterior placenta and appropriate fetal growth.
intravenous narcotics were required for adequate pain control.
general surgery was consulted given her history of gastric bypass and concern for a possible related complication.
a ct scan of the abdomen demonstrated a mildly enlarged left adrenal gland with areas of hyperdensity consistent with acute left adrenal hemorrhage (figure 1).
this was a new finding compared with a ct scan performed one year priorly.
the patient denied any history of abdominal trauma or anticoagulation.
she was admitted to the surgical intensive care unit where she was comanaged by maternal fetal medicine and general surgery.
she was monitored with serial hemoglobin assessments and abdominal examinations and remained clinically and hemodynamically stable.
she was discharged home at 37 weeks of gestation after a 4-day hospitalization and returned for induction of labor at 39 weeks of gestation due to chronic hypertension and gestational diabetes.
the patient had an uncomplicated, spontaneous vaginal delivery of a female neonate weighing 7 pounds and 4 ounces with apgars of 8 at 1 minute and 9 at 5 minutes.
her postpartum course was uncomplicated and interval imaging study to assess resolution of the adrenal hemorrhage was planned.
2.2. case #2 a 27-year-old multiparous patient presented to labor and delivery at 38 weeks of gestation for evaluation of sudden onset, left upper quadrant pain that radiated to the midline.
the patient also reported regular, painful contractions.
she had a past medical history significant for nephrolithiasis during her previous pregnancy, bipolar disease, and migraines.
prior surgeries included a diagnostic laparoscopy for chronic pelvic pain, loop electrosurgical excision procedure, and 2 elective terminations of pregnancy.
the patient was a 5-6-cigarette/day smoker.
on admission vital signs were within normal limits.
physical examination revealed her abdomen to be soft and minimally tender to palpation.
a complete blood count was within normal limits with a hemoglobin of 12.4 g/dl.
a urine drug screen was negative and a urinalysis revealed no blood or evidence of infection.
fetal status was reassuring and an obstetric ultrasound revealed no apparent pathology.
the patient's pain improved with intravenous narcotics, antacids, and a muscle relaxer and was attributed to a likely musculoskeletal etiology.
however, the patient was found to be in spontaneous labor and progressed to deliver a male infant without complication.
intrapartum pain relief was provided via epidural.
on the first postpartum day the patient again complained of left sided flank and upper abdominal pain and was presumptively treated for nephrolithiasis, given the clinical presentation and history, with intravenous narcotics and hydration.
despite treatment, the pain worsened and was associated with nausea and two episodes of emesis.
a ct scan of the abdomen revealed enlargement and mild heterogeneity of the left adrenal gland with surrounding fat stranding consistent with acute left adrenal hemorrhage.
an mri performed at the request of the attending physician confirmed these findings as seen in figure 2. she denied any trauma or use of anticoagulants.
total cortisol level was normal at 14.7 ug/dl with a low acth of 5.0 pg/ml.
the patient was monitored with serial assessments of hemoglobin and remained clinically and hemodynamically stable.
her pain was controlled with intravenous narcotics.
she was discharged on postpartum day 4 with a plan for short interval follow-up.
a ct scan performed 8 months later revealed unremarkable adrenal glands with complete resolution of the previously identified hemorrhage.
3. discussion if unrecognized, adrenal hemorrhage can lead to adrenal crisis, shock, and theoretically death for both mother and fetus and should be considered in the differential diagnosis of abdominal pain in pregnancy [3, 4].
presenting symptoms are similar to those in nonpregnant patients and include acute onset flank, abdominal or even chest pain, nausea, vomiting, or hypotension [4, 5].
in order to be classified as spontaneous and idiopathic there can be no history of trauma, anticoagulation, tumor, or sepsis [2, 4–6].
while the initial abdominal imaging study in pregnancy is typically ultrasound, sonographic findings of adrenal hemorrhage are nonspecific.
mri or ct scan is needed to confirm the diagnosis and to evaluate for potential underlying etiology such as pheochromocytoma or malignant tumor [2].
on mri, adrenal hemorrhage appears as a heterogeneous mass with enlargement of one or both adrenal glands while a contrast ct scan demonstrates adrenal echogenicity, streaky appearance of the perirenal fat, perinephric hematoma, or a retroperitoneal hematoma in a massive bleed [2, 4].
a follow-up mri or ct scan is usually recommended to confirm stability or resolution of the hematoma, especially if a conservative approach is adopted.
recommended laboratory evaluations include serial hemoglobin measurements as well as assessment of adrenal function.
work-up should also rule out disseminated intravascular coagulation and thrombotic thrombocytopenic purpura.
consideration should be given to inherited and acquired thrombophilias, including antiphospholipid syndrome, as potential etiologies of adrenal vein thrombosis and subsequent hemorrhage [3].
in both of the above reported cases platelet count and coagulation parameters were within normal limits and there was no clinical suspicion for thrombophilia.
appropriate management of sah in pregnancy depends on the stability of the patient.
conservative management includes supportive therapy with intravenous fluids, pain control, and serial hemoglobin assessments with blood transfusion and correction of coagulopathy as indicated [3].
close monitoring of fetal status is warranted.
preterm delivery may be indicated if a patient is unstable, worsening, or if adrenal hemorrhage is associated with severe preeclampsia or eclampsia [2].
in hemodynamically unstable patients with ongoing hemorrhage arterial embolization can be considered, but severely ill patients may warrant emergent adrenalectomy [3, 7].
there is scant literature available on optimal mode of delivery but, in a stable patient, vaginal delivery can be safely undertaken as demonstrated in the reported cases.
4. conclusion sah, although rare, is an important consideration when evaluating abdominal and flank pain in pregnancy.
diagnosis requires a high index of suspicion, particularly when more common etiologies of pain are excluded as was demonstrated in the two cases presented in this report.
diagnosis can be made by mri or ct scan.
in a clinically stable pregnant patient with sah conservative management and vaginal delivery are safe and appropriate.
@highlight
background.
abdominal pain during pregnancy has a broad differential diagnosis which includes spontaneous adrenal hemorrhage (sah).
there is scant literature available on optimal mode of delivery in stable patients.
cases.
patient 1 was a 35-year-old nullipara who presented at 36 weeks of gestation with left flank pain.
patient 2 was a 27-year-old multipara at 38 weeks who presented with left upper quadrant pain.
diagnosis of sah was made by ct scan and both were managed with pain control, serial hemoglobin assessments, and abdominal exams resulting in uncomplicated vaginal deliveries.
conclusion.
sah, although rare, is an important consideration when evaluating abdominal and flank pain in pregnancy.
management options vary from conservative management to surgical intervention depending on the stability of the patient.
