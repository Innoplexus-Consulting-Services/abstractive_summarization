introduction electronic cigarettes (ec) are nicotine delivery devices marketed as an over-the-counter alternative for smokers.
recent reviews suggest that ec may be effective in reducing tobacco-related morbidity and mortality (8), and may represent a lower health risk option for smokers wishing to quit (1).
these suggestions are based on reports showing that ec do not contain carbon monoxide and other harmful components associated with conventional tobacco cigarettes.
ec deliver vaporized nicotine from a propylene glycol or glycerol suspension heated with an inhalation-activated element.
to date, research on ec has primarily focused on health risk reduction and smoking cessation efficacy (15, 19, 21, 27).
however, the physiological effects of inhaling vaporized nicotine pertaining to metabolism and exercise performance have not been assessed.
nicotine increases resting metabolic rate (rmr) resulting in additional caloric expenditure (26).
because vaporized nicotine delivered by ec is marketed as “safer” than conventional smoking, the general public may perceive ec as a viable weight loss tool.
nicotine also stimulates the cardiopulmonary system (5), which, in turn, may increase the stress of performing physical activity (pa) (25).
these interactions could make exercise for uses of ec problematic.
difficulty in performing pa and reduced physical capacity may decrease the ability of ec users to accumulate the desired daily prescription of pa for health, especially moderate-intensity pa (13).
therefore, ec users’ wellbeing could be affected by vaporized nicotine directly and indirectly by the co-morbidities associated with low capacity for pa. the purpose of this study was to test the hypotheses that acute use of vaporized nicotine delivered via ec would increase resting blood pressure (bp) and rmr, and increase exercise bp while decreasing aerobic power in young, normotensive non-smokers.
the findings from this study could inform individuals considering ec for recreational use or weight management.
methods participants twenty (10 female) volunteer subjects self-reporting as healthy and non-smoking participated (age=23.1±2.5 years, height=1.69±0.1 m, weight=70.6±14.9 kg; all body fat=22.1±11.0%, male body fat=15.3±6.7%, female body fat=28.8.1±10.5%).
subjects were pre-screened for self-reported abstinence from any tobacco products including ec within the past year, known cardiovascular, respiratory, or metabolic abnormalities, prescription or non-prescription drug use, and pregnancy (all female subjects underwent a urine pregnancy test to ensure they were not pregnant).
subjects’ resting seated blood pressure was ≤120 mmhg systolic (sbp) and ≤80 mmhg diastolic (dbp).
participants signed a written consent form approved by the institutional review board for human subject research at the university of texas at san antonio prior to the commencement of any experimental procedures.
consenting subjects had their height and weight with minimal clothing measured prior to having body composition assessed via bioelectrical impedance (bia; tbf-410, tanita, arlington heights, il).
protocol subjects participated in two randomized trials separated by ≥1 week: placebo 0 mg•ml−1 nicotine ec trial and 18 mg•ml−1 nicotine ec trial.
participants were asked to refrain from caffeine, alcohol, dietary supplements, medications, and any activity (e.g., exercise) above that required for basic grooming and activities of daily living for 12 h prior to both experimental sessions.
additionally, participants were instructed to eat an identical pre-trial evening meal 10 h prior (i.e., by 10 pm) to reporting to the laboratory (i.e., 8 am) with water intake encouraged until bedtime and sleep of at least 6 h (≥12 am) the nights before testing.
subjects reported to the laboratory at 8 am in the fasted condition and were instrumented with a heart rate (hr) monitor (polar, kempele, finland) and automated sphygmomanometer (omron healthcare inc., lake forest, il) and then sat quietly for 10 min.
resting bp and hr were assessed before participants were provided a blinded ec and instructed to inhale deeply once every 30 s over the course of 10 min (20 inhalations total).
our inhalation procedure was chosen after informal observations of smokers’ average number of inhalations per traditional cigarette (unpublished observation based on 5 non-smoking pilot subjects, 2 female, of similar age and body composition).
we instructed participants to inhale as deeply as possible although anecdotally, inhalation volume varied amongst subjects.
during a 10 min quiet rest following use of the ec, participants completed a short questionnaire to assess subjective symptoms from the inhalations.
at the conclusion of the 10 min rest period, participants provided a urine sample for the assessment of cotinine (nicalert, biosciences inc, san diego, ca).
seventy to eighty percent of inhaled nicotine is rapidly metabolized to cotinine and therefore this surrogate biomarker found in the blood and urine is commonly used to assess nicotine exposure levels (7).
post-nicotine exposure cotinine levels are much higher in urine than those found in blood (28).
in a preliminary test of the ec inhalation protocol utilized in this study, ranges of urine cotinine concentrations during development of this protocol were significantly higher after nicotine (75±5 ng•ml−1) compared to placebo trials (5±1 ng•ml−1) using the same inhalation schedule.
(n=4, p<0.001, unpublished observation) and this value is similar to that in non-smokers exposed to second-hand smoke (7).
rmr was assessed by indirect calorimetry.
subjects were asked to lay supine while a lightweight see-through canopy was placed over their neck and head.
room air entered the canopy from a one-way port, while expired air was collected from another one-way port inline with a metabolic measurement system (parvomedics truemax 2400, sandy, ut).
to ensure metabolic rate was representative of resting levels, instrumented subjects lay motionless on an exam table with as little visual or auditory stimulation as possible for 15 min prior to the actual 10-min data collection period.
expired air was analyzed to estimate whole-body oxygen consumption (vo2; l•min−1).
caloric energy expenditure (kcal•min−1) was then estimated using the thermal equivalents of oxygen for the non-protein respiratory quotient (rq) (4).
average energy expenditure, vo2, rq, hr, sbp, and dbp were made over the last 5 min of the 10-min indirect calorimetry period.
it should be noted that these resting measurements were assessed starting ~40 min following the last ec inhalation (i.e., following 10 min of seated rest + 10 min for urine collection and instrumentation + 15 min of supine rest + 5 min of supine indirect calorimetry).
subjects then transitioned to a cycle ergometer for the exercise test.
the incremental cycle test protocol commenced 5 min following rmr testing to evaluate participants’ peak power output and cardiorespiratory response and peak aerobic capacity.
subjects were instrumented with a facemask for indirect calorimetry.
subjects rested on a pre-fitted and calibrated electronically braked cycle ergometer (lode excalibur, lode b.v., groningen, the netherlands) for 5 min prior to beginning exercise.
because all subjects were healthy, an incremental cycle vo2max protocol was used whereby workrate started at 15 w and increased by 15 w each minute.
subjects were instructed to maintain 60–70 rpm while pedal resistance changed according to the desired stage workrate.
subjects cycled until they could no longer maintain the rpm or pedal force to maintain the desired workrate.
whole-body vo2, hr, sbp, and dbp were assessed over the last 15 s of each stage.
indirect calorimetric estimations of energy utilization during exercise were assessed similar to that described for rmr above.
cycle exercise began ~55 min following the last ec inhalation (40 min of pre-indirect calorimetry + 5 min of indirect calorimetry + 5 min of cycle instrumentation + 5 min of seated rest on cycle).
statistical analysis statistical analyses were performed with sigmaplot (systat software inc., san jose, ca) urine cotinine concentrations, rmr data, as well as cycle exercise vo2peak, and wpeak were evaluated using a paired t-test.
the cycle exercise response was also assessed using a two-way repeated measures analysis of variance (anova) for intervention (nicotine vs. placebo) and time.
data for 45, 90, and 135 w were used for submaximal analyses, as all 20 participants completed these stages.
in the event of significant interactions between groups, results were explored further with bonferroni post-hoc tests.
data are presented as means ± standard deviation (sd) unless noted otherwise.
the a priori alpha level was set at p≤0.05.
results participants’ pre-inhalation sbp, dbp, and hr were not significantly different between conditions or from those averaged over the last 5 min of the indirect calorimetry protocol (table 1).
a single brand of over-the-counter ec was used for this study (green smart living, salt lake city, ut).
the 18 mg and 0 mg ec cartridges are marketed to vary only in nicotine content.
as described above, cotinine was assessed on post-inhalation (i.e., 10 min) urine samples.
the cotinine concentration ranges, as scored using the semi-quantitative urine analysis kit strips, were significantly higher (p<0.001) after nicotine inhalation (30–100 ng•ml−1) compared to placebo (0–10 ng•ml−1).
rmr was assessed ~40 min after the last ec inhalation.
rmr (p=0.39), vo2 (p=0.5), rq (p=0.15), and hr (p=0.47) were not significantly different between the placebo and nicotine trials (table 1).
compared to the placebo trial, nicotine use resulted in a 3.7 mmhg lower resting sbp (p=0.04) but a 3.0 mmhg higher dbp (p=0.04) (table 1).
vo2peak was not different between the nicotine trial (2.3±0.8 l•min−1) and placebo trial (2.3±0.7 l•min−1) trials (p=0.77, figure 1b).
no statistically distinguishable difference was observed for wpeak between nicotine (201.0±53.8 w) and placebo (204.8±57.8 w) (p=0.29, figure 1b).
there was a main effect of time over the cycle test for vo2 (figure 1a), energy expenditure, rq, and hr but no between treatment effects.
a main treatment effect was identified for dbp, which was higher following nicotine compared to placebo at all time points during the test (p=0.05, figure 2a).
no time by treatment interaction was identified for any variable during exercise.
exercise dbppeak after nicotine (79.4±7.6) was significantly higher (p=0.02) than placebo (74.9±8.3 mmhg) (figure 2b).
peak sbp was not different between trials (p=0.14).
discussion the potential of ec use on smoking cessation efficacy and possible health risk reduction compared to traditional cigarettes has been evaluated (15, 19, 21, 27).
however, to our knowledge the physiological effects of vaporized nicotine inhalation on energy metabolism and exercise performance have not been addressed.
in this study, we report the acute cardiorespiratory and performance effects of vaporized nicotine delivered via ec at rest and during cycle exercise in young, normotensive non-smoking subjects.
we hypothesized that acute ec (18 mg nicotine) use would result in elevated resting caloric expenditure.
however, no differences were observed for rmr or other cardiorespiratory measures between nicotine and placebo trials aside from those found for dbp.
perkins et al.
(26) identified a slight placebo effect on rmr from inhalation of a placebo (zero nicotine content) cigarettes.
this finding indicates possible physical and/or behavioral but non-pharmacological aspects of smoking that may also contribute to acute increases in rmr with the act of smoking.
our protocol did not include a “non-smoking” arm, so it was not designed to ascertain this putative effect with inhalation on a placebo ec.
from the present findings, the potential for acute ec to alter metabolism is not apparent, and the long-term metabolic effects of ec use need to be investigated.
perkins et al.
(25) detected a two-fold greater steady-state energy expenditure attributable to nicotine use compared to placebo in smokers.
this effect was not observed following ec use in non-smokers during our incremental protocol.
this may be attributable to different responses in non-smokers versus smokers with acute and single exposure.
nicotine delivered by traditional cigarettes is known to acutely increase arterial pressure and hr via elevated sympathetic activity (9, 11, 18, 22, 23) and impaired cardiac diastolic function in smokers (3) and non-smokers (2).
farsalinos et al.
(2014) recently reported a statistically significant 3 mmhg greater dbp 5-min following acute ec use (11 mg•ml−1) in chronic ec-using ex-smokers.
we also found a 3 mmhg higher dbp ~40 min following nicotine inhalations in young, normotensive non-smokers in itself does not necessarily indicate a clinically relevant finding.
dbp was also significantly higher during the nicotine trial at all submaximal exercise intensities compared with the placebo condition.
additionally, exercise dbp at vo2peak following nicotine inhalation was 4.5 mmhg higher than placebo.
we recently reported higher resting and orthostatic arterial pressures in young, normotensive non-smokers following acute ec nicotine exposure compared with placebo (10), and suggest that this and our current observations are related to known increases in plasma catecholamines observed with smoking (16).
a slightly higher dbp observed at rest and during exercise warrants further investigation.
if acute exposure to vaporized nicotine raises dbp in normotensives, a commensurate increase in exercising hypertensive individuals could hold clinical significance with respect to cardiovascular disease risk.
whether resting and/or exercise differences would be observed with ec use in smokers, hypertensive, older, and cardiac diseased individuals remains to be explored.
our findings are not without methodological limitations.
first, the actual nicotine level in commercially available ec may vary from advertised concentrations (17, 19) and affect total and between-subject variability of nicotine dosage.
secondly, the volume of vapor inhaled by our subjects was not controlled and may have varied across individuals and across trials.
anecdotally, observed inhalations were shallow in most subjects making possible comparisons with estimated lung volume and subsequent cotinine levels dubious.
the new and uncomfortable feel of the vapor occasionally made subjects cough and sneeze in some instances, but not consistently.
the ~40 min period between inhalations and rmr as well as the 55 min post-inhalation period before exercise could have affected possible trial differences if the effects of nicotine had waned or not reached maximal effectiveness.
finally, our cotinine test kit only provided wide ranges for values.
this, and the questionable reliability of the values that we did measure made statistical analyses and other comparisons equally unreliable.
epidemiological studies confirm that electronic cigarette use is expanding worldwide (14, 20, 6) with growing popularity among adolescents (12, 20) and non-smokers (24).
perception of ec as a safe and viable weight loss tool or recreational stimulant warrants public awareness of any concomitant negative physiological effects.
nicotine has been shown to elevate whole-body energy metabolism (26) and stress the cardiopulmonary system (5), both of which could make physical activity for smokers problematic.
the mild increase in dbp at rest and during exercise warrants continued assessment of the cardiovascular and metabolic effects of chronic use of vaporized nicotine.
@highlight
smokers, and even non-smokers, may utilize vaporized nicotine delivered by electronic cigarette (ec) due to the perception that ec are “healthier” than traditional tobacco cigarettes.
the effects of vaporized nicotine delivered by ec on resting blood pressure (bp) and resting metabolic rate (rmr), or bp and aerobic power during exercise have not been studied.
this investigation tested the effects of acute vaporized nicotine inhalation by ec on resting bp and rmr and cycle exercise bp, metabolic responses, and aerobic power in young, normotensive non-smokers.
using a double-blind design, 20 subjects (10 female) participated in two randomized trials: placebo (0 mg nicotine) or nicotine (18 mg nicotine).
participants inhaled from ec once every 30 s for 10 min (20 inhalations total).
rmr was assessed 40 min later by indirect calorimetry followed by an incremental cycle test.
rmr was not different between trials (p=0.79).
compared to the placebo, resting diastolic pressure (dbp) was 3 mmhg higher with nicotine (p=0.04).
vo2peak was not different between the nicotine trial (2.3±0.8 l•min−1) and placebo (2.3±0.7 l•min−1) trials (p=0.77), and wmax was also similar between nicotine (201.0±53.8 w) and the placebo (204.8±57.8 w) (p=0.29).
during the cycle exercise test, average dbp was higher following nicotine use compared with placebo trial (p=0.05), and exercise dbppeak after nicotine (79.4±7.6) was significantly higher than placebo (74.9±8.3 mmhg) (p=0.02).
resting systolic blood pressure (sbp) was 3.7 mmhg lower for nicotine trial (p=0.04) but no sbp treatment effect was observed during exercise (p=0.14).
our results show that acute vaporized nicotine inhalation via ec increases resting and exercise dbp but does not affect rmr or cycle aerobic power in young, normotensive non-smokers.
