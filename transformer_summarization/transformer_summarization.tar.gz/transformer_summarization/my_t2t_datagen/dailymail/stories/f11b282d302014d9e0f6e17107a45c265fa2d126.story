in the united states, group b streptococcus (gbs) has emerged as a frequent cause of invasive infection in nonpregnant adults with underlying medical conditions.
the incidence of gbs disease among these patients increased from 3.6 cases/100,000 persons in 1990 to 7.3 cases/100,000 persons in 2007 (p<0.001) (1).
this increase has occurred among adults 18–64 years of age and >65 years of age (2).
the centers for disease control and prevention active bacterial core surveillance estimated that 28,000 cases of invasive gbs disease occurred in the united states during 2014 and that 25,900 (93%) cases occurred beyond infancy, primarily in nonpregnant adults (3).
also, adults account for 90% of the estimated 1,660 annual deaths attributable to gbs infection.
most cases of invasive gbs disease are caused by 5 capsular types (ia, ib, ii, iii, and v), which together accounted for 88% of cases in nonpregnant adults during 1999–2005 (2).
the emergence of serotype v in the 1990s was first noted among gbs isolates from nonpregnant adults (4,5).
during 1999–2005, infection with the formerly rare serotype iv increased among nonpregnant adults (1).
as with invasive pneumococcal disease, the capsule of gbs is a major virulence factor targeted by candidate gbs capsular polysaccharide (cps)–protein conjugate vaccines; thus, knowledge of prevalence of these antigens is critical for vaccine development.
similarly, another surface component of gbs critical to virulence, the pilus islands (pis), are limited in number but are found in all strains and are promising as gbs vaccine candidates (6–8).
among infants, use of antenatal screening and intrapartum antimicrobial prophylaxis has markedly reduced early-onset (0–6 days of age) but not late-onset (7–89 days of age) gbs disease.
immunization of pregnant women offers the best strategy for prevention of early- and late-onset invasive gbs disease in infants.
immunization of adults also potentially could reduce the gbs disease burden in the united states, but data are needed regarding immune responses during convalescence from invasive disease (9).
we characterized cps and pi genotypes and expression among isolates and explored immune responses to these surface antigens during convalescence from invasive infection in a cohort of nonpregnant adults.
methods participants and setting we identified cases of gbs bacteremia by conducting prospective, laboratory-based surveillance from march 2012 through october 2014 at 4 texas medical center hospitals (houston, tx, usa) and 3 suburban affiliates of 1 texas medical center hospital, all of which provided uniform diagnostic evaluations and medical care.
invasive infection was defined as isolation of gbs from blood or cerebrospinal fluid.
potential cases were identified daily at participating hospital laboratories.
nonpregnant adults >18 years of age with invasive gbs infection were eligible for enrollment.
we excluded those with symptom duration >7 days, hiv infection, or polymicrobial bacteremia.
an investigator contacted the physician of record for approval before approaching the patient.
study personnel then discussed the study and eligibility with patients and obtained informed consent.
the study received approval by the institutional review boards for human research at baylor college of medicine and participating hospitals’ administrative processes.
specimen collection a blood sample was collected from each participant on the day of hospital admission or at enrollment.
demographic and clinical data were recorded from the medical record.
convalescent-phase blood was collected at a mean of 3 (range 2–4) weeks from the date of positive culture.
blood was transported to the investigators’ laboratory (baylor college of medicine, houston, tx, usa) where serum was separated, aliquoted, and stored at −80°c until sent to gsk vaccines (siena, italy) for testing.
bacterial strains, media, and growth conditions gbs isolates from each patient were obtained from hospital laboratories.
they were then grown in todd hewitt broth (becton dickinson, franklin lakes, nj, usa) at 35°c–37°c for serotyping and inoculated directly from plates into trypticase soy broth with 20% glycerol for storage at −80°c.
serotyping of gbs isolates capsular typing was performed for all isolates.
both the capillary precipitin method (10) and the strep-b-latex rapid agglutination method (statens serum institut, copenhagen, denmark) were used.
genotyping and pilus typing of gbs isolates genomic dna was prepared from gbs cultures by a standard protocol for gram-positive bacteria by mutanolysin treatment of bacteria and use of a genelute bacterial genomic dna kit (sigma-aldrich, milan, italy) according to the manufacturer’s instructions.
capsular gene typing was performed for all isolates by multiplex pcr (11) modified by including a primer pair specific for detection of serotype ix.
pilus genes were pcr amplified by using primers specifically annealed to conserved genomic regions external to the coding sequences as described (8).
multilocus sequence typing multilocus sequence typing was performed as described (http://pubmlst.org/sagalactiae/).
clonal complexes (ccs) were assigned by global optimal eburst analysis of multilocus typing data (12).
fluorescence-activated cell sorter analysis fluorescence-activated cell sorter (facs) analysis to assess surface expression of cps and pilus proteins was performed as reported (13,14).
in brief, paraformaldehyde-fixed bacteria were incubated with mouse monoclonal antibodies or immune polyclonal serum specific for cps type and pilus proteins (14).
cells were stained with r-phycoerythrin-conjugated f(ab)2 goat anti-mouse igg (jackson immunoresearch laboratories, west grove, pa, usa) and analyzed with a facs canto ii instrument (becton dickinson) and flowjo software (tree star inc., ashland, or, usa).
elisa serum cps-specific igg was determined by elisa.
microtiter plates (96-well) (nunc maxisorp; sigma aldrich, st. louis, mo, usa) were coated overnight at 2°c–8°c with 100 ng of purified cps ia, ib, ii, iii, iv, or v conjugated to human serum albumin-adipic acid dihydrazide in phosphate-buffered saline (pbs) at ph 7.4. after washing with 0.05% tween-20 in pbs (pbst), plates were incubated for 90 min with 2% bovine serum albumin in pbst.
serial 2-fold dilutions of test and standard serum in 2% bovine serum albumin in pbst were added, incubated 1 h, and washed.
after alkaline phosphatase-conjugated anti-mouse igg (1:1000 in pbst) was added, plates were incubated for 90 min and then washed.
after incubation with p-nitrophenylphosphate (4.0 mg/ml), the reaction was stopped with edta 7% (wt/vol) and absorbance was measured at 405 nm.
the concentration of specific igg was determined with a standard titration curve and expressed as micrograms per milliliter (cps ia, ib, iii, and v) or elisa units per milliliter (cps iv).
standard samples containing 47.2, 35.4, 30.4, 83.5, or 11.6 μg/ml of anti-cps ia, ib, ii, iii, and v igg were prepared by pooling serum from women immunized with the specific cps conjugated to tetanus toxoid (15).
the cps iv standard was prepared by pooling unweighted high-titer serum from study participants.
the lower limit of quantitation was 0.156 μg/ml for types ia, ib, and v; 0.250 μg/ml for types ii and iii; and 12.5 elisa units/ml for type iv.
a titer corresponding to one half of the lower limit of quantitation was assigned to serum with values below the lower limit of quantitation.
multiplex immunoassay pilus protein–specific igg was measured by multiplex immunoassay that used recombinant pilus proteins bp-1, bp-2a, and bp-2b coupled to magnetic beads and expressed as relative luminex units (rlu) per milliliter.
a total of 20 μg of each protein was coupled to carboxyl groups of a specific magplex bead set (luminex corporation, austin, tx, usa).
three sets of coupled beads (3,000 beads/region/well) were added to each dilution of the standard curve and serum samples (1:100 and 6 serial 2-fold dilutions), incubated for 90 min in the dark, with shaking at 700 rpm.
beads were washed twice with 200 μl of pbs and incubated with phycoerythrin-conjugated goat anti-human igg f(ab′)2 (jackson immunoresearch laboratories) at 5 μg/ml for 1 h in the dark, with shaking at 700 rpm.
after a second wash, beads were suspended in 100 μl pbs.
analysis was performed on a flexmap3d instrument by using bio-plex manager software version 6.0 (bio-rad, hercules, ca, usa).
for each analyte, median fluorescent intensity was converted to rlu per milliliter by interpolation from a 5-parameter logistic standard curve for every bead-region/standard.
standard serum for determination of human igg specific for gbs pilus proteins was obtained by pooling hyperimmune serum from persons colonized by gbs.
a titer of 1 rlu/ml was arbitrarily assigned to the highest concentration point of the calibration curve.
the lower limit of quantitation for the pilus proteins was 0.14 rlu/ml for bp-1 and 0.41 rlu/ml for bp-2a and bp-2b.
statistical analyses clinical features, by patient age group, were compared by using the 2-tailed fisher exact test.
antibody responses to cps or pilus proteins were assessed by paired t-test on log-transformed data.
cps-specific igg concentrations were compared for homologous and heterologous (mann–whitney u test) gbs serotypes.
results participant characteristics participants comprised 102 nonpregnant adults (race/ethnicity 44% white, 30% black, 25% hispanic, 1% other) with gbs bacteremia.
mean age was 59.5 years (median 59.7, range 27–91 years).
most (75%) were from texas medical center hospitals.
most (59%) were male.
one patient also had meningitis.
all patients had >1 condition that enhanced risk for invasive gbs disease, including diabetes mellitus (59%), obesity (57%), cardiovascular disease (45%), liver disease (20%), kidney disease (19%), or cancer (10%) (1,2).
the most common expressions of illness were skin/soft tissue infection (43%) bacteremia without focus of infection (16%), osteomyelitis (12%), and endocarditis or endovascular infection (8%).
four patients died, 2 of them before convalescent-phase serum was obtained.
characteristics of infecting gbs isolates of 102 isolates, 92 expressed 1 of 6 capsular types.
cps type ia accounted for 24.5% of isolates, followed by types iii (16.7%), iv (13.7%), v (12.7%), ib (12.7%), and ii (9.8%) (figure 1, panel a).
the genotype and serotype for these 92 isolates were concordant.
cps expression was undetectable by latex agglutination and capillary precipitin methods for 10 (9.8%) isolates; 7 were identified by facs analysis as type ia (1), ii (3), or v (3).
the genotypes for the 10 isolates were ia (1), ii (3), and v (6).
genotypes and ccs for all 102 isolates are displayed (figure 1, panel b); 77% of these isolates were 1 of the 3 lineages (cc1, cc19, or cc23).
the hypervirulent cc (cc17) accounted for 35% of type iii isolates.
among type iv isolates, cc1 (57%) and cc23 (43%) were exclusively represented.
figure 1 cps type and pi distribution and expression in 102 group b streptococcus isolates from adults with invasive infection, houston, texas, usa.
a) cps distribution of isolates by capillary precipitin method and latex agglutination assay (indicating cps expression).
b) correlation between cc distribution and cps genotype by pcr.
c) pi and cps distribution by genotype.
d) relationship between pilus genotype distribution and pilus expression in isolates expressing >1 pilus type on their surface.
cc, clonal complex; cps, capsular polysaccharide; nt, nontypeable; pi, pilus island.
pi genes were detected in all isolates (figure 1, panels c and d).
most carried genes for pi-1 and pi-2a (56%) or pi-2a alone (32%).
according to flow cytometry, 89% of isolates expressed in vitro >1 pilus type on their surface, most often pi-2a alone or with pi-1.
pi-2b was expressed only by type iv strains or in combination with pi-1 by type iii strains.
genes for pi-1 and pi-2a were present on 8 of 11 isolates not expressing pili.
the cps types for the 11 strains that did not express pili were ia (1), ib (2), ii (4), iv (2), and v (2).
all gbs strains expressed either cps or pili, and 79% expressed both surface antigens.
immune responses paired acute- and convalescent-phase serum samples were available from 97 patients, but only 87 were infected with cps-expressing strains.
a significant increase in cps-specific igg was observed during the convalescent phase for each of the 6 gbs types causing invasive disease in these 87 patients (table).
however, the concentration of antibodies to cps in acute- and convalescent-phase serum varied widely (figure 2).
when cps-specific igg was expressed as >4-fold increases during convalescence, an immune response to their infecting serotype was detected for 50% (ia), 31% (ib), 50% (ii), 41% (iii), 42% (iv), and 46% (v) of patients.
table cps-specific igg responses for 87 nonpregnant adults with invasive gbs infection* gbs type cps-specific igg, gmc (range) [95% ci], μg/ml no.
patients† acute-phase sample convalescent-phase sample p value‡ ia 22 26.0 (0.39–609.1) [9.5–71.0] 137.6 (0.35–7,792.2) [50.4–375.6] <0.001 ib 13 9.3 (0.08–680.9) [1.6–55.6] 25.2 (0.08–650.5) [4.6–139.5] 0.035 ii 10 11.6 (0.13–1,126.8) [1.2–113.6] 47.4 (0.61–2,279.9) [6.1–366.1] 0.032 iii 17 1.5 (0.13–153.9) [0.53–4.0] 4.8 (0.13–584.4) [1.1–20.4] 0.044 v 13 3.2 (0.24–596.3) [0.51–19.9] 10.1 (0.43–4,182.0) [1.9–55.0] 0.003 iv§ 12 409.5 (17.6–4,823.3) [133.3–1,257.5] 1,060.9 (149.4–9,085.2) [415.7–2,707.6] 0.022 *cps, capsular polysaccharide; gbs, group b streptococcus; gmc, geometric mean concentration.
†excludes 10 patients with infection caused by gbs that did not express capsular polysaccharide, 3 for whom convalescent-phase samples were of insufficient quantity for analysis, and 2 who died before collection of convalescent-phase serum.
‡paired t-test on log-transformed data.
§results are expressed in elisa units/ml.
figure 2 cps-specific igg concentrations/titers in acute- versus convalescent-phase serum from patients with group b streptococcal infection, houston, texas, usa.
horizontal bars represent median concentrations (± interquartile range) for each patient group.
conv, convalescent; cps, capsular polysaccharide; eu, elisa units.
for all patients, cps-specific igg concentrations in convalescent-phase serum samples were compared with the infecting gbs serotype and with heterologous gbs serotypes (figure 3).
with the exception of type iii, the means and interquartile ranges of cps-specific igg were significantly higher (p<0.001) for the infecting gbs serotype than for the other 5 serotypes, indicating that the cps immune response in adults is capsular type specific.
figure 3 concentrations of cps-specific igg against homologous or heterologous group b streptococcal serotypes in convalescent-phase serum samples from infected patients, houston, texas, usa.
horizontal bars indicate median concentrations (± interquartile range) within each group.
cps, capsular polysaccharide; eu, elisa units; het, heterologous; hom, homologous.
pi-1–specific igg increased significantly for the 35 patients infected with gbs strains expressing pi-1 when acute-phase serum (geometric mean concentration [gmc] 25.2 rlu/ml [range 0.57–765.0; 95% ci 12.2–52.0]) was compared with convalescent-phase serum (gmc 53.7 rlu/ml [range 0.5–4972.1; 95% ci 24.3–118.7]) (p = 0.003).
similarly, pi-2a–specific igg increased significantly between acute illness (gmc 15.0 rlu/ml [range 0.8–606.5; 95% ci 10–22.5]) and convalescence (gmc 28.7 rlu/ml [range 0.8–1459.9; 95% ci 19.43.2]) for the 66 patients with infection caused by gbs isolates expressing this pilus type (p<0.001) (figure 4).
among the 12 patients infected with gbs strains expressing pi-2b, there was no significant pi-2b–specific igg response (data not shown).
we detected >4-fold increases in pilus-specific igg during convalescence in 20% (pi-1), 16.7% (pi-2a), and 25% (pi-2b) of patients.
among these 20 patients, response to their infecting cps type was also >4-fold for 14 (70%).
figure 4 pilus-specific antibody responses in acute- and convalescent-phase serum from patients infected with group b streptococcal strains expressing pilus type 1 or type 2a, houston, texas, usa.
anti-pilus–specific igg titers were measured by multiplex immunoassay that used recombinant pilus proteins coupled to magnetic beads and expressed in rlu/ml.
horizonal bars represent the median (± interquartile range) within each population.
for both comparisons, anti-pilus igg increased significantly in serum collected during the acute and convalescent phases (p<0.001).
p values were calculated by t-test on log-transformed data.
conv, convalescent; rlu, relative luminex units.
discussion gbs is a common pathogen in nonpregnant adults (16).
skoff et al.
(1) suggest that the increasing prevalence of chronic medical conditions might explain the increasing incidence of gbs disease among adults.
most patients in our cohort had underlying conditions, as has been noted previously (1,17–19).
skin/soft tissue infections were present in 43%, and the presentation was nonfocal for 16%, usually in patients with hepatic disease (1,2).
our investigation led to 3 major findings.
first, serotype iv gbs was a prominent cause of invasive disease, accounting for 13.7% of cases.
skoff et al.
(1) noted that type iv cases increased from 0.2% during 1998–1999 to 5.7% during 2005–2006.
characterization of 549 strains from canada during 2010–2014 indicated that 16.9% of cases with invasive disease were caused by serotype iv (20).
in our cohort, 6 gbs types were responsible for at least 10% of cases, but only types ia (24.5%) and iii (16.7%) caused more infections than type iv.
none of the cases reported here were caused by gbs types vi–ix; skoff et al.
(1) identified only 3 of these types among 1,933 isolates from nonpregnant adults.
invasive type iv gbs infections were clinically diverse and included bacteremia without focus (4 patients), skin and soft tissue infections (3), osteomyelitis (3), septic shock (1), endocarditis (1), arthritis (1), and urosepsis (1).
second, our findings add to limited data regarding gbs virulence factors critical to invasive disease pathogenesis in adults.
most gbs isolates can be assigned to a small number of ccs, including cc1, cc10, cc17, cc19, and cc23 (21).
three major lineages (cc1, cc19, and cc23) accounted for 77% of isolates from our cohort.
these 3 ccs comprised 64% of isolates from nonpregnant adults in sweden who had invasive infections during 1988–1997 (22).
cc19, associated with less invasive type iii strains in neonates, accounted for 63% of type iii isolates in the patients reported here; the hypervirulent cc17 comprised only 33%, suggesting that less virulent strains may cause invasive disease in adults (23,24).
among type iv isolates, cc1 and cc23 were exclusively represented, extending the observations of ferrieri et al (25) that type iv isolates from nonpregnant adults with invasive disease were cc1 and that those from invasive infection in infants were cc23.
no type iv isolates belonged to the novel epidemic hypervirulent cc17 lineage resulting from the type iii to type iv capsular switch (26,27).
teatero et al.
(20) assert that emergence of serotype iv in canada was driven by cc1 sequence type 459 strains, possibly linked to acquisition of resistance to tetracycline, macrolides, and lincosamides.
all strains isolated from the patients reported here expressed cps, pili, or both surface-associated gbs virulence factors.
for a subset of strains, expression was undetectable for cps (10%) or pilus (11%).
the proportion of nontypeable strains (assessed by conventional cps typing methods) in our cohort was greater than the 6.5% reported by the centers for disease control and prevention during 2005–2006 (1).
also, the proportion of strains for which pilus expression was undetectable was slightly higher than the 6% reported for 289 gbs isolates from the united states and italy, but these data represented infants and adults with either invasive infection or asymptomatic colonization (8).
third, as a group, nonpregnant adults demonstrated an immune response to major virulence antigens after invasive gbs infection.
cps-specific igg to each infecting cps type and pi-1– or pi-2a–specific igg almost always increased significantly in convalescent-phase serum.
however, the immune response was complex; the range of antibody concentrations in acute- and convalescent-phase serum was broad, a pattern not found in neonates and infants, for whom low concentrations of cps-specific igg are uniformly found in acute-phase serum (28).
we observed several patterns of immune response.
between acute illness and convalescence, cps-specific igg increased by >4-fold for 44% of patients.
by comparison, cps-specific igg increased by >4-fold in postimmunization serum from 80%–93% of healthy adults immunized with monovalent gbs conjugate vaccines representing cps ia, ib, ii, iii, and v (29).
for other patients, cps-specific igg in concentrations at the time of hospital admission were higher than the 0.5–3 μg/ml predicted to be protective against neonatal infection (30), suggesting that either the immune response was rapid or that an immune response to cps is not as critical for nonpregnant adults with invasive infection as it is for neonates.
wessels et al.
(31) noted that the serum cps-specific igg to the infecting gbs isolate in adults with bacteremia was >3.5 μg/ml in 7 of 12 serum samples obtained within 2 days of admission.
although acute-phase serum from the patients reported here was almost always collected at the time of admission and those who had symptoms >7 days before admission were excluded from enrollment, for some, a rapid, anamnestic response could have developed before admission.
many patients had diabetes and lower extremity infection or chronic lower extremity disease that could have led to prolonged antigenic stimulation resulting in a high level of cps-specific igg that declined during convalescence.
our study has some limitations.
because we enrolled patients from only 1 city, the diversity of surface antigens relevant to immune response might not be applicable to other regions.
despite obtaining acute-phase serum at admission, the time of bacteremia onset could not be determined, complicating interpretation of immune response results.
our study was not designed to evaluate functional aspects of immune responses, which will be relevant to vaccine design considerations.
one requirement for a robust protective response is surface availability of antigens for antibody recognition (7).
in murine models of gbs disease, pilus components induce protective immunity against all tested gbs challenge strains (8), and sufficiently high cps-specific antibodies are associated with disease protection for newborn infants (30,32).
the concept that cps-protein conjugate vaccines are immunogenic in older adults also is well established (33).
a 13-valent polysaccharide conjugate vaccine has proven effective at preventing vaccine-type invasive disease caused by streptococcus pneumoniae, another pathogen that results in serious illness in adults with underlying medical conditions and those >65 years of age (34).
theoretically, a gbs conjugate cps vaccine also incorporating pilus protein surface antigens could elicit a protective immune response providing protection for those adults at risk for invasive infection.
@highlight
antibodies to capsular polysaccharides and pilus proteins develop in recovering adults.
