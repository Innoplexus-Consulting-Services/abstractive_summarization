introduction induced pluripotent stem (ips) cells are pluripotent stem cells generated artificially via genetic manipulation of somatic cells (1).
ips cells can be generated from fully differentiated non-pluripotent cells and possess pluripotency similar to that of embryonic stem (es) cells (2).
as they are derived from patients own cells; they are bio-compatible and can aid in disease modeling, drug screening and designing tailored treatment for individual patients (3, 4).
these cells were discovered by dr. shinya yamanaka by reprogramming mouse skin fibroblasts to their embryonic state so as to generate a patient-specific embryonic stem (es) cell equivalent from autologous somatic cells, which can develop into all tissues/organs (1).
ips cells can be obtained from either mouse cells or human embryonic or somatic cells via retroviral transduction of four transcription factors (fig.
1) (1, 2, 5).
currently non-integrating techniques i.e.
virus-free and dna-free has been developed for the production of ips cells (6–8).
ips cells and embryonic stem (es) cells are similar in terms of expression of certain stem cell genes and proteins, doubling time, chromatin methylation patterns, embryoid body formation, teratoma formation, viable chimera formation, potency, and differentiability (1, 9, 10).
like es cells, ips cells have potential for proliferation, and differentiate into all derivatives of the three primary germ layers (ectoderm, endoderm, and mesoderm) and many mature cells in vitro (1, 11, 12).
ips cells can maintain self-renewal when cultured under conditions similar to those used for es cells (12).
hiyama et al., observed similar responses of odontoblast-like cells derived from ips and those derived from es cells (13).
also ips cells are capable of differentiation into mature osteoblasts and produce hydroxyapatite having crystal structure similar to that of ms cell-associated hydroxyapatite (14).
in the field of dentistry (12), ips cells with high reprogramming efficiency and proliferation rate have been derived from stem cells form apical papillae (scap), dental pulp stem cells (dpscs) and stem cell from human exfoliated deciduous teeth (shed) (15, 16), stem cells from third molars (17), buccal mucosa fibroblasts (18), gingival and periodontal ligament fibroblasts (fig.
1) (19).
studies have shown the usage of ips cells, in mouse model, for differentiation into ameloblasts (20) and odontogenic mesenchymal cells (21).
also ips cell has the pluripotency for differentiation into all three primary germ layers (1, 22).
thus ips cells generated from discarded oral tissues can be used for autologous cell-based oral tissues regeneration (periodontal regeneration), custom modulation of oral diseases for individual patients, and to design tailor-made diagnostic tools.
they may also help to understand and specify the complex developmental process of oral organs (4).
pros & cons of ips cells pros (1, 8, 9, 11, 12) ips cells are universally accessible and relatively easy to obtain and process.
ips cells have the potential to proliferate and differentiate into all derivatives of the 3 primary germ layers i.e.
ectoderm, endoderm, and mesoderm.
ips cells can produce patient-specific or disease-specific cells of any lineage for therapeutic use.
ips cells can provide unlimited reservoir of stem cells minus the ethical controversy of embryonic materials.
ips cells are autogeneically accessible, thus avoiding both the ethical and immunological concerns related to embryonic stem cells.
thus, autologous ips cells have reduced chances of immune rejection and are highly biocompatible.
ips cell production can easily be scaled up, to provide an unlimited source of cells for clinical applications.
cons it has been observed that ips cells may retain an epigenetic memory of their former phenotype limiting their differentiation potential (23, 24).
studies have shown that ipsc retain the memory of their tissue of origin during successive early passages in culture (23, 25).
thus differences in reprogramming may occur among different ipsc lines resulting in differential regenerative capacity of cells (like, ms cells) derived from different ipsc lines (25).
residual undifferentiated ips cells at the target sites can uncontrollably proliferate to form teratomas (5).
concerns have also been raised regarding the artificial nature of induced pluripotency in ips cells (12).
viruses that integrate into the host cell genome have intrinsic risks in regards to cell transformation.
therefore there is a risk that viruses (like retroviruses) can transfect oncogenes into the cells.
sources of ips cells in dentistry as discussed earlier ips cells can be derived from stem cells in apical papillae (scap), dental pulp (dpscs) and deciduous/primary teeth (shed), third molars, buccal mucosa (buccal mucosa fibroblasts), gingiva (gingival fibroblasts) and periodontal ligament (periodontal ligament fibroblasts) (12–19, 26).
studies have shown dental tissue-derived stem cells (like, shed, scap, and dpscs) can readily be reprogrammed into ips cells at relatively higher rates as compared to neonatal foreskin fibroblasts and adult dermal fibroblasts (15).
scap scap are derived from the developing tissue at the apex of a tooth root named apical papilla.
yan et al., studied the accessibility and feasibility to generate ips cells from shed, scap and dps cells (15).
it was observed that all 3 cells can be reprogrammed into ips cells at a higher rate than fibroblasts having morphological features similar to es cells in cultures.
they formed embryoid bodies in vitro and teratomas in vivo containing tissues of all 3 germ layers and thus can be used as an alternative source of ips cells (15).
dental pulp stem cells (dpscs) dental pulp has been used to generate ips cells, which can easily be directed to differentiate toward specific oral tissues.
dpscs have higher reprogramming efficiency than the conventionally used dermal fibroblasts (12, 15, 16).
stem cells from primary teeth shed and immature dental pulp stem cell possess higher efficiency of reprogramming ipscs than skin fibroblast cells (12, 15, 27).
toriumi et al., compared the reprogramming efficiency of root cells and crown cells derived from primary teeth to induce ipscs.
the efficiency of generating ips cells from root cells was approximately four times higher than that from crown cells.
reprogramming efficiency was found to be 0.0160% for root cells and 0.0036% for crown cells (28).
thus cells competent for ips generation are more in number in root cells than crown cells of primary teeth and are more potent alternative source for ips cell generation.
ips cells can also be derived from human immature dental pulp stem cells (hidpscs) within a short-time frame as compared to human fibroblasts, shed, and dpsc.
these cell colonies can easily be created even under feeder-free conditions eliminating the possibility of contamination from xenoenvironment (27).
stem cells from third molars mscs from human third molars have shown to generate ips cells by retroviral transduction without using the transcription factors responsible for carcinogenesis (i.e.
c-myc) (17).
the derived ips cells were similar to human es cells in aspects, like morphology, surface markers and gene expression, in vitro differentiation, and teratoma formation.
as usually human third molars are discarded as clinical waste; these cells can provide a valuable, viable and economical source for the generation of ips cells (17).
oral mucosa ips cells isolated from oral mucosa fibroblasts (ofs) via the retroviral gene transfer have shown to have es-like morphology and are pluripotent in nature (18).
ofs may provide for a promising source of ips cells as their retrieval is simple and safe with no aesthetic or functional damage, and rapid wound healing (18).
gingival fibroblasts cells gingival tissue is easily obtainable and gingival cells can be easily expanded from patients.
ips cells obtained from gingiva-derived stem cells have shown better immunomodulatory properties as compared to other oral-tissue derived stem cells (29).
also reprogramming efficiency of gingival fibroblasts obtained from mice is higher than dermal fibroblasts (30).
umezaki et al., generated ips cells from human gingival fibroblasts (hgfs) using episomal plasmid vectors, which showed characteristics similar to es cells (31).
periodontal ligament fibroblasts cells isolated from pdl exhibit an osteoblast-like phenotype and have the capacity to form to form ligamentous structures resembling sharpey’s fibers and mineralized tissues similar to bone and cementum (25).
ms cells-like cells generated from the pdl-ips cells have a superior capacity to form physiological bone and connective tissue, both in vitro and in vivo, as compared to ms cells-like cells derived from gingival and lung fibroblast (25).
applications ips cells in dentistry (fig.
1) • retroviral integration-free ips cells derived from human gingival fibroblasts can be used to produce mesenchymal stem cells-like cells (mslcs).
these mslcs exhibited a higher proliferative capacity than mscs and thus can successfully be applied for tissue regeneration of oral tissues and organs (31).
the commonly applied approach to generate ms cells from human ips cells is spontaneous differentiation of ips cells, followed by selection of msc-like cells (fig.
2).
lian et al., observed that ms cells derived from human ips cells (ipsc-mscs), have greater proliferation capacity than bone marrow derived msc (bm-msc) (32).
they also have improved biosafety and superior potential for cell expansion as compared to direct ips cells (33).
• ips cells combined with dental mesenchyme and transplanted together with collagen sponges have shown to express ameloblasts marker and amelogenin indicating their differentiated into ameloblasts (34).
ips cells co-cultured with an ameloblastin-expressing dental epithelial cell can induce ips cells into ameloblasts via neurotrophic factor 4 (nt-4) and bone morphogenic protein 4 (bmp-4) signaling (20).
yoshida et al., also observed differentiation of ips cells into ameloblast-like cells in feeder-free cell cultures using medium conditioned by cultured epithelial cell rests of malassez (erm) cells and gelatin-coated dishes (35).
• neural crest-like cells (nclcs) derived from ips cells (36) cultured in dental epithelial cell-conditioned medium, express the odontoblast marker for dentin sialoprotein (dsp) and demonstrate the formation of calcified tooth germ-likes structures with bone when transplanted under kidney capsule in immunodeficient mice (37).
thus ips cell-derived nclc can differentiate into odontoblasts via reciprocal interaction with dental epithelium.
alternatively, mouse ips cells can be induced to form odontoblast-like cells, without epithelial–mesenchymal interaction, with the use of collagen type-i scaffold combined with bmp-4 and retinoic acid (38).
the differentiated cells were physiologically functional and non-teratogenic.
• bmp-4 has shown to induce ips cells to form both ameloblast-like and odontoblast-like cells when used with ameloblasts serum-free conditioned medium (39).
• combination of ips cells with enamel matrix derivatives can aid in pdl regeneration via formation of cementum, alveolar bone, and periodontal ligaments (40).
ips cells in combination with a silk scaffold and enamel matrix have shown alveolar bone formation, cementum, and pdl regeneration in periodontal fenestration defects (in mice) (40, 41).
ipsc-mscs implanted into the fenestration defects along with fibrinogen and thrombin clot lead to formation of newly formed mineralized tissue and pdl-like tissue present within the defects (41).
ips cells have also shown, in vitro, expression of periodontal tissue markers associated with bone, periodontal ligament and cementum under the influence of enamel matrix derivative (emd) and growth/differentiation factor-5 (gdf-5) (42).
treatment of periodontitis with ipsc-msc transfected with tumor necrosis factor gene 6 (tsg-6) have shown significant reduction of periodontal inflammation, with reduced levels of inflammatory infiltrates, proinflammatory cytokines and also inhibited the level of alveolar bone loss (43).
• it has been proposed to use reprogram patient’s somatic cells and produce patient-specific ips cells, which are induced to form ectodermal epithelial cells and neural crest (nc)-derived mesenchymal cells.
the interaction between these cells populations (mimicking the in-vivo conditions) can lead to formation of a tooth germ that once transplanted into oral cavity can possibly form a fully developed and functional biotooth (12).
ips cells, derived from urine cells, differentiated into ipsc-derived epithelial cells when combined with dental mesenchyme have exhibited the capacity to form tooth-like structures containing dental pulp, dentin, enamel space, and enamel organ (44).
another alternative proposed option to form biotooth is the combination of ips cells-derived dental epithelial cells (ipsc-dec) and ms cells (endogenous and autogenic).
ipsc-dec will produce enamel producing ameloblasts and ms cells will generate a complete dentin-pulp complex and periodontium.
this recombination will generate a bioengineered tooth germ that can be cultured in vitro and transplanted to the jawbone/maxillary bone of a recipient host to form a fully functional biotooth (45).
following normal dental development ips-derived epithelial cells will disappear after tooth eruption, thus reducing the risk of ips-induced tumorigenesis greatly in the dental system with reduced chances of immune rejection as well.
human ips cells have been successfully differentiated into bone-forming osteoprogenitor cells using 2 approaches.
the first approach involves the direct differentiation of ips cells into osteoprogenitor cells and the second approach involves differentiation of ipscs to ipsc-mscs and then to osteoprogenitor cells (26).
ips cells with bone morphogenic protein 2 (bmp-2) gene modification seeded onto calcium phosphate cements (cpc) have shown enhanced alp activity, osteogenic differentiation, osteocalcin gene expression and bone matrix mineralization, indicated that cpcs seeded with ips cells are suitable for bone tissue engineering (46, 47).
liu et al., (2013) demonstrated that bmp2 gene transduction of human ipsc-mscs seeded on rgd-cpc scaffold enhanced the attachment and osteogenesis of ms cells, osteogenic differentiation and increased bone mineral production without affecting the cell viability (46).
therefore, this technique has potential for bone regeneration in a wide range of clinical applications.
ips cells derived mesenchymal stem cells (msc) seeded with cpc have also shown to have excellent angiogenic capabilities similar to those of human bone marrow-derived mesenchymal stem cells (hbmscs) (47).
theinhan et al., (2013) generated ipsc-derived mesenchymal stem cells (ipsc-mscs), and investigated their proliferation and osteogenic differentiation on calcium phosphate cement (cpc) (48).
they observed that ipsc-msc-cpc constructs have enhanced cell proliferation and mineralization and bone regeneration efficacy.
mscs generated from ipscs showed excellent cell proliferation and differentiation on cpc.
further incorporation of autologous platelets from the plasma into the cpc paste enhanced the ipsc-msc attachment and bone regeneration (48).
tang et al., (2014) also observed that mscs derived from ips cell and supported by cpc scaffolds have better ipsc-msc attachment, cell viability, and proliferation along with elevated osteogenic marker expressions, and bone mineral synthesis.
thus ipsc-msc along with cpc construct can enhance bone regeneration (49).
• in mice model, histological analysis of the produced teratoma, following transplantation of ips cell showed the presence of glandular tissues similar to both the sub-mandibular salivary gland (smg) and the sublingual salivary gland (slg) (22).
though ips cells demonstrate the potential ability to regenerate smg and slg cells; only limited tissues differentiated was observed.
regenerated salivary glands from ips cell showed acinar-like structures similar to embryonic salivary glands with water channel protein in the lumen of the acinar-like structures, indicating their ability to secrete saliva (22).
also salivary glands produced from ips cells had more number of small acinar-like structures than the salivary glands differentiated from embryonic salivary gland cells.
these results indicate that ips cells have a potential ability to accelerate differentiation of salivary gland development and regeneration.
• developmental disorders like ectodermal dysplasia, cleidocranial dysplasia, osteogenesis imperfecta etc., are associated with dental manifestations.
use of disease-specific ips cells from the diseased person could aid in understanding the disease model and treating such genetic oro-dental disorders.
successful ex-vivo genetic manipulations of disease-specific ips cell lines can provide an efficient therapeutic tool for the treatment of dental pathologies and genetic dental disorders.
therefore use of ipsc technology should be directed at each aspect of dental diseases and their genetic causes that are yet to be investigated (14).
challenges and solutions the main challenges and limitations of ips cell technology are related to the issues of epigenetic memory of former phenotype, use of retroviruses, tumorigenesis and teratoma formation and application of xenogeneic materials.
a number of strategic solutions have been proposed and/or researched to overcome these challenges.
epigenetic memory the issue of epigenetic memory of ips cells is currently based on contrasting views regarding their application in regenerative medicine.
as mentioned earlier, epigenetic memory of ips cells derived from their former phenotype limits their differentiation potential (23, 24).
however research studies have shown that those differences between ips cells based on their cellular origin can be harnessed for generation of pscs for the generation of differentiated cell types that are currently hard to produce from existing pscs (50).
ips cell lines derived from different phenotypes can exhibit differential regenerative capacity due to inherited epigenetic memory which can cause a shift in the differentiation spectrum leading to differentiation of ips cell lines into somatic cells of the former (parent) type (25, 51).
for example mouse derived ips cells from skin and blood cells show a differential potential to form either hemopoietic colonies or osteogenic colonies.
ips cells derived from blood cells form hemopoietic colonies more readily, while the ips cell from skin cells form osteogenic colonies more readily (52).
this may not be beneficial always, especially in dental tissue regeneration, wherein selective regeneration of a particular type of tissue having cellular make-up of uniform characteristics is required.
similar differentiation potentials have been observed in human ips cells also (53).
also most of the cells lines established from ipscs derived from various somatic progenitors have failed to successfully participate in the growth and differentiation and development of ips cells derived-tissues in-vivo (54).
however other studies have shown that this skewed differentiation manifested due to epigenetic memory can increase the capacity for spontaneous differentiation into ips cells derived-specific cell lines that can be applied for targeted treatment of selective diseases (50).
beta cell-derived ips cells (bipscs) from human pancreas have demonstrated an increased ability to differentiate into insulin-producing cells both in vitro and in vivo, compared with es cells and non-beta ips cells.
this indicates that epigenetic memory may predispose bipscs to differentiate more readily into insulin producing cells (50).
therefore, ips cells with their skewed differentiation potential into specific cells lines can be used as an advantageous and useful option for cell replacement therapy.
as epigenetic memory can influence the characteristics of ips cell derived from different cell types and thus can impact the outcome in in-vivo situations; they need to be used cautiously in disease modeling studies or in regenerative cell medicine or for the study of developmental events.
approaches have been designed and suggested to overcome this phenomenon.
continuous passaging of the ips cell in culture allow, ips cell to lose their characteristics inherited from the parent cells; diminishing the differences between ips cell and es cells and allowing the ips cells to closely resemble escs (55).
also nuclear transfer es cells (nt es cells) derived by somatic cell nuclear transfer (scnt) are observed to possess less of the epigenetic memory derived form the parent cells as compared to ips cells (56).
tumorigenesis and teratoma formation presence of undifferentiated pluripotent stem (ps) cells like, ips cells can cause undesirable teratomas after transplantation.
thus there complete removal with no/minimal damage to differentiated cells is a prerequisite for clinical application in regenerative therapy.
several approaches can be applied to remove teratomas like, selective ablation using suicide genes and chemotherapy or to remove teratoma-forming cells using specific antibodies (57, 58).
one of the option is to target human ps cell-specific antiapoptotic factor(s) (i.e., survivin) by using chemical inhibitors of survivin (e.g., quercetin) to selectively induce cell death of undifferentiated human ps cells with teratoma potential (59).
ben-david et al., observed that selective removal of claudin-6 (tight-junction protein) positive ps cells from mixed cell population can aid in elimination of residual undifferentiated human pluripotent stem cells from culture (60).
this can be achieved by using an antibody against claudin-6, a cytotoxin-conjugated antibody that selectively targets undifferentiated cells and clostridium perfringens enterotoxin (toxin that binds to claudin-6).
another approach is the application of pluripotent cell-specific inhibitors (plurisins) which, can selectively eliminate human ps cells while sparing a large array of progenitor and differentiated cells (61).
among these the application of plurisin #1 has shown to prevent teratoma formation from tumorigenic undifferentiated cells.
cho et al., advised the use of killerred (kr) suicide gene, to selectively induce phototoxicity of undifferentiated ps cells using visible light via the production of reactive oxygen species and thus successfully inhibiting teratoma formation (62).
use of retroviruses • retroviral integration is a contributing factor to genomic instability and increases the risk of tumor formation.
retroviral integration-free ips cells have been developed from human dermal fibroblasts using episomal plasmid vectors consisting of six transcription factors (6).
the non-integrating reprogramming techniques include both dna (like, adenovirus and episomal plasmid vectors) and dna-free (like, sendai virus, protein or peptide-based delivery and mrna or microrna) techniques (5, 8, 63–66).
ips cell-derived mesenchymal stem cells (ipsc-mscs) have a higher ability to inhibit cancer progression than do bone marrow–derived mesenchymal stem cells (26, 67).
similarly differentiating ips cells into mature populations of cells can overcome the issue of tumorigenesis in the clinical application of ips cells (26).
neural crest-like cells (nclcs) derived from ips cells have shown to express several nc cell markers without teratomas formation when injected subcutaneously together with collagen gel into immunodeficient mice (10).
also lmyc has been advocated as a replacement for c-myc to overcome associated carcinogenic potential (68).
issue of xenogeneic materials ips cells are maintained in an undifferentiated with either the support of xenogeneic feeder cells (such as mouse embryonic fibroblasts) or extracellular matrix (matrigel™) (69).
however, the xenogeneic components of these products prevent the usage of pluripotent stem cells for the treatment of human diseases.
this obstacle have been overcome by the development of synthetic coatings and bioreactors that support the expansion and self-renewal of ips cells in defined culture conditions free from xenogeneic contamination (69).
issue of undifferentiated cells • as the cell reprogramming process is not 100% efficient; a heterogeneous mixture of ips cells, partially reprogrammed cells, and partially differentiated cells is produced following reprogramming (8).
to inhibit teratoma formation, it is important to remove the undifferentiated cells from ips-derived differentiated cells population before using in clinical applications and/or administration to the patients.
therefore, ips-derived differentiated cells must be isolated from the mixed population which, can be achieved using morphology-based manual selection of colonies (70), live cell staining (71), and immunoselection techniques based on fluorescence marked cell surface antigens (72) or antibody marked with green fluorescent proteins or by the use of magnetic-activated cell sorting (8).
thus the current focus should be on designing practical and controlled protocols for the induction of ips cell to generate specific pluripotent cells for the regeneration of targeted tissues and organs.
conclusion ips cells provide an alternative option to es cells without any ethical concerns and with universal usage.
their use and application in dentistry is relatively recent and currently under research.
these cells can be derived from a variety of dental tissue stem cells like, stem cells from apical papillae, dental pulp, deciduous teeth, third molars, buccal mucosa, gingiva and periodontal ligament.
ips cells derived from dental cells lines can have clinical applications and future prospects, both in the field of medicine and dentistry.
however viable and practical solution to issues like, epigenetic memory, tumorigenesis, use of retroviruses and xenogeneic materials, need to be addressed by further qualitative research in this field.
@highlight
ips cells are derived from somatic cells via transduction and expression of selective transcription factors.
both viral-integrating (like retroviral) and non-integrating (like, mrna or protein-based) techniques are available for the production of ips cells.
in the field of dentistry, ips cells have been derived from stem cells of apical papilla, dental pulp stem cells, and stem cells from exfoliated deciduous teeth, gingival and periodontal ligament fibroblasts, and buccal mucosa fibroblasts.
ips cells have the potential to differentiate into all derivatives of the 3 primary germ layers i.e.
ectoderm, endoderm, and mesoderm.
they are autogeneically accessible, and can produce patient-specific or disease-specific cell lines without the issue of ethical controversy.
they have been successfully tested to produce mesenchymal stem cells-like cells, neural crest-like cells, ameloblasts-like cells, odontoblasts-like cells, and osteoprogenitor cells.
these cells can aid in regeneration of periodontal ligament, alveolar bone, cementum, dentin-pulp complex, as well as possible biotooth formation.
however certain key issues like, epigenetic memory of ips cells, viral-transduction, tumorgenesis and teratoma formation need to be overcome, before they can be successfully used in clinical practice.
the article discusses the sources, pros and cons, and current applications of ips cells in dentistry with an emphasis on encountered challenges and their solutions.
