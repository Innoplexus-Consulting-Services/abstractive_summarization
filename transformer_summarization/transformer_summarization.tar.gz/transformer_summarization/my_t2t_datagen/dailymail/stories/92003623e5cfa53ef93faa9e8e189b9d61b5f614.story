introduction postoperative pain control is a challenging situation for a surgeon in patients undergoing shoulder arthroscopy.
postoperative pain can persist for 48 h in postoperative course, even if the patient is started on multimodal analgesic agents.1 for pain management, numerous treatment modalities have been described to date; however, they have some limitations, side effects, and risks.
nonsteroidal anti-inflammatory drugs (nsaids) can cause reduced platelet function, prolonged bleeding time and gastric ulceration.2 opioids can lead to nausea, vomiting, sedation, constipation and intestinal ileus.
intraarticular (ia) local anesthetic injections alone might not be enough to reduce pain, and efficiency of ia local anesthetic or morphine remains controversial.23 although interscalene block (isb) has been used for intraoperative anesthesia and postoperative pain management, it has serious side effects such as inadvertent epidural and spinal anesthesia, spinal cord injury, brain damage, brachial plexus injury and paralysis of the vagus and laryngeal recurrent nerves as well as cervical sympathetic nerve and pneumothorax.
effectiveness of isb is correlated with the anesthetist's skill level.4 recently, suprascapular nerve block (ssnb) and axillary nerve block (anb) are used for intraoperative anesthesia and postoperative pain management in shoulder arthroscopy, especially for rotator cuff repair; however, the procedure is technically challenging and the success rate varies widely.5 successful ambulatory surgery depends on analgesia and it is effective and has minimal adverse effects.3 for blocking nerve effectively, local anesthetic should be infiltrated close to the nerve.
although various techniques have been described ssnb and anb, none of them could achieve effective pain management.3467 our technique has allowed blocking nerves and placing catheters as close to the nerve as possible.
the aim of this study was to evaluate postoperative analgesic efficacy of suprascapular and anbs in shoulder arthroscopy for patients undergoing arthroscopic repair of rotator cuff under general anesthesia.
we hypothesized that suprascapular and anb would alleviate postoperative pain and reduce requirement of analgesic drugs, thus decreasing side effects of medicaments and problems arising out of the technique.
hence, all these benefits would improve patient satisfaction and permit early postoperative shoulder rehabilitation.
materials and methods twenty four consecutive patients who were diagnosed with medium or large cuff tear with retraction <2 cm were treated by shoulder arthroscopy with arthroscopy guided suprascapular and axillary nerve blocks between june 2014 and september 2014. the inclusion criteria were as follows: (1) substantial pain (no posterior pain) and functional limitation, (2) retraction <2 cm, (3) history of more than 6 months and (4) failure of nonsurgical treatment modalities.
informed consent was obtained from all the patients [table 1].
table 1 clinical details of patients (n=24) patients were evaluated with visual analog scale (vas) preoperatively and at postoperative 0 h, 6 h, 12 h, 18 h, 24 h, and day 2.
(0 = no pain, 10 = severe pain).
operative procedure surgeries were carried out under general anesthesia in the beach chair position by the same senior surgeon.
the arthroscopy was achieved using standard posterior “soft spot,” lateral and anterolateral portals for evaluating glenohumeral joint and subacromial space.
after joints were explored, an 18-gauge epidural needle (smiths medical asd, inc. keene, usa) was advanced from the rotator interval to joint, with outside-in technique, and directed toward anterior part of inferior middle glenohumeral ligament and advanced 5 mm into the joint capsule for anb and catheter was advanced through the needle.
after location, the catheter was verified with arthroscopic approach (between 4:30 and 7 o’clock radius for right shoulder and between 5 and 7:30 o’clock for left shoulder), we gave half portion of solutions prepared, which were composed of 10cc of 0.5’ bupivacaine hydrochloride (marcaine 0.5’, astrazeneca inc., london (uk), turkey), for anb.
figure 1a–d shows images obtained during arthroscopy for anb.
after glenohumeral joint was explored and axillary nerve (an) was blocked through the posterior portal, the arthroscope was introduced into the subacromial space through the posterior portal.
we used arthroscopic techniques to block suprascapular nerve (ssn), which was described in 2007 by lafosse et al.,8 for releasing entrapment of ssn at the suprascapular notch with arthroscopic method.
according to this technique after anteromedial bursa was removed to provide access to the suprascapular notch using shaver and radiofrequency (rf), the scope was introduced into the subacromial space through the lateral portal and shaver and rf device was introduced through the anterolateral portal to complete removal of bursal tissue.
this step was done first due to swelling; subacromial decompression, biceps tenotomy or tenodesis, and rotator cuff repair were done after ssnb.
first, coracoacromial ligament was identified, and its trace was followed down the base of the coracoid.
next, coracoclavicular ligaments (conoid and trapezoid) were identified with posterior and medial dissection.
medial border of those ligaments at the base of the coracoid defined lateral insertion of the superior transverse scapular ligament (tsl).
the tsl was identified as the medial continuity of the conoid ligament above the scapular notch.
the suprascapular artery was easily visualized superior to the ligament, and the ssn was identified as it travels underneath the ligament.
once tsl was adequately visualized, an 18-gauge epidural needle was advanced below the tsl and through medial border of transverse scapular notch to place the catheter for blocking ssn.
when the epidural needle was oriented correctly, the catheter was advanced into the needle and the needle was drawn back slowly and catheter position was visualized immediately below the tsl and medial border of the coracoid.
after the catheter was arthroscopically confirmed to be in the accurate location, we gave half portion of prepared solutions, which were composed of 10cc of 0.5% bupivacaine hydrochloride, for ssnb.
figure 1e–h shows the images obtained during arthroscopy for ssnb.
after blocking of the two nerves, the rotator cuff tear was mobilized and repaired using suture anchors.
all patients’ tears were repaired double-row anchor techniques and four biceps tenotomy and two biceps tenodesis were performed.
all patients have performed subacromial decompression because of fraying of coracoacromial ligament and impingement.
to complete the procedure, the portals were closed with an absorbable subcutaneous suture.
eventually, remaining portions of prepared solutions were given through the catheters, which were placed for blocking of ssn and an.
lastly, a velpeau bandage was used.
figure 1 the arthroscopic procedure for left shoulder.
(a) advancement of an 18-gauge epidural needle trough the rotator interval to the joint.
(b) needle was directed toward to anterior of inferior middle glenohumeral ligament (7 o’clock position) and advanced 5 mm into the joint capsule for axillary nerve block.
(c and d) advancement of catheter.
black arrow shows final positions of the catheter.
(e and f) the scope was introduced into the subacromial space through the lateral portal and shaver introduced through the anterolateral portal to complete removal of bursal tissue.
the ccl (conoid and trapezoid ligaments), tsl, ssa, c proses could be seen in front of the shaver.
(g) advancement of an 18-gauge epidural needle below the tsl to place the catheter for blocking suprascapular nerve.
(h) advancement of catheter.
and black arrow shows final positions of the catheter (ri: rotator interval, h: humerus, g: glenoid, c: coracoid, ssc: subscapularis, ssa: suprascapular artery, tsl: transverse scapular ligament, ssn: suprascapular nerve, ccl: coracoclavicular ligaments, *: catheters) postoperative management we give 5cc of 0.5% bupivacaine hydrochloride through both catheters 6 hourly up to end 24 h in postoperative period.
at the end of 24 h, we gave the last dose of 0.5% bupivacaine hydrochloride with 40 mg of methylprednisolone acetate (depo-medrol, pfizer inc., new york (usa), turkey) and catheters were removed at the end of 24 h. we evaluated patients’ satisfaction using vas before additional bupivacaine hydrochloride doses were given.
during this study, patient did not require extra analgesic dose for pain relief.
before patients were discharged, we prescribed nsaid for pain management, but no patient required drug for pain reduction.
all patients were mobilized at postoperative first 3 h. statistical analysis was performed using mann–whitney u-test.
the confidence level was 95%, and significance was set to p < 0.05. analyses were conducted using spss version 15 for windows (spss inc., chicago, il, usa) software.
results no specific complication secondary to nerve block procedure was postoperatively found in patients.
in the postoperative period, no patient complained of or showed motor deficits, vomiting, or nausea.
preoperative and postoperative 0 h, 6 h, 12 h, 18 h, 24 h, and day 2 mean vas scores were 6.38 ± 0.77, 0.44 ± 0.42, 0.58 ± 0.42, 0.63 ± 0.40, 0.60 ± 0.44, 0.52 ± 0.42, and 1.55 ± 0.46, respectively [table 2].
no statistical difference was found among postoperative 0 h, 6 h, 12 h, 18 h, and 24 h scores.
however, comparison of postoperative day 2 and postoperative 0 h, 6 h, 12 h, 18 h, and 24 h vas scores showed a statistically significant difference (p < 0.05) [table 3].
these results demonstrate that intraoperative blockage of two nerves provided excellent pain relief in postoperative period.
all patients were discharged without any complication at the end of 24 h. and they were seen on postoperative day 2 to change dressing and to evaluate pain with vas scores.
the mean time (minutes) of suprascapular and anbs was 14.38 ± 3.21 and 3.75 ± 0.85, respectively.
table 2 vas values table 3 biostatistics findings discussion postoperative pain management is the most important part of the shoulder surgery to facilitate convalescence, shorten hospital stay and start rehabilitation exercise earlier.59 after rotator cuff surgery, boss et al.2 emphasized that severe postoperative pain was seen within first 48 h. nsaids, opiate analgesic drugs, patient-controlled analgesia (pca), ia injections of morphine or local anesthetics, and nerve blocks such as isb, ssnb, or anb are commonly used for reducing postoperative pain.
these treatment modalities can be used alone or in combination.
recently, regional nerve blocks have been a more popular technique than nsaids, opiate analgesic drugs, pca and ia injections.
blocks reduce both intraoperative and postoperative pain efficiently in arthroscopic shoulder surgery.
complications such as vomiting, nausea, sedation, or unsatisfactory analgesic effects cannot be observed.1011 the isb has turned into a preferred technique for intraoperative anesthesia and postoperative analgesia worldwide.
especially, continuous isb block via a catheter after shoulder arthroscopy has reduced pain effectively in comparison with other techniques.
however, this technique has been associated with potential side effects and complications, such as rebound pain, phrenic nerve palsy respiratory distress, or diaphragmatic paresis.121314 the combination of ssnb and anb has been also used effectively for anesthesia in shoulder arthroscopy,6 and these blocks have provided safe analgesia in intraoperative and early postoperative periods.
however, landmarks of ssn and an could not have been described accurately so far.
the philosophy of regional nerve blocks is that the local anesthetic should be infiltrated close to the nerve to the maximum extent.5 therefore, the landmarks of the nerves should be identified precisely.
shoulder is innervated by ssn, an, and lateral pectoral nerve.
posterior and superior parts of joint capsule are innervated by ssn.
anteroinferior part of joint capsule is innervated by an.
anterosuperior part of joint is innervated by lateral pectoral nerve.
the ssn and an carries almost all sensorial impulses to and from shoulder.
hence, contribution of lateral pectoral nerves might remain unnoticed for rotator cuff surgery.4515 accordingly, ssn and an blocks provide effective management of pain in postoperative course of arthroscopic rotator cuff surgery.
anatomies and traces of nerves and location of sensorial branches of the ssn and an should be well known to carry out block anesthesia in intra- and postoperative pain management.
the ssn originates from the superior brachial plexus as a sensory-motor nerve, close to erb's point.8 it crosses the posterior triangle of the neck to the scapular notch, goes on deep to the trapezius and omohyoid muscles and then follows the suprascapular artery to the notch.
the suprascapular notch is a bony depression medial to the base of the coracoid process with its superior aspect roofed by the tsl.
the artery passes over the tsl, whereas the nerve passes underneath this ligament.41516 rarely, both of them can pass underneath tsl.17 at an average of 4.5 cm proximal to the tsl, a relatively large superior articular branch separates from the main stem and runs along with it to enter the suprascapular notch underneath the tsl at its most lateral aspect.
immediately after entering the suprascapular notch, the ssn turns laterally around the base of the coracoid process, to which it consistently releases small periosteal twigs and a small branch to the coracoclavicular ligaments.1518 the main articular branch then advances laterally in the interval between the dorsum of the coracoid and the suprascapular muscle, which is filled with fat and connective tissue and splits into 2 terminal branches.
one of them descends to innervate the coracohumeral ligament and its adjacent capsular region, and the other splits into several small branches innervating the subacromial bursa and the posterior aspect of the acromioclavicular joint capsule.
the main stem of the ssn traverses underneath the tsl into the suprascapular fossa and releases the main muscular branch to the supraspinatus muscle shortly after this passage, which takes off medially.
at the level of the scapula spine, a relatively large constant inferior articular branch separates laterally and travels obliquely toward the posterior joint capsule.
on its course, this inferior articular branch releases several small branches that deviate upward and downward to terminate where the tendon of the infraspinatus muscle merges with the posterior joint capsule and rotator cuff.
the ssn then terminates by innervating the infraspinatus muscle.81516 according to these anatomic pictures, under the tsl is optimal place for blocking ssn because of initial point for separation of sensorial braches of joint.
during arthroscopy, we placed the epidural needle underneath the tsl and advanced catheter into the needle near the ssn, so blocking was achieved.
the an originates from the spinal cord at the c5 and c6 level with occasional contribution from the c4 position.
it is branch of the posterior cord of the brachial plexus, lateral to the radial nerve, and posterior to brachial artery.4 along its course across the subscapular muscle, the an releases its first articular branch, which slowly separates itself from the main stem as it runs to the inferior-anterior joint capsule.
as the an enters the fat and connective tissue near the lower edge of the subscapular muscle, it splits into its 2 main branches.
the medial branch mainly supplies branches for the scapular aspect of the inferior anterior capsule and parts of the axillary recess, whereas the lateral branch runs along the inferior edge of the subscapular muscle to finally innervate the humeral parts of the anterior capsule.
the muscular branch, which innervates the teres minor, issues a small articular branch at the level of insertion of the long head of the triceps to the lateral axillary recess.1519 according to uno et al., 20 the an stayed in the middle third of the “capsular hammock” between the glenoid and humeral neck and it has an intimate relation with the shoulder capsule between the 5 and 7 o’clock (right shoulder) positions.
eakin et al.21 reported that the nerve was closest to the glenoid at the 4:30 o’clock position.
price et al.22 reported that an lies closest to the glenoid at the 6 o’clock position, and the an travels at a fixed distance from the inferior glenohumeral ligament throughout its course, and its average distance from the inferior glenohumeral ligament is 2.5 mm.
the study of bryan et al.23 showed that an average distance from the inferior glenohumeral ligament is 3.2 mm.
according to these anatomic descriptions, anterior shoulder capsule between the 4:30 and 7 o’clock (right shoulder) positions is optimal place for blocking an because of the initial point of separation of sensorial braches of joint.
during arthroscopy, we placed the epidural needle to the anterior joint capsule between 4:30 and 6 o’clock position and advanced the needle 5 mm through the joint capsule and then advanced catheter into the needle to block an.
in this study, tsl was not resected because of having no retraced rotator cuff tears more than 2 cm and no posterior shoulder pain with special test described by sahu et al.24 yamakado1 reported that rotator cuff repair with placed pain catheter adjacent to the ssn via arthroscopically was highly effective in controlling postoperative pain.
in that study, tsl release was performed on each patient during the surgery.
checcucci et al.4 report that 20 consecutive patients underwent arthroscopic procedures for shoulder cuff diseases were performed combined ssnb and anb using the identified landmarks; however, general anesthesia was not performed on any patients.
according to this study, combined blocks were adequate for intraoperative anesthesia and postoperative analgesia for certain procedures of shoulder arthroscopic surgery.
our vas results were similar in this study; however, our vas score was lower.
as emphasized in literature,13457918 the outcomes performed combined block of ssn and an provide good pain relief for postoperative periods.
patient satisfaction is increased by this way.
we performed blocking of ssn an an during surgery by monitoring, so regional nerve blocks philosophy were performed as close to nerve as possible.
in the literature,234567182526 there is no consensus about used kinds, mixtures and combination of local anesthetic agents and combinations with other drugs such as cortisone.
first, we used 10cc of 0,5% bupivacaine hydrochloride for blocking ssn and an in shoulder arthroscopy, after that we used 5cc of 0,5% bupivacaine hydrochloride in each catheter respectively during 6 h intervals up to 24 h. at the end of the 24 h, we used last doses with combined 40 mg methylprednisolone acetate and we removed the catheters.
these mixtures and combinations of local anesthetic agent with cortisone provide effective analgesia after shoulder surgery.
we did not need to give additional analgesic drugs such as nsaids, opioids or pca.
our study has some limitations such as small case number and no control or comparison groups.
besides, learning curve was decreased with time (required mean time [minutes] for blocking of ssn and an: 14.38, 3.75, respectively).
we think that blocks should be done at the beginning of the surgery because of swelling of tissue.
conclusion we obtained good comparable results with the literature about reduction of postoperative pain and provided rapid recovery and rehabilitation.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
background: postoperative pain management is the part of shoulder surgery to improve patient satisfaction, start rehabilitation process rapidly and decrease for hospital stay.
various treatment modalities have been used for pain management, but they have some limitations, side effects and risks.
throughout intraoperative and postoperative period, nerve blocks have been used more popularly than others because of efficacy.
for the regional nerve block, local anesthetic should be infiltrated close to the nerve for maximum effect.
consequently, aim of this study was to evaluate analgesic efficacy when catheters are placed with assistance of arthroscope to block suprascapular and axillary nerves in patients undergoing arthroscopic repair of rotator cuff under general anesthesia.
materials and methods: 24 patients (5 males, 19 females; mean age: 54.3 years) who underwent arthroscopic repair of rotator cuff between june 2014 and september 2014 and were catheterized to block suprascapular and axillary nerves during shoulder arthroscopy were included in the study.
clinical outcomes were assessed using visual analog scale (vas) scores preoperatively and at 0 h, 6 h, 12 h, 18 h, 24 h, and postoperative day 2. results: preoperative and postoperative 0 h, 6 h, 12 h, 18 h, 24 h, and day 2 mean vas scores were 6.38 ± 0.77, 0.44 ± 0.42, 0.58 ± 0.42, 0.63 ± 0.40, 0.60 ± 0.44, 0.52 ± 0.42, and 1.55 ± 0.46, respectively.
no statistical difference was found among 0 h, 6 h, 12 h, 18 h, and 24 h time points; however, comparison of postoperative day 2 and postoperative 0 h, 6 h, 12 h, 18h and 24 h vas scores showed statistically significant difference (p < 0.05).
all patients were discharged at the end of 24 h with no complication.
the mean time (in minutes) required for blocking suprascapular nerve and axillar nerve were 14.38 ± 3.21 and 3.75 ± 0.85, respectively.
conclusion: these results demonstrated that blocking two nerves with arthroscopic approach was an excellent pain management method in postoperative period.
accordingly, patients could recover rapidly and patients’ satisfaction could be improved.
