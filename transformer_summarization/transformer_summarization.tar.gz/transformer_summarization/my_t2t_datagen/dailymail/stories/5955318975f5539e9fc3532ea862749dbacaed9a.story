in recent years, several vectorborne diseases have reemerged either at new locations or to new levels in locations where they have historically ranged.
commonly cited factors for reemergence include evolution of novel vector or pathogen strains (1), increased human mobility or disease spread by infected travelers, decreased herd immunity (2), landscape change (3), climate change (4), and invasion of new regions by competent disease vectors (5).
although disease translocations across continents are almost always a result of human transport, pathogens that exhibit novel regional spread, increased transmission in preexisting locations, or both are more difficult to explain.
such is the case with la crosse encephalitis, a mosquitoborne viral disease currently emerging in the us appalachian region (appalachia, comprising tennessee, north carolina, virginia, and west virginia).
with 30–180 cases of severe lacv disease reported annually (6) and an estimated total disease annual incidence as high as 300,000 cases, lacv is rapidly becoming a leading cause of encephalitis in the united states (7,8).
for patients with severe cases, lacv disease has lifelong neurologic consequences (6) and carries an estimated fatality rate of 0.5%–1.9% (6,9).
previously, most lacv disease cases were associated with forested areas in the midwestern united states (10), where lacv was maintained through a cycle involving the eastern tree-hole mosquito (ochlerotatus triseriatus), hereafter called the tree-hole mosquito, and mammals of 3 species: eastern chipmunks (tamias striatus), gray squirrels (sciurus carolinensis), and fox squirrels (sciurus niger) (10,11).
however, since the mid-1990s, appalachia has emerged as a new focus for the disease (8,12–14).
one potential explanation is the introduction of the invasive asian tiger mosquito (aedes albopictus), hereafter called the tiger mosquito (15).
this suggestion is based on the laboratory-demonstrated competence of the tiger mosquito (16,17), isolation of lacv from field-collected tiger mosquito pools (18), observation of lacv-positive tiger mosquitoes at sites of lacv infections of humans (19), and the coincidental link between tiger mosquito invasion and the emergence of lacv in the appalachian region (12).
unfortunately, although these observations demonstrate the potential for the tiger mosquito to influence lacv dynamics, the contribution of this mosquito to observed increases in lacv transmission remains unclear.
one obstacle to identifying the role of the tiger mosquito in lacv emergence is our limited understanding of the interaction between invasive species and native disease cycles and how this interaction affects disease transmission, both within natural reservoirs and to human hosts.
epidemiologic modeling is a powerful tool, useful for understanding the outcomes of different transmission pathways in other disease systems.
to our knowledge, however, no dynamic models for lacv disease have been developed, even for regions where the tree-hole mosquito is the only disease vector.
we therefore developed a series of compartmental models (figure 1) for lacv.
using these models, we then explored lacv dynamics in systems with (native) and without (invaded) tiger mosquitoes to assess the likelihood that the tiger mosquito is responsible for the emergence of lacv in appalachia.
figure 1 schematic illustrating transitions/interactions in the compartmental model for la crosse virus disease.
subscripted 1, 2, and c denote parameters and state variables for the eastern tree-hole mosquito, asian tiger mosquito, and host populations, respectively.
state variables and parameters are described elsewhere (see basic model and table a1, at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html).
black boxes indicate infected classes; gray boxes, exposed classes; and white boxes, susceptible/recovered classes.
dashed box with gray shading demarks the subset of transitions/interactions that define the native system before tiger mosquito invasion.
methods model we built 3 models: 1) the tree-hole model, in which the tree-hole mosquito is the only lacv vector; 2) the tiger model, in which the tiger mosquito is the only lacv vector; and 3) the tree-hole/tiger model, in which mosquitoes of both species simultaneously serve as lacv vectors.
in the third model, mosquitoes of either species may be driven extinct through competitive exclusion; thus, although both vectors are potentially present, it is possible that only 1 persists.
for all models, we assumed that the vertebrate host was the eastern chipmunk.
the basic dynamic system (figure 1), including all relevant assumptions and system parameterizations, is fully described elsewhere (see basic model, at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html).
basic reproduction number, r0 to determine whether sustained lacv transmission is predicted, we considered the basic reproduction number, r0, for each of the 3 models (see basic reproduction numbers, r0, at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html).
for r0>1, lacv transmission can be sustained.
for r0<1, lacv will go extinct.
transmission pathways the tree-hole/tiger model, which represents current lacv spread throughout much of appalachia and the midwest, accounts for 2 vector species and, thus, 4 transmission pathways: 1) horizontal transmission between tree-hole mosquitoes and chipmunks, 2) vertical (transovarial) transmission by tree-hole mosquitoes, 3) horizontal transmission between tiger mosquitoes and chipmunks, and 4) vertical transmission by tiger mosquitoes.
to determine the relative contributions of the different transmission pathways to r0, we used elasticity analyses (20).
large elasticities indicate transmission routes that contribute most to disease maintenance and spread (see elasticity analysis of transmission pathways, at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html).
lac dynamics r0 analyses reflect equilibrium conditions, which are good approximations of full system behavior when seasonality is weak or when the system reaches equilibrium rapidly within a single season.
because the relevance of seasonality for lacv is unknown, we also considered fully dynamic multiseason extensions to each of our models (see lac dynamics, at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html).
using dynamic simulations, we estimated the fraction of scenarios (i.e., parameter combinations) resulting in sustained lacv transmission above a critical threshold.
this is the numerical equivalent of r0 but may differ as a result of seasonality.
for dynamic simulations in which lacv persists, we also quantified season-long host seroprevalence rates, peak rates of mosquito infection, and the timing of peak transmission to humans.
last, we considered the potential for the tiger mosquito to act as a bridge vector, linking lacv transmission in wildlife reservoirs to infections in human populations.
latin hypercube sampling measurements of system parameters vary, for example, as a result of geographic differences in abiotic variables, differences in local mosquito or chipmunk populations, differences in circulating virus strains, or measurement error.
to capture model predictions over empirically determined parameter ranges, we used latin hypercube sampling, followed by sensitivity analyses with partial rank correlation coefficients (prccs) (see latin hypercube sampling and prcc, at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html) (21).
results basic reproduction number, r0 we found that sustained lacv transmission can occur according to most (60%) tree-hole model scenarios but only a small fraction (3%) of tiger model scenarios (figure 2) (see latin hypercube sampling and prcc, and tables a2 a3, at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html).
this finding is surprising because the average tiger mosquito population has approximately twice as many biting females per hectare as does the average tree-hole mosquito population (see table a2, at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html), which reflects the higher larval carrying capacity and faster larval maturation rate of tiger mosquitoes than those of tree-hole mosquitoes.
clearly, the numerical abundance of tiger mosquitoes does not compensate for the lower rates of horizontal and vertical lacv transmission and the lower rates of their biting on key host species (see basic model, at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html).
figure 2 histograms of basic reproduction numbers (r0) for la crosse virus, based on latin hypercube sampling analyses with 10,000 randomly selected parameter sets (ranges shown at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html).
a) tree-hole model, b) tiger model, and c) tree-hole and tiger model.
in each panel, the black vertical line at log(r0) = 0 corresponds to the general breakpoint between growing and shrinking infection rates and thus represents the threshold for la crosse virus disease persistence.
in the 2-vector system, our results for the tree-hole/tiger model indicated a similar outcome—that the invasion of tiger mosquitoes into tree-hole mosquito populations should reduce the fraction of scenarios (from 60% to 37%) in which lacv transmission is viable.
thus, instead of causing the emergence of new lacv foci, tiger mosquitoes should instead drive lacv out of regions where previously it could persist.
this result is again a function of the poor intrinsic capability of tiger mosquitoes to serve as lacv vectors.
it also depends on asymmetric competition between tiger and tree-hole mosquitoes (see latin hypercube sampling and prcc and table a3, at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html).
for example, whereas 14% of parameter combinations yielded tiger mosquitoes competitively excluding tree-hole mosquitoes, for only 0.03% of parameter combinations was the converse true.
moreover, even when tiger and tree-hole mosquitoes were predicted to coexist, the tree-hole mosquito population declined by an average of 63% through interspecific competition.
by contrast, interspecific competition reduced the tiger mosquito population by an average of only 16%.
not surprisingly, then, when both mosquito species were present, most (average 78%) were tiger mosquitoes.
because the tiger mosquito is the less competent of the 2 lacv vectors, its invasion actually reduces the likelihood of lacv transmission.
transmission pathways elasticity analysis of the 4 virus transmission pathways in the tree-hole/tiger model indicated that in most scenarios the pathway that contributes most to disease spread is horizontal transmission by tree-hole mosquitoes (figure 3).
vertical transmission by tree-hole mosquitoes can also contribute but usually only when the role of tiger mosquitoes is minimal.
for scenarios in which tiger mosquitoes contribute to spread, the main pathway is horizontal transmission either by tiger mosquitoes alone or in combination with horizontal transmission by tree-hole mosquitoes.
by contrast, vertical transmission by tiger mosquitoes rarely affects disease dynamics; when it does, it is only in systems in which horizontal transmission by tiger mosquitoes is already the major mode of disease spread.
figure 3 two views of a quaternary plot showing the relative contributions to basic reproduction number (r0) from 1) horizontal transmission of la crosse virus by eastern tree-hole mosquitoes, 2) vertical transmission by eastern tree-hole mosquitoes, 3) horizontal transmission by asian tiger mosquitoes, and 4) vertical transmission by asian tiger mosquitoes.
this figure plots only the 8,602 replicates (out of 10,000) wherein asian tiger and eastern tree-hole mosquitoes coexisted.
parameters for each replicate were sampled from the ranges according to our latin hypercube sampling scheme (http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html).
lacv dynamics predictions from dynamic models were similar to predictions for r0 (lacv transmission in 46% of scenarios) and matched many expectations from lacv systems (table; see also lac dynamics at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html).
first, in the native system (the tree-hole model) and the invaded system (the tree-hole/tiger model), predicted host seroprevalence rates were remarkably high, approaching 100% toward the end of the season (mean [median] end-of-season host seroprevalence rates of 89% [99%] in the tree-hole model and 84% [97%] in the tree-hole/tiger model).
these rates are consistent with findings from wisconsin where, at least in high-quality mosquito habitats, multiple surveys have demonstrated that antibody prevalence rates among chipmunks can be well over 50%, often nearing 100% late in the season (15,22).
at the same time, our model predicted very low numbers of lacv-positive mosquitoes, even in the native system (mean [median] yearly averages of 2.0% [1.6%] for the tree-hole model).
again, this finding is highly consistent with observed minimum field infection rates that range from 0.26 to 12.5 (14,23–26).
of note, predicted rates of infection among overwintering eggs were even lower than rates of infection among adult populations (mean [median] end-of-season infection rates of 0.63% [0.49%] for the tree-hole model.)
this finding reflects the fact that transovarial transmission is <100% and that overwintering eggs are laid later in the season, sometimes after peak lacv transmission has subsided.
again, predicted rates of egg infection strongly agree with field data indicating that 0.29%–0.6% of overwintering eggs from lacv-endemic sites yield lacv-positive larvae (26,27).
last, our predicted timing of peak risk for human disease was broadly consistent with observed cases of lacv disease in humans that tend to occur in late summer and early fall (8, 13).
what our dynamic model did not predict was any increase in lacv prevalence in the invaded system (tree-hole/tiger model) over that in the native system (tree-hole model).
even in systems in which lacv survived introduction of the tiger mosquito, the tiger mosquito tended to decrease lacv transmission.
for example, both the absolute number of infected mosquitoes and the rate of mosquito infection were lower in the tree-hole/tiger model than in the tree-hole model (table).
consistent with rates of mosquito infection, we found that rates of host seroprevalence were also lower when tiger mosquitoes were present.
table summary statistics for epidemiologic metrics of lacv, based on latin hypercube sampling analysis of the full dynamic model* variable tree-hole model tiger model tree-hole/tiger model† parameter sets with lacv persistence, % 46 0.20 24 end-of-season host seroprevalence rate, % mean 89 79 84 median 99 88 97 maximum 100 100 100 midseason host seroprevalence rate, % mean 65 12 18 median 74 8.9 12 maximum 100 38 98 peak no.
infected mosquitoes, per hectare mean 32 58 23 median 22 50 16 maximum 331 200 222 peak mosquito infection rate, % mean 4.5 1.6 1.9 median 3.5 1.5 1.3 maximum 27 5.3 15 average mosquito infection rate, % mean 2.0 0.44 0.80 median 1.6 0.33 0.57 maximum 13 1.8 6.8 maximum human transmission, infections per month per person per hectare mean 15 59 14 median 8.6 40 7.9 maximum 251 247 221 timing of peak human transmission mean aug 14 sep 21 aug 23 median aug 10 sep 28 aug 21 earliest jun 21 aug 26 jun 26 latest sep 30‡ sep 30‡ sep 30‡ end-of-season egg infection rates, % mean 0.63 0.08 0.28 median 0.49 0.07 0.20 maximum 5.0 0.32 2.2 *all metrics beyond the first row are only calculated for the subset of simulations that gave infected mosquitoes.
lavc, la crosse virus.
†we avoid reporting minimum values since these are likely to depend on the threshold that we selected for determining disease persistence (see lac dynamics, at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html).
‡in these systems, the abundance of infected mosquitoes was still increasing at the end of the season, indicating that infection rates do not slow before the decline in mosquitoes at the end of the summer.
although the tiger mosquito is a poor amplifying vector for lacv, it may still increase the number of human lacv infections.
indeed, because this species is an aggressive human biter, it has the potential to intensify the rate of disease transfer to human populations, albeit while simultaneously reducing disease spread in wildlife reservoirs (i.e., it may act as a bridge vector).
however, this potential is not realized (table).
although rates at which tiger mosquitoes bite humans (see basic model, at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html) partially compensated for lower rates of lacv transmission among wildlife reservoirs, this compensation was not complete.
thus, human infections were still predicted to occur more commonly in the native system (table; see also summary statistics for alternate scenarios at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html).
sensitivity analysis with partial rank correlation coefficients in 1-vector models, positive correlation with r0 was found for transmission rates, biting rates, mosquito survival rates, mosquito population growth rates, mosquito maturation rates, mosquito carrying capacity, and rates of lacv dissemination among mosquitoes (figure 4).
in contrast, rates of host recovery were negatively correlated with r0, as was host population size.
although this latter result is somewhat counterintuitive, it is well known for systems with a saturating functional response (28).
figure 4 partial rank correlation coefficients (prccs) showing the effect of each model parameter of la crosse virus transmission on the basic reproduction number (r0) in the tree-hole model (white), tiger model (black), and tree-hole/tiger model (gray).
positive prcc values indicate that r0 is positively correlated with a specific parameter, whereas negative prcc values indicate the opposite.
for specific prcc values and significance, see latin hypercube sampling and prcc, at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html.
in the 2-vector model, most prcc values were reduced but maintained the same sign.
this finding reflects the similar effect but lesser role of either mosquito species individually when both species are present.
not surprisingly, prcc reductions were more severe for the tiger mosquito, which is the less competent vector in the 2-vector system.
although most prcc values merely exhibited reductions in the 2-vector model, several underwent more striking changes.
first, the tiger mosquito population growth rate and the tiger mosquito carrying capacity switched from being positively correlated with r0 (strongly so in the case of carrying capacity) in the tiger model to being negatively correlated with r0 in the tree-hole/tiger model.
this switch occurs because tiger mosquitoes are generally detrimental to lacv spread in systems in which the native vector is also present, a conclusion that accords with our general finding that tiger mosquitoes should, if anything, reduce lacv transmission.
second, the population growth rate of the tree-hole mosquito actually became more strongly correlated with r0 when tiger mosquitoes were present.
the explanation is as follows.
in the tree-hole/tiger model, this parameter helps to influence the outcome of interspecific competition.
specifically, high tree-hole mosquito growth rates give this species an increased chance for survival against the more aggressive, generally more fecund, tiger mosquito population.
although prcc analyses can identify correlations between model parameters and disease outcomes, large prcc values additionally indicate model parameters that contribute a high degree of uncertainty to model predictions.
in the tree-hole/tiger model, the largest sources of uncertainty in r0 were the survival rate of tree-hole mosquitoes, the biting rate of tree-hole mosquitoes, and interspecific competition of tiger and tree-hole mosquitoes.
in the tree-hole model and the tiger model, the largest contributions to uncertainty were survival and biting rates but also vector carrying capacities.
discussion in contrast to previously published conclusions (29), our model suggests that lacv should be sustainable in 46%–60% of scenarios in which the tree-hole mosquito serves as the sole vector.
this conclusion still indicates a sizeable number of scenarios in which lacv transmission should not occur.
one interpretation is that lacv spread is only marginally favorable and that small changes in system characteristics (e.g., different mosquito or virus strains or environmental conditions) are sufficient to initiate or suppress disease transmission.
this marginal favorability could explain the patchy detection of lacv across its native range (9) and the sudden appearance of lacv at sites where it was previously absent.
the potential for variability in epidemiologic parameters raises the question of how to predict when and where lacv might emerge.
although measuring every system parameter at every local site is not feasible, our prcc analysis suggests that careful attention to vector survival, competition, biting rates, and carrying capacities would be beneficial.
one factor that does not explain the emergence of novel lacv foci is the invasion of tiger mosquitoes.
we predict that the invasive tiger mosquito should actually reduce disease transmission in wildlife reservoirs and human populations (even accounting for the fact that tiger mosquitoes are aggressive human biters).
thus, the presence of the invasive tiger mosquito does not sufficiently explain the dramatic increase in lacv disease cases in appalachia (8,12–14,30) (http://trace.tennessee.edu/utk_gradthes/1788/), suggesting that correlations between tiger mosquito invasion and the epidemiologic risk for lacv disease are driven by other, concomitant, changes.
in support of this conclusion is the absence of any increase in lacv disease prevalence in the midwest, despite the presence of a tiger mosquito infestation.
indeed, reported cases in the region have decreased (12), consistent with predictions from our model, but may also be independent of the arrival of tiger mosquitoes (see midwest lac cases, at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html).
having ruled out a straightforward contribution of invading tiger mosquitoes to lacv disease emergence, we consider the possibility that tiger mosquitoes are responsible for recent changes in lacv epidemiology.
one potential mechanism involves indirect effects on the native vector.
tree-hole mosquitoes that survive competition with tiger mosquitoes are generally larger and more competent lacv vectors (31), which could increase the likelihood of lacv transmission.
another possible mechanism is niche differentiation.
in general, mosquito competition is quantified by raising the larvae of competing species together in 1 container and then assessing growth metrics such as survival or maturation time.
although this approach enables estimation of direct competition, it does not capture spatial (32) or temporal niche partitioning that can decrease the strength of interspecific competition.
if tiger mosquitoes do not reduce the tree-hole population as severely as our model predicts, then their dampening effect on lacv transmission will, likewise, be diminished (see conditions under which tiger mosquitoes enable lac spread at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html).
last, our estimates for lacv transmission to and from tiger mosquitoes are based on 1 study that used an lacv strain predating establishment of the tiger mosquito in the united states (17).
given that transmission studies can be highly variable and that, since introduction of the tiger mosquito into the united states, local lacv strains may have adapted to be more suitable in this new host, it is also possible that our estimates for tiger mosquito competence are overly low (see conditions under which tiger mosquitoes enable lac spread, at http://www.clfs.umd.edu/biology/faganlab/disease-ecology.html).
recent evidence finding substantial infection rates in a tiger mosquito population in tennessee (33) supports this conclusion, although further transmission studies and analyses of virus evolution are warranted.
one final explanation for the recent emergence of lacv, and the explanation that we favor, is that our model predictions are correct and that other factors beyond tiger mosquitoes are responsible for the change.
a promising contender is the asian bush mosquito (ochlerotatus japonicus), hereafter referred to as the bush mosquito.
this mosquito is a second container-breeding invasive species that, like the tiger mosquito, seems to have arrived in north america in a shipment of tires (34).
because the bush mosquito was introduced more recently than the tiger mosquito (34), it has not been studied as extensively, particularly in the context of lacv.
nevertheless, laboratory work has demonstrated its competence as an lacv vector (35), and lacv has been isolated from field-collected pools of these mosquitoes (36).
the role of bush mosquitoes in lacv transmission may be studied by using a model similar to that presented here.
however, this study would require additional empirical work, including characterization of transovarial transmission by this species.
beyond the introduction of novel vectors, other changes (e.g., climatologic variables [4], human demographics [37], wildlife densities [38], and land use [https://vtechworks.lib.vt.edu/handle/10919/64932]) may also contribute to lacv emergence.
according to our prcc analysis, for example, small changes in adult mosquito survival rates could dramatically alter r0.
mosquito survival rates not only increase the equilibrium size of mosquito populations but also increase the likelihood of mosquitoes surviving to their second or third blood meals, which is necessary for horizontal lacv transmission.
decreases in mosquito predators, varying from birds to spiders (38–41), could thus strongly affect lacv prevalence.
our prcc analysis also indicates that mosquito carrying capacities have a substantial effect on lacv persistence.
consequently, even small increases in container availability (e.g., new tire yards or unemptied backyard planters) should have dramatic effects on lacv disease incidence rates.
last, substantial growth has occurred in southern appalachia over the past 30 years (37); thus, even without increased enzootic transmission, absolute cases may have increased from population growth alone.
although purely speculative, such habitat and demographic changes may be the true cause of the recent emergence of lacv.
that tiger mosquito invasion is not predicted to increase lacv transmission or even human cases highlights an important issue at the interface between disease ecology and invasion biology.
in particular, this finding shows that predicting whether an invasive vector will exacerbate or dampen the spread of a disease can be complex and can depend on an elaborate network of species interactions.
although this network includes obvious disease interactions like horizontal and vertical transmission, it also includes ecologic interactions that may be relatively independent of the disease itself.
in the lacv system, for example, competition between native tree-hole mosquitoes and invasive tiger mosquitoes strongly influences whether or not lacv persists (figure 4).
indeed, as a consequence of this competition, tiger mosquitoes can drive local extinction of lacv, despite the fact that tiger mosquitoes can acquire and transmit the virus, making them seem to be competent vectors.
because of the complexity of disease transmission in ecologic systems, it is often hard to identify the causes of altered disease epidemiology.
however, faced with increasing climate and landscape change, ongoing introduction of novel invasive species (pathogens and vectors), and emerging or reemerging diseases, an understanding of the effects of these different forms of global change on disease dynamics is essential.
we have moved toward this goal by developing a framework for investigating the role of invasive vectors on the transmission of a native disease.
using lacv as an example, our model highlights the fact that the introduction of a new disease vector does not guarantee increased disease transmission and, in fact, can even drive local extinction of an endemic pathogen.
@highlight
emergence may involve invasive mosquitoes other than asian tiger mosquitoes, climate change, and changes in wildlife densities.
