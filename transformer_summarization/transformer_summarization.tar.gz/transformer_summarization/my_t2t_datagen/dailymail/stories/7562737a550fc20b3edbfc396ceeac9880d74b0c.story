the four epidemiological forms of kaposi’s sarcoma aids-associated kaposi’s sarcoma kaposi’s sarcoma (ks) is a multi-focal, angioproliferative neoplasm that usually appears on the skin, but can also involve the visceral organs.
in 1981, 26 cases of ks were reported as occurring in young homosexual men in new york and california.
many of these patients also had concomitant pneumocystis carinii pneumonia (pcp) and a variety of other “opportunistic infections” [1].
at that time, the underlying cause of aids was unknown, but, remarkably, one-third of these patients developed a disseminated form of ks.
in 1983, it was postulated that ks was driven by the host’s profoundly immunocompromised state.
interestingly, 95% of these cases had occurred in homosexual men.
furthermore, it appeared that the clinical presentation of aids-associated ks (aids-ks) differed significantly from previously described clinical variants of this unusual neoplasm [2].
in these immunocompromised patients, ks behaved more aggressively, often involving mucosal tissues, and progressed to visceral involvement leading to organ dysfunction and death [3].
in the early 1980s, a significant proportion of homosexual men with aids were affected by ks; for example, in san francisco, this opportunistic neoplasm occurred in 40% of homosexual men with aids.
this suggested that a major risk factor for ks might be homosexual intercourse [4].
in fact, several early studies showed a connection between the number of sexual partners and the prevalence of ks.
for example, in vancouver, 56% of homosexual men with aids and more than 20 partners developed ks [5].
as the widespread use of highly active antiretroviral therapy (haart) gained popularity in the early and mid-1990s, an 8.8% annual decline from 1990 to 1998 in ks incidence in the united states was observed, along with a 50% reduction in ks incidence among those on triple antiretroviral therapy [6].
a cancer surveillance program in san francisco revealed similar patterns, with the incidence of ks in 1973 (prior to the aids epidemic) at 0.5 cases per 100,000 people, while during the peak of the aids epidemic in 1991, this number was 33.3 cases per 100,000 people and then declined in 1998 (post-haart) to 2.8 cases per 100,000 people [7].
the classic form in 1872, moritz kaposi first described the “classic” variant of ks that is typically observed in elderly men of mediterranean or eastern european origin [8].
this form of ks generally presents with lesions confined to the lower extremity, affects men more commonly than women in a 15:1 ratio, and is usually indolent with patients living 10 years or more [9].
the incidence of ks in the mediterranean is significantly higher than in the rest of europe and the united states.
for example, prior to the aids epidemic, there was a two- to threefold higher prevalence of ks among the italian population compared to that of the usa, and a ten times greater prevalence compared to england [10].
the endemic form in the 1950s, an endemic form of ks was reported to be one of the most common neoplasms observed in central africa, affecting men, women and children [11].
notably, following the aids epidemic, the incidence of ks in africa increased markedly, and from 1968 to 1970, ks accounted for 6.6% of all cancers occurring in men; however, from 1989 to 1991, ks became the most commonly reported cancer occurring in men (48.6% of male cancer patients), while the prevalence in female cancer patients rose to 17.9% [12].
the iatrogenic form in the 1970s, an “iatrogenic” form of ks was also observed among organ transplant recipients, as well as other patients on long-term immunosuppression for other diseases [2].
recently, there have been a growing number of cases of this iatrogenic variant of ks.
for example, there are an increasing number of reports in the literature describing individuals who develop ks arising in the context of long-term corticosteroid therapy and other biologic therapies, including rituximab, infliximab, and abatacept administered for chronic inflammatory and autoimmune conditions, including autoimmune thrombocytopenia, polyangiitis and pemphigus vulgaris [13–15].
the occurrence of ks in such patients frequently resolves spontaneously when the immunosuppressive therapies are discontinued [16].
as the increasing use of these immunomodulatory medications becomes more widespread, it is important to be aware of the possibility of ks occurring among these individuals who previously had not been considered “high-risk”.
new attention has been focused on the increased occurrence of ks among patients who are significantly immunosuppressed following organ transplantation.
in fact, the incidence of ks is 400–500 times higher among such patients than the general population [17].
this may be due to reactivation of latent hhv-8 virus or perhaps through acquisition of the virus from the donor organ [18].
however, certain immunosuppressants may be less likely to put patients at risk for iatrogenic ks.
for example, sirolimus or everolimus (mtor inhibitors) appear to inhibit the occurrence and/or progression of ks in transplant recipients while preventing organ rejection [19, 20].
these drugs may reduce the effect of vascular endothelial growth factor (vegf) which is believed to play a pivotal role in the pathogenesis of ks [20].
therefore, clinicians need to be aware of the oncogenic potential of immunosuppressive therapy in these organ transplant recipients.
pathogenesis for many years, the cause of ks was initially perplexing, with the occurrence of ks in patients such as those on long-term immunosuppressant therapy strongly suggesting the possibility that this neoplasm might be related to a transmissible agent.
interestingly, in the 1990s, there were also case reports of ks occurring in gay or bisexual hiv-negative immunocompetent individuals, supporting the hypothesis that ks was a neoplasm that could be due to a sexually transmitted infection occurring within that community [21].
it still remains unclear exactly why ks is almost exclusively observed in homosexual aids patients, and is very rarely if ever observed in iv drug users, or in individuals receiving blood products through transfusions, such as hemophiliacs.
perhaps the pathogenesis of ks may be hormone-dependent, which would account for the predominance in males and for the observation that ks is transferred between men through homosexual intercourse more commonly than from a male to a female partner through heterosexual intercourse [22].
in 1996, a newly discovered virus was found to be associated with every specimen of ks examined.
kaposi’s sarcoma-associated herpesvirus (kshv), now known as human herpesvirus-8 (hhv8), was sequenced and identified as the infectious agent previously associated with ks among different populations, including individuals in eastern europe, africa and the united states [23].
since this discovery, new research has shed light on the molecular mechanisms of ks.
the lesions found in ks are known to contain several cell types, such as infiltrating inflammatory cells, endothelium and spindle cells, which have been postulated to derive from either vascular or lymphatic precursors.
one paper has shown a monoclonal antibody that stains specifically for lymphatic endothelium and also stains spindle cells from ks lesions, suggesting that the tumor cell of ks may be of lymphatic origin [24].
moreover, spindle cell viability is likely dependent on the tumor milieu, which in ks consists of elevated levels of growth factors and cytokines, such as interleukin (il)-1, il-6, platelet-derived growth factor, tumor necrosis factor, ifn-gamma, and vegf [25].
in hiv-infected individuals, th1-type cytokines have been suggested to potentiate kshv activation, which can lead to an increased viral load and a greater likelihood of the development of ks [26].
also, hiv-1-associated trans-activating regulatory (tat) protein is needed for replication of the hiv virus and is also released from acutely infected t cells.
this protein may induce ks by stimulating proangiogenic chemokines, and by enhancing ks cell growth by synergizing with basic fibroblast growth factor (bfgf), which is an essential factor for lesion formation [3].
this may account for the more aggressive behavior of ks lesions in hiv-infected individuals compared to the classic variant [27].
however, the tat protein is only able to interact with endothelial cells through a rgd motif, which is absent in hiv-2.
this may explain why ks is less commonly found in individuals with hiv-2 compared to hiv-1 infection [28].
treatment a variety of treatment options are available for the classic variant of ks.
since these lesions often recur, but are less often life-threatening, one viable treatment strategy is recurrent use of local cryotherapy which typically resolves the isolated lesions [29].
another well-described approach is the use of intralesional chemotherapeutics such as vincristine which are also efficacious [30].
for patients with extensive disease and/or widespread rapidly progressive disease, it may be necessary to resort to more generalized therapies.
pegylated liposomal doxorubicin has been used as a first-line treatment, with a favorable 71% response rate, and is significantly better tolerated than traditional chemotherapeutics [31, 32].
another option is the use of localized radiation to the lower extremity which has shown a high rate of resolution to the affected fields [33].
kaposi’s sarcoma occurring in patients on significant immunosuppression will resolve in the majority of patients when the immunosuppressive therapy is altered, reduced or discontinued.
commonly, when ks arises in renal transplant recipients, a decrease in the level of immunosuppression is a first reasonable strategy [34].
when this does not promote resolution of the disease, or begins to compromise graft viability, some patients may benefit from transition of typical calcineurin inhibitors such as cyclosporine to proliferation signal inhibitors such as sirolimus, which often results in complete resolution of active ks without rejection of the graft [20].
the mainstay of treatment for aids-related ks involves the initiation of haart, which typically results in a subsequent decrease in tumor burden as the cd4 count rises and is able to adequately suppress the hhv8 virus.
interestingly, a subset of these patients may experience a progression of their disease following initiation of haart in an immune reconstitution inflammatory syndrome (iris) [35, 36].
typically, these patients are able to continue therapy, but in some cases adjuvant chemotherapy may be required to control the tumor burden.
compliance with ethics guidelines this article is based on previously conducted studies and does not involve any new studies of human or animal subjects performed by any of the authors.
@highlight
kaposi’s sarcoma is an angioproliferative neoplasm which has undergone considerable epidemiologic change since the original description by moritz kaposi in the late 1800s.
this opportunistic neoplasm gained widespread notoriety within the us during the height of the aids epidemic, where it was frequently found co-occurring with opportunistic infections.
with the advent of modern antiretroviral therapies, as well as an increasing number of individuals on immunosuppression for autoimmune disease or organ transplantation, the landscape of the immunocompromised individual has changed.
it is now important for clinicians to be mindful of kaposi’s sarcoma manifesting in a growing variety of clinical contexts.
