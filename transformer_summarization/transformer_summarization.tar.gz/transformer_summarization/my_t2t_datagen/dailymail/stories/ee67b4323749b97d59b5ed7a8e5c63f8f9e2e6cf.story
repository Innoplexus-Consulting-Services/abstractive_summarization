introduction the mediterranean bryozoan fauna represents about 9.6% of the known global diversity of bryozoa (rosso and di martino 2016).
however, current knowledge on the bryozoan fauna of this basin is highly biased due to differences in research effort for different taxa, marine areas and habitat types.
recent efforts in the south-eastern mediterranean sea have significantly increased our knowledge from areas which were previously considered “data-poor” spots for bryozoans, revealing a considerable proportion of non-indigenous taxa (e.g.
harmelin et al.
2016, sokolover et al.
2016).
furthermore, information on bryozoa from several mediterranean areas is fragmented in old publications and grey literature; the collation of updated checklists (e.g.
koçak and aydın önen 2014) by experts could contribute to the mapping of diversity for understudied taxa and areas (bailly et al.
2016, this special collection).
sporadic records of bryozoans from the aegean sea can be found in old taxonomic studies, including the descriptions of the cheilostome species calpensia nobilis, hippaliosina depressa and watersipora cucullata from this marine region (busk 1854), based on material collected from shallow water macroalgae by e. forbes.
the first studies focusing on bryozoa of the eastern mediterranean basin, the greek seas included, took place in the late 1960s (harmelin 1969), based on material that was collected with dredges during the oceanographic expedition of the french research vessel “jean charcot” (1968).
a total of 101 species belonging to all the 3 living bryozoan orders, were found, including several new records for the mediterranean fauna.
later, the taxonomic study by hayward (1974) on the cheilostome bryozoa of chios island (north-eastern aegean) yielded 101 species, including rare records and new species.
sharing only 47 cheilostomes with harmelin’s list mentioned above, this study increased the eastern mediterranean bryozoan diversity by 54 species.
more recently, few taxonomic and ecological studies have focused on the bryozoan fauna of greece (e.g.
castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, castritsi-catharios et al.
1985a, castritsi-catharios et al.
1985b, castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b, castritsi-catharios and ganias 1989, ganias 1990), while a considerable number of records has been included in general ecological studies examining a variety of habitats (e.g.
simboura et al.
1995, conides et al.
1999, morri et al.
1999, antoniadou and chintiroglou 2005, gerovasileiou et al.
2013, gerovasileiou et al.
2015).
a complete checklist of bryozoa however had never been published from greece.
the aim of the present study is to give a first annotated checklist of bryozoa from the greek seas.
materials and methods the checklist presented in this paper was compiled in the framework of the greek taxon information system (gtis), an initiative of the lifewatchgreece research e-infrastructure aiming to produce a complete inventory of the known biodiversity of greece (bailly et al.
2016, this special collection).
as this is the first attempt to compile a checklist of bryozoan diversity of the greek seas, we performed an exhaustive literature review of bryozoan records.
all taxa were cross-checked for synonymies and dubious records against the world list of bryozoa (recent and fossil), the world register of marine species (bock and gordon 2016, worms editorial board 2016), and the recent update of the mediterranean bryozoan diversity by rosso and di martino (2016).
taxa identified as cf., as well as those left in open nomenclature, and fossil records were not included in the list.
the checklist is annotated with the literature references reporting the presence of each species from greek waters, as well as with notes on the nomenclature of some taxa.
non-indigenous bryozoans are also marked (nib).
the checklist follows the alphabetical order.
checklists checklist of bryozoa known to occur in the greek seas gymnolaemata allman, 1856 cheilostomatida busk, 1852 adeonidae busk, 1884 adeonella busk, 1884 adeonella calveti (canu & bassler, 1930) notes gautier 1962 adeonella pallasii (heller, 1867) notes castritsi-catharios et al.
1985a, castritsi-catharios et al.
1985b, castritsi-catharios et al.
1986a, ganias 1990, rosso and novosel 2010, chimenz gusso et al.
2014, gerovasileiou et al.
2015​ reptadeonella busk, 1884 reptadeonella violacea (johnston, 1847) notes harmelin 1969, hayward 1974, castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios and kiortis 1984, castritsi-catharios et al.
1986a (as reptoporellina, probably a mispelling), ganias 1990, morri et al.
1999, antoniadou and chintiroglou 2005 aeteidae smitt, 1868 aetea lamouroux, 1812 aetea anguina (linnaeus, 1758) notes harmelin 1969, hayward 1974, castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, ganias 1990 aetea lepadiformis waters, 1906 notes ganias 1990, morri et al.
1999 aetea sica (couch, 1844) notes harmelin 1969, hayward 1974, castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, castritsi-catharios et al.
1985a, castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b, castritsi-catharios and ganias 1989, ganias 1990, morri et al.
1999 aetea truncata (landsborough, 1852) notes harmelin 1969, hayward 1974, castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, castritsi-catharios et al.
1985a, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990, morri et al.
1999 antroporidae vigneaux, 1949 rosseliana jullien, 1888 rosseliana rosselii (audouin, 1826) notes harmelin 1969, ganias 1990 beaniidae canu & bassler, 1927 beania johnston, 1840 beania cylindrica (hincks, 1886) notes ​harmelin 1969, ganias 1990, morri et al.
1999 beania hirtissima (heller, 1867) notes harmelin 1969, hayward 1974, castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios and kiortis 1984, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990, simboura et al.
1995, morri et al.
1999 beania magellanica (busk, 1852) notes harmelin 1969, hayward 1974, castritsi-catharios and kiortis 1984, castritsi-catharios and ganias 1989, ganias 1990 beania mirabilis johnston, 1840 notes ​hayward 1974, castritsi-catharios and ganias 1989, ganias 1990 bitectiporidae macgillivray, 1895 metroperiella canu & bassler, 1917 metroperiella lepralioides (calvet, 1903) notes harmelin 1969, hayward 1974, ganias 1990, morri et al.
1999 pentapora fischer, 1807 pentapora fascialis (pallas, 1766) notes ganias 1990, antoniadou and chintiroglou 2005, chimenz gusso et al.
2014 schizomavella canu & bassler, 1917 ﻿sc﻿hiz﻿omav﻿ella rudis ﻿(manzoni, 1869﻿) notes in the absence of type material, the validity of s. rudis has been questioned by reverter-gil et al.
(2012).
two new species, stephanotheca watersi reverter-gil, souto & fernandez-pulpeiro, 2012 and schizomavella adriatica reverter-gil, souto, novosel & tilbrook, 2016 have been erected to allocate some records from the western basin and the adriatic, respectively.
nevertheless, records and material from the aegean were not considered and hence they are provisionally still reported as s. rudis (see also rosso and di martino 2016).
schizomavella (calvetomavella) discoidea (busk, 1859) notes harmelin 1969, hayward 1974, morri et al.
1999; the status of these records needs to be checked (see rosso and di martino 2016​).
schizomavella (schizomavella) asymetrica (calvet, 1927) schizomavella (schizomavella) asymetrica synonym valid for calyptotheca triarmata hayward, 1974 (see rosso et al.
2010​).
notes hayward 1974 schizomavella (schizomavella) cornuta (heller, 1867) notes harmelin 1969, hayward 1974, castritsi-catharios and ganias 1989, ganias 1990, simboura et al.
1995, morri et al.
1999; mediterranean colonies recorded as s. auriculata, s. auriculata cuspidata and s. cuspidata possibly belong to this species.
schizomavella (schizomavella) hastata (hincks, 1862) notes morri et al.
1999​ schizomavella (schizomavella) linearis (hassall, 1841) notes gautier 1962, harmelin 1969, hayward 1974, castritsi-catharios et al.
1985a, ganias 1990 schizomavella (schizomavella) mamillata (hincks, 1880) schizomavella linearis mamillata notes gautier 1962, harmelin 1969, hayward 1974, morri et al.
1999 bryocryptellidae vigneaux, 1949 bryocryptella cossmann, 1906 bryocryptella tubulata (busk, 1861) notes harmelin 1969​ palmiskenea bishop & hayward, 1989 palmiskenea gautieri madurell, zabala, domínguez-carrió & gili, 2013 notes harmelin 1969, castritsi-catharios et al.
1985a (as palmiskenea aff.
aviculifera), castritsi-catharios et al.
1986a.
these records have been provisionally reported as p. gautieri following madurell et al.
(2013) and rosso and di martino (2016).
palmiskenea skenei (ellis & solander, 1786) notes ganias 1990​ porella gray, 1848 porella concinna (busk, 1854) notes harmelin 1969​ porella minuta (norman, 1868) notes harmelin 1969​ bugulidae gray, 1848 bicellariella levinsen, 1909 bicellariella ciliata (linnaeus, 1758) notes antoniadou and chintiroglou 2005 bugula oken, 1815 bugula calathus (norman, 1868) notes hayward 1974 bugula neritina (linnaeus, 1758) distribution nib notes castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, castritsi-catharios and ganias 1989 bugulina gray, 1848 bugulina avicularia (linnaeus, 1758) notes ganias 1990 bugulina fulva (ryland, 1960) distribution nib notes morri et al.
1999 bugulina simplex (hincks, 1886) notes castritsi-catharios and kiortis 1984 bugulina spicata (hincks, 1886) notes castritsi-catharios and marcopoulou-diacantoni 1983 bugulina stolonifera (ryland, 1960) notes castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, ganias 1990, antoniadou and chintiroglou 2005 bugulina turbinata (alder, 1857) notes ​castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985 crisularia gray, 1848 crisularia aperta (hincks, 1886) notes castritsi-catharios and marcopoulou-diacantoni 1983 crisularia plumosa (pallas, 1766) distribution nib notes hayward 1974 crisularia serrata (lamarck, 1816) distribution nib notes harmelin 1969, ganias 1990 calloporidae norman, 1903 alderina norman, 1903 alderina imbellis (hincks, 1860) notes hayward 1974 aplousina canu & bassler, 1927 aplousina capriensis (waters, 1898) notes hayward 1974 callopora gray, 1848 callopora dumerilii (audouin, 1826) notes hayward 1974, ganias 1990 callopora lineata (linnaeus, 1767) notes harmelin 1969, ganias 1990 copidozoum harmer, 1926 copidozoum planum (hincks, 1880) notes hayward 1974, castritsi-catharios et al.
1986b, castritsi-catharios and ganias 1989, ganias 1990 copidozoum tenuirostre (hincks, 1880) notes hayward 1974, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990 corbulella gordon, 1984 corbulella maderensis (waters, 1898) notes hayward 1974, ganias 1990, morri et al.
1999 crassimarginatella canu, 1900 crassimarginatella crassimarginata (hincks, 1880) notes gautier 1962 crassimarginatella solidula (hincks, 1860) notes ganias 1990 ellisina norman, 1903 ellisina gautieri fernandez pulpeiro & reverter gil, 1993 notes ​ganias 1990 parellisina osburn, 1940 parellisina curvirostris (hincks, 1862) notes harmelin 1969, hayward 1974, ganias 1990 retevirgula brown, 1948 retevirgula akdenizae chimenz, nicoletti & lippi boncambi, 1997 notes morri et al.
1999 candidae d'orbigny, 1851 caberea lamouroux, 1816 caberea boryi (audouin, 1826) notes harmelin 1969, hayward 1974, ganias 1990, morri et al.
1999, simboura et al.
1995 cradoscrupocellaria vieira, spencer jones & winston, 2013 cradoscrupocellaria bertholletii (audouin, 1826) notes hayward 1974, ganias 1990 cradoscrupocellaria macrorhyncha (gautier, 1962) notes harmelin 1969, hayward 1974 scrupocaberea vieira, spencer jones, winston, migotto & marques, 2014 scrupocaberea maderensis (busk, 1860) notes castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b, castritsi-catharios and ganias 1989, ganias 1990 scrupocellaria van beneden, 1845 scrupocellaria aegeensis harmelin, 1969 notes harmelin 1969, ganias 1990 scrupocellaria delilii (audouin, 1826) notes harmelin 1969, ganias 1990, morri et al.
1999 scrupocellaria incurvata waters, 1897 notes harmelin 1969, ganias 1990 scrupocellaria muricata (lamouroux, 1816) notes castritsi-catharios and kiortis 1984, castritsi-catharios et al.
1986a scrupocellaria scrupea busk, 1852 notes gautier 1962, harmelin 1969, hayward 1974, castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, castritsi-catharios et al.
1986a, ganias 1990, simboura et al.
1995, morri et al.
1999 scrupocellaria scruposa (linnaeus, 1758) distribution nib notes hayward 1974, ganias 1990, simboura et al.
1995, morri et al.
1999 cellariidae fleming, 1828 cellaria ellis & solander, 1786 cellaria fistulosa (linnaeus, 1758) notes ganias 1990 cellaria normani (hastings, 1947) notes harmelin 1969 cellaria salicornioides lamouroux, 1816 notes hayward 1974, castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, ganias 1990 celleporidae johnston, 1838 buskea heller, 1867 buskea dichotoma (hincks, 1862) notes ganias 1990 buskea nitida heller, 1867 notes harmelin 1969 cellepora linnaeus, 1767 cellepora posidoniae (hayward, 1975) notes ganias 1990 cellepora pumicosa (pallas, 1766) notes morri et al.
1999 celleporina gray, 1848 celleporina caminata (waters, 1879) notes gautier 1962, harmelin 1969, hayward 1974, castritsi-catharios and kiortis 1984, castritsi-catharios et al.
1985a, castritsi-catharios et al.
1986a, ganias 1990, morri et al.
1999 celleporina hassallii (johnston, 1847) notes ​castritsi-catharios and kiortis 1984 (as cellepora hassalli), castritsi-catharios et al.
1985a, castritsi-catharios et al.
1985b, castritsi-catharios et al.
1986a, ganias 1990, simboura et al.
1995, morri et al.
1999 celleporina lucida (hincks, 1880) notes morri et al.
1999 celleporina tubulosa (hincks, 1880) notes harmelin 1969, morri et al.
1999 palmicellaria alder, 1864 palmicellaria elegans alder, 1864 notes harmelin 1969, ganias 1990 turbicellepora ryland, 1963 turbicellepora avicularis (hincks, 1860) notes ganias 1990 turbicellepora camera hayward, 1978 notes hayward 1978, ganias 1990, morri et al.
1999 turbicellepora coronopus (wood, 1844) notes hayward 1974, ganias 1990, gerovasileiou et al.
2015 turbicellepora crenulata hayward, 1978 notes ganias 1990 turbicellepora magnicostata (barroso, 1919) notes ganias 1990 chlidoniidae busk, 1884 chlidonia lamouroux, 1824 chlidonia pyriformis (bertoloni, 1810) notes ​harmelin 1969, hayward 1974, castritsi-catharios and kiortis 1984, castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b, ganias 1990, morri et al.
1999 chorizoporidae vigneaux, 1949 chorizopora hincks, 1879 chorizopora brongniartii (audouin, 1826) notes ​gautier 1962, harmelin 1969, hayward 1974, castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios and kiortis 1984, castritsi-catharios et al.
1985a, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990, simboura et al.
1995, morri et al.
1999, antoniadou and chintiroglou 2005 colatooeciidae winston, 2005 trematooecia osburn, 1940 trematooecia ligulata ayari & taylor, 2008 notes harmelin 1969 (as cigclisula turrita) crepidacanthidae levinsen, 1909 crepidacantha levinsen, 1909 crepidacantha poissonii (audouin, 1826) distribution nib notes ganias 1990​ cribrilinidae hincks, 1879 collarina jullien, 1886 collarina balzaci (audouin, 1826) notes ​hayward 1974, castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990 figularia jullien, 1886 figularia figularis (johnston, 1847) notes ​harmelin 1969, hayward 1974, ganias 1990 puellina jullien, 1886 puellina (cribrilaria) innominata (couch, 1844) notes harmelin 1969, hayward 1974, castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b, castritsi-catharios and ganias 1989, ganias 1990 puellina (cribrilaria) hincksi (friedl, 1917) notes gautier 1962, morri et al.
1999 puellina (cribrilaria) radiata (moll, 1803) notes ​harmelin 1969, hayward 1974, castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990, simboura et al.
1995, morri et al.
1999 puellina (cribrilaria) venusta (canu & bassler, 1925) notes ganias 1990 puellina (glabrilaria) orientalis harmelin & aristegui, 1987 notes ​morri et al.
1999 puellina (glabrilaria) pedunculata (gautier, 1956) notes harmelin 1969, hayward 1974 puellina (puellina) gattyae (landsborough, 1852) notes ​gautier 1962, hayward 1974, castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios and kiortis 1984, castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b, castritsi-catharios and ganias 1989, ganias 1990, morri et al.
1999 puellina (puellina) setosa (waters, 1899) notes harmelin 1969, ganias 1990, morri et al.
1999 cryptosulidae vigneaux, 1949 cryptosula canu & bassler, 1925 cryptosula pallasiana (moll, 1803) notes hayward 1974, castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios et al.
1985a, castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b, ganias 1990, antoniadou and chintiroglou 2005 electridae d'orbigny, 1851 conopeum gray, 1848 conopeum seurati (canu, 1928) notes ganias 1990 electra lamouroux, 1816 electra pilosa (linnaeus, 1767) notes castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990, antoniadou and chintiroglou 2005 electra posidoniae gautier, 1954 notes hayward 1974, castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, castritsi-catharios et al.
1985a, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990 epistomiidae gregory, 1893 synnotum pieper, 1881 synnotum aegyptiacum (audouin, 1826) notes ​harmelin 1969, hayward 1974, ganias 1990 escharinidae tilbrook, 2006 escharina milne edwards, 1836 escharina dutertrei protecta zabala, maluquer & harmelin, 1993 notes ​harmelin 1969, hayward 1974, morri et al.
1999 escharina johnstoni (quelch, 1884) notes ganias 1990 escharina vulgaris (moll, 1803) notes harmelin 1969, hayward 1974, castritsi-catharios et al.
1986a (as schizoporella vulgaris), castritsi-catharios et al.
1986b (as s. vulgaris), ganias 1990, ​morri et al.
1999 herentia gray, 1848 herentia hyndmanni (johnston, 1847) notes harmelin 1969, morri et al.
1999 hippomenella canu & bassler, 1917 hippomenella mucronelliformis (waters, 1899) notes harmelin 1969, hayward 1974, ganias 1990 therenia david & pouyet, 1978 therenia rosei berning, tilbrook & rosso, 2008 notes ​hayward 1974 (as escharina porosa), ganias 1990 (as e. porosa), berning et al.
2008 exechonellidae harmer, 1957 anarthropora smitt, 1868 anarthropora monodon (busk, 1860) notes ﻿﻿harmelin 1969, hayward 1974, ganias 1990, morri et al.
1999 exechonella duvergier, 1924 exechonella antillea (osburn, 1927) distribution nib notes hayward 1974 exochellidae bassler, 1935 escharoides milne edwards, 1836 escharoides ﻿coccinea﻿ (abildgaard, 1806) notes harmelin 1969, hayward 1974, castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios and kiortis 1984 (as cellepora coccinea), castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990, morri et al.
1999​, antoniadou and chintiroglou 2005 flustridae fleming, 1828 chartella gray, 1848 chartella papyrea (pallas, 1766) notes hayward 1974 gregarinidra barroso, 1949 gregarinidra gregaria (heller, 1867) notes ​harmelin 1969, hayward 1974, castritsi-catharios and kiortis 1984 hincksina norman, 1903 hincksina flustroides (hincks, 1877) notes ​hayward 1974, ganias 1990, morri et al.
1999 haplopomidae gordon in de blauwe, 2009 haplopoma levinsen, 1909 haplopoma impressum (audouin, 1826) notes ​harmelin 1969, hayward 1974, ganias 1990, morri et al.
1999 hippaliosinidae winston, 2005 hippaliosina canu, 1919 hippaliosina depressa (busk, 1854) notes busk 1854, harmelin 1969, hayward 1974, castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios et al.
1985a, castritsi-catharios et al.
1985b, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990, morri et al.
1999, gerovasileiou et al.
2013, gerovasileiou et al.
2015 hippopodinidae levinsen, 1909 hippopodina levinsen, 1909 hippopodina ambita (hayward, 1974) notes ​harmelin 1969 (as cosciniopsis sp.
), hayward 1974, ganias 1990 hippopodina feegeensis (busk, 1884) distribution nib notes morri et al.
1999 hippoporidridae vigneaux, 1949 hagiosynodos bishop & hayward, 1989 hagiosynodos latus (busk, 1856) notes ​hayward 1974, ganias 1990, morri et al.
1999 hippoporidra canu & bassler, 1927 hippoporidra picardi gautier, 1962 notes gautier 1962, morri et al.
1999 hippothoidae busk, 1859 hippothoa lamouroux, 1821 hippothoa flagellum manzoni, 1870 notes ganias 1990 lacernidae jullien, 1888 arthropoma levinsen, 1909 arthropoma cecilii (audouin, 1826) notes hayward 1974, ganias 1990 lanceoporidae harmer, 1957 calyptotheca harmer, 1957 calyptotheca rugosa hayward, 1974 notes hayward 1974, ganias 1990 margarettidae harmer, 1957 margaretta gray, 1843 margaretta cereoides (ellis & solander, 1786) notes harmelin 1969, hayward 1974, castritsi-catharios et al.
1985a, ganias 1990 microporellidae hincks, 1879 diporula hincks, 1879 diporula verrucosa (peach, 1868) notes harmelin 1969, ganias 1990 fenestrulina jullien, 1888 fenestrulina malusii (audouin, 1826) notes harmelin 1969, hayward 1974, castritsi-catharios et al.
1986b, castritsi-catharios and ganias 1989, ganias 1990, morri et al.
1999 microporella hincks, 1877 microporella coronata (audouin, 1826) distribution nib notes harmelin et al.
(2011) suggested that specimens from the aegean sea reported as microporella orientalis could belong to m. coronata (followed by rosso and di martino 2016).
recorded by hayward 1974, morri et al.
1999. microporella ciliata (pallas, 1766) notes this taxon corresponds to a complex of species (rosso et al.
2010, rosso and di martino 2016).
recorded by harmelin 1969, castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios et al.
1986a, ganias 1990, antoniadou and chintiroglou 2005. microporella marsupiata (busk, 1860) notes hayward 1974 microporidae gray, 1848 calpensia jullien, 1888 calpensia nobilis (esper, 1796) notes busk 1854, hayward 1974, castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, castritsi-catharios and ganias 1989, ganias 1990, morri et al.
1999 coronellina prenant & bobin, 1966 coronellina fagei (gautier, 1962) notes harmelin 1969, hayward 1974 micropora gray, 1848 micropora coriacea (johnston, 1847) notes hayward 1974, ganias 1990 mollia lamouroux, 1821 mollia multijuncta (waters, 1879) notes hayward 1974, morri et al.
1999 mollia patellaria (moll, 1803) notes gautier 1962, harmelin 1969, hayward 1974, ganias 1990, morri et al.
1999 monoporellidae hincks, 1882 monoporella hincks, 1881 monoporella bouchardii (audouin, 1826) notes mediterranean specimens of monoporella nodulifera and m. fimbriata carinifera actually belong to this species, as suggested by harmelin (2014a) and followed by rosso and di martino (2016).
recorded by harmelin 1969, hayward 1974, ganias 1990, morri et al.
1999. myriaporidae gray, 1841 myriapora de blainville, 1830 myriapora truncata (pallas, 1766) notes ​harmelin 1969, hayward 1974, morri et al.
1999, gerovasileiou et al.
2015 onychocellidae jullien, 1882 onychocella jullien, 1882 onychocella angulosa (reuss, 1847) notes hayward 1974, ganias 1990 onychocella marioni (jullien, 1881) notes ​harmelin 1969, morri et al.
1999, gerovasileiou et al.
2015 onychocella vibraculifera neviani, 1895 notes ​hayward 1974, castritsi-catharios and marcopoulou-diacantoni 1983, ganias 1990 smittipora jullien, 1882 smittipora disjuncta (canu & bassler, 1930) smittipora is a synonym of rectonychocella (see rosso and di martino 2016​).
notes harmelin 1969, hayward 1974, ganias 1990 phidoloporidae gabb & horn, 1862 dentiporella barroso, 1926 dentiporella sardonica (waters, 1879) notes gautier 1962, harmelin 1969 plesiocleidochasma soule, soule & chaney, 1991 plesiocleidochasma mediterraneum chimenz-gusso & soule, 2003 notes harmelin 1969 (as cleidochasma sp.
), hayward 1974 (as cleidochasma porcellanum) reteporella busk, 1884 reteporella complanata (waters, 1894) notes ganias 1990 reteporella couchii (hincks, 1878) notes harmelin 1969, ganias 1990 reteporella grimaldii (jullien & calvet, 1903) reteporella grimaldii synonym valid for r. septentrionalis (see rosso et al.
2010​).
notes ​hayward 1974, ganias 1990, morri et al.
1999, antoniadou and chintiroglou 2005, chimenz gusso et al.
2014 reteporella mediterranea (hass, 1948) notes hayward 1974, ganias 1990 reteporellina harmer, 1933 reteporellina delicatula hayward, 1974 notes hayward 1974, harmelin 1976, ganias 1990 rhynchozoon hincks, 1895 rhynchozoon bispinosum (johnston, 1847) notes hayward 1974, ganias 1990 rhynchozoon neapolitanum gautier, 1962 notes ​harmelin 1969, hayward 1974, ganias 1990, morri et al.
1999, gerovasileiou et al.
2015 rhynchozoon pseudodigitatum zabala & maluquer, 1988 notes morri et al.
1999 ﻿rhy﻿nchozoon sp.﻿ ﻿1 sen﻿su hayward, 1974 notes hayward 1974 schizoretepora gregory, 1893 schizoretepora imperati (busk, 1884) notes chimenz gusso et al.
2014 schizoretepora serratimargo (hincks, 1886) notes gautier 1962, harmelin 1969, ganias 1990 schizoretepora solanderia (risso, 1826) notes harmelin 1969, ganias 1990 schizotheca hincks, 1877 schizotheca fissa (busk, 1856) notes harmelin 1969, hayward 1974, ganias 1990 stephanollona duvergier, 1921 stephanollona armata (hincks, 1861) notes harmelin 1969, hayward 1974, castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios et al.
1985a, castritsi-catharios et al.
1985b, ganias 1990 phoceanidae vigneaux, 1949 phoceana jullien in jullien & calvet, 1903 phoceana tubulifera (heller, 1867) notes harmelin 1969, hayward 1974, ganias 1990 romancheinidae jullien, 1888 escharella gray, 1848 escharella rylandi geraci, 1974 notes ganias 1990 hemicyclopora norman, 1894 hemicyclopora multispinata (busk, 1861) notes ganias 1990, morri et al.
1999 hippopleurifera canu & bassler, 1925 hippopleurifera pulchra (manzoni, 1870) notes harmelin 1969 savignyellidae levinsen, 1909 savignyella levinsen, 1909 savignyella lafontii (audouin, 1826) notes gautier 1962, hayward 1974, morri et al.
1999 schizoporellidae jullien, 1883 schizobrachiella canu & bassler, 1920 schizobrachiella sanguinea (norman, 1868) notes gautier 1962, harmelin 1969, ganias 1990, morri et al.
1999 schizoporella hincks, 1877 schizoporella dunkeri (reuss, 1848) notes harmelin 1969, hayward 1974, castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios et al.
1986a, morri et al.
1999, ganias 1990 schizoporella errata (waters, 1878) notes hayward 1974, castritsi-catharios et al.
1985a, ganias 1990 schizoporella magnifica hincks, 1886 notes harmelin 1969, hayward 1974, ganias 1990 schizoporella unicornis (johnston in wood, 1844) notes castritsi-catharios et al.
1986a, ganias 1990, morri et al.
1999, antoniadou and chintiroglou 2005 setosellidae levinsen, 1909 setosella hincks, 1877 setosella vulnerata (busk, 1860) notes hayward 1974, ganias 1990 smittinidae levinsen, 1909 parasmittina osburn, 1952 parasmittina raigii (audouin, 1826) distribution nib notes ganias 1990 parasmittina rouvillei (calvet, 1902) notes harmelin 1969, hayward 1974, ganias 1990 prenantia gautier, 1962 prenantia cheilostoma (manzoni, 1869) notes hayward 1974, ganias 1990 prenantia inerma (calvet, 1906) notes harmelin 1969 smittina norman, 1903 smittina cervicornis (pallas, 1766) notes ​gautier 1962 (as porella cervicornis), ganias 1990 (as p. cervicornis), morri et al.
1999, chimenz gusso et al.
2014 smittina colleti (jullien & calvet, 1903) notes harmelin 1969, ganias 1990 smittina landsborovii (johnston, 1847) notes ganias 1990, antoniadou and chintiroglou 2005 smittina remotorostrata (canu & bassler, 1928) notes hayward 1974 smittoidea osburn, 1952 smittoidea marmorea (hincks, 1877) notes hayward 1974, ganias 1990 smittoidea ophidiana (waters, 1879) notes harmelin 1969, hayward 1974 smittoidea reticulata (macgillivray, 1842) notes gautier 1962, morri et al.
1999, antoniadou and chintiroglou 2005 tessaradomidae jullien, 1903 tessaradoma norman, 1869 tessaradoma boreale (busk, 1860) notes ganias 1990 trypostegidae gordon, tilbrook & winston, 2005 trypostega levinsen, 1909 trypostega venusta (norman, 1864) notes ganias 1990 umbonulidae canu, 1904 umbonula hincks, 1880 umbonula ovicellata hastings, 1944 notes hayward 1974, castritsi-catharios and kiortis 1984, castritsi-catharios et al.
1986a, ganias 1990, morri et al.
1999 watersiporidae vigneaux, 1949 watersipora neviani, 1896 watersipora complanata (norman, 1864) notes ganias 1990 watersipora cucullata (busk, 1854) notes busk 1854, hayward 1974, castritsi-catharios et al.
1986b, castritsi-catharios and ganias 1989, ganias 1990. records of watersipora subovoidea (d'orbigny, 1852) probably belong to w. cucullata.
ctenostomatida busk, 1852 alcyonidiidae johnston, 1838 alcyonidium lamouroux, 1813 alcyonidium cellarioides (calvet, 1900) notes castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985 alcyonidium duplex prouho, 1892 notes ganias 1990 alcyonidium polyoum (hassall, 1841) notes ganias 1990 buskiidae hincks, 1880 buskia alder, 1857 buskia nitens alder, 1857 notes ​castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, ganias 1990 farrellidae d'hondt, 1983 farrella ehrenberg, 1838 farrella repens (farre, 1837) notes castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b mimosellidae hincks, 1877 bantariella jebram, 1973 bantariella verticillata (heller, 1867) notes ​castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, castritsi-catharios et al.
1985a, castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b, castritsi-catharios and ganias 1989, ganias 1990, morri et al.
1999 mimosella hincks, 1851 mimosella gracilis hincks, 1851 notes harmelin 1969, castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, castritsi-catharios et al.
1985a, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990, morri et al.
1999 nolellidae harmer, 1915 nolella gosse, 1851 nolella dilatata (hincks, 1860) notes harmelin 1969, ganias 1990 nolella stipata gosse, 1855 notes castritsi-catharios and kiortis 1984, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990, morri et al.
1999 pherusellidae osburn & soule, 1953 pherusella soule, 1951 pherusella tubulosa (ellis & solander, 1786) notes castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, castritsi-catharios et al.
1986a, ganias 1990, morri et al.
1999 vesiculariidae hincks, 1880 amathia lamouroux, 1812 amathia gracilis (leidy, 1855) notes ganias 1990, morri et al.
1999 amathia gracillima (hincks, 1877) distribution nib notes castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, ganias 1990 amathia imbricata (adams, 1798) notes castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b, castritsi-catharios and ganias 1989, ganias 1990 amathia lendigera (linnaeus, 1758) notes castritsi-catharios and ganias 1989, ganias 1990, morri et al.
1999 amathia pruvoti calvet, 1911 notes castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990, morri et al.
1999 amathia pustulosa (ellis & solander, 1786) notes castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b amathia semiconvoluta lamouroux, 1824 notes castritsi-catharios and ganias 1989, ganias 1990 amathia verticillata (delle chiaje, 1822) distribution nib notes castritsi-catharios and kiortis 1984, castritsi-catharios and kiortis 1985, castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b, castritsi-catharios and ganias 1989, ganias 1990, conides et al.
1999 victorellidae hincks, 1880 victorella saville-kent, 1870 victorella pavida saville-kent, 1870 notes castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b walkeriidae hincks, 1880 walkeria fleming, 1823 walkeria tuberosa heller, 1867 notes castritsi-catharios and kiortis 1984, castritsi-catharios et al.
1985a, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990, morri et al.
1999 walkeria uva (linnaeus, 1758) notes castritsi-catharios and kiortis 1984, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990 stenolaemata borg, 1926 cyclostomatida busk, 1852 annectocymidae hayward & ryland, 1985 annectocyma hayward & ryland, 1985 annectocyma arcuata (harmelin, 1976) notes ganias 1990 annectocyma major (johnston, 1847) notes ​castritsi-catharios et al.
1985a (as stomatopora major), castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b, castritsi-catharios and ganias 1989 (as s. major), ganias 1990, simboura et al.
1995, morri et al.
1999 annectocyma tubulosa (busk, 1875) notes ganias 1990 entalophoroecia harmelin, 1976 entalophoroecia deflexa (couch, 1844) notes castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b, castritsi-catharios and ganias 1989, ganias 1990 entalophoroecia gracilis harmelin, 1976 notes ganias 1990 entalophoroecia robusta harmelin, 1976 notes ganias 1990 crisiidae johnston, 1838 crisia lamouroux, 1812 crisia denticulata (lamarck, 1816) notes ganias 1990 crisia eburnea (linnaeus, 1758) notes castritsi-catharios and kiortis 1984, castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b, castritsi-catharios and ganias 1989, ganias 1990 crisia elongata milne edwards, 1838 notes castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b crisia fistulosa (heller, 1867) notes castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios et al.
1986a, ganias 1990 crisia pyrula harmelin, 1990 notes harmelin 1969 (as crisia sp.
ii), ganias 1990​ crisia ramosa harmer, 1891 notes castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990, simboura et al.
1995 crisia sigmoidea waters, 1916 notes harmelin 1969, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990, simboura et al.
1995 entalophoridae reuss, 1869 mecynoecia canu, 1918 mecynoecia delicatula (busk, 1875) notes ganias 1990 frondiporidae busk, 1875 frondipora link, 1807 frondipora verrucosa (lamouroux, 1821) notes harmelin 1969 (as frondipora gracilis), ganias 1990, gerovasileiou et al.
2015 horneridae smitt, 1867 hornera lamouroux, 1821 hornera frondiculata lamouroux, 1821 notes harmelin 1969, ganias 1990, simboura et al.
1995 lichenoporidae smitt, 1867 disporella gray, 1848 disporella hispida (fleming, 1828) notes rosso and di martino (2016) maintained this taxon but it is possible that these records actually belong to a different species, d. alboranensis alvarez, 1992; all records need to be validated.
recorded by harmelin 1969, castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989 (as lichenopora hispida), ganias 1990, simboura et al.
1995, morri et al.
1999. patinella gray, 1848 patinella radiata (audouin, 1826) notes ​castritsi-catharios and marcopoulou-diacantoni 1983, castritsi-catharios and kiortis 1984, castritsi-catharios et al.
1985a, castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990, simboura et al.
1995, morri et al.
1999, antoniadou and chintiroglou 2005 patinella verrucaria (linnaeus, 1758) notes castritsi-catharios et al.
1986a, castritsi-catharios and ganias 1989, ganias 1990 oncousoeciidae canu, 1918 ﻿'microecia' canu, 1918 ﻿'m﻿icroecia' occulta (harmelin, 1976) ﻿'m﻿icroecia' occulta see rosso et al.
(2010) notes ganias 1990 plagioeciidae canu, 1918 cardioecia canu & bassler, 1922 cardioecia watersi (o'donoghue & de watteville, 1939) notes harmelin 1969 (as entalophora rugosa), harmelin 1976, castritsi-catharios et al.
1986b, castritsi-catharios and ganias 1989, ganias 1990 desmeplagioecia canu & bassler, 1920 desmeplagioecia amphorae harmelin, 1976 notes ganias 1990 desmeplagioecia violacea harmelin, 1976 notes ganias 1990 diplosolen canu, 1918 diplosolen obelius (johnston, 1838) diplosolen obelius the use of the name d. obelius for this species has been proposed by rosso and di martino (2016) in spite of 'obelium' and 'obelia', used inconsistently in the literature to ensure accordance to the gender of the genus name.
notes harmelin 1969, ganias 1990, morri et al.
1999 plagioecia canu, 1918 plagioecia dorsalis (waters, 1879) notes ganias 1990 plagioecia inoedificata (jullien, 1882) notes ganias 1990 plagioecia patina (lamarck, 1816) notes harmelin 1969, ganias 1990, antoniadou and chintiroglou 2005 plagioecia platydiscus harmelin, 1976 notes ganias 1990 plagioecia sarniensis (norman, 1864) notes harmelin 1976, ganias 1990 terviidae canu & bassler, 1920 tervia jullien, 1883 tervia irregularis (meneghini, 1844) notes ganias 1990 tubuliporidae johnston, 1838 harmelinopora brood, 1976 harmelinopora indistincta (canu and bassler, 1929) harmelinopora indistincta see rosso and di martino (2016) and references therein notes castritsi-catharios and marcopoulou-diacantoni 1983, ganias 1990 idmidronea canu & bassler, 1920 idmidronea coerulea harmelin, 1976 idmidronea coerulea see rosso et al.
(2010) and references therein notes ganias 1990 idmidronea triforis (heller, 1867) idmidronea triforis see rosso et al.
(2010) and references therein notes harmelin 1969 (as idmidronea atlantica), ganias 1990 (as i. atlantica) platonea canu & bassler, 1920 platonea stoechas harmelin, 1976 notes harmelin 1976, ganias 1990, morri et al.
1999 tubulipora lamarck, 1816 tubulipora hemiphragmata harmelin, 1976 notes castritsi-catharios and kiortis 1984, castritsi-catharios et al.
1985a, castritsi-catharios et al.
1985b, castritsi-catharios et al.
1986a, castritsi-catharios et al.
1986b, ganias 1990 tubulipora liliacea (pallas, 1766) notes castritsi-catharios et al.
1985a, ganias 1990 tubulipora notomale (busk, 1875) notes ganias 1990 tubulipora plumosa thompson in harmer, 1898 notes castritsi-catharios and ganias 1989, ganias 1990, morri et al.
1999 tubulipora ziczac harmelin, 1976 notes ganias 1990​ analysis the bryozoan fauna of the greek seas consists of 237 species, classified into 127 genera, 66 families, 3 orders, and 2 classes (suppl.
material 1).
the vast majority belongs to the class gymnolaemata, comprising 198 species (177 cheilostomatida and 21 ctenostomatida) and the remaining 39 species are stenolaemata (all cyclostomatida).
the families with the highest number of species belong to cheilostomatida, and are phidoloporidae (16 species), celleporidae (14 spp.
), bugulidae (12 spp.
), calloporidae (12 spp.
), smittinidae (11 spp.
), candidae (10 spp.
), and cribrilinidae (10 spp.).
these families are the most speciose in the mediterranean sea as well (rosso and di martino 2016).
all other families include less than 10 species each.
all species included in the checklist are recognized in the world list of bryozoa and the world register of marine species, except for three of them.
these are: idmidronea triforis (heller, 1967) and i. coerulea harmelin, 1976, allocated within the genus idmidronea canu and bassler, 1920 and not exidmonea david, mongereau and pouyet, 1972; 'microecia' occulta (harmelin, 1976), provisionally left in its former allocation because the characters of the species differ from those of the genus oncousoecia canu, 1918 that has been suggested for its allocation (although microecia canu, 1918 is recognized as a synonym of plagioecia canu, 1918).
the taxon rhynchozoon sp.
1 sensu hayward, 1974 described from chios island, was retained in the checklist following extensive lists by zabala and maluquer 1988, rosso et al.
2010, rosso and di martino 2016 and taxonomic papers with description and illustrations of material from tyrrhenian and adriatic localities (chimenz gusso et al.
2014).
a number of taxa were omitted from the present checklist (table 1) for different reasons: (1) taxa now recognized as species complexes and considered absent from the mediterranean; further examination of specimens is needed to ascertain their correct identification; (2) species whose currently accepted geographic distribution does not include the mediterranean sea; the examination of the material with the scanning electron microscope could possibly raise the number of non-indigenous species in the mediterranean basin; (3) species known exclusively as fossils from tertiary sediments of europe, whose persistence in the mediterranean sea throughout the messinian salinity crisis needs to be ascertained.
discussion the bryozoan fauna of the greek seas makes up 42.7% of the species, 59.9% of the genera and 71% of the families of the mediterranean bryozoan fauna, specifically 41.7% of the cheilostomatida, 36.8% of the ctenostomatida and 52% of the cyclostomatida species, based on the recent update by rosso and di martino (2016).
despite the small number of sporadically distributed studies on this phylum in greece, a considerable number of bryozoan species has been reported compared to adjacent eastern mediterranean countries.
a total of 185 species has been recorded from turkey, 139 of which along the aegean coasts (koçak and aydın önen 2014) and 93 species from lebanon (harmelin et al.
2016), while 60 species were estimated to occur along the mediterranean coasts of israel (sokolover et al.
2016).
these numbers confirm the observed impoverishment of the bryozoan fauna from the western to the eastern basin (harmelin et al.
2016).
among the species reported from greece, 12 are considered endemic to the eastern mediterranean basin; these are the cheilostomes adeonella pallasii, calyptotheca rugosa, cellepora posidoniae, hippopodina ambita, hippoporidra picardi, monoporella bouchardii, plesiocleidochasma mediterraneum, reteporellina delicatula, retevirgula akdenizae, smittipora disjuncta, therenia rosei and turbicellepora camera.
of these, 5 species were first described from the island of chios based on material collected by hayward (i.e.
c. rugosa, h. ambita, r. delicatula, t. rosei, and t. camera), h. picardi was described from the gulf of thessaloniki, while r. akdenizae was described from the turkish coasts of the aegean sea.
the cheilostome hippaliosina depressa, which was described from the aegean sea, is considered more typical of the eastern mediterranean basin, including the sicily strait, the western ionian and south adriatic seas (harmelin et al.
2016 and references therein, ar personal observations).
nevertheless, this species was recorded in a few localities of western corsica (calvet 1902, gautier 1962) and sardinia (ar and e. di martino, personal observations) in the western mediterranean.
interestingly, three of the bryozoans recorded from greece are typical of the north atlantic (hayward and ryland 1998, hayward and ryland 1999) and have been rarely reported from the mediterranean sea.
these are alderina imbellis (hincks, 1860), also reported from northern catalonia (madurell et al.
2013), escharina johnstoni (quelch, 1884), also reported from the western ionian sea (rosso 1996a, rosso 1996b, rosso et al.
2014), and anarthropora monodon (busk, 1860).
the recent introduction of non-indigenous species, mostly lessepsian migrants, over the last decades, has considerably increased the number of bryozoans occurring in the mediterranean sea (rosso and di martino 2016).
studies in the southeastern mediterranean basin have brought to light a considerable number of nibs (harmelin 2014b, gerovasileiou et al.
2016, harmelin et al.
2016, sokolover et al.
2016), mainly originated from the red sea/indo-pacific ocean.
until today, 12 nibs have been reported from the greek seas, representing 5% of the bryozoan fauna of greece and 20% of the mediterranean nib fauna; these are the ctenostomes amathia gracillima and a. verticillata and the cheilostomes bugula neritina, bugulina fulva, crepidacantha poissonii, crisularia plumosa, c. serrata, exechonella antillea, hippopodina feegeensis, microporella coronata, parasmittina raigii, and scrupocellaria scruposa.
bryozoans from the greek seas were reported from a variety of habitats, including soft sediments, seagrass leaves and rhizomes, macroalgae, coralligenous concretions and, to a smaller extent, from marine caves.
further research on bryozoan diversity in understudied habitats, typically species-rich in bryozoans (e.g.
marine caves and coralligenous beds), is expected to increase our knowledge, possibly revealing additional new and non-indigenous species.
supplementary material supplementary material 1 checklist of marine ﻿bryozoa of greece data type: taxonomic checklist brief description: taxonomic checklist of bryozoa known to occur in the greek seas.
file: oo_104057.xls vasilis gerovasileiou, antonietta rosso
@highlight
abstract background until today, a complete checklist of bryozoa of the greek seas had never been published and species records were scattered in several taxonomic and ecological studies.
the aim of this paper is to produce a first checklist of marine bryozoan species of greece, in the framework of the greek taxon information system (gtis) initiative of the lifewatchgreece research infrastructure (esfri), by reviewing the existing literature and following the recent trends in the taxonomy of this group.
﻿ new information the marine bryozoan fauna of greece comprises 237 species, classified in 127 genera, 66 families, 3 orders, and 2 classes.
the vast majority belongs to the class gymnolaemata (177 cheilostomatida and 21 ctenostomatida), while the remaining 39 species are stenolaemata (all cyclostomatida).
among these species, 12 are considered endemic to the eastern mediterranean, while another 12 species are non-indigenous.
