1 introduction pseudomonas aeruginosa (pa) remains an important pathogen in cystic fibrosis (cf) with its extensive armament of virulence factors and evolving resistance profile [1], [2].
chronic infections with mucoid pa strains develop in the majority of patients and result in poorer lung function and patient survival [1], [2], [3].
current treatment strategies can delay onset of such chronic airways infection, but truly preventative measures, including anti-pseudomonal vaccines [4], remain elusive.
thus, identifying a critical anti-pseudomonal host response could enable therapeutic immunomodulation.
interleukin-22 (il-22), a member of the il-10 family of cytokines, has recently attracted attention as a critical mediator of mucosal host defense, including the lung [5], [6].
il-22 is produced by t helper (th) 17 cells, th22 cells, γδ t cells, natural killer (nk) t cells and innate lymphoid cells (ilcs) [5], [6].
via its actions on non-haemopoieitic cells, il-22 predominantly functions in tissue protection and repair—increasing innate defenses via expression of β-defensins, s100 proteins and lipocalin-2, maintaining transepithelial barrier functions and enhancing tissue regeneration [6]; thus representing an attractive therapeutic target.
however, il-22 may also exacerbate pro-inflammatory tissue-damaging responses in the lung when acting in synergy with the pro-inflammatory cytokine il-17 [5], [7].
in respiratory infections, il-22 provides critical immunity against klebsiella pneumoniae [8], streptococcus pneumoniae [9], chlamydia muridarum [10], influenza [11], [12], as well as the cf pathogen aspergillus fumigatus [13].
a protective role of il-22 against pulmonary p. aeruginosa infection potentially exists [14], [15], but is yet to be clearly defined.
interleukin-22 production is evident in patients with cf and pseudomonas infection.
we have demonstrated that cf patients have peripheral pseudomonas-specific th22 and th17 cells which may produce il-22 in an antigen-specific manner and home to the infected lung [16].
in addition, explanted pulmonary lymph nodes of cf patients contain cd4+ il-22+ t cells specific for p. aeruginosa antigens [17].
il-22 transcript expression has also been found to be increased in lung tissue [17] as well as il-22 levels in sputum and plasma [18] of cf patients.
we examine explanted cf lung airway il-22 expression and il-22 immune localization to further demonstrate cytokine involvement in the cf lung environment.
to define the role of il-22 in immunity to chronic p. aeruginosa infection, we utilized the agar bead model of persistent pulmonary infection [19] in mice, determining whether the cytokine is produced in response to infection and its role in determining acute outcome, chronic infection, inflammatory response, and infection-related weight loss.
2 methods 2.1 ethics approval was obtained from the newcastle and north tyneside 2 research ethics committee (07/q0906/47).
informed consent was obtained from all participants at the time of acceptance onto the active lung transplantation list at the freeman hospital, newcastle upon tyne, uk.
characteristics of the 14 patients in the study who underwent lung transplantation for end-stage cf are contained in supplementary table 1.
2.2 airway lavage samples airway lavage fluid was obtained from the explanted lungs of cf patients undergoing lung transplantation, as previously described [20].
il-22 levels were measured via elisa (ebioscience) with a lower limit of detection of 2 pg/ml.
2.3 immunohistochemistry airway blocks were dissected to provide intermediate/large airways of 1–5 mm diameter with intact columnar airway epithelia.
formalin-fixed blocks were embedded in paraffin, sectioned at 5 μm and stained with haematoxylin and eosin to check for the presence of appropriate airway epithelia.
sections for il-22 staining were de-waxed in xylene and rehydrated through graded alcohols.
endogenous peroxidase activity was blocked by soaking sections in 0.3% methanolic hydrogen peroxide.
the sections were washed for 10 min in running tap water and rinsed in tris-buffered saline (tbs).
antigen retrieval was performed in tris-edta-triton x buffer at ph 9 (10 mm tris, 1 mm edta, 0.02% triton x-100) at boiling point for 10 min.
the sections were then allowed to cool for 20 min before blocking with 5% non-fat milk protein in tbs for 10 min.
the primary antibody was a rabbit polyclonal immunoglobulin anti-il-22 (millipore, reference 06-1076) diluted 1:100 in 3% bovine serum albumin and applied for 24 h in a bioassay incubating tray at 4 °c.
sections were washed twice with tbs and treated with a biotinylated horse anti-rabbit envision secondary antibody system (dako laboratories) for 30 min.
sections were washed twice with tbs and treated with the abc vectastain elite kit and dab as per the manufacturer's instructions.
the sections were finally counterstained with carazzi's stain for 1 min and mounted.
negative controls were performed by omission of the primary antibody and treatment with isotype normal rabbit immunoglobulin (dako laboratories).
2.4 agar bead infection model the infection model was adapted from the protocol described by van heeckeren et al.
[19] and is widely utilized in cf research with inflammatory, microbial and remodeling akin to human cf lung disease [21], [22].
wild-type (wt) mice were inoculated with sterile agar beads compared with p. aeruginosa-laden beads.
in separate experiments examining the effect of il-22, both wt and il-22 knockout (il-22 ko) mice were infected with pa-laden agar beads.
p. aeruginosa-laden agar beads were prepared the day before inoculation, stored overnight at 4 °c, and a different bead preparation used for each experiment.
pa-laden beads were stored on ice throughout the murine surgery.
following inoculation of pa-laden beads, the administrated inoculum was confirmed by homogenization and quantitative bacteriology.
sterile agar beads were stored at 4 °c, used for several experiments and confirmed as sterile before and after each use.
for inoculation of beads, mice were anaesthetized using isofluorane via nose cone and the trachea exposed and cannulated (22g intravenous cannulae; bd biosciences) under aseptic conditions.
wt mice were infected at inoculum 1 × 106 cfu per animal for comparison of response against sterile bead-treated animals.
an initial low-dose experiment, of 1 × 105 cfu/50 μl per animal, was undertaken to judge potential toxicity in genetically modified animals, followed by three subsequent experiments utilizing 1 × 106 cfu/50 μl per animal.
daily weights were used as a measure of disease progression and those with weight loss of greater than 20% of baseline weight were culled prior to the predefined experiment end-point.
experiments were terminated at 2 weeks post-inoculation via carbon dioxide asphyxiation.
bronchoalveolar lavage (bal), pulmonary lymph nodes and lung tissue were harvested under aseptic conditions.
a total of 1 ml of sterile phosphate-buffered saline (pbs) was infused and aspirated into the airways three times for each bal sample.
thoracic lymph node cells were obtained from the bilateral mediastinal lymph nodes and single tracheobronchial lymph node [23].
2.5 p. aeruginosa strains the clinical nh57388a strain was provided by n. hoffmann (university of copenhagen), the strain possesses a mutation in muca resulting in alginate hyper-production [24].
the mucoid yh5 strain and non-mucoid gri-1 strains were obtained locally, from a patient with cf and with ventilator-associated pneumonia, respectively.
pa strains were maintained in − 80 °c stocks until required.
both the nh57388a and yh5 strains were used to form pa-laden agar beads as described previously [19].
for production of heat-killed pa, each strain was grown to mid-log phase in luria–bertani (lb) broth (invitrogen) and the bacterial concentration at od600 readings between 0.4 and 0.6 were quantified by serial dilution and plating to enumerate colony-forming units (cfu) (genequant pro spectrophotometer, amersham biosciences).
pa were heated at a known concentration in pbs to 95 °c for 10 min.
2.6 animals all mice were used between 12 and 16 weeks of age.
il-22 ko mice were supplied by genentech [25].
all murine lines had a c57bl/6 background.
c57bl/6 mice bred in-house were used as wild-type controls for knockout comparisons.
animal work was carried out under a project licence as required by uk home office regulations as well as scrutiny and approval by an institutional review board at the university of glasgow.
2.7 bacteriology lung tissue was mechanically homogenized in 1 ml pbs.
bal and lung homogenates were plated for quantitative bacteriology on lb agar and examined after 24 and 48 h of incubation.
colonies were confirmed to be pa by appearance, gram stain (bd biosciences) and oxidase testing (sigma-aldrich).
chronic infection was defined as recovery of mucoid pa from lung cultures at 2 weeks post-inoculation.
pulmonary bacterial burden was calculated from bal and right lung homogenates.
2.8 neutrophil quantification blood and bal samples underwent red blood cell (rbc) lysis (red cell lysis buffer; sigma-aldrich) prior to staining with gr-1 (ly6g; rb6-8c5; biolegend).
countbright absolute counting beads (invitrogen) were added prior to washing cells and used according to the manufacturer's instructions.
stained cells were analyzed using facs aria (bd biosciences) and flowjo software (treestar).
2.9 cytokine measurement murine il-17a, il-17f, il-21, interferon-γ (ifn-γ), and il-22 were quantified by elisa (all ebioscience).
lower limits of detection were: il-17a < 4 pg/ml, il-17f < 15 pg/ml, il-21 < 16 pg/ml, ifn-γ < 15 pg/ml and il-22 < 8 pg/ml.
cytokine levels less than the lower limits of detection of the assay were assigned a value of zero.
2.10 histology scoring inflation fixed murine lungs were embedded in paraffin, sectioned at 5 μm and stained with haematoxylin and eosin.
histology was scored for peribronchial and alveolar involvement using a scoring system adapted from that described by dubin et al.
[15].
scoring of each lung section was performed blindly at × 10 magnification by two independent investigators with an overall score given following assessment of a randomly selected whole lung section.
2.11 mediastinal lymph node stimulation mediastinal lymph nodes were passed through 80 μm nitex mesh and rbcs lysed to form a single cell suspension.
cells were either left unstimulated or stimulated with heat-killed pa at moi30.
following 3 days of culture, 100 μl of supernatant was removed for cytokine quantification.
2.12 statistics results are presented as medians or, for technical repeats, mean and standard error of the mean (sem).
mann–whitney test was used for non-parametric comparisons.
for parametric testing, student's 2-sample t-test was used.
proportions were compared via fishers' exact test.
comparison of animal weight changes were analysed using a repeated-measures anova.
survival data was analysed via log-rank (mantel–cox) test.
statistical analysis was undertaken using prism version 6.0 (graphpad software).
a p-value of < 0.05 was considered significant.
3 results 3.1 il-22 production and airway epithelial localization in explanted cf lung il-22 was evident in airway lavage obtained from the explanted lungs of adult patients with cf undergoing transplantation (fig.
1a).
il-22 was identified, via immunohistochemistry of explanted cf lung tissue, to localize to the airway epithelium with more sparse staining in lung parenchyma (fig.
1b).
3.2 il-22 production in pa-specific immune responses following infection comparison of animals treated with sterile or pa-laden agar beads demonstrated no significant difference detectable in il-22 levels in bal or lung homogenates at either 48 h (data not shown) or 2 weeks (fig.
1d) post-instillation.
in addition, there was no significant difference between infected animals and sterile bead controls in other pulmonary cytokine levels related to th17 cells, i.e.
il-17a, il-17f, and il-21 (supplementary fig.
1).
no detectable il-17a or il-22 was found in the bal of treatment-naïve wild-type mice.
we thus sought to ascertain if pa-specific immune responses had been induced by the persistent pulmonary pa infection and were able to produce il-22 in an antigen-specific manner.
two weeks following pa infection, there was a marked enlargement of the mediastinal lymph nodes compared to control animals (3.56 × 106 cells mean value for nh57388a-infected animals versus 2.83 × 105 cells mean value for sterile bead-treated animals; three separate experiments, p < 0.05).
ex vivo restimulation of these lymph node cells from infected animals with heat-killed bacteria of the infecting strain nh73788a or an unrelated clinical pa strain gri-1 for 3 days resulted in robust production of il-22, which was not evident in animals receiving sterile beads (fig.
1e).
similarly p. aeruginosa-specific production of il-17a by infected animals was evident (data not shown).
this suggests that il-22 production can occur as a specific response to pulmonary pseudomonas infection and that there is migration to and/or expansion of pa-specific il-22+ producing cells within the thoracic lymph nodes in response to pulmonary infection.
3.3 il-22 absence does not alter acute responses to pulmonary pa infection having demonstrated that il-22 could be produced locally in response to pulmonary p. aeruginosa infection, we compared the response to infection in wild-type mice and animals lacking the ability to produce il-22.
the response was assessed to two clinical mucoid strains of pa, nh57388a and yh5, including at low- and high-inoculation dose in the latter.
to ensure il-22 ko animals did not have altered responses to the agar beads per se, we examined the impact of sterile agar beads in il-22 ko and wt mice at 48-h post-bead instillation.
importantly, we found no difference in weight loss, clinical score, microbiology (no organisms isolated) or blood and bal neutrophil levels between il-22 ko and wt animals treated with sterile beads (data not shown).
il-22 has previously been shown to play a critical role in protection from acute pulmonary infection with another gram-negative organism by maintaining transepithelial resistance and preventing systemic spread [8], [13].
in contrast, there was no significant difference in acute mortality (i.e.
prior to pre-defined experimental endpoint) in any of the experiments comparing persistent pa infection in il-22 knockout and wt animals.
higher rates of acute mortality in wt and il-22 ko groups were seen to the nh57388a strain compared with yh5 stain.
combined, there were a total of 7 acute deaths from 40 treated animals (17.5%) in both the presence and absence of il-22.
in both wt and il-22 ko groups, early termination was due to weight loss greater than 20% of baseline and occurred over the same time period of 3–5 days post-inoculation (fig.
2a).
there was also no significant difference in bacterial burden (fig.
2b) nor in the level of acute inflammation, measured via bal leukocyte and neutrophil levels (fig.
2c and d) in the lungs of il-22 ko compared with wt animals culled at these early time-points (i.e.
3-5 days post-infection).
importantly, due to the role of il-22 in transepithelial resistance, there was no bacterial growth on terminal blood cultures of any animal at any time-point.
thus, acute resistance to pulmonary pa infection was unaltered in the absence of il-22.
3.4 il-22 signaling does not provide resistance to chronic pulmonary pa infection at two weeks post-inoculation, there was no significant difference in chronic pulmonary p. aeruginosa infection rates between inoculated il-22 ko and wt animals in any experiment.
at low inoculum yh5 infection, 37.8% (3/8) wt compared with 14.3% (1/7) il-22 knockouts were chronically infected (p = 0.5962, fishers' exact test).
in the high inoculum experiments, chronic infection was seen in 25% (5/20 animals) in both wt and il-22 ko groups.
pulmonary bacterial burden in chronically infected animals was also similar in il-22 knockout (median 845 cfu, iqr: 505–1468) and wild-type (median 380, iqr: 505–1468) animals (p = 0.9497, fig.
3a).
thus, il-22 does not provide critical protection against the development of persistent pulmonary pa infection.
3.5 il-22 absence does not alter inflammatory responses to chronic pa infection the absence of il-22 signaling did not influence the level of chronic inflammation measured by neutrophil levels both in peripheral blood (fig.
3b) and bal (fig.
3c and d).
total leukocytes were marginally less in il-22 ko bal (fig.
3c) but there was no significant difference both for all animals inoculated with pa-laden agar beads (fig.
3b–d) and for those remaining chronically infected (data not shown) in neutrophilic inflammation.
persistent pulmonary inflammatory changes were evident 2 weeks post-inoculation of pa-laden agar beads (fig.
3d-i).
minimal changes were seen in response to sterile agar bead instillation per se (fig.
3e).
infected lungs demonstrated localized peribronchial monocytic infiltrates with an agar bead frequently evident in the adjacent airway (fig.
3f) and higher histological score in wt animals treated with pa-laden compared with sterile agar beads (fig.
3i).
histological changes were similar in wt (fig.
3g) and il-22 ko (fig.
3h) mice treated with pa-laden agar beads, with no significant difference in lung histological scores at 2 weeks post-inoculation (fig.
3j).
3.6 weight loss related to infection is attenuated by the absence of il-22 post-procedure weight loss was significantly greater and sustained in wt animals treated with pa-laden beads compared with sterile bead controls (p < 0.0001, via repeated measures anova; data not shown).
interestingly, there was significantly less weight loss in il-22 knockout animals compared with wt mice treated with pa-laden agar beads (fig.
4).
this lower level of weight loss in the absence of il-22 remained evident when only chronically infected animals were compared (p < 0.0001, via repeated measures anova; fig.
4b).
4 discussion consistent with our previous work demonstrating il-22-producing p. aeruginosa-specific responses in the peripheral blood of patients with cf [16], we demonstrate airway il-22 production and il-22 localization to the airway epithelium in explanted lung tissue from cf patients.
in addition, we demonstrate that murine persistent pulmonary pa infection elicits an antigen-specific response able to produce il-22 locally in draining lymph nodes.
we found no difference in il-22, and other related cytokines, in the lungs of animals treated with pa compared with sterile bead-treated animals.
trauma itself may induce cytokine production and thus the observed lack of difference may be attributable to the mode of bead inoculation.
despite its reported protective role against a range of pulmonary pathogens [8], [9], [10], [11], [12], we found no evidence that il-22 is critical in preventing the establishment of chronic pulmonary p. aeruginosa infection.
the most striking effect of il-22 was in relation to infection-associated weight loss.
poor growth and impaired nutritional status are now recognized as important determinants of pulmonary health and survival in cf [3], [26].
determinants of low weight are likely multifactorial; however, pulmonary pa infection and the associated inflammation are important contributors [27].
our model demonstrated weight loss in relation to p. aeruginosa infection, which was significantly less marked in the absence of il-22 (fig.
4).
the mechanism by which il-22 causes weight loss in pulmonary pa infection is not clear and may include multiple direct and indirect effects of the cytokine.
we found no difference in bacterial burden or pulmonary inflammation levels in the presence or absence of il-22 that might explain the difference between groups.
there may yet be a pathological effect of il-22 in promoting systemic and airways inflammation, perhaps regulated by il-17 [7], which was undetected in the present study but which exacerbates the weight loss associated with infection.
in addition, recent data suggests a new role for il-22 in regulating metabolic homeostasis including insulin sensitivity [28] and production [29] as well as regulation of lipid metabolism in liver and adipose [28]; with studies to-date identifying complex and beneficial effects on metabolism in murine models of obesity [28], [29].
thus, our observed increased weight loss in the presence of il-22 could also represent an effect on metabolism independent of the cytokine's immune function.
interleukin-22 exerts an important role in maintaining mucosal integrity with resultant prevention of systemic spread of organisms [8].
thus, importantly, we demonstrated il-22 localization to the airway epithelium in human cf lung (fig.
1), which may represent production and/or binding of the cytokine at this site of immune activity.
however, akin to p. aeruginosa infection in patients, the experimentally persistent pa infection model demonstrates that intrabronchial sepsis and transepithelial invasion is not a significant component of pathogenesis.
this may explain the lack of importance of il-22 in chronic pulmonary infection observed here compared with the findings of others in acute lung infection where transepithelial spread significantly influences disease outcome [8], [9], [11], [14].
interleukin-22 is implicated in mucosal immunity and homeostasis both in the lung and gut, and the inter-relationship of gut and lung immunity is an area of growing interest.
shih et al.
demonstrate that mice lacking il-22 and il-22 neutralisation in mice via exogenous anti-il-22 antibody resulted in altered gut microflora, with increased segmented filamentous bacteria (sfb) that can promote th17 cell development [30].
gauguet et al.
demonstrated that the gut microbiome may influence pulmonary immunity as mice with gut sfb showing increased bal il-22 levels and decreased susceptibility to acute s. aureus pneumonia [31].
we did not examine the gut microflora of either the wt or ko animals used in our research and whether the gut microbiome has effects on persistent pulmonary infections is unexplored.
however, consideration of gut–lung interactions in the context of cf would need to take account of the increasing evidence of altered gut microbiota in cf patients [32], [33].
a further function of il-22 in mucosal immunity is in the production of anti-microbial peptides including β-defensins and s100 proteins [8].
elevated levels of such anti-microbial proteins have been demonstrated in the airway secretions of patients with cf [34].
in addition, in the context of ocular infection, human β-defensin 2 plays an important role in defense against p. aeruginosa [35].
however, such anti-microbial factors may be induced by alternative non-il-22 pathways, including via il-17 [36], [37], and thus may further explain our observed lack of impact of il-22 on bacterial burden or infection rates in persistent pa infection.
cross-talk between cytokines is undoubtedly important in immunopathological outcomes [5], [7] and thus dual manipulation of il-22 and il-17 cytokines may provide further insights into the important interactions within the complex cytokine milieu of the infected cf lung.
our infection model utilized pa-laden agar beads instilled into animals with no previous lung infection.
interestingly, mear et al.
found that prior candida albicans lung infection resulted in il-22 production from ilcs that provided cross-protection against subsequent acute p. aeruginosa pneumonia [14].
similarly il-22 was found to protect against superimposed infection with s. pneumoniae following respiratory influenza a infection [11].
thus, assessing whether a similar il-22 response can be induced by an early cf pathogen, which provides cross-protection against subsequent chronic mucoid pa infection, still merits consideration.
interleukin-22 functions in appropriate repair following pulmonary insults.
simonian et al.
used an experimental model of pulmonary fibrosis, using repeated exposure to bacillus subtilis, demonstrating that il-22 blockade results in accelerated lung fibrosis [38].
a similar anti-fibrotic role for il-22 has been demonstrated following influenza infection with a corresponding benefit in preserving lung function [12].
whether il-22 has a similar longer-term reparative role in the cf lung is of interest but cannot be answered in the present study.
our preliminary analysis of lung collagen deposition (via picro-sirius red collagen lung staining) in response to 2 weeks of pulmonary pa infection suggested no difference between wild-type and il-22 ko animals (data not shown).
study of more prolonged pa infection may reveal a role for il-22 in preventing aberrant lung repair and fibrosis.
although interleukin-22 has attracted attention as a critical mediator of mucosal immunity, we found no evidence that it influences the short or longer-term outcome in experimental chronic pulmonary p. aeruginosa infection.
critical to therapeutic targeting and cf pathogenesis, il-22 failed to protect against the development of p. aeruginosa colonization.
however, we identified a novel role for il-22 in exacerbating infection-induced weight loss, an important prognostic factor in patients with cystic fibrosis, which warrants further investigation.
the following are the supplementary data related to this article.supplementary table 1characteristics of cf patients undergoing lung transplantation where airway lavage fluid +/- explanted lung tissue was obtained.supplementary table 1.supplementary fig.
1levels of bal and lung homogenate cytokines in mice treated with sterile beads and pseudomonas aeruginosa-laden beads.c57bl6 mice were treated with intrapulmonary sterile agar beads or agar beads laden with p. aeruginosa strain nh57388a.
bal il-17f (a), bal il-21 (b) and lung homogenate il-17a levels measured at 2 weeks post-instillation of sterile agar beads or beads laden with nh57388a.
line represents median.
p-values denote comparison by mann–whitney test.
image 2, animals with ongoing pulmonary pa infection.image 1 disclosures none.
@highlight
background interleukin (il)-22 is a critical mediator of mucosal immunity and tissue regeneration, protecting against a number of respiratory pathogens.
whether il-22 confers protection against chronic pseudomonas aeruginosa (pa) infection in cystic fibrosis (cf) is unknown.
methods explanted cf lungs were examined for il-22 production and immune-localization.
a murine model of persistent pulmonary pa infection was used to examine production of il-22 following infective challenge.
the role of il-22 was examined using il-22 knockout (ko) animals.
results il-22 is produced within the adult cf lung and localizes to the airway epithelium.
il-22 is produced by murine pulmonary lymph node cells following lung infection.
the absence of il-22 resulted in no significant difference in acute mortality, bacterial burden, chronic infection rates, histological changes or neutrophilic inflammation in the chronic pa infection model.
however, il-22 ko animals lost less weight following infection.
conclusion il-22 is produced in the cf lung and in response to pa infection yet is dispensable in protection against chronic pulmonary p. aeruginosa infection in a murine model.
however, we identified a novel role for the cytokine in promoting infection-related weight-loss, a significant prognostic factor in the cf population.
