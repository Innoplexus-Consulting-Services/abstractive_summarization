introduction bartter syndrome is a rare autosomal recessive disorder, manifested in childhood or in the perinatal period with severe hypokalemia, metabolic alkalosis, and low-normal blood pressure.
it is due to primary defect in sodium chloride reabsorption in the medullary thick ascending limb of the loop of henle.
bartter syndrome is caused by inactivating mutation of each of its major transport proteins nkcc2, romk, clc-kb, and bartin which are typed as bartter syndrome 1, 2, 3, and 4, respectively.
[1] gentamicin-induced renal tubular dysfunction may present as a acquired bartter-like syndrome (bs) and to the best of our knowledge, only a few cases are reported in literature.
[234] case report a 26-year-old male was admitted with 6-day history of high-grade fever followed by productive cough who was diagnosed as a case of the right-sided pneumonitis.
he was put on two intravenous (iv) ampicillin and gentamicin.
investigations showed increased white cells count (15,100/cmm) with normal serum electrolytes, renal profile, and liver function test.
subsequently, white cells count normalizzed on the the 5th day of treatment.
the patient was relieved and became afebrile.
on the 7th day of admission, the patient complained of nausea and generalized weakness.
in the evening he had one episode of generalized tonic-clonic seizure.
on the initial evaluation, his glasgow coma scale was 10/15 (e2v3m5).
both pupils were normal in size and reactive to light.
his vital signs were blood pressure 124/70 mmhg, pulse rate 104/min, temperature 98.6°f, and respiratory rate 18/min.
signs of meningeal irritation were absent.
general and systemic examinations were unremarkable.
he was managed immediately with intravenous (iv) diazepam 10mg bolus dose and iv phenytoin at a loading dose of 15mg/kg followed by 100mg 8 hourly.
the blood gas analysis revealed ph 7.54, pco2 42 mmhg, po2 114 mmhg, so2 98.8%, sodium 112 mmol/l, potassium 2.2 mmol/l, bicarbonate 38 mmol/l, and calcium (ca) (ionic) 0.82 mmol/l.
his ultrasonography revealed normal kidneys.
computed tomography of the head detected no abnormality, and cerebrospinal fluid cerebrospinal fluid analysis was normal.
thyroid profile and serum cortisol level were normal.
we noted increase in urine output (>5 l/24 h) after an episode of seizure.
urinary osmolality was measured as 400 mosm/kg (500-800).
spot urine found k+ 13 (3.5-5.0 mmol/l) and na+ 129 (<20 mmol/l).
twenty-four hours urine collection revealed ca of 475 mg (50-300).
blood chemistry showed gross electrolytes abnormalities, suggestive of metabolic encephalopathy, and the seizure episode could be due to severe hypocalcemia and/or hyponatremia.
these abnormalities persisted for many days [table 1].
these deranged parameters as a result of severe renal salt wasting were due to defective renal tubular concentrating ability.
the patient was diagnosed as a case of bs associated with gentamicin exposure.
gentamicin was stopped immediately.
electrolyte replacements were started accordingly.
his laboratory parameters normalized after 13 days and remained asympotomatic thereafter.
table 1 significant investigations of patient, since the day of hospitalization* and seizure# discussion aminoglycosides are known to produce vestibular, cochlear, and renal toxicity.
approximately, 8%–26% of patients receiving an aminoglycoside for several days will develop mild renal impairment which is almost always reversible.
[5] gentamicin is excreted by glomerular filtration, and toxicity is due to the the accumulation of drug in porphyria cutanea tarda porphyria cutanea tarda cells.
the drug interferes with cellular energetic, impares intracellular phospholipase, and induces oxidative stress which in turn results in cell destruction.
[1] however, mitochondrial dysfunction is hypothesized for underlying abnormalities in all parts of the renal tubule.
[2] thus, aminoglycoside-induced renal tubular dysfunction may present as fanconi-like syndrome, bs, and distal renal tubular acidosis.
[23] the exact pathways culminating in aminoglycoside-induced bs is not well known and may be similar to the hereditary variant of bartter's disease which involves a transporter defect situated in the thick ascending loop of the renal tubule.
it is hypothesised that gentamicin, a polyvalent cationic molecule, directly activates the ca sensing receptor in the thick ascending loop of henle and the distal tubule, which results in renal wasting of sodium, potassium, chloride, ca, and magnesium.
[34] the risk of renal tubular dysfunction is related to a prolonged and inappropriately high-dose aminoglycosides use.
[2] cases of transient bartter's syndrome associated with aminoglycoside use have been described to recover after 2–6 weeks following cessation of the antibiotics.
[26] the presentation of our patient (metabolic alkalosis, refractory hypokalemia, hypocalcemia hypomagnesemia, and hypercalceuria) was suggestive of bs while other close differential diagnosis, gitelman syndrome was ruled out by the the presence of low serum ca level and documentation of hypercalciuria.
[7] our case represents characterization of a rare and potential danger of gentamicin therapy.
conclusion patients on gentamicin therapy should be monitored.
routinely for electrolyte imbalances to avoid potential morbidity and life-threatening condition.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
aminoglycoside nephrotoxicity may manifest as nonoliguric renal failure or tubular dysfunction, such as fanconi-like syndrome, bartter-like syndrome (bs), or distal renal tubular acidosis.
we report a case who developed severe renal tubular dysfunction on the the 7th day of gentamicin therapy, resulting in metabolic alkalosis, refractory hypokalemia, hypocalcemia, hypomagnesemia, and polyuria.
the patient was diagnosed as a case of transient bs associated with gentamicin exposure.
the patient recovered with conservative management.
