introduction tetraspanins are membrane-spanning proteins with a conserved structure that function primarily as membrane protein organizers.
phylogenetic analysis identified 33 tetraspanins in humans, 37 in drosophila melanogaster (charrin et al., 2014), and 20 in caenorhabditis elegans (huang et al., 2005), while only 17 were identified in arabidopsis thaliana (boavida et al., 2013).
tetraspanins have also been identified in the ameoba, dictyostelium discoideum, which exists as both a unicellular and multicellular organism (albers et al., 2016).
while some tetraspanins are expressed ubiquitously in humans, others are cell or tissue specific (maecker et al., 1997; de winde et al., 2015), providing a means to regulate the signal transduction associated with a breadth of cellular processes.
members of the tetraspanin family of proteins have four transmembrane domains, which contribute to the creation of a small (ec1) and large (ec2) extracellular loop (figure 1).
the large extracellular loop contains a conserved cys-cys-gly amino acid motif (ccg-motif), as well as two other conserved cysteine residues.
ec2 of cd81 was resolved using crystallography (kitadokoro et al., 2001), where the authors demonstrated that the four conserved cysteine resides within ec2 promote the formation of disulfide bridges, as had been suggested by previous reports (levy et al., 1991; tomlinson et al., 1993; maecker et al., 1997).
moreover, molecular modeling studies using the cd81 ec2 structure as a template predicted the topography of several other tetraspanins including cd37, cd53, cd82, and cd151 (seigneuret et al., 2001; seigneuret, 2006).
these studies demonstrated that the ec2 domain of tetraspanins consist of one conserved and one variable domain, with the conserved domain consisting of a three-helix bundle while the variable domain is unique to particular tetraspanins.
a recent report resolved a crystal structure of full-length cd81, finding that the four transmembrane domains create a cholesterol-binding pocket (zimmerman et al., 2016).
furthermore, the authors performed molecular dynamics simulations that suggest cd81 can adopt an open or closed conformation depending on whether or not cholesterol is bound.
figure 1 schematic of tetraspanin molecular structure (based on zimmerman et al., 2016).
cartoon depicting the structural characteristics of tetraspanins.
tetraspanins have four transmembrane domains (tm1-tm4), which create one small (ec1) and one large (ec2) extracellular loop as well as a short inner loop.
the n- and c-termini of tetraspanins are localized to the intracellular side of the membrane.
the cys-cys-gly amino acid motif is depicted in addition to the two characteristic disulfide bonds that are formed in ec2.
in addition to the defining features of tetraspanins, many members of the tetraspanin family also contain post-translational modifications.
for example, tetraspanins may be palmitoylated at membrane proximal cysteine residues, which was demonstrated to regulate protein-protein interactions (berditchevski et al., 2002; charrin et al., 2002; yang et al., 2002, 2004).
meanwhile, tetraspanins can also be n-linked glycosylated at asparagine residues, which is less clearly understood (ono et al., 1999; stuck et al., 2012; marjon et al., 2016).
tetraspanins may also be ubiquitinated at cytoplasmic sites, which contributes to their down-regulation (lineberry et al., 2008; wang y. et al., 2012).
an example structure of tetraspanin cd82 is depicted in figure 2, with the post-translational modifications highlighted.
how these tetraspanin post-translational modifications impact signal transduction will be addressed in more detail later in this review.
figure 2 cd82 structure and motifs.
cartoon depicting cd82 topology within the plasma membrane and important motifs.
cd82 contains five membrane proximal cysteine residues (shown in green) at residues 5, 74, 83, 251, and 253, which can be palmitoylated.
there are three asparagine residues in ec2 (shown in orange) that are predicted to be n-linked glycosylated at residues 129, 157, 198. there are four cytoplasmic lysine residues 7, 10, 263, and 266 (shown in gray), which are predicted to be ubiquitinated.
the c-terminal tyrosine based sort motif (yxxø) is depicted in blue at amino acids 261–264; for cd82 this motif is tyr-ser-lys-val.
through their function as molecular scaffolds, tetraspanins contribute to organismal development, reproduction, and immunity (kaji et al., 2000, 2002; le naour et al., 2000; miyado et al., 2000; garcía-frigola et al., 2001; levy and shoham, 2005; jarikji et al., 2009; van spriel, 2011; han et al., 2012).
consistent with their expression being primarily found in multicellular organisms, it is not surprising that many processes to which tetraspanins contribute center around cell-cell- interactions.
additionally, numerous tetraspanins are also associated with the development and progression of disease, in particular, with respect to cancer and cancer cell-niche interactions (zoller, 2009; hemler, 2013).
although tetraspanins do not have known adhesive ligands or catalytic activity, they contribute to cellular physiology by organizing molecules within the plasma membrane into microdomains.
the proposed function of tetraspanins is to organize the plasma membrane by facilitating the formation of what are termed tetraspanin enriched microdomains (tems).
tems consist of homophilic and heterophilic interactions amongst tetraspanins, interactions between tetraspanins and other membrane proteins, as well as interactions between tetraspanins and proteins at the membrane/cytoplasm interface (hemler, 2005; charrin et al., 2009, 2014; stipp, 2010).
moreover, these protein associations can occur through direct binding between tetraspanins and other proteins or through tetraspanin interactions with a common binding partner.
interactions between tetraspanin and signaling molecules have been detected for various types of proteins, including adhesion and signaling receptors, and cytosolic signaling molecules, which are depicted in figure 3. the downstream cellular consequences of these interactions vary, ranging from regulation of cellular adhesion, migration, contractility and morphology.
as recent comprehensive reviews focused on tetraspanin regulation of immune signaling are available (levy and shoham, 2005; halova and draber, 2016), we will discuss other major classes of signaling molecules regulated by tetraspanins, as well as the cellular consequences of such regulations.
figure 3 tetraspanin enriched microdomains with signaling molecules.
illustration of the plasma membrane depicting tetraspanin interactions with membrane and cytosolic signaling molecules.
the downstream signaling consequences attributed to tetraspanin regulation are indicated beneath.
key signaling molecules modulated by tetraspanins include: (a) adhesion-mediated signaling (integrins/fak), (b) receptor-mediated signaling (gpcrs, egfr, c-kit, c-met, adams, tgf), and (c) intracellular signaling (pkc, pi4k, rho-gtpases, and β-catenin).
tetraspanins and adhesion-mediated signaling one of the most prominent classes of adhesion receptors which tetraspanins are known to regulate is the integrin family of proteins.
integrins are heterodimeric proteins consisting of one α and one β subunit, and this combination of subunits dictates their ligand specificity (humphries et al., 2006).
numerous studies identified direct and indirect interactions between integrins and tetraspanins (slupsky et al., 1989; rubinstein et al., 1994; berditchevski et al., 1996; mannion et al., 1996; yáñez-mo et al., 2001, 1998; stipp and hemler, 2000; berditchevski, 2001).
though integrins lack intrinsic catalytic activity, they propagate signals through a variety of cytoplasmic signaling molecules, many of which are components of focal adhesions (schwartz, 2001).
through a combination of imaging and biochemical studies, researchers showed that tetraspanins colocalize with the focal adhesion proteins vinculin and talin as well as myrstoylated alanine-rich c-kinase substrate (marcks), which is involved in pkc-mediated signaling (berditchevski and odintsova, 1999).
moreover, signaling downstream of integrins is also mediated by the focal adhesion kinase, which is further regulated by tetraspanins as indicated below.
focal adhesion kinase focal adhesion kinase (fak) is a cytosolic protein which can interact directly with the integrin cytoplasmic tail, thereby allowing integrins to link to the actin cytoskeleton and promote downstream signaling (schlaepfer et al., 1999).
immunoprecipitation studies demonstrated that tetraspanins cd9, cd63, cd81, cd82, and cd151 interact with the phosphorylated form of fak (berditchevski and odintsova, 1999).
additionally, cells plated on anti-tetraspanin monoclonal antibodies demonstrated reduced fak phosphorylation, further suggesting that tetraspanin scaffolding can contribute to fak activation.
as suggested, a number of tetraspanins have been implicated in fak regulation.
it was shown that the sirna knockdown of cd151 resulted in diminished phosphorylation of fak, p130cas, paxillin, and src (yamada et al., 2008).
in fact, treatment with a cd151 monoclonal antibody, which reduced cd151 interactions with α3β1, also led to a reduction in fak phosphorylation.
in an attempt to rescue this phenotype, control or cd151 knockdown cells were treated with a β1 integrin activating antibody and these data demonstrated that fak phosphorylation could not be rescued under enforced integrin activation.
as such, this study provides evidence that tetraspanins may regulate integrin-mediated signaling through a mechanism independent of initial integrin activation.
the authors quantified fak autophosphorylation (tyr397), which is a fak modification stimulated by integrin clustering (schlaepfer et al., 1999).
as tetraspanins have been previously demonstrated to regulate integrin clustering (van spriel et al., 2012; termini et al., 2014), perhaps the loss of cd151 diminishes integrin clustering, thereby reducing fak phosphorylation.
additionally, the presence of cd151 increased fak and src phosphorylation in response to plating on extracellular matrix components, which modulated gtpase activation and downstream cell migration (hong et al., 2012).
the authors demonstrated that there is a greater increase in fak and src activation in response to plating on laminin than fibronectin, which is consistent with previous findings that cd151 is closely associated with laminin binding integrins (berditchevski et al., 2002; stipp, 2010).
another tetraspanin identified to regulate fak activity is cd9.
in the case of lymphatic dermal endothelial cells, cd9 knockdown diminished fak phosphorylation in response to vegf-1 administration, demonstrating that tetraspanin regulation of fak signaling can occur through multiple activating stimuli (iwasaki et al., 2013).
the authors further demonstrated that this cd9-mediated reduction in post-adhesion signaling impaired lymphangiogenesis.
consistent with previous studies of cd151 (yamada et al., 2008), rocha-perugini et al.
demonstrated that silencing of cd151 or cd9 reduced the expression of phospho-fak and phospho-erk in response to t-cell engagement (rocha-perugini et al., 2014).
a decrease in the accumulation of activated β1 integrins and phospho-fak was also detected at the immune synapse in cd9 and cd151 knockdown cells, suggesting that cd9 and cd151 promote the recruitment to and retention of integrins at the immune synapse, which results in diminished integrin downstream signaling.
therefore, the influence that tetraspanins have on integrin localization provides a critical means to regulate integrin-mediated signaling.
though not technically considered a tetraspanin, the l6 tetraspan protein, tm4sf5, has sequence characteristics and structural properties similar to tetraspanins (wright et al., 2000).
it was shown that the intracellular loop of tetraspan tm4sf5 is critical for promoting an interaction between tm4sf5 and fak (jung et al., 2012).
the authors performed in vitro pull-down assays using the n- or c-terminal cytoplasmic regions of tm4sf5 or the tm4sf5 intracellular loop to assess fak binding.
it was found that only the intracellular loop interacted with fak, although the precise sites of association remain unknown.
future studies focused on identifying the particular amino acid residues within tetraspans that promote this association may offer potential targets to attenuate fak signaling, which can be deregulated in numerous types of cancer (sulzmaier et al., 2014).
tetraspanins and receptor-mediated signaling g-protein coupled receptors g-protein coupled receptors (gpcrs) are seven membrane-spanning proteins that transmit signals with the help of intracellular g proteins (kobilka, 2007).
upon ligand binding, gpcrs can be coupled to gα, gβ, and gγ subunits to activate numerous cellular responses including calcium and potassium channel regulation, as well as phospholipase c (plc) and phosphoinositide 3-kinase (pi3k) signaling (tuteja, 2009).
with the use of model systems such as drosophila, it was determined that tetraspanins can regulate gpcr-mediated signaling.
for example, the drosophila-specific tetraspanin, sunglasses or sun, is required for the light-induced down-regulation of rhodopsin, a light-sensitive gpcr (xu et al., 2004).
interestingly, sun was concentrated in the retina and removal of sun resulted in retinal degeneration.
moreover, the authors determined that in flies with reduced sun expression, extended exposure to light resulted in the diminished ability to down regulate rhodopsin.
in line with these findings, sun is most closely related to human tetraspanin, cd63, which is enriched within the lysosome (metzelaar et al., 1991).
therefore, it is likely that sun assists with gpcr signal attenuation by directing its endosomal trafficking in a similar manner to cd63.
additionally, an interaction between sun and the gq subunit of rhodopsin was identified, which was further proposed to help sun promote the endocytosis of rhodopsin (han et al., 2007).
the regulation of gpcrs by human tetraspanins has also been explored.
it was shown that the gpcr, gpr56, associates with tetraspanins cd9 and cd81 (little et al., 2004; xu and hynes, 2007), two tetraspanins which have also been demonstrated to interact with one another (stipp et al., 2001).
through the use of mass spectrometry, it was also determined that the g protein subunits, gα11 gαq and gβ associate with cd81 and further immunoprecipitation studies demonstrated that this association is not detected with tetraspanins cd63 or cd151 (little et al., 2004).
the authors postulate that perhaps the regulatory role of tetraspanins with respect to gpcrs may be to enhance ligand binding and downstream signaling, though this has yet to be directly tested.
important future studies will involve the analysis of downstream signaling through tetraspanin-mediated changes in gpcrs, including the potential regulation of gpcr-ligand affinity.
epidermal growth factor receptor in addition to gpcrs (metzelaar et al., 1991; xu et al., 2004; han et al., 2007) and integrins (he et al., 2005; winterwood et al., 2006; termini et al., 2014), tetraspanins have also been demonstrated to regulate the trafficking and signaling downstream of the epidermal growth factor receptor (egfr).
egfr is a transmembrane receptor that can be activated by numerous ligands including epidermal growth factor (egf) and transforming growth factor-α (tgf-α).
ligand binding induces egfr dimerization, which enhances egfr catalytic activity (jura et al., 2009; valley et al., 2015).
moreover, egfr endocytosis can serve as both a positive and negative regulatory signaling mechanism (tomas et al., 2014).
the contribution of tetraspanins in mediating egfr trafficking has been extensively studied (odintsova et al., 2000, 2003; berditchevski and odintsova, 2007).
through a series of immunoprecipitation studies, it was shown that tetraspanin cd82 associates with egfr and the overexpression of cd82 controls the phosphorylation kinetics of egfr, grb2, and shc (odintsova et al., 2000).
it was determined that this regulation mediates the morphological response of hb2 cells to egf stimulation.
interestingly, in cells expressing cd82, there was a more rapid down-regulation of egfr upon egf stimulation compared to cells that do not express cd82, indicating that cd82 contributes to egfr down-regulation through modified internalization kinetics.
this led the authors to suggest that the presence of cd82 modulates the signaling potency of the receptor even before it is activated.
furthermore, the authors speculate that the combination of reduced cd82 and increased egfr expression may lead to uncontrolled signaling.
therefore, cd82, and likely other tetraspanins, may provide a means to attenuate signaling through modulations in egfr trafficking.
a follow-up study found that cd82 negatively regulates ligand-induced dimerization of egfr, but does not affect the dimerization of erbb2 or erbb3 (odintsova et al., 2003).
although the authors did not examine the downstream effects of altered dimerization, they suggest that the differential compartmentalization of egfr by cd82 might alter cellular signaling.
further studies examined the role of the vesicular associated membrane protein (vamp), ti-vamp, and cd82 in regulating the surface dynamics of egfr.
in this study, knockdown of cd82 led to increased egfr endocytosis upon egf stimulation through increased ap-2 recruitment (danglot et al., 2010).
furthermore, cd82 knockdown also altered the egfr diffusion patterns on the plasma membrane and reduced erk phosphorylation upon egf stimulation, providing evidence that tetraspanins can regulate the spatial dynamics of proteins for controlling downstream signaling.
this report provides a unique mechanism by which cd82, through cooperation with ti-vamp and ap-2, can regulate egfr signaling and surface dynamics.
moreover, the authors propose that these regulatory mechanisms may be in part controlled by cd82-mediated alterations in actin dynamics or the membrane lipid composition.
egfr regulation by cd82 was also shown to mediate ganglioside production.
more specifically, the overexpression of cd82 in combination with inhibition of ganglioside production resulted in increased egfr phosphorylation in response to egf stimulation (li y. et al., 2013).
the authors speculate that significant interplay occurs between glycosphingolipid enriched microdomains and tems, which cooperatively regulate cellular signaling.
the overexpression of cd82 might promote egfr clustering, which may stimulate dimerization and thereby enhance downstream egfr signaling.
alternatively, the reduction in ganglioside production might improve egfr phosphorylation by reorganizing the receptors into clusters within tems, since gangliosides have been demonstrated to contribute to tem organization (odintsova et al., 2006).
beyond the prominent role of cd82 in regulating egfr, additional studies also identified cd9 as a mediator of egfr signaling.
with the use of an autocrine system of mdck cells co-expressing cd9 and tgf-α, tgf-α stimulation promoted egfr activation (shi et al., 2000).
the authors also utilized a paracrine system whereby cho cells expressing tgf-α alone or tgf-α and cd9 together were plated with 32d cells expressing egfr.
this experiment demonstrated that co-expression of tgf-α and cd9 increases egfr activation, although the precise mechanism by which cd9 modulates egfr signaling remains unclear.
regardless, this study provides unique insight into how cd9 may regulate cellular signaling initiated through contact between adjacent cells.
interestingly, another report investigated the effect of cd9 expression on egfr signaling, finding that increased expression of cd9 resulted in decreased phosphorylation of egfr, shc, and total grb2 expression (murayama et al., 2008).
though these studies demonstrate opposing effects of cd9 on egfr, they also indicate that tnf-α plays a role in mediating egfr activation through cd9.
these studies open the possibility that other tetraspanins such as cd82 may also work in concert with tnf-α, similar to cd9 and tnf-α in mediating egfr activation.
therefore, future analyses would benefit from examining the interplay of tnf-α with other tetraspanins in regulating egfr signaling.
c-kit the stem cell factor receptor or c-kit (cd117) is a receptor tyrosine kinase that binds to its ligand, stem cell factor (scf), which is also known as steel factor (slf) or kit ligand (lennartsson and rönnstrand, 2012).
c-kit signaling can activate several signaling cascades, including pi3k, src family kinases, and mapk to name a few.
moreover, c-kit mediated signaling can control numerous cellular processes including migration, survival and the differentiation of hematopoietic progenitor cells.
with the use of immunoprecipitation studies, it was determined that c-kit associates with tetraspanins cd9, cd63, and cd81 and this interaction was enhanced upon treatment with scf (anzai et al., 2002).
although the authors found increased phosphorylation of c-kit within the immunoprecipitated fraction, they determined that this does not enhance kinase activity in response to scf treatment.
rather, the kinetics of scf binding to c-kit were altered when c-kit associated with cd63.
the authors suggest that this might be because free c-kit is internalized upon scf binding, implying that perhaps the cd63/c-kit complex is more stable on the cellular surface.
while this study alludes to a role for tetraspanins in regulating c-kit phosphorylation, further analysis is necessary to determine the downstream consequences of tetraspanin mediated c-kit activation.
additionally, the possibility that tetraspanins, such as cd63, might stabilize c-kit and modulate signaling through alterations in protein trafficking could have significant impact on specific leukemias where c-kit expression and activation are known to be dysregulated (ikeda et al., 1991; goemans et al., 2005; boissel et al., 2006; corbacioglu et al., 2006; paschka et al., 2006).
c-met c-met is a receptor tyrosine kinase that can activate numerous pathways to promote cellular survival, motility, and proliferation (birchmeier et al., 2003).
hepatocyte growth factor (hgf) binding to c-met causes c-met dimerization, which helps to initiate various cellular signaling cascades including akt, erk/mapk, and jnk (organ and tsao, 2011).
furthermore, the overexpression of cd82 diminished the phosphorylation of c-met in response to integrin ligand engagement, resulting in reduced src phosphorylation (sridhar and miranti, 2006).
in the case of invasive tumor situations, the authors' data suggest that the loss of cd82 leads to enhanced activation of c-met through integrin activation.
although the regulatory mechanism remains unknown, this study provides a clear indication that tetraspanins can modulate c-met mediated signaling downstream of integrin engagement.
it was also shown through immunoprecipitation studies that cd82 and c-met interact (takahashi et al., 2007).
moreover, the authors demonstrated that upon the ectopic expression of cd82, activation of c-met with hgf led to increased formation of lamellipodia and filipodia through modulations in gtpase activities.
additionally, the ectopic expression of cd82 also prevented c-met association with grb2 and pi3k, implicating that cd82 has an inhibitory role with respect to these binding events.
as such, perhaps the grb2 and pi3k binding sites within c-met become inaccessible in the presence of the c-met/cd82 interaction.
the regulatory role of cd82 with respect to c-met-mediated signaling has also been extended to controlling erk1/2 and akt signaling in hepatocellular carcinoma cells (li y. et al., 2013).
an alternative report focused on cd151 with respect to met signaling, showing that knockdown of cd151 led to diminished hgf-induced proliferation (franco et al., 2010).
the researchers determined that cd151 knockdown decreased tyrosine phosphorylation of the β4 integrin subunit, which decreased mapk signaling through erk in response to hgf.
therefore, this study suggests that the c-met-cd151-β4 complex is critical for mapk signaling.
while the molecular link between tetraspanins and erk or akt downstream of c-met remains an open question, this work implicates integrins as a possible connection.
transforming growth factor signaling transforming growth factor α (tgf-α) is synthesized as a transmembrane protein, which can become cleaved by metalloproteinases to release soluble tgf-α (pandiella and massagué, 1991).
this cleavage is stimulated by endotoxins (breshears et al., 2012; liu z. et al., 2013) and ros (boots et al., 2009) and is mediated primarily by adam17 (peschon et al., 1998), but also by adam10 (hinkle et al., 2003) and meprina (bergin et al., 2008; minder et al., 2012; singh and coffey, 2014).
moreover, tgf-α can interact with and activate egfr on neighboring cells (schlessinger and ullrich, 1992; thorne and plowman, 1994; moral et al., 2001).
an association between cd9 and transmembrane tgf-α was identified and found to be dependent on the tgf-α ectodomain (shi et al., 2000).
the experimenters illustrated that the cleavage of tgf-α was inhibited by cd9, implicating a role for the association between cd9 and tgf-α as a means of protecting tgf-α from proteolytic cleavage.
the authors suggested that the inhibition of tgf-α cleavage feeds into enhanced tgf-α induced egfr activation, which can increase cellular proliferation.
this study provides evidence that tetraspanins, such as cd9, can promote cellular signaling by stabilizing transmembrane proteins, thereby providing a potent activation stimulus to mediate juxtacrine signaling.
protein kinase c (pkc) and mapk signaling can also regulate tgf-α cleavage (baselga et al., 1996; fan and derynck, 1999).
as tetraspanins can regulate pkc and mapk signaling (zhang et al., 2001; termini et al., 2016), a closer examination into the interplay between these molecules in mediating tgf-α signaling may provide a more comprehensive view of the complex regulatory networks at play within tems.
a follow up study demonstrated that cd9 expression enhances tgf-α expression at the cell surface using mdck cells (imhof et al., 2008).
here, cd9 was shown to promote the trafficking of tgf-α from the golgi to the cell surface by stabilizing the glycosylated and prodomain-removed forms of tgf-α.
furthermore, the authors demonstrated that the expression of tgf-α and cd9 alters actin organization and focal adhesion formation, supporting the notion that the combination of cd9 and tgf-α expression produces dramatically different signaling responses than the expression of tgf-α alone.
therefore, the tetraspanin expression profile should be considered when characterizing tgf-α signaling, particularly in many cancers where tgf-α expression is thought to support cancer progression (kenny and bissell, 2007).
additionally, the contribution of tetraspanins to the regulation of the tgf isoform tgf-β1 has been assessed.
researchers used cd151 knockdown mda-mb-231 cells and determined that in the presence of tgf-β1, cd151 knockdown cells had a significantly decreased proliferative rate compared to control cells (sadej et al., 2010).
more specifically, in the cd151 knockdown cells, tgf-β1 stimulation led to reduced p38 phosphorylation, resulting in decreased metastasis.
mechanistically, the authors propose that cd151 modulations of the plasma membrane may alter the distribution of tgf-β1 receptors and downstream signaling.
future studies may focus on determining how cd151 modulates the molecular organization of the tgf receptor, as this may provide a mechanism to regulate downstream signaling.
a disintegrin and metalloproteases the a disintegrin and metalloprotease (adam) family of transmembrane and secreted proteins contribute to the regulation of cellular adhesion, migration, proliferation, and signaling (seals and courtneidge, 2003).
as the name states, adams contain a disintegrin and a metalloprotease domain.
while the metalloprotease domain can cleave extracellular matrix (ecm) components and mediate ectodomain shedding of cytokines, growth factors, the disintegrin domain can interact with integrins.
recent comprehensive reviews provide insight on the role that tetraspanins play in regulating membrane proteases, with a particular emphasis on their role in regulating adam10 and adam17 (yáñez-mo et al., 2011; matthews et al., 2016).
initial reports demonstrated that adam10 is associated with cd9, cd81, and cd82, indicating that adam10 likely exists within tems.
interestingly, treatment with anti-tetraspanin antibodies stimulated the release of tnf-α and egf in an adam10-mediated manner.
furthermore, through mass spectrometry studies and extensive immunoprecipitation studies, tspan12 was found to associate with adam10, which contributed to the ability of adam10 to process amyloid precursor protein for shedding (xu et al., 2009).
using several mutated tspan12 constructs, this association was determined to be regulated by ec1, the c-terminal tail and tspan12 palmitoylation.
more recent co-immunoprecipitation studies revealed that the subgroup of tspanc8 tetraspanins (tspan5, 10, 14, 15, 17, and 33) interact with adam10 (dornier et al., 2012).
additionally, adam17 was also found to associate with tetraspanin cd9 in leukocytes and endothelial cells, which diminishes adam17-mediated tnf-α and icam-1 shedding.
interestingly, cd9 can regulate the catalytic activity of adam17 with regards to shedding of lr11 in monocytes, promonocytes and b-lymphoblastoid cell lines (tsukamoto et al., 2014).
as adams are implicated in regulating various cancer cell types (mochizuki and okada, 2007), the role of tetraspanins in regulating adams in malignant cells will provide significant insight and perhaps a means to attenuate aberrant adam activity.
adams are produced as immature, inactive, preforms in the endoplasmic reticulum.
during trafficking from the er to the plasma membrane, the enzyme's prodomain is removed and adams are then rendered catalytically active (seals and courtneidge, 2003).
interestingly, it was determined that tspanc8 contributes to adam10 maturation and ultimately the stabilization of adam10 at the cell surface (prox et al., 2012).
furthermore, tspan33 knockdown in erythrocytes resulted in diminished adam10 surface expression.
meanwhile, adam10 surface expression remained unchanged in platelets, demonstrating that tetraspanin regulation of adam10 is likely cell-type specific (haining et al., 2012).
additionally, the role of tspan33 in regulating adam10 for the control of macrophage activation was recently explored (ruiz-garcía et al., 2016).
researchers utilized tspan33 overexpressing raw 264.7 cells and demonstrated that increased tspan33 expression results in increased adam10 processing, consistent with the earlier aforementioned studies.
tetraspanins and intracellular signaling although tetraspanins are known to primarily affect the properties of other membrane proteins, they have also been shown to regulate cytoplasmic signaling molecules.
signaling proteins are often recruited to the cytoplasmic interface of the plasma membrane where they initiate signaling and tems can serve as a potential membrane recruitment site.
therefore, in the following section, we will review how tetraspanins control the localization, kinetics, and signaling properties of cytosolic proteins.
protein kinase c the protein kinase c (pkc) family of intracellular signaling proteins consists of isoforms, which are further classified into conventional, novel or atypical isoforms (newton, 1995).
pkcs can phosphorylate several targets, including the myosin light chain ii (liu x. et al., 2013), pkd2 (waldron et al., 2001; navarro and cantrell, 2014), ras gefs (jun et al., 2013), and the β1 integrin tail (stawowy et al., 2005), which collectively contribute to the regulation of cell proliferation, apoptosis, and adhesion amongst other cellular behaviors (kang, 2014).
the interaction between tetraspanins and pkc was originally demonstrated in k562 cells using an elaborate series of immunoprecipitation experiments (zhang et al., 2001).
the experimenters used phorbol 12-myristate 13-acetate (pma), which mimics diacylglycerol (dag) to activate pkc (castagna et al., 1982).
under pma stimulated conditions tetraspanins cd9, cd53, cd81, and cd82 individually interact with pkcα and not with pi3k.
additionally, they determined that cd81 and cd151 associate with pkcβii.
moreover, in a pkcα pull-down, β1, α3, and α6 integrins were detected in complex with pkc.
therefore, it was suggested that tetraspanins serve to link pkc to integrins.
in order to assess the tetraspanin domains that control pkc associations, chimeric mapping was performed by replacing portions of cd9 with portions of the non-pkc associating tetraspanin, a15/talla1.
these findings demonstrated that pkc association with tetraspanins occurs outside of the short inner loop, the large outer loop, and transmembrane 3 or 4. a recent report also demonstrated that tetraspanin cd151 regulates skin squamous cell carcinoma through stat3 and pkcα signaling (li q. et al., 2013).
utilizing wild type or cd151 ablated a431 epidermoid carcinoma cells, it was shown that the loss of cd151 reduces stat3 activation in response to 12-o-tetradecanoylphorbol-13-acetate (tpa) stimulation, which is another known activator of pkcα.
the authors found that pkcα only associates with α6β4 upon tpa stimulation when cd151 is present.
together, these data suggest that perhaps the role for cd151 is to recruit pkcα into close proximity with the α6β4 integrin, which ultimately aids in the phosphorylation of α6β4.
as such, these data build upon previous implications that tetraspanins link pkc to integrins (zhang et al., 2001), but also provide evidence that this scaffolding is important for epidermal proliferation and stat3 activation.
another interesting report investigated how cd9, cd81, and cd151 expression affects pkcα association with tems (gustafson-wagner and stipp, 2013).
it was demonstrated that cd9/cd81 knockdown diminishes the ability for the α3 integrin to associate with pkcα, which delays cell spreading on laminin and directed migration.
in contrast, cd151 knockdown enhanced the association of pkcα with the α3 integrin, while promoting cell migration on collagen-i.
the authors propose that cd9/81 may serve as linkers of pkc to the α3 integrin subunit, or there might be an indirectly associating molecule at play.
furthermore, the authors propose that perhaps upon cd151 depletion, there is increased association between pkc and α3 due to the loss of cd151, which makes cd9/81 available to fully associate with α3, thereby promoting pkc-integrin association.
this study provides substantial evidence that the roles of tetraspanins cd9, cd81, and cd151 are unique in their regulation of pkcα-integrin interactions.
further examination into the regulatory role of tetraspanins with respect to pkc-mediated signaling has uncovered many unique cellular responses.
for example, treatment of a431 cells with calphostin c to inhibit pkcα reduced filipodia extensions as well as e-cadherin puncta formation, demonstrating the involvement of actin in tetraspanin-regulated pkc signaling (shigeta et al., 2003).
the authors suggest that cd151 directly or indirectly associates with pkcα, which they propose may activate cdc42 to promote filipodia formation.
a more recent report from our laboratory demonstrated that cd82 regulates pkcα signaling in acute myeloid leukemia (aml) (termini et al., 2016).
using quantitative fret imaging and kg1a aml cell lines that overexpress wild type cd82 or a palmitoylation deficient form of cd82 (delandre et al., 2009), we found that upon pma stimulation, pkcα was recruited to the plasma membrane where it associates with cd82.
however, upon extended pma stimulation, this pkcα/cd82 association is reduced in cells overexpressing the palmitoylation deficient form of cd82, demonstrating that the palmitoylation of cd82 regulates the stability of the pkcα interaction.
we went on to use super-resolution imaging to examine how the scaffolding properties of cd82 regulate the macromolecular clustering of pkcα and found that upon disruption of the cd82 scaffold, there is a significant reduction in the size of pkcα clusters.
moreover, using cd82 knock-down cells, we found that while pkcα is still recruited to the membrane upon pma stimulation, large-scale pkcα clusters are not detected.
this change in pkcα clustering was then linked to alterations in downstream erk1/2 signaling that influenced the aggressive phenotype of aml (termini et al., 2016).
interestingly, the kinetics of pkcα oligomerization were recently quantified and modeled using hek cells where they found that the intramolecular clustering of pkcα contributes to downstream phosphorylation (bonny et al., 2016).
collectively, these studies illustrate that the modulation of signaling molecule clusters may serve as an important regulatory mechanism for stabilizing and/or attenuating signal transduction pathways.
moreover, our work implicates tetraspanins as critical mediators of cluster size and stability.
future super resolution imaging studies focused on identifying how the clustering of tetraspanins can modulate downstream signaling through pkc and other molecules such as rac or cdc42 would be valuable to help clarify how tetraspanins and pkcα mediate cytoskeleton-dependent cellular responses such as adhesion and migration.
an interesting link was also discovered between pkc and egfr-mediated signaling that is enhanced by cd82.
c-cbl is an ubiquitin ligase recruited to egfr where it assists with receptor down-regulation (joazeiro et al., 1999).
the authors found that pkc mediates c-cbl phosphorylation upon egf stimulation in cd82 expressing h2b cells (odintsova et al., 2013).
the phosphorylation of c-cbl serves as a negative regulator of enzyme function (ryan et al., 2006), which may be responsible for inhibiting egfr downregulation.
therefore, without cd82 present, egfr can be quickly downregulated as pkc is not present to regulate c-cbl.
collectively, these studies provide substantial evidence that implicates tetraspanins as signaling scaffolds that promote the close proximity of pkc with integrins, egfr and cytoplasmic proteins like c-cbl.
phosphatidylinositol 4-kinase phosphatidylinositol 4-kinase (pi4k) catalyzes the conversion of phosphatidylinositol (pi) to phosphatidylinositol 4-phosphate (pi4p), which is an important intermediate for lipid-mediated signaling (clayton et al., 2013).
a series of biochemical experiments demonstrated that pi4k exists within α3 integrin and cd63 containing tems (berditchevski et al., 1997).
the authors suggest that perhaps tems are responsible for linking the α3β1 integrin to pi4k.
a follow up study from the same group explored this further, demonstrating that immunoprecipitation of α3 or cd151 yields similar levels of pi4k activity based upon pi4p production (yauch et al., 1997).
additionally, using cells with diminished α3 expression, cd151 was pulled down, demonstrating that there is still pi4k associated with the complex.
conversely, immunodepletion of cd151 resulted in significantly diminished lipid kinase activity associated with α3, while cd63 and/or cd81 deletion did not have as significant of an effect.
collectively, these data implicate cd151 as a critical linker between pi4k and α3β1, which the authors suggest may support cell migration.
a subsequent follow up study demonstrated that pi4k associates with tetraspanins a15/talla1, cd63, cd151, cd9, and cd81, however it does not appear to associate with nag-2, cd53, cd37, or cd82 (yauch and hemler, 2000).
moreover, pi3k and pi4p5k activity were not detected in cd63, cd81, and cd151 complexes, indicating that perhaps the association is specific to pi4k.
studies with cd9/cd82 chimeras were unsuccessful at determining the site of association with pi4k.
therefore, a closer examination into the structural domains within tetraspanins that contribute to their association with pi4k could provide insight into the mechanism by which tetraspanins may regulate the catalytic activity of pi4k and downstream responses.
gtpases rho gtpases mediate signal transduction by switching between a gtp-bound (active) and gdp-bound (inactive) state (bishop and hall, 2000).
there are numerous effector proteins downstream of gtpases including pi3k, pi-4-p5k, mekk1, and dag kinase.
the rho family gtpases rac1, rhoa, and cdc42 as well as the ras family of gtpases translocate to the plasma membrane upon activation (collins, 2003), where their regulation by tetraspanins continues to be defined.
for example, cd151 was demonstrated to regulate cdc42 for the control of cellular adhesion.
using a431 cells, cd151 antibody treatment or cd151 overexpression was found to increase cdc42 activation, which the authors suggest controls actin reorganization, promoting filopodia-based adhesions (shigeta et al., 2003).
another study assessed how the coexpression of cd9 and tgf-α regulates gtpase signaling, finding increased and decreased levels of activated rac1 and rhoa respectively, with cdc42 levels remaining unchanged upon coexpression of cd9 and tgf-α (imhof et al., 2008).
this shift in signaling was determined to be due to enhanced egfr signaling, which ultimately contributed to enhanced stress fiber formation.
additionally, the overexpression of cd82 was shown to decrease the proportion of gtp-bound rac1, while rhoa and cdc42 levels remained unchanged (liu et al., 2012).
previous work also demonstrated that cd151 promotes the association between cd151-β1 complexes and ras, rac1 or cdc42.
immunofluorescence imaging showed that cd151 regulates the translocation of rac1 and ras to the membrane and promoted colocalization with β1 integrins (hong et al., 2012).
interestingly, through the use of a cd151 chimera with disrupted α3β1 integrin association, the authors showed that this mutant is unable to recruit rac1 to the membrane.
therefore, integrins also have the capacity to link gtpases to tetraspanins in a manner similar to what was previously proposed for pkc and tetraspanins (zhang et al., 2001; li q. et al., 2013).
an association between rac1 and the c-terminal, cytoplasmic region of cd81 has also been suggested based on the use of an eight amino acid c-terminal tail peptide (tejera et al., 2013).
future experiments that mutate or delete the cd81 c-terminal tail will be important to demonstrate that such a mutation eliminates rac1 association, further validating the interaction.
furthermore, upon egf stimulation, it was shown that knockdown of cd81 increases rac activation.
a more recent study identified a correlation between cd9 expression and gtp bound rac1 expression in acute lymphoblastic leukemia patient samples (arnaud et al., 2015).
moreover, this group also determined that the c-terminal tail of cd9 is important for regulating rac1 activation.
interestingly, the c-terminal region of cd9 has two known palmitoylation sites (charrin et al., 2002), and rac can also be palmitoylated (tsai and philips, 2012).
therefore, it is possible that these post-translational modifications may help to anchor tetraspanins and gtpases into similar membrane compartments.
tetraspanin regulation of rhoa signaling, which can promote changes in cytoskeletal organization, has also been characterized (sit and manser, 2011).
using human aortic smooth muscle cells, cd9 knockdown decreased the expression of gtp-bound rhoa, leading to defects in cellular morphology, spreading and contraction (herr et al., 2014).
the authors suggest that integrins are involved in cd9-mediated alterations in rhoa activation by possibly stabilizing integrin-ecm interactions, augmenting rhoa activation.
interestingly, a recent report demonstrates that the loss of cd151 in breast cancer cells resulted in increased rhoa activation as quantified using fret biosensors (novitskaya et al., 2014).
these data are contrary to hong et al.
(2012), who showed no change in rho activation upon cd151 depletion.
however, the change in fret efficiency detected was <5%, which would likely be below the detection of the small gtpase protein pull-down assays used by hong et al.
moreover, a separate report demonstrated that the knockdown of cd151 in human dermal microvascular endothelial cells resulted in an increase in rhoa-gtp and decreased rac1-gtp (zhang et al., 2011).
future studies focused on the mechanism by which tetraspanins can modulate gtpase activation will be important for determining how certain tetraspanins may be targeted to control specific gtpase activities in specialized cell types.
β-catenin β-catenin is a component of the wnt signaling pathway that binds to the cytosolic portion of cadherins to initiate cellular signaling (valenta et al., 2012).
through this complex formation, β-catenin promotes the internalization and recycling of e-cadherin, thereby destabilizing the complex and ultimately reducing cell-cell adhesion.
researchers determined that ectopic cd82 expression in h1299 cells relocalizes β-catenin to e-cadherin at the cell membrane, which stabilizes complex formation (abe et al., 2008).
furthermore, they showed that ectopic cd82 expression increased cancer cell aggregation.
to assess the downstream consequences of altered β-catenin localization, the authors stimulated cells with egf or hepatocyte growth factor (hgf), demonstrating that ectopic expression of cd82 diminished β-catenin phosphorylation.
while β-catenin phosphorylation is known to destabilize the e-cadherin complex, the mechanism for tetraspanin involvement remains to be clearly defined.
based on our previous work with n-cadherin (marjon et al., 2016), we speculate that the cd82 scaffold might contribute to cadherin clustering, which may stabilize β-catenin membrane interactions, thereby protecting β-catenin from phosphorylation and down-regulation.
more recently, cd63 was shown to stabilize β-catenin signaling.
in this study, shrna knockdown of cd63 decreased β-catenin protein expression levels, which was suggested to occur through diminished levels of inactive gsk3β, leading to increased levels of phosphorylated β-catenin (seubert et al., 2015).
furthermore, decreased levels of the β-catenin targets, mmp-2 and pai-1, were detected, demonstrating cd63-mediated changes in downstream β-catenin signaling.
the authors went on to find that the reduced expression of cd63 diminishes the metastatic potential of lung cancer cells, while the overexpression promoted tumor aggressiveness.
however, modulations in signaling induced by cd63 overexpression were not explored.
a previous study provided evidence that disrupting the interaction between the α3β1 integrin and cd151 enhanced β-catenin phosphorylation (chattopadhyay et al., 2003).
therefore, it is plausible that the combination of integrins and tetraspanins serves to stabilize β-catenin within tems.
tetraspanin post-translational modifications and signaling palmitoylation s-palmitoylation is the addition of a 16-carbon fatty acid chain, palmitate, to cysteine residues of either cytoplasmic or membrane proteins (blaskovic et al., 2013).
palmitoylation of cytoplasmic proteins promotes membrane anchoring, while palmitoylation of membrane proteins facilitates trafficking and membrane organization.
palmitoylation has been confirmed for tetraspanins cd9, cd151 (yang et al., 2002), cd81 (delandre et al., 2009), and cd82 (mazurov et al., 2007), however other tetraspanins also contain conserved cysteine residues that are predicted to be palmitoylated.
the defined role for palmitoylation is to modulate tem formation (yang et al., 2004).
therefore, we took a closer examination of how tetraspanin palmitoylation contributes to the signaling that occurs downstream of tem associated proteins.
for example, the expression of the palmitoylation deficient form of cd151 weakened its association with integrins (berditchevski et al., 2002), resulting in diminished phosphorylation of akt in response laminin-5 engagement.
these data indicate that palmitoylation-mediated disruption of tems can reduce downstream signaling responses.
additionally, a palmitoylation deficient form of tetraspanin12 was shown to have diminished association with adam10, resulting in decreased adam10 activity as assessed by app shedding (xu et al., 2009).
recent work from our lab has shown that overexpression of a palmitoylation-deficient form of cd82 diminishes pkc membrane stabilization, reducing erk1/2 activation, and downstream leukemia colony formation (termini et al., 2016).
collectively, these studies demonstrate that tetraspanin palmitoylation contributes significantly to the regulation of downstream cellular signaling.
intracellular signaling molecules such as ras (eisenberg et al., 2013), rac (tsai and philips, 2012), and pkc (ford et al., 1998) can themselves be palmitoylated to assist with their membrane anchorage.
as tetraspanin palmitoylation is thought to regulate lateral protein associations within tems, perhaps tetraspanin palmitoylation functions in concert with the palmitoylation of cytoplasmic proteins to produce stable membrane interactions critical for sustained signaling.
glycosylation although the large extracellular loop of many tetraspanins has been demonstrated to have one or more potential n-linked glycosylation sites, little is known about the functional consequences of this post-translational modification.
the n-glycosylation pattern of cd82 was recently identified using proteomics and glycomics, determining that there are three putative n-glycosylation sites (wang h. et al., 2012).
previously, these sites were suggested to regulate apoptosis, however the researchers did not examine the signaling that led to these apoptotic changes (ono et al., 1999).
interestingly, the photoreceptor-specific tetraspanin retinal degeneration slow (rds) can also be glycosylated (kedzierski et al., 1999; conley et al., 2012).
more recently, the function of rds glycosylation was re-examined by expressing a glycosylation deficient version of rds in mice, which identified differential functional outcomes in cones vs. rod photoreceptor cells (stuck et al., 2015).
moreover, the authors determined that glycosylation regulates the formation of rds complexes with another tetraspanin rom-1, demonstrating that glycosylation can modulate tetraspanin complex formation.
a recent report from our laboratory examined the role of cd82 glycosylation with respect to acute myeloid leukemia homing (marjon et al., 2016).
in this study, we demonstrated that mutation of the three glycosylation sites within cd82 to inhibit glycosylation resulted in increased aml cell homing to the bone marrow, which we linked to increased molecular packing of n-cadherin via super resolution imaging.
although we have yet to examine signaling deficits in cells with disrupted cd82 glycoslation, it is possible that these changes in the molecular organization of n-cadherin may modulate the activation or stability of p120 catenin or β-catenin signaling downstream of n-cadherin.
ubiquitination protein ubiquitination is important for regulating cellular signaling by selectively targeting proteins for degradation.
both cd81 and cd151 were shown to interact with gene related to anergy in lymphocytes (grail), which promotes tetraspanin ubiquitination, ultimately downregulating surface tetraspanin expression (lineberry et al., 2008).
interestingly, it was determined that these tetraspanins can only be ubiquitinated at their n-terminus.
through mutational studies, it was shown that mutation of k8 and k11 diminished the ubiquitination of cd81, while mutation of k8, k11, and k17 ablated the ubiquitination of cd151.
more recently it was demonstrated that tspan6 interacts with the adaptor mitochondrial antiviral signaling (mavs) in 293t cells to inhibit rig-i-like receptor (rlr) mediated signaling (wang y. et al., 2012).
the authors went on to show that induction of rlr signaling promoted the ubiquitination of tspan6 at k11, k16, and k43, which are sites found within the tm1 of tspan6.
additionally, the authors determined that tspan6 ubiquitination serves to inhibit the formation of the signalosome, effectively down-regulating rlr signaling.
as ubiquitination can target proteins for degradation, we suspect that tetraspanin ubiquitination will be a regulatory mechanism to allow for specific and efficient attenuation of tetraspanin-mediated signaling.
concluding remarks tetraspanins and their formation into tems enable the compartmentalization of membrane receptors within the plasma membrane.
in this review, we focus on how tetraspanins also serve to connect these membrane-associated molecules with intracellular signaling complexes.
it is now clear that tetraspanins regulate diverse cell signaling pathways that impact a breadth of biological processes.
however, though numerous signaling molecules have been demonstrated to associate with tetraspanins, the mechanisms by which tetraspanins precisely modulate signal transduction remains relatively undefined.
future studies focused on how domains and motifs within tetraspanins promote or perhaps attenuate cellular signaling will help us understand the specific mechanisms used by this family of proteins to control signaling.
many laboratories are now using sophisticated imaging techniques to provide novel insight into the spatiotemporal interactions mediated by tetraspanins and tems.
these studies will help to define how the scaffolding properties of tetraspanins contribute to the formation, stabilization and dynamics of signal transduction complexes at the plasma membrane.
moreover, these studies may provide the needed insight to establish tetraspanins and tems as potential therapeutic targets for the modulation of aberrant signal transduction that mediates processes such as inflammation, wound healing, and various types of cancer.
author contributions ct and jg wrote and edited the manuscript.
ct created the figures.
all authors reviewed the manuscript.
funding this work was supported by an f31 fellowship from the national heart, lung, and blood institute (f31hl124977 to ct), an american heart association scientist development grant (13sdg14630080 to jg), and an nih investigator grant (ro1hl122483-01 to jg).
support was also provided from nih p50 gm085273 (b. wilson).
conflict of interest statement the authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.
@highlight
tetraspanins are molecular scaffolds that distribute proteins into highly organized microdomains consisting of adhesion, signaling, and adaptor proteins.
many reports have identified interactions between tetraspanins and signaling molecules, finding unique downstream cellular consequences.
in this review, we will explore these interactions as well as the specific cellular responses to signal activation, focusing on tetraspanin regulation of adhesion-mediated (integrins/fak), receptor-mediated (egfr, tnf-α, c-met, c-kit), and intracellular signaling (pkc, pi4k, β-catenin).
additionally, we will summarize our current understanding for how tetraspanin post-translational modifications (palmitoylation, n-linked glycosylation, and ubiquitination) can regulate signal propagation.
many of the studies outlined in this review suggest that tetraspanins offer a potential therapeutic target to modulate aberrant signal transduction pathways that directly impact a host of cellular behaviors and disease states.
