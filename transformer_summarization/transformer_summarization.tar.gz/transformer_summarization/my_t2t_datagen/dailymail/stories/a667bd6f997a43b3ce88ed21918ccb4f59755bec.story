introduction the use of pre-workout beverages (i.e.
red bull®, redline®) is becoming an increasingly common method of improving endurance exercise performance in athletic and recreationally active populations.
these drinks are usually ingested with the goal of eliciting increased performance capacities during exercise.
recent research has suggested that energy drinks are the most popular supplement among adolescents and young adults in america and around the world(4, 12, 18, 28).
a recent study reported that 41.7% of young elite athletes who reported using supplements ingested energy drinks (26).
additionally, approximately 60.2% of the athletes surveyed who ingested energy drinks did so to increase endurance performance (26).
the most commonly used active ingredient found in energy drinks is caffeine.
it has been previously suggested that there are multiple potential mechanisms that lead to positive performance outcomes produced by caffeine.
one potential physiological mechanism by which caffeine is thought to alter strength and power performance is by increasing free fatty acid availability, thus increasing fat oxidation, and decreasing carbohydrate oxidation.
this could potentially increase performance in exercises limited by carbohydrate availability, in turn, increase the efficiency and intensity of muscle contractions by sparing muscle glycogen (23, 28).
in addition, there are two theorized mechanisms located within the central nervous system.
(7) first, evidence suggests that caffeine works primarily through the blockade of adenosine receptors within the central nervous system (7, 11).
this can lead to a decrease in inhibition, leading to an increase in exercise duration.
secondly, caffeine has been shown to inhibit phosphodiesterase (pde), allowing calcium to enter into the cell, and thus increasing contraction force (7).
this is achieved through the inhibition of pde, which prevents the cessation of calcium flowing into the cell (7).
additionally, the lipophilic properties of caffeine allow the substance to cross the blood brain barrier, potentially impacting locomotor activity, which may lead to a lower perceived exertion level and prolonged force production (2, 6).
this increase in the duration of the stimulation on the central nervous system could explain the increase in performance during prolonged exercise (7).
a recent study that examined the effect of a caffeinated energy drink on muscle strength attempted to pinpoint whether the mechanism responsible for performance improvements was central or peripheral in nature (5).
fifteen young, healthy adults ingested either a caffeinated, uncaffeinated, or placebo beverage.
each participant drank a specified amount of the caffeinated beverage (based on body mass) in order to consume 5 mg/kg−1 of caffeine.
the volume of liquid consumed for all of the beverages were equal to the amount of liquid consumed for the caffeinated beverage.
after consuming the beverage, participants then performed a fatiguing protocol of the leg extensors.
results showed a 5% performance enhancement after drinking the caffeinated beverage, when compared to both the uncaffeinated beverage and the placebo.
however, the authors were unable to determine the exact mechanism by which caffeine elicited improvements.
likewise, the authors questioned whether caffeine was solely responsible for this improvement, suggesting that carbohydrate may also play a valuable role (5).
even though the mechanism of action is still unknown, caffeine remains a highly utilized supplement for those looking to increase both anaerobic and aerobic performance.
currently, the recommended dose of caffeine to elicit performance enhancement is 3–6 mg/kg of body weight (13).
several studies have reported performance enhancements in both aerobic and anaerobic capacity after ingesting an energy supplement prior to exercise in a wide-variety of participants ranging from recreationally active to resistance trained athletes (1, 10, 14, 20, 21, 25, 30).
however, other studies have found no performance benefits from caffeine consumption prior to exercise in similar populations (6, 16).
energy drinks featuring caffeine have been shown to increase exercise performance by increasing energy, alertness, reaction time, and performance (8, 9, 19).
many studies have examined the effects of a standardized amount of caffeine on exercise performance (i.e.
mg/kg of body mass).
however, many of these studies lack practicality, because the amount of caffeine contained in commercially available products may be dramatically different than the quantities recommended to produce an ergogenic effect.
examining exercise performance after following guidelines from the manufacturer may be more beneficial to the recreational athlete than standardizing the amount of caffeine ingested.
other studies have examined the effects of a standardized amount of energy drink ingestion on the performance of submaximal (60–80% 1rm) loads during bench press and leg press muscular endurance tests (1, 10, 25).
however, the effects of caffeine ingestion on multiple fatiguing sets of an exercise are unknown.
this insight would provide practical information for those who of ingest commercially available energy drinks prior to fatiguing exercise.
in addition, this information may be extremely valuable to the tactical population, who are not only required to complete a 2 minute push up test, but also consume caffeine in an attempt to prolong their wakefulness and alertness while performing occupational tasks (3).
therefore, the aim of the present study was to investigate the effects of a commercially available energy drink on upper body muscular endurance.
considering the rise in the use of energy drinks and supplements, these results could prove to be beneficial for measuring upper body muscular endurance at in a variety of settings and populations.
we hypothesized that the energy drink supplement would enhance upper body muscular endurance.
methods participants twenty-three healthy males and eight healthy females volunteered to participate in this study.
participants were included in the study if they were familiar with the push-up exercise and reported that they regularly participated in moderate to vigorous intensity exercise at least three times per week for a minimum of 12 weeks prior to enrolling in the study.
participants were excluded from the study if they reported smoking, any known musculoskeletal or nervous system injuries or disorders, metabolic disease, cardiovascular disease, or any psychiatric diseases.
participants were also excluded from the study if they were allergic to any of the following ingredients: sodium, calcium, magnesium, potassium, caffeine anhydrous, l-leucine, phenylethylamine, hcl, l-valine, l-isoleucine, n-acetyl-l-tyrosine, yohimbe, toothed clubmoss, yerba mate extract, green tea extract, 5-htp, or vinpocetine.
the study was approved by the institutional review board at the university prior to collecting data.
subjects were briefed regarding the risks of the study and were required to complete a health history questionnaire, caffeine-usage questionnaire, and a signed written consent form prior to engaging in the study.
descriptive statistics for each group is provided in table 1. protocol the study utilized a randomized, double-blind, placebo controlled, parallel design.
participants were required to visit the laboratory on 2 different occasions.
the 2 trials were separated by no more than 7 days and took place at the exact same time of day.
participants were asked to refrain from consuming any caffeinated food, tablets, or beverages 12 hours prior to each testing session.
participants who reported taking any of these substances within 12 hours of the testing session were excluded from participation.
additionally, participants were also asked to refrain from doing any upper body exercises 48 hours prior to testing.
upon arrival for the first session, participant’s anthropometric measures (height, weight, body composition) were collected.
after removing their shoes, participants stood on a standard beam scale (cardinal/detecto scale co, webb city, mo, usa) for height and weight measurements.
after changing into compression pants, a swim cap, and a sports bra (for females), each participant’s unfasted body composition was assessed using air displacement plethysmograph (bod pod, life measurement inc., concord, ca, usa).
participants were instructed to sit in the unit and remain as still as possible until testing was complete.
the bod pod has been determined to be both valid and reliable (24, 29).
after completion of body composition, participants completed the baseline upper body muscular endurance test.
the second testing session consisted of randomizing the participants into 1 of 2 groups: supplement group (su; n=16) or the placebo group (pl; n=15).
each group was given 4 ounces of a similar beverage, designed by the manufacturer (vital pharmaceuticals, inc. weston, fl) to have the same volume, taste, caloric density, and color as the energy drink beverage.
both groups consumed their respective beverages 30 minutes prior to initiating the upper body muscular endurance test.
this was done in attempt to follow manufacturer instructions suggesting ingesting 4 ounces of the beverage 30 minutes prior to activity.
table 2 contains the ingredients for the energy drink supplement (redline®).
following the 30 minute waiting period, participants completed the upper body muscular endurance test.
the push-up to fatigue test was used to assess upper body muscular endurance (8).
prior to completing this assessment, participants were familiarized with the protocol and completed a standardized warm-up.
each participant was required to begin the test in the standard “up” position with body rigid, and in a straight line with hands shoulder width apart and fingers pointed forward.
a yoga block (approximately the size of a fist) was placed on the floor directly under the individual’s chest.
on the “go” command, the participant was instructed to lower him or herself until their chest contacted the yoga block.
the participant then returned to the standard “up” position by extending their elbows at their own pace.
each set was not timed, and participants were allowed as much time and rest during the set of push-ups, provided they were able to stay in a plank position.
each participant performed three sets of as many push-ups as possible using this technique.
five minutes of rest was allowed after the completion of each set to ensure complete recovery (17) directly after the completion of each set, rating of perceived exertion (rpe) was collected using the omni-resistance exercise scale (omni-res), which has been previously validated as an appropriate scale in assessing both upper and lower body workloads (27).
statistical analysis descriptive statistics (mean ± standard deviation) were calculated for the different variables were calculated.
data for each dependent variable was analyzed via a 2 x 2 between-within factorial anova.
independent samples t-tests were used to determine if any baseline differences were observed.
cohen’s d was calculated to assess the effect size for each dependent variable.
all analyses were completed using spss (spss version 22, ibm.
armonk, ny) software and the alpha criterion for significance were set at 0.05. results all results are displayed as mean and standard deviations (mean ± sd).
it is important to note that there were no significant differences at baseline between groups in the push-ups completed during set one (prepu1, p=.924), set two (prepu2, p=.487), set three (prepu3, p= .436), or in total (preputot, p= .742).
additionally, there were no significant differences in height (p= .759), weight (p= .630), body fat % (p= .360), lbm (p= .813), or fat mass (p= .307) between the two groups.
both pl and su groups significantly improved the amount push-ups completed during each set and in total from pre- to post-testing.
as such, there was a significant main effect for time in relation to the amount of push-ups completed at each set and in total, for both groups (p = <.05 for each variable, respectively).
additionally, there were no statistically significant differences between groups in improvement from baseline to post-testing in total number of push-ups completed (p=.823).
given the increase in total push-ups completed, it was necessary to calculate the effect size (cohen’s d) of the number of push-ups completed during each set and total number of push-ups.
table 3 and 4 outlines the push up data for each group.
no significant differences were found between pre- and post-testing for rpe data following any set or in total, indicating that the same effort was given for both testing in both sessions for groups.
table 5 below summarizes the rpe data.
no statistically significant differences were found between groups for percent change at any time point during the testing, at either baseline or post-testing.
data regarding percent change between groups is presented below in table 6. discussion the primary result in the current investigation suggests that there was no significant difference in push-up performance between the pl and su groups.
while previous studies have found increased performance from the ingestion of caffeine containing supplements(1, 10, 14, 21, 22, 25, 30), our study appears to be in align with other studies that found no such performance improvements (6, 16).
both the su and pl groups significantly increased the amount of push-ups performed between baseline and post testing (p=<.001).
however, there were no significant differences between groups at any time point or in total push-ups completed.
in a similar study to the present investigation, active male participants were provided with an energy drink containing 2 mg of caffeine/kg of body mass or a placebo, 60 minutes prior to the upper body endurance protocol (3 sets to fatigue at 70% 1rm bench press) (10).
the group that ingested the caffeine-containing beverage showed significant increase in the number of repetitions performed throughout the three sets, completing about 6% more than compared to the placebo group (10).
the authors of that investigation, like the authors of the current investigation, followed the directions of the manufacturer.
while the amount of caffeine contained in the supplement provided in our present study was lower (avgerage of 1.95mg/kg of body weight), there was still an increase in total push-ups completed from baseline to post-testing in both the su and pl groups.
however, there is no evidence to suggest that the energy drink supplement provided any additional benefits over the placebo.
the differences in results between these two studies could potentially be due to the differences in time from ingestion to performance of the upper body muscular endurance test.
in the present study, testing was completed 30 minutes after ingestion of the beverage, while the testing was completed 60 minutes after ingestion in the study by forbes (10).
additionally, the differences in supplement composition could be an explanation additional variable as to why the results from the previous study and the present study are in disagreement (10).
another similar study examined the effect of a pre-workout energy drink on upper body muscular endurance, as measured by a push-up to fatigue test.
the authors reported a significant 12% increase in the number of push-ups to fatigue after ingesting the manufacturer’s suggested amount of pre-workout energy drink supplement 30 minutes prior (8).
similarities exist between the previously mentioned study and the current investigation, as the protocol for the push-up to fatigue test and the amount of energy drink supplement that was ingested was very similar between the two studies.
however, the study designs differ in that our study examined the muscular endurance over 3 sets of push-ups to failure, rather than one set of push-ups to failure used in the dawes investigation (8).
although there was an improvement in performance in the su group from pre- to post-testing in the current study, the pl received a comparable performance improvement.
therefore, we cannot conclude with any certainty that the energy drink supplement has any additional ergogenic effect on upper body muscular endurance beyond that of the placebo.
it is possible that both groups improved as a result of repeating the test for a second time.
this result is comparable to that of the previously mentioned study by dawes (8), where college-aged males ingested an energy drink supplement prior to completing the ymca bench press.
the author’s reported no significant improvements in upper body endurance, suggesting that the supplement used in the study may not have a synergistic effect on upper body muscular endurance (9).
it is important to note the limitations of the present investigation.
a potential limitation and possible explanation for the non-significant difference in performance between groups could be that the average caffeine concentration in the energy drink supplement used in the present study was 1.95 mg of caffeine/kg of body mass, which is lower than the recommended dosage of 3 mg/kg of bodyweight (13).
based on the recommended dosage, the average dosage used in the present investigation may not be high enough to elicit an ergogenic effect.
it is also possible that other active ingredients that have been shown to elicit performance enhancements were under dosed.
however, since the manufacturer’s “energy blend” was proprietary, it is difficult to know for certain if the combination of all the ingredients elicited a stimulating effect.
finally, as previously noted, the previously recommended time frame between caffeine ingestion and the beginning of exercise performance is 45 minutes (15).
however, the current investigation followed the manufacturer’s guidelines and ingested the supplement 30 minutes prior to the commencement of testing.
thus, this time frame may not be optimal and may have contributed to the lack of ergogenic effect in the su group.
to conclude, our results suggest that the energy drink used in the current study does provide improved muscular endurance over multiple sets of push-ups to fatigue.
however, this supplement did not provide any benefit over a placebo.
therefore, redline® may not offer any additional performance benefits beyond that of a placebo beverage.
redline ® is a commonly used energy drink supplement consumed by those looking to potentially increase endurance exercise performance.
these results suggest that this supplement may not elicit endurance exercise performance enhancements beyond that of a placebo beverage.
future research is needed to examine if this energy drink supplement effects muscle activity, and force production during prolonged upper body exercise.
additionally, future studies may want to consider having participants consume a larger volume of the beverage to meet the recommended caffeine dosage for improved performance.
@highlight
the use of pre-workout beverages is becoming an increasingly common method of improving performance during exercise in athletic and recreationally active populations.
therefore, the purpose of this study was to investigate the effects of a commercially available energy drink on exercise performance.
thirty-one healthy males (n=23) and females (n=8) participated in this study and were separated into two groups: supplement (su; n=16) or placebo (pl; n=15).
subjects visited the laboratory on 2 occasions separated by no more than 7 days.
the first visit consisted of completing a push up to fatigue protocol (pufp) without ingesting the pre-workout energy drink supplement (pweds).
the second visit consisted of ingesting either a placebo or the pweds 30 minutes prior to completing the pufp.
rate of perceived exertion (rpe) was recorded following each set of pushups on both testing days.
also, participant’s height, weight, and body composition were collected.
there was no significant differences at baseline in any variable between groups (p = >.05).
after the second testing session, both groups significantly improved total push-ups (pl pre: 133.3 ±39.4, pl post: 155.3 ± 54.1; su pre: 139.3 ± 58.5, su post: 161.3 ± 79.4; p=<.001), and push-ups completed in each of the 3 sets (p=<.001), when compared to baseline.
post-testing revealed no significant difference between groups in total push-ups completed or rpe at any time point, when compared to baseline.
in conclusion, the commercially available pweds offered no additional ergogenic effects when compared to the placebo.
