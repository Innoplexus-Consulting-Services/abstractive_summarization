introduction cervical cancer is associated with considerable morbidity in young adolescent women in japan.
persistent infection of the cervix with some oncogenic subtypes of human papilloma virus (hpv) causes cancer.
thus, vaccination against high-risk oncogenic hpv infection before the first sexual experience may reduce morbidity by approximately 70%.
the world health organization has recommended worldwide hpv vaccination to prevent the majority of cervical cancers (1).
several cases of young females presenting with central nervous system (cns) demyelination following the administration of hpv vaccine have been reported thus far (2).
we herein present the first two cases of acute disseminated encephalomyelitis (adem) following vaccination against hpv in japan.
case reports case 1 a 16-year-old japanese girl had received a bivalent hpv vaccine (cervarixⓡ, 0.5 ml intramuscularly) during a school program.
she had a previous medical history of bronchial asthma in her childhood, but had not received any treatment for this condition.
the second vaccination was administered 33 days after the first injection on the same limb.
the patient felt discomfort in her visual field 14 days after the second vaccination.
she became aware of double vision and dizziness on the next day, followed by instability while walking.
nineteen days after the second vaccination, she was referred to our neurological outpatient clinic.
her neurological examination revealed complete alertness, bilateral medial longitudinal fasciculus syndrome, left facial sensation decrease, and mild left facial paresis.
the cerebrospinal fluid (csf) was acellular, with normal sugar and protein levels and igg index (59 mg/dl, 38 mg/dl, and 0.44, respectively) and there was no evidence of oligoclonal igg bands (ocb).
however, the myelin basic protein level was elevated (440 ng/ml; normal <102 ng/ml).
electrophysiological studies, such as those for somatosensory evoked potentials, auditory brainstem responses, and visual evoked potentials, showed no significant abnormalities.
brain magnetic resonance imaging (mri) showed an isolated small, demyelinating lesion in the pontine tegmentum on t2-weighted and fluid-attenuated inversion recovery images.
the lesion was not enhanced by contrast agent (fig.
1).
according to these findings, the patient was diagnosed with post-vaccination adem and administered methylprednisolone 1,000 mg/day intravenously for 3 days.
her visual function improved after treatment and the double vision resolved within a week.
the abnormal brainstem lesion ascertained by mri was normalized 80 days after vaccination.
she was left with no residual neurological deficit and did not receive the third dose of the vaccine.
no clinical relapse was observed over the 2-year follow-up period.
figure 1. mri of the brain on admission in case 1. a: t2-weighted image.
b: fluid-attenuated inversion recovery (flair) image.
c: a diffusion-weighted image revealed an isolated small high intensity lesion in the pontine tegmentum.
d: a t1-weighted image showed no apparent abnormalities.
case 2 a 15-year-old previously healthy japanese girl had received the first dose of a quadrivalent hpv vaccine (gardasilⓡ, 0.5 ml intramuscularly) through a school program.
the second vaccination was administered 77 days after the first vaccination on the same limb.
sixteen days after the second vaccination, she suffered from a fever, headache, and polyarthralgia with swelling of the extremities for 1 week.
serum igm anti-cytomegalovirus antibody was present, but no abnormal neurological signs were evident in the pediatric clinic.
she did not receive any specific treatment, and her headache and dysesthesia in the limbs persisted for 2 weeks after the fever diminished.
in the third week, she visited a neurological clinic and brain mri studies showed a hyperintense lesion in the pons with slight edema on a t2-weighted image and diffusion-weighted images (fig.
2).
forty days after the second vaccination, the patient was referred to our neurological outpatient clinic.
her neurological examination was normal and reevaluation of brain mri revealed that the pontine hyperintense lesion had completely diminished.
she did not receive the third dose of the vaccine.
clinical relapse was not observed over the 2-year follow-up period.
figure 2. mri of the brain in case 2. a: t2-weighted image.
b: flair image.
c: a diffusion-weighted image revealed a hyperintense lesion in the pons with slight edema.
d: sagittal t2-weighted imaging of the brainstem showed the lesion existed on the pontine midline.
the lesion finally diminished without any treatment.
discussion multivalent hpv vaccines are generally administered three times, with the second and the third injections at 1-2 months and 6 months, respectively, after the first injection.
the quadrivalent hpv vaccine gardasil is widely used in many countries, whereas the bivalent hpv vaccine cervarix was first introduced in japan.
thirteen cases concerning cns demyelinating adverse effects associated with hpv vaccination have been reported previously (table).
however, nine of these were finally diagnosed as multiple sclerosis or neuromyelitis optica (3).
the prevalence of multiple sclerosis in western countries is approximately 10 times higher than that in asian countries (4).
the targeted age of nationwide voluntary hpv immunization programs conducted in australia and other countries is consistent with the age group susceptible to multiple sclerosis (5).
table.
previously reported cases of adem occurring after hpv vaccination.
reference no.
number of cases vaccine intervals after last injection progress to multiple sclerosis treatment prognosis 6 4 gardasil 3-6 months nmosd ivmp, rituximab good 16 1 gardasil 4 weeks none ivmp, ivcy good 17 5 gardasil ~3 weeks 3 ivmp good 18 1 gardasil 10 days none ivmp good 19 2 gardasil 4 weeks 2 ivmp good current cases 2 gardasil/cervarix ~2 weeks none ivmp/no treatment good nmosd: neuromyelitis optica spectrum disorder, ivmp: intravenous methyl prednisolone, ivcy: intravenous cyclophosphamide however, it has been noted that the molecular structure of aquaporin 4 resembles l1 virus-like particles contained in the hpv vaccine, and the influence of novel immunostimulatory adjuvant as04 may have a role in cns demyelinating adverse events (6,7).
generally, the onset of autoimmune disorders is triggered by infectious conditions for genetically susceptible individuals.
therefore, vaccination may also stimulate the immune system in susceptible young women.
however, recent pooled analyses of large-scale and long-term safety data have revealed no evidence of an increased risk of autoimmune disease associated with hpv vaccination (7,8).
the proposed criteria for pediatric adem are multifocal, large (1-2 cm each) lesions identified by brain mri and behavioral changes or alteration of consciousness (9).
there are no standardized descriptions of adem for adult patients; however, consciousness is not necessarily impaired and infratentorial lesions are more frequently identified in both young and elderly adults (10).
cerebral lesions are typically disseminated; however, solitary lesions occur in approximately 10-30% of all cases (11).
the differential diagnosis from multiple sclerosis is determined by a clinical course with no relapse and the absence of any oligoclonal igg bands in the csf (9).
in our cases, ocb were not detected; nonetheless, elevated myelin basic protein levels were observed, suggesting that acute central demyelinating changes occurred.
clinical relapse was not observed over the 2-year follow-up period in both cases.
the median interval from the onset of the initial demyelinating symptom to the second neurological episode in multiple sclerosis has been reported to be two years (12).
patients with monofocal symptoms without asymptomatic mri abnormalities have a relatively low risk for later meeting the criteria for multiple sclerosis than patients with multifocal asymptomatic lesions (13).
a previous confirmed report of adverse effects in the cns associated with hpv vaccination in japan described the case of a pediatric patient diagnosed with acute cerebellar ataxia (14).
no obvious mri abnormality was observed in that case.
the annual incidence of adem is 0.8 per 100,000 individuals, of which 5% is believed to be post-vaccination adem (11).
post-vaccination adem is an unavoidable complication and 0.1-0.2 per 100,000 vaccinated individuals develop adem (15).
at the end of march 2014, 7 million doses of cervarix and 1.9 million doses of gardasil were administered to more than 3.7 million individuals as part of the vaccination program in japan.
the number of adem cases, which were confirmed by mri abnormality, reported to the pharmaceuticals and medical devices agency were only three including the present cases (20).
thus, we estimate that approximately 0.05 adem cases occurred per 100,000 since initiating hpv vaccination in japan.
this frequency is not particularly higher than that for post-vaccination adem induced by other vaccines.
however, we cannot confirm whether this is the true incidence of post-vaccination adem at this time because adem is an extremely rare disorder and its diagnosis is obscure.
it is therefore important to accumulate further data on confirmed cases of adem temporally associated with hpv vaccination.
we herein presented two cases of adem following vaccination against hpv.
clinicians should keep in mind that neurological symptoms due to demyelination can occur after hpv vaccination.
the authors state that they have no conflict of interest (coi).
@highlight
we herein present two cases of acute disseminated encephalomyelitis (adem) following vaccination against human papilloma virus (hpv).
case 1 experienced diplopia and developed an unstable gait 14 days after a second vaccination of cervarix.
brain magnetic resonance imaging (mri) showed an isolated small, demyelinating lesion in the pontine tegmentum.
case 2 experienced a fever and limb dysesthesia 16 days after a second vaccination of gardasil.
brain mri revealed hyperintense lesion in the pons with slight edema on a t2-weighted image.
both cases resolved completely.
it is important to accumulate further data on confirmed cases of adem temporally associated with hpv vaccination.
