introduction breast cancer is still one of the main causes of mortality in women worldwide.
in these patients, metastases at distant sites is the main cause of death [1].
new diagnostic and prognostic markers are urgently required to identify patients who are at the highest risk for developing metastases, which might allow oncologists to begin adjusting treatment strategies to individual patients [2].
natriuretic peptides (nps) are a family of cardiac hormones including atrial, brain, and c-type nps (anp, bnp, and cnp, respectively).
anp and bnp are produced mainly in the cardiac atria and ventricles, respectively, and play important roles in the preservation of cardiovascular homeostasis [3].
anp is stored, as pro-peptide, in cytoplasmic dense granules of cardiomyocytes.
atrial stretch resulting from elevated blood pressure leads to release of anp into the blood stream [4].
anp is synthesised as inactive precursor (pro-anp) and is proteolytically cleaved by the membrane-associated protease corin, which converts it to the mature active peptide [5].
nps’ biological actions are mainly mediated via the intracellular messenger cgmp through activation of guanylyl cyclase a&b receptors [3].
the newest detected biological functions of these peptide hormones is their anticancer effects [6].
these peptide hormones decrease progression of prostate, breast, pancreatic, and colon adenocarcinoma.
their main anticancer mechanism is the inhibition of dna synthesis in cancerous cells via the intracellular messenger cgmp [6].
aim of the study the aim of the present study was to assess serum levels of anp in breast cancer female patients and its relationship to metastasis and some clinical parameters among those patients.
material and methods the present study was conducted on two groups (control and patient groups) matched in age and sex.
the first control group included 20 heathy female individuals with no history of malignancy, cardiovascular, or pulmonary disease and mean age of 41 ±10.8 years (table 1).
table 1 patient characteristics parameter no.
of patients (100) % who performance status  0 fully active, able to carry on all pre-disease performance without restriction 20 20  1 restricted in physically strenuous activity but ambulatory 29 29  2 ambulatory and capable of all self-care but unable to carry out any work activities 51 51 primary tumours  ductal adenocarcinoma (invasive and/or in situ) 58 58  lobular adenocarcinoma (invasive and/or in situ) 30 30  paget’s disease (with or without invasive ductal or intraductal component) 12 12 stage (tnm):  i 12 12  ii 18 18  iii 15 15  iv 55 55 her2 receptor  her2 (+) 48 48  her2 (–) 52 52 er status  er (+) 81 81  er (–) 19 19 pr status  pr (+) 82 82  pr (–) 18 18 systemic treatment  surgery (modified radical mastectomy) 35 35  radiotherapy 30 30  chemotherapy 35 35  endocrine therapy 20 20 the second group included 100 selected breast cancer female patients with a mean age of 45.9 ±11.3 years.
this group was sub-classified into the following: group 2a (n = 30): non-metastatic breast cancer patients: they were proven to be non-metastatic in the surgical oncology department in the oncology centre of mansoura university, and they were candidates for surgery.
all patients with neoadjuvant therapy were excluded from this group of patients.
the radiologic workup was abdominal us, chest x-ray, and/or chest ct & bone scan.
group 2b (n = 20): metastatic breast cancer de-novo (i.e.
new breast cancer cases are initially stage 4 or metastatic).
group 2c (n = 20): metastatic breast cancer under hormonal treatment with either tamoxifen or aromatase inhibitors and (oestrogen receptor) er and/or (progesterone receptor) pr receptor are positive.
group 2d (n = 15): metastatic breast cancer under follow-up with er and/or pr receptor are negative.
group 2e (n = 15): locally advanced breast cancer is invasive breast cancer that has not received chemotherapy and has one or more of the following features: may be large (typically bigger than 5 cm), may have spread to several lymph nodes in the axilla or other areas near the breast,  may have spread to other tissues around the breast such as skin, muscle, or ribs.
they were selected from patients admitted to the oncology centre, mansoura university from december 2014 to november 2015, one day every week.
a complete history and clinical examination with special attention to signs and symptoms related to heart failure were performed.
routine laboratory investigations and anp were also done.
informed consent was obtained from all participants prior to their enrolment in the study, and approval from the local ethics committee of mansoura university was also obtained with reference cod r/17.03.29.
exclusion criteria patients with left ventricular dysfunction or coronary artery disease.
patients who received adjuvant anthracycline-based chemotherapy.
chest wall irradiation.
sample collection three millilitres of venous blood was withdrawn after 12–14 hours of overnight fasting.
the blood samples were collected via clean venipuncture and were delivered into plain vacutainer tubes, left to clot for 20 minutes at 37°c, and then centrifuged at 3000 g for 10 minutes.
the separated serum was further divided into two aliquots.
the aliquots were kept at –70°c for anp assessment.
biochemical analyses serum anp levels were detected by enzyme-linked immunosorbent assay (elisa) technique using kits supplied by elaab (catalogue no.
e0225h) with range 0.156–10.0 ng/ml [7].
statistical analysis the statistical analysis of data was done by using spss program (statistical package for social science) version 20. the quantitative data were expressed as range and mean ± standard deviation (sd), while qualitative data were expressed in number and per cent.
for quantitative data student’s t-test was used for the comparison between two groups while one way anova test was used to compare among the groups.
for qualitative data, the χ2 test was used to compare among the groups.
statistical significant difference was considered at p < 0.05, and highly significant difference at p < 0.001. results mean serum levels of anp were significantly elevated in breast cancer patient groups (13.9 ±10.1 ng/ml) compared to controls (2.2 ±1.3 ng/ml) p < 0.001 (table 2).
table 2 comparison of the age and anp levels between patients and control groups patients (n = 100) controls (n = 20) t test mean ± sd mean ± sd t p age (years) 45.9 ±11.3 41 ±10.8 1.816 0.072 anp (ng/ml) 13.9 ±10.1 2.2 ±1.3 5.131 < 0.001 mean serum anp levels were significantly increased in metastatic breast cancer patients (17.1 ±8.9 ng/ml) compared to non-metastatic breast cancer patients (6.4 ±8.8 ng/ml) p < 0.001).
a non-significant difference was detected in er%, pr%, and her2 when compared metastatic to non-metastatic patients (table 3, fig.
1).
table 3 comparison of the age and anp levels between non-metastatic and metastatic breast cancer patients non-metastatic breast cancer patients (group 2a) (n = 30) metastatic breast cancer patients (group 2b, 2c, 2d, 2e) (n = 70) t test mean ± sd mean ± sd t p age (years) 48.9 ±10.2 45.8 ±11.1 1.310 0.193 anp (ng/ml) 6.4 ±8.8 17.1 ±8.9 5.504 < 0.001 or, n (%) 27 (90%) 54 (77.1%) 2.256* 0.133 pr, n (%) 27 (90%) 55 (78.6%) 1.858* 0.173 her2, n (%) 13 (43.3%) 35 (50%) 0.374* 0.541 * χ2 test or – oestrogen receptor; pr – progesterone receptor; anp – atrial natriuretic peptide fig.
1 comparison of the anp between non-metastatic and metastatic breast cancer patients one-way anova within the four groups of metastatic breast cancer patients using the serum anp as the dependent variable revealed that there were significant differences in anp levels between groups (p = 0.007) (table 4, fig.
2).
table 4 comparison in anp levels between different groups of metastatic breast cancer de novo metastatic (n = 20) metastatic under hormonal therapy (n = 20) metastatic under follow up (n = 15) locally advanced (n = 15) anova test mean ± sd mean ± sd mean ± sd mean ± sd f p age 41.6 ±10.4 44.6 ±12 46.6 ±11.6 42.9 ±10.8 0.642 0.591 anp (ng/ml) 18.1 ±4.5 11.2 ±10.2 15.8 ±11.7 21.3 ±6.5 4.410 0.007 or, n (%) 20 (100%) 20 (100%) 0 (0%) 14 (93.3%) 64.707* < 0.001 pr, n (%) 20 (100%) 20 (100%) 0 (0%) 15 (100%) 70.000* < 0.001 her2, n (%) 15 (75%) 12 (60%) 0 (0%) 8 (53.3%) 20.867* < 0.001 * χ2 test or – oestrogen receptor; pr – progesterone receptor; anp – atrial natriuretic peptide fig.
2 roc curve of anp for discrimination between cases and controls no association was detected between serum anp levels and er, pr, her 2, and breast cancer stage (table 5).
table 5 the association of or, pr, her2, and tumour stage with anp in the patients with breast cancer anp (ng/ml) t test mean ± sd t p or  absent 13.8 ±11.7 0.014 0.989  present 13.9 ±9.8 pr  absent 16.3 ±12.2 1.134 0.260  present 13.3 ±9.6 her2  absent 13.5 ±10.4 0.346 0.730  present 14.2 ±9.9 stage of tumour  i 13.5 ±17.8 2.601* 0.079  ii 11.3 ±11  iii 15.9 ±8.8 f value, anova test anp – atrial natriuretic peptide; or – oestrogen receptor; pr – progesterone receptor the roc analysis to assess the sensitivity of anp revealed the ability of anp to discriminate between the control and breast cancer patients and between metastatic and non-metastatic breast cancer patients.
the area under curve (auc) was 0.791 and 0.808, respectively.
by using a cutoff value of 4.75 ng/ml between control and breast cancer patients the sensitivity was 69.4 and specificity was 100 (table 6 and fig.
3).
as regards metastatic and non-metastatic breast cancer patients the cutoff value was (11.4 ng/ml) and the sensitivity and specificity were 78.6 and 78.6, respectively (table 6).
table 6 auc and performance characteristics of anp for discrimination between cases and controls, as well as between non-metastatic and metastatic discrimination between cut off auc p 95% ci sensitivity (%) specificity (%) ppv (%) npv (%) accuracy (%) cases and control 4.75 0.791 < 0.001 0.713-0.869 69.4 100 100 40 74.6 non-metastatic and metastatic 11.4 0.808 < 0.001 0.704-0.912 78.6 78.6 90.2 59.5 78.6 fig.
3 roc curve of anp for discrimination between metastatic and non-metastatic bc discussion breast cancer is the most common cancer and the leading cause of cancer death in women worldwide [8].
the development of breast cancer starts with ductal hyperproliferation, followed by subsequent evolution to carcinoma in situ, invasive carcinoma, and finally into metastatic disease [9].
besides the role of anp in cardiovascular homeostasis, it has the ability to inhibit tumor growth both in vitro and in vivo [10].
this study reveals significantly higher anp levels in breast cancer patients (metastatic and non-metastatic) compared with controls (p < 0.001) (table 2).
this is in agreement with vesely et al., who reported that breast adenocarcinomas growing in vivo have receptors that mediate anp’s effects.
after binding of anp to their receptors, the anticancer mechanism of action begins [11].
the molecular mechanism underlying the anticancer and anti-proliferative effect of anp has been mainly related to its interaction with the specific natriuretic peptide receptors (nprs) and inhibition of some metabolic targets critical for cancer development, including the ras-mek1⁄2, erk1⁄2 kinase cascade [12, 13], wnt pathway [14, 15], vegf, and b-catenin [16].
dna synthesis is also inhibited within the nucleus; this inhibition is mediated by the intracellular mediator cyclic gmp [17].
on the other hand, anp does not inhibit ras-mek 1/2-erk 1/2 kinases in healthy non-cancerous cells but in cancer cells only [18].
normally, after anp binds to its receptor, the receptor internalises and anp is degraded, with the receptors recycling to the plasma membrane.
part of the cytoplasmic demonstration of these peptide hormones within the cancer cells may be the anps attached to their receptors that are being internalised [19].
this study reveals significantly higher serum levels of anp in metastatic breast cancer patients compared with non-metastatic patients (p < 0.001) (table 3, fig.
1).
this disagrees with the role of anp in inhibiting metastasis via the inhibition of vegf-induced signalling and angiogenesis [20].
these results are in disagreement with the study conducted by nojiri et al., [21] who assumed two mechanisms for anp inhibition of tumour metastases in lung cells; the first through direct inhibition of tumour cell proliferation and the other through inhibition of inflammatory response and the suppression of e-selectin and hence suppression of tumour cell adhesion to inflamed endothelial cells.
this discrepancy with our results is ascribed to the fact that metastatic breast cancer lesions have less natriuretic peptide a receptors (npr-a) than the primary lesion.
the metastatic lesions may have a mutation which leads to them losing their npr-a receptors so they are unable to respond to anp, similarly to breast cancers that lose their oestrogen and/or progesterone receptors being more prone to metastasise.
this loss of npra by metastatic lesions would cause metastatic lesions not respond to, or have a decreased response to anp [11].
oestrogen is essential for normal mammary development, and ductal growth and plays a central role in the development and progression of human breast cancer.
exposure to oestrogen and/or an increase in oestrogen receptor expression in human mammary epithelial cells increases the risk of breast cancer [22].
in the present study, our results have negative association between anp levels and breast cancer clinical parameters such as oestrogen receptor, progesterone receptor, and cancer staging, and this may be attributed to the loss of npra in metastatic lesions (table 5) [12].
no significant differences are observed between metastatic and non-metastatic bc patients as regard to er, pr, and her2.
the proportions of er-positive, pr-positive, and her2-positive in the metastatic group are 77.1%, 78.6%, and 50%, respectively.
in agreement with our results, some studies have shown that 75% to 85% of invasive breast cancers are er-positive and/or pr-positive and 15% to 20% are her2-positive [23, 24] (table 3).
the present study also showed that within the metastatic patient groups, circulating anp levels was lowest in metastatic patients who received hormonal therapy either tamoxifen or aromatase inhibitors.
this was in agreement with the study by silva et al.
[25], who found decreased levels of nt-probnp in patients receiving tamoxifen, and attributed this to the role of tamoxifen in preventing sub-clinical cardiac damage and decreasing cardiac synthesis of pro-bnp through different mechanisms.
the first is the stimulation of endothelial nitric oxide synthase (enos) activity and promotion of antioxidant effects by increasing catalase activity [26].
the second was through the promotion of a significant increase in the antioxidant activity of glutathione and glutathione peroxidase [27].
as regard to the roc analysis to assess the sensitivity of anp in the discrimination between the control and breast cancer patients and between metastatic and non-metastatic breast cancer patients.
by using a cut off value of 4.75 ng/ml between control and breast cancer patients the sensitivity was 69.4 and specificity was 100 (table 6, fig.
3).
as regards metastatic and non-metastatic breast cancer patients the cutoff value was 11.4 ng/ml, and the sensitivity and specificity were 78.6 and 78.6, respectively (table 6).
points of strength: to our knowledge the current study is the first report showing the diagnostic value of anp in breast cancer and its relationship with metastasis and some clinical parameters.
one limitation of our study is the limited number of participants.
the disparity between our results and some reported studies could be due to sample size limitation, different ethnic groups, and different environmental factors.
therefore, additional high-quality research to consider this peptide as a biomarker for assessing detection, progression, and early intervention therapy strategies in breast cancer patients with large sample sizes should be carried out to verify the association.
from this study, we can conclude that anp, a cardiovascular hormone used as a targeted therapy for heart failure, may be a suspected marker for distant metastases in breast cancer patients.
@highlight
aim of the study to assess serum levels of anp in breast cancer female patients and its relationship to metastasis and some clinical parameters among those patients.
material and methods one hundred breast cancer patients with and without metastasis along with 20 healthy closely matched controls, were enrolled in the present cross sectional study.
background: to assess the serum levels of atrial natriuretic peptide in breast cancer serum levels of anp were assessed using elisa.
results mean serum levels of anp breast cancer patients (13.9 ±10.1 ng/ml) were significantly elevated compared to healthy control group (2.2 ±1.3 ng/ml) (p < 0.001).
the metastatic breast cancer patients showed significant elevated anp levels (17.1 ±8.9 ng/ml) compared to non-metastatic group (6.4 ±8.8 ng/ml) p < 0.001. within the metastatic group significant difference was detected between de novo metastatic, under follow-up, under hormonal control and locally advanced group (p = 0.007).
conclusions this study showed significant elevated levels of anp in the serum of metastatic breast cancer patients compared to non-metastatic patients.
within the metastatic group the lowest levels were detected in metastatic breast cancer under hormonal treatment either tamoxifen or aromatase inhibitor.
