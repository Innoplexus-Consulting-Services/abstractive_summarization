1. introduction obesity is a complex chronic global disease affecting people worldwide across all ages, sexes, ethnicities, and nationalities [1].
comparing body weight to height using body mass index (bmi) allows for the classification of obesity into class i (bmi 30–34.9 kg/m2), class ii (bmi 35–39.9 kg/m2), and class iii (bmi ≥ 40 kg/m2) [2] the prevalence of the highest obesity class is of concern due to its association with poorer health outcomes compared to lower bmi categories [1].
in 2013-2014, class iii obesity affected 5.5% of males and 9.9% of females in the united states, with a linear increase in prevalence for females since 2005 [3].
compared to the united states, fewer canadians have class iii obesity (2.5%); however the same trend by sex is found with a greater percentage of females affected (3%, compared to 2% of men) [4, 5].
in addition to bmi, waist circumference can be used to identify obesity.
both anthropometric methods provide a surrogate assessment of fat mass (fm) but are poor detectors of lean mass, also called lean soft tissue (lst), and hence of body composition.
people with obesity can have varying proportions of lst and the single use of anthropometry to diagnose obesity precludes an accurate characterization of the different proportions of fm versus lst of an individual [6].
emerging evidence suggests obesity can coexist with low lst (sarcopenia) [7–10].
in this case, the gravity impact of the excess body weight may not be sufficient to promote a concurrent increase in lst; therefore, individuals with obesity may have high fm without a parallel increase in lst [11].
notably, this phenotype termed sarcopenic obesity may not be identified without the use of body composition assessment techniques.
low lst is an important prognostic factor in health and clinical conditions, as its main component is skeletal muscle mass, a tissue of vital importance for strength, functional mobility, immune function, and wound healing, among others [8, 12–16].
sarcopenia has been primarily studied in older adults and individuals with chronic conditions but emerging evidence suggests that “healthy,” younger individuals are also at risk for presenting with this condition [17, 18].
compounded with the consequences of excess fm, the concurrent sarcopenic obesity phenotype has been independently associated with worse morbidity and disability than either sarcopenia or obesity alone [10].
in the context of obesity treatment, weight loss results in the loss of both fm and lst [19, 20].
with repeated weight loss-gain cycles combined with age-related body composition changes, developing sarcopenic obesity is possible [10].
the identification of sarcopenic obesity is limited not only due to the availability of accurate body composition techniques but also due to heterogeneity in its diagnostic criteria [10].
a variety of body composition indices and cut-offs have been used to define sarcopenia and obesity, leading to conflicting findings on the prevalence and risk prediction of this condition [10, 21] additionally, the great majority of studies have focused on identifying sarcopenic obesity in older adults and the prevalence within younger adults and those with class ii/iii obesity is not well defined.
with the increasing prevalence of class iii obesity [3] and of sarcopenia [18], the prevalence of sarcopenic obesity in these individuals is likely to increase dramatically.
therefore, the objective of this study is to explore the variability in the prevalence of sarcopenic obesity in an adult sample with class ii/iii obesity using different diagnostic criteria.
2. methods in a cross-sectional approach, we included consecutive patients from a multidisciplinary clinic providing medical and bariatric surgical interventions for adults (18–69 years) with class ii/iii obesity (bmi ≥ 35 kg/m2) in edmonton, alberta, canada.
ethics approval was received from the university of alberta health research ethics board.
medical records were used to assess demographic and medical history obtained from the initial clinic assessment.
height was measured (without shoes, within 0.1 cm) with a wall-mounted stadiometer.
weight was measured (single layer of clothing, without shoes, within 0.1 kg) with a high-capacity weigh scale (scale-tronix 6702w®, welchallyn inc., skaneateles falls, new york).
waist circumference was measured (within 0.1 cm) with a nonstretch tape at the midpoint of the torso (between lowest rib and iliac crest) on the right side using a cross-handed technique, recorded as the average of three consecutive measures.
dual-energy x-ray absorptiometry (dxa) was required at the initial assessment and completed at a local medical imaging center [hologic discovery a (s/n 45026) or w (s/n 83792) scanners, software version 12.7.4.2, hologic inc., bedford ma].
no subjects exceeded the dxa weight capacity limit (204 kg) or scan area length (195 cm).
reflection positioning was used for subjects with larger supine widths (>65 cm).
right side data was duplicated when values for the left side were either not reliable or available [22–24].
collected values included whole body and segmental values for fm, lst, appendicular skeletal muscle mass (asm, which is lst from arms and legs), and fat-free mass (ffm = lst + bone), and its derivatives are adjusted by height in square meters, also called indexes (e.g., fmi, asmi).
detailed definitions of each of these body composition variables can be found elsewhere [6].
subjects with complete initial clinic assessments and body composition analysis by dxa were included in the study.
dxa scans available for analysis dated from january 2009 to june 2012, after which they were no longer ordered at the initial clinical assessment.
all data was collected prior to starting obesity treatment.
subjects were excluded from the final analysis if dxa data was unreliable (i.e., segmental measurements were outside of the field of view or due to lack of separation of tissues between the arms and torso).
2.1. sarcopenic obesity: definitions and terminology a literature search was conducted using pubmed, scopus, and web of science databases to identify studies using definitions sarcopenic obesity based upon body composition data derived from dxa with or without use of anthropometric variables (e.g., weight, bmi, and waist circumference), excluding clinical studies (e.g., cancer).
for definitions using ethnic-specific cut points, white/caucasian references were included as the majority of our population (83.9% edmonton, 86% canada) self-identified as caucasian [25].
ethnicity was not collected as part of the clinic assessment, in accordance with the freedom of information and protection of privacy act [26], therefore unavailable for analysis.
based on the literature review, ten studies were identified using nine variables based upon lst or asm to define sarcopenia (table 1) and four variables were identified to define obesity (table 2, plus fmi phenotype listed in table 1) [7, 8, 18, 27–33].
the use of inconsistent body composition terminology may preclude a clear understanding of sarcopenic obesity's diagnostic criteria in the literature (i.e., authors use of different terminology for the same body composition variables).
therefore, in order to improve clarity while still accurately representing the body composition components being measured in each study, we consistently use the terms lst for studies measuring the nonbone, nonfat body compartment in general from the whole body (i.e., arms, legs, trunk, and head) and asm for studies measuring lst from the arms and legs [6].
with the exception of bmi, each variable for sarcopenia and obesity used sex-specific cut points, with more than one cut point for some variables.
sixteen unique definitions (composed of a variable and cut point for each sarcopenia and obesity) were identified and applied to the sample to explore the prevalence of sarcopenic obesity.
linear regression analysis with asm, height, and fm (kg) was used to determine prevalence of sarcopenia using the newman et al., residual method [29].
the classification by body composition phenotypes was determined using deciles of population-derived asmi and fmi cut points based on sex, bmi, and age, as per the protocol described in prado et al.
[18].
the classification of abnormal body composition phenotype as a load-capacity model (load being fm and capacity ffm) was calculated as the ratio of fm : ffm (as centiles), as per methodology described in siervo et al.
[33].
additional classifications were derived from our study cohort, using asmi calculated as the lowest 20th percentile and two standard deviations (sd) below the mean of the distribution; a method commonly reported in the literature when a reference population is not available [34].
definitions of sarcopenic obesity utilizing measures of muscle strength or function were not included, as data were not available for our cohort.
2.2. statistical analysis descriptive statistics were used for subject characteristics, anthropometrics, and body composition and reported as mean (interquartile range).
normality testing was completed using the shapiro-wilk test.
frequencies and proportions were reported for categorical variables.
independent samples t-test for normally distributed data and nonparametric (mann–whitney u) independent samples t-test were used to compare variables between sexes.
to account for missing data (waist circumference), subjects were compared to determine if differences existed between the groups.
correlations were tested using pearson's r to explore the relationship between variables.
two-tailed tests were used for all the analysis with a p value of <0.05 considered for statistical significance.
data was analysed using ibm spss statistics for mac, version 23 (ibm corp., armonk, ny, usa).
3. results a total of 167 subjects with completed initial assessments and dxa scans were initially reviewed, in which 120 subjects (85.8% female) had reliable dxa data to be included in the final analysis.
clinical characteristics of excluded subjects (n = 47) were not different from those included in the analysis.
mean age of the entire cohort was 46.9 ± 11.1 years (range: 18–69 years).
subject characteristics, anthropometrics, and body composition are presented in table 3. patients were community-dwelling (100%) and predominantly married/common-law (f 68%, m 65%) and worked outside the home (f 68%, m 70%) and 7.8% of females (no males) were current smokers.
the majority of patients were generally well educated (f 98%, m 94% completed high school), with more females than males who completed their education at a university/college level (f 57%, m 35%).
recommended activity levels (>150 minutes of moderate intensity activities a week) were met by 20% of females and 23% of males.
due to the positively skewed data for weight in females, some variables were not normally distributed.
independent samples t-tests and nonparametric (mann–whitney u) tests results were compared and showed the same results.
no significant differences were observed between females and males for age, bmi, and fm (kg), table 3. compared to males, females had higher values for fm (%), fmi, and fm : ffm ratio and lower values for variables depicting the lean mass compartment.
a large variability in lst (kg) was observed for individuals with the same body size, figures 1(a) and 1(b).
the relationship between bmi and lst in females and males was moderate and weak (r = 0.41, r = 0.20, resp.
), figure 1(a).
the entire cohort met the criteria for obesity defined by bmi, waist circumference, and fmi cut points (table 2).
for fm%, all males exceeded the five different cut points.
one female (bmi 39.7 kg/m2 and 32.2% fm) did not meet the criteria for obesity defined by % fm with five of the six different cut points.
ten females (9.7%) had % fm below the highest cut point (42.9%) and therefore would not be identified with obesity despite bmi's ranging from 35.9 to 45.1 kg/m2.
of note, the highest sex-specific 20th percentile for fmi was >23.8 kg/m2 for females and >21.5 kg/m2 for males.
considering the entire cohort had class ii/iii obesity as defined by bmi, when each definition of sarcopenia was applied to the current sample, the prevalence of sarcopenic obesity varied from 0 to 84.5% for females and 0 to 100% for males (table 4).
definitions using unadjusted values for lst, asm, or asmi, with the exception of the highest asmi cut point, failed to identify any subjects with sarcopenic obesity.
notably, a higher prevalence of sarcopenic obesity was identified by definitions combining asm either with weight, bmi, or a measure of fm.
the sex-specific cut points developed from the newman et al.
[29] study group were only able to identify males with sarcopenic obesity in our cohort, table 4. applying the newman et al.
[29] residual method to derive cut points from the current cohort, sarcopenic obesity was identified in both sexes.
for the latter, the cohort-specific cut points derived from the 20th percentile of the sex-specific distributions of the residuals were <2.96 for females and <−4.82 for males, identifying 19.4% of females and 17.6% of males with sarcopenic obesity.
equivalent cut points for asmi were also derived from the study cohort.
the cohort-specific 20th percentile cut point to describe sarcopenic obesity by asmi was <8.21 kg/m2 for females and <9.44 kg/m2 for males.
using the lowest 2 sd criteria for asmi, the cohort-specific cut points were <6.79 kg/m2 for females and <8.62 kg/m2 for males.
selecting the cohort-specific 20th percentile, low asmi was observed across the age spectrum, figure 2. using the phenotype definition proposed by prado et al.
[18] to the entire sample, 16 (13.3%) subjects where classified with high adiposity and low muscularity (sarcopenic obese-like phenotype), and 95 (79.2%) subjects presented with the high adiposity and high muscularity phenotype (obese nonsarcopenic-like phenotype), figure 3. nine females were classified as having a normal body composition phenotype.
using the load-capacity model to account for the interaction of both body compartments [33], the fm : ffm ratio identified about a third of females and three-quarters of males with moderate and severe body composition phenotype (≥85th percentile), table 4.
4. discussion previous research identified sarcopenic obesity in older adults [35] and groups with certain chronic diseases [6].
although several diagnostic criteria have been used, no one approach has been widely accepted.
this is the first study to use state-of-the-art methodology (dxa) to explore the prevalence of sarcopenia in a younger adult cohort (mean age 46.9 ± 11.1 years) with class ii/iii obesity.
lst was extremely variable in individuals with similar bmi illustrating a wide variability of body composition within the same body size.
using 16 previously reported definitions, the prevalence of sarcopenic obesity varied from zero to 100%.
such variability precludes a comprehensive understanding of the prevalence of sarcopenia in younger individuals with more severe classes of obesity, as well as the development of preventive and treatment strategies for this condition in clinical settings.
as these individuals are actively seeking obesity treatment, maintaining lean mass should be a coprimary endpoint of the nutrition care plan together with weight management.
all males and almost all females were classified with obesity using diverse fm% cut points (30–42.9% for females and 20–29% for males).
most individuals with a bmi ≥ 35 kg/m2, excluding extremely muscular individuals, will present with excess adiposity [36] and prevalence will vary only based on the comparison cohort used to identify the cut point.
for example, 10 females from our cohort would not be considered to have obesity using the zoico et al.
[27] cut point based on quintiles of % fm from a sample of healthy elderly females (bmi 26 ± 3.8 kg/m2).
nonetheless, these 10 females were within 0.2% to 3.7% below the % fm cut point.
interestingly, using the adjusted prado et al.
cut points [18], we observed that nine females were not classified as having high adiposity.
in addition to sex, this cut point is notably adjusted for age and bmi.
six females were identified as having both lower % fm and fmi using the zoico et al.
[27] and prado et al.
[18] cut points respectively.
prevalence of sarcopenia ranged approximately from 0 to 84.5% in females and from 0 to 100% in males.
the null prevalence using several cut points may be explained by the approach used to define sarcopenia.
reference values to diagnose sarcopenia have been primarily developed from older cohorts, which may not be applicable for younger adults.
although cherin et al.
[17] included younger individuals (45–83 years), their cohort's mean age was 63.1 ± 10.2 years and the prevalence of sarcopenic obesity was not reported.
in our study, no subjects were identified with sarcopenic obesity by definitions of lst [27, 28].
baumgartner et al.
[7, 37] and others have defined sarcopenia using asmi sex-specific cut points based on two standard deviations below the mean for a young reference group [7, 21, 30, 37–39].
no subjects were identified with sarcopenic obesity applying each of these different cut points.
although these young reference groups were north american and of similar age to the current study cohort, their bmi (described as “normal”) would be much lower.
however, sarcopenic obesity may still be present but not identified as the cut points may not be sensitive enough to identify relatively low lean mass in subjects with larger total body mass.
likewise, no subjects were identified as sarcopenic using newman et al.
cut point which defined sarcopenia as the lowest 20th percentile of their cohort's asmi distribution [29].
notably, applying the same method to our cohort, our asmi cut points were 45% and 31% greater for females and males, respectively, highlighting how differences in age and body size may impact comparison among different cohorts.
although the quantity of lst may meet or exceed reference values derived from normal, healthy reference populations (e.g., normal bmi or age 25 years), the higher lst amount is insufficient to maintain the larger body size (largely due to a larger fm amount).
this phenomenon can be conceptualized as the metabolic load (due to fm) versus capacity (of the lst/ffm) model previously described [33].
therefore, sarcopenia in those with obesity may be present at higher lst values and must be evaluated in relation to body mass or fm.
our findings support the use of a combined definition of body mass or fm to a measure of sarcopenia for the identification of sarcopenic obesity in this cohort of younger adults with class ii/iii obesity.
considering measures of asm with weight [31, 32], bmi [8], fmi [18], or fm [29, 33], our prevalence of sarcopenia ranged from 12.6 to 84.5% for females and 17.6 to 100% for males.
likewise, in the newman et al.
[29] study, higher prevalence rates were observed for both sexes using a method in which asm was considered in relation to height and fm compared to none using nonadjusted asmi cut points.
the authors concluded this technique captured the effect of both lst (as asm) and high fm simultaneously, therefore identifying a greater proportion of people with obesity as being sarcopenic.
our findings are consistent with their results and highlight the potential importance of considering fm with lst indices together when evaluating sarcopenia in people with obesity.
we were able to identify three body composition phenotypes using the prado et al.
[18] previously established cut points, where age, sex, and bmi-specific reference curves were created to define body composition phenotypes (fmi and asmi above or below the 50th percentile).
as the 50th percentile was used, the terms “obesity” and “sarcopenia” were avoided with individuals being classified using a combination of high/low adiposity and high/low muscularity.
the concurrent high adiposity and low muscularity are the “sarcopenic obesity-like” phenotype with an observed population prevalence of 10.3% in females and 15.2% in males.
although subjects >136 kg were excluded from that study thereby limiting the reference data, applying this method to the current study cohort produced similar results, identifying 12.6% of females and 17.6% of males with sarcopenic obesity.
similar to siervo et al.
[33] fm : ffm ratio reference curves in our study found females had a higher fm : ffm ratio than males.
notably, the current study included subjects with higher weights, with 17.5% of females and 41.2% of males >136 kg.
the load-capacity model is a novel method to identify low lst relative together with excess fm in subjects with class ii/iii obesity.
although our sample size of males was small, their prevalence of sarcopenia was higher than females for all definitions except the newman et al.
residual method [29], where the prevalence was similar.
the prevalence of sarcopenia by sex is controversial with some studies reporting higher prevalence among males, others among females and some finding no differences [35].
an important consideration for any definition is to understand the characteristics of the group from which the cut points were derived.
notably, some definitions were developed from european or asian cohorts that are ethnically different from a north american population.
widely recognized differences in body composition among different ethnicities preclude a direct comparison of sarcopenic obesity prevalence among different studies.
in the absence of a young reference group, cohort-specific cut points were used using the lowest one [30] or two [28, 29] quintiles for asmi.
applying this approach to our dataset, our cohort-specific cut points were much higher than previously published ones, again highlighting that cut points derived from other cohorts or nonspecific populations (i.e., older adults, individuals without obesity) may either fail to detect or underestimate the prevalence of sarcopenic obesity in adults with class ii/iii obesity.
contrary to expectations, the prevalence of sarcopenia was not higher among individuals ≥65 years compared to those <65 years [18].
indeed, we reported asmi was highly variable across the age spectrum; only one of the 23 individuals with an asmi below the 20th percentile for this cohort was older than 65 years (figure 2).
the large variability of lst (figures 1(a) and 1(b)) in individuals with the same body size represents a clinical challenge for determining nutritional requirements.
for example, protein and energy needs are often determined based on body weight, yet, considering lean mass drives protein requirements, people with the same body weight can receive varying amounts of protein per unit of lean mass (lst), a concept previously explored [40, 41].
in the selected example on figure 1(b), if protein requirements were assessed as 1 g/kg actual body weight (116 kg), the estimated amount of dietary protein would be equivalent to 1.6 to 2.2 g/kg lst.
data on body composition of adults with class ii/iii obesity is limited, especially of those with bmi > 40 kg/m2.
one barrier is related to equipment limitations [42].
individuals with class iii obesity not only have increased weights, but increased body dimensions such as height or supine width.
although there are large body composition data sets available, subjects above 136 kg were excluded due to equipment limitations [36].
recent dxa equipment improvements, such as the lunar idxa (ge healthcare) and discovery/horizon models (hologic, inc.), have increased scan area widths and weight capacities, improving the capability to assess more people with obesity.
notably, this study was completed prior to initiation of obesity treatment at the clinic.
weight loss is associated with reductions in both fm and lst, with weight regain predominately as fm [10].
if people with low lst are not identified as such, initiating obesity treatments targeted to reduce weight can further reduce lst, thereby either creating or worsening a sarcopenic state.
limitations of our study include our ambulatory cohort seeking obesity treatment, which may not reflect all adults with obesity or other care settings (i.e., acute care, long term care).
although the representation of males in the current study appears low, it is comparable to other studies conducted in this clinic [43, 44].
in general, males tend to be underrepresented in obesity treatment studies [45, 46].
additionally, we were unable to explore definitions of sarcopenia using a measure of muscle function, as these were not collected as part of patient's initial assessment.
5. conclusions sarcopenia was present in our cohort but masked by obesity.
basic anthropometric measurements alone are inadequate to identify sarcopenia and hence sarcopenic obesity in these individuals.
sophisticated tools such as dxa may be needed to identify and profile lst of adults with class ii/ii obesity and could be implemented as part of clinical assessment.
the inclusion of measures of fm and body size in the definition of sarcopenic obesity identifies a greater proportion of individuals with this abnormal body composition phenotype compared to stand-alone definition of low lean mass.
different diagnostic criteria should be tested in prospective studies investigating the risk prediction for metabolic, functional, and clinical parameters of these adults with class ii/iii obesity.
@highlight
background/objective.
sarcopenic obesity (so) is a hidden condition of reduced lean soft tissue (lst) in context of excess adiposity.
so is most commonly reported in older adults and both its risk and prevalence increase with age.
a variety of body composition indices and cut points have been used to define this condition, leading to conflicting prevalence and risk prediction.
here, we investigate variability in the prevalence of so in an adult sample of individuals with class ii/iii obesity (bmi ≥ 35 kg/m2) using different diagnostic criteria.
methods.
so definitions were identified from a literature review of studies using dual-energy x-ray absorptiometry (dxa) to assess lst.
demographics, anthropometrics, and body composition (by dxa) were measured in n = 120, 86% female (46.9 ± 11.1 years).
results.
lst was extremely variable in individuals, even with similar body sizes, and observed across the age spectrum.
the prevalence of so ranged from 0 to 84.5% in females and 0 to 100% in males, depending upon the definition applied, with higher prevalence among definitions accounting for measures of body size or fat mass.
conclusion.
so is present, yet variable, in adults with class ii/iii obesity.
accounting for body mass or fat mass may identify a higher number of individuals with so, although risk prediction remains to be studied.
