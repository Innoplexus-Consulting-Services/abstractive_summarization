chikungunya virus (chikv) and dengue virus (denv) are arboviruses currently circulating in southeast asia, central and west africa, the pacific islands, and the americas, and their transmission can occur simultaneously (1).
denv and chikv co-infections have been reported from 13 of 98 countries/territories to which the viruses are endemic and are more likely to occur in areas with high transmission intensity.
co-infection rates reported have ranged from 2% in gabon to 34% in nigeria (1–3).
the americas are currently experiencing an unprecedented number of denv infections that coincided with emergence of chikv infections.
a total of 2.3 million denv infections and 635,000 chikv infections were reported in this region in 2015 (4,5).
however, details of the frequency of co-infection are lacking (1), although a recent study involving 173 samples from nicaragua that were positive for either virus found a co-infection rate of 22% (6).
co-infections might be frequently missed by surveillance systems because pan american health organization (paho) diagnostic algorithms indicate that denv-positive samples do not need to be tested for chikv or other viruses and vice versa (7).
the clinical role of co-infection is somewhat disputed because some (8) but not all (1,9) studies reported an association between co-infection and disease severity for symptoms such as diarrhea (9) or hemorrhage (10).
although guatemala has had constant dengue transmission for >20 years (11), the first cases of chikv infection were reported in september 2014. we report the proportion of patients co-infected with denv and chikv and the association of co-infection with disease severity among patients referred for diagnosis to the national health laboratory (nhl) in guatemala city, guatemala, in june 2015. because zika virus was not introduced until november 2015, we did not test for this virus in this study.
the study serum samples from febrile persons suspected of having arboviral infections are referred to the nhl in guatemala for surveillance and confirmation purposes.
for logistical reasons, most samples are received from 12 of the 22 districts in guatemala, and most samples originate from quetzaltenango, guatemala, and escuintla districts, the largest urban centers in guatemala.
we selected for screening a convenience set of consecutive samples received in june 2015, which is the peak transmission season for denv, and reported as having positive results by reverse transcription pcr (rt-pcr) for either virus.
clinical data for patients were obtained from surveillance databases to compare patients with monoinfections or coinfections with denv or chikv.
all samples were obtained from patients <5 days of symptom onset.
samples were obtained after patients provided consent and donated to laboratories for further testing.
all samples were anonymous.
results of the study were not used for clinical management or surveillance purposes.
during june 2015, a total of 523 samples were tested for chikv at the nhl; 328 (63%) were positive for chikv rna by rt-pcr.
a total of 514 samples were also tested by rt-pcr for denv; 75 (9%) were positive (figure).
seventy-four of samples reported as positive for denv rna and 70 samples reported as positive for chikv rna were available for further screening for the other virus.
figure positivity of samples tested for a) dengue virus and b) chikungunya virus, guatemala, 2015. samples selected were consecutive positive samples from the beginning of the month; there were no additional exclusion or inclusion criteria.
we included as many samples as possible within the time available.
rna was extracted by using a viral rna mini kit (qiagen, manchester, uk) and tested by using the us centers for disease control (cdc; (atlanta, ga, usa) multiplex denv rt-pcr and the cdc chikv 6856f/6981c/6919-fam rt-pcr (12).
twenty-five (33.8%) of 74 denv-positive samples were positive for chikv, and 21 (30%) of 70 chikv-positive samples were positive for denv rna.
co-infection with chikv was detected in 4/9 samples containing denv-1, 40/76 samples containing denv-2, 0/3 samples containing denv-3 and 2/7 samples containing denv-4.
clinical characteristics of patients with chikv and denv monoinfections and co-infections were similar (table).
patients co-infected with chikv and denv were more likely to have a rash than those with denv monoinfections (p = 0.02) and were more likely to be hospitalized than those with chikv monoinfections (p = 0.002).
all other associations were not statistically significant.
table characteristics of patients infected with chikungunya virus, dengue virus, or both, guatemala, 2015* characteristic chikv moninfection denv monoinfection denv/chikv co-infection p value chikv vs co-infection denv vs co-infection no.
samples tested 49 49 46 sex m 15/48 (31) 23/45 (51) 21/46 (46) 0.2 0.6 f 33/48 (69) 22/45 (49) 25/46 (54) 0.2 0.6 age, y <1 2/48 (4.2) 3/45 (7) 5/46 (11) 0.2 0.7 2–16 15/48 (31) 26/45 (58) 19/46 (41) 0.4 0.1 17–30 13/48 (27) 6/45 (13) 9/46 (20) 0.4 0.5 31–60 14/48 (29) 9/45 (20) 10/46 (22) 0.5 1 >60 4/48 (8.3) 1/45 (2) 3/46 (7) 1 0.6 sign/symptom hemorrhage 7/49 (14) 11/44 (25) 8/44 (18) 0.8 0.6 arthralgia/myalgia 41/44 (93) 36/42 (86) 35/45 (77) 0.07 0.4 fever 43/48 (90) 41/42 (98) 46/46 (100) 0.06 0.5 rash 31/48 (65) 11/43 (26) 23/44 (52) 0.3 0.02 nausea 26/46 (57) 31/44 (70) 22/44 (50) 0.7 0.08 vomiting 13/46 (28) 21/43 (49) 16/45 (36) 0.5 0.3 diarrhea 3/18 (17) 10/34 (29) 6/25 (24) 0.7 0.8 headache 40/47 (85) 35/42 (83) 40/44 (91) 0.5 0.3 hospitalization 0/48 (0) 16/45 (36) 8/46 (17) 0.002 0.09 death 0/48 (0) 4/45 (9) 2/46 (4) 0.2 0.4 *values are no.
positive/no.
tested (%) unless otherwise indicated.
chikv, chikungunya virus; denv, dengue virus.
conclusions our findings must be viewed with caution because of the limitations of this study.
the study was not powered to analyze clinical associations with a high robustness because of the small number (n = 46) of co-infected samples tested.
also, because samples were selected at a reference laboratory and only symptomatic cases were tested, the prevalence of co-infection might be different in a less selected population.
the paho algorithm recommends screening clinical specimens by using consecutive assays and ending screening once a pathogen is identified.
cdc in turn recommends simultaneously conducting rt-pcrs for denv, chikv, and zika virus.
emergence of zika virus in latin america has further complicated diagnosis of arboviral infections, and simultaneous co-infections with all 3 arboviruses have been reported (13).
although the paho approach misses co-infections, the cdc approach is costlier.
guatemala used the paho algorithm because of a shortage of consumable supplies.
on further testing, 25 (33.8%) of 74 denv-positive samples were positive for chikv, and 21 (30%) of 70 chikv-positive samples were positive for denv.
because guatemala reported 49,043 cases of denv and chikv infections in 2015, it is likely that the algorithm missed a large number of co-infections.
patients with single and dual infections had similar clinical manifestations in this limited study.
the frequency of arbovirus coinfections in guatemala is high.
simultaneous screening for denv, chikv, and zika virus in disease-endemic areas would improve the quality of arboviral surveillance and potentially aid in clinical management of the disease.
@highlight
we screened serum samples referred to the national reference laboratory in guatemala that were positive for chikungunya or dengue viruses in june 2015. co-infection with both viruses was detected by reverse transcription pcr in 46 (32%) of 144 samples.
specimens should be tested for both arboviruses to detect co-infections.
