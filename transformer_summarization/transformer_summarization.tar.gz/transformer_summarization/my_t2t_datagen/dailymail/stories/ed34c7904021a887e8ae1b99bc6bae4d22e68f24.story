introduction the anthracyclines (ac), which are a key component of many chemotherapy regimens, are clearly the most cardiotoxic chemotherapeutic agents producing left ventricular dysfunction and arrhythmias.1 atrial conduction system abnormalities play a major role in the genesis of re-entrant atrial arrhythmias.
left atrial (la) volume and mechanical function have recently been identified as a potential indicator of cardiac dysfunction and arrhythmias.2,3 intra- and inter-atrial electromechanical delays are well-known electrophysiological features of the atrium prone to fibrillation.4 echocardiography is a sensitive and reproducible technique for the assessment of atrial mechanical and electromechanical features.5,6 atrial electromechanical delay had been shown to be prolonged in patients with nonrheumatic paroxysmal atrial fibrillation, obesity, hyperthyroidism, and celiac disease.7-10 the pathophysiology and predictors of arrhythmias after treatment with ac are poorly defined.
the hypothesis of the present study was that atrial mechanical and electromechanical features might be affected in patients treated with ac.
therefore, we aimed to assess atrial mechanical and electromechanical features in patients after the administration of anthracycline chemotherapy and to compare them with healthy controls and then to evaluate their relationship with parameters of left ventricular function on echocardiography.
methods study population the study design was retrospective.
fifty-three women with breast cancer were selected from consecutive patients who received 240 mg/m2 of adriamycin, 2400 mg/m2 of cyclophosphamide, and 960 mg/m2 of paclitaxel at our institution between january 1, 2013 and december 31, 2013. a power analysis was performed before the study.
accordingly, when a reference study was considered, 28 subjects (14 in each group) would have resulted in 95% confidence and 90% power.
we included 95 subjects (53 patients and 42 controls) in the present study.
the power analysis showed that our results, when examined for inter-atrial emd values, reached 95% confidence and 94% power.
these women had a comprehensive echocardiographic examination before the treatment, which showed truly normal lv systolic and diastolic function.
the control group was comprised by 42 age-and sex-matched healthy female office staff.
exclusion criteria were ischemic heart disease, moderate-to-severe valvular heart disease, heart failure, hypertension, diabetes mellitus, obesity, systolic and/or diastolic dysfunction, atrial fibrillation, bundle branch block, atrioventricular conduction abnormalities on electrocardiogram, acute or chronic renal failure, collagen tissue disease, thyroid dysfunction, electrolyte imbalance, pulmonary disease, anemia, chronic liver disease, prior history of radiation therapy, life expectancy< 1 year, and insufficient echocardiographic imaging.
none of the participants were taking any antiarrhythmics, tricyclic antidepressants, antihistaminics, angiotensin-converting enzyme inhibitors, angiotensin receptor blockers, and antipsychotics.
heart rate, blood pressure, and routine biochemistry were measured in all participants.
exercise tolerance test to exclude ischemic heart disease was performed in all subjects.
a total of 750 women with breast cancer were examined as to their eligibility for our study.
the institution's medical ethics review committee approved the study protocol (registration number: 60116787-020/7763, date of issue: 06.02.2014).
informed consent was obtained from all participants.
the study protocol conforms to the ethical guidelines of the 1975 declaration of helsinki.
transthoracic echocardiography echocardiographic examinations were carried out by using vivid-7 echocardiography device with a 2.5-4 mhz probe (ge vingmedultrasound, horten, norway).
all participants were examined in the left lateral decubitus position by 2-d, m-mode, pulsed and color flow doppler, and tissue doppler echocardiography.
continuous 1-lead ecg recording was performed during the examination.
lv ejection fraction was obtained from two- or apical four-chamber views through the modified simpson method.
to obtain maximum filling velocities, the pulsed-doppler sampling volume was placed between the tips of the mitral valve leaflets in the apical four-chamberview.
myocardial velocity profiles of the lateral and septal mitral annuli were obtained.
tissue doppler measurements were obtained by placing the sample volume at the junction of the mitral annulus and the septum, and lateral wall.
all measurements were recorded as an average of 3 cardiac cycles.
left atrial volumes (la v) were obtained from apical four-chamber view through the discs method and indexed for body surface area (bsa).
la v measurements were performed at the mitral valve opening (maximal, vmax), the onset of atrial systole (p wave on electrocardiogram, vp), and the mitral valve closure (minimal, vmin) (figure 1 a-c).
the following la emptying function parameters were calculated: la passive emptying volume = vmax-vp, la passive emptying fraction = (vmax-vp)/vmax, la active emptying volume = vp-vmin, la active emptying fraction = (vp-vmin)/vp.10 all volumes were indexed to bsa and expressed in ml/m2.
atrial electromechanical coupling (pa) was defined as the time interval from the onset of the p wave on surface electrocardiogram to the beginning of the late diastolic wave (am wave).
pa was obtained from the lateral mitral annulus (pa lateral), septal mitral annulus (pa septum), and right ventricular tricuspid annulus (pa tricuspid) (figure 2 a-c).
values were averaged over 3 consecutive beats.
the difference between pa lateral and pa tricuspid was defined as inter-atrial electromechanical delay, the difference between pa lateral and pa septum was defined as left intra-atrial electromechanical delay, and the difference between pa septum and pa tricuspid was defined as right intra-atrial electromechanical delay.10 figure 1la volumes are measured in the a4c views by means of 2d echo at the mitral valve opening (a), at the onset of atrial systole (b), and at the mitral valve closure (c).
figure 2measurements of time interval from the onset of p wave to the beginning of am wave (pa) are obtained at the lateral mitral annulus (a), septal mitral annulus (b), and rv tricuspid annulus (c).
reproducibility one experienced operator blinded to clinical and laboratory characteristics of the participants analyzed all echocardiographic data.
intraobserver variability was assessed in 30 selected subjects randomly from the both groups by repeating the measurements.
measurements were repeated 1 week apart.
only one reader conducted this analysis.
the reader was allowed to select the best measurement each time and was blinded to previous measurements.
intraobserver variability was calculated as the difference between two measurements of the same patient by a single cardiologist divided by the mean value.
statistical analysis categorical variables are expressed as percentages and continuous variables as mean ± standard deviation and median with minimum-maximum values.
continuous variables were compared between groups using independent t tests (for normally distributed variables) or a mann-whitney u test (for variables not normally distributed).
categorical data were compared with the chi-square test.
a multiple linear regression analysis was used to identify independent predictors of la mechanical function impairment and electromechanical delays.
p values < 0.05 were considered to indicate statistical significance.
all analyses were performed using spss version 15.0 (spss, inc., chicago, il).
results clinical and echocardiographic findings of the patients (53 women, 48 ± 8 years) and controls (42 women, 47 ± 9 years) are listed in table 1. none of the patients had developed cardiac complications including atrial fibrillation.
age, weight, body mass index, body surface area, systolic and diastolic blood pressures, heart rate, and lv ef were similar between the 2 groups.
the mean duration of time elapsed from the completion of chemotherapy to the performance of echocardiography was 11 ± 7 months (median 9 months).
the mitral a-wave velocity, e-wave deceleration time, am velocities, e/em ratio were significantly higher in the patients.
the mitral em velocities, e/a ratio were significantly lower in the patients.
the other conventional echocardiographic parameters such as lv ef, ivs and pw thickness, la diameter, lvedd, lvesd, and systolic pulmonary artery values were within normal reference ranges, with no significant differences between the 2 groups (data not shown).
table 1 characteristics of the study subjects   patients (n=53) controls (n=42)     mean ± sd med.
(min.
– max.)
mean ± sd med.
(min.
– max.)
p value demographic and clinical characteristics   age, years 48 ± 8 49(29 - 65) 46 ± 9 47(30 - 65) 0.419 body mass index, kg/m2 23.98  ± 2.41 23.8 (19.5 – 28.1) 23.72  ± 2.33 23.8 (20.3 – 28.5) 0.603 body surface area, m2 1.77 ± 0.14 1.8(1.5 – 2.1) 1.74 ± 0.13 1.7(1.5 – 2.1) 0.142 systolic blood pressure, mmhg 118 ± 9 120 (100 – 135) 120  ± 9 120 (100 – 135) 0.396 diastolic blood pressure, mmhg 71 ± 5 70 (60 – 85) 73 ± 5 73 (60 – 85) 0.064 heart rate, beats/min 72 ±11 70 (64-90) 74 ± 11 72 (62-88) 0.104 lv ejection fraction, % 63 ± 5 63 (49 - 74) 64 ± 5 62(57-78) 0.958 effect of chemotherapy on doppler parameters   mitral e velocity, m/s 0.8 ± 0.2 0.8 (0.5-1.1) 0.8 ± 0.2 0.7 (0.4-1.2) 0.223 mitral a velocity, m/s 0.8 ± 0.2 0.8 (0.5–1.2) 0.7 ± 0.2 0.6 (0.4-1.0) 0.0001* mitral e deceleration time, m/s 201.3 ± 35.6 196.3 (126-291.1) 163.7 ± 21.8 166.2 (109.9-203.7) 0.0001* mitral e/a ratio 1.0 ± 0.3 0.9 (0.5-1.9) 1.3 ± 0.3 1.3 (0.7-2.3) 0.0001* mitral mean em, m/s 0.09 ± 0.03 0.09 (0.05-0.16) 0.11 ± 0.03 0.11 (0.05-0.2) 0.001* mitral mean am, m/s 0.11 ± 0.02 0.11(0.06 – 0.14) 0.09 ± 0.02 0.09 (0.06-0.12) 0.0001* mitral e/mean em ratio 8.8 ± 3.2 8.7 (3.9-23.1) 7.6 ± 2.6 7.1 (4.1-16.8) 0.017* * p<0,05 statistically significant; sd: standard deviation; med: median; min-max: minimum - maximum values left atrial mechanical functions la volume measurements of the study subjects are presented in table 2. maximum la volume, vp, la active emptying volume (laaev) and fraction were significantly increased in the patients.
la passive emptying volume (lapev) and fraction were significantly decreased in the patients.
the mitral e-wave deceleration time was weakly associated with la passive emptying fraction (lapef), la active emptying volume, and fraction.
the reservoir function and total la emptying did not change in the patients (data not shown).
table 2 left atrial volume measurements of the study subjects   patients (n=53) controls (n=42)     mean ± sd med.
(min.
– max.)
mean ± sd med.
(min.
– max.)
p value effect of chemotherapy on atrial function   vmax1, ml/m2 23.76 ± 5.2 22.82 (16.54 – 38.81) 20.71 ± 3.22 20.6 (14.71 – 28.61) 0.001* vp2, ml/m2 16.34 ± 4.55 15.65 (10.41 – 31.57) 11.07 ± 2.19 11.29 (6.27 – 14.88) 0.0001* vmin3, ml/m2 8.78 ± 2.98 8.33 (4.66 – 18.95) 7.7 ± 1.79 7.96 (4 – 10.31) 0.153 la passive emptying volume, ml/m2 7.41 ± 2.01 7.42 (3.01 – 12.32) 9.64 ± 2 9.71(4.92 – 14.54) 0.0001* la passive emptying fraction, % 31.6 ± 7.37 31.02 (15.8 – 45.49) 46.53 ± 7.03 45.34 (31.33-67.51) 0.0001* la active emptying volume, ml/m2 7.56 ± 2.21 7.25 (4.66-16.04) 3.41 ± 0.74 3.45 (2.15-4.75) 0.0001* la active emptying fraction, % 46.67 ± 7.04 45.45 (33-63.19) 31.19 ± 5.24 31.66 (19.73-44.77) 0.0001* * p<0,05 statistically significant; sd: standard deviation; med: median; min-max: minimum - maximum values.
1vmax: volume measurements were performed at the mitral valve opening; 2vp: volume measurements were performed at the onset of atrial systole; 3vmin: volume measurements were performed at the mitral valve closure.
la: left atrial.
atrial electromechanical coupling the atrial electromechanical coupling intervals measured from different sites are shown in table 3. pa lateral, inter-atrial, and left intra-atrial electromechanical delays were significantly higher in the patients.
however, pa septum, pa tricuspid, and right intra-atrial electromechanical delays did not differ significantly between the groups.
e/a ratio was weakly associated with left intra-atrial and inter-atrial electromechanical delays (data not shown).
table 3 atrial electromechanical coupling findings measured by tissue doppler imaging   patients (n=53) controls (n=42) p value   mean ± sd med.
(min.
– max.)
mean ± sd med.
(min.
– max.)
effect of chemotherapy on atrial function   pa lateral, ms 59.12 ± 8.91 59.15 (36.97-78.82) 54.04 ± 9.43 51.76 (36.97-73.94) 0.008* pa septum, ms 47.72 ± 9.1 48.06 (29.57-69.54) 45.91 ± 9.5 44.36 (25.88-66.85) 0.348 pa tricuspid, ms 39.18 ± 8.36 40.67 (22-57.3) 39.35 ± 8.71 37.9 (22.18-62.85) 0.921 inter-atrial emd, ms 19.73 ± 7.38 18.49 (8.06-38.82) 14.69 ± 6.51 13.7 (7.39-29.58) 0.001* left intra-atrial emd, ms 11.4 ± 5.98 10.76 (1.85-25.88) 8.13 ± 4.87 7.39 (1.84-22.18) 0.008* right intra-atrial emd, ms 8.52 ± 5.48 7.39 (1.85-25.18) 6.56 ± 4.09 4.77 (2.61 – 22.18) 0.194 * p<0,05 statistically significant; sd: standard deviation; med: median; min-max: minimum - maximum values.
emd: electromechanical delay; pa: the time interval from the onset of p wave on surface electrocardiogram to the beginning of am wave with tdi.
among patients, the body mass index, diastolic blood pressure, mitral e deceleration time were independent predictors for lapef.
the systolic blood pressure, diastolic blood pressure, mitral e deceleration time were independent predictors for laaev.
among controls, age, mitral e/a ratio were independent predictors for laaef (table 4).
table 4 multiple linear regression analysis of subject characteristics influencing la mechanical function impairment patient group dependent variable: lapef  standardized beta sig.
(p) 95,0% ci lower - upper age -0,098 0,505 -0,334 - 0,167 bmi 0,292 0,037* 0,054 - 1,733 sbp -0,312 0,058 -0,491 - 0,008 dbp 0,575 0,001* 0,303 - 1,118 mitral e/a ratio -0,009 0,949 -6,964 - 6,53 mitral e deceleration time -0,271 0,039* -0,109 - -0,003 mitral e/mean em ratio 0,053 0,696 -0,507 - 0,752 r2=0,321; model p=0,01; bmi: body mass index; ci: confidence interval; dbp: diastolic blood pressure; lapef: left atrial passive emptying fraction; sbp: systolic blood pressure; * statistically significant.
patient group dependent variable: laaev  standardized beta sig.
(p) 95,0% ci lower - upper age -0,042 0,783 -0,089 - 0,067 bmi -0,186 0,196 -0,432 - 0,091 sbp 0,461 0,008* 0,029 - 0,184 dbp -0,576 0,001* -0,341 - -0,086 mitral e/a ratio -0,010 0,948 -2,17 - 2,034 mitral e deceleration time 0,285 0,036* 0,001 - 0,034 mitral e/mean em ratio 0,076 0,587 -0,143 - 0,249 r2=0,152; model p=0,041; bmi: body mass index; ci: confidence interval; dbp: diastolic blood pressure; laaev: left atrial active emptying volume; sbp: systolic blood pressure; * statistically significant.
control group dependent variable: lapef  standardized beta sig.
(p) 95,0% ci lower - upper age -0,541 0,005* -0,509 - -0,101 bmi -0,311 0,065 -1,445 - 0,045 sbp 0,189 0,213 -0,065 - 0,283 dbp -0,100 0,508 -0,359 - 0,181 mitral e/a ratio -0,437 0,017* -12,325 - -1,293 mitral e deceleration time -0,103 0,493 -0,098 - 0,048 mitral e/mean em ratio 0,221 0,168 -0,199 - 1,1 r2=0,243; model p=0,018; bmi: body mass index; ci: confidence interval; dbp: diastolic blood pressure; lapef: left atrial passive emptying fraction; sbp: systolic blood pressure; * statistically significant.
intra-observer variability was less than 5% for all echocardiographic measurements.
discussion the present study showed that left intra-atrial and inter-atrial em intervals were prolonged; lv diastolic function was impaired in patients with breast cancer treated with ac, despite preservation of la mechanical functions.
this study suggests that proarrhythmogenic mechanisms could be the result of changes in cardiac function, including lv diastolic dysfunction and delayed electrical conduction, which create an arrhythmogenic substrate.
this arrhythmogenic substrate leads to a decrease in intracardiac conduction and to a heterogeneous dispersion of repolarization, two effects that facilitate the genesis of cardiac arrhythmias in those patients.
this study also showed that diastolic function parameters were significantly impaired in the patients.
we were not able to demonstrate systolic dysfunction in our patients because we could not perform global strain evaluation.
the most common cardiotoxicity of ac is left ventricular systolic dysfunction with possible arrhythmias.
studies examining the occurrence of arrhythmia in patients treated with ac are scarce.
atrial fibrillation appears to be a rather common complication of ac and in one study, it was described in 2-10% of the patients.11 there are a limited number of studies investigating diastolic function in patients treated with ac.
there is no consensus regarding whether diastolic function is impaired in those patients.
in this study, patients with breast cancer after ac did not display any significant change in total la emptying, despite the fact that we showed that la active emptying volume and la active emptying fraction were increased in those patients.
this may suggest preservation of atrial mechanical function early in the course of breast cancer survivors treated with ac.
yet it is possible to consider that the decrease in la passive emptying volume is related to elevated end-diastolic lv pressure at least due to lv diastolic dysfunction.
the shift in early and late diastolic ventricular filling might have occurred secondary to impaired relaxation.
la mechanical function plays a significant role to maintain cardiac output in patients with dd.12 la mechanical function is an important determinant of lv filling, especially in patients with end-stage systolic or diastolic ventricular dysfunction.12 it consists of reservoir, conduit, and booster pump functions.
in previous studies, it was demonstrated that la mechanical functions were impaired in patients with hypertension, chronic obstructive lung disease, and type 1 diabetes mellitus.4,13,14 in addition, la volume has been shown to be a powerful prognostic variable in a variety of cardiac disease states.
compared with ap diameter, la volume has a stronger association with outcomes in cardiac patients.15 left atrial total emptying fraction was reported to be an independent and strong predictor for the development of af.10 the present study revealed that left intra- and interatrial emd were significantly prolonged in the patients.
only mitral e/a ratio was weakly associated with la emd.
increased em delay was found to assist in the identification of subjects at increased risk of af.
atrial conduction time reflects both electrical and structural atrial remodeling.
atrial emd has been reported to be associated with low-grade inflammation, insulin resistance, la enlargement, early lv diastolic dysfunction, and oxidative stress.4,16-18 therefore, the impaired conduction observed in the present study could be associated with an increased risk of af.
the prolonged em intervals observed in this study could be explained by anthracycline-induced oxidative stress, which has been associated with autonomic dysfunction.18,19 prolonged em intervals may also indicate atrial remodeling during arrythmogenic process and may be a predictor of af.7,20 autonomic nervous system may play a role in the development of atrial fibrillation by its effects on atrial conduction time (heterogeneity).21,22 studies looking at atrial function in patients treated with cardiotoxic chemotherapy are limited.
our results are consistent with a previous study by ceyhan et al., which reported that intra- and inter-atrial conductions were delayed in patients treated with 5-florouracil.23 the results of our multiple linear regression analysis are inconclusive due to low r² values.
they may suggest that risk factors for diastolic dysfunction such as blood pressure, bmi, age, and diastolic dysfunction itself may play role in la mechanical function impairment.
clinical implications these alterations may be an early form of subclinical cardiac involvement in breast cancer survivors treated with ac and with no cardiovascular risk factors.
we can speculate that these patients may be at a higher risk to develop new or recurrent atrial arrhythmias particularly atrial fibrillation.
monitoring could be prudent in those patients to guide additional interventions such as anti-arrhythmic and/or anti-coagulant therapy.
this could lead to a better clinical management and improved patient outcome.
study limitations in this study, patients also received cyclophosphamide and paclitaxel simultaneously, which makes it difficult to decide which one caused these adverse effects.
pretreatment evaluation with comprehensive echocardiography including assessment of atrial mechanical and electromechanical features had not been done.
however, the patients were selected among the ones who had truly normal lv systolic and diastolic function on the baseline studies.
these alterations might have been attributed incorrectly to the adverse effects of chemotherapeutic agents.
la volume should be measured using the disk summation algorithm in both the apical four- and two- chamber views.
we had measured them from a single-plane apical four-chamber approach, which is typically 1 to 2 ml/m2 smaller than apical two-chamber volumes.15 however, we used the same technique for both patients and controls.
we excluded patients with cardiovascular risk factors that can create an arrhythmogenic substrate.
we cannot rule out systolic dysfunction, as we could not study global strain.
further research is needed to define a true incidence and clinical relevance of atrial arrhythmias in those patients and to determine the role of holter monitoring for the early diagnosis, intervention and surveillance of those patients more susceptible to develop arrhythmia.
conclusions our study revealed that left intra- and inter-atrial em were prolonged and that lv diastolic function was impaired in breast cancer survivors treated with ac.
impaired electrical conduction in those patients may be associated with the development of arrhythmias.
@highlight
background atrial electromechanical delay (emd) is used to predict atrial fibrillation, measured by echocardiography.
objectives the aim of this study was to assess atrial emd and mechanical function after anthracycline-containing chemotherapy.
methods fifty-three patients with breast cancer (48 ± 8 years old) who received 240 mg/m2of adriamycin, 2400 mg/m2 of cyclophosphamide, and 960 mg/m2 of paclitaxel were included in this retrospective study, as were 42 healthy subjects (47 ± 9 years old).
echocardiographic measurements were performed 11 ± 7 months (median 9 months) after treatment with anthracyclines.
results left intra-atrial emd (11.4 ± 6.0 vs. 8.1 ± 4.9, p=0.008) and inter-atrial emd (19.7 ± 7.4 vs. 14.7 ± 6.5, p=0.001) were prolonged; la passive emptying volume and fraction were decreased (p=0.0001 and p=0.0001); la active emptying volume and fraction were increased (p=0.0001 and p=0.0001); mitral a velocity (0.8 ± 0.2 vs. 0.6 ± 0.2, p=0.0001) and mitral e-wave deceleration time (201.2 ± 35.6 vs. 163.7 ± 21.8, p=0.0001) were increased; mitral e/a ratio (1.0 ± 0.3 vs. 1.3 ± 0.3, p=0.0001) and mitral em (0.09 ± 0.03 vs. 0.11 ± 0.03, p=0.001) were decreased; mitral am (0.11 ± 0.02 vs. 0.09 ± 0.02, p=0.0001) and mitral e/em ratio (8.8 ± 3.2 vs. 7.6 ± 2.6, p=0.017) were increased in the patients.
conclusions in patients with breast cancer after anthracycline therapy: left intra-atrial, inter-atrial electromechanical intervals were prolonged.
diastolic function was impaired.
impaired left ventricular relaxation and left atrial electrical conduction could be contributing to the development of atrial arrhythmias.
