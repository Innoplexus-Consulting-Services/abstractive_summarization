introduction isolated dislocation of the carpal scaphoid is a rare injury.
to the best of our knowledge only approximately 35 cases have been reported in the literature since 1930. the present case is unique in the following aspects: (1) there was a delay of 2 months in treatment; (2) 6 years mid term followup was conducted; (3) suture anchor repair of the scapholunate ligament was done and blatt's dorsal capsulodesis were performed.
case report a 40 year old male presented with a chief complaint of pain in the right dominant wrist.
two months prior to presentation, he sustained injury to the right wrist while protecting himself with extended right upper extremity upwards from heavy object falling from a high place.
initially, he did not seek any treatment despite immediate severe pain.
however, symptoms of the injured wrist, including swelling and pain increased over time.
examination of the right wrist revealed generalized swelling, diffuse tenderness, limited range of motion, at wrist and an abnormal bony prominence in the palmar aspect of the scaphoid.
the function of the fingers was unimpaired.
there was no sign of neurovascular injury.
radiographs of wrist showed an isolated palmar dislocation of the scaphoid and there were no abnormal findings in other carpal bones [figure 1].
these findings were confirmed with computed tomography [figure 2].
figure 1 initial radiograph of wrist joint with forearm posteroanterior (a) and lateral (b) view showing isolated scaphoid palmar dislocation figure 2 (a) axial, (b) coronal, (c) sagittal, and (d) three-dimension computed tomography scans of wrist showing isolated scaphoid palmar dislocation initially, closed reduction was attempted by longitudinal traction and ulnar deviation undermanual application of direct pressure over the dislocated scaphoid under general anesthesia, but it was unsuccessful.
we determined further attempts would be futile considering that 2 months had already passed from the date of trauma.
thus, open reduction was performed through a dorsal approach.
after capsulotomy, the isolated palmar scaphoid dislocation was observed, and a complete tear of the scapholunate ligament was noted [figure 3].
although we could not identify the integrity of the volar side ligaments, we assumed that they were disrupted.
reduction was interrupted due to fibrotic soft tissue interposed in the scapholunate interval.
after debridement and retraction, the dislocated scaphoid was reduced [figure 4].
the torn scapholunate ligament was sutured using a mitek anchor (depuymitek, inc. raynham, ma, usa) and the reduced scaphoid was stabilized using two kirschner wires (one scapholunate wire and one scaphocapitate wire).
in addition, blatt's dorsal capsulodesis was performed using a mitek anchor to prevent rotary subluxation of the distal pole of the scaphoid [figure 5].
after wound closure, an above the elbow thumb spica splint was applied for 2 weeks.
an above the elbow thumb spica cast was worn in the same position for the subsequent 3 weeks, which was followed by application of a below the elbow thumb spica cast for an additional 2 weeks.
in the 7th postoperative week, kirschner wires were removed and rehabilitation was started.
figure 3 intraoperative photograph showing the completely torn scapholunate ligament and scaphoid palmar dislocation.
(c; capitate, s;scaphoid, l; lunate) figure 4 intraoperative photograph showing reduced scaphoid figure 5 immediate postoperative radiographs showing reduced scaphoid with kirschnerwire fixation and two mitek anchor sutures the patient showed satisfactory wrist function on subsequent followup.
he was doing regular physiotherapy.
he was able to return to his work as a manual laborer and had no complaints of residual pain.
at 6 years followup, his radiographs of wrist showed a normal carpal alignment with a scapholunate gap of 3 mm and no evidence of avascular necrosis (avn) of the scaphoid [figure 6].
the grip strength measured using a dynamometer was 21 kg in the right wrist (20 kg in the left wrist).
the range of motion in the right wrist was 60° dorsiflexion, 55° palmar flexion, 25° ulnar deviation and 15° radial deviation (70°, 70°, 30° and 15°, respectively, in the left wrist).
figure 6 followup x-rays six years after surgery showing that there was no avascular necrosis of scaphoid or redislocation discussion isolated scaphoid dislocation is an extremely rare injury.
the exact mechanism of scaphoid dislocation has yet to be established, but it is generally believed to involved dorsiflexion and ulnar deviation with or without rotational forces.12 there are several treatment options for scaphoid dislocation: closed reduction and immobilization with a cast,34 closed reduction and percutaneous pinning,56 open reduction and pinning7 and open reduction and pinning followed by ligament repair.189 these treatment modalities are comparable in terms of long term clinical outcomes and share a relatively favorable prognosis.
however, if diagnosis and treatment are delayed, open reduction and ligament repair may become inevitable.101112 in our patient, we performed open reduction, kirschner wire pinning, interosseous ligament repair, and blatt's capsulodesis.
open reduction was considered necessary, in part due to failed attempt at closed reduction, but mainly due to the need for ligament repair for enhanced stability after anatomical reduction.
open reduction and ligament repair have increasingly become more practical treatment strategy as demonstrated in previous studies.781113 the torn scapholunate ligament was repaired to prevent scapholunate dissociation, which is the most common complication associated with scaphoid dislocation.14 a dorsal approach was used for ligament repair since the patient showed no sign of median nerve compression, thereby eliminating the need for the palmar approach.
furthermore, this approach allowed access to the strongest portion of the scapholunate interosseous ligament which is dorsal.
in general, ligament reconstruction is considered a more appropriate option than repair for delayed treatment of ligament injuries.
however, we thought repair using the remnant ligament tissue would yield better results in our case and stability of the scaphoid could be improved by blatt's capsulodesis.
the closed reduction failure can be attributed mainly to the presence of interposed soft tissue as well as to treatment delay.
thus, we believed it is reasonable to undertake open reduction in cases where closed reduction appears unattainable after one or two attempts.
in contrast to most studies using only suture materials, we utilized an anchor device for ligament repair as suggested vy akinci m et al.
(2012) and samford mp et al.
(2010).1015 blatt's capsulodesis was additionally carried out to prevent rotary subluxation and improve stability of the scaphoid16 which has never been employed by other authors other than gómez et al.13 avn of the scaphoid is a potential complication, but only one case of avn after isolated scaphoid dislocation has been reported.9 the low incidence of avn following partial scaphoid dislocation can be attributed to the remaining scaphotrapezial ligament and capsular attachments providing sufficient blood supply.817 in cases of complete disruption of all ligamentous attachments, undisturbed intraosseous channels within the intact scaphoid bone allow rapid revascularization from surrounding soft tissue.1 there was no development of avn in our case as in other previous reports, which, however, is notable considering that the followup period was relatively long (6-years) compared to the other short-term followup studies.241118 we believe ligament repair with open reduction effectively enhanced revascularization of the scaphoid from surrounding soft tissue, contributing to the prevention of avn.
delayed diagnosis and treatment is a major risk factor for unfavorable prognosis of scaphoid dislocation.15671219 however, despite the 2 months delay, treatment results were satisfactory in our patient.
to conclude, although early diagnosis and treatment is an important prognostic factor, accurate anatomic reduction, ligament repair, and secure fixation have more profound impact on the prognosis of scaphoid dislocation.
a mid term results of treatment of neglected isolated scaphoid dislocation is presented.
@highlight
the authors present a case of isolated scaphoid dislocation in a 40-year-old male that was undiagnosed for 2 months.
the patient was treated by open reduction, kirschner wire fixation, interosseous ligament repair using a suture anchor and blatt's dorsal capsulodesis.
at 6 years followup, his radiographs of wrist showed a normal carpal alignment with a scapholunate gap of 3 mm and no evidence of avascular necrosis (avn) of the scaphoid.
