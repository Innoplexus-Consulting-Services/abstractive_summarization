introduction what was known?
focal dermal hypoplasia is an x linked dominant disorder with characteristic cutaneous and skeletal manifestations.
focal dermal hypoplasia (fdh) or gorlin–goltz syndrome (omim #305600) is a rare disorder affecting tissues of ectomesodermal origin mainly the skin and bones.
inherited in an x-linked dominant pattern, it is lethal in males.
[1] the porcn gene plays a critical role in the development of the ectoderm in the embryo and the various mutations occurring in this gene results in this syndrome.
we hereby report fdh in a male infant with postzygotic de novo nonsense mutation p.e300* in porcn gene.
a different mutation is reported earlier from india.
[2] this is the first report of the mutation p.e300* in porcn gene from india and the second international report of the same.
[3] case report a 10-month-old male child presented to us with skeletal deformities and hypopigmented macules.
he was born to a nonconsanguineous couple at term with birth weight of 2400 g. on examination, the child had hemihypotrophy of the face on the right leading to an asymmetric appearance [figure 1a].
there were atrophic areas of skin with yellowish nodules over depigmented macules following the lines of blaschko [figure 1b].
he had sparse hair and oligodontia.
on the right side: coloboma of the iris and optic disc; syndactyly of hand, ectrodactyly of foot [figure 1c] and undescended testis were present.
the child had global developmental delay and growth below third centiles.
systemic examination was normal.
ultrasonogram of the abdomen, radiographs of long bones, and echocardiography were normal.
full-thickness skin biopsy was taken from right upper arm from an area of the yellow nodule with depigmented skin.
histopathology of skin biopsy showed very scanty collagen with adipocytes and lobules of adipose tissue in the dermis [figure 2].
dermal appendages were absent.
figure 1 (a) asymmetric facies with hypoplasia of the right half of the face.
(b) the skin showing yellowish nodules over depigmented macules following the lines of blaschko.
(c) ectrodactyly of the foot (permission taken for publication) figure 2 microphotograph low power view of focal dermal hypoplasia displaying epidermal thinning and patchy absence of dermal elements and replacement by adipose tissue (h & e ×100) with consent, genomic dna was extracted from ethylenediaminetetraacetic acid blood obtained from the child and his parents using standard phenol-chloroform method.
all coding exons and flanking introns of porcn gene (nm_203475) were amplified using polymerase chain reaction (pcr).
subsequent sanger sequencing of pcr amplicons revealed point mutations at position c. 898g > t (p.e300*) in exon 10 (cm080503), in addition to the wild-type g nucleotide.
the smaller size of the mutant peak suggested a mosaic state [figure 3a–c].
parents did not carry the mutant allele.
figure 3 electropherogram of exon 10 nucleotide sequence of porcn gene of (a) proband showing both wild-type signal g nucleotide and mutant signal t nucleotide (indicated by the arrow).
(b) wild type signal g nucleotide in father.
(c) wild type signal g nucleotide in mother discussion fdh is a rare disorder with only 250 reported cases in literature because of potential lethality in either gender as well as failure to recognize milder phenotypes.
[4] the porcn gene on chromosome xp11.23 plays a critical role in the development of ectoderm through wnt signaling.
the gene plays a critical role in ecto- and mesodermal communication and wnt suppresses fibroblast proliferation in the skin and osteoblast differentiation in the bone leading to primary manifestations in the skin and skeletal system.
[3] the disorder is lethal in hemizygous males.
as in the index case, surviving males by default show a de novo postzygotic mutations with mosaicism.
the porcn-lovd online database carries around 170 variants of which 16 are in exon 10.
[5] the p.e300* is a known nonsense mutation that results in premature amino acid chain termination of translation at residue 300 of wnt signal protein.
[3] the only other report of this mutation from asia is in a female of thai origin.
[3] the only reported mutation from india is ivs2 + 1g > a in porcn gene.
[2] a geographic or ethnic prevalence of mutations is not elucidated as of yet.
[4] an interesting feature noted in the index child was the predominantly right-sided findings and documented by few others as well.
[6] a genotype-phenotype correlation is not established in this condition.
phenotype variability is determined by the degree of x-inactivation in females and mosaicism in either gender.
the original process of x-inactivation is normal, but skewing occurs because cells expressing the mutant allele do not survive.
unless a mutation is established, carrier status may be missed in milder phenotypes.
we report this case for the rarity and conclude that molecular characterization will become increasingly relevant both for the recognition of milder phenotypes and risk counseling.
declaration of patient consent the authors certify that they have obtained all appropriate patient consent forms.
in the form the patient(s) has/have given his/her/their consent for his/her/their images and other clinical information to be reported in the journal.
the patients understand that their names and initials will not be published and due efforts will be made to conceal their identity, but anonymity cannot be guaranteed.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
what is new?
this is the first report of mutation p.e300* of porcn gene from india.
@highlight
focal dermal hypoplasia is a rare disorder inherited in an x-linked dominant pattern and is usually antenatally lethal in males.
we report a surviving male with postzygotic de novo mutation p.e300* in exon 10 of porcn gene with mosaicism, earlier reported in a female of thai origin.
this is the first report of this mutation from the indian subcontinent.
