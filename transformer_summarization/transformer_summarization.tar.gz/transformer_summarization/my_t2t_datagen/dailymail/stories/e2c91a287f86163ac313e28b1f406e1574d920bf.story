introduction imerslund-grasbeck syndrome (igs) is a rare disorder with autosomal recessive inheritance that affected children between 1 and 5 years old and is recognized by megaloblastic anemia, asymptomatic intermittent proteinuria, and vitamin b12 deficiency.
[1] other manifestations including failure to thrive, recurrent gastrointestinal, respiratory infections, and mild neurological signs and symptoms can be seen in these patients.
[2] igs can be associated with genitourinary malformation,[34] dolichocephaly, β-thalassemia trait, and diabetes mellitus.
the syndrome does not manifest immediately after birth and almost always affects children from 4 months after birth up to several years.
[5] laboratory investigations have been shown that intestinal cell wall morphology and intrinsic factor (if) production are normal, and no evidence of antibody against these components was found.
however, the only abnormal finding was a selective cobalamin malabsorption not responding to if administration.
mutations in cubilin gene on chromosome 10 or amnionless on chromosome 14 have been found responsible for this syndrome.
[5] life long treatment is needed for igs.
it responds well to intramuscular administration of 1 mg hydroxocobalamin for 10 days and then monthly.
herein, we present a 5-year-old iranian boy presented with fatigue and loss of appetite that finally diagnosed with igs.
case report a 5-year-old boy was referred with fatigue, loss of appetite, and failure to thrive.
the patient was second child of consanguineous parents.
he had been vaccinated as routine and had used iron supplement up to 18 months of age.
the patient's mother who was taken him to the clinic mentioned that the boy was in a usual state of health until 4 months ago who gradually developed fatigue, low level of activity, and decreased appetite.
according to the mother, the patient had not gained any weight during last 8 months.
on medical history, the patient has had intermittent proteinuria (2+–3+) since 4 years ago in the absence of hematuria, serum creatinine rising, or hypertension.
no history of fever, recent infection, and neurologic deficits were evident, and he was not on any drugs.
on physical examination, his vital signs were in normal limits (temperature: 36.3°c, blood pressure: 103/79 mmhg, pulse rate: 99/min, respiratory rate: 23/min) but was pale without hepatosplenomegaly or lymphadenopathy and had normal results in general neurologic examination.
laboratory findings showed severe anemia (hemoglobin: 5.2 g/dl, mean corpuscular volume: 103, reticulocyte count 1%).
direct/indirect coombs test was negative, and he had normal osmotic fragility (42%) and autohemolysis test.
other laboratory findings were as follow: ferritin of 375 (normal range: 18–341), iron of 188 (normal range: 60–180), and tibc of 201 (normal range: 230–410).
finally, due to the macrocytic anemia serum folate and b12 levels were assessed that showed a low level of serum b12 (74 pg/ml, normal range of 191–663) and normal folate (>20, normal range: 3.1–17.5 ng/ml).
ultrasonography of kidneys, genitourinary system, and liver revealed no abnormalities.
on bone marrow aspiration and especially peripheral blood smear, some “pessary” or “ring-like” rbc were notable [figure 1].
thus, the diagnosis of igs was established based on megaloblastic anemia, low level of serum b12, and asymptomatic proteinuria.
the patient placed on oral vitamin b12 100 μg/day for 10 days and then 300 μg monthly.
in addition, two units of packed red blood cells were given to the patient at the first day of admission due to his severe anemia.
in 8 months follow-up, the patient's anemia got completely resolved; however, episodic proteinuria persisted despite treatment [table 1].
moreover, evaluation of other family members indicated similar paraclinical findings in his 7 years old sister who was asymptomatic clinically.
figure 1 pessary cells on peripheral blood smear table 1 some laboratory findings in patient's follow-up discussion in this reports, a 5-year-old boy was diagnosed with igs after evaluation for growth retardation, intermittent proteinuria, and megaloblastic anemia.
he was from consanguineous parents, and his sister was asymptomatic with same laboratory findings.
similar to our patient, wulffraat et al.
[6] reported two girls with definite diagnosis of igs, who their first manifestation was a failure to thrive.
in contrast to our report, the patient, reported by stones and ferreira,[7] was a 16-month-old girl without any evidence of grow retardation at presentation.
it has been hypothesized that differences in the age of onset and clinical findings are related to a different molecular defect in developing igs.
[8] however, igs is treated successfully by intramuscularly injection of 1 mg cobalamin for 10 days and then monthly for lifelong; orally replacement therapy of cobalamin is effective also.
prognosis is excellent with lifelong cobalamin replacement.
among symptoms, the proteinuria is the only symptoms that may persist even during treatment, without exacerbation or renal failure.
[6] our patient became symptom-free after 2 weeks of b12 supplemental therapy and most of the laboratory findings resolved after 2 months except the intermittent proteinuria.
it is important to keep in mind that proteinuria can continue even after vitamin b12 replacement therapy.
conclusion although igs occurs rarely, it is important to consider this syndrome in a child who presented with anemia, growth retardation, and intermittent proteinuria who responds well to vitamin b12 treatment.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
imerslund-grasbeck syndrome (igs) is a rare syndrome characterized by clinical symptoms and signs of vitamin b12 deficiency and proteinuria.
our patient was a 5-year-old boy with pallor, lack of appetite, and low weight gain.
laboratory studies showed severe macrocytic anemia, normal reticulocyte count, negative direct coombs test, normal osmotic fragility, and autohemolysis test.
he has had intermittent proteinuria since 3 years ago despite normal creatinine level and absence of hematuria or hypertension.
finally, based on low level of serum b12 vitamin and normal folate level accompanied by asymptomatic proteinuria, the diagnosis of igs was made.
furthermore, his sister has had laboratory abnormalities without any symptoms.
igs responded to b12 replacement therapy dramatically but intermittent proteinuria persisted even after appropriate therapy.
