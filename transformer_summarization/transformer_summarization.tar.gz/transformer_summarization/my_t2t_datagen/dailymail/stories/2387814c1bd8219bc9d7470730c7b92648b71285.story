1. introduction osteoporosis and fragility fractures represent a growing health problem in developed countries in terms of social costs and increased risk of death, especially in the elderly [1].
fracture incidence rates are closely related to the ageing of a population, as older people present higher fracture rates than younger subjects with the same bone mineral density [2].
this is due to a lower bone quality and higher tendency to fall.
it is estimated that 25% of women aged 80 years and over have already undergone at least one vertebral fracture [3].
according to the esopo (epidemiological study on the prevalence osteoporosis in italy) study, about 5 million italians suffer from osteoporosis with almost 1.5 million of these subjects being “at high risk” of femoral fracture because they have already experienced one or more vertebral fractures [4].
hospital costs of femoral fractures in the elderly italian population account for 1 billion euros per year [5].
prevention of osteoporosis is traditionally based on bone measurement tests, aimed to predict the risk of future fragility fractures.
diagnostic criteria for osteoporosis are based on dual energy x-ray absorptiometry (dxa) measures, as performed at the hip or lumbar spine.
dxa is considered the gold standard methodology for the diagnosis of bone demineralization.
however, other kinds of diagnostic tests are available.
predictive parameter bmd (bone mineral density), which derives from dxa, is used in clinical practice to assess the risk of fracture, even though it is well recognized that other risk factors, such as age and drugs inducing osteoporosis (steroids and others), are independent contributors to the risk of fracture and improve the sensitivity of bmd measurement in identifying patients at risk [6,7].
quantitative ultrasounds (qus) at calcaneal (heel) or phalangeal sites represent the most commonly used non-dxa methodologies.
this kind of radiation-free test was shown to be user-friendly, cheap, non-invasive, and—most importantly—it is able to discriminate subjects at increased risk of fragility fracture [8].
qus, developed by langton et al.
in 1984, have been settled for the evaluation of bone quality and skeletal disorders on the basis of various experiments that suggest that the ultrasonic parameters could provide information not only on bone density but also on micro-architecture and elastic properties of bone tissue [9].
the phalangeal qus methodology was introduced in europe in 1992–1993, and a series of studies have been performed to validate the method in clinical settings [10,11].
bone resorption at the proximal phalanx is associated with significant changes in the speed of the ultrasonic signal that passes through the phalanx [12].
benitez et al.
performed a comparison between phalangeal qus and dxa (measured at total hip and lumbar spine), concluding that phalangeal qus can be effectively used for the screening of osteoporosis in postmenopausal women [13].
more recently, the assessment of clinical risk factors has become more and more important in the diagnosis of osteoporosis and to select patients for appropriate treatment.
in this frame, the euro mediterranean bio-medical scientific institute (isbem, brindisi, italy) has launched a pilot project for the disease management of osteoporosis, which is aimed at the prevention of fragility fractures through the early identification of people at higher risk through the use of phalangeal qus and the collection of clinical risk factors in the rois (ionian and salento osteoporosis registry), which represents the first section of the emeros (euro mediterranean registry of osteoporosis), acknowledged as an official commitment by the european commission action group on active and health ageing.
the registry started in 2009 thanks to a strong cooperation between isbem researchers and physicians from the local health authorities (asl) brindisi, asl taranto, and asl lecce (limited to the hospital of gallipoli, division of orthopedics and traumatology).
this first section of the registry is of particular interest because salento sub-region represents the “oldest” area of apulia and of entire southern italy, as it is characterized by an “ageing index”, very closely reflecting the national average value (which has risen up to 143) [5].
the “ageing index” is an epidemiological indicator that corresponds to the ratio between the number of people aged >65 and the number of children aged 0–14 years old.
therefore, this population could be considered representative of the entire italian population and could be particularly useful both for case-control analyses and prospective cohort studies, thanks to the monitoring activities carried out within the rois registry integrated in the emeros.
in addition, in the study area, there is a strong industrial activity (brindisi and taranto) with a high impact on pollution of air, soil, and water and on public health [14].
a study conducted on women living in taranto showed that the content of polychlorinated dibenzo-p-dioxins in human breast milk was 10–40 times higher than legal limit [15].
furthermore, several epidemiological studies showed an increased mortality/morbidity from respiratory, cardiovascular diseases, and several cancer sites [16,17].
for the years 2005–2009, a higher chronic obstructive pulmonary disease prevalence was found in brindisi than in other italian cities [18].
the impact of concentrations of air pollutants in both men and women has been shown in a recent study.
the author, in fact, found a positive associations between the presence of pollutants and a risk of osteoporosis; they concluded that high level of air pollutants might increase the risk of osteoporosis by 39% to 89% [19].
in this paper, we present the updated analyses of the rois/emeros registry focusing on the association between some major clinical conditions (i.e., obesity, dyslipidemia, diabetes, hypertension, cardiovascular diseases, rheumatic diseases, and previous fractures) and bone demineralization in a population living in a specific area characterized by heavy environmental pressure between brindisi and taranto.
2. materials and methods 2.1. subjects the pr.o.f.
(prrevention of osteoporosis and fractures) study was a disease management project for the prevention of fragility fractures carried out at the ambulatorial and hospital centers for the diagnosis and treatment of osteoporosis of local health authority of brindisi, taranto and lecce (limited to the hospital of gallipoli, division of orthopedics and traumatology).
each subject was provided with adequate information about the privacy policy, and everybody was asked to sign for approval to data processing for the purposes of the study.
all personal data was collected in compliance with the declaration of helsinki.
the study was conducted in accordance with the local health authority (asl) of brindisi and taranto, and the declarations were approved by the general director of the local health authority (asl) of brindisi (number 3393 of 25 november 2008);the general director of the local health authority (asl) of taranto (number 3240 of 14 september 2009).
in 2016, the ethics committee of lecce approved the study within the european version of the project called emeros.
before the kick-off of the project, isbem researchers developed a questionnaire in order to record main clinical information of each patient; the questionnaire includes all the mandatory fields and items of the electronic form developed by the italian society of osteoporosis of bone mineral and of skeletal disease (siommms).
during the enrollment visit, the weight of all patients was recorded, with a tolerance of 0.5 kg; standing height was measured on the balance stadiometer to the nearest centimeter.
body mass index (bmi) was calculated as weight/height2 (kg/m2); obesity was defined in the presence of bmi ≥ 30. each subject was interviewed about frequency of alcohol consumption, cigarette smoking, calcium intake (by milk and dairy products), physical activity, previous fractures, parental history of osteoporotic fractures, age, and cause of menopause.
in the interview, the presence of diseases known to be associated with osteoporosis and any other diseases was specifically recorded, as well as any previous or current use of anti-fracture drugs (including vitamin d and calcium supplementations), therapies influencing bone mineralization (i.e., corticosteroid, immunosuppressive, heparin, antiepileptic, antiestrogens, and chemotherapies), and any other current treatment for other diseases.
the use of drugs known to increase the risk of falls (i.e., benzodiazepines or hypnotics) was also recorded.
physical activity was assessed with a specific score (0 = no physical activity; 1 = moderate physical activity; 3 = heavy physical activity) developed for clinical records by the italian national research council throughout a systematic review of the available medical literature.
all data were entered into the rois registry (ionian and salento osteoporosis registry) which represents the first section of the emeros (euro mediterranean registry of osteoporosis), acknowledged as official commitment by the european commission action group on active and health ageing.
between february 2009 and june 2016, about 12,000 consecutive patients undergoing bone densitometric examination by qus were included in the rois/emeros registry.
however, the number of enrolled subjects presenting a complete dataset of clinical variables and qus measurements needed for the purpose of this study was 6471 (727 men, 4909 postmenopausal women, and 835 pre-menopausal patients).
premenopausal women, men, subjects with extreme bmi values (<18.5 and >50), and thalassemic patients examined at taranto and brindisi thalassemia centers were excluded from this study, so the final sample analyzed consisted in 4909 postmenopausal women.
2.2. ultrasound measurements ultrasound measurements were performed for all subjects using dbm sonic bone profiler 1200 (igea®, carpi, italy).
this device is based on the transmission of ultrasounds through proximal phalanges (ii–v) of the fingers at dominant or non-dominant hand; transmitting and receiving probes are applied to the lateral surface of each finger; the coupling of the probes with the skin is accomplished using simple gel for ultrasound transmission.
at each measurement session, the reference values of the patient’s soft tissue were measured by applying the probes to the soft tissue of the hand (“anatomical snuff box”).
the measurements were performed by placing probes at the distal metaphysis of the first phalanges, in the proximity of the condyles.
the measurement outcomes provided by the device were amplitude-dependent speed of sound (ad-sos, m/s) and ad-sos t-score, where this latter parameter compares the measured ad-sos value with the average value of young adults and is expressed as standard deviation (sd).
for this device, the specific t-score diagnostic threshold discriminating between healthy and osteoporotic people at increased risk of fractures has been set up in a large study carried out on a population of 10,000 subjects and corresponds to −3.2 sd.
t-score between −3.2 and −1 was defined as osteopenia status [20].
2.3. statistical analysis all statistical analyses were performed by using stata/se 12 software for windows (stata statistical software: release 12. statacorp lp.
college station, tx, usa).
obesity, dyslipidemia, type 1 and type 2 diabetes, hypertension, cardiovascular diseases, rheumatic diseases, and previous fractures were used as dichotomous variables.
continuous data were presented as mean value ± sd; frequency and percentage of dichotomous variables were computed.
baseline characteristics of osteoporotic, osteopenic, and normal postmenopausal subjects were compared via student’s t-test for continuous variables and via linear regression analysis for categorical variables.
pearson correlation coefficients were calculated to assess the association between ad-sos and bmi.
linear regression analysis was performed to test the presence of linear trends among different classes of bmi for all the clinical variables.
multivariate analysis was performed using a logistic regression model to assess the association between bone demineralization status and diabetes, hypertension, cardiovascular diseases, and obesity.
models were adjusted to eliminate the effects of age, physical activity, and the previous or current use of any drug known to be associated with bone demineralization.
mantel–haenszel odds ratios of osteoporosis, crude and adjusted for age, physical activity, and the previous or current use of osteoporosis-inducing drugs were calculated to assess the effect of the classes of bmi on the odds of being osteoporotic.
3. results table 1 summarizes baseline characteristics of postmenopausal women stratified by their bone mineralization status (osteoporosis, osteopenia, and normal).
mean age was higher in osteoporotic subjects (70.3 ± 8.6) than in osteopenic (62.8 ± 8.3) and normal subjects (54.9 ± 7.1).
osteoporotic subjects presented a higher mean bmi (29.84; sd 5.56) than osteopenic (28.64; sd 5.19) and normal people (26.71; sd 4.87).
ad-sos mean values were significantly higher (p < 0.001) in normal subjects (2087.3 m/s; sd 44.1) than in osteopenic (1967.5 m/s; sd 46.5) and osteoporotic patients (1842.2 m/s; sd 60.7; p < 0.0001).
the frequency of obesity, hypertension, type 1 and type 2 diabetes, dyslipidemia, and cardiovascular diseases was significantly higher in osteoporotic subjects (p < 0.001).
no statistically significant differences were found among the three groups for the presence of rheumatic diseases or in the case of a previous or current use of drugs known to be associated with bone demineralization.
pearson correlation analysis between ad-sos and bmi revealed a negative correlation: r = −0.2 (p < 0.0001).
table 2 presents the results of multivariate logistic regression analysis between osteoporotic status (ad-sos t-score lower than −3.2 sd) and other conditions such as cardiovascular diseases, type 1 and type 2 diabetes, hypertension, and obesity (bmi ≥ 30).
all of these conditions presented odds ratios (ors) > 1, thus significantly associated with diagnosis of osteoporosis (p < 0.001 and p < 0.01).
however, the association between osteoporosis and cardiovascular diseases, type 2 diabetes, and hypertension was revealed as not statistically significant after adjustment for age, physical activity, and the use of drugs known to be associated with bone demineralization.
on the contrary, obesity and type 1 diabetes were confirmed to be associated with osteoporosis, even after adjustment for age, physical activity, and the use of osteoporosis-inducing drugs, with or (confidence interval (ci) 95%) of 1.39 (1.05–1.83) and 1.46 (1.20–1.78), respectively.
all patients were divided into five groups corresponding to different bmi classes: subjects with optimal weight (bmi < 25), overweight people (bmi ≥ 25 but <30), grade 1 obesity (bmi ≥ 30 but <35), grade 2 obesity (bmi ≥ 35 but <40), and grade 3 obesity (bmi ≥ 40).
the average age, bmi, ad-sos measurements, and clinical characteristics for all five groups are shown in table 3. a significant positive linear trend (p < 0.0001) was found across categories of bmi in the frequency of type 1 diabetes, cardiovascular diseases, hypertension, and dyslipidemia.
we investigated the ors of osteoporosis for all five bmi groups, calculating both the crude and the ors adjusted for age, physical activity, and the use of osteoporosis-inducing drugs, using the class of optimal weight as a reference group, with assigned value = 1 (table 4).
considering the adjusted ors, we found a significant linear trend over bmi categories, with a significant score test for trend (p < 0.001).
4. discussion the study took place in salento, a sub-region of southern apulia characterized by the same ageing index of the entire italian population and therefore representative of the general population, and will be particularly useful for further analyses when the registry becomes larger.
though the majority of people enrolled in the registry was living in the area between brindisi and taranto (officially classified as “site of national interest” for environmental pollution related to the big steel and power plants of these two industrial cities), the effects of comorbities, attributable to environmental causes, on the proportion of secondary osteoporosis were not clear from our analysis of our database.
the value of this cross-sectional study, carried out on 4909 postmenopausal women, consists in having demonstrated an independent association between obesity or diabetes and osteoporosis as diagnosed by using a radiation-free, non-invasive methodology such as qus.
this kind of technology has shown no significant differences when compared to dxa in terms of ability to predict hip fractures in large cohorts of patients or discriminate fractured patients.
in particular, some authors found that qus parameters (ad-sos and ubpi) were able to identify subjects with a bmd t-score below 2.5 and those with a bmd t-score above the threshold value so that a correlation between ultrasound and densitometric results was moderate but positive [21].
dxa measurements were available for 303 subjects involved in this study, so we calculated the pearson correlation between ad-sos and bmd and found a positive correlation (r = 0.32; p < 0.001).
we demonstrated in another study the ability of qus to detect thalassemic patients with prevalent fragility fractures, and the results are comparable to those of dxa [22].
correlation analysis between bmi and ad-sos revealed a negative correlation coefficient, demonstrating a negative impact of bmi increase on bone ultrasound velocity at proximal phalanges.
these findings seem to confirm the results of a cross-sectional study which found an association between fat mass and osteoporotic fractures [23].
the pearson correlation coefficients of the bmd and bmi in the small sample of 303 subjects was 0.15 (p < 0.001).
although correlation was weak, it reflects the negative trend found between bmi and ad-sos.
the relationship between osteoporosis and obesity is currently controversial.
several evidences, including those from the nora study, reported that an increasing bmi is associated with a bmd increase [24].
these observations could be explained taking into account the mechanical load exerted by the increased body weight, which results in an increase of bone mineral density [25].
moreover, adipocytes in postmenopausal women represent the main source of estrogens and are known for their inhibitory activity of osteoclast-mediated bone resorption [26].
finally, obesity is often related to high plasma insulin levels, a fact which contributes to the overproduction of sex hormones—estrogens and androgens—responsible for increased osteblast activity and reduced osteoclast activity [27].
on the contrary, other evidences suggest that obesity might negatively influence bone health [28,29].
this complex relationship between obesity and bmd could be explained by the effect on bone of a series of adipokines and cytokines secreted by adipose tissue, such as leptin, resistin, adiponectin, interleukin 6, and tumor necrosis factor-alpha [30,31].
one study involving obese patients found a lower lumbar spine bmd than was expected for age and bmi [32].
after performing pqct (peripheral quantitative computed tomography) to analyze volumetric bmd, bone mineral content, and geometric and bone strength properties, some authors concluded that adiposity has a negative effect on trabecular and cortical bone [33].
these findings are in agreement with our results about the correlation between phalangeal qus parameter and bmi.
one limitation to the explanation of our results could be the interference of soft tissue during the execution of phalangeal qus.
in several studies performed using qus, soft tissues have been proven to reduce the speed of sound (sos) transmitted across bones [33]; on the basis of these studies, some authors have proposed that the negative impact of bmi on qus parameters can be ascribed to the interference of soft tissues [34].
in their paper, biino et al.
also found a negative correlation between ad-sos and bmi, with ad-sos showing the highest correlation coefficient with bmi among all qus parameters; these authors, by bioimpedance analysis, proved that an increase in fat mass results in a negative impact on bone health [34].
on the basis of these findings and of the pqct results, we accepted the appropriateness of qus measurements in obese subjects.
according to the results of our study, the ors of being osteoporotic for obese and diabetic subjects indicate that being obese or suffering from type 1 diabetes increases the probability of belonging to the osteoporotic group by 46% and 15%, respectively.
for type 2 diabetes subjects, or is not statistically significant after adjustment.
when stratifying our study population by class of bmi, the ors of being osteoporotic have confirmed that an increase in the bmi value negatively affects bone mineralization.
as shown in table 4, when considering optimal weight (bmi < 25 kg/m2) as a reference group, we find a two-fold probability of being osteoporotic in subjects with grade 2 and grade 3 obesity (ors = 1.94, ci: 1.27–2.97, and or = 2.51, ci: 1.38–4.56, respectively).
our findings are consistent with results from other studies also concerning the association between diabetes and bone demineralization, where type 1 diabetes has already been associated with bmd reduction [35]; in people with type 2 diabetes, a higher bmd at the hip has been documented only at the baseline, with a rapid bone loss having been observed over time in a longitudinal study [36].
leslie et al.
observed that type 2 diabetes is associated with high bmd values and an increased risk of fragility fractures, thus claiming new markers and new preventive approaches to evaluate the risk of fractures in these patients [36]; these authors have also suggested including type 2 diabetes in the questionnaire of the frax international algorithm for the fracture risk assessment.
a recent study carried out on canadian women affected by type 2 diabetes confirmed the existence of a “bone fragility paradox”: although patients with type 2 diabetes had a normal femoral neck bmd compared to controls, they showed a weaker response to mechanical loading on the neck of the femur when entering a simulated mechanical model depicting forces acting on the femoral bone [37].
as hyperglycemia itself is an important factor in the regulation of osteoclast-mediated bone degradation, several studies have investigated the effect of hyperglycemia in fostering bone quality reduction and microarchitecture impairment in diabetic patients [37].
moreover, non-enzymatic glycation (neg), which consists of spontaneous reactions between extra-cellular sugars and free amino groups of several matrix proteins including collagen type i, leads to formation of molecular crosslinks which are known as advanced glycation end-products (ages).
high concentrations of ages are known to increase bone fragility [38].
phalangeal qus was found to be comparable to dxa in discriminating people at higher risk of fracture, with qus able to provide additional information for the skeletal assessment in type 2 diabetic patients [39].
as previous shown for obese patients, also about type 2 diabetes, there are evidences based on high resolution peripheral quantitative tomography (hr-pqct) that demonstrated increased cortical porosity in the tibia and other bone sites of postmenopausal women suffering from type 2 diabetes [40].
considering this ability of qus to provide the physician with additional information on bone micro-architecture, this technology could be tested for specific use in clinical practice in combination with spinal deformity index (sdi), an index of bone quality used for the diagnosis of osteoporosis in subjects affected by type 2 diabetes.
in a recent controlled study involving subjects with type 2 diabetes, spinal deformity index revealed its ability to discriminate subjects with vertebral fractures in a more specific way than the simple use of bmd for the diagnosis of osteoporosis [41].
other limitations affect our study, such as the lack of data about the cortical and trabecular mineralization that could give us the entity of correlation between our data and bone status.
this was not possible; since our study was conducted on such a large sample, a massive measurement with pqct was not practical.
moreover, data about fat and lean mass are not available, and bmd measurements were only registered in a restricted section of the sample.
5. conclusions in conclusion, our study confirmed the high impact of obesity and type 1 and type 2 diabetes on osteoporosis.
@highlight
objectives: we aimed to analyze bone mineralization and the effect of different risk factors for osteoporosis in postmenopausal women.
methods: we found 4909 postmenopausal subjects within ≥10,000 records from the rois/emeros (ionian and salento osteoporosis registry/euro mediterranean registry of osteoporosis) registry, a population study carried out in an area characterized by heavy environmental pressure between brindisi and taranto from 2009 to 2016. all subjects were assessed via phalangeal quantitative ultrasound (qus) to evaluate their bone mineralization (assessed via amplitude dependent speed of sound (ad-sos)) and the association between demineralization and the presence of other conditions or risk factors.
results: mean age was 64 ± 9.5 years and mean body mass index (bmi) was 28.7 ± 3.5 kg/m2.
pearson correlation analyses revealed a negative association between bone mineralization (ad-sos) and bmi (p < 0.001).
by using multivariate logistic regression analysis, we observed significant values of odds ratios (ors) of osteoporosis (adjusted for age, physical activity, and the use of drugs known to increase the risk of fractures) in subjects with diabetes and obesity: 1.39 (confidence interval (ci): 1.05–1.83) and 1.46 (ci: 1.20–1.78), respectively.
a statistically significant linear trend of higher ors of osteoporosis was found for increasing values of bmi.
conclusions: our study confirmed the high impact of obesity and type 1 and type 2 diabetes on osteoporosis.
