1. introduction a conceptus may implant soon after its arrival in the uterus (as in humans and muroid rodents), or may remain free in the uterus for several weeks before implanting (as in equids) [1].
intermediate to these extremes are the conceptuses of many carnivora and artiodactyla which implant 10–20 days after mating.
the delay is attributed to time required for mating-induced ovulation, travel through the fallopian tubes, and a variable period during which the blastocyst develops without close cellular contact with maternal tissues [1].
in some species of mustelid, ursids, phocids and roe deer, implantation is postponed for several months, during which time the conceptus enters obligatory diapause at the blastocyst stage and must be maintained and protected until reactivation is permitted by the mother [2–5].
the european polecat, mustela putorius [6], fits into the intermediate group, with an embryonic development period (without embryonic diapause) of approximately 12 days preceding implantation.
proteins secreted into the non-pregnant uteri of eutherian mammals have a range of presumptive functions such as maintenance of the mucocutaneous surface of the endometrium, antimicrobial protection, receptivity to sperm and the subsequent conceptus, and nutrition of an embryo.
distinct differences have been found among mammal groups in the proteins secreted into the uterus before placentation, although there are commonalities [7–12].
these proteins have been divided mainly into those involved in nutritional support for the conceptus, or in facilitating and controlling implantation events.
perhaps, the most notable example of the nutritional function is the uterocalin/p19 protein in horses.
this protein appears to deliver essential lipids such as retinol and polyunsaturated fatty acids across the glycoprotein capsule to the equine conceptus [13–15].
lipids present a problem in their transfer from mother to conceptus because they tend to be insoluble, and in some cases susceptible to oxidation damage unless protected within a protein binding site.
uterocalin is also notable in that its primary structure is enriched in essential amino acids, which doubles its function as a nutrient source for the developing embryo [15].
other examples of lipid carriers in uterine secretions include a modified form of plasma retinol binding protein, and serum albumin which binds a range of small molecules, fatty acids in particular [11,16,17].
of those proteins considered to influence implantation events, the broad-spectrum proteinase inhibitor α2-macroglobulin (α2m) is secreted into the pregnant uterus around the time of implantation in several species, and, among other roles, is thought to limit tissue damage during implantation and to control local inflammatory responses [7–12,18,19].
overall, there is considerable diversity in the suite of proteins secreted into pre-placentation uteri by different clades of mammals, as exemplified by equids, artiodactyles and carnivora, all of which exhibit distinctive repertoires [7–10,12].
we investigated the proteins found in uterine secretions of pregnant european polecats (domesticated as ferrets) in order to explore the preparatory events that lead up to, and at, implantation.
analysis of chronological samples indicated that progressive and dramatic changes in the protein profile occur as the time at which implantation would occur approaches.
some of the proteins have been found in pre-implantation uterine flushes of other species (notable among which is α2-macroglobulin), although not in the same combination or relative concentrations.
at least one protein, lipocalin-1, which we found to peak in abundance at implantation, has previously not been reported as a uterine secretory protein.
not only does this study demonstrate that mustelids exhibit a different repertoire of implantation-related uterine secretions from other species groups, but it may also provide a general framework for investigation of what happens during embryonic quiescence and subsequent reactivation in species that engage in prolonged embryonic diapause.
2. material and methods 2.1. animals and sample collection the subjects used in this study descended from a population of 70 wild european polecats (mustela putorius) captured in the 1970s and interbred with 200 captive imported domestic ferrets (subspecies mustela putorius furo).
the resulting population forms the basis for all polecats farmed for the fur industry and research in finland.
the animals were maintained at the kannus research farm luova ltd., in kannus, finland.
they were held in individual cages measuring 70 × 30 × 38 cm (length × width × height) with nest-boxes measuring 40 × 29 × 32 cm which were accessible to the females but external to the main cage areas.
during the breeding season, the animals were exposed to outdoor temperatures and light conditions: mean 2°c and 15 h light in april, 9°c and 16 h light in may, 14°c, and 20 h light in june.
the animals were fed according to standards for breeding farmed polecats in finland (prepared to provide at least 1150–1250 kcal kg−1, 40–50% protein, 30–32% fats and 15–25% carbohydrates, supplemented with vitamins and minerals), and had water provided ad libitum.
the time of oestrus was estimated by the physical appearance of the vulva.
males used for mating were known to have been fertile the previous year, and matings were visually confirmed (a tie observed).
animals were selected for sample collection on days 4, 6, 7, 9, 12 and 14 after mating.
those sampled on days 4 and 14 proved not to have become pregnant but were nevertheless included because they acted as mated but non-pregnant controls.
each animal was anaesthetized with medetomidine (dorbene®; laboratorios syva s.a., león, spain) and ketamine (ketalar®; pfizer oy, helsinki, finland), and the uterus removed under sterile surgical conditions.
the animals were subsequently euthanized with t-61 (intervet international b.v., boxmeer, the netherlands) while still under anaesthesia.
once the uterus was removed, the tips of each horn were opened, and the cut ends cleared of blood.
the cervix was closed with forceps, and the uterus flushed with 5 ml sterile physiological saline through one horn and out the other, with care to avoid blood contamination.
the flush fluid was filter-sterilized and frozen at −20°c in approximately 2 ml aliquots.
pregnancy was confirmed by the presence of developing embryos in uterine flushes.
samples were collected from a total of 14 animals, protein gel analysis from all of which is shown in electronic supplementary material, figure s1, and those that were selected for further analysis are indicated in electronic supplementary material, figure s1.
2.2. protein electrophoresis one-dimensional vertical sodium dodecyl sulfate polyacrylamide gel electrophoresis (sds-page) was carried out using the invitrogen (thermo scientific, paisley, uk) nupage system using precast 4–12% gradient acrylamide gels, with β2-mercaptoethanol (25 µl added to 1 ml sample buffer) as reducing agent when required.
gels were stained for protein using colloidal coomassie blue (instantblue, expedeon, harston, uk) and images of gels were recorded using a kodak imager.
electronic images were modified only for adjustment of contrast and brightness.
pre-stained molecular mass/relative mobility (mr) standard proteins were obtained from new england biolabs, ipswich, ma, usa (cat.
number p7708s).
samples were run under non-reducing and reducing conditions using β-2 mercaptoethanol as reducing agent.
selected gel slices were taken from non-reduced, coomassie blue-stained gels and processed for application to fresh gels under reducing conditions.
samples were concentrated where required using a vivaspin 3,000 mwco pes (sartorius, epsom, surrey, uk) centrifugal concentrator device operated according to the manufacturer's instructions.
2.3. proteomics stained protein bands were excised from preparative one-dimensional gels and analysed by liquid chromatography--mass spectrometry as previously described [20].
protein identifications were assigned using the mascot search engine to interrogate protein and gene sequences in the ncbi databases and the mustela putorius genome database [21] and linked resources, allowing a mass tolerance of 0.4 da for both single and tandem mass spectrometry analyses.
blast searches, or searches of genome databases of other carnivora (e.g.
dog and giant panda), were carried out to check the annotations.
prediction of secretory leader peptides and their cleavage sites was carried out using signalp software (http://www.cbs.dtu.dk/services/signalp/; [22]), and molecular masses calculated using protparam (http://web.expasy.org/protparam/).
3. results 3.1. sequential changes in the protein profile of pre-implantation uterine secretions the protein profiles of all the uterine flush samples collected from days 4 to 14 after mating are shown in the sds-page analysis in electronic supplementary material, figure s1.
the disparities between overall protein concentrations among the samples could be due to differences in efficiency of flushing, changes in the total tissue volume, differences between individual animals' secretion volumes or changes in secretory activity.
in order to improve comparability, selected samples were concentrated as described above and/or the volume of loaded sample adjusted to approximately equalize the intensity of the band at ca 65 kda mr (band c; figure 1), suspected (and subsequently confirmed by mass spectrometry), to be serum albumin from its size and slower migration under reduction.
figure 1.changes in european polecat uterine secretory proteins with time after mating.
animals sampled on days 4 and 14 were non-pregnant.
the sample volumes were adjusted to normalize the intensity of the strong band at approximately 65 kda (serum albumin).
see electronic supplementary material, figure s1, for sds-page of all of the samples collected and upon which the adjustments were based.
gel band codes are indicated by letters and are referred to in the text and in table 1. the proteins that most clearly increased in concentration with time were α2-macroglobulin (uniquely identified in bands a, b, j and k) and lipocalin-1 (uniquely identified in bands g and u).
m, marker/calibration proteins with relative mobilities (mr) as indicated in kilodaltons (kda).
table 1.identification of the proteins isolated from bands excised from the protein electrophoresis gels indicated in figures 1 and 2.bandaproteinbmass of proteincdatabase accession codedmascot scoreenumber of peptides (unique peptide matches)ffunction, association, synonyms and commentsga, b, h, i, j, k, m, oα2-macroglobulin163781.5 (161296.4)xp_0047797623502215 (127)inhibitor of all classes of proteinase.
bait and trap mechanism triggers enclosure of target proteinase.
thio-ester bond-mediated covalent binding of proteinases.
largest major non-immunoglobulin protein complex in plasma.
acute-phase protein in rats, minor acute phase reactant in other species.
elevated in pregnancy in humans and mice.
controls fetal positioning.
functionally distinct isoformsc, r, xα1-antitrypsin46521.2 (44096.2)xp_00475481566351 (26)serine proteinase inhibitor.
acute-phase reactantg, ulipocalin-119342.0 (17491.7)xp_00475703531723 (11)syn.
tear lipocalin, von ebner's gland protein.
lipid transport.
bacterial siderophore-binding.
endonuclease.
cystatin–cysteinyl proteinase inhibitorwzinc-α-2-glycoprotein36407.5 (34360.9)xp_00478189431022(9)lipid metabolism signal; adipokinecserum albumin68597.4 (66474.9)xp_004766346142599 (52)carrier of fatty acids and other small lipids, other small molecules and drugs, osmotic regulation in circulatory systemf, pserotransferrin78378.1 (76408.6)xp_00476253784959 (27)syn.
transferrin.
iron transporterf, plactotransferrin77327.0 (75354.4)xp_00476122650937 (20)syn.
lactoferrin.
iron capture, antimicrobial, negative regulator in inflammation.
synthesized and stored in neutrophil granulese, h, wcathepsin l137047.3 (35338.2)xp_00478238934334 (17)cysteinyl proteinase.
lysosomal.
antigen processing in mhc ii pathway.
extracellular matrix modification.
endometrial remodellinge, h, wuteroferrin37645.9 (35353.2)xp_00474842846424 (13)tartrate-resistant acid phosphatase type 5 (acp5).
pregnancy-associated acid phosphatase.
synthesized in response to progesterone.
widely conserved uterine protein in mammals.
appears to function in transplacental iron transport and stimulation of erythropoeisis.
human–bone building and remodelling, negative regulator of inflammatory signalsd, oectonucleotide pyrophosphatase109707.5 (none)xp_00474354644360 (19)ectoenzyme.
bone mineralization and soft tissue calcification.
appears to modulate insulin sensitivity and function; insulin receptor bindingrlegumain49280.8 (47556.7)xp_00473908927616 (7)hydrolyses proteins at -asn-xaa- site.
multifunctional.
processing of proteins for mhc class ii antigen presentation in the lysosomal/endosomal systemvhaemoglobin β15994.3 (none)xp_00477908243024 (13)o2/co2 transport and exchanged, ogalectin-3-binding protein62371.8 (60418.3)xp_00474884328122 (9)galectin is a galactose-specific lectin required for terminal differentiation of columnar epithelial cells during early embryogenesis; involved in acute inflammatory responses.
promotes intergrin-mediated cell adhesion.
may stimulate host defence against viruses and tumour cellsd, ocomplement c282486.9 (80560.4)xp_01290565026723 (11)component of the complement system.
cell lysis.
inflammationsapolipoprotein a-i30179.2 (28334.9)xp_00474995745831 (13)lipid binding.
cholesterol transport.
major protein component of high density lipoprotein (hdl) in plasma.
constituent of milki, palkaline phosphatase, tissue-non-specific isozyme isoform x157449.3 (55717.2)xp_00474132113512 (3)non-specific phosphomonoesterases possibly involved in cell signalling and bone mineralization.
enzymes of this class found widely in liver, bile duct, kidney, bone, intestinal mucosa and placentaiaminopeptidase n110639.6xp_01291746312712 (4)broad spectrum aminopeptidase.
may be involved in the metabolism of regulatory peptides of diverse cell types.
responsible for the processing of peptide hormonesk, migg fc-binding protein234543.3xp_01291817140157 (16)binds fc fragment of immunoglobulin g (igg).
may be involved in the maintenance of mucosal structure as a gel-like component of the mucosaxcathepsin d44455.3 (42483.8)xp_00475975171854 (25)acid protease active in intracellular protein breakdown.
oestrogen-regulated transcript in breast cancer cellsxuteroferrin-associated basic protein 248617.4 (45884.0)xp_00475481430768 (17)serine proteinase inhibitoragel band codes as indicated in figures 1 and 2.bprotein identifications.
peptides matching to keratin were excluded.cthe predicted molecular masses, as calculated by protparam (http://web.expasy.org/protparam/), are of the complete polypeptides encoded before removal of any leader/signal peptides for secretion.
the predicted masses following removal of such leader peptides at positions predicted by signalp is listed in brackets [22].
note that posttranslational modifications, principally glycosylation, will alter mobility in protein electrophoresis gels.daccession number/reference sequence from ncbi genbank database for mustela putorius genome database and checked by blast searching.emascot (mowse) search score where scores greater than 38 are taken to be significant.
the mascot score is the highest value obtained where the protein was identified in more than one band, as were the peptide match values.fnumber of peptides found to match with number of peptides unique to this identification in parentheses.gputative functions and comments are drawn from literature cited, or ncbi and uniprotkb/swiss-prot databases.
standardization of protein concentration to serum albumin revealed dramatic changes in the chronological protein profile of pregnant uterine flushes, in particular the proteins in bands a, b, d, e, g, u and w (figure 1).
the pregnant animals on days 6 and 7 showed few, if any, differences from the mated but non-pregnant animal at day 4, but by day 9 considerable differences were evident between pregnant and non-pregnant individuals.
in order to explore relationships between some of the proteins in the most intense bands, gel slices were excised from a non-reduced gel, and the proteins in them subjected to electrophoresis under reducing conditions.
this showed that bands a and b reduced to a similar set of proteins, suggesting that they were related or identical (figure 2).
the sizes of the resulting fragments were not commensurate with post-reduction cleavage products of large multi-chain immunoglobulins (igm and iga) which might be expected to appear in uterine secretions.
protein band c, which was used to standardize the loading protein concentrations of samples for figure 1, migrated more slowly when reduced, which is typical of serum albumin.
the change in its migration is usually attributed to cleavage of its intramolecular disulfide bond such that the unfolded protein is retarded in its migration.
similar behaviour was exhibited by band g protein, but the others separated as under non-reducing conditions.
the reduction of band c protein uncovered a different protein that was subjected separately to proteomic analysis (band r).
figure 2.subunit composition of major proteins in european polecat uterine flush following protein reduction.
the labelled bands were excised from a non-reducing preparative sds-page gel of a uterine flush sample taken from a pregnant animal on day 12 after mating and re-run under reducing conditions.
the letter codes for each band are consistent with those in figure 1. the two proteins that most notably increased in concentration with time were α2-macroglobulin (bands a and b) and lipocalin-1 (band g).
the original protein samples were run under reducing (r) or non-reducing (nr) conditions.
m, marker/calibration proteins with relative mobilities (mr) indicated in kilodaltons (kda).
3.2. proteomics protein bands whose concentrations changed dramatically with time after mating, or whose concentrations remained constant, were selected for proteomic analysis from both reducing and non-reducing gels (figure 1).
the separation between the bands in the sds-page gels was sufficient to allow proteomic identification of the proteins with high confidence, all directly from the m. putorius genome-derived protein sequence database.
the deductions were unchanged upon checking by blast searching of genomic and other databases for other carnivora.
table 1 lists the identifications and also the mascot scores and peptide matches of the proteins, and illustrates the high quality of the matches.
the two bands with the highest mr, bands a and b, were both identified as α2-macroglobulin (α-2m), as was their reduced form in band j. these sizes are larger than expected from the protein's polypeptide mass with its predicted secretory signal peptide removed, and may be due to glycosylation and/or covalent linkage with other entities.
the other proteins that appeared at high relative amounts around the time of implantation included lipocalin-1 (bands g, u; also known as tear lipocalin, and an enzyme of the ectonucleotide pyrophosphatase family, also represented in bands d, o), cathepsin l1 (bands e, w), uteroferrin (bands e, h, w) and zinc-α-2-glycoprotein (band w).
transferrin (bands f, p), α1-antitrypsin (bands c, r, x) and lactoferrin (bands f, p) remained at constant levels relative to serum albumin throughout the sampling period.
4. discussion the proteins secreted into the uteri of pregnant european polecats changed dramatically in abundance over the approximately 12 days between mating and the time of implantation by the embryo.
the repertoire of proteins shows some similarities with that found in other groups of mammals, presumably reflecting a theme inherited from a common ancestor, or convergent evolution in order to satisfy similar functional requirements.
in european polecats, however, the appearance of α2m was particularly pronounced, and the appearance of lipocalin-1 has not previously been found.
4.1. α2-macroglobulin α2m was the most notable protein to appear in abundance shortly before the time of implantation.
it is closely related to pregnancy zone protein (pzp) and three members of the complement system [23].
it is the largest non-immunoglobulin protein in circulation in mammalian blood, comprises an approximately 160 kda polypeptide that is glycosylated, and usually occurs in circulation as a tetramer comprising a pair of non-covalently associated disulfide-linked dimers [23].
it is synthesized mainly in the liver, but also in the decidua and endometrium in mice and possibly also in humans, and is thought to be important for implantation [12,24–27].
α2m is a minor acute-phase inflammation reactant in several species [28].
it operates via two mechanisms as a broad-spectrum proteinase inhibitor [23].
in one mechanism, an active proteinase cleaves a bait peptide that causes α2m to fold around and encapsulate the target enzyme.
in the other, the target proteinase is covalently bound via a thioester bond.
these mechanisms trap proteinases of all classes but do not necessarily inactivate them, instead removing them from access to intact proteins.
in acute-phase and inflammatory responses, the proteinases targeted by α2m are thought to be those of pathogens, but, significantly, also those released by granulocytes and other immune cells in potentially damaging inflammatory reactions [23].
this function could be directly relevant to placentation, given that the sites of placentation in some mammals exhibit local inflammation-like maternal responses [29–31].
the inflammatory response may be amplified by localized apoptosis of epithelial cells, and proteinase inhibition by α2m may minimize damage caused by released enzymes [27,32–37].
α2m also binds several hormones, growth factors and cytokines involved in inflammatory responses, and can modify the biological activity of these signalling molecules [19,23].
in pregnancy, α2m is found in uterine secretions of several species, and has been described to control trophoblast positioning and overgrowth in the mouse [7–12,18,19].
several bands in the gels of polecat uterine flushes contained α2m, ranging in size from close to that of the monomeic glycoprotein (band j) to higher-order structures (dimer, tetramer; bands a and b).
some that did not conform to simple monomers, dimers or tetramers of the protein may be covalent α2m : proteinase complexes that were not dissembled by the reducing agent (figure 2).
the presence of α2m in the uterine lumen could be due to increased permeability of the uterine vessels to plasma proteins or tissue disruption.
if plasma leakage were to have contributed to the presence of α2m, as would also be the case for blood contamination during sampling, then other major plasma proteins, such as immunoglobulins and complement c3, would be present in proportionately high amounts.
none of these were observed, although serum albumin was clearly present at all times.
while this is the most abundant plasma protein in terms of relative molarity, it is found in uterine secretions of other species in the absence of other plasma proteins [8,12].
moreover, α2m is known to be synthesized by uterine tissues in humans and mice (see above).
α2m and pzp are closely related proteins.
the plasma concentration of pzp increases dramatically in the course of human pregnancy.
its functions are not understood [38], although it is known to have proteinase inhibitory activities similar to those of α2m [38,39].
despite pzp's documented synthesis in several reproductive tissues [38], and that a gene encoding a pzp homologue has been predicted in the european polecat genome (ncbi accession xp_012906269.1), our analysis identified no protein that might be identified as pzp in the uterine flushes.
4.2. lipocalin-1 the appearance of lipocalin-1 was unexpected, as it has not previously been described as a component of uterine secretions.
moreover, while other lipocalins have been described in the reproductive tissues of other species, only lipocalin-1 was found in this study of polecat uterine secretions.
also known as tear lipocalin and von ebner's gland protein, lipocalin-1 is a member of a large family of proteins that operates predominately extracellularly.
in addition to its eponymous presence in tears, lipocalin-1 has been found in a wide range of tissues [40], albeit not in uterine secretions.
most lipocalins bind small hydrophobic ligands such as retinol, fatty acids, odorants or pheromones, and some are enzymatic [40,41].
others are involved in infection defence, such as α1-acid glycoprotein (orosomucoid), which is an acute-phase protein in humans that binds a range of small lipophilic molecules and drugs.
lipocalin-2 (neutrophil gelatinase-associated lipocalin) is also an acute-phase protein and binds bacterial siderophores [42,43].
lipocalins associated with reproduction include progestogen-associated endometrial protein (glycodelin, pregnancy-associated endometrial α2-globulin, placental protein 14) secreted by the human endometrium from mid-luteal phase of the menstrual cycle and during the first trimester of pregnancy; a salivary lipocalin found in pigs is secreted into their uteri at the time of implantation [44]; and equine uterocalin is secreted by the endometrium of mares in the pre-placentation period, during which the equine conceptus is confined within a glycoprotein capsule [13,14].
despite all these examples of lipocalins found in reproductive tissues in other species, lipocalin-1 was the only one found in our european polecat samples.
the biochemical properties of lipocalin-1 are known only from the human form, which binds small lipids such as fatty acids and sterols [40].
the protein may therefore be involved in delivering or scavenging lipids at a time when there is significant tissue reorganization and potential for cellular disruption at implantation, as is speculated for the role of porcine salivary lipocalin [8].
lipocalin-1, like lipocalin-2, is known to bind bacterial siderophores, so it may function as part of the innate immune system in an anti-bacterial role [40,45].
human lipocalin-1 also has been recorded as having cysteinyl proteinase inhibitory activity [46], and nuclease activity that can operate against viral genomes [47,48].
the polecat protein may therefore have multiple protective roles in the uterus, as is thought for its function in tears and epithelia in humans [40,49].
taken together, these observations suggest that lipocalin-1 may work alongside α2m to protect the uterine environment against infections, and its lipid-binding may involve sequestration of toxic lipid peroxidation products created under condition of oxidative stress [50].
4.3. tissue-protective and embryo support proteins in addition to α-2m and lipocalin-1, we identified several additional proteins that may protect the uterus against infection and tissue damage associated with implantation.
these include the iron-binding proteins lactoferrin (lactotransferrin) and transferrin (serotransferrin), both of which were present at fairly constant levels throughout the sampling period.
lactoferrin in particular is associated with antimicrobial activity by sequestering iron in milk, it is also synthesized and stored in neutrophil granules [51], and it directly attacks bacterial membranes and has anti-viral activity [52–56].
α1-antitrypsin was also present throughout, and increased in concentration slightly with time.
this is an inhibitor of serine proteinases, is a major acute-phase reactant in humans, and is increasingly recognized as an anti-inflammatory mediator [57].
its primary function appears to be protection against excessive proteolysis of tissues (e.g.
in the lower respiratory tract) by neutrophil elastase in inflammation [58,59].
it has been observed in pregnant uteri of other species, possibly to control proteinases released during tissue remodelling, trophoblast invasion, apoptosis or inflammatory processes that may accompany placentation [60,61].
other proteins increased with time.
cathepsin l1, a cysteinyl proteinase, is usually confined to lysosomes and is involved in mhc class ii antigen processing.
its expression level in uterine tissues is progesterone-dependent, and its importance in placentation has been recognized [60,62,63].
other progesterone-dependent proteins that appeared in the polecat uterine fluid included a member of the ectonucleotide pyrophosphatase family (a lysophospholipase that may be involved in the production of pharmacologically active lipid mediators), and uteroferrin (pregnancy-associated acid phosphatase, which appears to function in transplacental iron transport and stimulation of erythropoeisis) [16,64–70].
curiously, we did not find any dedicated nutrient carrier protein similar to equine uterocalin that might act to support a developing conceptus during a pre-placentation period.
equine uterocalin may, however, be a special adaptation in equids to provide resources for a large, capsule-enclosed conceptus during a prolonged pre-placentation period.
nothing like it has been found in non-equids.
mustelid blastocysts do have extended placentation periods, and they can even distend the uterus before they implant, but they have no glycoprotein capsule intervening between their surfaces and the endometrial surface [6].
moreover, the surface to volume ratios of mustelid conceptuses are substantially smaller than in equids at maximum growth such that they may not need a specialized nutrient carrier.
equine uterocalin and lipocalin-1 bind a similar set of small lipids [15,40], but the former is atypically enriched in essential amino acids [15], a feature that is not true of lipocalin-1.
we did, however, find other lipid carriers that may supply the polecat conceptus with lipids, such as serum albumin and apolipoprotein a-i.
4.4. conclusion the protein secretory response of the pre-implantation phase of pregnancy that we observed in european polecats appears primarily to prevent infection, facilitate implantation and protect against release of deleterious cellular components associated with the tissue trauma of implantation.
some of the lipid-binding proteins we found may also be involved in maternal:embryo communication by transporting insoluble signalling molecules such as progesterone, prostaglandins and leukotrienes, or their precursors (as postulated for equine uterocalin; [13,15]).
it has recently been argued that embryonic diapause is phylogenetically conserved and not secondarily acquired by embryos of diapausing species [2].
it is therefore conceivable that a common ancestor of mustelids that includes european polecats engaged in embryonic diapause.
it would therefore now be interesting to establish whether species of mustelid that exhibit prolonged obligatory embryonic diapause (e.g.
stoats, otters, badgers) show a similar protein secretory response as european polecats during the period when diapausing blastocysts are free in the lumen and devoid of haemotrophic support, or when reactivation of blastocysts occurs and implantation is imminent.
supplementary material figure s1.
changes in european polecat uterine secretory proteins with time after mating.
this figure shows the changes in uterine secreted protein profiles from all the animals used in the study - figures 1 and 2 of the main text show only a selection of these.
@highlight
uterine secretory proteins protect the uterus and conceptuses against infection, facilitate implantation, control cellular damage resulting from implantation, and supply pre-implantation embryos with nutrients.
unlike in humans, the early conceptus of the european polecat (mustela putorius; ferret) grows and develops free in the uterus until implanting at about 12 days after mating.
we found that the proteins appearing in polecat uteri changed dramatically with time leading to implantation.
several of these proteins have also been found in pregnant uteri of other eutherian mammals.
however, we found a combination of two increasingly abundant proteins that have not been recorded before in pre-placentation uteri.
first, the broad-spectrum proteinase inhibitor α2-macroglobulin rose to dominate the protein profile by the time of implantation.
its functions may be to limit damage caused by the release of proteinases during implantation or infection, and to control other processes around sites of implantation.
second, lipocalin-1 (also known as tear lipocalin) also increased substantially in concentration.
this protein has not previously been recorded as a uterine secretion in pregnancy in any species.
if polecat lipocalin-1 has similar biological properties to that of humans, then it may have a combined function in antimicrobial protection and transporting or scavenging lipids.
the changes in the uterine secretory protein repertoire of european polecats is therefore unusual, and may be representative of pre-placentation supportive uterine secretions in mustelids (otters, weasels, badgers, mink, wolverines) in general.
