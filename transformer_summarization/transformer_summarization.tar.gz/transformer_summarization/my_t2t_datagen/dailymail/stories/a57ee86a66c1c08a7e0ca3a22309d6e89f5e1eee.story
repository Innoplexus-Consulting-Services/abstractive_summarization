introduction cowden's syndrome (cs) is a rare autosomal dominant hereditary disease, affecting multiorgans leading to higher risk for malignancies, particularly breast, thyroid, and endometrium, as well as benign hamartomatous overgrowth of skin, colon, and thyroid.
[1] lloyd and dennis were the first persons to describe this syndrome in 1963 and named it after their patient, rachel cowden, who died from breast cancer.
[23] later in 1972, weary et al.
reported additional five cases and suggested the name of multiple hamartoma syndrome (mhs).
[34] till now less than 500 cases were reported in the literature worldwide.
[4] both sexes are equally affected, although some authors believe it to be more common in females in the second or third decade of life than males with a ratio of 6:4.
[34] here we report a rare case of cs in a 45-year-old female patient.
case report a 45-year-old female patient reported to the department of oral medicine with a chief complaint of irregularity on her cheek region and gums.
the patient gave a history of thyroidectomy 13 years back and breast cancer 10 years ago, which was operated.
her past medical history was summarized from previous medical reports available, which revealed on various occasions, gastric and colonic polyps had been extirpated via endoscopy.
on general physical examination, she appeared thin built and anemic.
on extraoral examination, multiple papular lesions were seen on upper and middle-third of the face measuring around 1–3 mm in diameter (scalp, nose, right and left malar processes) [figure 1], and similar cutaneous lesions were found on the neck, which were diagnosed as trichilemmomas on biopsy.
intraoral examination showed multiple papules on the attached gingiva resulting in a cobblestone effect [figure 2], similar papular lesions were also noticed on lower and upper labial mucosa resulting in corrugated appearance, and on the tongue creating a moriform appearance, and a soft nodule measuring about 5 mm in diameter was also noted on right retromolar region [figure 3].
the routine laboratory investigations, such as complete blood count and urinalysis, were noncontributory.
imaging modalities performed were orthopantomogram, revealed an incipient interdental bone loss; and gastrointestinal (gi) endoscopy revealed multiple intestinal lymphoid polyps [figure 4].
the incisional biopsy performed on gingiva revealed a nonkeratinized stratified squamous epithelium with pseudoepitheliomatous hyperplasia and dense collagenous fibers in connective tissue with focal areas of hemorrhage, suggestive of inflammatory gingival hyperplasia [figure 5].
based on the history, clinical examination, and histopathological findings a diagnosis of cs was considered.
figure 1 multiple papular flat topped trichilemmomas seen on and around the nose of the patient figure 2 multiple papules on gingiva giving rise to a cobblestone appearance figure 3 multiple papules on tongue giving rise to a moriform appearance and soft nodule noted on right retromolar region figure 4 intestinal polyps on gastrointestinal endoscopy figure 5 photomicrograph (h and e, ×40) showing nonkeratinized stratified squamous epithelium with pseudoepitheliomatous hyperplasia and dense collagenous fibers in connective tissue discussion cs is a rare autosomal dominant genodermatosis, characterized by multiple hamartomas affecting the tissues arising from all the three germ layers like skin, oral mucosa, gi tract, bones, eyes, central nervous system, and genitourinary tract.
so the name multiple hamartoma syndrome was considered.
[56] the exact etiology is unknown.
but in 85% of the cases, mutation in the phosphate and tensin homolog (pten) tumor suppressor gene also termed as mutated in multiple advanced cancers (mmac1) on chromosome 10q22-23 was observed.
[567] the pten protein product is believed to promote cell death and lead to overproliferation of cells, due to the mutation that causes loss of protein function that may result in hamartomatous growths.
[5] cs exhibits orofacial features, which include multiple papules on gingiva, labial mucosa, and on tongue giving a cobblestone appearance, multiple fibroepithelial polyps, oral papillomatosis, nodular gingival hyperplasia, fissuring with lobulations on tongue, multiple facial trichilemmomas (hamartomas of hair follicle tissue), and ackral keratosis.
[8] in the present case all the above features are present except ackral keratosis.
systemic features include thyroid abnormalities (75% such as benign multinodular goiter, lymphocytic thyroiditis, and adenomas); gi lesions (50% such as multiple intestinal polyps), macrocephaly, genitourinary abnormalities, and malignancies particularly adenocarcinoma of breast (25% to 50%); thyroid cancer (3% to 10%); endometrial cancer (5%–10%); and renal cell carcinoma.
[6789] a recent study reported that 6% of cs patients are associated with melanoma.
[9] in the present case the patient had multiple intestinal polyps, thyroid abnormalities, and also gave a history of carcinoma of breast, for which she underwent treatment.
cs is a diagnostic hurdle for the clinicians as it can manifest with various clinical features and in many instances it does not manifest classically.
so the international cowden syndrome consortium has proposed operational criteria for the diagnosis of cs in 1996 and it was revised in 2008 by the national comprehensive cancer network given below[6810] [table 1].
table 1 diagnostic criteria proposed by the international cowden syndrome consortium the diagnosis of cs is usually made on the following: (1) the presence of pathognomonic criteria alone if there are six or more facial papules with three of which must be trichilemmomas, or orofacial papillomatosis and acral keratosis, or identification of six or more palmoplantar keratosis lesions; (2) two major criteria with one being lhermitte–duclos disease or macrocephaly; (3) one major and three minor criteria; and (4) four minor criteria.
[6810] the present case report fulfilled the pathognomonic (oral papillomatous lesions and facial cutaneous papules), major (breast cancer) and minor (hamartomatous intestinal polyps, goiter, and fibromas) criteria given by the international cowden consortium.
cs with various clinical manifestations presents difficulty in diagnosis, and based on its clinical manifestations differential diagnosis includes bannayan–riley–ruvalcaba syndrome, proteus syndrome, tuberous sclerosis, fragile x syndrome, heck's disease, darier's disease, epidermolysis bullosa, goltz syndrome, and juvenile polyposis syndrome.
[6] the baseline laboratory investigations such as complete blood count, urinalysis, thyroid function tests, lesional biopsy, molecular gene analysis study, and imaging modalities such as biannual mammograms to screen breast cancer, chest radiograph, thyroid scans, and gi endoscopy are essential and play an important role in early diagnosis.
[5] treatment of this syndrome is complicated due to increased risk of cancer of multiple organs.
[6] the mucocutaneous lesions can be treated with 5-fluorouracil, retinoids, electrosurgery, cryosurgery, dermabrasion, laser abrasion, interferon-2α, bleomycin, and surgery.
[511] in future, restoration of pten-associated molecular pathways may help to control the increased risk of cancer in these patients.
[6] the overall prognosis of this syndrome depends on frequent followup, which is main key to survival.
[56] conclusion cs represents with different clinical manifestations, making a diagnostic challenge to the oral physician.
so every physician should be aware of various clinical features as well as diagnostic criteria proposed by the international cowden consortium for early detection, and prompt treatment to decrease the mortality.
this article emphasizes on various mucocutaneous manifestations and their importance in diagnosis of this syndrome.
declaration of patient consent the authors certify that they have obtained all appropriate patient consent forms.
in the form the patient(s) has/have given his/her/their consent for his/her/their images and other clinical information to be reported in the journal.
the patients understand that their names and initials will not be published and due efforts will be made to conceal their identity, but anonymity cannot be guaranteed.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
cowden's syndrome is an autosomal dominant genodermatosis with variable orofacial and systemic manifestations.
here we present one such classical case of cowden's syndrome in a 45-year-old female patient with features such as multiple cutaneous papillomatosis, oral fibromas, and fibromas involving multiple organs such as gastrointestinal tract (multiple polyps), thyroid disorders, and breast cancer.
