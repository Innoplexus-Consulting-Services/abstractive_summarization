introduction preoperative assessment of the patient's airway enables the anaesthesiologist to predict the ease of visualising the glottis and to perform intubation.
several bedside physical airway assessment tests are available, but they have a high inter-observer variability[1] and moderate to fair sensitivity and specificity.
[2] they may also be difficult to apply in emergency and critical care settings, where patients are frequently confused, uncooperative and unable to follow directions.
[3] the rationale for the use of ultrasonography (usg) for assessment of tissues in close proximity to the larynx is based on the observation of the process of direct laryngoscopy.
direct laryngoscopy involves introducing the blade of the laryngoscope into the mouth and displacing the tongue, epiglottis and hyoid bone into the subglossal space.
the tip of the laryngoscopic blade rests against the hyoepiglottic ligament, which forms the anterior border of the pre-epiglottic space (pes).
researchers have hypothesised that increased anterior neck soft tissue thickness could impair the forward mobility of the pharyngeal structures[345] and that an increase in the pes or a decrease in the distance from the epiglottis to the vocal cords could be associated with increasingly difficult laryngoscopy and intubation.
[6] there is limited literature available that compares the ultrasound (us) parameters to the cormack-lehane (cl) grade and physical parameters.
hence, the present study was undertaken to determine the utility of the us measurement of three parameters in the evaluation of the airway: anterior neck soft tissue thickness at the level of the hyoid (ans-hyoid), anterior neck soft tissue thickness at the level of the vocal cords (ans-vc) and ratio of the depth of the pes (pre-e) to the distance from the epiglottis to the mid-point of the distance between the vocal cords (e-vc).
three physical parameters: mallampati (mp) class, thyromental distance (tmd) and sternomental distance (smd), were then compared with the us measurements.
methods after approval by the institutional review board and obtaining written informed consent, 100 consecutive patients undergoing elective surgery under general anaesthesia with endotracheal intubation were included in the study.
the study was a prospective, observational study conducted in the neuroanaesthesia department of a tertiary care centre.
patients above the age of 18 years without any known airway pathology were included in the study.
those requiring rapid sequence intubation, with cervical spine pathology, scheduled for fibreoptic tracheal intubation, uncooperative patients and pregnant patients were excluded.
preanaesthetic evaluation of the patient was done before the surgery.
patient airway assessment was carried out in two stages by the principal investigator.
the modified mp class, tmd (distance from mentum to thyroid notch with the neck fully extended[7]) and smd (distance from suprasternal notch to mentum with the neck fully extended[8]) were noted.
us measurements were obtained using a sonosite® micromaxx® ultrasound system (sonosite inc, bothell, wa, usa) with hfl38/13-6 mhz transducer.
with the patient in the sniffing position [figures 1 and 2], the anterior neck soft tissue thickness was measured as the distance from the skin to the anterior aspect of the trachea at the level of the hyoid (ans-hyoid) and the vocal cords (ans-vc).
[9] figure 1 measurement of anterior neck soft tissue thickness at the level of the hyoid figure 2 measurement of anterior neck soft tissue thickness at the level of the vocal cords with the patient in the supine position with active maximal head extension [figure 3], the ultrasound probe was placed in the submandibular area in plane a (a coronal plane to see the mouth opening).
without changing the position of the probe, the us probe was rotated in the transverse planes from cephalad to caudad direction, i.e., plane a, through planes c-e, to plane g, which was an oblique transverse plane bisecting the epiglottis and posterior most part of the vocal folds with arytenoids in one 2-dimensional view.
further rotation of the us array was ceased at this point [figure 4].
in this plane g, the epiglottis is visible as a hypoechoic curvilinear structure.
its anterior border is demarcated by the hyperechoic pes and its posterior border by a bright linear air mucosal interface.
the posterior most part of the two vocal folds with arytenoids appear as hyperechoic lateral v-shaped structures facing away from each other [figure 5].
protrusion of the tongue or swallowing helps to identify the epiglottis.
identification of the vocal folds is facilitated by observing their linear movement during quiet breathing or phonation.
the pre-e and the e-vc were measured.
the ratio was calculated and recorded.
[6] figure 3 measurement of the ratio of the depth of the pre-epiglottic space to the distance from the epiglottis to the mid-point of the distance between the vocal cords figure 4 picture showing the plane through which the ultrasound beam (yellow line) passes in plane g figure 5 ultrasonographic image in plane g. sm – strap muscles; r vc – right vocal cord; l vc – left vocal cord; red arrow – depth of the pre-epiglottic space; orange arrow – distance from the epiglottis to the mid-point of the distance between the vocal cords the patients were induced and intubated by a senior anaesthesiologist with more than 10 years of experience post-qualification.
he was blinded to the findings of preoperative airway assessment.
direct laryngoscopy was performed using a macintosh blade (size 3 blade in female patients and medium sized male patients or size 4 blade in well built male patients) and the cl grade was noted.
intubation was classified as easy (cl grade 1 and 2) or difficult (cl grade 3 and 4).
appropriate sized endotracheal tube (ett) was inserted and anaesthesia was maintained.
the number of attempts at intubation, need for alternative difficult intubation approaches and invasive airway access or cancellation of the procedure due to inability to secure the airway was also noted.
a total sample size of 100 was arrived at for a power of 75% to detect a change in sensitivity from 0.645 to 0.75 using a two-sided binomial test and 97% power to detect a change in specificity from 0.824 to 0.95 using a two-sided binomial test.
the target significance level is 0.05. the sensitivity and specificity values for calculation were based on a previous study by adamus et al.
[10] the ms excel® and spss® 10.5 (spss inc., chicago, il, usa) software packages were used for data entry and analysis.
the results were averaged (mean ± standard deviation [sd]) for each parameter for continuous data.
the chi-square test was used to determine whether there was a statistical difference between the patients with easy and difficult intubations.
the predictive value of the tests was assessed by calculating the sensitivity, specificity, positive predictive value (ppv), negative predictive value (npv) and accuracy.
to assess the optimal cut-off scores, a relative operating characteristics (roc) curve was plotted and the area under the curve was calculated to assess the prognostic accuracy.
results one hundred adult patients undergoing elective surgery under general anaesthesia with endotracheal intubation were included in the study.
the study population included individuals in the age group of 18-70 years with 69% males and 31% females.
the body mass index (bmi) of the study population ranged from 14.2 to 39.0 kg/m2.
it was found that 39% of the patients had cl grade 1, 47% had cl grade 2 and 14% had cl grade 3. there were no patients with cl grade 4. tables 1–4 show the distribution of the cl grade in comparison with the us parameters, mp class, tmd and smd.
table 5 shows the correlation and regression coefficients of the us parameters.
the easy intubation (cl grade 1 or 2) group of patients had a mean ans-vc of 0.25 ± 0.11, with a range of 0.07–0.67 cm.
the patients with difficult intubation (cl grade 3 or 4) had a mean of 0.35 ± 0.18 cm, with a range of 0.18–0.76 cm.
there was a statistically significant difference between the two groups (p = 0.004).
using a roc curve, we found that an ans-vc of >0.23 cm was associated with difficult intubation (area under the roc curve = 0.73) [figure 6].
the sensitivity, specificity, ppv, npv and accuracy of the parameters included in the study were calculated and are represented in table 6. table 1 comparison of ultrasound parameters with cormack–lehane (cl) grade table 2 distribution of cormack–lehane (cl) grade according to mallampati (mp) class table 3 distribution of cormack–lehane (cl) grade according to thyromental distance (tmd) table 4 distribution of cormack–lehane (cl) grade according to sternomental distance (smd) table 5 correlation and regression coefficient of ultrasound parameters figure 6 relative operating characteristics curve for anterior neck soft tissue thickness at the level of the vocal cords table 6 comparison of ultrasonographic measurements with physical parameters in predicting the cormack–lehane grade thirteen per cent (13 patients) of our study population required more than one attempt or additional equipment to achieve endotracheal intubation.
among them, 46.2% (6) had ans-vc >0.23 cm, 23.1% (3) had mp class ≥3, 15.3% (2) had tmd <6.5 cm and 7.7% (1) each had pre-e/e-vc between 2-3 and smd ≤12.5 cm.
discussion ultrasound has become a part of the anaesthesiologists’ armamentarium to facilitate various procedures in the operation theatre and critical care areas.
imaging of the airway is a newer application of ultrasound.
[91112] it can be used for prediction of paediatric ett size,[13] prediction of double lumen tube size,[14] confirmation of correct placement of ett,[12] diagnosis of upper airway pathology,[9] guidance of percutaneous tracheostomy[9] and cricothyroidotomy,[12] for performing nerve blocks to facilitate awake intubation,[15] in the detection of subglottic stenosis,[9] prediction of post-extubation stridor[16] and confirmation of proper laryngeal mask airway position.
[9] usg has also been used to assess the size of the tongue,[317] floor of the mouth musculature,[17] pre-e,[6] e-vc[6] and anterior neck soft tissue thickness.
[34] these measurements have been used to correlate with the findings obtained from physical assessment.
inability to view the hyoid on sublingual sonography has also been found to be associated with difficult intubation.
[18] in the present study, it was found that the measurement of the ans-vc is a potential tool in airway assessment and a thickness of more than 0.23 cm correlated with the prediction of difficult intubation.
in a similar study that was conducted comprising a middle eastern population, the investigators found that the amount of pre-tracheal soft tissue in the easy and difficult laryngoscopy groups was mutually exclusive.
patients in whom laryngoscopy was difficult had more pre-tracheal soft tissue (mean [sd] 28 [2.7] mm vs. 17.5 [1.8] mm; p < 0.001) and greater neck circumference (50 [3.8] vs. 43.5 [2.2] cm; p < 0.001).
[4] however, in another study conducted in an american population, it was found that the anterior neck soft tissue thickness was not a good predictor of difficult laryngoscopy.
[5] both these studies included a population with a bmi >35 kg/m2 unlike the current study which had only one patient with a bmi >35 kg/m2.
ans-hyoid did not prove to be a significant predictor of difficult intubation (p = 0.857) in our study.
a study that was conducted previously among whites and african americans resulted in conflicting findings.
[3] this was probably due to the differences in the study populations involved.
in a study conducted at the wayne university, detroit, united states,[6] the investigators attempted to predict the cl grade using a noninvasive technique such as the ultrasound.
they found that the pre-e had a positive correlation, e-vc had a negative correlation and the ratio pre-e/e-vc had the strongest positive correlation with cl grade.
similar findings were observed in the present study, but it was found that the correlation of the pre-e and e-vc with the cl grade was not statistically significant (p = 0.154 and 0.084, respectively).
the ratio pre-e/e-vc had a significant correlation with the cl grade (p = 0.026).
further, the study conducted at wayne university concluded that prediction of cl grades could be adequately (67%–68% sensitivity) made by the ratio of pre-e and e-vc distances (pre-e/e-vc).
it was found that a ratio of 0–1 ≈ cl grade1; 1–2 ≈ cl grade 2; and 2–3 ≈ cl grade 3. there were no patients with cl grade 4. using this criteria, we found that prediction of difficult intubation (pre-e/e-vc 2–3) had a high specificity but a very low sensitivity.
in our study, we found that mp class and smd were good predictors of difficult intubation, but the tmd was not.
however, the tmd had a high specificity and npv.
amongst all the parameters that were assessed, the ans-vc had the highest sensitivity in predicting difficult intubation, which was higher than that of the mp class, tmd and smd.
the specificity, ppv and accuracy were lower than the physical parameters.
the npv was comparable.
the us measurement of the ans-hyoid was not a useful indicator of difficult intubation in the present study population.
the ratio pre-e/e-vc was useful in predicting a difficult intubation.
however, it had a low sensitivity, npv and accuracy.
its specificity and ppv were comparable to that of the mp class and tmd.
we also found that increasing age, bmi, decreased mandibular protrusion and difficult mask ventilation were other factors associated with difficult intubation.
gender, history of obstructive sleep apnoea, decreased mouth opening and abnormal dentition did not influence the cl grade.
we included only 100 adult patients of asian origin.
the incidence of difficult intubation in our study was only 14%, with none of the patients having a cl grade 4. patients with abnormal dentition were not excluded.
this could have contributed to a higher incidence of difficult intubation.
only 6% of our subjects were obese (bmi ≥30 kg/m2).
all these are potential limitations of this study.
further investigations can be done involving a more diverse study population including patient groups having factors known to cause difficult intubation such as pregnancy, obesity and syndromes involving the airway.
studies can also be done to correlate the neck circumference with the us measurements of the ans-vc.
conclusion us measurement of the ans-vc is a potential predictor of difficult intubation.
a value of more than 0.23 cm is more sensitive than the physical parameters such as mp class, tmd and smd in predicting a cl grade of 3 or 4. us measurement of ans-hyoid is not a useful indicator in predicting difficult intubation.
the ratio pre-e/e-vc has a low to moderate predictive value.
declaration of patient consent the authors certify that they have obtained all appropriate patient consent forms.
in the form the patient(s) has/have given his/her/their consent for his/her/their images and other clinical information to be reported in the journal.
the patients understand that their names and initials will not be published and due efforts will be made to conceal their identity, but anonymity cannot be guaranteed.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
background and aims: accurate prediction of the cormack-lehane (cl) grade preoperatively can help in better airway management of the patient during induction of anaesthesia.
our aim was to determine the utility of ultrasonography in predicting cl grade.
methods: we studied 100 patients undergoing general endotracheal anaesthesia.
mallampati (mp) class, thyromental distance (tmd) and sternomental distance (smd) were noted.
ultrasound measurements of the anterior neck soft tissue thickness at the level of the hyoid (ans-hyoid), anterior neck soft tissue thickness at the level of the vocal cords (ans-vc) and ratio of the depth of the pre-epiglottic space (pre-e) to the distance from the epiglottis to the mid-point of the distance between the vocal cords (e-vc) were obtained.
cl grade was noted during intubation.
chi-square test was employed to determine if there was any statistical difference in the measurements of patients with different cl grades.
sensitivity, specificity, positive predictive value (ppv), negative predictive value (npv) and accuracy were calculated for the various parameters.
results: the incidence of difficult intubation was 14%.
an ans-vc >0.23 cm had a sensitivity of 85.7% in predicting a cl grade of 3 or 4, which was higher than that of mp class, tmd and smd.
however, the specificity, ppv and accuracy were lower than the physical parameters.
the npv was comparable.
conclusion: ultrasound is a useful tool in airway assessment.
ans-vc >0.23 cm is a potential predictor of difficult intubation.
ans-hyoid is not indicative of difficult intubation.
the ratio pre-e/e-vc has a low to moderate predictive value.
