introduction cd4+ tcrαβ t cells centrally orchestrate multiple arms of innate and adaptive immunity using distinct and, often, opposing effector and regulatory functions through the differentiation of distinguishable functional cd4+ t cell subsets (o’shea and paul, 2010, swain et al., 2012, zhu et al., 2010).
several such functional subsets are now recognized, including the prototypic th1 and th2 subsets but also the th17, follicular helper (tfh), and regulatory t (treg) subsets, each characterized by a well-defined transcriptional program (crotty, 2014, o’shea and paul, 2010, swain et al., 2012, vinuesa et al., 2016, zhu et al., 2010).
based on the increasingly appreciated diversity of cd4+ t cell activities, additional functional subsets have been proposed.
these include cd4+ with cytotoxic t cell (ctl) potential, able to kill target cells through the release of granzyme-containing granules (brown et al., 2016, cheroutre and husain, 2013, swain et al., 2012).
cytotoxicity is typically associated with cd8+ t cells and natural killer (nk) cells and has not been conventionally considered a cd4+ t cell function (cullen et al., 2010).
indeed, “helper” and “cytotoxic” terms are often used to describe the major histocompatibility complex (mhc) class-ii-restricted cd4+ and mhc class-i-restricted cd8+ tcrαβ t cell lineages, respectively.
commitment of developing thymocytes to the cd4+ or cd8+ lineage and acquisition of either helper or cytotoxic activity is controlled by the antagonistic transcription factors thpok and runx3.
thpok suppresses the cytotoxic program in cd4+ thymocytes and mature t cells, whereas runx3 promotes this program in cd8+ t cells (cheroutre and husain, 2013).
despite transcriptional repression of the cytotoxic program during cd4+ t cell development, mhc class-ii-restricted, cell-contact-dependent cytotoxicity has long been observed in a variety of conditions, both in humans and experimental animals (brown, 2010, brown et al., 2016, cheroutre and husain, 2013, soghoian and streeck, 2010, swain et al., 2012, van de berg et al., 2008).
although cd4+ t cells can kill target cells also through surface expression of tumor necrosis factor (tnf) family members, including fasl and trail, accumulated evidence has established their ability to develop and use granzyme-mediated cytotoxic activity (brown et al., 2016, cheroutre and husain, 2013).
pivotal recent studies with a thpok-reporter mouse strain uncovered considerable plasticity of the “helper” program in cd4+ t cells, with loss of thpok expression and transcriptional switch to the “cytotoxic” program.
indeed, a sizable fraction of cd4+ t cells residing in the intestine as intraepithelial lymphocytes (iels) downregulate the expression of zbtb7b (the gene encoding thpok) and acquire the expression of runx3 (mucida et al., 2013, reis et al., 2013).
this transcriptional reprogramming is accompanied by the expression of genes more characteristic of the cd8+ lineage, such as cd8a, crtam, and eomes, and, importantly, also by the development of gzmb-mediated cytotoxic potential (mucida et al., 2013, reis et al., 2013).
these studies emphasize the similarities between cd8+ t cells and reprogrammed cd4+ ctls and suggest that the latter subset should be viewed as distinct from other cd4+ th cell subsets (cheroutre and husain, 2013).
despite these significant advances, the factors that dictate cd4+ ctl differentiation are still incompletely understood.
also unclear are the precise place of cd4+ ctls in the transcriptional spectrum of all th cell subsets and whether the cd4+ ctl program is compatible with other th cell differentiation pathways.
here, we investigated the priming requirements for cd4+ ctls and the signals that either promote or inhibit cd4+ ctl differentiation.
to overcome the lack of a reliable marker for the unambiguous identification of cd4+ ctls, we applied global transcriptional analysis of single cd4+ t cells.
we report that cd4+ ctl differentiation strictly depends on the infecting or immunizing virus, with retroviral infection and adenovirus-based vaccination at the low and high ends of the spectrum, respectively.
moreover, our results uncovered regulation of the cd4+ ctl program by expression of inhibitory receptors and direct antagonism by the tfh program.
results cd4+ ctl development depends on infecting virus we have previously described an adoptive transfer system that allows the study of the cd4+ t cell response to the dominant h2-ab-restricted env122–141 epitope within the friend murine leukemia virus (f-mlv) gp70 glycoprotein (merkenschlager et al., 2016, thorborn et al., 2014).
small numbers of allotypically marked ef4.1 tcrβ-transgenic cd4+ t cells were transferred into wild-type (wt) c57bl/6 (b6) recipients and primed either by infection with friend virus (fv) or by immunization with a human adenovirus 5 (ad5)-based vector expressing f-mlv gp70 (ad5.pix-gp70) (bayer et al., 2010).
fv is a retroviral complex of f-mlv and spleen focus-forming virus (sffv) that causes chronic infection in b6 mice (hasenkrug and chesebro, 1997, tsuji-kawahara et al., 2013), whereas the ad5.pix-gp70 vaccine vector is replication defective (bayer et al., 2010).
microarray-based comparison of ef4.1 env-reactive cd4+ t cells primed by ad5.pix-gp70 indicated elevated transcription of ctl-related genes, in comparison with t cells primed by fv (thorborn et al., 2014).
indeed, on day 7 of the response, env-reactive effector cd4+ t cells expressed significantly higher amounts of gzmb mrna when primed by ad5.pix-gp70 than when primed by fv (figure 1a).
moreover, the hosts exhibited significantly higher levels of mhc class-ii-restricted in vivo cytotoxicity against env122–141-pulsed b cell targets when primed by ad5.pix-gp70 than when primed by fv (figure 1b).
more efficient in vivo killing also correlated with enhanced gzmb-mediated in vitro killing, by purified env-reactive cd4+ t cells, of b cells loaded with a fluorogenic gzmb substrate (figure 1c).
consistent with higher gzmb expression and gzmb-mediated killing at the population level, env-reactive effector cd4+ t cells contained a significantly higher proportion of gzmb+ cells if primed by ad5.pix-gp70 than if primed by fv (figure 1d).
notably, gzmb protein expression was detected in env-reactive effector cd4+ t cells even without in vitro restimulation (figure s1a), suggesting that it reflected in-vivo-induced production.
moreover, ef4.1 env-reactive cd4+ t cells, additionally carrying an allele encoding a fusion of gzmb and tdtomato fluorescent protein (mouchacca et al., 2013), contained a significantly higher frequency of gzmb-tdtomato+ cells when primed by ad5.pix-gp70 than when primed by fv (figure s1b).
together, these data support the idea that gzmb production was induced in vivo in splenic cd4+ t cells during ad5.pix-gp70 immunization.
furthermore, ad5.pix-gp70 vaccination induced a significantly higher frequency of gzmb+ cells in splenic host effector cd44+ifn-γ+cd8+ t cells than fv infection did (figure s2), arguing that the difference between the two immunogens was not restricted to cd4+ t cells or to tcr (t cell-receptor)-transgenic t cells.
one notable difference between fv infection and ad5.pix-gp70 immunization is their ability to prime different tcr clonotypes (thorborn et al., 2014).
ef4.1 env-reactive cd4+ t cells induced by fv are primarily tcr vα2+, whereas those induced by ad5.pix-gp70 express a member of the tcr vα3 family (thorborn et al., 2014).
differences in tcr usage could underlie the distinct ability of fv and ad5.pix-gp70 to induce cd4+ ctls.
indeed, differentiation of gzmb+ cd4+ t cells was moderately higher in vα3+ than the vα2+ fraction of fv-primed env-reactive cd4+ t cells (figures s3a and s3b).
nevertheless, the two fractions differentiated into gzmb+ cd4+ t cells with comparable efficiency upon ad5.pix-gp70 immunization (figures s3a and s3b).
moreover, ad5.pix-gp70 induced significantly stronger gzmb expression in monoclonal tcr-transgenic evα2 cd4+ t cells than fv infection did (figure s3c).
these results indicated a small effect of tcr usage on cd4+ ctl differentiation, which was, however, overshadowed by other properties of the two viruses.
lastly, different immunization regimens elicited distinct frequencies of gzmb+ cells within env-reactive effector cd4+ t cells (figure 1e).
these included non-persisting infection with attenuated n-tropic f-mlv (f-mlv-n) (dittmer et al., 1998) or transient env124–138 peptide immunization, which failed to induce gzmb+ cells, and transplantation of the fv-induced fbl-3 tumor cell line (klarnet et al., 1989), which induced moderate levels of gzmb+ cells (figure 1e).
they also included infection with a replication-competent and persisting mouse-cytomegalovirus (mcmv)-based vector encoding f-mlv env, which also induced readily detectable gzmb+ cells (figure 1e).
thus, properties of the infecting or immunizing virus, independently of its ability to persist in the host, largely determine the efficiency of antigen-specific cd4+ t cell differentiation into ctls, with ad5.pix-gp70 outperforming fv.
antagonistic cd4+ ctl and tfh development both tcr usage and the nature of infecting virus can heavily influence th subset differentiation, which is reflected in the corresponding transcriptional profiles.
the necessary cell processing for intracellular gzmb staining precluded further transcriptional analysis between gzmb+ and gzmb− cd4+ t cells.
to overcome this limitation, we performed single-cell rna sequencing of env-specific cd4+ t cells primed either by fv or ad5.pix-gp70.
consistent with flow-cytometric detection of gzmb production, fv induced gzmb expression in 3/57 and 1/65 cells (an average of 3.2%), whereas ad5.pix-gp70 induced gzmb expression in 6/42 and 4/45 cells (an average of 11.5%) analyzed in two independent runs (p = 0.022, fisher’s exact test) (figure 2a).
in contrast, expression of other cytotoxic mediators, such as tnfa, fasl, and tnfsf10, was comparable between fv and ad5.pix-gp70 priming (figure s4).
it should be noted that gene expression assessment by single-cell rna sequencing represents the lower limit, as it captures only a fraction of the genes expressed in a given cell.
this is evident in the transcription of the cd4 gene, which is not detected in all of the cd4+ t cells analyzed (figure 2a).
single-cell transcriptional analysis revealed another notable difference between fv-primed and ad5.pix-gp70-primed cd4+ t cells: a significantly higher proportion of the former transcribed bcl6 (p = 0.025, fisher’s exact test) (figure 2b), which is essential for tfh development (crotty, 2014, vinuesa et al., 2016).
in contrast, the two types of cd4+ t cells displayed comparable transcription of tcf7 (figure 2b), encoding the transcription factor tcf-1, which has been recently found to promote tfh development at multiple levels, including through induction of bcl6 transcription (choi et al., 2015, wu et al., 2015, xu et al., 2015).
independently assessed in cd4+ t cell populations, levels of tcf7 were not significantly lower in ad5.pix-gp70-primed than in fv-primed cd4+ t cells, whereas levels of bcl6 were (figure 2c).
together, these results suggested that the degree of ctl and tfh differentiation in env-specific cd4+ t cells are inversely correlated and dictated by the priming virus.
to examine whether ctl differentiation was inhibited by competing th programs, we compared the gene transcripts that distinguished gzmb+ cells (table s1).
interestingly, gzmb+ cells primed by either virus were characterized by specific loss of tcf7 expression, among a selected set of genes (figure 2d).
conversely, gzmb+ cells were characterized by elevated expression of several other genes, including cxcr6, entpd1 (encoding cd39), slamf1 (encoding cd150), and cd226 (figure 2d), which were further validated by flow cytometry (figure 2e).
these transcriptional differences were also significant when gzmb− and gzmb+ cells primed by ad5.pix-gp70 only were analyzed (figure s5).
accordingly, none of the ad5.pix-gp70-primed gzmb+ cells expressed bcl6, and half of them expressed the antagonistic transcription factor blimp-1, encoded by prdm1, in sharp contrast to gzmb− cells (figure 2f).
also in contrast to gzmb− cells, which were nearly all tcf7+ and most also expressed lef1, encoding the tcf-1 homolog lef-1, gzmb+ cells only sporadically expressed tcf7 and lef1 (figure 2f; figure s6a).
the balance of zbtb7b (encoding thpok) and runx3 transcription, associated with the cd4+ and cd8+ lineages, respectively (cheroutre and husain, 2013), was also altered in ad5.pix-gp70-primed gzmb+ t cells (figure 2f; figure s6a).
this observation is consistent with previous reports on intestinal cd4+ ctls, in which runx3 expression is associated with cd8α expression (mucida et al., 2013, reis et al., 2013).
in contrast to intestinal cd4+ ctls, however, the altered balance of zbtb7b and runx3 transcription in splenic gzmb+ cd4+ t cells induced by ad5.pix-gp70 did not lead to transcription of either the cd8a or cd8b1 genes or the acquisition of crtam or eomes expression (figure s6b).
lastly, transcription of cd5 and nr4a1 (encoding nur77), which could be indicative of the strength of tcr signaling experienced by env-specific cd4+ t cells, did not significantly differ between gzmb− and gzmb+ cells (figure s6c), suggesting that tcr signal strength is not the primary determinant of cd4+ ctl differentiation.
collectively, these findings point to a cd4+ ctl-specific transcriptional signature, characterized by acquisition of runx3 transcription and, importantly, downregulation of tfh-related transcription, particularly of tcf7.
bcl6 suppresses cd4+ ctl development loss of tfh-specific transcription in gzmb+ cd4+ t cells suggested that the tcf-1–bcl6 nexus was incompatible with, or actively inhibiting, cd4+ ctl differentiation.
to test this possibility, we used conditional ablation of bcl6 in env-specific effector cd4+ t cells, which were transferred into wt hosts (figure s7).
this was achieved by expression of cre in donor cd4+ t cells under the control of the tnfrsf4 promoter (tnfrsf4cre) (klinger et al., 2009).
this promoter activates in the majority of cd4+ t cells, only following antigen recognition, thus avoiding any effects of gene deletion during t cell development and prior to activation (marques et al., 2009).
effector cd4+ t cells that activated the tnfrsf4 promoter were identified using a cre-conditional yellow fluorescent protein (yfp) reporter (gt(rosa)26soryfp) allele.
a cre-conditional bcl6 (bcl6fl) allele (kaji et al., 2012) was also introduced in separate donor ef4.1 mice.
these combinations created four separate populations of env-specific donor cd4+ t cells (figure 3a; figure s7).
particularly, yfp− cd4+ t cells with (bcl6fl) or without the conditional bcl6 allele (bcl6wt) would be comparable, as they retained the capacity to express bcl6, whereas yfp+ bcl6fl, but not bcl6wt, cd4+ t cells would lose this capacity (merkenschlager et al., 2016).
transcriptional analysis of env-specific donor cd4+ t cell populations primed by either virus confirmed significantly higher bcl6 expression in fv-primed than in ad5.pix-gp70-primed t cells, regardless of tnfrsf4 promoter activity (figure 3b).
moreover, bcl6 expression was lost in the yfp+, but not the yfp−, fraction of bcl6fl t cells (figure 3b), validating the approach.
loss of bcl6 expression in the yfp+ fraction was accompanied by significant gain in expression of prdm1, as well as of gata3, tbx21, and ifng (figure 3b), but not of foxp3 or rorc (figure s8), suggesting that bcl6 was suppressing the th1 and th2 programs.
this effect of bcl6 deletion on cd4+ t cell differentiation was further confirmed by intracellular staining for t-bet (encoded by tbx21) and interferon (ifn)-γ (figure s9).
higher levels of t-bet and ifn-γ were induced by fv infection than ad5.pix-gp70 immunization in bcl6wt cd4+ t cells, and these were not further elevated in bcl6fl cd4+ t cells (figure s9).
in contrast, the low levels of t-bet and ifn-γ induced by ad5.pix-gp70 immunization in bcl6wt cd4+ t cells were significantly elevated in bcl6fl cd4+ t cells (figure s9).
in addition to enhancing differentiation of other th cell subsets, loss of bcl6 expression led to a striking upregulation of gzmb transcription, specifically in ad5.pix-gp70-primed cd4+ t cells (figure 3b).
importantly, the gain in gzmb expression in the latter population (>13-fold) was considerably more pronounced than the gain in the transcription of the other genes examined (2.2- to 3.8-fold) (figure 3b).
the significantly heightened transcription of gzmb, specifically in ad5.pix-gp70 immunization, was additionally confirmed by intracellular staining for gzmb in the total env-specific bcl6fl cd4+ t cell population, containing both bcl6-deleted and non-deleted cells (figure 4a).
to gain better insight into the transcriptional profile of only the bcl6-deleted env-specific cd4+ t cells, without the need for in vitro restimulation, we next subjected the purified yfp+ fraction of bcl6fl cd4+ t cells to single-cell rna sequencing.
this analysis demonstrated a significant increase in the frequency of gzmb+ cells in bcl6-deleted env-specific cd4+ t cells following priming by ad5.pix-gp70 (figure 4b).
indeed, nearly 40% of these cells were positive for gzmb transcripts (figure 4b).
in contrast, the frequency of gzmb+ cells in bcl6-deleted env-specific cd4+ t cells primed by fv did not change significantly (figures 2a and 4b).
these data with bcl6-deleted populations and purified single cells suggested that bcl6 was restraining the ctl program in env-specific cd4+ t cells, at least during ad5.pix-gp70 priming.
to relate the effect of bcl6 deletion on gzmb expression, we examined the transcription of additional effector molecules in single wt or bcl6-deleted env-specific cd4+ t cells.
a high proportion (68%) of wt cd4+ t cells primed by fv expressed il21 (which, in these settings, was characteristic of the tfh response), and a smaller proportion (14%) expressed il10, with only partial overlap with ifng expression (figure 4c).
although loss of bcl6 during fv infection did not markedly reduce il21 expression, it did significantly enhance expression of both ifng (2.3-fold) and il10 (4.7-fold), which were now co-expressed in the majority of bcl6-deleted cd4+ t cells (figure 4c).
in stark contrast to fv infection, ad5.pix-gp70 immunization induced very little il21 or il10 expression in either wt or bcl6-deleted env-specific cd4+ t cells (figure 4c).
moreover, bcl6 deletion induced a more modest gain in ifng-expressing cells (1.5-fold) after ad5.pix-gp70 priming than after fv priming (figure 4c).
collectively, these data argued that bcl6 suppressed specifically ctl differentiation of env-specific cd4+ t cells during ad5.pix-gp70 priming.
cd4+ ctl and th1 cells are transcriptionally distinct gzmb expression is often considered a part of the th1 program of cd4+ t cell differentiation.
indeed, some of the genes, such as slamf1 (encoding cd150), whose expression characterized gzmb+ cells (figures 2d and 2e), are also used to distinguish th1 from tfh cells (crotty, 2014, vinuesa et al., 2016).
single-cell transcriptional analysis revealed that, independently of priming virus or bcl6 sufficiency, over half (57%) of gzmb+ cells co-expressed ifng (figure 5a).
similar results were obtained at the protein level (figure 5b), indicating a close relationship between gzmb and ifn-γ production.
however, the strong ifng expression in fv infection without concomitant gzmb expression, and the inverse during ad5.pix-gp70 immunization, particularly after loss of bcl6 (figures 3b, 4a, and 4c), suggested that the profiles of th1 cells and those that additionally display ctl potential may be separable, both qualitatively and quantitatively.
for example, although both th1 cells and th1 cells with ctl potential expressed cd150 (encoded by slamf1), a direct comparison of ifn-γ+ env-specific cd4+ t cells that co-produced gzmb (ifn-γ+gzmb+) with those that did not (ifn-γ+gzmb−) revealed significantly higher cd150 expression in the former (figure 5c).
to comprehensively explore potential transcriptional differences between th1 and ctl cd4+ t cells, we compared the transcriptional profiles of env-specific cd4+ t cells expressing ifng, but not gzmb (ifng+gzmb−), and those co-expressing ifng and gzmb (ifng+gzmb+).
we reasoned that restricting this comparison only to cells expressing ifng would minimize the effect of comparing mixed th functional subsets and emphasize differences correlating with gzmb production.
despite common ifng expression, the transcriptional profile of ifng+gzmb+ cells was readily distinguishable from that of ifng+gzmb− cells (figure 5d).
the transcriptional difference between ifng+gzmb+ and ifng+gzmb− cells remained significant when ad5.pix-gp70 priming was analyzed separately, whereas it narrowly lost significance when fv priming was analyzed in isolation due to the low number of gzmb+ cells induced by fv (figure s10).
moreover, ifng+gzmb+ and ifng+gzmb− cells remained transcriptionally significantly distinct when tfh cells were excluded from the analysis, either by virtue of cxcr5 expression or by limiting the analysis to bcl6-deleted cd4+ t cells, which cannot differentiate into tfh cells (figure s11).
importantly, the transcriptional differences between ifng+gzmb+ and ifng+gzmb- cells (figure 5d) largely overlapped with those characterizing the gzmb+ subset as a whole (figure 2d).
this was particularly evident in the opposing expression of prdm1 and tcf7.
indeed, whereas most ifng+gzmb− cells expressed tcf7 but not prdm1, most ifng+gzmb+ cells expressed prdm1 but not tcf7 (figure 5e), suggesting that the combination of these two markers was sufficient to distinguish between the th1 and cd4+ ctls.
to confirm the distinguishing pattern of prdm1 and tcf7 expression of gzmb+ cd4+ t cells, we used ef4.1 tcrβ-transgenic cd4+ t cells additionally carrying a gfp reporter into the prdm1 locus (kallies et al., 2009).
as gfp insertion disrupts the prdm1 gene in these mice (kallies et al., 2009), we used donors heterozygous for the prdm1gfp allele to prevent loss of function of the encoded blimp1 in the adoptively transferred cd4+ t cells.
following ad5.pix-gp70 immunization, a small proportion (∼8%) of donor env-specific effector cd4+ t cells displayed blimp1-gfp expression (figure 5f) and contained prdm1 transcripts (figure 5g).
notably, this fraction was also characterized by paucity of tcf7 and overabundance of gzmb transcripts, relative to the blimp1-gfp− fraction (figure 5g).
thus, loss of tcf7 expression and induction of prdm1 expression could differentiate gzmb+ cd4+ t cells from other th subsets, including th1 cells.
layered checkpoints in cd4+ ctl development our findings supported a role for bcl6 in restraining cd4+ ctl development, particularly of cd4+ t cells responding to ad5.pix-gp70 immunization (figures 3 and 4).
however, in response to fv infection, bcl6 ablation in env-specific cd4+ t cells failed to promote cd4+ ctl differentiation, despite elevated prdm1 expression (figure 3).
therefore, we hypothesized that additional layers of regulation were limiting cd4+ ctl differentiation specifically in fv infection.
to test this idea, we compared the expression of inhibitory receptors in env-specific cd4+ t cells primed by either fv or ad5.pix-gp70.
following fv infection, the majority (>65%) of gzmb− cells co-expressed pcdc1 (encoding pd-1), lag3, and ctla4 but completely lacked expression of havcr2 (encoding tim-3) (figure 6a).
by comparison, following ad5.pix-gp70 immunization, ctla4 expression was comparable in gzmb− cells, but expression of pcdc1 was reduced to 36%, and expression of lag3 was now largely absent (8%) (figure 6a).
notably, the difference in expression of inhibitory receptors between the two viruses was more pronounced in gzmb+ cells, which, in the case of fv priming, co-expressed all four inhibitory receptors (figure 6a).
in contrast, gzmb+ cells primed by ad5.pix-gp70 lacked expression of pcdc1 and lag3 (figure 6a).
this difference between the two viruses in the induction of pcdc1 and lag3 expression was also confirmed at the pd-1 and lag3 protein level.
consistent with the rna expression data, pd-1 was expressed by nearly all env-specific cd4+ t cells, but at significantly higher levels in fv infection than in ad5.pix-gp70 immunization (figures 6b and 6c).
similarly, a much larger fraction of env-specific cd4+ t cells exhibited lag3 surface expression when primed by fv than by ad5.pix-gp70 (figure 6b), a difference that was also reflected in the intensity of lag3 staining of the entire population (figure 6c).
thus, gzmb+ cells displayed considerable expression of ctla4 and exclusive expression of havcr2, regardless of the priming virus.
indeed, havcr2 expression also distinguished ifng+gzmb+ cells from ifng+gzmb− cells (figure 5c).
in contrast, significant expression of both pcdc1 and lag3 was induced in gzmb+ env-specific cd4+ t cells uniquely by fv infection but not ad5.pix-gp70 immunization.
the pattern of inhibitory receptors expressed by fv-primed env-specific cd4+ t cells was suggestive of an exhausted phenotype (crawford et al., 2014), which was investigated further.
pd-1 expression was more consistent with antigen-induced activation of effector cd4+ t cells than with cellular exhaustion, as it was also induced by ad5.pix-gp70, albeit to a lower intensity per cell (figure 6c), and was also substantially reduced quickly after the peak of the effector response to fv infection (figure s12).
moreover, effector cd4+ t cells isolated from acute fv infection were transcriptionally distinct from typical exhausted cd4+ t cells isolated from chronic lymphocytic choriomeningitis virus (lcmv) infection (crawford et al., 2014; figure s13a), suggesting that expression of inhibitory receptors by fv-primed effector cd4+ t cells was part of acute effector differentiation rather than of the exhaustion that characterizes chronic viral infections.
nevertheless, expression of inhibitory receptors, particularly of pd-1 and lag3, by env-specific cd4+ t cells during acute fv infection could still influence cellular activation or ctl differentiation.
to this end, we treated wt recipients of env-specific cd4+ t cells with pd-1- and lag3-blocking antibodies during the course of fv infection.
although blockade of either pd-1 or lag3 separately had only a modest effect, the combined pd-1 and lag3 blockade significantly increased in the frequency of gzmb+ cells in donor cd4+ t cells (figure 6d; figure s14), supporting their role in restraining cd4+ ctl differentiation.
in contrast, the pd-1 and lag3 blockade did not appreciably alter clonal expansion of donor cd4+ t cells or their production of ifn-γ and tnf-α (figure s15).
the high levels of pd-1 expression in env-specific cd4+ t cells responding to fv infection were previously shown to require cognate interaction between t cells and b cells (ploquin et al., 2011).
therefore, we used b cell deficiency as an alternative to pd-1 blockade.
indeed, a significantly higher proportion of env-specific cd4+ t cells expressed intracellular gzmb when transferred into b cell-deficient ighm−/− hosts than into wt hosts (figure 6d).
these findings supported the premise that pd-1 and lag3 posed a further block in cd4+ ctl differentiation, in addition to bcl6 expression.
to test this premise directly, we combined bcl6 deficiency in env-specific cd4+ t cells with pd-1 and lag3 blockade.
as before (figure 4a), bcl6 deficiency alone did not significantly enhance cd4+ ctl differentiation during fv infection (figure 6d).
in contrast, the combination of bcl6 deficiency and pd-1 and lag3 blockade markedly increased the proportion of gzmb+ cells (∼3-fold) (figure 6d) to levels comparable with those induced by bcl6 deficiency in ad5.pix-gp70 immunization (figure 4b).
thus, pd-1 and lag3 were preventing bcl6-deficient env-specific cd4+ t cells from acquiring gzmb expression during fv infection, representing an additional level of cd4+ ctl differentiation control.
discussion since the earliest descriptions of mhc class-ii-restricted cytotoxic activity in cd4+ t cells nearly 4 decades ago, a number of studies have implicated cd4+ ctls in antiviral and antitumor immunity, as well as in autoimmune and inflammatory conditions (brown, 2010, brown et al., 2016, cheroutre and husain, 2013, soghoian and streeck, 2010, van de berg et al., 2008).
nevertheless, the priming requirements for cd4+ ctls or their phenotypic overlap with other cd4+ th subsets have only recently begun to emerge.
here, we described the transcriptional profile of cd4+ ctls as the antipode of the tfh profile.
we provided evidence to suggest multilayered control of cd4+ ctl differentiation: first, by the tcf-1–bcl6 nexus driving tfh polarization, and second, inhibition by pd-1 and lag3.
study of cd4+ ctls has been hampered by the lack of distinctive markers that are compatible with further characterization of these cells.
although mhc class-ii-restricted cytotoxic activity has been amply documented, it has not been consistently attributed to granzyme-mediated killing, as opposed to killing mediated by secreted or membrane-bound cytokines, including ifn-γ, expressed by th1 cells, or members of the tnf family, expressed by multiple cd4+ th cell subsets (brown et al., 2016, cheroutre and husain, 2013).
even when production of gzmb was used for the identification of cd4+ ctls, a certain degree of phenotypic overlap with th1 cells was noted (hua et al., 2013), and indeed, gzmb-producing cd4+ t cells are still regarded in the literature as a variant of the th1 subset.
this view is further supported by a potential developmental connection between cd4+ ctls and th1 cells (cheroutre and husain, 2013).
indeed, gzmb-producing cells often also express typical th1 products, including ifn-γ.
cd4+ ctl differentiation, particularly in response to interleukin-2 (il-2) and ifn-α stimulation, has also been suggested to rely on the th1-related transcription factor t-bet (encoded by the tbx21 gene), which can bind directly to the gzmb promoter (hua et al., 2013).
however, cd4+ ctl differentiation has been reported in other studies to depend not on t-bet but on its homolog eomesodermin (encoded by the eomes gene) (hirschhorn-cymerman et al., 2012, qui et al., 2011).
the differential dependency on either t-bet or eomesodermin may indicate that, depending on the priming conditions, cd4+ ctls can develop through separate developmental pathways, which may or may not overlap with the th1 differentiation pathway.
using a single-cell rna-sequencing approach, we were able to contrast the entire transcriptome of gzmb+ cd4+ t cells with that of other cd4+ t cells, without prior assumptions of their transcriptional overlap.
this approach did not support a correlation between expression of gzmb and expression of either tbx21 or eomes, suggesting a certain degree of redundancy.
it did, however, reveal a clear distinction between cd4+ t cells with ctl potential and th1 cells, exemplified in the reciprocal expression of tcf7 and prdm1.
although cd4+ ctls are more similar to the th1 than other th subsets, loss of tcf7 expression and concomitant gain of prdm1 expression in cd4+ ctls set them apart from all other th subsets, including th1 cells.
equally unique was the expression of havcr2 (encoding tim-3), which was found exclusively in cd4+ ctls.
although our results uncover prominent transcriptional differences between cd4+ ctls and th1 cells, they do not currently inform on any lineage or precursor-product relationship between the two.
cd4+ ctls may represent an advanced or divergent state of th1 differentiation, characterized by loss of tcf7 and acquisition of runx3 and prdm1 expression.
the markers reported here that distinguish cd4+ t cells with ctl potential from th1 cells will be valuable in determining the transcriptional and phenotypic stability of cd4+ ctls, or interconversion to a th1 phenotype, in longitudinal cell-fate studies.
another defining characteristic of cd4+ ctls that distinguishes them from other th subsets is the acquisition of cd8+ lineage-related features.
our analysis confirmed the relative loss of zbtb7b expression (encoding thpok) and acquisition of runx3 expression, considered responsible for the reprogramming of cd4+ ctls (mucida et al., 2013, reis et al., 2013).
however, despite acquiring runx3 expression under the conditions we have examined, cd4+ ctls did not express other cd8+ lineage-related genes, such as cd8a or crtam, previously observed in cd4+ ctls in other conditions (mucida et al., 2013, reis et al., 2013, takeuchi et al., 2016).
it is possible that acquisition of cd8+ lineage-related characteristics is not as extensive in splenic cd4+ ctls as in intestine intraepithelial cd4+ ctls.
it is also possible that further reprogramming of cd4+ ctls requires longer antigenic stimulation than the 7 days we have examined here.
our ability to contrast the global transcriptional profile of gzmb+ cd4+ t cells against that of other cd4+ t cells revealed a principal feature of cd4+ ctl differentiation; namely, antagonism by the tfh program.
indeed, loss of tcf7 and lef1 expression distinguished cd4+ ctl from other cd4+ t cell subsets, including ifng+ th1 cells.
tcf-1 (encoded by tcf7) and its homolog, lef-1, have been recently demonstrated to coordinate tfh differentiation partly by enhancing bcl6 expression during lcmv infection (choi et al., 2015, wu et al., 2015, xu et al., 2015).
interestingly, tcf7 and lef1 gene deletion in cd4+ t cells in two of these studies promoted transcriptional features of th1 cells, as well as of cd4+ ctls, including gzmb expression (choi et al., 2015, xu et al., 2015).
the acquisition of ctl-related characteristics by tcf7-deficient cd4+ t cells in these population studies was interpreted as part of enhanced th1 responses (choi et al., 2015, xu et al., 2015).
our single-cell analysis clearly demonstrated that the blocking of tfh differentiation can promote th1 and ctl differentiation of distinct cells.
not only were th1 cells and cd4+ ctls transcriptionally separable, but they were also induced to different degrees in response to different infections.
this was exemplified by retroviral infection, where bcl6 deficiency promoted th1, but not ctl, differentiation of cd4+ t cells and adenoviral vaccination, where bcl6 deficiency unleashed specifically ctl differentiation.
antagonism between the tfh and cd4+ ctl programs is also supported by the contrasting expression of blimp1 (encoded by prdm1).
blimp1 suppresses both bcl6 and tcf7 expression and is, in turn, negatively regulated by bcl6 and tcf-1 (choi et al., 2015, wu et al., 2015, xu et al., 2015).
previous studies demonstrated defective gzmb expression by blimp1-deficient cd4+ t cells, whereas blimp1 overexpression enhances cd4+ ctl differentiation (gong and malek, 2007, hua et al., 2013).
these studies suggest that cd4+ ctl differentiation requires blimp1, which is thought to enhance t-bet binding to the promoters of ctl-related genes, including gzmb (gong and malek, 2007, hua et al., 2013).
although blimp1 expression, in combination with loss of tcf-1, was shown here to be a unique characteristic of cd4+ ctls, blimp1 can also be expressed highly by other th subsets, and its expression alone is not sufficient to drive cd4+ ctl development in our experimental systems.
for example, bcl6 deficiency induced significantly elevated expression of both prdm1 and tbx21 in cd4+ t cells responding to fv infection, but it did not enhance ctl differentiation, arguing that blimp1 may be necessary, but not sufficient, to drive the ctl program in cd4+ t cells.
retroviral infection was particularly ineffective at inducing ctl differentiation in responding cd4+ t cells.
this apparent defect was also observed when tfh differentiation was precluded by deletion of bcl6, suggesting additional blocks in cd4+ ctl differentiation.
our present findings add the dimension of intrinsic regulation of cd4+ ctl differentiation by the inhibitory receptors pd-1 and lag3, induced in response, specifically, to retroviral infection.
these receptors represented an additional layer of regulation, which prevented bcl6-deficient cd4+ t cells acquiring ctl characteristics.
indeed, cd4+ ctl differentiation in fv infection required the combination of bcl6 deletion and pd-1 and lag3 blockade.
in addition to pd-1 and lag3, cd4+ ctls were also characterized by expression of the inhibitory receptor tim-3 (encoded by havcr2), which was, in fact, entirely restricted to gzmb+ cells.
the precise cause of the highly elevated expression of inhibitory receptors in virus-specific effector cd4+ t cells, particularly, in cd4+ ctls, specifically in response to retroviral infection, remains poorly understood.
notably, gzmb production has been previously detected in cd4+ t cells responding to fv or fv-induced fbl-3 cells, when treg cells and cd8+ t cells were depleted (akhmetzyanova et al., 2013, manzke et al., 2013), suggesting extrinsic regulation.
these data imply that both extrinsic regulation, in the form of treg cells, and intrinsic regulation, in the form of inhibitory receptors in effector t cells, are effectively exploited by retroviruses.
although incompletely understood, the induction of inhibitory receptors in virus-specific cd4+ t cells during fv infection requires cognate interaction with b cells (ploquin et al., 2011).
expression of pd-1 in virus-specific cd4+ t cells, for example, is significantly reduced in the absence of b cell antigen presentation during fv infection (ploquin et al., 2011) or endogenous antigen expression (han et al., 2010).
in keeping with these observations, b cell deficiency also enhanced cd4+ ctl differentiation in this study.
these findings are entirely consistent with a critical role for b cells in deciding the balance between tfh and ctl differentiation of interacting cd4+ t cells.
b cells play a well-described role in stabilizing the tfh program (crotty, 2014, vinuesa et al., 2016), and, together with inducing pd-1 expression in cd4+ t cells, they inhibit cd4+ ctl differentiation.
such a role for b cells would ensure efficient antibody production at the expense of cd4+ t cell-mediated immunity.
indeed, b cells inhibit antibody-independent cd4+ t cell-mediated protection against tumors (qin et al., 1998) or fv-induced erythroblastosis (pike et al., 2009).
a critical influence of the type of antigen-presenting cell on tfh and ctl differentiation may also underlie the difference in the efficiency with which distinct viruses or viral vaccines elicit either tfh or cd4+ ctls.
elucidation of the role of distinct antigen-presenting cell types in this process may hold the key to both understanding and controlling the balance between tfh and cd4+ ctls.
overall, using single-cell analysis, our study revealed the transcriptional signature of gzmb-expressing cd4+ t cells.
their unique transcriptional features not only support the notion of a distinguishable cd4+ ctl subset but also provide markers for future identification and further longitudinal study of cd4+ ctls.
additionally, regulation of the cd4+ ctl program by the tcf-1-bcl6 axis, b cells, and inhibitory receptors, offers a means for manipulating the cytotoxic activity of cd4+ t cells in health and disease.
experimental procedures mice inbred b6 and cd45.1+ congenic b6 (b6.sjl-ptprca pep3b/boyj) mice, tcrβ-transgenic ef4.1 mice (antunes et al., 2008), tcrαβ doubly transgenic evα2 mice (merkenschlager et al., 2016), rag1-deficient (rag1−/−) mice (mombaerts et al., 1992), b cell-receptor-deficient (ighm−/−) mice (kitamura et al., 1991), mice with an activatable yfp gene targeted into the gt(rosa)26sor (r26) locus (srinivas et al., 2001), mice with a targeted insertion of cre recombinase into the tnfrsf4 locus (klinger et al., 2009) (tnfrsf4cre), mice with a conditional bcl6 allele (kaji et al., 2012) (bcl6fl), endogenous ecotropic murine-leukemia-virus-deficient (emv2−/−) mice (young et al., 2012), mice with a targeted insertion of gfp into the prdm1 locus (kallies et al., 2009) (blimp1-gpf), and mice with a targeted insertion of tdtomato fluorescent protein into the gzmb locus (mouchacca et al., 2013) (gzmb-tdtomato) were all on the b6 genetic background and were maintained at the francis crick institute’s animal facilities.
all animal experiments were approved by the ethical committee of the francis crick institute and were conducted according to local guidelines and uk home office regulations under the animals (scientific procedures act) 1986 (aspa).
retroviral infection and immunization details of infections, immunizations, and other in vivo treatments can be found in the supplemental information.
t cell purification, adoptive transfer, and recovery single-cell suspensions were prepared from the spleens and lymph nodes of donor cd45.1+ or cd45.2+ ef4.1 mice or cd45.2+ evα2 mice, and cd4+ t cells were enriched using immunomagnetic positive selection (stemcell technologies) at >90% purity.
a total of 1 × 106 ef4.1 cd4+ t cells or 1 × 105 evα2 cd4+ t cells was injected into cd45.1+cd45.2+ recipients via the tail vein.
env-reactive donor cd4+ t cells were purified (>98% purity) from the spleens of recipient mice by cell sorting, performed on moflo cell sorters (dako-cytomation).
flow cytometry single-cell suspensions were stained with directly conjugated antibodies to surface markers obtained from ebiosciences, caltag/invitrogen, bd biosciences, or biolegend.
for intracellular detection of gzmb, spleen cell suspensions were stimulated for 4 hr with phorbol 14,13 dybutirate (pdbu) and ionomycin (both at 500 ng/ml), in the presence of monensin (2 μg/ml).
cells were then stained for surface antigen and washed; after this step, they were fixed and permeabilized using an anti-mouse/rat foxp3 staining kit (ebioscience), according to the manufacturer’s instructions.
after an additional wash step, cells were stained for intracellular gzmb with alexa fluor 647- or fitc (fluorescein isothiocyanate)-conjugated anti-human/mouse gzmb antibodies (clone gb11, biolegend) and phycoerythrin (pe)-conjugated anti-mouse ifn-γ antibodies (clone xmg1.2, ebioscience).
multi-color cytometry was performed on canto ii or lsrfortessa x-20 flow cytometers (both from bd biosciences) and analyzed with flowjo v10 (tree star).
cytotoxicity assays details of in vitro and in vivo cytotoxicity assays can be found in the supplemental information.
pcr-based expression profiling expression of selected genes was quantified in env-reactive cd4+ t cells by real-time qrt-pcr.
the indicated cd4+ t cell populations were purified by cell sorting, and rna was isolated using the qiacube (qiagen).
synthesis of cdna was carried out with the high capacity reverse transcription kit (applied biosystems) with an added rnase inhibitor (promega biosciences).
a final clean-up was performed with the qiaquick pcr purification kit (qiagen).
purified cdna was then used as template for the quantitation of the indicated genes using gene-specific primers (eurofins mwg operon) (table s2).
values were normalized and plotted according to the expression of hprt in the same samples, using a δct method.
single-cell rna sequencing env-reactive cd4+ t cells from the indicated recipient mice were purified by cell sorting.
a detailed description of subsequent single-cell rna sequencing can be found in the supplemental information.
statistical analyses statistical comparisons were made using sigmaplot 12.0 (systat software).
parametric comparisons of normally distributed values that satisfied the variance criteria were made by unpaired student’s t tests or one-way anovas.
data that did not pass the variance test were compared with non-parametric two-tailed mann-whitney rank sum tests or anova on ranks tests.
hierarchical clustering and heatmap production was performed with qlucore omics explorer (qlucore).
author contributions conceptualization, g.k.; methodology and formal analysis, g.r.y.
; investigation, t.d., j.m., u.e., and n.b.
; resources, w.b., u.d., n.b., v.t.k.l-t., m.t., s.l.n., and c.b.
; funding acquisition, g.k.; supervision, g.k.; writing – original draft, t.d., g.r.y., and g.k.; writing – review & editing, g.k.
@highlight
summary cd4+ t cells develop distinct and often contrasting helper, regulatory, or cytotoxic activities.
typically a property of cd8+ t cells, granzyme-mediated cytotoxic t cell (ctl) potential is also exerted by cd4+ t cells.
however, the conditions that induce cd4+ ctls are not entirely understood.
using single-cell transcriptional profiling, we uncover a unique signature of granzyme b (gzmb)+ cd4+ ctls, which distinguishes them from other cd4+ t helper (th) cells, including th1 cells, and strongly contrasts with the follicular helper t (tfh) cell signature.
the balance between cd4+ ctl and tfh differentiation heavily depends on the class of infecting virus and is jointly regulated by the tfh-related transcription factors bcl6 and tcf7 (encoding tcf-1) and by the expression of the inhibitory receptors pd-1 and lag3.
this unique profile of cd4+ ctls offers targets for their study, and its antagonism by the tfh program separates cd4+ t cells with either helper or killer functions.
