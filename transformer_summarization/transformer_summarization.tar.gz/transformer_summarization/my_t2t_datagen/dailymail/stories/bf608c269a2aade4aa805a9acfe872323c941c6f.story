i. introduction large granular lymphocyte leukemias (lgll) are chronic clonal lymphoproliferations of mature post-thymic tcrαβ+ cd3+cd4−cd5dimcd8+cd27−cd28− cd45ro−cd57+ t cells (t-lgll, 85% of cases) or cd3− cd56+ natural killer cells (nk-lgll) [1–5].
t-lgll usually affects old subjects (> 60 years) with an indolent course and a median overall survival > 10 years [1,5].
at diagnosis, t-lgll patients show peripheral blood (pb) cytopenias, splenomegaly, bone marrow (bm) infiltration by clonal large granular lymphocytes (lgls), frequently associated with autoimmune or hematologic disorders (40% of cases) (table 1) [1,3,5].
current guidelines of t-lgll suggest to start treatment only in patients with symptomatic or life-threatening cytopenias (table 2) [3,4].
immunosuppressive therapy (ist), with single agent methotrexate (mtx), cyclophosphamide (ctx), or cyclosporin-a (cya), is the first-line therapy of t-lgll.
overall response rate with ist ranges from 40% to 70%, but no standard treatments are clearly defined due to the lack of prospective studies [3–5].
relapsed patients after ist stop or tapering, as defined in table 3, are eligible for a second course of immunosuppression with similar or different ist [6].
in t-lgll patients with ist failure after 4 months, a switch to a second-line treatment is recommended [5,7].
bendamustine is an alkylating agent that may act as a purine analogue, but the precise mechanism of action is still unclear [8].
this drug is largely used in b-cell non-hodgkin lymphoma (nhl), but recent studies have focused on refractory/relapsed t cell neoplasm patients, suggesting a role of this drug also in t-cell nhl [9–10].
here, we report two cases of elderly refractory t-lgll patients who achieved a prolonged complete remission using bendamustine as salvage therapy.
ii.
patients and methods in this study, two t-lgll patients were enrolled after informed consent in accordance with the declaration of helsinki [11] and the institutional review boards of the hematology and transplant center, department of medicine and surgery, university of salerno, italy.
the authors retrospectively reviewed all available medical records.
iii.
results case 1 a 73-year-old woman received diagnosis of t-lgll in 2003 from other institution.
treatment with low-dose oral mtx, (10 mg/m2 weekly) and prednisone (pdn) was started in 2008, due to anemia and moderate thrombocytopenia.
after a 4-month therapy, in the absence of a clinical response, oral ctx (100 mg/day) and pdn for 4 months were used as second-line treatment without any response, although this therapy was associated with erythropoiesis-stimulating agents (esas).
in august 2012, the patient referred to our institution for fatigue, transfusion-dependent severe anemia and neutropenia.
the basic clinical characteristics, laboratory data on admission and clinical records of the patient are detailed in table 4. in september 2012, oral cya, (2 mg/kg/day) and pdn were administered as third-line therapy, but the patient experienced the worsening of cytopenias, the increase in the transfusion support (8–10 packed red blood cell transfusions/month), and positivity of indirect and direct antiglobulin tests.
after 8 months of no clinical response, the patient performed a salvage therapy with bendamustine (70 mg/m2 for 2 consecutive days every 28 days).
pneumocystis jiroveci prophylaxis was carried out with trimethoprim/sulfamethoxazole (tmp/smx), while esas were administered to improve erythropoiesis.
after the first bendamustine course, our patient experienced a rapid hemoglobin improvement and transfusion independence, achieving complete remission (cr) within three months.
grade 4 neutropenia was documented after the second course of chemotherapy and treated with granulocyte colony-stimulating factors (g-csfs).
the patient experienced also other complications such as escherichia coli-related urinary tract infection (treated with 500 mg/day oral levofloxacin for 6 days) and hypertransaminasemia associated with vasculitis-like rush of the limbs after the third cycle, which led to the treatment discontinuation and patient re-evaluation.
given that the patient was in cr and showed a minimal bm infiltration (lgls <10% of total cellularity), bendamustine was definitely discontinued.
cr was maintained for 20 months, when the patient showed again anemia; for this reason, a second course of 4 cycles of bendamustine was administered, without any clinical toxicity.
at last follow-up, 12 months after the end of therapy, the patient was still in cr.
case 2 a 72-year-old man was admitted to our department in october 2013 for severe anemia associated with atypical circulating and marrow lgls (figure 1a).
physical examination did not detected lymphadenopathies and hepatomegaly, but revealed splenomegaly, confirmed by ultrasonography (longitudinal diameter, 150 mm; anteroposterior diameter, 156 mm; transverse diameter, 66 mm).
other clinical characteristics, laboratory data on admission and clinical records of the patient are summarized in table 4. immunosuppression was started with cya (5 mg/kg/day) and pdn (0.5 mg/kg/day).
after a 4-month therapy, the persistence of transfusion-dependent anemia and the worsening of neutropenia (0.29 × 109 cells/l) required a second line therapy.
bendamustine was administrated for a total of 6 cycles at 70 mg/m2 for 2 days every 28 days.
bacterial, fungal and pneumocystis jiroveci prophylaxis was carried out using oral levofloxacin (500 mg/day), oral fluconazole (200 mg/day), and tmp/smx (160–800 mg/twice per week).
esas and g-csfs were also administered to reduce myelosuppression and to prevent febrile neutropenia.
grade 3 neutropenia and two episodes of transient hypertransaminasemia with indirect hyperbilirubinemia were documented, but they did not require drug discontinuation.
cr was achieved after 6 cycles of bendamustine and, after that, the patient no longer needed transfusions or esas administration (figure 1b).
bm aspiration performed at the end of treatment did not show evidence of lymphoproliferative disorder, confirmed by bm flow cytometry immunophenotype and bm biopsy.
after 26-month of follow-up, the patient was still in cr.
iv.
discussion t-lgll is a chronic lymphoproliferative disorder with an indolent course, mostly diagnosed after the sixtieth decade of life1.
t-lgll patients are a fragile population because of their older age (>60-year-old), the presence of comorbidities (frequently autoimmune disorders) and symptoms which negatively influence the quality of life and the outcome [12,13].
nowadays, there are no “curative” therapeutic options for t-lgll.
for this reason, the goals are the stabilization of the disease and the correction of cytopenias.
ist is the mainstay of treatment for t-lgll [3,5], but the optimal therapeutic strategy for refractory/relapsed patients is still challenging, even though purine analogues and alemtuzumab are currently used as second-line therapy4.
bendamustine, a molecule developed more than 50 years ago, is an alkylating agent with a complex mechanism of action, sharing characteristics with purine analogues [8,11].
several mechanisms of action have been hypothesized, as the induction of extensive and durable dna damage and impairment of dna repair [8].
the inhibition of the dna repair mechanism could be enhanced by the in vitro combination of bendamustine with cladribine or fludarabine, commonly used for b-cell and t-cell nhl [8,14].
bendamustine can induce apoptosis through traditional and non-traditional pathways [8].
in particular, the activation of mitotic catastrophe is caspase-2-dependent and cannot be inhibited by overexpression of bcl-2 [8].
moreover, the p53-dependent dna-damage response pathways can be activated not only by bendamustine-induced dna interstrand crosslinks, but also by oxidative stress and increased release of apoptosis-inducing factor from mitochondria [8].
based on the interesting results of zaja et al.
in 2013 in a small cohort of t-cell nhl refractory/relapsed patients, we decided to start bendamustine administration in two cases of refractory t-lgll patients, according to the dosage previously reported [9].
furthermore, bendamustine was chosen as salvage therapy due to its mechanism of action, hypothesizing that the mitotic catastrophe could avoid the constitutively activated anti-apoptotic pathways in lgls [8].
indeed, our series of refractory t-lgll patients experienced a rapid clinical response and achieved the cr within 3 and 6 months, respectively.
one patient relapsed after 20 months of cr with a minimal bm lgl infiltration.
interestingly, she was still responsive to a second course of bendamustine which allowed a 12-months disease-free survival at the time of writing.
moreover, bendamustine was confirmed as a drug with a good safety profile [14], because the myelosuppression was easily managed with g-csfs and esas.
v. conclusion standard salvage treatment for relapsed/refractory t-lgll patients has not been defined yet due to the lack of prospective studies.
bendamustine-based regimens are increasingly used in both b-cell and t cell neoplasms, but few studies are available for t-lgll.
our case series shows the efficacy and safety of bendamustine in the treatment of elderly relapsed/refractory t-lgll patients.
even though these results require further validation in prospective randomized studies, bendamustine as single agent or in combination should be considered a feasible second-line option for relapsed or refractory t-lgll.
@highlight
t-large granular lymphocyte leukemia (t-lgll) is a chronic clonal proliferation of effector memory cytotoxic cd3+cd57+cd56− t cells and the current guidelines suggest immunosuppressive therapy as first-line therapy, but the treatment of refractory/relapsed patients is still challenging due to the lack of prospective studies.
we describe a series of two refractory/relapsed t-lgll patients successfully treated with bendamustine, a chemotherapeutic agent largely used for b-cell neoplasms, but poorly investigated for the treatment of t-cell diseases.
complete remission (cr) was achieved in 3 and 6 months, respectively, and maintained for at least 20 months.
one patient relapsed after a 20-month cr, but she was responsive to bendamustine therapy again, obtaining a further prolonged cr.
bendamustine as single agent or in combination could be a feasible therapeutic option in refractory/relapsed t-lgll, especially for elderly patients because of its safety profile.
