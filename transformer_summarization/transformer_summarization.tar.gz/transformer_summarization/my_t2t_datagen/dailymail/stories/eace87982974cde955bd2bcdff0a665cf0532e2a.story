introduction metabolic syndrome (mets) is defined by the clustering of several cardiovascular risk factors, including hypertension, hyperglycemia, dyslipidemia and visceral obesity (1).
mets is associated with cardiovascular disease, which is the leading cause of mortality and morbidity (2).
thus, an early identification of individuals at high risk for mets would help prevent the associated cardiovascular complications.
in japan, the prevalence of mets according to a joint interim statement has been reported to range from 18.5-37.3% in men and from 4.4-12.8% in women (3,4), and it may have recently become even more common with the continuous increase in obesity prevalence.
hypernatremia is associated with an increased mortality, especially in subjects with various comorbid conditions such as congestive heart failure (5,6) and chronic kidney disease (7,8).
moreover, a recent study has revealed that the increase of serum sodium (na+) in the normal range is also associated with the mortality in general populations (9).
in addition, hypochloremia is associated with a risk of mortality in subjects with hypertension (10).
to the best of our knowledge, however, the relationship between mets and serum na+ and chloride (cl-) concentrations in general populations remains to be elucidated.
therefore, we compared serum na+, serum cl- and the sodium-chloride difference (na+-cl-) in subjects with and without mets and investigated the relationship between serum na+, serum cl- or na+-cl- and clinical and biochemical metabolic parameters in both cross-sectional and longitudinal studies.
materials and methods design of study the oike health survey is an ongoing cohort investigation of risk factors for chronic diseases, including hypertension, diabetes and chronic kidney disease.
the oike clinic (kyoto, japan) provides regular health check-ups for employees of various companies.
the purpose of the medical health check-up program and the detailed characteristics of the participants were described previously (11).
briefly, in japan, yearly routine examinations for employees are legally mandated and all or most of the costs for the health check-ups are generally paid by their employers.
approval for the study was obtained from the ethical committee of oike clinic, and the study was conducted in accordance with the declaration of helsinki.
for this type of study, formal consent was not required.
informed consent was obtained from all individual subjects included in the study.
cross-sectional study in 2001, 4,127 japanese subjects, who did not have a history of cardiovascular disease (myocardial infarction, coronary revascularization or stroke), malignant disease, liver cirrhosis or hematologic disease, were enrolled in this cross-sectional study.
we excluded 252 subjects because of missing data of covariates.
thus, 3,875 subjects were eligible for the cross-sectional study.
first, we compared serum na+, serum cl- or na+-cl- between subjects with and without mets.
second, we evaluated the relationship between serum na+, serum cl- or na+-cl- and clinical and biochemical metabolic parameters.
then, we investigated whether na+-cl- was associated with the presence of mets in the cross-sectional study.
longitudinal study in this retrospective longitudinal study, we excluded 521 subjects who had mets at the baseline examination.
in addition, 2 subjects were excluded because of missing data of covariates at the follow-up study.
thus, 3,352 subjects were eligible for the longitudinal study and included in an 8-year follow-up study.
we investigated whether na+-cl- was associated with the development of mets in the longitudinal study.
data collection and measurements all subjects provided details of their demographics.
the body mass index (bmi) was calculated as weight in kilograms divided by height in meters squared.
smoking was defined as current tobacco usage.
habit of alcohol was defined as daily alcohol consumption.
habit of exercise was defined as performing any kind of sports at least once a week.
after an overnight fast, venous blood was collected for the measurement of the levels of various factors, including fasting plasma glucose, total cholesterol, triglycerides, high-density lipoprotein (hdl) cholesterol, creatinine, uric acid, serum na+, serum cl- and serum potassium.
the glomerular filtration rate (gfr) was estimated using the japanese society of nephrology equation as follows: estimated gfr (egfr) = 194 × cre–1.094 × age–0.287 (ml/min/1.73 m2) (12).
for women, the egfr was multiplied by a correction factor of 0.739. definition of metabolic syndrome the diagnosis of mets was determined according to a joint interim statement of the international diabetes federation task force on epidemiology and prevention; the national heart, lung and blood institute; the american heart association; the world heart federation; the international atherosclerosis society; and the international association for the study of obesity, using the criteria for asians (13).
the subjects were diagnosed with the presence of mets when three or more of the following criteria were present: elevated blood pressure (systolic blood pressure ≥130 mmhg and diastolic blood pressure ≥85 mmhg and/or medication for hypertension, in both sexes); hyperglycemia (fasting plasma glucose ≥5.6 mmol/l and/or medication for diabetes, in both sexes); hypertriglyceridemia (serum triglycerides ≥1.70 mmol/l and/or medication for dyslipidemia, in both sexes); low hdl cholesterol levels (serum hdl cholesterol <1.03 mmol/l in men and <1.29 mmol/l in women); and abdominal obesity (waist circumference ≥90 cm in men and ≥80 cm in women).
because waist measurements were not available for the entire study sample, we substituted a bmi of ≥25 kg/m2, which has been proposed as a cut-off value for the diagnosis of obesity in asian people (14), for all subjects as an index of obesity.
the validity of this definition was confirmed previously (15).
statistical analysis statistical analyses were performed using the jmp version 10.0 software program (sas institute, cary, usa), and a p value <0.05 was considered to be statistically signiﬁcant.
the mean or frequencies of potential confounding variables were calculated.
categorical variables are expressed as numbers.
continuous variables are presented as the mean ± standard deviation (sd).
the unpaired student's t-tests or χ2 tests were conducted to assess the statistical signiﬁcance of differences between subjects with and without mets.
the association among na+, cl-, na+-cl- and metabolic parameters was analyzed by pearson's correlation coefficient.
the association between na+-cl- and the presence or development of mets was analyzed by logistic regression analyses.
the logistic regression analyses were adjusted for age, sex, the bmi, systolic blood pressure, fasting plasma glucose, triglycerides, hdl cholesterol, creatinine, uric acid and lifestyle factors, such as smoking status, habit of alcohol and habit of exercise.
odds ratio (or) and 95% confidence interval (ci) were calculated.
in addition, we used the diagnosis of mets determined by the japanese society of internal medicine (16) and performed logistic regression analyses in the cohort study.
results characteristics of study subjects the baseline characteristics are shown in table 1. there were 3,354 subjects without mets and 521 subjects with mets.
age, the bmi, systolic blood pressure, diastolic blood pressure, fasting plasma glucose, total cholesterol, triglycerides, uric acid, serum na+ and na+-cl- were higher in subjects with mets than those in subjects without mets.
on the other hand, hdl cholesterol, the egfr, serum cl- and serum potassium were lower in subjects with mets than those in subjects without mets.
correlations between serum na+, serum cl- or na+-cl- and clinical and biochemical metabolic parameters are shown in table 2. na+-cl- was associated with components of mets, including the bmi, blood pressure, fasting plasma glucose, triglycerides and hdl-cholesterol.
on the other hand, serum na+ was not associated with fasting plasma glucose or triglycerides, and serum cl- was not associated with the bmi or hdl-cholesterol.
in addition, relationships were observed between serum na+ and serum cl- (r=0.327, p<0.0001), serum na+ and na+-cl- (r=0.483, p<0.0001) and serum cl- and na+-cl- (r=-0.669, p<0.0001).
table 1. clinical characteristics of subjects at baseline examination.
subjects without mets subjects with mets p n 3,354 521 - age (years) 47.2 ± 9.9 52.5 ± 9.3 < 0.0001 sex (male/female) 1,850/1,504 412/109 < 0.0001 body mass index (kg/m2) 22.0 ± 2.7 25.9 ± 3.0 < 0.0001 systolic blood pressure (mmhg) 115.4 ± 16.3 133.2 ± 15.8 < 0.0001 diastolic blood pressure (mmhg) 69.5 ± 10.7 80.5 ± 10.2 < 0.0001 fasting plasma glucose (mmol/l) 5.0 ± 0.7 6.2 ± 1.7 < 0.0001 total cholesterol (mmol/l) 5.4 ± 0.9 5.7 ± 0.9 < 0.0001 triglycerides (mmol/l) 1.1 ± 0.8 2.3 ± 1.5 < 0.0001 hdl cholesterol (mmol/l) 1.6 ± 0.4 1.3 ± 0.3 < 0.0001 creatinine (umol/l) 72.1 ± 14.2 77.3 ± 14.1 < 0.0001 egfr (ml/min/1.73m2) 73.1 ± 12.9 70.4 ± 12.7 0.0040 uric acid (μmol/l) 307.4 ± 80.5 356.8 ± 82.5 < 0.0001 serum sodium (mmol/l) 142.2 ± 1.9 142.3 ± 2.0 0.0355 serum chloride (mmol/l) 101.8 ± 2.3 101.2 ± 2.4 < 0.0001 serum potassium (mmol/l) 3.9 ± 0.4 3.9 ± 0.4 0.0076 na+-cl- (mmol/l) 40.4 ± 2.5 41.1 ± 2.3 < 0.0001 smoking (-/+) 2,843/511 436/85 0.7275 habit of alcohol (-/+) 2,219/1,135 316/205 0.0074 habit of exercise (-/+) 1,449/1,905 202/319 0.0252 data are number of subjects or mean ± sd.
mets: metabolic syndrome, hdl: high-density lipoprotein, egfr: estimated glomerular filtration rate, na+-cl-: sodium-chloride difference.
unpaired student t tests or χ2 tests was conducted to assess the statistical significance of differences between subjects without mets and subjects with mets.
table 2. correlation between serum na+, serum cl- or na+-cl- and clinical and biochemical metabolic parameters.
na+ cl- na+-cl- r p r p r p age 0.136 < 0.0001 0.064 < 0.0001 0.047 0.0030 body mass index 0.075 < 0.0001 -0.028 0.0816 0.085 < 0.0001 systolic blood pressure 0.061 0.0001 -0.112 < 0.0001 0.151 < 0.0001 diastolic blood pressure 0.067 < 0.0001 -0.120 < 0.0001 0.163 < 0.0001 fasting plasma glucose -0.040 0.0123 -0.162 < 0.0001 0.118 < 0.0001 total cholesterol 0.037 0.0231 -0.144 < 0.0001 0.162 < 0.0001 triglycerides 0.020 0.2173 -0.132 < 0.0001 0.138 < 0.0001 hdl-cholesterol -0.114 < 0.0001 -0.008 0.6378 -0.083 < 0.0001 creatinine 0.179 < 0.0001 0.086 < 0.0001 0.221 < 0.0001 egfr -0.097 < 0.0001 -0.023 0.1584 -0.056 0.0005 uric acid 0.181 < 0.0001 -0.094 < 0.0001 0.229 < 0.0001 na+ - - 0.327 < 0.0001 0.483 < 0.0001 cl- - - - - -0.669 < 0.0001 na+: sodium, cl-: chloride, na+-cl-: sodium-chloride difference, hdl: high-density lipoprotein, egfr: estimated glomerular filtration rate presence of metabolic syndrome to investigate the association between serum na+, serum cl- or na+-cl- quartiles and the presence of mets, we performed logistic regression analyses (table 3).
in a multivariate approach, the highest na+ quartile (≥144 mmol/l) was associated with an increased risk of the presence of mets (multivariate or 1.34, 95% ci 1.01-1.78, p=0.0395) compared to the lowest na+ quartile (≤140 mmol/l), and the highest cl- quartile (≥104 mmol/l) was not associated with a decreased risk of the presence of mets (multivariate or 0.90, 95% ci 0.58-1.38, p=0.6172) compared to the lowest cl- quartile (≤99 mmol/l).
on the other hand, in a multivariate approach, the highest na+-cl- quartile (≥43 mmol/l) was associated with an increased risk of the presence of mets (multivariate or 1.81, 95% ci 1.17-2.84, p=0.0078) compared to the lowest na+-cl- quartile (≤38 mmol/l).
the or of na+-cl- was higher than that of na+ or cl-.
table 3. odds ratio of prevalence of mets according to quartiles of serum na+, serum cl- or na+-cl- level.
serum na+ (mmol/l) ≤ 140 141-142 143 ≥ 144 case/n 91/736 190/1,448 88/734 152/957 or or (95% ci) p or (95% ci) p or (95% ci) p unadjusted or 1 (reference) 1.39 (0.91-2.14) 0.1237 1.26 (0.79-2.04) 0.3387 1.82 (1.18-2.84) 0.0068 adjusted or* 1 (reference) 1.07 (0.82-1.40) 0.6163 0.97 (0.71-1.32) 0.8260 1.34 (1.01-1.78) 0.0395 serum cl- (mmol/l) ≤ 99 100-101 102-103 ≥104 case/n 120/630 1164/1,184 1150/1,238 187/823 or or (95% ci) p or (95% ci) p or (95% ci) p unadjusted or 1 (reference) 0.68 (0.53-0.89) 0.0042 0.59 (0.45-0.76) < 0.0001 0.50 (0.37-0.68) < 0.0001 adjusted or* 1 (reference) 0.83 (0.56-1.23) 0.3424 0.86 (0.59-1.29) 0.5005 0.90 (0.58-1.38) 0.6172 na+-cl- (mmol/l) ≤ 38 139-40 141-42 1≥ 43 case/n 62/772 1151/1,175 1156/1,143 1152/785 or or (95% ci) p or (95% ci) p or (95% ci) p unadjusted or 1 (reference) 1.69 (1.25-2.32) 0.0007 1.81 (1.34-2.49) 0.0001 2.76 (2.02-3.80) < 0.0001 adjusted or* 1 (reference) 1.34 (0.88-2.06) 0.1740 1.16 (0.76-1.78) 0.5064 1.81 (1.17-2.84) 0.0078 mets: metabolic syndrome, na+-cl-: sodium-chloride difference, or: odds ratio, ci: confidence interval.
*: adjusted for age, sex, body mass index, systolic blood pressure, fasting plasma glucose, triglycerides, high-density lipoprotein cholesterol, creatinine, uric acid and lifestyle factors such as smoking status, habit of alcohol and habit of exercise.
development of metabolic syndrome of the 3,352 subjects without mets at the baseline examination, 658 subjects were newly diagnosed with mets at the follow-up examination.
in a multivariate approach, the highest na+ quartile (≥144 mmol/l) was associated with an increased risk of the presence of mets (multivariate or 1.60, 95% ci 1.16-2.23, p=0.0045) compared to the lowest na+ quartile (≤140 mmol/l), and the highest cl- quartile (≥104 mmol/l) was not associated with a decreased risk of the presence of mets (multivariate or 0.74, 95% ci 0.53-1.03, p=0.0757) compared to the lowest cl- quartile (≤99 mmol/l).
on the other hand, in a multivariate approach, the highest na+-cl- quartile (≥43 mmol/l) was associated with an increased risk of the development of mets compared to the lowest na+-cl- quartile (≤38 mmol/l) after adjusting for covariates (multivariate or 1.76, 95% ci 1.27-2.45, p=0.0007) (table 4).
the or of na+-cl- was higher than that of na+ or cl-.
table 4. odds ratio of development of mets according to quartiles of serum na+, serum cl- or na+-cl- level.
serum na+ (mmol/l) ≤ 140 141-142 143 ≥144 case/n 91/645 244/1,257 135/646 188/805 or or (95% ci) p or (95% ci) p or (95% ci) p unadjusted or 1 (reference) 1.47 (1.13-1.91) 0.0035 1.61 (1.20-2.16) 0.0013 1.85 (1.41-2.45) < 0.0001 adjusted or* 1 (reference) 1.29 (0.95-1.77) 0.1075 1.33 (0.94-1.88) 0.1048 1.60 (1.16-2.23) 0.0045 serum cl- (mmol/l) ≤ 99 100-101 102-103 ≥104 case/n 122/509 216/1,020 202/1,088 118/736 or or (95% ci) p or (95% ci) p or (95% ci) p unadjusted or 1 (reference) 0.85 (0.66-1.10) 0.2172 0.72 (0.56-0.93) 0.0133 0.61 (0.46-0.80) 0.0005 adjusted or* 1 (reference) 0.97 (0.72-1.31) 0.8558 0.86 (0.64-1.16) 0.3156 0.74 (0.53-1.03) 0.0757 na+-cl- (mmol/l) ≤ 38 39-40 41-42 ≥ 43 case/n 98/709 180/1,024 204/987 176/632 or or (95% ci) p or (95% ci) p or (95% ci) p unadjusted or 1 (reference) 1.33 (1.02-1.74) 0.0339 1.63 (1.25-2.12) 0.0002 2.41 (1.83-3.18) < 0.0001 adjusted or* 1 (reference) 1.08 (0.79-1.48) 0.6198 1.16 (0.85-1.58) 0.3530 1.76 (1.27-2.45) 0.0007 mets: metabolic syndrome, na+-cl-: sodium-chloride difference, or: odds ratio, ci: confidence interval.
*: adjusted for age, sex, body mass index, systolic blood pressure, fasting plasma glucose, triglycerides, high-density lipoprotein cholesterol, creatinine, uric acid and lifestyle factors such as smoking status, habit of alcohol and habit of exercise.
development of metabolic syndrome according to the japanese society of internal medicine of the 3552 subjects without mets at the baseline examination, 157 subjects were newly diagnosed with mets at the follow-up examination.
in a multivariate approach, the highest na+-cl- quartile (≥43 mmol/l) was associated with an increased risk of the development of mets compared to the lowest na+-cl- quartile (≤38 mmol/l) after adjusting for covariates (multivariate or 1.93, 95% ci 1.06-3.63, p=0.0317) (table 5).
table 5. odds ratio of development of mets, determined by japanese society of internal medicine, according to quartiles of na+-cl- level.
na+-cl- (mmol/l) ≤ 38 39-40 41-42 ≥ 43 case/n 20/727 43/1,073 45/1,048 49/704 or or (95% ci) p or (95% ci) p or (95% ci) p unadjusted or 1 (reference) 1.48 (0.87-2.58) 0.1489 1.59 (0.94-2.77) 0.0837 2.64 (1.58-4.59) 0.0002 adjusted or* 1 (reference) 1.32 (0.73-2.47) 0.3578 1.23 (0.68-2.30) 0.4923 1.93 (1.06-3.63) 0.0317 mets: metabolic syndrome, na+-cl-: sodium-chloride difference, or: odds ratio, ci: confidence interval.
*: adjusted for age, sex, body mass index, systolic blood pressure, fasting plasma glucose, triglycerides, high-density lipoprotein cholesterol, creatinine, uric acid and lifestyle factors such as smoking status, habit of alcohol and habit of exercise.
discussion the major finding of our study is that na+-cl- is associated with the increased risk of the presence or development of mets after adjusting for other risk factors.
it has been reported that both hypernatremia (9) and hypochloremia (10) are associated with mortality.
to the best of our knowledge, this is the first study to investigate the association between na+-cl- and the presence or development of mets.
potential explanations for the associations between na+-cl- and mets are as follows.
the na+-cl- level equals the serum anion gap plus serum bicarbonate ion level (17).
the body's acid-base balance is tightly regulated, maintaining the arterial blood ph between 7.35 and 7.45. the serum anion gap increases when an unmeasured anion, such as endogenous acid production, increases (18,19).
the kidneys excrete an amount of acid equal to the production of endogenous acids and replenish the bicarbonate ion that is lost by neutralization of the endogenous acid production (20).
at the same time, na+ is absorbed via na+/proton exchanger and na+/bicarbonate ion cotransporter at the proximal convoluted tubule (20).
indeed, na+-cl- was correlated with urine ph (r=-0.066, p=0.0023) using spearman's rank order correlation method in this study.
moreover, recent studies have demonstrated that dietary acid load, which leads to increased endogenous acid production, is associated with a risk of type 2 diabetes (21,22).
in addition, an increased serum anion gap is associated with blood pressure (17), insulin resistance (19) and a chronic inflammation state (23) in general populations.
previous studies have revealed that a high anion gap and corresponding high serum na+ and low serum cl- are associated with higher blood pressure (17,18).
in fact, na+-cl- was closely associated with systolic blood pressure in the present study.
in addition, low serum cl- concentrations, especially <100 mmol/l, are associated with mortality in subjects with hypertension (10).
furthermore, higher na+-cl- is associated with the increased risk of mortality in subjects with hypertension (10).
taking these findings together, it seems plausible that na+-cl- is associated with mets.
the strengths of our study include the relatively large number of subjects both at baseline and at the follow-up.
however, there are some limitations associated with the present study.
first, we did not measure arterial ph, serum bicarbonate ion, serum albumin or partial pressure of carbon dioxide.
therefore, we are unable to assess fully the acid-base status of the subjects in this study.
second, the lack of waist circumference data make weakens the definition of mets.
however, several studies in japan have used a bmi ≥25 kg/m2 as a substitute for central obesity (15,24).
this value corresponds to a cut-off point for a visceral fat area of 100 cm2, regarded to be the gold standard for defining central obesity (25).
third, serum na+ and cl- might be variable and thus serum na+ and cl- should be measured several times.
unfortunately, however, we measured serum na+ and cl- only once at the baseline examination.
lastly, the study population consisted of japanese men and women, therefore, it is uncertain whether these findings are generalized in other ethnic groups.
in conclusion, we showed that na+-cl- is associated with the increased risk of mets in this study.
this finding suggests the diagnostic utility of na+-cl- as a provisional new risk marker for mets, which can be easily measured in the clinical laboratory and applied in medical practice.
na+-cl- could be an important marker for the presence or development of mets, however, interventional methods to decrease na+-cl- have not yet been established.
thus, subjects with high na+-cl might require aggressive lifestyle modifications and medication to lower blood glucose, triglycerides and blood pressure to prevent the development of mets.
author's disclosure of potential conflicts of interest (coi).
masahiro yamazaki: honoraria, astrazeneca plc.
naoto nakamura: honoraria, astrazeneca plc and ono pharmaceutical.
michiaki fukui: fees for promotional materials, astrazeneca plc., astellas pharma, nippon boehringer ingelheim, ltd., daiichi sankyo, eli lilly japan, kyowa hakko kirin company, kissei pharmaceutical, msd, mitsubishi tanabe pharma, novo nordisk pharma, sanwa kagaku kenkyusho, sanofi, ono pharmaceutical and takeda pharmaceutical.
mai asano: research funding, ono pharmaceutical.
@highlight
objective metabolic syndrome (mets) is associated with cardiovascular disease, which is the leading cause of mortality and morbidity.
hypernatremia and hypochloremia are also associated with an increased mortality.
thus, the aim of this study was to evaluate the association between the sodium-chloride difference (na+-cl-) and mets.
methods in this cross-sectional and retrospective cohort study, we enrolled 3,875 subjects and evaluated the relationship between na+-cl- and mets using logistic regression analyses.
mets was diagnosed according to the joint interim statement when a subject had three or more of the following criteria: hypertension; hyperglycemia; hypertriglyceridemia; low high-density lipoprotein (hdl) cholesterol; and abdominal obesity.
results there were 3,354 subjects without mets and 521 subjects with mets at baseline.
the highest na+-cl- quartile (≥43 mmol/l) was associated with an increased risk of the presence of mets compared to the lowest na+-cl- quartile (≤38 mmol/l) after adjusting for covariates, including age, sex, the body mass index, systolic blood pressure, fasting plasma glucose, triglycerides, hdl cholesterol, creatinine, uric acid and lifestyle factors [multivariate odds ratio (or) 1.81, 95% confidence interval (ci) 1.17-2.84, p=0.0078].
after an 8-year follow-up, 658 out of 3,352 subjects were newly diagnosed with mets.
the highest na+-cl- quartile (≥43 mmol/l) was associated with an increased risk of the development of mets compared to the lowest na+-cl- quartiles (≤38 mmol/l) after adjusting for covariates (multivariate or 1.76, 95% ci 1.27-2.45, p=0.0007).
conclusion the sodium and chloride difference is associated with mets.
