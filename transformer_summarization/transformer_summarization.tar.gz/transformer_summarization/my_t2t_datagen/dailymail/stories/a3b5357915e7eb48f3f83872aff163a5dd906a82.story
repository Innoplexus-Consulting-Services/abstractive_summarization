introduction the association between sleep and diabetes has attracted extensive attention in the last decade [1].
sleep duration has been the centre of the discussion, with several meta-analysis confirming a u-shaped relationship between sleep duration and risk of type 2 diabetes [2], [3].
more recently, a potential link between daytime napping and type 2 diabetes has been reported.
cross-sectional studies have suggested that napping was associated with an increased prevalence of diabetes or impaired fasting plasma glucose in chinese older adults [4], [5], and in white postmenopausal women [6].
this raises questions as to whether daytime napping could simply be a consequence of diabetes.
indeed, the health abc study showed earlier in 235 older adults that the odds of day napping, as recorded by wrist actigraphs, was five times higher in individuals with diabetes compared to those without [7].
as such, prospective study designs may help determine the nature of this relationship.
to date only two published prospective studies with diabetes as the primary outcome have attempted to address this issue.
one study concluded that day napping may be an independent risk factor for self-reported incident diabetes in an american population [8].
the association was modestly attenuated by adjustment for body mass index (bmi), and was stronger among those with short nighttime sleep durations.
a more recent study [9] found a non-significant association between frequent napping and incident type 2 diabetes in a middle-aged finnish population, after accounting for bmi.
these intriguing findings, particularly the joint effects of daytime and nighttime sleep and the influence of obesity need to be confirmed by larger prospective studies with validated ascertainment of diabetes cases, and with consideration of a wider range of anthropometric measures.
moreover, since daytime napping has a strong cultural implication, it is important to compare findings in different cultural settings.
we set out to study the prospective association between daytime napping and the risk of type 2 diabetes in a middle- to older-aged british population.
specifically this study aimed to test the role of anthropometric measures, and whether there is an interaction between daytime napping and sleep duration in relation to diabetes risk.
methods study population participants were drawn from the european prospective investigation of cancer-norfolk (epic-norfolk) cohort study, which is part of an ongoing multi-centre prospective cohort study [10].
details of the design of the study have been described previously [11].
briefly, a total of 25 639 men and women aged 40–74 years attended the baseline health check during 1993–1997, and were then followed up for two further health checks from 1996 to 2000 and from 2006 to 2011. in between these health examinations, participants were sent various questionnaires, which contained questions on sleep characteristics.
the norwich district ethics committee approved the study and all participants gave signed informed consent.
measures participants were asked to report their daytime napping habit during 1998–2000.
this information was collected through a yes-no question “do you normally take a nap during the day?” in addition, participants were asked “on average, how many hours do you sleep in a 24 h period?” with six response options: “<4, 4–6, 6–8, 8–10, 10–12 and >12”.
all covariates were chosen a-priori based on their relevance to sleep and diabetes [12], [13], [14].
socio-demographic information were obtained through the baseline health questionnaire, and included age, sex, educational (highest qualification attained: no qualifications, educated to age 16 years, educated to age 18 years, or educated to degree level), and marital status (single, married, widowed, separated, or divorced).
the follow up health questionnaire collected information on smoking status (current, former, or non-smokers), alcohol intake (units of alcohol drunk per week) and hypnotic drug use (yes/no).
physical activity levels was reported in four categories (inactive, moderately inactive, moderately active, or active) through a validated questionnaire [15].
comorbidities included self-reported cardiovascular diseases (cvd), cancer, asthma and bronchitis.
anthropometric measures included objective assessed bmi (weight in kilograms divided by height in meters squared) and waist circumference (wc).
wc was defined as the smallest circumference between the ribs and iliac crest, or at the level of the umbilicus if there was no natural waistline, and was measured to the nearest 0.1 cm with the volunteers standing with abdomen relaxed at the end of a normal expiration.
participants who reported doctor-diagnosed diabetes or diabetes-specific medication use at the time of sleep measurement were excluded from the analysis (n = 629).
the final study sample included 13 465 participants with complete information on daytime napping and the covariates.
incident type 2 diabetes cases were identified through multiple data sources [16] until 31 july 2006. these included self-reported doctor-diagnosed diabetes cases and diabetes-specific medication use, verified through record linkage with the general practice diabetes register, local hospital diabetes register, hospital admissions data and office of national statistics death certificate data with coding for diabetes.
a new case was defined by a doctor's diagnosis of type 2 diabetes with no insulin prescribed within the first year following diagnosis and/or a glycated haemoglobin (hba1c) level of greater than 7 percent at the health check.
self-reported diabetes cases that could not be verified were not included as incident cases.
statistical analysis baseline characteristics of the participants were firstly compared by daytime napping (yes/no), using pearson's χ2 test for categorical variables and student's t-test for continuous variables.
as the influence of sex on bmi and wc is potentially important, the sex-specific mean (sd) of these two measures were presented.
multivariable logistic regression was used to obtain or (95% ci) for incident diabetes by daytime napping (with no napping being the reference group), and by sleep duration (with 6–8 h being the reference group, due to the u-shaped relationship reported previously [3]).
three models were fitted with progressive adjustment of the covariates: model a adjusted for age and sex; model b further adjusted for education, marital status, smoking status, alcohol intake, physical activity, comorbidities and hypnotic drug use; model c additionally accounted for bmi and wc.
subgroup analysis was conducted to explore the effects of potential effect modifiers, including age (<65 vs. > = 65 years old), sex, social class (non-manual vs. manual), bmi, wc, pre-existing diseases and self-reported general health.
the interaction between day napping and sleep duration was also tested, and the joint effects for different combinations of napping and sleep duration categories were presented, using participants with no napping and 6–8 h of daily sleep duration as the reference group.
all subgroup analysis was conducted using model b to avoid over-adjustment by anthropometric measures.
all statistical tests were 2-sided, and a p value <0.05 was considered statistically significant.
analyses were implemented in stata, version 12.0 (statacorp lp, college station, texas).
results in total, 3852 (28.6%) of the participants reported day napping, and 9285 (67.9%) of them reported sleeping for 6–8 h per day.
table 1 shows baseline characteristics of the participants by napping habit.
those who reported napping were older, more likely to be men and to have lower education.
they were also more likely to be current or former smokers, physically inactive, to be taking hypnotic drugs and to have comorbidities.
supplemental table 1 summarises the sex-specific distributions of bmi and wc by sleep.
both men and women who reported daytime napping had a higher bmi and higher wc.
those who reported short sleep duration also had a slightly higher bmi and wc, although the overall difference was not statistically significant in women.
table 2 shows the adjusted or (95% ci) of diabetes incidence by napping and 24-hour sleep duration.
after adjustment for age and sex, daytime napping was associated with a more than 50% higher diabetes risk.
further multivariable adjustment had little influence on the association, but additional adjustment for bmi and wc attenuated the or (95% ci) to 1.30 (1.01, 1.69).
for sleep duration, adjustment for bmi and wc mainly attenuated the association for short sleep duration.
after adjustment for all covariates, the ors (95% ci) associated with short and long sleep duration were 1.46 (1.10, 1.90) and 1.64 (1.16, 2.32), respectively.
results from subgroup analysis are summarised in supplemental tables 2 and 3. the association between daytime napping and diabetes incidence appeared to be stronger among those with a higher wc (or = 1.54, 95% ci: 1.17, 2.03) and those reporting poorer general health (or = 1.75, 95% ci: 1.06, 2.89), although neither of these tests for interaction was significant.
the associations for sleep duration across subgroups showed a similar pattern, with no significant interaction observed between sleep duration and any of the stratified variables.
fig.
1 shows the joint effects of daytime napping and sleep duration on diabetes incidence.
the risk of diabetes was lowest among those who did not nap and had 6–8 h of sleep.
the association between napping and diabetes risk was not seen among those with more than 8 h of sleep.
long sleep was associated with more than 90% increased risk of diabetes, regardless of the napping behaviour.
however, the association between short sleep and diabetes risk was much stronger among those who reported napping.
the or (95% ci) for persons who both had <6 h of sleep and reported napping was 2.57 (1.74, 3.78).
the overall interaction between sleep duration and daytime napping did not reach statistical significance (p = 0.3).
discussion this prospective cohort study suggested that daytime napping was independently associated with an increased diabetes risk in a middle- to older-aged british population.
the association was partly explained by anthropometric measures, but not entirely with a 30% increased diabetes risk associated with napping after controlling for bmi and wc, in addition to adjustment for socio-demographic and lifestyle factors.
a u-shaped relationship was observed between sleep duration and diabetes risk.
after adjustment for all covariates, short sleep duration and long sleep duration was associated with a 46% and 64% increase in diabetes risk, respectively.
the risk of developing diabetes more than doubled for those who took day naps and had less than 6 h of sleep, compared to those who did not nap and had 6–8 h of sleep per day.
this is the first study to examine the relationship between daytime napping, sleep duration and diabetes risk in a british population.
the study benefited from a prospective design, validated ascertainment of diabetes cases in a large population sample, and objectively measured anthropometric measures including both bmi and wc to help understand the association.
some limitations need to be considered.
first, the analysis was restricted to participants without diabetes at baseline and with complete measures of covariates.
compared to the rest of the baseline sample, these participants were younger, more likely to be women, and more likely to be of higher social class and higher education.
while this might have influenced the external validity of the study, selection bias is unlikely as the incidence of diabetes was similar between those included and excluded from the current analysis.
second, diabetes cases were identified and verified primarily by health records, and some of the underlying cases could have been missed.
however, hba1c was also used as a criteria to help address undiagnosed cases, and it was reported previously in this cohort that the number of unidentified cases was relatively small and was unlikely to have led to significant bias [16].
therefore, the case identification approach used in this study should provide a relatively accurate estimate, especially given that multiple oral glucose tolerance testings on all individuals might not be feasible for large population-based studies.
in addition, daytime napping and sleep duration were reported through questionnaires, which might have introduced measurement errors and the true association could have been attenuated.
reported sleep reflects individual's own perception and could be subject to selection bias and recall bias.
in order to retain power, daytime napping was dichotomised, without further categorization of napping durations.
sleep duration was grouped into three categories based on a u-shaped relationship found by most previous studies [2].
therefore, we were unable to differentiate the effects of power naps from those of excessive napping, and could not investigate the differences associated with each hour of change in sleep duration.
while this might have diluted the overall association, these two reported sleep measures have been previously associated with other health endpoints in the epic-norfolk cohort [17], [18].
from a practical standpoint, the perception of general sleep habits should have validity in itself and is also a more feasible measure in primary care settings.
future studies need to examine in more detail the effects of different napping durations as well as more extreme sleep durations.
accelerometry recording over a prolonged period of participants' daytime and nighttime sleep might also help to resolve the problem.
finally, obstructive sleep apnea (osa) and poor sleep quality have been associated with both napping and diabetes [1], [19], [20], and might have confounded the association.
in order to address this problem, we adjusted for adiposity, an important marker of osa and respiratory impairment [21], [22].
however, residual confounding might still exist, and future studies should include assessment of osa and sleep quality to help understand this relationship.
consistent with previous findings [4], [8], this prospective study found an independent association between daytime napping and increased diabetes risk.
several cross-sectional studies have been conducted among chinese older adults, and have found a dose–response relationship between the duration of napping and increased prevalence of diabetes, after adjustment for either bmi or wc [4], [5].
one recent study found in a chinese population that long sleep duration and long daytime napping were independently and jointly associated with higher diabetes risk [23].
unlike in the uk, daytime napping in china is a social norm and is practiced by many people as a routine.
therefore, the implications of napping in the british could be different from that in the chinese, where only long and frequent naps might be related to adverse health outcomes.
while the lengths of naps were not noted in the current study, we found an increased diabetes risk associated with napping habit overall, regardless of the duration of the naps.
indeed, in a population who do not normally take naps, the presence of napping habit could have potential indicative implications for health.
notably, the nappers were generally older and had a less favourable health profile, so the possibility of residual confounding by declining health cannot be ruled out.
however, napping habit was reported years before diabetes incidence, and the association was independent of pre-existing diseases and did not differ by self-reported general health, making this explanation unlikely on its own.
the role of obesity in the association between daytime napping and diabetes risk is particularly interesting.
both of the two prospective studies have tried to address this issue and have found the association attenuated after accounting for bmi [8], [9].
xu et al.
reported that the associations remained significant in a us national sample of older adults but proposed that a more precise measurement of adiposity might further attenuate it [8], while the most recent study among finnish middle-aged adults suggested complete attenuation of the association [9].
this could be due to the smaller sample size of the latter study, or could be because of different pathways for people of different ages.
the current study included both bmi and wc as covariates, and performed subgroup analyses to test if the association differed by bmi or wc.
while we showed that those who took naps indeed had higher bmi and wc and adjustment for these adiposity measures attenuated the association between napping and diabetes risk, there remained a 30% significantly increased risk after all the adjustment.
this indicated that adiposity might explain part but not all of the association between napping and diabetes in this population.
notably, additional adjustment for adiposity measures mainly attenuated the association for short sleep rather than for long sleep duration.
it is possible that obesity explains more of the association between short sleep duration and diabetes risk in this population.
subgroup analysis suggested that the association between napping and diabetes was only significant among those with a higher wc, although test for interaction was not statistically significant.
larger studies should further investigate whether daytime napping is linked to diabetes only in obese populations or if this should be noted generally in middle- to older-aged adults.
interestingly, participants who took daytime naps but slept for short hours at night had the highest diabetes risk.
this is in keeping with finding from an earlier us study [8].
meanwhile, the differences in diabetes risk by napping habit cannot be observed among those with long sleep duration.
it is plausible that short sleep duration and daytime napping were both indicators of sleep disturbance or share a common pathway, leading to an additive combined effect of the two factors.
the mechanisms for long sleep and diabetes risk remain to be elucidated, with residual confounding and reverse causality being major concerns [3].
it should be noted that even among those with sleep duration of 6–8 h, daytime napping was still associated with a 53% increase in diabetes risk.
the test for interaction between daytime napping and sleep duration, however, was not significant in this study.
this might be due to a lack of power to detect interaction, and larger studies are needed in the future to help understand this potential interaction effect.
although daytime napping was traditionally considered as a healthy lifestyle [24], it has been increasingly associated with adverse health outcomes in the past few years [25], [26].
a number of recent meta-analysis consistently reported an increased mortality risk associated with daytime napping [27], [28], yet the underlying health implications of daytime napping remain to be examined.
the biological mechanisms triggered by day naps are unknown, and it is unclear which system is most directly involved with napping that eventually links to an increased mortality risk.
the accumulating evidence on daytime napping and increased risk of type 2 diabetes suggested the need for a closer look at the potential mechanisms.
in the epic-norfolk cohort, daytime napping was previously associated with an increased all-cause mortality risk [17] and a higher level of pro-inflammatory marker [29].
since elevated levels of inflammatory biomarkers have been associated with sleep, sedentary time and an increased risk of diabetes [30], [31], [32], this could be a plausible pathway.
in addition, increased sympathetic activity upon awaking from daytime naps, especially prolonged naps, could lead to disruption of the sympatho-vagal balance, activation of the renin-angiotensin system, and subsequently modulated insulin secretion and glycaemic control [33], [34].
one study found increased evening cortisol levels associated with excessive daytime napping in nursing home residents with dementia [35].
besides, an experimental study has suggested a 16% rise in glucose levels, 55% increase in insulin secretion, and 39% increase in serum insulin levels, associated with daytime sleep [36].
notably, this study focused on circadian rhythmicity and thereby involved 8 h of daytime sleep, which seems unrealistic in a natural setting.
another population-based cohort study found that napping >30 min was associated with a higher risk of abnormal glucose metabolism [37].
while the exact biological mechanisms for the association between sleep habits and diabetes requires further exploration, it is possible that other genetic and environmental factors have played an role, and thus causal relationship cannot be established.
notably, the protective effects of daytime napping, known as the ‘siesta’, have been reported mostly in mediterranean settings a long time ago [24], whereas findings from northern european countries or the us [6], [9], [25] often contrast with these traditional views.
in countries where daytime napping is not a routine, it is likely that we are describing a ‘forced’ napping behaviour driven both by pre-existing conditions and by insufficient nightitme sleep that makes the daytime napping catchup more common.
furthermore, the attenuation of the risk after adjustment for bmi and wc also suggests osa as a potential mediator, given the close relationship between obesity and osa [38].
osa might lead to shortened and disrupted nighttime sleep, increased daytime sleepiness, and has been independently associated with diabetes risk [19], [20], further supporting our observation on the interaction between short sleep and daytime napping in predicting diabetes risk.
on the whole, adiposity as a potentially important mediating factor requires further exploration, especially given the existing evidence on napping and increased odds of obesity [39].
studies incorporating measures of neck circumference and osa might help to address this question in the future.
in summary, this prospective cohort study suggested that daytime napping was independently associated with a 30% increased diabetes risk in a british population.
the relationship between daytime napping and diabetes risk was more pronounced among those with short sleep durations; the combined risk of developing diabetes for those who took day naps and had less than 6 h of sleep more than doubled compared to those with 6–8 h of sleep and without day naps.
while adiposity partly explains the associations, further studies are needed to help understand the nature of the relationship and the joint effects of daytime napping and sleep duration in predicting future risk of type 2 diabetes.
authors' contributions the work presented here was carried out in collaboration between all authors.
yl analysed these data and wrote the manuscript with co-authors.
yl, fpc, pgs, cb and ktk discussed the analysis, interpretation and presentation of these data.
rl performed all data management and record linkage.
rl and ktk are on the management team of epic-norfolk population study and contributed substantially to acquisition of data.
ktk is a principal investigator in the epic-norfolk study.
all authors provided detailed comments on the draft, and revised the manuscript critically.
all authors read and approved the final manuscript.
guarantor dr. yue leng.
funding the design and conduct of the epic-norfolk study and collection and management of the data was supported by programme grants from the medical research council uk (g9502233, g0300128) and cancer research uk (c865/a2883).
funding sources did not have a role in the design and conduct of the study; collection, management, analysis, and interpretation of the data; and preparation, review, or approval of the manuscript.
conflict of interest the authors declared no conflict of interest.
@highlight
background and aims few studies have prospectively examined the relationship between daytime napping and risk of type 2 diabetes.
we aimed to study the effects of daytime napping and the joint effects of napping and sleep duration in predicting type 2 diabetes risk in a middle- to older-aged british population.
methods and results in 1998–2000, 13 465 individuals with no known diabetes participating in the european prospective investigation into cancer-norfolk study reported daytime napping habit and 24-h sleep duration.
incident type 2 diabetes cases were identified through multiple data sources until 31 july 2006. after adjustment for age and sex, daytime napping was associated with a 58% higher diabetes risk.
further adjustment for education, marital status, smoking, alcohol intake, physical activity, comorbidities and hypnotic drug use had little influence on the association, but additional adjustment for bmi and waist circumference attenuated the odds ratio (or) (95% ci) to 1.30 (1.01, 1.69).
the adjusted ors (95% ci) associated with short and long sleep duration were 1.46 (1.10, 1.90) and 1.64 (1.16, 2.32), respectively.
when sleep duration and daytime napping were examined together, the risk of developing diabetes more than doubled for those who took day naps and had less than 6 h of sleep, compared to those who did not nap and had 6–8 h of sleep.
conclusion daytime napping was associated with an increased risk of type 2 diabetes, particularly when combined with short sleep duration.
further physiological studies are needed to confirm the interaction between different domains of sleep in relation to diabetes risk.
