specifications table table subject area biology more specific subject area immunology, innate immunity, tumor immunology type of data text and figures how data was acquired neutrophils were isolated from either healthy volunteer or bone marrow of mice and stimulated with retinoic acid.
the changes were analyzed using facs (bd facs calibur), microscopic image (nikon eclipse ti-e), and measurement of in vivo tumor growth data format analyzed experimental factors neutrophils were exposed to retinoic acid experimental features apoptosis, nuclear segmentation, and surface marker expressions of neutrophils were determined.
tumor growth in recipient mice was examined.
data source location kyungpook national university, daegu, republic of korea, data accessibility data are presented in this article value of the data • the data highlights the changes in the function of human neutrophils after treatment with retinoic acid.
• the data can be useful to compare the rate of apoptosis in neutrophils induced by retinoic acid.
• the data shows changes in the nuclear morphology and surface expression markers induced by retinoic acid treatment and the effect of adoptive transfer of retinoic-acid-treated donor neutrophils on tumor growth in recipient mouse.
• the data can be useful for other researchers investigating the effects of retinoic acid on neutrophils.
1 data the data includes information regarding the effect of retinoic acid on neutrophils complementing the previous study [1].
the apoptosis rates of neutrophils exposed to either retinoic acid (100 nm) or vehicle were examined using annexin/ propidium iodide (pi) fluorescence-activated cell sorting (facs) staining (fig.
1).
the percentages of living (annexinv−/pi− cells, fig.
1a), apoptotic (annexinv+/pi− cells, fig.
1b), and necrotic (annexinv+/pi+ cells, fig.
1c) neutrophils were described.
next, the mean lobe counts of retinoic acid-treated neutrophils were examined using hemacolor staining (fig.
2).
the lobe counts of neutrophils were described (fig.
2a), and the effect of rapamycin on the lobe counts of retinoic acid-treated neutrophils were described as ic50 (fig.
2b).
the expression of surface markers in retinoic acid-treated neutrophils were examined using facs analysis (fig.
3).
the gating strategies for evaluation of neutrophil surface markers were described (fig.
3a).
the surface expression of cd62l (l-selectin), cd177 (nb1, a glycosyl-phosphatidylinositol-linked n-glycosylated cell surface glycoprotein), cd16 (fcγriiia), cd64 (fcγri), and olmf-4 (olfactomedin) were analyzed (fig.
3b).
finally, the intratumoral adoptive transfer of retinoic acid-treated neutrophils from donor mouse into the recipient tumor-bearing mice were examined (fig.
4).
2 experimental design, materials and methods 2.1 neutrophil isolation human blood experiments were approved by the institutional research board of hallym university and kyungpook national university.
neutrophils were isolated from venous blood by double density gradient method using histopaque 1077 and 5% dextran [2].
2.2 apoptosis detection neutrophils (1×106 cells/ml) were treated with retinoic acid (100 nm) for the indicated time.
neutrophils were collected and stained with annexin v/propidium iodide following instructions of apoptosis detection kit.
then cell apoptosis was detected using flow cytometer.
2.3 wright–giemsa staining for mean lobe count hypersegmentation in neutrophils was determined by wright–giemsa staining.
isolated neutrophils (2×106) were treated with retinoic acid (100 nm, sigma-aldrich) for 4 h. cells were then cytospun and stained with hemacolor stain (merck millipore) and mean lobe counts were determined.
2.4 flow cytometry neutrophils were fixed and then stained.
antibodies targeted against different surface receptors: cd15, cd14, cd16 and cd64 and adhesion molecules: cd177, cd62l, and olmf-4: fitc conjugate were used.
the cells were washed and dissolved in staining buffer.
data acquisition was done using flow cytometer (bd facs calibur) and data analyzed by flowjo.
2.5 adoptive transfer of retinoic acid-treated neutrophils neutrophils from naïve mice were harvested by positive selection using ly6g+ macs kit.
the neutrophils were treated with retinoic acid (100 nm) for 4 h. recipient balb/c mice (five weeks old, female) were injected with 1×105 4t1 cells in the right leg.
then, recipient tumor-bearing mice were administered retinoic acid treated neutrophils (5×106 cells) on day 13 and 16 post tumor injection.
tumor growth was measured every three days until day 21.
2.6 statistical analysis all statistical analyses were performed using graphpad prism 5.0 (graphpad software).
avova analysis or two-tailed student׳s t-test were performed to determine the significance.
@highlight
the data presented in this article are related to the research article entitled “retinoic acid induces hypersegmentation and enhances cytotoxicity of neutrophils against cancer cells” (s. shrestha, s.y.
kim, y.j.
young, j.k. kim, j.m.
lee, m. shin, d.k.
song, c.w.
hong, 2017) [1].
this article complements the potential of retinoic acid to induce changes in effector function of human neutrophils.
here the datasets describe the rate of apoptosis, changes in numbers of nuclear lobes, and the expressions of surface markers in human neutrophils in presence or absence of retinoic acid.
the tumor growth in recipient mice with adoptive transfer of retinoic acid-treated neutrophils was evaluated.
the included data is made publicly available to criticism and extended analysis.
