introduction synthetic tablet abuse has seen a dramatic worldwide increase.
the chemical makeup and contents of these tablets differ, resulting in varying effects that may even lead to death, depending on the users’ psychological and physical features.
this study addresses the pharmacokinetics and addictive effects of these drugs, and the injury and changes that occur in the kidneys (acute hyponatremia caused by the inappropriate secretion of arginine vasopressin, hyperthermia (>42 °c), disseminated intravascular coagulation (dic) resulting from hyperthermia, non-traumatic rhabdomyolysis, malign hypertension, and necrotizing vasculitis).
we also suggest treatment methods for these kidney injuries.
ecstasy (mdma; 3,4-methylenedioxymethyl-amphetamine) is an illicit drug that has been increa-singly abused by young people.
its effects include euphoria, enhanced sociability and heightened mental awareness.
the most well-known of the illicit synthetic tablets, it was introduced to turkey in the early 2000s – a country which, due to its geographical location and youthful population, has been subject to the negative effects of the international drug trafficking.
(1-5).
the recent appearance of synthetic cannabinoids, known locally as ‘bonsai’, has resulted in a pseudo-impression that ecstasy abuse has decreased.
however, it is still third on the list of most-seized drugs (1.7%), after hashish (cannabis sativa and derivatives) (77.99%), and heroin (17.88%).
the amounts of ecstasy captured in turkey between 2007-2013 are shown in the table 1. although the active component of ecstasy is 3,4-methylenedioxy-methylamphetamine (mdma), users of the drug give the same name to all similar synthetic tables.
these tablets, which are illegally manufactured and sold on the streets, contain amphetamine-type stimulants.
most commonly, this is mdma, although tablets may also include mda (3,4-methylenedioxyamphe-tamine), mdea (3,4-methylenedioxyethylamphe-tamine), amphetamine and methamphetamine.
in addition to amphetamine-type stimulants, illegal tablets commonly contain caffeine and/or paraceta-mol.
they may also contain sugar, inorganic chemicals and inorganic salts that do not have any stimulant, sedative or sleeping effects on the human body.
amphetamine-type stimulant substances are illegally produced.
as a result, they contain additional chemicals that are created during the production process and which present an added danger to drug users.
ecstasy tablets are made and sold in various colours, with different geometric shapes and logos intended to make them more attractive to young people.
the increased attractiveness of synthetic tablets leads to greater curiosity, which in turn leads to higher levels of addiction.
examples of recently captured ecstasy tablets are shown in figure 1. table 1 amounts of ecstasy seized in turkey between 2007-2013 figure 1 examples of ecstasy tablets produced with various colours, geometric shapes and logos in 2012, the number of the deaths directly related to illicit drugs in turkey was 162, rising to 232 in 2013 – a 43.2% increase.
in terms of sex, 97% of deaths in 2013 were male (225) and 3% were female (7).
the average age of death was 31 in males (min/max: 14/68), 33.3 in females (min/max: 16/48) and 31.1 overall (6).
amphetamine-type stimulants (mdma/ mda/ mdea/ amphetamine/ methamphetamine) were involved in 33.6% of deaths (78) in 2013. of these, 13 involved the use of only amphetamine-type stimulants (mdma/ mda / mdea / amphetamine), while the other cases all involved at least one other addictive substance (thc, heroin, synthetic cannabinoids, amphetamine/-methamphetamine, benzodiazepines, cocaine, etc.)
(6).
effects and pharmacokinetics of ecstasy mdma causes feelings of vibrancy and well-being, loss of anxiety, emotional fluctuations and indecisi-veness (1, 5, 8, 9).
initially, the body experiences hyperthermia and hyperactivity (1, 5, 10).
there may also be adverse effects such as exhaustion, sleeping disorders, nausea, vomiting, shudders, sweats, chin-lock, gnashing of teeth, blurry sight, dilating pupils, discomfort caused by light, and arrhythmia (1, 5, 11).
mdma has a stimulant, hallucinogenic effect, and is also known to enhance mental factors such as energy, empathy and euphoria (12).
generally considered a recreational drug, mdma produces these effects by preventing the re-uptake of neuroactive hormones such as serotonin, dopamine and noradrenalin in both the central nervous system and the sympathetic nervous system (12).
known as ‘serotonin syndrome’, this affects thermoregulation and automatic dysfunction.
serotonin syndrome may also cause changes in a person’s mental condition, leading to autonomic hyperactivity and neuromuscular abnormalities (12).
taking mdma increases arginine vasopressin (avp), cortical, adrenocorticotropic hormone, prolactin (12) and oxytocin levels (13).
tablets that include amphetamine-type stimu-lants have a mass of between 150 mg and 350 mg (1).
on average, they contain 100 mg of mdma.
the doses for typical recreational mdma range from 1-2 mg/kg.
the drug begins to take effect after 30-60 min, peaking at 90 min (14, 15).
in general, its effect may last between 3-5 hr, occasionally longer.
the effects of illicit tablets on humans may depend on the contents and amounts of the tablet consumed.
effects may also differ from case to case depending on the varieties and amounts of the active ingredients in different synthetic tablets (5).
mdma metabolizes in two pathways.
in the first, it conjugates with n-dealkylation, deamination, oxidation and glycine, becoming hma (4-hydroxy-3-methoxyamphetamine).
in the second, mdma becomes hmma (4-hydroxy-3-methoxymethamphe-tamine), its major metabolite, by means of o-demethylation, followed by catechol-o-methyltrans-ferase (comt), which occurs by means of cytochrome p 450 system cyp2d6 isoenzyme© (12).
medicines that are inhibitors of cytochrome p 450 2d6 isoenzyme (ritonavir and antifungal) can prevent ecstasy from being metabolized (16-18).
it has been established that the effect of cytochrome p 450 2d6 isoenzyme, in addition to inhibiting other medicines, varies from person to person.
as the drug stays longer in the body of people who metabolize it slowly, there is a higher risk of acute toxicity (12).
due to the lower enzyme activity in people of korean, chinese and japanese origin, there is an inclination towards hyperthermia, rhabdomyolysis, serotonin syndrome and multi-organ failure (19, 20).
also, it has been shown that mdma metabolites might create an inhibitor complex with the cytochrome p 450 2d6 enzyme, leading to toxicity in repetitive doses.
the metabolism of mdma is nonlinear – a slight increase in dose causes a large increase in the amount of mdma in the blood (12).
mdma and metabolites (21) are removed by the kidneys, and variations in the removal process might explain why people taking the same dose of mdma do not experience the same adverse effects.
although ecstasy usage is relatively common, instances of fatal adverse effects are rare.
the death rate at first usage is 1/2,000-1/50,000 (22).
effects of ecstasy on the immune system mdma has a negative effect on the immune system.
the drug’s suppression of innate immunity is caused by the destruction of neutrophil phagocytosis and the decreased production of proinflammatory cytokines–the dendritic cell/ macrophage-originated tumour necrosis factor alpha, interleukin (il) -1 beta, il-12 and il-15 (23).
mdma suppresses innate ifn-gamma production and reduces mhc class ii expression from the dendritic cells and macro-phages, as well as inhibiting the expression of co-stimulatory molecules.
regarding adaptive immunity, mdma reduces the number of circulating lymphocytes, especially cd4 + t cells and naturel killer (nk).
it also suppresses t cell proliferation, shifts cytokine production to th2 (ifn-gamma and il-2 production decreases), and increases il-10 production (23).
il -10 is an anti-inflammatory or immunosuppressive cytokine that inhibits the production of pro-inflammatory cytokine tnf-alpha, il-12, and ifn-gamma, as well as decreasing many macrophage functions.
mdma also has a suppressive effect on catechol aminergic beta-adrenoceptor and nicotinic acetyl-choline receptor-mediated immune function (23, 24).
the drug increases levels of glucocorticoid cortisol, plasma corticosterone, and also the inactive steroid 11- dehydrocorticosterone.
mdma’s repetitive use at either long or short intervals increases the strength and duration of suppression.
mdma use may negatively affect cancer progression by inhibiting immune regulatory systems and reducing the resistance of host cells to viral infections (25).
effects of ecstasy on the kidneys the effects of ecstasy on the kidneys can be placed into the following sub-groups: effects on fluid and electrolyte metabolism; hyperthermia; and acute kidney injury.
these categories are discussed in further detail below.
effects on fluid and electrolytes metabolism a) hyponatremia acute symptomatic hyponatremia heads the list of serious ecstasy-related complications.
it takes effect between 101-130 meq/l, and generally occurs after the first intake (26).
in terms of physiopathology, inappropriate secretion of avp is believed to be the cause of hyponatremia.
psychogenic polydipsia resulting from the belief that large amounts of generally hypotonic liquid should be taken to avoid hyperthermia during parties could be of benefit to the physiopathology.
other possible reasons for hyponatremia include the loss of liquid and solutes (sweat na concentration 45 meq/l) (27) caused by hyperthermia and sweating due to extreme physical activity, as well as feelings of thirst.
b) avp secretion in one study, there was a statistically significant increase (from 1.14-1.88 pmol/l to 2.46-9.16 pmol/l) in the avp levels of eight volunteers who were administered 40 mg mdma (average dose is accepted as being 100 mg) within 1-2 hr (28).
case studies in which avp levels were not measured have also shown that urine osmolality increases incompatibility in the case of serum hypoosmolality, which is compatible with the inappropriate secretion of avp (29).
mdma and metabolites have been shown to increase serotonin levels in the central nervous system, and this high level of serotonin causes avp release due to neurohypophysis (30).
it is believed that avp release could increase with stress, physical activity and the use of nicotine–additional factors that are generally present in situations where ecstasy is used (31).
some studies have found a negative correlation between mdma levels and avp release, which is explained by the fact that hmma–a main metabolite of mdma–might affect avp release (32-34).
as seen in the case of fluoxetin–a serotonin-specific reuptake inhibitor (ssri)–another factor might be increased water absorption in the internal medullar collector channel linked to an increase in the expression of aquaporin 2 channels (35).
hyperthermia, which could be caused by a reduction in mdma levels and an increase in hmma, is not frequently seen in cases that are accompanied by hyponatremia (36).
hmma causing hyponatremia appears in people for whom mdma’s demethylation via cytochrome p450 2d6 isoenzyme converts to hmma (mdma’s main metabolite) rather quickly.
hyponatremia symptoms generally commence between two to twelve hours after ecstasy intake.
when the na value is <125 meq/l, symptoms may include headache, nausea and vomiting.
when the na value reaches <115 meq/l there can be serious complications such as change in consciousness, coma, seizures, cardiorespiratory arrest, peduncle herniation and death (26, 37).
in patients with ayus–arieff syndrome, there may be neurogenic pulmonary oedema.
hyponatremia in patients with this syndrome will cause the development of pulmonary oedema after cytotoxic cerebral oedema.
pulmonary oedema would result in hypoxia, which inhibits the volume regulation of the brain cells, which in turn causes further deterioration to the cerebral and pulmonary oedema (38).
the same na values are more symptomatic in women than in men (39).
some studies affirm that there is a higher risk of symptomatic hyponatremia in women and that the condition may even be fatal (38, 40).
it is more likely for women to experience hyponatremia for the following reasons: a) oestrogen lessens na-k-atpase pump activity and inhibits the brain cells’ volume regulation (39);b) women’s brains have more dominant avp vaso-constructive effects, which result in less oxygen being transferred to the brain (41);c) oestrogen’s stimulation of avp secretion (42);d) women’s kidneys are more sensitive to avp (43);e) women have less muscular mass and less body weight (27);f) oestrogen causes changes in avp osmotic regulation and thirst levels, lowering serum osmolality and leading to the development of hyponatremia (44).
a study involving eight men and eight women found that the levels of copeptin, which is easier to quantify than mdma, is higher in men.
this may be an indication of avp secretion after mdma intake (45).
c) hyperthermia hyperthermia is a fatal complication of mdma.
the serious mortality and morbidity threshold of extreme hyperthermia is >42 °c (46).
at around <40 °c, recovery is generally expected (47).
however, the condition might lead to non-traumatic rhabdomyolysis, hypotension, disseminated intravas-cular coagulation (dic), acute kidney failure, hepatic failure, cardiovascular collapse, intracranial bleeding and death (48, 49).
the mechanism of mdma-induced thermogenesis involves serotonin as well as noradrenalin, α1- and β3- adrenoceptors, and mitochondrial uncoupling proteins (50-53).
some studies state that hyperthermia originates from sustained heat resulting from the activation of 5-oh tryptamine and dopamine receptor systems (54-55).
it has been observed that hyperthermia does not originate from a change in heat adjustment in the hypothalamus, and antipyretics are hence not included in the treatment options.
it has also been observed that increased muscular activity could contribute to hyperthermia (48).
long-lasting hyperthermia may result in dic and multi-organ failure (11, 56).
d) acute kidney injury the most significant reason for acute kidney injury is acute tubular necrosis caused by pigment due to non-traumatic rhabdomyolysis (necrosis of myocytes caused by a rapid rise in cellular calcium).
levels of creatinine phosphokinase can reach over 100,000 u/l (16).
acute kidney injury might be caused by hyperthermia, extreme activity, seizures, or by the direct toxic effects of mdma on muscle cells (57).
volume depletion increases the nephrotoxic effect of rhabdomyolysis.
there may also be myoglobinuria, hyperuricemia, hyperkala-emia and hyperphosphatemia.
obvious and long-lasting hyperuricemia in particular may cause renal vasoconstriction, endothelial dysfunction, infla-mmatory response, oxidative stress and failures in autoregulation (58).
one published case study has shown uric acid levels to be over 20 mg/dl (59).
reasons for acute kidney injury may include urinary bladder neck obstruction (60) and malign hypertension (61).
in a patient who has isole proximal tubule dysfunction, temporary glycosuria, phosphaturia and solute diuresis have all been observed (62).
in the literature, there are histopathologic diagnoses of necrotising vasculitis (63) and vascular thrombosis (64).
the presence of vascular thrombosis and fibrinoid necrosis (65) have also been seen in the results of renal biopsy performed due to the loss of graft function in two renal kidney transplant patients.
a greater number of biopsy results would leave us better placed to establish the relationship between acute kidney injury and mdma.
the underlying cause of tissue damage due to mdma may be increased oxidative stress or mitochondrial dysfunction (66).
increased reactive oxygen species (ros) with mdma metabolism and/or toxic oxidation and glutathione depletion may be responsible for tissue damage to the brain, liver, heart, and kidneys (67, 68).
increased production of ros and reactive nitrogen species (rns) result in the production of more potent peroxynitrite (onoo-), which interacts with cellular macromolecules (69).
the over-expression of antioxidant enzymes such as n-acetylcysteine, ascorbic acid or superoxide dismutase may neutralize the potential toxic effects of mdma (70, 71).
treatment approaches a) hyponatremia in cases of acute serious symptomatic hyponatremia, 100-200 ml 3% saline infusion must be given immediately.
as there is increased urine osmolality due to the inappropriate secretion of avp, hypotonic fluids and 0.9 % nacl must be avoided in order not to deepen the hyponatremia.
the na value should be increased to 3-5 meq/l to reduce intracranial pressure and lessen symptoms (72).
as soon as the diagnosis is made, 3% saline infusion should be given immediately, even for patients with pulmonary oedema (39).
in cases of acute medium symptomatic hyponat-remia, the transition from hyponatremia to normo-natremia may be achieved by restricting the intake of liquids.
this should result in a quick drop in the avp level, and the kidneys’ water-removal function returning to normal.
the patient should be clinically monitored for urine output, serum na, urine osmolality and urine na.
also, the possibility of a patient requiring 3% saline without diuresis or clinical response should not be overlooked.
the evaluation of a patient’s volume status would be of use when treating hyponatremia.
if findings indicate hypovolemia, the patient’s na level should be closely monitored under careful hydration (0.9% nacl) and diuresis.
avp antagonists have recently been introduced for clinical use in cases where avp secretion is inappropriate (e.g.
heart failure).
although avp antagonists are not used in treating hyponatremia caused by mdma, it might be reasonable to do so in the future.
b) hyperthermia body temperature should be decreased aggressively as it may result in serious adverse effects including rhabdomyolysis, dic and acute kidney/ hepatic failure.
in cases of multi-organ failure, intra-vascular (iv) fluid should be administered and external cooling performed (placing ice packages on the groin and/or axilla, using surface cooling blankets, immersion in 1-3 °c water, cold water lavage through the nasogastric (ng) administration of chilled iv liquids) (73).
paralysis and intubation could be performed to reduce muscular thermogenesis, while benzodiazepines can be used for reducing agitation and seizures.
although there are conflicting data on the use of dantrolene (a muscle relaxant) in the treatment of hyperthermia caused by mdma, there are cases in which dantrolene has been employed successfully (74, 75).
in a study by hysek et al involving 16 healthy volunteers, carvedilol helped reduce the low-level hyperthermia and cardiostimulant effects that occurred after a single dose of mdma.
hyperthermia resulting from mdma is caused by alpha 1 and beta adrenoceptor, and carvedilol inhibits alpha 1 and beta 1.2.3 adrenoceptors.
the authors therefore support the use of carvedilol in treating hyperthermia (76).
carvedilol’s role will be better understood following its introduction for the treatment of patients with high-level hyperthermia caused by mdma.
c) rhabdomyolysis – acute kidney injury non-traumatic rhabdomyolysis is caused by long periods of dancing, seizures or hyperthermia.
hyperkalaemia originating from rhabdomyolysis can cause arrhythmias.
treatment requires hydration-force diuresis, monitoring of the fluid and electrolyte situation, including intake and removal, and kidney function tests.
for hyperkalaemia, hemodialysis can be used.
for hyperuricemia, rasburicase might be used (77).
urine alkalization is not recommended, as it would lessen the kidneys’ ability to remove mdma (78).
a study by karami et al has shown that an extract made from the leaves of plant called feijoa sellowiana (acca sellowiana) histopathologically showed a protective effect in mice from mdma-related injury by increasing kidney glutathione (79).
d) risk of chronic kidney disease (ckd) in a survey by akkina et al involving 5,861 people, where the definition of ckd was accepted as gfr< 60 ml/dk/1.73 m2 (or for micro-albumin: male >17 mg/g creatinine, and female >25 mg/g creatinine) 1,202 people were found to have used illicit drugs.
ckd presence, kidney function and albuminuria were not found to be related to the use of cocaine, methamphetamine and heroin (80), despite a study by vupputturi et al claiming this to be the case (81).
however, these studies are not sufficiently large to state with confidence that the use of illicit drugs is not linked to the development of ckd.
conclusion an increase in the number of young people, coupled with the ease of cross-border transportation, mean that the use and accompanying health effects of mdma will become more frequent in the future.
the adverse effects of ecstasy use include mortality, particularly in young patients with hyperthermia or serious hyponatremia.
fatal hyperthermia is caused by increases in serotonin affecting muscular activity, the treatment for which requires peripheral cooling.
severe hyponatremia is caused by the inappropriate secretion of the antidiuretic hormone psychogenic polydipsia.
in order to prevent hyperthermia, a high fluid intake is required.
besides fatal hyperthermia and hyponatre-mia, rhabdomyolysis (generally non-traumatic) causes acute renal failure.
rhabdomyolysis treatment in this instance is unconventional.
urine alkalization is not recommended, as it would reduce the ability of the kidneys to remove the mdma (78).
we clinicians have an obligation to recognize these deadly side effects of mdma.
immediate and appropriate treatment following correct diagnosis is essential for patients’ survival.
most importantly, young people should be kept away from drugs in order to avoid complications that may result in their deaths.
@highlight
ecstasy (mdma; 3,4-methylenedioxymethylamphetamine) is an illicit drug that has been increasingly abused by young people.
its effects include euphoria, enhanced sociability and heightened mental awareness.
these come about via the increase of serotonin in both the central nervous system and the sympathetic nervous system.
despite the drug’s prevalent abuse, serious or adverse effects are rare.
due to personal pharmacokinetics, effects from the same dosage vary according to the individual.
fatal instances may include acute hyponatremia, hyperthermia (>42 °c), disseminated intravascular coagulation (dic) resulting from hyperthermia affecting the kidneys, and non-traumatic rhabdomyolysis.
however, it is seldom the case that hyponatremia and hyperthermia co-exist.
hyponatremia is thought to be caused by hmma – a metabolite of mdma.
hyponatremia is caused by the inappropriate secretion of arginine vasopressin (avp) and the excessive intake of hypotonic liquid accompanied by increased hyperthermia.
symptomatic, even deadly hyponatremia is seen more frequently in females, with the effects of oestrogen on arginine vasopressin believed to be the cause.
onset in such cases is acute, and treatment should be given to symptomatic patients as quickly as possible, with 3% saline administered when necessary.
reasons for acute kidney injury may include rhabdomyolysis, malign hypertension, and necrotizing vasculitis.
