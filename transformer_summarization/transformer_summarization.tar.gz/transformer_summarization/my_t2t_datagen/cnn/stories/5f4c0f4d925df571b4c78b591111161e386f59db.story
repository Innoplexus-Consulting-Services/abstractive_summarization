introduction human immunodeficiency virus (hiv) is highly heterogeneous even within infected individuals, owing to rapid turnover rates, high viral load, and an error-prone reverse transcriptase enzyme, and recombination between viral genomes [12345].
the rapid evolution and exceptional diversity of hiv facilitate the application of a variety of phylogenetic approaches to study its various aspects such as its geographical distribution and dispersion patterns.
the number of newly identified korean hiv-1-infected individuals has increased in recent years[6] and an understanding of hiv epidemiology would contribute to better management of the recent hiv epidemic in korea.
origin of the hiv epidemic hiv originated from multiple zoonotic transmissions of simian immunodeficiency virus (siv) from nonhuman primates to humans in west and central africa.
more than 40 different nonhuman primate species harbor siv strains, each of which exhibits species‑specificity [7].
independent zoonotic transmission events from nonhuman primates to humans have generated several hiv lineages: hiv type 1 (hiv-1) groups m, n, o, and p; and hiv type 2 (hiv-2) groups a–h.
while hiv-1 group m (main) is responsible for the global hiv pandemic [8], not all hiv lineages have been identified and new cross-species transmissions may take place in the future.
hiv-1 groups m and n originate directly, but independently, from siv found in the chimpanzee pan troglodytes (sivcpz) in west–central africa [910].
group n has remained confined to a small number of individuals in cameroon, but group m spread south via the congo river to what is now kinshasa in the democratic republic of the congo (drc; formerly leopoldville, zaire), where the global hiv-1 epidemic probably began [10].
the earliest direct evidence of hiv infection in humans was found retrospectively in a serum sample and a lymph node biopsy specimen stored in 1959 and 1960, respectively, in kinshasa, drc [1112].
molecular clock computer programs used to estimate the time since the most recent common ancestors (tmrcas) and evolutionary rates of various hiv lineages revealed that groups m and sivcpz shared a common ancestor in 1853 (1799–1904), and cross-species transfer is therefore inferred to have taken place around this time [13].
global epidemiology of hiv group m causes the majority of hiv-1 infections, owing to its high number of subtypes and circulating recombinant forms (crfs).
variation within group m is greatest in the congo river basin, while is the probable site of the initial zoonotic jumps and regional diversification.
initial subtype distribution indicated dominance of subtype b in the western world and of subtype a in sub-saharan africa.
in the past 15 years, however, the rapid emergence of new subtypes, and intermixing of strains, has altered the geographical distribution of subtypes [1415].
sub-saharan africa bears the highest burden of hiv-1 in terms of prevalence and diversity [16].
most, if not all, subtypes, sub-subtypes, and crfs have been reported in the drc and cameroon [1718].
although hiv-1 genetic diversity is high in west and central africa, the highest prevalence shifted in the late 1990s from east africa (uganda, kenya, and tanzania) to the southern african region.
on average, close to 20% of the human population of south africa, lesotho, botswana, and zimbabwe is thought to be infected with hiv-1 [19].
this shift provides strong evidence for the founder-effect theory (a single introduction followed by a rapid spread), since the southern african epidemic is due almost entirely to the spread of hiv-1 subtype c [20].
independently, a rapid spread of subtype c in east asia has also contributed to this subtype being responsible for more than 50% of all hiv-1 infections worldwide [21].
the hiv epidemic in asia is dynamic and all subtypes that circulate are due to multiple founder events.
subtype b was the first to be introduced to asia, in the mid-1980s, and it was seen mainly in china, india, and thailand.
this strain has been named b´ (also known as thai b) because of its divergence from the subtype b that occurs in the americas.
deng and colleagues [22] reported that this divergence occurred about 15 years after the b subtype began to spread, which coincides roughly with the introduction of crf01_ae into thailand.
crf01_ae has now gained dominance in thailand; likewise, subtype c is currently dominant in most east asian countries [23].
subtype c was reportedly introduced into india from south africa, and then into china from india [24].
in china, subtypes b and c have recombined to form crf07_b´c and crf08_b´c [25].
in eastern europe, the breakdown of the former soviet union has coincided with an increase in the number of hiv-1 infections, and most notably, the spread of sub-subtype a1, which has been linked to intravenous drug use (idu), and the spread of subtype b (and to a lesser extent crf03_ab), mainly through sexual transmission.
in western europe, as in north america and australia, subtype b predominates.
however, the prevalence of non-b strains has increased owing to the influx of immigrants from africa and asia [2627].
in south america, the prevalence and diversity of hiv-1 are highest in brazil and argentina, with substantial circulation of subtypes b, c, and f, and bc and bf recombinants.
the subtype c epidemic is now the fastest-emerging epidemic in south america [2829].
circulating recombinant forms and unique recombinant forms analyses of multiple genome regions, and in particular full-length genome sequencing, have revealed that recombination between strains is a frequent occurrence; this has also been demonstrated between strains of different groups of hiv-1 (groups m and o), as well as between and within group m subtypes [3031].
if recombinants of different hiv-1 group m subtypes have been fully sequenced and are found in three or more epidemiologically unlinked individuals, they are defined as circulating crfs.
alternatively, they may be defined as unique recombinant forms (urfs) if they do not meet these criteria.
newly discovered crfs are named in the order in which they are discovered and described; thus, their numbering does not reflect their evolutionary history or the chronological order in which they were formed.
crf01_ae is the result of a recombination between subtypes a and e, and crf02_ag is a recombinant of subtypes a and g. while no ‘pure’ subtype e lineage has been found, crf01_ae is probably the result of a recombination event early on in the epidemic after which the putative parental ‘pure’ subtype e became extinct.
the extension ‘cpx’, representing complex, is given if the crf consists of contributions from three or more different subtypes (e.g., crf04_cpx is composed of a, g, h, k, and u).
as of january 2017, 88 crfs have been registered by the los alamos national laboratory [32].
hiv genetic diversity and dual infection recombination is one of the reasons of high variability of hiv, which involves shuttling of mutations between viral genomes and leads to major antigenic shifts or alterations in virulence [333435].
one of the most important factors in the worldwide spread of hiv is this enormous genetic variability and rapid evolution.
in particular, viral sequences within a single individual can differ genetically by up to 10% [36]; however, productive infections are initiated by a single infectious unit (a single virus or infected cell), and the remainder are the result of multiple variants.
the mucosal barrier in inflammatory genital infections is thought to be important for this genetic bottleneck [37].
this reduction in viral diversity from a diverse swarm in the donor to a very limited number of variants in the recipient is dependent on the transmission route.
for example, approximately 80% of productive infections are caused by a single virus in heterosexual transmission, but only 60% in men who have sex with men (msm) and 40% in idu [3839].
within a subtype of the hiv-1 group m (subtypes a–d, f–h, j, and k), variation at the amino acid level is in the order of 8–17%, but can be as high as 30%.
variation between subtypes is usually between 17% and 35%, but can be up to 42% depending on the subtypes and genome regions examined [36].
further, dual infection can increase the viral genetic diversity within an infected person [40].
dual infection can be due to simultaneous infection with two heterologous strains (co-infection) or to sequential infection, in which a second infection with a heterologous strain occurs after seroconversion to the initial infection (superinfection).
dual infection is detected in 10–20% of hiv-infected individuals in regions of africa where different variants co-circulate.
moreover, dual infection may be associated with a higher viral load setpoint and more rapid disease progression [4142].
phylogenetic analysis of hiv as mentioned previously, phylogenetic analyses can bring to light dimensions of hiv evolution, such as the “where,” “when,” and “how” of its spread across the globe, which are impossible to assess using other approaches [134344].
in addition, phylogenetic analyses of hiv sequences have been used to investigate a variety of problems, such as potential transmission of the hiv virus among individuals [45], cross-species transmissions [9], origins [1013], subtyping [46], and drug resistance [47].
the geographical distribution and dispersion patterns of hiv have been inferred using phylogenetic analysis [4849] however, if the dataset is enlarged, the number of cases increases exponentially.
for example, the number of possible trees that can be generated using 100 sequences is 1.700459 × 10182 [50].
therefore, it is necessary to generate a representative set of trees rather than finding a single best answer.
if 95% of the trees contain a particular feature, the confidence of this feature is 95%.
resampling techniques, such as bootstrapping [51], are used to estimate the variance of a statistic for which the underlying distribution is either unknown or difficult to derive analytically.
each new sample obtained by resampling is called a “pseudosample.” from each pseudosample a new tree is estimated, and the number of times that a specific internal branch appears in the whole set of trees is recorded as the bootstrap proportion of that branch [5253].
transmission network analysis of hiv the origin and geographic expansion of hiv-1 have been well characterized using phylogenetic approaches [43], but these methods are suboptimal for describing recent hiv transmission.
phylogenies are well suited for differentiating distinct viral lineages, but not for identifying transmission partners.
it is generally accepted that phylogenetic analysis is the most powerful tool for excluding potential transmission partners, rather than establishing linkages [54].
conversely, transmission networks focus on similarity and directly link genetically similar viruses.
regarding hiv transmission clusters, investigation typically begins by inferring a phylogeny and then identifying those clades that have the appropriate statistical support.
the branching structure within the phylogeny is irrelevant after these clades have been identified.
a conceptual problem arises as these clades are not easily resolved into transmission pairs and clusters, and within a transmission cluster all individuals are treated as equally related/connected; the inferred branching structure within these clusters is again discarded, wasting the considerable computational effort expended to infer the complete phylogeny [55] (fig.
1).
furthermore, high statistical support (e.g., bootstrap) for any specific clade does not indicate that the members of the clade itself are necessarily closely related to each other [52].
figure 1 comparison of network analysis (a) and phylogenic tree (b).
while the level of interconnection in the cluster is indistinguishable in the phylogenetic tree, network analysis reveals the level of connections.
in cluster 4 (red circle), every node is connected with the other nodes while only one node is interconnected with the other two nodes in cluster 16 (blue circle) [74].
the transmission network is derived from a matrix of pairwise distances between each pair of nodes or sequences in a dataset, and a network can be created much more rapidly than a tree for large numbers of sequences because no attempt is made to take into account the patterns of shared ancestry of the individual sequences.
the distribution of cluster sizes in an hiv-1 population sequence is usually found to be heterogeneous in network analysis, consistent with different rates of transmission for different subpopulations or individuals [5657].
this heterogeneity suggests that interventions to prevent transmission should be targeted towards those with the highest risk of transmitting the virus to others [5859].
not surprisingly, studies in which sequence data are combined with behavioral risk factors have shown that sequences from individuals with the same risk factors are likely to cluster with one another [56].
phylogenetic studies among korean hiv-infected individuals the first report regarding hiv phylogenetics in korea was published in 1998 [60], 13 years after the first hiv case was identified.
this study analyzed the nef gene in 46 korean hiv-1-infected individuals; 35 of the 41 korean subtype b isolates formed a distinct monophyletic clade that was not related to any of the sequences reported from other countries available in the los alamos database or genbank.
subsequently, several studies consistently reported this unique korean clade b (kcb), analyzing various genes such as nef [6061], env [6263], vif [61], and pol [6465].
in 2012, kim et al.
phylogenetically analyzed 560 korean and 2,347 global subtype b env sequences; 491 (88%) of the 560 korean subtype b env sequences belonged to the distinct kcb (75% bootstrap value), which was differentiated from those of other countries [66] (fig.
2).
in this report, the mean tmrca was estimated to be around 1961 and 1967 for subtype b and kcb, respectively.
a bayesian skyline plot estimated that the effective number of infections increased rapidly until the early 1980s, followed by a slower increase until the mid-1990s, thereafter reaching a steady-state.
the mean growth rates were estimated to be 0.15 and 0.17 per year for subtypes b and kcb, respectively, which were approximately three- to five-fold lower than those reported for other countries [4967].
this relatively slow growth rate could be explained by the demographic factors of hiv acquisition in korea, in which heterosexual contact was the most common cause of transmission (51.9%), followed by homosexual contact (39.2%), while few patients described themselves as idus so far [6].
however, many hiv-infected men may not have disclosed their true sexual risk considering that the male-to-female ratio among newly reported hiv infected individuals is greater than 20:1, and a substantial proportion (36.0%) refused to refer to their risk factor for hiv acquisition [6].
figure 2 neighbor-joining phylogenetic relationship generated from 2907 hiv-1 subtype b gp120 env sequences.
korean clade b (in red) formed a distinct cluster from worldwide hiv-1 subtype b sequences [66].
phylogenetic analyses were also utilized for epidemiologic evaluation of hiv-infected korean hemophilia patients [6869], and investigation of hiv-1-transmitted drug resistance (tdr) in korea [6468707172].
studies on tdr revealed that the drug resistance mutation was not common among treatment-naïve hiv-infected individuals in korea, and there was little evidence to suggest that tdr in korea is related to the clonal spread of drug-resistant strains.
by employing the transmission network analysis, limited genetic variation in the env gene was observed within subtype b strains from korean msms [73], and heterosexual exposure as well as younger age at hiv-1 diagnosis were associated with cluster formation among recently diagnosed korean hiv-infected individuals [74].
summary the origin of hiv and its epidemics are beginning to be understood by molecular epidemiology utilizing the characteristics of hiv, which include rapid turnover rates, high viral load, and error-prone reverse transcriptase enzymes.
while most subtypes and crfs have been reported in sub-saharan africa (such as in the drc and cameroon, where hiv was first introduced to humans), the heterogeneity of its worldwide distribution can be explained by the founder effect of a single introduction followed by rapid spread.
in korea, the unique monophyletic subtype b has predominated throughout the hiv epidemic.
while low growth rates of the hiv-infected population were suggested to explain kcb formation, a recent increase in the number of newly diagnosed hiv-infected individuals suggests the necessity of molecular investigation of the hiv epidemic in this area.
@highlight
during the evolution of human immunodeficiency virus (hiv), transmissions between humans and primates resulted in multiple hiv lineages in humans.
this evolution has been rapid, giving rise to a complex classification and allowing for worldwide spread and intermixing of subtypes, which has consequently led to dozens of circulating recombinant forms.
in the republic of korea, 12,522 cases of hiv infection have been reported between 1985, when aids was first identified, and 2015. this review focuses on the evolution of hiv infection worldwide and the molecular epidemiologic characteristics of hiv in korea.
