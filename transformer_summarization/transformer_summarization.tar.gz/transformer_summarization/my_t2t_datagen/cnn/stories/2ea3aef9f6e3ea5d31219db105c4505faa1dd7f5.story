1. background light environments change predictably with depth in the water column due to the selective attenuation of short and long wavelength irradiance by the aquatic medium [1,2].
whereas, in clear marine waters, the ambient light at the surface (0–2 m) is nearly identical to that found on land in the visible range, wavelengths in the range of 600–700 nm (perceived as red) and those below 400 nm (in the uv range) are almost entirely lacking at more than 20 m depth [3–6].
in general, fishes are spectrally tuned to their light environment, with species found at greater depth having blue-shifted photoreceptor sensitivities [7–9].
even fish species that occur in greater abundance near the water surface (above 10 m) are not particularly sensitive to light in the red end of the spectrum [7].
indeed, the peak absorption of the photoreceptor most sensitive to long wavelengths averages around 520 nm in marine fish [7]; in comparison, the average peak absorption of the avian long-wavelength sensitive cones is 565 nm [10].
one of the consequences of long-wavelength attenuation in water is that materials that reflect red lose this component of the colour and appear dark grey with increasing depth [11].
this is why species of brightly coloured red and yellow reef fish appear duller in deeper waters, even when observed from a short distance, whereas blue and green coloured fishes still appear relatively bright.
the presence of red coloration below 20 m, however, is not uncommon.
red fluorescence is ubiquitous in marine ecosystems and its production has been confirmed in various taxa (sponges: porifera [12]; corals: cnidaria [13–16]; arthropods: arthropoda [17]; echinoderms: echinodermata [12]; fish: chordata [12,18]).
in reef fishes alone, red fluorescence has been identified in at least 270 species, making up more than 40% of the species surveyed [5,18].
in contrast with bioluminescence, which consists of the production of light by biological material [19], fluorescence is the conversion of short-wavelength light into longer-wavelength light [11].
therefore, the radiance of fluorescent surfaces is due to the combination of their reflective properties (reflectance) and of their fluorescent properties (fluorescence); we use the term ‘relative radiance’ to describe the combination of light reflected and fluoresced as a proportion of the ambient light field.
species surveyed to date show that the red fluorescence excitation peaks in fishes are found below 550 nm and that peak emission wavelengths range from 580 nm to over 700 nm [5,20–22].
since photons of wavelengths below 550 nm are relatively abundant below 10 m, fluorescence, in combination with sufficiently long-wavelength spectral sensitivity, has the potential to generate perceivable red coloration in fishes starting at these depths.
however, the contribution of fluorescence to complete signals (reflectance and fluorescence) at different depths has only been addressed in corals [15,23] and mantis shrimps [24].
previous studies on red fluorescence in fishes have described its presence or absence and inferred possible functions depending on the location and intensity of the fluorescing patches [5,20–22].
red fluorescence could contribute to signals involved in male–male agonistic interactions [20], species recognition [24], prey detection [5,25], camouflage [5,18] and mate choice [5,20,22].
in species that are not sensitive to red wavelengths, red fluorescence could offer protection against ultraviolet irradiance near the water surface, but, in contrast with corals [26], there is no evidence for this hypothesis in fish [22].
furthermore, we know from laboratory experiments that even if fishes have low sensitivity to red wavelengths, a few species can perceive their own fluorescence [20,27].
these studies have given us important insight into the potential role of red fluorescence, yet it is unclear how much fluorescence contributes to animal signals under natural light environments.
in this study, we used visual models to better understand under which natural conditions red fluorescence produced by the irides of the triplefin tripterygion delaisi could contribute to the chromatic and achromatic component of their relative radiance.
to achieve this, we characterized the visual system of the triplefin, separated the colours of the irides into their reflectance and fluorescence components, and combined these data with field measures of ambient light spectra from triplefin habitats.
we predicted that red fluorescence generates stronger contrast in the stenospectral zone (at depths where red wavelengths are limited [22]), and that fluorescence contributes increasingly to the perception of the signal with increasing depth.
determining how the relative radiance of fluorescent colours change in different environments will allow a better understanding of the visual ecology of fluorescence and provide further insight into the functions of fluorescence.
2. material and methods 2.1. model species and general methods tripterygion delaisi (family: tripterygiidae; figure 1) is a small benthic fish species widely distributed across the northeastern atlantic ocean and mediterranean sea from a depth of 3–50 m. it forages mainly on small arthropods [28,29], which it hunts using a saltatory feeding behaviour on vegetated rocky substrates.
its general movements are limited and individuals will often freeze when approached, relying on their cryptic coloration and patterning to avoid detection.
it has red-brown irides that fluoresce red under blue-green light, and a previous study on t. delaisi has demonstrated that it is capable of perceiving red colours similar to its own fluorescence [27].
we focus on the irides because, except for a small area on the top of the head, they are the only fluorescing body parts in this species.
the fluorescence radiance increases with depth in the field [22] in response to the reduced ambient brightness rather than differences in the spectral composition [30].
these differences in fluorescence radiance are due to the movement of melanosomes within melanophores, which can obscure the guanine crystals responsible for the production of fluorescence [31,32].
in the laboratory, we characterized aspects of the visual system of t. delaisi by measuring: the transmission of the ocular media using spectrophotometry, the peak sensitivity of the retinal photoreceptors using microspectrophotometry (msp) and the density of photoreceptors by mapping the retinal topography.
we also objectively quantified the reflective and fluorescent properties of the triplefin irides using a spectrofluorometer with monochromators.
in the field, we collected ambient irradiance measurements at different depths.
we combined these data to determine if the fluorescent properties of the irides are sufficient to increase the conspicuousness of individuals when viewed by conspecifics.
using the receptor-noise model of colour vision [33], we modelled, under different light environments, the chromatic and achromatic contrasts between: (i) the iris with and without fluorescence; (ii) the iris without fluorescence (reflectance only) against an achromatic background; and (iii) the fluorescing iris (relative radiance) against an achromatic background.
all data are available on dryad [34].
figure 1.tripterygion delaisi in its natural environment at 5 m (a,b) and at 20 m depth (c,d).
all images were taken with natural lighting, but (b) was taken with the camera fitted with a long-pass filter, which emphasizes the red coloration of the head and irides; (a,b,d) were taken with a manual white balance, whereas (c) was taken with an automatic white balance.
photo credits: nico k. michiels.
2.2. fish capture and post-capture care field data were collected between 2014 and 2015 at the station de recherches sous-marines et océanographiques de calvi (stareso), corsica, france.
fieldwork took place from the beginning of june until early july in two successive years.
fish were caught while scuba-diving between 5 and 20 m using hand nets and 50 ml perforated falcon tubes (to permit water exchange during the dive).
during the field trip, fish were kept in the field station in a 50 l flow-through tank at ambient water temperature, until they were transferred to aquarium facilities at the eberhard karls university of tübingen, germany.
in these facilities, individuals were kept separately in blue led-illuminated 15 l flow-through tanks (18°c, salinity 34‰, ph 8.2, 12 l : 12 d cycle, fed once per day) in a 600 l water-filtering system.
2.3. light environment radiance measurements were taken with a spectroradiometer (spectrascan pr-740, photo research, new york, ny, usa) equipped with the ms-75 standard lens fitted with an sl-0.5× add-on macro lens, and encased in a custom-made underwater housing (bs kinetics, achern, germany).
because the integration time of the spectroradiometer is mainly set at depth by the abundant blue-range wavelengths, the signal-to-noise ratio in the long wavelengths was poor.
to correct for this, we equipped the spectroradiometer with a double ct orange filter (filter #287, lee filters, hampshire, uk).
the device was set up and calibrated for radiance measurements (w sr−1 m−2 nm−1) in the 380–780 nm range, summarized in 1 nm bins at a 1 nm resolution using a bandwidth of 8 nm.
ambient irradiance was quantified by measuring a diffuse white standard (ptfe) angled at 45° from normal to the surface.
this measurement geometry captured the downwelling and side-welling light field components that will most often strike the iris of triplefins on the substrate.
three measurements were obtained every 2 m from a depth of 6 to 36 m, and the averages at each depth used for analyses.
while measuring, the diver operating the spectrophotometer held their breath to avoid any potential confound due to ascending air bubbles.
a compass, a level indicator and an electronic depth gauge were mounted on top of the housing for accurate positioning.
all data were then corrected for the spectral transmission of the underwater housing's port, the macro lens and orange filter.
radiance measurements (w sr−1 m−2 nm−1) were transformed into photon irradiance (photons s−1 m−2 nm−1) by multiplication with π × wavelength × 5.05 × 1015 at each wavelength [11].
2.4. transmission properties of ocular media eight individuals were sacrificed; the dermal cornea, scleral cornea and lens of each eye were dissected out with eye scissors and placed in a small petri dish filled with enough saline to just cover each part (saline composition in mm: nacl 125.3, kcl 2.7, cacl2 1.8, mgcl2 1.8, d(+)-glucose 5.6, tris–hcl 5.0, ph 7.2).
the transmission properties of the structures were measured by means of a spectroradiometer (spectrascan pr-670, photo research) attached to a leica stereomicroscope (leica mz16f, leica mikrosysteme vertrieb gmbh, wetzlar, germany) with a bright field base illuminated using a cold light source (leica kl 2500, leica mikrosysteme vertrieb gmbh).
for each structure of every eye, we took three radiance measurements of the background light as seen through the structure (plus petri dish and saline) and one of the background without the structure (but including the petri dish and saline).
transmission was then determined as the mean of the three measurements of the structure divided by the background reference and expressed as a proportion at each nanometre.
2.5. photoreceptor sensitivity nine fish were dark-adapted for at least 1 h before being killed by overdose (eugenol 100 mg l−1) followed by cervical transection under dim red light.
we prepared the retinal tissue for msp as detailed in hart [35] and temple et al.
[36].
in short, we sampled small pieces (1–2 mm2) of the retina from five locations (central, dorsal, ventral, temporal and nasal periphery), orienting the retina using the falciform process.
the absorbance spectra of the photoreceptors were recorded from the outer segments using the equipment and procedures described in govardovskii et al.
[37].
the measurements were obtained between 300 and 800 nm with the incident light lateral to the outer segment and polarized perpendicularly to its longitudinal axis.
each pre-bleach absorbance spectrum was produced by subtracting a scan of a tissue-free area of the preparation from a non-bleached photoreceptor scan.
similarly, each post-bleach absorbance spectrum was produced by subtracting a scan of tissue-free area from a photoreceptor that was bleached for 1 min with full-spectrum light.
final absorbance profiles were calculated by subtracting the post-bleach spectra from the pre-bleach spectra, and analysed using procedures described in hart [38].
we compared the λmax values of photoreceptors from different retinal areas using one-way anova, and controlled for a false discovery rate [39] by adjusting the p-values for multiple comparisons (four photopigments).
all statistical analyses were conducted using r [40].
2.6. photoreceptor densities the relative density of the different photoreceptor types is an important visual model parameter because it has a large influence on the accuracy of perceived contrast [41,42].
to determine the ratio of single to double cones in t. delaisi, we produced retinal wholemounts of the eyes of four individuals.
we followed a slightly modified protocol for receptor cells presented in coimbra et al.
[43] and give only an overview of the procedures here.
the fish were euthanized by immersion in seawater with 1 g l−1 tricaine mesylate (ms-222), buffered to ph 8.2, and death was ensured via spinal cord cut.
the light-adapted eyes were excised immediately and their corneas, iris, lens and vitreous body removed while kept in ringer solution.
after immersion–fixation of the remaining eyecup with 4% paraformaldehyde in 0.1 m phosphate buffer for 25 min, four to five radial cuts were applied to facilitate removing the sclera and choroid, as well as flattening the retina.
the retinal pigment epithelium was bleached with 12% hydrogen peroxide in 0.9% phosphate-buffered saline for 5 h at room temperature.
finally, the retina was transferred to an uncoated slide, flattened and mounted in 80% glycerol, and the coverslip edges sealed with nail varnish.
after letting the tissue clear for at least 24 h, the receptor mosaic pattern was inspected under a dic microscope (leica dm5000b, leica mikrosysteme vertrieb gmbh).
2.7. reflective and fluorescent properties we separated the reflectance and fluorescence component of the triplefin iris with a quantamaster qm 40 (photon technology international, bensheim, germany) connected to a leica stereomicroscope (leica mz16f, leica mikrosysteme vertrieb gmbh) using liquid light guides (llg 380, photon technology international, new jersey, usa).
the samples were immersed in a seawater ringer solution with k+ elevated solution (mm: nacl 78, kcl 50, cacl2 1.8, mgcl2 1.8, d-(+)-glucose 5.6, tris–hcl 5.0, ph 7.2).
elevated levels of potassium result in melanosome aggregation, thus exposing the fluorescent surface, allowing us to capture the potential fluorescence of the sample [30,32].
we first characterized a polytetrafluoroethylene (ptfe) white diffuse standard (berghof fluoroplastic technology gmbh, eningen, germany) by sequentially shining monochromatic light (range 400–700 nm in 5 nm intervals for three fish and in a 4 nm interval for one fish) onto the sample, and collecting the emitted light across the entire visible range (range 380–720 nm in 5 nm intervals for three fish and 2 nm intervals for one fish) for every excitation interval.
we characterized the irides (eight eyes from four fish) of triplefins using the same sequence of measurements, and all spectra were interpolated to 1 nm intervals.
following acquisition of these data, we corrected the spectral curve of each scan for the wavelength dependency of the photon counter and light absorbance by the equipment between the sample and the photon counter (liquid light guides, collimating lenses and microscope) with a calibration function derived from measurements made using a spectroradiometer (spectrascan pr-740, photo research).
we calculated the reflectance component of the signal by comparing the difference in emitted photons between the white standard and the samples at the emission wavelength that coincided with the current excitation wavelength (inelastic scattering).
this implicitly assumes that fluorescent emission is negligible whenever the excitation and emission intervals are identical.
to calculate the fluorescence component of the signal, we first corrected the spectral curve of the sample emission scan at each excitation interval for the incomplete quench of the monochromator by subtracting the product of the sample reflectance per nm and the white standard emission.
a complete fluorescence probability function was then extracted by (i) calculating the difference in photons reflected between the white standard and sample (all photons absorbed) and (ii) calculating the proportion of these non-reflected photons and the ones re-emitted at longer wavelengths (elastic scattering) [24].
this is a conservative measure of fluorescence efficiency since we measured natural tissue and photons were not just absorbed by fluorescent guanine crystals.
this resulted in a complete excitation by emission wavelength matrix with values for fluorescence efficiency (proportion) for each excitation value at all longer emission wavelengths.
2.8. visual models of conspecific detection the relative radiance of the eyes of triplefins was produced by multiplying the reflectance vector by the downwelling irradiance at various depths and adding the contribution of fluorescence obtained by applying the ambient light vector to the fluorescence efficiency matrix.
to determine how the fluorescent component of the red iris signal contributes to the conspicuousness of triplefins to conspecifics at different depths, we modelled the chromatic and achromatic contrasts between 6 and 36 m of (i) the iris with fluorescence and without (reflectance only), (ii) the iris reflectance (no fluorescence) against achromatic backgrounds and (iii) the fluorescing iris (relative radiance) against achromatic backgrounds.
we produced backgrounds of different brightness using achromatic spectra (equal intensity across all wavelengths from 400 to 700 nm) with varying mean brightness because many marine substrates are achromatic [44,45] (mean brightness = 5% to 50% in 2.5% intervals).
we calculated the chromatic and achromatic contrasts in just-noticeable differences (jnds), where scores above 1.0 indicate that the colours are distinguishable from one another, using vorobyev and osorio's receptor-noise model [33].
we used the visual system measurements obtained from this study to inform the model, and set the weber fraction at 0.05 for the long-wavelength sensitive cone [33].
we calculated achromatic contrasts for the double cones, also assuming a weber fraction of 0.05. we assumed that most interactions between individuals occur at distances of less than 10 cm for which light scattering would be negligible [44]; therefore we did not include an attenuation coefficient and distance parameter in any model.
we included the measured irradiance, which combines the downwelling and side-welling light fields, at the appropriate depth as the adapted background (von kries correction) [44,46].
we compared the signals with and without the contribution of fluorescence at depths ranging from 6 to 36 m, in 2 m intervals.
we used the package pavo [47] for the r programming language [40] to produce the photoreceptor sensitivity curves for the models and to calculate the chromatic and achromatic contrasts.
3. results 3.1. visual system tripterygion delaisi possesses a dermal (outer) and a scleral (inner) cornea.
both corneas are characterized by transmissions of more than 90% across the spectral range between 400 nm and 700 nm.
we found no iridescent structures in the corneas, as has been reported in other fishes [48,49].
the lens was also highly transparent, but with distinct shortwave absorption characterized by a reduction to 50% transmission at 416 nm, and only 10% transmission at 400 nm (electronic supplementary material, figure s1).
the retina of t. delaisi is dominated by cones, which are found throughout (details to be published elsewhere).
rods occur in the entire retina, except for the fovea, with increasing numbers towards the periphery.
the overall cone pattern is a regular square mosaic with a ratio of two double cones to one single cone.
the fovea and surrounding area, however, feature a distinct and regular pattern with each single cone being surrounded by four double cones and no rods.
where these patterns transition from one to the other, the mosaic takes on irregular, intermediate ratios.
we successfully measured the spectral absorbance from 115 photoreceptors sampled from the ventral, nasal, dorsal, temporal and central locations across the retinae of nine triplefins (example measurements in figure 2).
we measured 30 rods, six single cones and 79 members of double cones of which 52 were paired.
the 27 double cone members that were not paired could neither be assigned to the short-wavelength sensitive nor to the long-wavelength sensitive member due to the considerable overlap in λmax values and were therefore analysed separately from the paired double cones.
the λmax values of all photoreceptors seemed to vary slightly across the retinal regions (figure 3), but the observed differences were not statistically significant after controlling for false discovery rates (rods: mean = 501.7 ± 2.9 s.d., f4,25 = 1.42, p-value = 0.51; single cones: mean = 468.0 ± 28.7 s.d., f2,3 = 17.17, p-value = 0.09; double cone shorter λmax: mean = 516.8 ± 9.5 s.d., f4,21 = 0.26, p-value = 0.90; double cone longer λmax: mean = 530.2 ± 11.3 s.d., f4,21 = 0.65, p-value = 0.85).
because of these results, we treated t. delaisi as trichromatic in the models [50].
the non-paired double cone members possessed pigments with wavelength of maximum sensitivity very similar to that of the paired longer λmax cones (mean = 530.4 ± 14.15 s.d.
), which also did not differ significantly by retinal region (f3,23 = 0.56, p-value = 0.65).
figure 2.representative photoreceptor absorbance curves (dashed lines) and predicted normalized absorbance (solid lines) of (a) the single and double cones and (b) the rods of t. delaisi.
figure 3.mean wavelength of maximum sensitivity of photoreceptors from different retinal regions in t. delaisi.
only paired short and long wavelength-sensitive members of double cones are included (see results).
error bars indicate 95% cis and values in symbols indicate sample size.
3.2. visual signal based on its spectral shape, the reflectance of the iris of t. delaisi (without the contribution of fluorescence) is reddish-brown (figure 4).
the wavelength of peak fluorescence excitation averaged 525 nm across all eight eyes characterized with a full width at half maximum range of 452–575 nm (figure 4).
the wavelength of peak fluorescence emission averaged 609 nm with a full width at half maximum range of 572–686 nm (figure 4).
the practical fluorescent efficiency of the peak excitation wavelength (proportion of non-reflected photons converted to longer-wavelength photons) averaged 3.34% (range: 2.00–6.24).
the contribution of red fluorescence to the visual signal of the iris varied with depth (figure 5).
at 6 m (figure 5a), for example, the contribution of the fluorescence had little influence on the relative radiance of the irides, which never surpassed the long-wavelength irradiance available in the ambient light field.
by contrast, the contribution of fluorescence to the relative radiance at 20 m was great (figure 5b), such that the relative radiance surpassed the long wavelength irradiance available in the ambient light field.
quantification of perceptual contrasts determined that between 6 and 12 m fluorescence did not contribute perceptively to the chromatic component of the signal (figure 6a).
however, below 14 m the contribution of fluorescence to the chromatic component of the signal was greater than 1 just-noticeable-difference, the minimum threshold for colour discrimination (1.25 jnd at 14 m), and subsequently increased with depth at an average rate of 0.53 jnd m−1.
the contrast between the iris and an achromatic background depended more on the brightness of the background than on the contribution of the fluorescence (figure 6b).
in simulations in which the background reflectance averaged 15% or less, the iris was perceptively brighter near the surface (6 m), slightly increasing with increasing depth.
when the background reflectance averaged more than 15%, the iris was perceptively darker, but less so with increasing depth.
figure 4.
(a) average (±s.d.)
reflectance spectra and average (±s.d.)
normalized fluorescence excitation and emission efficiency of eight tripterygion delaisi irides.
the colours of the curves are approximations of how they would be perceived by humans based on rgb scores of the spectral shapes.
(b) practical fluorescence efficiency at every 5 nm of excitation wavelength for each 5 nm of emission wavelength.
fluorescence efficiency is defined as the quotient between the number of photons emitted and photons absorbed (not reflected) and is unitless.
figure 5.radiance of t. delaisi iris with and without the contribution of fluorescence at 6 m (a) and 20 m (b), along with the respective ambient irradiance.
figure 6.
(a) the iris of t. delaisi increases in chromatic contrast with depth against an achromatic background because of red fluorescence.
solid line indicates 1 jnd.
(b) the achromatic contrast of a t. delaisi red-fluorescing iris against an achromatic background is influenced by depth.
against a dark background, the iris is increasingly brighter with depth (left).
against a bright background, the iris is much darker at shallow depths but reduces in contrast with greater depth (right).
4. discussion over 270 species of reef fishes are known to fluoresce red but the function of these complex signals has only been tested in a handful of species [20,27].
furthermore, although repeatedly suggested, it has never been demonstrated under which natural environmental light conditions red fluorescence is likely to contribute to visual signals.
to better understand the importance of red fluorescence for the visual ecology of the triplefin t. delaisi, we characterized its visual system, separated the iris colour into its reflectance and fluorescence components, quantified the light environment of triplefin habitat and used these data to parametrize visual models.
we found that triplefins have (i) double cones with photoreceptor sensitivities differing by an average of 14 nm, which, it may be reasonable to assume, contribute to a trichromatic colour vision system as has been reported in other marine fish species [50], (ii) fluorescent irides that convert wavelengths of light available in a wide range of depths to longer wavelengths lacking in the stenospectral zone and (iii) irides with fluorescence that contributes to the perceived chromatic contrast of the iris against an achromatic substrate [27].
our results strongly suggest that t. delaisi should be capable of perceiving their own fluorescence in various natural light environments, the signalling importance increasing with depth.
this is the case even if the photoreceptor sensitivity of the double cone does not appear optimized for the detection of the red fluorescence.
because this red-fluorescent radiance would be quickly absorbed through the water column, it is likely to serve a short-distance role only.
our msp measurements of double cones demonstrated that the short-wavelength sensitive member (516 nm) and the long-wavelength sensitive member (530 nm) are red-shifted by 25 nm and 10 nm, respectively, compared with the average for other species with a near surface distribution [7], suggesting that long-wavelength signals are important to the ecology of t. delaisi.
colour discrimination in the red range of the spectrum should be further possible due to the presence of double cone members with different peak sensitivities [50].
however, the difference in the peak sensitivity of the two members (average of 14 nm) is much smaller than found in the reef fish rhinecanthus aculeatus (50 nm difference), the only species for which experimental evidence exists for colour discrimination through double cones [50,51].
only behavioural tests on trained t. delaisi would confirm that their ability to detect their own fluorescence [27] is facilitated through trichromacy.
nonetheless, our results demonstrate that fluorescence produced by the irides of t. delaisi could contribute to the signal as perceived by conspecifics.
speculation on the role of fluorescence in t. delaisi is hampered by the lack of basic information regarding its biology and ecology.
nonetheless, there is the potential for this fluorescent colour to be of use in intra-specific interactions in a communicative role.
as with patches coloured with non-fluorescent pigments and structural colours [52,53], a fluorescent signal could be used for species recognition.
in areas where t. delaisi inhabit areas with similar-looking species that do not possess fluorescent irides (e.g.
parablennius zvonimiri [28]), bright red irides would be an easily identifiable species-specific trait.
it is also possible that red fluorescence contributes to sex identification.
while there are differences in coloration between males and females during the breeding season (males turn bright yellow with black faces, including their irides), there is little difference between the sexes during the non-breeding season.
it is possible that male and female t. delaisi differ in the intensity of their fluorescence; surveys of red fluorescence in reef fishes have found sexual differences in the distribution and intensity of fluorescence [12,21].
assessment of iris fluorescence of individuals of known sex (identified during the breeding season or through examination of gonads in sacrificed fish) could help resolve any sex-related differences.
unfortunately, we did not inspect the gonads of the fish we sacrificed and cannot comment on any possible trends.
additionally, colourful secondary sexual characteristics are condition-dependent in several vertebrate taxa, and indicative of an individual's potential fitness (see [54] for examples in diverse taxa).
it is possible that fluorescence plays a similar role but variation in fluorescence efficiency across individuals found at the same depth is completely unknown.
of particular interest to the signals produced by fluorescence is that all the functions described here would be depth- and, therefore, context-dependent.
furthermore, all interactions would have to take place at relatively close distances because the red coloration is quickly dulled through absorption by the water.
more information pertaining to the species’ behaviour in a natural setting during both the breeding and non-breeding season would be of great value for interpreting our results.
other non-communicative functions should also be considered.
for example, it is possible that fluorescence contribution to the overall eye (and head) coloration of triplefins increases camouflage against backgrounds that we did not measure here.
several underwater algae are known to fluoresce and, in a heterogeneous environment composed of both fluorescing and non-fluorescing materials, it would be possible to reduce conspicuousness of an otherwise dark iris and pupil by producing some red coloration.
the strength of this hypothesis is limited, however, because plant materials common in t. delaisi habitat typically fluoresce maximally at 680 nm because chlorophyll is the primary fluorescent pigment [55], and t. delaisi produce fluorescence that peaks at 609 nm.
we used the ambient light measured at 45° from normal to the surface, capturing both the contribution of the downwelling and side-welling light field that would usually strike the iris.
this approach contrasts with most studies of underwater visual ecology by not separating the downwelling and side-welling fields; the downwelling field is typically considered the main contributor to the irradiance of a surface, while the side-welling is used as the adaptive background for colour constancy (von kries correction).
one of the implications is that our assessment of the contribution of fluorescence to the perceived contrasts calculated in this study would be underestimated.
indeed, side-welling irradiance is always much more blue wavelength-shifted compared with downwelling irradiance between 0 and 40 m [11].
controlling for colour constancy using exclusively side-welling irradiance, fluorescence of the iris would start contributing to the signal at shallower depths and generate stronger perceived contrasts than those calculated.
further complicating matters, ambient illumination almost certainly affects discrimination thresholds but these effects have never been behaviourally tested [56].
discrimination thresholds may be higher when the patch being evaluated matches the background [57], which would be the case in our achromatic contrast calculations below a depth of approximately 10 m. as demonstrated by this study, red fluorescence associated with guanine–hypoxanthine crystals in the skin of fish can generate a perceivable contribution to the chromatic and achromatic component of a visual signal.
the contribution to the colours produced are strongly depth-dependent and may only play a role below 12 m, at least in t. delaisi.
because the distribution of red fluorescence in fishes is species-, depth- and even sex-specific in many species, there are strong reasons to suggest that it has an adaptive role.
a better understanding of its contribution to visual signals in other species in the context of their ecology and biology and experiments to test for specific functions will be needed to truly understand the role of red fluorescence in fish coloration.
supplementary material figure s1 the mean transmittance of the dermal cornea, scleral cornea, and lens of the triplefin tripterygion delaisi
@highlight
the light environment in water bodies changes with depth due to the absorption of short and long wavelengths.
below 10 m depth, red wavelengths are almost completely absent rendering any red-reflecting animal dark and achromatic.
however, fluorescence may produce red coloration even when red light is not available for reflection.
a large number of marine taxa including over 270 fish species are known to produce red fluorescence, yet it is unclear under which natural light environment fluorescence contributes perceptively to their colours.
to address this question we: (i) characterized the visual system of tripterygion delaisi, which possesses fluorescent irides, (ii) separated the colour of the irides into its reflectance and fluorescence components and (iii) combined these data with field measurements of the ambient light environment to calculate depth-dependent perceptual chromatic and achromatic contrasts using visual modelling.
we found that triplefins have cones with at least three different spectral sensitivities, including differences between the two members of the double cones, giving them the potential for trichromatic colour vision.
we also show that fluorescence contributes increasingly to the radiance of the irides with increasing depth.
our results support the potential functionality of red fluorescence, including communicative roles such as species and sex identity, and non-communicative roles such as camouflage.
