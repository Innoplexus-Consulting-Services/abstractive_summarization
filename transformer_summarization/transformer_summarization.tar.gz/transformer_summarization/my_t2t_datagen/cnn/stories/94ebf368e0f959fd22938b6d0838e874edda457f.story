1. introduction microbial communities are ubiquitous and of great interest for biotechnological applications [1,2], health [3–6], food production [7] and environmental studies [8].
key questions in the field of microbial ecology are: ‘who are the community members?’, ‘what are they doing?’, ‘how do they interact?’ and ‘what functionality arises from these interactions?’.
metagenome sequencing is rapidly answering the first question [9–12], and this makes the other questions all the more pressing.
great strides have been made in analysing metabolic interactions between the members of microbial communities [13–17].
despite this progress, the principles that shape the structure of microbial communities remain largely elusive, making it challenging to understand, describe, predict and (ultimately) design communities with particular behaviour.
here, we review modelling approaches that take genome information as the primary input and aim to predict community behaviour from a metabolic perspective.
thus, we do not discuss interactions between microorganisms that have no direct metabolic component, such as physical interactions or signalling processes (quorum sensing, for example).
the approaches we describe are all constraint-based, stoichiometric, modelling methods for metabolic networks.
the associated models are essentially mappings of genes to metabolic enzymes, the reactions of which form a (genome-scale) metabolic network where the edges and nodes represent (enzyme-catalysed) reactions and metabolites, respectively.
constraint-based modelling has been developed for sequenced microbes in monoculture, and many methods have been developed to reconstruct, query and predict the metabolic capacities of a species based on its genome sequence [18–24].
the most widely used method is flux balance analysis (fba) [25,26].
given a biologically relevant objective function and constraints on input/output rates (e.g.
glucose consumption, carbon dioxide excretion), fba predicts steady-state flux distributions that optimize the chosen objective—typically biomass formation, but also multi-dimensional objectives exist [27–29].
under the right premises, to be discussed later, these predictions are often surprisingly accurate—which is remarkable considering that these models do not take kinetic information into account [24].
when metagenome sequencing became feasible for entire communities [9–12], the development of constraint-based stoichiometric modelling approaches for microbial communities has become attractive.
as we explain later in more detail, the results of fba-type approaches mainly depend on (i) the quality of the reconstructed metabolic model, including the biomass composition of the associated microorganism and the assumed gene–protein reaction rules, (ii) the chosen objective function, (iii) the considered constraints for exchange and intracellular rates, and (iv) the considered nutrients that can be used for biomass and product formation.
if fba is extended to analyse metabolism on a community level, then additional layers of complexity are added to all four of these points.
with respect to reconstructions, despite the progress that has been made in automating the reconstruction of metabolic models on the genome scale [30–34], model reconstruction and manual curation is still a very time-consuming process.
in particular, detailed biomass compositions are available only for a few microbial species, and their experimental determination requires the isolation and culturing of the species.
if one misses physiological characteristics, e.g.
certain auxotrophies or transport reactions in the reconstruction process, then it will have a considerable impact on the predicted interactions between organisms.
once a genome-scale model has been reconstructed, it is essential for community modelling that it can be combined with other models in a meaningful way.
the construction of community models is complicated by the fact that, in most cases, such models will have been created by different authors and research groups.
consider, for example, that all models should be encoded to be readable by the same simulation software; model components (reactions, metabolites, flux capacity constraints) must be unambiguously annotated such that they can be used to link models together and community models themselves should be reproducible and exchangeable.
fortunately, with regards to model interoperability, the constraint-based modelling community has recently adopted a standard model encoding format that allows for efficient model exchange [35].
however, the problem of seamless integration, when using models collected from different sources, currently remains open.
another difficulty is to define a community objective function in both biological and mathematical terms; typically, a combination of the objective functions of individual species is optimized but the exact formulation can differ [15,17,36–39].
this question touches upon fundamental questions in evolutionary biology about group selection versus selection at the level of individuals.
regarding exchange rates, at a monoculture level, exchange rates can be calculated from extracellular concentration data, and intracellular fluxes can be estimated using, for example, 13c-labelling experiments [40,41].
such data can then be used as constraints for fba.
both become much more complicated on a community level; it is not trivial to determine individual contributions of microbial species to measured net fluxes of extracellular compounds, making it difficult to define appropriate constraints on the species level.
there are isotopic labelling methods for community-level quantification of fluxes, and metatranscriptomics and metaproteomics data may be translated to flux constraints under simplifying assumptions [42–48], but these have not reached a sufficiently quantitative level yet.
on a single-species level, the growth potential of organisms is directly determined by the composition of the medium.
this is not so on a community level where the available resources and the metabolic capabilities of other community members determine the metabolism and growth behaviour of particular species.
even if species cannot use certain compounds available in their environment directly, they might be able to use those indirectly through the metabolic activity of other members in the community, as illustrated for a minimal example in figure 1. interactions between species are therefore context and medium dependent [49–54].
thus, at the moment, models are required to predict and quantify these (hidden) metabolic interactions between microbial species, given different environmental conditions and objectives, as we can presently not measure them.
figure 1.growth potential depends on the composition of the medium and the metabolic capabilities of members in the community.
organism 1 (red) can only use aext that can be converted into a precursor of biomass, c. if it grew alone, then it could not make use of bext.
when organism 2 (green) is present, which is capable of using bext and thereby excreting a growth coupled compound d, organism 1 can increase its biomass production.
in this review, we discuss the several methods that have been developed [14,15,17] to use fba and variants thereof on a community level.
the first work using genome-scale models for a microbial community was published in 2007 [36].
since then, it has been used to estimate interspecies fluxes as well as intracellular flux distributions [36], to classify metabolic interactions [13], to predict the compositions of media that induce interactions between members of a community [55], to predict optimal relative biomass abundances [39] and many more, most of which are summarized in [17].
we view these studies in the light of the complications that we have identified.
for a thorough understanding of these issues, however, we first need to derive the classical fba approach from its basic principles before we move on to the specifics of community fba (cfba).
2. basic principles and assumption of single-organism flux balance analysis: the foundation of microbial-community flux balance analysis the foundations of classical fba were developed in the 1980s [56–58] and today it is one of the most used methods to study metabolism [24–26].
by making assumptions about an objective function (typically biomass formation) and using information about transport fluxes (e.g.
sugar uptake, product formation) and intracellular rates, fba can be used to determine flux distributions that optimize the respective objective; kinetic parameters are not required.
fba and all of its variants rely on a metabolic steady state.
hence, it strictly applies only to cell populations displaying balanced growth, i.e.
cells in batch culture growing in the exponential phase, or cells cultured in a chemostat, where the concentration of each metabolic intermediate and the growth rate are constant.
the rationale of fba is as follows: one considers all metabolic reactions in the metabolic network, including those reactions leading to the macromolecular components of cells such as proteins, rna, lipids and dna (or their respective building blocks) and one that specifies the macromolecular component composition of cells, using an artificial biomass-forming reaction.
next, one demands a metabolic steady state, which then directly leads to a constant rate at which new biomass is synthesized.
hence, the balanced growth condition is modelled.
to make this explicit and facilitate the discussion of modelling microbial communities, in the following classical fba is derived from basic principles.
the starting point of this derivation is the definition of the concentration ci of a metabolic intermediate i in the metabolic network with ci = ni/v, where ni is the number of molecules i and v is the cell volume.
v and ni are defined for the entire population of cells; v is the total cell volume and ni is the total amount of molecules i. owing to growth, both variables are time dependent, and the temporal change of ci is given by applying the chain rule for differentiation2.1when the volume is constant, i.e.
∂v/∂t = 0, the concentration change is proportional to the change in the number of molecules.
when the number of molecules is fixed, ∂ni/∂t evaluates to 0 and ci can be increased when the volume is decreased and vice versa.
at steady state, the temporal change of ci is 0, i.e.
(d/dt)ci = 0. this yields for equation (2.1)2.2multiplying equation (2.2) by v/ni allows us to define the specific growth rate μ at steady state as2.3 rewriting equation (2.2) by using equation (2.3) illustrates that the synthesis of new molecules equals their dilution by (volume) growth at steady state2.4 at a constant volume (so in the absence of volume growth), the rates of the reactions vj occurring in metabolism relate to equation (2.4) in the following way:2.5whereby sij are stoichiometric coefficients which are positive/negative if metabolite i is produced/consumed in reaction j. equation (2.5) means that the temporal change of ci is determined by fluxes vj that can either produce or degrade metabolite i. the vectorized version of equation (2.5) then reads2.6where c is the vector of concentrations, v is a vector of rates and s is the stoichiometric matrix with m rows and r columns representing metabolites and reaction rates, respectively.
it contains the stoichiometric coefficients sij.
2.1. biomass and growth dilution in fba, one now defines two classes of metabolites that appear in the stoichiometric matrix s: molecules that are required for biomass formation (metabolic end-products such as dna, rna, protein, membranes or their respective building blocks) and intermediates which are not.
these two classes are treated differently regarding the dilution by growth (equation (2.4)).
it is neglected for intermediates as the metabolic rates of intermediate conversions are assumed to be much higher in value than μ · ci.
for biomass components, however, dilution by growth is taken as their main sink, and, therefore, equations (2.4) and (2.5) become2.7and2.8which means that intermediate concentrations do not change over time, i.e.
their production rates equal their consumption rates, whereas biomass components accumulate exponentially with rate μ, reflecting the exponential increase of biomass.
in stoichiometric models, the fluxes vj are usually expressed in mmol (h · g)−1 and growth rate μ has the unit g (g · h)−1 reflecting the increase of biomass per biomass per hour.
considering this, one sees that ci has the unit mmol g−1 (equation (2.8)).
hence, ci is the amount of biomass component i per gram of biomass.
a biomass-forming reaction vbiomass can be defined as2.9where represents one of the z biomass components (dimensionless) and the coefficients ci the contribution of biomass component i to 1 g of biomass with unit mmol g−1.
summarizing, fba involves the following mass-balance constraints, with the rates vj as unknowns:2.10or in a more compact form2.11whereby the flux vector v contains vbiomass and the stoichiometric matrix s a corresponding column that contains 0s in rows that correspond to intermediates and the factors ci in rows that correspond to biomass components.
so-called boundary species (senv and penv in figure 2) do not appear in the stoichiometric matrix; they just serve as parameters and do not have any influence on the actual simulations.
in some model formulations, they are omitted, and the environmental fluxes j are expressed as ‘hyperspace’ reactions.
the net units on the left- and right-hand sides of the relations in equation system (2.10) are per unit ‘gram cells’.
so they remain valid when the biomass increases owing to growth.
these relations are therefore the balanced growth condition that was mentioned earlier.
the rate of biomass increase equals dx/dt = μ · x with x as biomass in gram cells.
biomass therefore does not need to be considered explicitly in fba on monocultures.
this is different for communities, as we see!
figure 2.illustration of the different rates in fba.
one distinguishes environment fluxes ji with unit mmol h−1, specific rates vi with unit mmol (h · g)−1 and the organism's specific growth rate in h−1.
x denotes the organism's biomass in unit g, are components required for biomass formation and their respective contribution to 1 g of biomass is denoted by ci with unit mmol g−1.
2.2. flux distributions have variability as there are typically more unknown fluxes than metabolites, the linear system defined in equation (2.11) is usually underdetermined.
the solution space can be reduced (i) by constraining individual rates with so-called capacity constraints, using information about reversibility of reactions and constraints based on experimental data, such as uptake rates, and (ii) by optimizing a particular objective as, for example, vbiomass, using linear programming.
the optimization problem in fba can be expressed in a compact form as follows:2.12where z represents the objective function and is expressed as a linear combination of fluxes v with weights contained in vector w and has been discussed extensively in [27,28]; typically, growth rate is maximized, thus z = vbiomass.
the vmin and vmax contain the lower and upper bounds of the rates; if a reaction is irreversible, then the corresponding lower bound is set to 0. usually, multiple flux distributions exist that optimize the respective objective function.
the flexibility of individual fluxes can be examined by using flux variability analysis (fva), where each flux is minimized and maximized, using the optimal value of the objective function as an additional constraint [59–62].
fva can be formulated as follows:2.13whereby zopt is determined, using fba.
more advanced methods exist to study all the alternative optimal flux distributions [63,64].
2.2.1. a closer look at the units in classical flux balance analysis in fba, one can distinguish three different rates, which are depicted in figure 2: environmental (exchange) fluxes j with unit mmol h−1, specific rates v with unit mmol (h · g)−1 and a biomass-forming reaction vbiomass occurring at the specific growth rate μ which has the unit h−1.
in the following, we explain how these different rates are connected, using the small example system from figure 2. the external metabolite, sext, is made available at a rate of j1(t) and is consumed by the organism at a rate of v1 · x(t).
the temporal change of sext is therefore given by2.14where x(t) denotes the biomass of the organism.
in most fba formulations, sext is also balanced by uptake and exchange reactions, and because the biomass increases exponentially the steady-state solution to equation (2.14) must readnormalizing this expression with respect to the total biomass given byone obtains for the specific rate v1where2.15is the specific exchange flux with the environment.
has the unit mmol (h · g)−1 consistent with the units of the remaining rates.
for all internal metabolites, the biomass cancels out at steady state, as shown here for metabolite m12.16note that this is not the usual way that fba and the role of exchange fluxes are presented: rather, exchange fluxes ve are often ‘just’ assigned for every external metabolite under the premise of fixed external metabolite concentrations in steady state.
yet, strictly speaking, sext can only remain constant under exponential growth if the feeding rate increases exponentially with biomass.
it illustrates an important point often taken for granted: in fba, we fix some input flux(es) through capacity constraints.
in real systems, this can be achieved in different ways.
in fed-batch growth, the feeding rate of sext is indeed increased exponentially to keep its concentration constant during exponential growth.
in the chemostat, we use dilution to achieve a steady state of biomass and nutrient levels; in normal batch growth, we define a region where the inevitable changes in external metabolites do not affect the uptake (and production) rates.
for substrates taken up, this implies saturation—or nutrient excess.
as we see, a clear distinction of the units of the different fluxes will be essential to understand the fba approaches applied to communities.
2.2.2. limitations of single-organism flux balance analysis fba has been proven to be a useful tool in several contexts, such as strain design [65–67], the outcome prediction of evolution studies [68,69] and gene deletion studies [70–72] (many more can be found in various reviews and references therein [24–26]).
however, because of its stoichiometric nature, and because it uses optimization, fba comes with inherent limitations.
most prominently, one should be aware of the fact that fba predicts flux distributions that provide the maximal yield on the limiting nutrient, and does not actually predict kinetic rates.
if one sets the uptake rate of a nutrient, e.g.
vglucose, to a certain value and μ is maximized by finding optimal values of the remaining vj, then the fluxes that maximize the ratio μ/vglucose are found.
this expression is defined as a yield, ybiomass/glucose, with unit grams of biomass per mol glucose.
while there are examples where the predicted flux distributions are in good agreement with experimental data [68,69,73], there is poor agreement under conditions of nutrient excess that favour low-yield strategies such as fermentation [74–76].
as mentioned earlier, owing to the assumption of time-invariant extracellular conditions, classical fba can only be applied to chemostat cultures and cells in batches that grow exponentially, i.e.
populations that display balanced growth.
external fluctuations of metabolite concentrations cannot be incorporated.
furthermore, owing to the linear nature of the system, fba neither allows absolute concentrations to be predicted nor incorporates saturation effects.
in addition, regulatory effects cannot be examined.
to overcome some of the limitations, classical fba has been extended in recent years [77–84].
the most exciting extensions from a community point of view are dynamic fba (dfba) [85]—discussed in more detail later—and very recent methods that couple metabolic fluxes to enzyme synthesis costs, thus allowing growth-rate-dependent switches in metabolic fluxes according to the principle of limited resource allocation [82–84,86,87].
the latter approaches have not been used in community modelling as far as we are aware, but show much more realistic behaviour than classical fba.
2.2.3. summary of the main assumptions for classical flux balance analysis fba allows steady-state flux distributions to be determined given a genome-scale stoichiometric model, flux capacity constraints (e.g.
sugar uptake) and an objective function (e.g.
growth rate).
one distinguishes two classes of relevant metabolites for which different mass-balance constraints apply: intermediates for which dilution by growth is not considered and biomass components for which growth dilution is the main sink (equations (2.7), (2.8), (2.10)).
there are three different kinds of rates: environmental exchange fluxes with unit mmol h−1, specific rates with unit mmol (h · g)−1 and a biomass-forming reaction occurring at the specific growth rate μ which has the unit h−1 (figure 2).
in classical fba, biomass does not have to be taken into account explicitly when uptake rates are calculated (§2.1) which is a major difference from fba on the community level as discussed in the following sections.
3. steady-state community flux balance analysis in nature, microorganisms usually do not occur in monocultures but are rather organized in communities where they interact in various ways [88].
until now, it has remained a great challenge to qualify and quantify metabolic interactions between community members and to understand how these influence the community structure and its dynamics.
for this purpose, several approaches have been developed [14,15,17], one of which is fba on a community level where stoichiometric models of different species are connected [14,17,36,89].
such a meta-species network allows for an analogue mathematical representation as described for classical fba.
the choice of an appropriate objective function, however, is even less obvious on the community level than it is for monocultures as there has been a long-standing debate on which level natural selection actually occurs [90–97].
nevertheless, in brave attempts to use the time-invariant constraint-based formalism for communities, several expressions for an objective function have been proposed, such as linear combinations of individual species objectives [36], a community growth rate meaning that all species grow at the same rate [39] as well as a bilevel objective function where individual as well as community objectives are taken into account [37].
we now extend the mathematical formulation of classical fba to describe the steady-state growth of communities.
for this, a community is considered that consists of only two members, as depicted in figure 3; a more generalized derivation can be found in [39].
figure 3.two organisms live in the same environment competing for a substrate sext.
xi represent their respective biomass, ji are environment fluxes with unit mmol h−1 and vi are specific rates with unit mmol (h · g)−1.
internal metabolites are denoted by mij.
first, the steady-state concentration of the external metabolite sext is considered (the same formalism applies to p1ext and p2ext).
sext is made available by an environmental flux j1 and taken up by both organisms.
these uptake rates are proportional to their biomass: x1 and x2, respectively.
the differential equation for sext therefore reads as follows:where vij is the specific uptake/production rate of compound j by species i. at steady state, the temporal change of sext is 0 and the organisms' biomass increases exponentially with their respective growth ratesso that one obtains3.1the clearest solution to equation (3.1) can be derived if both organisms grow at the same rate and j1(t) also increases exponentially with that same ratenormalizing this expression with respect to the total biomass in the system given byyields when we introduceandfor the relative biomass abundances and the specific environmental exchange fluxes, respectively, we obtain the final expression3.2equation (3.2) shows that biomass abundances have to be taken into account when the balances of external metabolites are calculated.
this is a major difference from classical fba where the relative biomass abundance is always 1 by definition (equation (2.15)).
for all internal metabolites biomass abundances do not matter as seen before (equation (2.16)) and cancel out as demonstrated for m113.3 this derivation assumed equal growth rates for both organisms.
in many cases, this is the only sensible steady state that can be achieved by communities.
for communities in chemostats, equal growth rates are obvious, as the dilution rate sets the steady-state growth rate for each organism independently.
in fed-batch growth, however, one might consider organisms with different growth rates, combined with a double-exponential feeding regime to keep the nutrients constant, following equation (3.1).
in addition, during batch growth, in analogy with monoculture batch fba, there may be a window in time where all organisms are in balanced growth, i.e.
their internal components are in steady state, even when the external concentrations are not.
however, this is provided that there is no cross-feeding present.
if the two organisms were to have different growth rates, the one with the highest growth rate would rapidly outgrow the other.
if this fast-growing organism is dependent on a factor d secreted by the slow organism (as in figure 1), its growth will soon start to become limited by the relatively slow production of d, according to the balance3.4here, the signs indicate that species 1 consumes d produced by species 2, and j is the exchange rate of d. a small fraction of species 2 will result in slow production of d, and, unless d is provided from the environment, d will decrease until it affects the specific uptake rate of species 1, i.e.
v1d.
at that point, growth rate will start to decrease for species 1, and the system will settle into a global steady state only when the growth rates are equal.
thus, using steady-state fba for modelling communities is allowed even if organisms grow at different rates, as long as within that regime the conditions allow constant uptake and production rates.
for all practical purposes, that means saturation of the uptake systems.
for metabolites that are exchanged such as d, saturation is rather unlikely; hence, these models can only represent short snapshots of the system.
either one can resort to dfba, which glues many such snapshots together (as we discuss later), or one sticks to equal growth rates, as is done in cfba [39], as discussed in §3.1.
3.1. community flux balance analysis: applications and limitations cfba has a number of advantages.
first, it provides an unambiguous objective function for all consortium members: the identical growth rate.
moreover, imposing equal growth rates ensures that the relative biomass abundances are constant, and it was shown that these abundances affect the optimal growth rate [39].
thus, these models predict species abundance ratios, something that can be readily determined experimentally by (metagenomics) sequencing.
steady-state cfba is, however, mainly applicable to systems in fairly constant environments such as cells grown in the chemostat or cultures used for waste-water treatment.
it is currently unclear whether organisms in a community are actually capable of adjusting their metabolism to operate in an optimal manner: ideally, long-term community chemostats should be studied.
in yoghurt fermentations, which are derived from serial transfer of two microorganisms (streptococcus thermophilus and lactobacillus bulgaricus), we do observe biomass abundances close to the predicted optimum (m hanemaaijer et al.
2016, unpublished results).
in our view, predictions made by steady-state cfba should probably be best seen as idealized states that represent potential final states of evolutionary/adaptation processes.
its main applications are the same as for classical fba in terms of qualitative exploration of medium compositions, metabolic engineering strategies and—most interestingly perhaps—the prediction of essential interactions between species given a certain medium composition.
additionally, cfba gives an indication of the corresponding optimal relative biomass abundances.
essential interactions can be identified by optimizing the system's community growth rate and by performing fva (equation (2.3)) on all the transport reactions of shared metabolites.
if the lower and upper values of a flux have the same sign, then it is unidirectional and can therefore be classified as essential.
this way, one can easily identify feeding mechanisms and also competition for resources.
please note that in this framework no assumptions are made about the metabolic interactions between species but that these are a direct outcome of the simulations.
if a community of only two species is examined, then the optimal biomass abundances can be obtained by systematically scanning ratios of biomass abundances and calculating the corresponding maximal community growth rate.
a plot of the optimal community growth rate versus the biomass ratio then identifies the optimal ratio of biomass abundances [39].
for communities of larger size, a systematic scan is not feasible and therefore optimization methods as gradient descent or evolutionary algorithms can be used with the constraint that the sum of all biomass fractions is 1. as for classical fba, steady-state cfba also comes with certain limitations: absolute metabolite and biomass concentrations cannot be determined but only flux distributions that optimize the community growth rate.
it is also important to keep in mind that the results obtained by this method highly depend on the quality of the reconstructed models, and especially their biomass compositions: these define the community growth rate.
in addition, the correct identification of possible auxotrophies of individual species during the reconstruction is crucial as these give rise to potential interactions between organisms.
3.2. other approaches to model steady-state behaviour of microbial communities in most studies that have been published using fba to study metabolism on a community level, equal growth rates are not assumed.
for example, in the first paper on community fba [36] a syntrophic two-species consortium was examined consisting of desulfovibrio vulgaris and methanococcus maripaludis and an objective function of the type3.5was used for different combinations of weights wi.
similarly, pairwise interactions of 118 species were investigated and classified as neutral, competitive or cooperative based on a weighted sum of biomass production rates [13].
in [98], growth rates of leptospirillum ferriphilum and ferroplasma acidiphilum are examined in terms of a unidirectional feeding flux from l. ferriphilum to f. acidiphilum resulting in different specific growth rates.
in [99], pairwise interactions of 11 gut bacteria were studied by iteratively fixing the growth rate of one organism and optimizing the other species' growth rate, whereby the resulting pareto frontiers revealed four different types of interactions.
in the optcom framework, a nested objective function is used whereby a community-level objective is optimized (e.g.
maximizing the total biomass of the community) subject to the single-species objectives (e.g.
maximizing individual biomass production) [37].
considering both species-level objective functions and a community-level objective allows cellular and interspecies fluxes to be calculated and trade-offs between species- and community-level objectives to be analysed [37,38,100].
this approach makes no assumption on the relation between individual growth rates that are calculated for each individual species.
it is most suitable for well-characterized communities with a defined community objective and, for example, does not include the analysis of communities whose members only compete for resources.
however, this approach requires the formulation of a non-convex, bilinear optimization problem that cannot be solved by standard linear programming solvers [37].
under the constraint that two organisms have to be able to produce biomass at a rate greater than a certain threshold—which allows growth rates to differ—medium compositions that can induce interactions between two species were determined [55].
with this method, known interactions between organisms could be confirmed and new ones predicted, and it allows synthetic communities to be created without modifying the organisms themselves.
these examples show that a lot of valuable information can be gained without assuming equal growth rates, but there are two issues regarding this kind of approach.
first, as discussed earlier, these results will describe only a snapshot of the community dynamics, because unequal growth rates will result in rapid changes of shared external metabolites and the biomass abundances of the species.
this means that stable relative biomass abundances cannot be inferred when the species' growth rates differ.
if this is desired to compare with experimentally determined data, then the equal growth rate constraint needs to be taken into account.
there is a second point to consider when an approach such as equation (3.5) is used, which occurs for communities whose members compete for shared metabolites.
if the community species differ in their biomass composition, then a weighted sum of biomass-forming rates will lead to a solution where all available resources are invested in the growth of the organism with the highest biomass yield, i.e.
there will be only one biomass formation reaction that carries an actual flux, and which one this is depends on the chosen weights wi.
in other words, all resources will be invested in the least expensive biomass.
technically, this issue can be avoided by assuming equal growth rates [39], by setting lower limits on the growth rates, as in, for example, [55,99], or by coupling the respective transport fluxes to growth rate, as in [101].
one might argue that this problem could be solved by interspecies feeding mechanisms.
the reasoning behind this is that then resources cannot only be invested in one organism, but also in the other one because they depend on each other.
while this will indeed lead to several metabolically active networks and an exchange of metabolites, still only the biomass-forming reaction of the organism with the highest biomass yield will carry a non-zero flux (if both organisms compete for the same resource and have different biomass yields for this substrate).
the network of the other organism will only be used to provide the required metabolite, but resources will not be invested in growth.
this is rather artificial as these fluxes require a catalyst—biomass.
coupling of excretion flux to growth rate is one way this problem has been tackled [101].
besides using explicit constraints on the growth rates, one can also overcome this issue by merging the species' biomass equations into one, so that all the required macromolecules are produced.
instead of maximizing (in the case of a two-species community) one defines according to equation (2.9)3.6as an objective function where and correspond to the biomass components in organisms 1 and 2, respectively.
such a lumped biomass reaction ensures that biomass components of all species in the community are produced.
merging of models into one network, however, should still take the biomass abundances into account for the exchange fluxes; if not it will implicitly assume a species ratio of 1 : 1.
4. dynamic metabolism-based models of microbial communities: dynamic community flux balance analysis steady-state cfba based on balanced growth is well suited to make predictions about communities in fairly constant environments, such as chemostats, regarding their metabolic interactions and optimal relative biomass abundances.
however, in batch cultures and many natural communities, organisms are exposed to dynamically changing conditions and can grow sequentially, something this framework cannot accommodate.
for such an analysis, dfba can be used—under simplifying conditions.
dfba was first used to describe the diauxic growth of escherichia coli [85] and has since also been extended to describe community dynamics [14,15,102–107].
dfba models are similar to fba models, except that the constraints on the input fluxes are made dependent on extracellular concentrations through kinetic rate expressions.
usually michaelis–menten kinetics are used, which are sometimes extended with inhibitory terms [15],4.1 when the kj parameter is equated to the affinity of the transporter, equation (4.1) describes purely substrate-limited uptake, and thus assumes that the transport step is fully controlling the downstream metabolic pathway.
from metabolic control analysis, we know that this is not necessary and in fact not very likely, as control over steady-state flux tends to be distributed [108].
on the other hand, kj can be interpreted as the monod constant for growth (which tends to be lower than the km of the transporter [109]).
in practice, kj is often fitted to data, and the distinction does not have an effect on the simulations, but it is good to be aware of the underlying assumptions.
with the uptake kinetics, a system of differential equations can be defined that describes the dynamics of external metabolite concentrations, the consequent dynamics of uptake rates and, via fba, biomass formation.
thus, at each time integration step, a linear program computes the growth rate from the uptake kinetics, and both biomass and external metabolites are updated according to4.2for the biomass, and for the external concentration4.3where vi is the net uptake or production of an external metabolite and the convention in the field is to assign a negative value for uptake fluxes.
one important assumption in dfba is that the time constants related to intracellular dynamics are much smaller than those that describe changes of external concentrations.
this is the basis for the quasi-steady-state (qss) approximation inherent in the approach.
the assumption that metabolism is in qss during the relatively slow medium transitions, invoked by the cell's own metabolic activities, is very reasonable and generally accepted in the field.
however, for adaptations that require gene-regulatory processes that may act at comparable time scales to the environmental changes, this does not apply, and so cells need not to be in balanced growth, in the sense that all biomass components, so also proteins, are in steady state.
as long as proteome reallocations are not explicitly modelled in genome-scale metabolic models—but they will be in the future—this complication is not an issue.
the concept of dfba is summarized in figure 4. figure 4.dfba allows the prediction of time courses for metabolite and biomass concentrations using the quasi-steady-state (qss) approximation.
in this figure, we illustrate the typical results of a dfba simulation.
while a carbon source, glc, is consumed over time, the associated biomass, x, increases.
the concentration profiles are described by a set of differential equations incorporating the growth rate μ and the net uptake rate for glc, vglc.
these rates are determined using classical fba whose constraints are dynamically calculated, using michaelis–menten kinetics.
extending dfba to communities is then relatively straightforward: one defines input fluxes for which kinetic expressions are required, and solves the set of differential equations, using fba for each organism individually.
however, here we also face a challenge in the interactions between the species, and different solutions that researchers have suggested.
4.1. dynamic community flux balance analysis: applications and limitations dfba has been proven to be a very useful tool to analyse metabolism on a community level [14,15,102–107,110].
it allows communities where species grow in succession to be modelled, which cannot be achieved by steady-state cfba.
multi-species dfba was first used to describe the competition between rhodoferax ferrireducens and geobacter sulfurreducens in an anoxic subsurface environment leading to predictions about the conditions under which one can outcompete the other [102].
later on, this approach was applied to a synthetic community consisting of e. coli and saccharomyces cerevisiae that—in this study—exclusively consume xylose and glucose, respectively, to engineer a co-culture system in which both sugars are consumed simultaneously [104].
chiu et al.
[111] combined fva and dfba to examine 6670 two-species communities consisting of 116 species regarding metabolites that can be produced in a community, but not by a single species growing on the same medium.
they showed that emergent biosynthetic capacity occurs in most of the communities, and in two phases: once the two organisms are introduced into the same growth medium and when the medium is nutrient-depleted at the end of a growth phase.
in these studies, the important assumption is made that communities are spatially homogeneous.
often, however, natural occurring communities tend to be structured, which can give rise to interesting dynamics [112–114].
this layer of complexity was addressed in [110], where multi-species community dfba is coupled with diffusion, allowing the analyses of spatio-temporal effects.
this framework was used to predict the species ratio to which a community of two and three members converges, which was found to be in agreement with experimental findings.
similar approaches have also been developed for monocultures [115–117].
as for any application of fba, the choice of the objective function has certain implications.
it has been debated for a long time on which level natural selection occurs: on the species or community level [90–97].
without specific knowledge about the examined community's objective, it is reasonable to assume that each member of a community attempts to maximize its own growth rate.
this is indeed the assumption made in the dynamic multi-species metabolic modelling (dmmm) framework [102], which was the first that allowed dfba to be performed on a community level.
one very interesting—and challenging—consequence of optimizing organisms individually is that one needs to hardwire the interactions between the organisms, as they cannot be predicted.
the reason for this is that at each time instance fba will predict the currently most optimal flux distribution for growth.
it will not predict the suboptimal excretion of a metabolite (e.g.
d), even though, in the long run, providing d to another organism would provide a growth benefit later on.
the models cannot predict the optimal strategy over a longer period of time, only at each time instance.
if another organism is auxotrophic for this compound d and it is not provided in the medium, the growth dynamics of this organism cannot be described without explicitly setting the model up for this purpose.
in contrast, in steady-state cfba, this interaction would show up without explicitly enforcing it.
the d-optcom framework [107] tries to capture this kind of behaviour by using not only fitness functions of individual species, but also a community-level objective.
using this, the authors claimed to be, indeed, able to describe interactions that could not be modelled using dmmm [107].
obviously, this approach assumes that a community-level objective function exists, which does not necessarily have to be the case.
moreover, owing to the nonlinear nature of this optimization problem, it is unclear whether this approach will scale—from a computational point of view—when larger communities are examined.
scaling up to more complex communities is, in fact, a general problem also for dfba.
the extension to larger naturally occurring communities is non-trivial: sequencing and reconstructing metabolic models—including the determination of the respective biomass compositions—for a representative amount of species is, as for all fba approaches, very time-consuming.
it is however important to have good reconstructions as they determine the inference of the interactions between microorganisms.
moreover, as all the interactions ultimately require some kinetic description of the input fluxes, with increasing size of the community, also the number of parameters required to model exchange rates will increase considerably, making it computationally harder to integrate the system and fit the parameters given experimental data.
not surprisingly therefore, so far, dynamic cfba has mainly been applied to small well-characterized communities whose members have been sequenced (i.e.
genome-scale models exist) and where metabolic interactions are known.
in these cases, modelling the community with dfba provides flux distributions within and between species, and can provide insight into the strength of metabolic interactions that cannot be measured directly.
5. summary and outlook in this paper, we illustrated and discussed how steady-state cfba can be derived from classical fba without any additional assumptions.
we made a clear distinction between different types of fluxes—specific internal fluxes, exchange fluxes and fluxes towards biomass—as they have different units that are relevant in a community setting.
we concluded that stable biomass abundances in communities can only be modelled if (i) the species' relative biomass abundances are explicitly considered and (ii) all organisms grow with the same growth; this ‘community growth rate’ can then serve as the objective function.
cfba allows optimal biomass abundances and the associated community growth rate at a steady state of balanced growth to be calculated.
furthermore, this approach can be used to infer essential interactions between species in a certain environment without making any assumption about how and whether species interact.
however, the cases in which community members all grow at the same rate may be rather limited because that can only be achieved in fairly stable environments.
in natural occurring communities, however, dynamically changing environmental conditions are prevalent which cannot be incorporated into cfba.
here, dcfba can be used.
this approach is, however, limited in its predictive power of unknown interactions and usually requires that the entire system structure is defined beforehand.
this is, in particular, true for mutual interactions based on suboptimal growth strategies, i.e.
if the excretion of a by-product comes at a growth cost but would benefit an organism in the long run, as it would allow growth of another organism that conversely provides growth-promoting metabolites.
while dcfba is a very powerful tool to describe small synthetic well-characterized communities, its extension to larger communities is not straightforward, owing to the number of parameters required to model transport rate dynamics and the associated numerical instability.
one way to keep the number of parameters in a reasonable range is to use explicit exchange kinetics only for metabolites that are essential for the community to grow optimally.
this information could be revealed by performing fva on the solution computed by steady-state cfba.
this combination of cfba and dcfba therefore seems promising.
we still face many challenges in modelling metabolism in communities that go significantly beyond insufficient experimental data or reconstructed genomes.
we require advances in how to define the objective function of communities, how to deal with dynamics and subsequent (sub)optimal dynamic strategies within the constraint-based modelling format, and how to incorporate the recent advances made in modelling monocultures [82–84].
it seems clear however that better use of metagenomics data towards understanding ecosystem functioning will require models that incorporate such genomics data and ways to make these models useful.
@highlight
microbial communities are ubiquitously found in nature and have direct implications for the environment, human health and biotechnology.
the species composition and overall function of microbial communities are largely shaped by metabolic interactions such as competition for resources and cross-feeding.
although considerable scientific progress has been made towards mapping and modelling species-level metabolism, elucidating the metabolic exchanges between microorganisms and steering the community dynamics remain an enormous scientific challenge.
in view of the complexity, computational models of microbial communities are essential to obtain systems-level understanding of ecosystem functioning.
this review discusses the applications and limitations of constraint-based stoichiometric modelling tools, and in particular flux balance analysis (fba).
we explain this approach from first principles and identify the challenges one faces when extending it to communities, and discuss the approaches used in the field in view of these challenges.
we distinguish between steady-state and dynamic fba approaches extended to communities.
we conclude that much progress has been made, but many of the challenges are still open.
