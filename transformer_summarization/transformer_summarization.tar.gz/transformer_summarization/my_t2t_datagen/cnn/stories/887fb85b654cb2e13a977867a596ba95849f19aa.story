introduction what was known?
systemic lupus erythematosus (sle), an autoimmune disorder, is commonly associated with bacterial and viral infections.
opportunistic fungal infection like histoplasmosis is uncommon.
progressive disseminated histoplasmosis in sle is a rare finding and mainly reported in adult population.
systemic lupus erythematosus (sle), an autoimmune disorder, is commonly associated with bacterial and viral infections and less frequently with opportunistic fungal infections.
[1] classical histoplasmosis, also known as darling's disease, is a deep mycotic infection caused by one of the two thermal dimorphic fungi, histoplasma capsulatum and histoplasma duboisii.
[2] affected individuals usually present with pulmonary and primary cutaneous disease.
progressive disseminated histoplasmosis (pdh) which commonly affects immunocompromised patients represents a severe form of the disease.
[345] an association between sle and histoplasmosis in adult patients has been published in a recent report which revealed 8 out of 14 patients had pdh.
[6] however, only one case of disseminated fungal infections was reported in lupus pediatric population.
[1] therefore, we report a case of pdh in a 13-year-old girl who was diagnosed with juvenile sle (jsle).
case report a 13-year-old girl presented with malar rash [figure 1a], fever, myalgia, stiffness of hands and knees, and photosensitivity.
on physical examination, she appeared febrile (39.5°c), pale (2 + pallor), with heart rate 120/min, respiratory rate of 28 breaths/min, and blood pressure 112/70 mmhg.
on auscultation, she had diffuse wheezing, crepitations in lower thirds of lungs, and rhythmic heart sounds without murmurs.
laboratory examination revealed the following results: hemoglobin (hb) - 9.0 g/dl; hematocrit - 27%; white blood cell (wbc) count - 2800/mm3 (95% neutrophils, 2% lymphocytes, and 3% monocytes), platelet count - 56,000/mm3; c-reactive protein - 40 mg/l (normal <5.0 mg/l); c3, 35 mg/dl (normal 90–180 mg/dl); c4, 7.0 mg/dl (10–40 mg/dl); antinuclear antibodies (anas) by indirect immunofluorescence (1/640 homogenous nuclear pattern).
chest x-ray revealed opacification of both hemithoraces and 24 h proteinuria, 1.0 g (normal <0.5 g/24 h) was also noted.
a diagnosis of jsle was established according to the revised classification criteria proposed by the american college of rheumatology,[7] based on malar rash, photosensitivity, nonerosive arthritis, positive ana, serositis (pleural effusion), and hematological disorder (leukopenia, lymphopenia, and thrombocytopenia), and proteinuria.
she was treated with oral prednisolone (60 mg/day) and hydroxychloroquine (150 mg/day).
figure 1 (a) butterfly (malar) rash of systemic lupus erythematosus.
(b) generalized erythematous maculopapular rash, observed on follow-up seven months later, she presented with high fever, severe cough with expectoration, abdominal pain, and distension with generalized erythematous maculopapular rash [figure 1b].
routine blood test revealed hb - 8.5 g/dl; wbc - 2000/mm3; platelet count - 30,000/mm3.
abdominal computed tomography (ct) showed evidence of hepatosplenomegaly and enlarged retroperitoneal lymph nodes with thoracic ct showing bilateral hilar lymphadenopathy.
a doppler echocardiography revealed pulmonary arterial pressure of 64 mmhg.
a punch biopsy was taken from the skin lesion on the forearm, and histopathological examination of the formalin-fixed, paraffin embedded, and hematoxylin-eosin stained sections revealed diffuse infiltration of the dermis with small round to oval organisms surrounded by a clear space resembling spores of histoplasma sp.
[figure 2a and b].
the organisms were better appreciated in periodic acid-schiff [figure 2c] and methenamine silver stains.
figure 2 (a) histology of skin showing diffuse infiltration of the dermis by yeast cells of histoplasma (h and e, ×100).
(b) high-power view highlighting spores of histoplasma in the dermis (h and e, ×400).
(c) periodic acid–schiff positive spores of histoplasma in the dermis (periodic acid–schiff, ×400).
(d) bone marrow aspiration smear showing macrophages containing histoplasma spores (leishman's stain, ×400).
(e) bone marrow biopsy section showing yeast cells of histoplasma (h and e, ×400).
(f) periodic acid–schiff positive spores of histoplasma in bone marrow (periodic acid–schiff, ×400) bone marrow (bm) aspiration as well as biopsy was done which revealed hypocellular marrow with macrophages containing numerous intracytoplasmic oval organisms with a surrounding clear halo similar to those found in skin biopsy [figure 2d–f].
culture from the skin tissue specimen grew white cottony colonies suggestive of h. capsulatum.
the patient was started on intravenous amphotericin b (1.0 mg/kg/day).
despite this therapy, she died 12 days later due to septic shock.
an autopsy revealed the evidence of septic shock and disseminated histoplasmosis involving lung, lymph nodes and bm with no signs of pulmonary thrombosis, and vasculitis.
discussion we are reporting a case of jsle with fatal disseminated histoplasmosis and to the best of our knowledge, only one case with similar findings has been reported in the literature.
histoplasmosis is caused by histoplasma sp., which is a dimorphic fungus belonging to ascomycetes class.
[1] the disease can be broadly classified into three subtypes: acute pulmonary form (found in immunocompetent host), chronic pulmonary form (associated with anatomical defect), and disseminated histoplasmosis (seen in immunocompromised individuals).
[8] this mycotic infection is mostly asymptomatic and has a self-limited course in normal children.
[9] disseminated histoplasmosis is quite rare and is seen in only 10% of patients with histoplasmosis,[4] particularly seen in immunocompromised individuals like those receiving immunosuppressive drugs and corticosteroids after transplantation, or suffering from acquired immunodeficiency syndrome.
[9] in sle, both occurrences of localized or diffuse histoplasmosis are unusual and such association is mainly reported in adult patients.
[1] patients with disseminated disease present with nonspecific symptoms such as fever, malaise, anorexia, weight loss, cough, and dyspnea[9] as were noted in our patient.
features meeting the criteria of pdh in our case were persistence of clinical manifestations which did not improve even after 3 weeks of acute infection along with extrapulmonary tissue involvement[9] as confirmed by physical, laboratory, and radiographic evaluation.
the presence of histoplasma infection was confirmed by the histopathological examination of tissue section and culture which are regarded as the gold standard methods.
[9] disseminated disease subtype mainly involves bm and lung[6] as was observed in our case.
pulmonary hypertension was observed in our patient, the cause of which might be due to alveolar hemorrhage caused by histoplasmosis.
this severe complication significantly increases mortality in jsle as compared to adult sle.
[110] histoplasmosis mainly affects lupus patients on immunosuppressive drugs such as corticosteroids, cyclophosphamide, azathioprine, and rituximab[6] as was noted in our case.
disseminated histoplasmosis is usually treated with amphotericin b and itraconazole for 3 completed months.
[1] in spite of aggressive therapy, there is a high incidence of mortality[6] as was observed in our case.
the key factors which led to the dismal outcome of our case were delay in diagnosis of histoplasmosis and failure to administer antifungal therapy promptly.
conclusion we report a case of disseminated histoplasmosis in an active jsle patient who presented with generalized cutaneous rash, lymph nodal, lung, and bm involvement.
histoplasmosis is an uncommon opportunistic infection in an sle patient.
a high degree of clinical suspicion is needed for early diagnosis and prompt management with antifungal drugs should be advocated for favorable prognosis.
declaration of patient consent the authors certify that they have obtained all appropriate patient consent forms.
in the form the patient(s) has/have given his/her/their consent for his/her/their images and other clinical information to be reported in the journal.
the patients understand that their names and initials will not be published and due efforts will be made to conceal their identity, but anonymity cannot be guaranteed.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
what is new?
we are reporting a case of disseminated histoplasmosis in a juvenile sle patient which is an exceedingly rare occurrence with only one case in the literature.
symptoms are generally nonspecific which cause delay in the diagnosis.
high level of suspicion is necessary for prompt diagnosis and treatment includes aggressive antifungal therapy.
a delay in diagnosis usually results in an ominous outcome which we encountered in our case.
@highlight
histoplasmosis is a systemic fungal infection caused by dimorphic fungus, histoplasma capsulatum.
immunocompetent individuals usually have self-limiting or localized disease whereas immunocompromised individuals develop disseminated disease.
the occurrence of progressive disseminated histoplasmosis in juvenile systemic lupus erythematosus is extremely rare with only one reported case in literature showing such association.
therefore, we report a case of severe opportunistic fungal infection caused by histoplasma in a 13-year-old girl who was diagnosed with juvenile lupus erythematosus, subsequently developed septic shock and died of the disease despite of aggressive antifungal therapy.
