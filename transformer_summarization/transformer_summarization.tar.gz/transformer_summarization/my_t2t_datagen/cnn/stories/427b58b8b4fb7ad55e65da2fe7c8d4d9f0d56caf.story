introduction the aminoglycoside class of antibiotics consists of different agents.
gentamicin, tobramycin, amikacin, streptomycin, neomycin, and paromomycin were approved by the united states’ food and drug administration and are available for clinical use in the united states.
among these, gentamicin, tobramycin, and amikacin are the most frequently prescribed.1 to overcome microbial infections, some antimicrobial approaches with various daily doses have been considered which are divided doses to retain antibiotic serum concentration above the minimum inhibitor concentration (mic) for a required time (time dependent), but aminoglycoside performance in body is dependent to the concentration.
this concentration dependency means that with increase in transient serum concentration of drug in serum, bacteria removal rate also increases and aminoglycosides are also able to create postantibiotic effect (pae).234 gentamicin is an aminoglycoside antibiotic composed of a mixture of related gentamicin components and fractions and is used for many types of bacterial infections treatment, particularly those caused by gram-negative organisms.5 as similar to all aminoglycosides, when gentamicin is given orally, it is not systemically active.
this is because it is not absorbed to any appreciable extent from the small intestine.
it is administered intravenously, intramuscularly, or topically to treat infections.
it appears to be completely eliminated, unchanged in the urine.
urine must be collected for many days to recover all of a given dose because the drug binds avidly to certain tissues.6 neurotoxicity, manifested as both bilateral auditory and vestibular ototoxicity, can occur in patients with preexisting renal damage and in patients with normal renal function treated at higher doses and/or for periods longer than those recommended.
high-frequency deafness usually occurs first and can be detected only by audiometric testing.7 aminoglycosides are potentially nephrotoxic, so risk is greater in patients with impaired renal function and in those who receive high doses or prolonged therapy.
rarely, nephrotoxicity might not be detected after the first few days of therapy cessation.8910 neuromuscular blockade and respiratory paralysis have been reported following parenteral injection, topical instillation (as in orthopedic and abdominal irrigation or local treatment of empyema), and oral use of aminoglycosides, especially when given soon after anesthesia or muscle relaxants.
if blockage occurs, calcium salts may reverse these phenomena, but mechanical respiratory assistance may be necessary.1112 in single dose of aminoglycosides, half-life and peak concentration of serum concentration and volume of distribution (vd) are higher and drug clearance is lesser which proves higher efficiency of aminoglycosides.
furthermore, in single dose blood creatinine (cr) increase is less, and since aminoglycosides have almost complete renal execration, less increase of cr in single dose shows less renal damage and consequently lower nephrotoxicity and increase in application safety of drug.131415161718 in patients’ auditory serial evaluation, there was no difference in terms of ototoxicity between two conditions of once a day and divided.
in single dose, ototoxicity was lower and application of single dose has been affordable and time effective.1319202122 in a study by rao et al.
which compares the efficacy and safety of one dose per day compared to multiple doses per day of gentamicin in suspected or proven sepsis in neonates, it was concluded that pharmacokinetic properties of “once a day” gentamicin regimen are superior to “multiple doses a day” regimen in that it achieves higher peak levels while avoiding toxic trough levels and there was no change in nephrotoxicity or auditory toxicity.23 according to information provided above and considering gentamicin as an important part of armamentarium of antibiotic therapy, it would be so great to have a schedule for antibiotic therapy in which toxicity is minimized and efficacy is maximized.
hence, in this study, it was tried to compare two different methods of administration to figure out the least harmful treatment method to reach a higher efficiency and increasing application safety of gentamicin which is about its side effects and selecting an approach in which ototoxicity and nephrotoxicity are lower at the same time.
materials and methods this single-blinded clinical trial (irct201104125584n2) was conducted in medical-educational centers of tabriz university of medical sciences (tabriz, iran) from august 2011 to october 2013. patients with age 12–55 years and normal renal function with diagnosis of sepsis syndrome including respiratory infection, skin infection or soft tissue, urosepsis and pyelonephritis, and patients in need of therapy with gentamicin were included in the study.
in this study, dropping glomerular filtration rate (gfr) under 80 ml/min was considered as nephrotoxicity.
decrease in gfr leads to retention of nitrogenous waste products such as blood urea nitrogen (bun) and cr.
patients with diabetes mellitus, intravascular volume deficit (hypovolemia), hyponatremia, hypokalemia, and drug history of using other nephrotoxic or ototoxic were excluded from the study.
of all the patients, eighty patients were included in the study after filing a written consent.
in these patients, depending on diagnosis, other antibiotics by condition of nonnephrotoxicity were used for the treatment alongside with gentamicin as supplemental drug.
during sampling period, selected patients were divided into two forty-people groups randomly using randlist software (version 1.2, datinf gmbh, tubingen, germany).
group one was daily single-dose group and group two was divided as dose group.
in the first group, gentamicin was prescribed with dose of 5 mg/kg as once a day, and in the second group, the same dose was prescribed but in divided form of three times a day, dose of 1.7 mg/kg.
using bun serial evaluation and cr and calculating gfr in times of one: before starting therapy, two: after the first dose, three: after 3 days, four: after finishing therapy, and five: 1 week after cutting therapy, we considered renal condition of patients.
to evaluate patients’ aural status, audiometry was conducted in times one and two, that is, before and after therapy and patients’ days of hospitalization, age, sex, and weight were also registered in both groups.
in cases when patients had any complication in terms of resistance against gentamicin (or increase in cr >2.4 mg/dl) or any other complication other than those of under study such as weight loss (weight loss causes cr increase to be hidden) during positive culture treatment, they were excluded from the study.
all stages of this study were approved by the ethics committee of tabriz university of medical sciences (ethic committee code 4895) which is in accordance with declaration of helsinki.
data collection and statistical analysis were done using spss™ version 16 (spss ltd, chicago, il, usa).
quantitative variables were expressed as mean ± standard deviation and compared with student's t-test between groups.
qualitative variables were expressed as frequency and difference between groups was analyzed by chi-square test.
significant difference defined as p < 0.05 was shown as mean ± standard deviation.
this study was approved by the research deputy of medical faculty after verification in committee of ethics with no.
5/4/4895 and registration in clinical trial site with code irct201104125584n2 under serial 88/1-4/5.
results all eighty patients were studied in two similar groups of single dose and divided dose.
some demographic information of patients are shown in table 1; the difference between two groups was not statistically significant.
table 1 some of patients’ demographic information bun, cr, and gfr were measured in five stages [table 2].
for this comparison, variance analysis with repeated measures and wilks’ lambda approach were used.
the null hypothesis in this test is equality of mean of bun, cr, and gfr in five stages.
mean of bun, cr, and gfr in five stages in two single and divided groups was compared where mean of bun and cr in single-dose group gradually decreased and those of divided dose group gradually increased and gfr of five stages increased gradually in single-dose group but decreased gradually in divided group.
in calculating gfr percentage in five stages of two groups, during five stages, gradually, percentage of single-dose group increases in gfr increase and percentage of divided dose group decreases in gfr increase.
relationship between hearing level at the start of treatment and hearing level at the end of treatment in single dose and divided dose groups is shown in tables 3 and 4. evaluating hearing level in two groups showed that ototoxicity in divided dose group is higher than that of the single-dose group.
table 2 blood urea nitrogen, creatinine, and glomerular filtration rate in different stages of study table 3 patients’ auditory status in different stages of study (single dose) table 4 patients’ auditory status in different stages of study (multiple dose) discussion in comparing age, sex, and number of hospitalization days, there was no difference between two groups and these three variables had not been mentioned in literature.
our objective of investigating these three variables was to reach a high efficiency in a specific group and sex using single dose of gentamicin and if the number of hospitalization days had increased by this method, efficiency of this method would have been proven; however, according to the obtained results, there were no differences between two groups in these three variables.
increase in bun and cr is one of the important symptoms of renal damage and if continues, it will lead body toward azotemia and kidney failure.
to determine gfr for adjusting dose of drugs with renal excretion such as gentamicin, serum cr estimation is used.
serum cr is the most usual index for gfr determination; gfr has direct relationship with urinal cr concentration and reverse relationship with serum cr.
cockcroft-gault equation is widely used to estimate gfr and we too used this equation to calculate gfr in eighty patients.24 gfr is a trustable biomarker in investigating renal status resulted from toxicity of drugs.25 according to this point, increase in mean of bun and cr during five evaluation stages in divided group and equivalent loss of mean and percentage of gfr in this group show that nephrotoxicity in divided group is more than that of the single-dose group.
furthermore, ototoxicity in divided group is more than that of the single-dose group.
hence, complication of using gentamicin (nephrotoxicity and ototoxicity) in divided group is more than those of single-dose group, and due to decrease in complications, application safety of drug in single dose is higher.
in investigated studies on aminoglycosides and gentamicin dosage, 4 factors, high efficacy, high application safety, decrease in toxicity, and time and cost save were compared in two treatment regimens.
in the study of krivoy et al.
on pharmacokinetic analysis of amikacin in two regimens of single dose and twice-a-day dose, applying single dose a day has had higher efficacy and lower toxicity and this study has suggested application of single dose.
patients were children with immune system weakness suffering fever and neutropenia.
they had measured efficacy using laboratory measuring of half-life, the highest serum concentration, and distribution and clearance volume of aminoglycoside.
in addition, applying this dose has been time and cost effective.26 the study of winsent et al.
conducted in 2000 is on single daily use of aminoglycosides in endocarditis therapy according which single daily treatment is more efficient and safer.
efficacy is obtained with pharmacokinetic studies and safety is about decrease in nephrotoxicity.27 in the study of ward et al., in 2009, on applying single daily gentamicin in gynecologic-related infections, results were in a way that in applying single daily gentamicin efficacy and application safety was higher due to decrease in toxicity and is affordable.
proving efficacy in this study was through pharmacokinetic studies, and measuring concentration, half-life, and the highest serum concentration.28 in the study of turnidgo et al.
on pharmacokinetic characteristics and aminoglycosides’ dosage, it has been concluded that in the application of gentamicin, efficacy is higher (via pharmacokinetic studies and measuring concentration, half-life, and vd) and nephrotoxicity is lower.29 the abundance of the highest serum concentration, and high half-life and distribution volume and decrease in drug clearance in single dose group causes drug retention in serum and considering concentration dependency nature of drug, cytotoxic effect grows; so with lower clearance and serum pae of drug, this process becomes useful and increases drug effect and in this way it has been proved that in single dose group efficiency is higher than that of divided group.
however, since we did not have access to laboratory tools of such measurements, we do not have an exact explanation about this efficacy increase but we can explain about increase in gentamicin efficacy in single dose method considering findings of our study and increasing resistance to these drugs, in spite of their rule in therapy of most of infections, limitations of this drug is a consequence of fear from their aural and renal complications.
on the other hand, using high dose in this drug will have a more effect on gram-negative pathogens.29 other comparative factors were application safety and toxicity reduction in two therapy regimens.
in mentioned studies, application of safety was considered as decrease in drug toxicity, where cr increase and gfr decrease alongside with it, was defined as nephrotoxicity, and just like present study nephrotoxicity decreased in single dose method.
in single dose, damage was lower or at least single dose was not more ototoxic.
it should be mentioned that about ototoxicity, there were not many studies available.
furthermore, in studies above, it had been mentioned to affordability and decrease of working load of health staff and increase in time of caring patients (time effectiveness) in single-dose group, which was due to decrease in using line intravenous (iv), syringe, and injection courses.
also by emphasizing on this point, since a single injection takes place in single dose, and line iv and syringe are needed for injection, so adminesteration costs would be less and since nurses perform one injection instead of series of injections, they would have more time to pay attention to patients and by this way it can be concluded that single gentamicin dose injection would be cost and time efficient.
of course, due to the shift changes of nurses, it was not possible to record data in this field.
efficacy was evaluated using pharmacokinetic studies, measuring concentration and vd and ototoxicity was evaluated using audiometry.
renal status was evaluated using cr and other proteins increase in urine such as proximals and renal tubular epithelial protein and so on and also gfr comparison.30 in these studies, to evaluate renal damage, they considered increase in some urinal proteins such as phospholipids, clara cell, and beta-2 microglobulin as renal damage as well as measuring cr, bun, and gfr.
we were not able to measure urinal proteins resulted from renal damage in urine, so according to initially mentioned points, we used measuring serial of cr, bun, and gfr for this reason where results were in favor of using single dose due to its lower nephrotoxicity.
ronald et al.
conducted a study on applying single aminoglycosides dose in therapy of peritonitis in end stage renal diseases patients.
the result was that applying single daily dose leads to increase in nephrotoxicity and is affordable and causes reduction in working load of nurses (time effective).
in this study, single daily method is suggested for treatment of peritonitis.31 the difference in results of different studies could have various reasons.
probably, difference in lower nephrotoxicity of single dose and equivalent nephrotoxicity in two groups is due to existence of different references for determining cr and gfr thresholds for being nephrotoxic and also different laboratory tools and maybe difference in ototoxicity amount and could be related to audiometry devices and different numbers for determining ototoxicity threshold.
furthermore, perhaps the existence of different statistical tests to analyze, various conditions of patients, different diseases, and pathogens could be effective in these differences.
the existence of these differences calls for further studies in this field.
conclusion according to the findings of our study, in using single dose of gentamicin in patients with sepsis syndrome, nephrotoxicity and ototoxicity amount is less than those of using divided dose.
there was no statistical difference between two groups in terms of age, sex, and number of hospitalization days.
financial support and sponsorship the authors would like to thank the support from the chronic kidney diseases research center.
conflicts of interest there are no conflicts of interest.
@highlight
background: aminoglycosides and mainly gentamicin are the most important antimicrobial agents.
two different methods of administration exist: single and multiple doses.
there has always been a controversy about the less harmful administration method, to minimize adverse effects of gentamicin – deafness and renal insufficiency.
in this study, it was aimed to compare two different methods of administration to figure out the least harmful treatment method.
materials and methods: in a clinical study, eighty patients aged 12–55 years who were admitted with sepsis syndrome were included in the study; they were divided into two groups: the first group received single-dose treatment (5 mg/kg) whereas the second group was treated with multiple doses (1.7 mg/kg three times a day) of gentamicin.
results: the results show that blood urea nitrogen (bun) and creatinine (cr) levels were decreased in the first group.
both blood urea nitrogen and creatinine and also mean glomerular filtration rate was increased in the same group.
in the second group, mean bun and cr levels were increased while the gfr was decreased in the same group.
there was also a gradual increase in gfr in the first group.
gfr <80 was decreased from 20% to 5.1% in the first group while increased from 5% to 27.5% in the second group.
results of audiometric studies show 6.1% hearing problem in the first group and 12.8% in the second one.
conclusions: results of the present study showed that nephrotoxicity and ototoxicity are minimized in single-dose administration compared to multiples doses.
