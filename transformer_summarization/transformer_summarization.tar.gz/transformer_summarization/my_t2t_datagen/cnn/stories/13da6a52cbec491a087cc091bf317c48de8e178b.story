introduction in 2015, 15.7 million family and friends provided 17 billion unpaid hours of dementia caregiving valued at more than $217 billion.1 as the us population ages, the alzheimer’s association (2015) predicts the number of people with alzheimer’s disease (ad) will increase from the present one new case every 67 seconds to one case every 33 seconds by 2050.1 as the disease advances, it becomes more challenging for those afflicted to perform activities of daily living (adl), thereby heightening the need for practical ways for families to assist them.
family caregivers identify dressing as one of the most pressing daily needs.2 although dressing tips are publically available on the internet and in support groups, caregivers often use trial and error methods for 5—6 years before seeking this information.3 moreover, evidence-based interventions to assist caregivers are absent in the literature.
studies on medical textiles and disability wear have focused more on the stigmatizing aspects of patient wear,4 and have not attended to less cognitively taxing dressing approaches.
people with dementia (pwd) become unable to choose appropriate clothing, organize, and sequence self-dressing.
prior research with white and african american family caregivers found that they provided frequent coaching to preserve the pwd’s sense of autonomy and dignity.
over time caregivers became frustrated by repetitive prompting and supported the idea of using a “smart dresser” to automate verbal and pictorial cues.5 notably missing in both the dressing and technology literature is latino/hispanic representation, including those over age 65 who are projected to be the largest ethnic/racial minority in this age group by 2019.6 given the limitations in the literature, our first aim was to gain an understanding of latino/hispanic caregivers’ dementia-related dressing issues and to assess whether there were any culture-related aspects.
the second aim was to obtain caregivers’ impressions of our prototype smart dresser system, being designed to guide pwd in dressing, and to obtain their suggestions for improvements.
conceptual framework the preservation of self model: care recipient to caregiver emerged from a prior inductive qualitative grounded theory study conducted with white and african american family caregivers caring for pwd who had difficulty dressing wherein data trustworthiness and credibility checks are reported.3 the model comprises eight thematic domains, representing stages of caregiving from early through the advanced stages of alzheimer’s disease: (1) maintaining pwd’s dignity, (2) placating, (3) problem solving, (4) facing pitfalls, (5) unpredictability, (6) precipice point, (7) transition time, and (8) self-preservation (see figure 1).
the model posits that caregivers initially attempt to preserve pwd’s dignity by taking the blame for their dementia-related dressing problems.
over time, difficulties escalate and caregivers try problem-based strategies that have meaning to the person to respectfully sustain their dressing involvement, even when physical assistance is necessary.
finally, when caregivers confront serious threats to their physical or emotional well-being due to caregiving requirements, the focus shifts from the pwd to preserving the caregiver’s self.
this model provided the framework and underlying constructs and code categories for the present inquiry to enable an understanding of the similarities and differences in issues and perspectives by latino/ hispanic caregivers.
prior to commencement of the study, the research protocol received institutional review board approval from arizona state university as an exempt study.
method project outreach staff and community liaisons (promotores) recruited participants from summer through the fall of 2014 through personal contacts, support groups, fliers at churches and senior centers serving the latino community in a large urban southwest area of the us.
to be eligible to participate, respondents had to be a latino/hispanic family member or friend who directly helped a person, diagnosed with late early to middle stage alzheimer’s disease, get dressed for at least 5 days a week over a six-month period.
in addition, participants had to be able to converse in spanish (bilingual participants were welcomed), have the ability to hear and speak in a group setting, and give verbal and written informed consent.
caregivers without dressing experience were excluded to ensure information rich participants.
telephone screenings determined final eligibility and gathered additional characteristics of the caregivers and their care recipients.
our sampling goal was not to attain a specific number, but to purposefully engage latino/hispanic caregivers with extensive dressing experiences to foster productive discussions that ultimately result in data saturation.7 participants were recruited to include diversity in gender, role, age, and living arrangements.
focus group procedures the number of participants per focus group was designed to be between 5 and 10, large enough to encourage discussion and small enough to facilitate everybody’s participation.8 sessions commenced after the moderator and promotora helper discussed and obtained signed consent forms.
all forms and handouts were available in both spanish and english.
the same bilingual latina phd-level moderator (cl) facilitated all of the focus groups in spanish (participants’ preference), using the same semi-structured interview guide and funnel technique (global open-ended to focused questions) previously used with white and african american alzheimer’s family caregivers to ensure obtaining comparative data.9 each session lasted approximately 2.5 hours and consisted of the following phases: (1) moderator’s review of session purpose, confidentiality assurances, choice of pseudonyms, invitation for positive and negative input (10 minutes); (2) participants’ discussion of general dementia-related dressing issues interspersed with moderator’s probes to assess, confirm, validate, refute, and elaborate upon thematic issues (one hour, then 10 minute break);10 (3) moderator’s spanish narration of a 5-minute demonstration video showing the prototype dresser’s components, installation, and proposed in-home operation.
given the high cost and complexity of initial prototyping, only one non-mobile dresser system could be built.
consequently, to accommodate the focus groups in three geographically different locales, we developed the video showing an older male actor portraying a pwd using the prototype.
the moderator prompted the participants to discuss acceptability, applicability and usability of the system in general and for each of its features.
they were strongly encouraged to share not only positive, but also negative opinions; and (4) session recap to summarize and validate interpretations with the participants, also known as member checking, to ensure the trustworthiness of the data.
upon conclusion, participants received a $40 honorarium and local caregiving resource information.
the technology technical details of the system plans, which have been published previously,5 are updated here.
the system is being designed as a cognitive assistive device for pwd who have difficulty organizing, sequencing, and completing dressing by themselves.
based on recommendations from the prior non-latino focus groups, we revised our design to now offer personalized verbal and video cues through an ipad (to mimic a tv) placed on top of the user’s bureau dresser.
a computer base station, hidden in or under the dresser, receives inputs from an array of drawer and room sensors, clothing sensor tags, and a privacy camera that can capture body outlines and movement without revealing personal body parts.
the pwd will wear a watch with an imbedded wrist sensor that transmits his/her skin conductance response state to the computer.
custom-designed algorithms parse the data and adjust the type of dressing task guidance, based upon actual conditions, and delivers prompting cues tailored to the user’s situation through the ipad.
potentially caregivers will be able to do other activities or gain respite time until the system notifies them, via a text message that either help is needed or dressing is completed.
the elements of the system (figure 2) and the caregivers’ device interface screen (figure 3) were verbally described to the participants accompanied by handouts in both spanish and english.
analysis we employed a deductive grounded qualitative method to address the study aims.
deductive inquiry starts with an established model, and seeks to ascertain the fit, in different instances.11 in the present study, we explored the fit of the preservation of self model to different participants, namely latino/hispanic caregivers, by replicating the focus group study protocol for data collection and applying the code categories derived from the model.
our analytic approach followed pattern matching using spradley’s principles for qualitative comparisons:12 (a) the similarity principle determines categories by looking for units of information with similar content to the model’s eight domains through constant comparative analysis, (b) the contrast principle directs the search for mutual exclusivity, or exceptions to the study model.
the focus groups were audio recorded and transcribed in spanish then back translated into english by the moderator (cl).
the transcriptions were read line by line by two analysts (dfm & dc) first independently and then together through peer debriefing to clarify the meaning of the raw data and to ensure mutual agreement on the translation.
using an iterative analytic process, data were re-reviewed to code descriptors, categories, and patterns with mapping to the eight themes.
if any discrepancies occurred, the researchers discussed them until they reached 100% consensus.
in stage 1, we coded the open-ended and semi-structured interview data according to the preservation of self model’s domains, and assessed congruent (similar) and non-congruent (different or divergent) constructs or themes.
then, in stage 2, we explored differences related to cultural aspects and regional location.
finally, in stage 3, we conducted an analysis of the caregivers’ impressions of the proposed smart dresser.
data analyses involved question-by-question and line-by-line continual comparing and contrasting of meanings until pattern and data saturation was achieved, signaling completion.8 findings were shared with the moderator and promotores for structural and interpretive corroboration.
the results are presented with thick descriptions supporting interpretive validity and to allow readers to assess the transferability of the findings to their contexts.13 results participants twenty caregivers (4 male and 16 female) all self-identified as latino or hispanic were recruited, enrolled, and participated in the focus groups.
they were predominantly in their early sixties but ranged from 32 to 80 years of age.
the participants were spouses (n = 5), adult children or children-in-law (n = 7), a sister (n = 1), adult grandchildren (n = 3), and paid helper/friends (n = 4).
almost half lived with their care recipients who were mostly in the middle stage of alzheimer’s disease.
on average, the participants have been caregiving for almost five years (m = 4.78 years; sd=1.16), stating that they were either the only person who provided any substantial amount of care (20%), they provided most of the care (50%), or they shared care responsibilities about equally with others (30%).
their caregiving involvement was reflected in the high average number of hours per day they estimated they were actually “doing things” (m = 14.50; sd = 9.02) or feeling they needed to “be there” or “on duty” (m = 22.10; sd = 4.66) to provide help for their care recipients.
the caregivers participated in one of the three focus groups held across the region, which resulted in 9, 6, and 5 session members, respectively.
thematic similarities — preservation of self model congruence the discussions that emerged from the members were first mapped to the constructs and existing codes for the preservation of self model following the deductive approach previously described.11 numerous instances of text aligned with the model’s codes and constructs.
the following section presents sample exemplars to support the model’s fit.
please note the names are pseudonyms, followed by the number of the focus group and transcript page(s) that show the links to the audit trail in support of data credibility.
1. preserving personal dignity latino caregivers readily related the importance of respecting their loved ones by and in the way they dress.
dressing was an integral part of who pwd once were and now it is becoming a stumbling block, a daily reminder of decline, and a task to be increasingly negotiated in a thoughtful manner.
barbara 2/5: “she [mother] has also buttoned the blouse crooked … she begins to button, and i tell her in a way not to hurt her.” canción 1/6 &11: “he very much liked to look handsome, [with] his tie, hat and everything.
but the difference we noticed… if he spilled food on himself we wanted [him] to change and he would say why?
[but if his shirt] was buttoned wrong and we would tell him: look; and he would say: leave me alone… you hesitate a little out of the respect that you have for them but at the same time you want to help them because they can’t do it.” 2. placating many of the caregivers sought to maintain the peace and avoid confrontations over dressing issues by removing incorrect clothing choices and minimizing, not emphasizing, any errors resulting from pwd’s efforts.
jessica 2/5: “my husband… was putting back on the clothes that he had taken off … he couldn’t tell the clean clothes from the dirty ones.
so i would say, “this one you just took off.’ and he would say, “no, no that can’t be” … so i started hiding his dirty clothes… and he would button [his shirt] all wrong.
but i wouldn’t tell him you’re putting it on wrong, i would just tell him it looks a little different and i would fix it.” 3. problem solving over time, caregivers seem to develop a repertoire of useful strategies, ranging from avoidance of known difficulties to motivational approaches that align dressing with favorite activities.
blanca 1/12: “the lady i took care of loved to watch john wayne movies a lot.
she would make me take out all of her blouses from the closet and say ‘no, not that one,’ ‘no, that one.’ i would take it off the hanger and put it on her [and she would say], ‘no, not this one either,’ ‘no, not that one.’ [i could get her to stop by saying,] ‘come on, now get dressed because we are going to watch a john wayne movie.’ she would say ‘oh, okay, okay.
yes, yes!’ she never forgot him you know… she would forget to eat, she would forget to go to the bathroom, and she would forget everything, except john wayne!” 4. pitfalls eventually, the strategies became less successful and problematic behaviors escalated into non-productive situations that were frustrating for both the caregiver and the pwd.
in this example, bathing triggered the resistance to dressing.
lily 1/8: “when i take her out of the tub, she gets out of the bathroom and doesn’t let me dress her.
[i say] ‘come on, let’s get you dressed,’ and she says, ‘no, i don’t want to,’ and there i am with the clothes chasing her all over the house [with her yelling,] ‘no, i don’t want to!’ she has a little chair where she goes and gets into a ball.” 5. progression participants realized that marked personality changes indicated a worsening of the disease and led to more challenging caregiving.
family members experienced great emotional strain when they were yelled at and told to go away.
marta 2/13: “if she [aunt] was in a difficult moment, helping her was going to be hard… it was hardest when she was screaming, ‘go!
i don’t want to see you!’ to not feel bad and take it personally.” 6. precipice eventually the demands of the caregiving situation exceeded the capabilities of the caregiver(s).
this was more noticeable with spousal or older adult caregivers who were frail and had their own health problems that adversely affected their caregiving abilities.
lily 3/9: “my father had someone placed to care for him and didn’t want the help.
he only wanted my mother, but now she uses a walker and can’t do his care.
we would tell him, ‘here is the person to help you’, and he would say, ‘no.’ it was very difficult.” 7. transition families frequently turned to external helpers to buttress their caregiving and protect the older vulnerable caregivers.
they would employ non-family caregivers who could provide the needed services.
bárbara 2/15: “my mother would get tired.
she would stress.
when you are tired, you get impatient, and then he [grandfather] doesn’t want to do things.… so we placed a helper for my mother…half a day for the lady to care for him, and the other half of the day, my mother would care for him.” 8. preservation of the self by the last stage of the model, attention fully shifts from preserving the self of pwd to that of preserving the well being of the family caregiver(s).
competing demands for their own personal health and welfare overcome their capacity to provide the intensity of needed caregiving.
for these caregivers, it meant they sought more full time help, usually trusted latino friends and acquaintances that were known to be warm and loving.
blanca 1/2: “i began cleaning their house and we (the family member and her) began to develop trust and she considered me her friend and i did her, and when i saw she was having problems with her mother i offered [to help] … she didn’t have anybody to leave her with… i offered and i cared for her.
i took care of her with lots of love because she was the mother of my friend.” phase 2: cultural differences the second phase of the study searched for any views or themes that deviated from the model, and found no disagreement with the key components.
as expected, cultural differences did emerge related to the participants’ mexican heritage and christianity’s influence.
latino/ hispanic caregivers frequently attributed caregiving abilities to god’s enablement.
god was seen as underpinning the caregiving situation and engendering the physical and emotional capacity to do the necessary caregiving.
jessica 2/2: “it is difficult… [but] god has given me patience and the love to care for my husband.” several participants mentioned that they viewed the responsibility for elder family caregiving as part of their cultural heritage.
one participant conveyed a long-term family commitment.
barbara 2/15: in mexico, my family didn’t have resources.
there is you and your family, nothing more… .
i’m taking care of my mom now.
we had previously cared for my grandfather until he died at 105 years old.
we were able to take care of him: to feed, dress, bathe, clean his ears, cut his nails and so on.
right now we are starting up with my mom.
we’ve been at it around 4 years and she’s 77 years of age right now … we gladly do it.
i think that it’s part of our mexican-american culture to help our elders.” regional dressing preferences wives reported their husbands had a strong affinity for their western boots, ties, buttoned down shirts, pants and belts, despite their lack of cognitive ability to perform the coordinated maneuvers necessary to apply them.
substituting elasticized sweat suits for these men, while easier to put on, was not deemed acceptable by them for their age and gender in this southwest region.
rosa esther 3/17: “he sees his clothes hanging in the closet, his shirts, his pants, everything he would wear including his boots; everything he wants to wear like before and he can’t.
it’s a problem.
i would like him to be able to dress like before and wear the clothes he has, but i can’t let him.
if i have so much difficulty helping him put on clothes that are easy with elastic and all, how am i going to be able to get his other clothes on him?
it’s very difficult… he can’t use a zipper, he can’t button his shirts or pants … he blames me … i have him dressed in women’s clothing!” changing caregiving values and response to technology participants expressed different perspectives on the cultural expectations for family caregiving and the use of technology.
the dominant view supported a strong cultural preference for caring for one’s elders by the family.
ester 2/22 daughter: “this would work for families who have no other option but to leave their older relatives alone.
but, typically the mexican culture is to be cared for by the family.” several participants, predominantly the paid helpers, noted that not all families are currently able to provide caregiving.
mike 1/17: “lots of people that have dementia don’t have any family here; the family doesn’t want to bother with them.
the caretaker is someone they don’t know (paid helper).” technology usage emerged as a potential aid, especially for the next generation of elders, the baby boomers that are using computers to maintain long-distance family relationships and are open to new advances.
marta 2/21: “with my grandmother, the culture and all of that… the technology was not something she used, but my mom now, she knows… at her job she uses the computer, email.
she learned a lot and if something happens to her or to my dad, this technology would be more acceptable and if it happens that they get alzheimer’s, this would help them….
my dad, he is a very private person, [and wouldn’t want us] to see him.
[naked]” phase 3: impressions of the assistive dressing technology we wanted to learn if the technology system design using an ordinary home, dresser would integrate into caregivers’ routines and home environment and found general agreement and support for this mode.
lily 3/35: “looking at that chest of drawers i think that it would function because i am remembering how my father would get in front and open his drawers… i would ask, ‘what are you looking for?’ he would say, ‘i don’t know.’ he would open the drawers, he didn’t know for what, but he would open them.
if in that moment you tell him, ‘take out the socks and put them on,’ then he doesn’t have to think… with such direction he could do it.” respite participants were queried about whether they might use the 30—45 minute dressing session as a “respite break,” that is, to do something more restful while the system oversees the dressing process.
prior research has found that this short interlude, when used to do something perceived as pleasant by the caregiver, helped to reduce caregiver stress.14 most participants agreed that they’d welcome a break to rest or complete other tasks.
bárbara 2/31: “for me, the benefit is being able to rest.
having something the person can do for themselves with just a little bit of help from technology, well, that would give me a little time to rest, or to do other things i have to do.” jessica 2/31: “i also think that the benefit is not only to dress but the sensor also helps because they won’t get out without you knowing and that helps a lot.
because one gets very tired, you dose off and fall into a deep sleep … it will alert me if he wanders out of the room.” technology benefits caregivers were then asked an openended question to query the possible benefits this technology might offer them.
they identified the following (see table 1): validates memory loss caregivers saw the technology’s potential to provide a critical source of information to inform family members who did not recognize or denied their relative’s memory loss.
they felt recording the time to complete dressing, how many prompts, and the number of dressing errors as useful measures to help recognize cognitive and functional declines over time.
marta 2/19 & 20: “in the beginning, there were [family] arguments that were like fights.
i think a system like this would have helped convince those who didn’t believe us.
‘look, it is noticeable that she is not remembering, she is not functioning.’ and it would have helped us to talk with and show the doctor.” empowers user participants liked the way the system adjusted to the person’s situation and encouraged self-dressing.
they felt as if they had taken away dressing independence out of necessity and now might be able to return some, if not all, independence in dressing.
laura 2/18: “he would feel more comfortable this way and feel useful instead of being handed everything (by wife).” always talks in a calm voice some caregivers reported interpersonal difficulties when trying to repeatedly guide dressing routines.
most had noticed increasing tensions due to resistance over dressing, frequently resulting in louder tones and more angry voices that only worsened the situation.
they valued dress’s persistent neutral calm voice.
lily 3/36 & 37: “i saw it with my father, if my mother gave him an order he did not want to follow it … i believe it is very important that it be a calm voice that is nice.” sherlyn 3/36&37: “a soft loving voice … if a man’s, not macho.” mental and physical exercise participants identified an activity benefit from encouraging pwd to dress themselves by exercising not only their minds, but also their bodies.
blanca 1/13 & 14: “when they have alzheimer’s, they are definitely sitting doing nothing, and the only thing they are doing is stiffening their muscles.
i think that’s [dress system] perfect, because it helps to exercise their hands, their legs, their mind.” promotes privacy and dignity the caregivers did not view the technology as violating their privacy because they viewed it as offering a new means to help maintain or achieve privacy for the pwd during dressing.
many participants noted not only they were uncomfortable being in the presence of an elder while they undressed but also they felt it diminished their dignity.
marta 2/23: “i am seeing that the sensor would let us know [dressing status] even though we close the door.
she will be able to get dressed alone … that is what she likes, to be private.
the same with my grandfather, [he would yell] ‘i want to be alone to dress’.” barriers to technology usage equal time and emphasis was given to querying for negative concerns about the technology and the discussion revealed the following: wrong stage of ad several recognized that their pwd, now in the advanced stages, would not be able to use this device and affirmed our plans to target people in late early to early middle stages.
sherlyn 3/45: “i think that that system is for a person who’s in an intermediate stage; someone whose illness has already begun and is now progressing, but not for someone whose disease has already become very advanced … if they have it in front of them they won’t know what to do even though it tells them.” visual and sensory perception problems others raised concerns that their pwd’s existing problems with understanding sensory inputs might affect their usage and suggested accommodations.
one had a care recipient that experienced tv induced hallucinations and was concerned that the ipad screen “talking” would create a similar situation.
estrella 3/36: “my mother has very poor vision so the size for her to be able to see the pictures or letters has to be larger.
when the television is on, she isn’t looking at it, but she says, ‘see there that lady?’ … i just realized that the people that she was telling me about were in the news.
so i wonder if she sees a device like that [will it cause similar confusion?
].” changes the routine introducing new routines to pwd is challenging and often evokes resistance.
caregivers voiced the need for motivational encouragement and reinforcement until it becomes an established routine.
estrella 3/31: “it could work if i explain it to her and tell her, ‘look, we are going to try this.
we’re going to play.
let’s see what you think of the game.’… she might accept it today, but tomorrow she won’t want to.
and i convince [her again] in the next week and again, it might function in that way.” caregivers’ need to “be there.” caregivers wrestled with the desire versus the need to be there with and for the pwd.
some believed the person still made a connection and knew at some level the caregiver was there and loved them.
other participants relinquished being there to trusted friends to ensure oversight safety.
julia 1/14: “personally, i think it is very important to make them feel that we are there with them, but there are moments they may get mad with us and say ‘don’t help me,’ but even with that anger, i say they want us.” canción 1/14: “we looked for a person when i couldn’t be there all the time, but she would say, ‘no, no, i don’t want that’.
she would only use the person to talk with, not to do things for her.
but she [helper] is there to watch over her, to see what is going on.” computer instability and lack of reliability one participant did not see the possibility of giving up supervising dressing to a computer due to technology’s lack of reliability and vulnerability to network and performance problems.
julia 1/17: “maybe it would save some time for a caregiver, but if something happens, you can’t be doing other things; computers fail and one has to always be alert.” affordability of technology how to offset the high cost of technology for lower income people was prominent in the discussion.
participants suggested several ways to make future access to this type of technology more affordable should it be commercialized.
martha 2/32: “i imagine the person will get to a point they will advance or something will happen physically, and the [end] time has come.
let’s say it cost two thousand dollars.
i return it and there’s a credit.” jessica 2/32: “it would be easier to rent because the time will come when you will no longer use it.
so another person can rent it again.” device features and recommended modifications participants were queried about the smart dresser features to gain their impressions, cultural relevance, and solicit recommendations.
dresser first we asked about their usual choice of clothing storage to see if it would be a closet, wardrobe, or anything other than our plans for a dresser bureau with drawers.
chest of drawers was the local term and the use of drawers was universally accepted.
blanca 1/23: “chests of drawers have always been used … since we were children”.
we planned to integrate personalized music into the coaching to divert agitation and the participants supported this idea if the music was familiar to them.
jessica 2/24&25: “but don’t put on loud music, [use] something that will relax them … music that is most pleasing to them.” we asked about mounting a mirror on the side of the dresser to allow those who can use it to check their appearance, and everyone agreed this would be helpful.
estrella 2/ 28: “my mother likes to have the mirror there because she still recognizes herself.” adding a chair next to the dresser was recommended in all the groups for comfort and balance safety.
estrella 3/42: “they can lose their balance when they are not sitting down.” fiducials fiducials, clothing tags similar to a barcode that allow the camera to detect clothing orientation without seeing body parts, received mixed reactions.
two caregivers thought their person with dementia would not notice or remember the tags while others recommended blending them within clothing designs to disguise them.
jessica 2/26: “well, i think we would use it [tags] in the house, but not to go out.
maybe they won’t notice them so much, but we would.” dialogs from watching the video simulation of the dressing coaching, participants recommended more personalized approaches to the audio dialogs by using culturally familiar endearments and nicknames and possibly their own voices and pictures.
ester 2/24: “a very cordial message, ‘mami, it’s time to get up and get ready, open the top drawer’… try to calm her down (calm soothing voice), ‘mami, don’t worry, that is not the drawer, but don’t worry, look, let’s start over again.
let’s open the top drawer first and there is your blouse,’ like that.” bárbara 2/21: “i think it should be the voice of the person that is caring for them so she would feel more familiar and would think the person is there.” others, who experienced fighting over dressing, disagreed, preferring a new “neutral” voice.
run-in adjustment period three participants brought up the need to test the system’s operation and capability to tailor to the pwd’s needs.
one recommended that we have a planned run-in period to test operations and tweak the settings to optimize customization.
martha 2/30: “have a period like a week, then adjust the system because it would function perfectly, let’s say in jessica’s house, using everything.
then take out some things, because that is how it would work better for barbara in her house … accept it like it is (with all the features), install, then adjust it.” affirming overall, the vast majority of the participants (95%) supported the effort of designing new technologies for caregiving in general, and this intervention in particular.
blanca 1/24: “well, that it is perfect and it makes me happy that they continue to come up with more, more help for all the persons that need it … you guys are going through the work to come up with all of this, it is very good.” paloma 3/47: “i hope that there will be things like this, if one day i get dementia.” discussion notably, latino/hispanic caregivers reported similar dementia-related dressing issues to those previously reported by white/african american caregivers.
the behavioral manifestations of middle stage alzheimer’s disease related dressing issues appears similar across cultural groups and aligned with the constructs and themes from the preservation of self model without any major deviances.
for example, latino caregivers similarly tried to offset the care recipients’ difficulties by taking the blame for missteps and using a variety of strategies to encourage dressing.
knowledge about caregiving also primarily came from family, friends, and through trial and error.
transcripts revealed that many family members used patterns of communication that made unrealistic demands on pwd, and resulted in bilateral frustrations.
prior research has indicated that non-latino pwd and their caregivers are infrequently seen by clinicians in the early disease stages and that families attempt to negotiate behavioral changes and difficult interactions without professional guidance.3,15 we found similar findings in this study and recommend more outreach and earlier caregiver referrals to local resources for more proactive caregiver dementia skill building and support.
cultural differences influenced the response to needing help with dressing.
familismo, or being cared for by family members, has been a strong tradition in latino families.16 we found that some older family members worried that this tradition was being weakened by the “american” lifestyle that they see as devaluing family caregiving.
gelman’s recent in-depth analysis of familismo reported discrepant views on its current cultural relevance.
some family members believed it facilitated caregiving by reinforcing traditional expectations of helping, while others disavowed its’ contemporary relevance.17 others report that baby boomer caregivers appear more open to outside service supports to succeed in juggling caregiving, work, family, and social commitments.18 we did find some latino/hispanic caregivers were open to employing lay friends or helpers to provide care.
four participants, who were paid helpers, reiterated a theme of “love” for older people and a need by the family as the motivation to trade other similar paying employment for this more personally gratifying position.
they also mentioned being “trusted” by the families, coming from within the same community, and being known to them, as important factors.
when queried, however, they did not relate any concerns about use of this technology eroding their employment opportunities.
from the technology perspective, a surprising finding was the participants’ level of enthusiasm, in response to this technology in particular, and the potential for caregiving technologies in general.
all participants agreed with the intent to develop and use dress with pwd, but they did emphasize matching it to the right stage of dementia and investigating its’ limits.
one participant questioned whether a voice coming from the dresser would cause hallucinations.
concerns about inducing hallucinations, from using interactive prompting technologies, have been raised by critics, but they have not occurred in the auditory coaching research reported to date.19,20 we will, however, specifically observe for any new onset or exacerbation of hallucinatory experience when the system is tested with pwd.
contrary to expectations of technology critics, the participants viewed this technology as a means to provide privacy by enabling the pwd to dress without the intrusiveness of a caregiver being present.
in addition, prior research has shown that it is very stressful for adult-children to dress a parent, especially of the opposite gender.3 a recent qualitative study of eight mexican-american sons who are providing personal care to their mothers offers further insights into this emerging phenomenon.21 having an automated dressing aid was viewed as a buffer; reducing the intrusiveness and intimacy related stressors inherent with hands on dressing assistance.
caregivers also reported difficulties with family members and doctors who did not believe them when they reported cognitive concerns.
they saw the technology’s event record as a means to provide objective documentation to measure and track the decline in dressing abilities.
they hoped this type of information would be useful to gain family and provider recognition of the seriousness of the memory loss and impairment of self-care abilities.
they also endorsed the cognitive stimulation and physical activity the system offered the pwd, as a means to “exercise their minds” and move their bodies to dress.
rather than passively sitting and having things done to or for them, the caregivers saw the technology as offering a new way to engage pwd.
the study findings did reveal the need for the technology to display more culturally sensitive training and prompting video-clips.
the current video, featuring a white male dyad, was seen as being too “cold,” with need for more affection and familiar endearments.
caregivers mentioned that they typically embrace and are more demonstrative and asked if we could use additional words/pictures/songs to display more “warmth.” as a result, we see the need to develop a new version, with video clips and promptings in spanish, with a latino/hispanic dyad using the recommended interaction style.
we also found that the clothing categories included in our system narratives needed to be expanded given the appeal of “western wear,” especially for the latino men in this region.
one husband resisted wearing easier to put on sweatpants because he insisted that “men only wear pants with belts.” as a consequence, we will alter our scripting to include narrative options for southwest regional style rope ties, boots, and belts and consider other meaningful items.
we will approach these alterations as options and not stereotypes by constructing alternative scripts that are congruent with the model’s theme of preserving personal dignity, whether that sense of personhood is exemplified through the pwd workplace “uniforms” or their preferred home or leisure time apparel.
participants suggested integrating the fiducial tags into the clothing designs to make them less noticeable.
currently for prototyping, the fiducials offer the most cost effective and reliable way to provide system testing.
we are monitoring the rapidly developing market for sensor imbedded fabric and plan to integrate that technology when it becomes economically feasible.
the latino caregivers in this study identified that the dress technology offered a new way to make the lives of those they cared for better by promoting autonomy, exercise, and dignity, all aspects called for in developing interventions for older adults.22 although person-centered care has been mandated by federal legislation, substantial barriers exist that include negative beliefs about its feasibility for people with cognitive impairment given co-morbidity, culture, race, ethnicity, language, and socio-economic challenges.23 it is important to note that the latino caregivers viewed this technology intervention as a respectful way to help pwd by taking into consideration their individual abilities, needs, and cultural preferences.
given our present “internet of things,” comprised of 25 billion electronic devices connected to the internet this year and 50 billion of these devices forecasted by 2020, along with the emerging “internet of things” business models, there is a tremendous opportunity for person-centered innovations in technology.24 emanating from this research is a model that portrays that perspective to guide future developers.
it features the pwd at the center surrounded by their cultural and caregiving milieu.
technology appears in the outmost circle, influenced by and needing to be responsive to the inner realms (see figure 4).
limitations we were mindful that “structured focus groups run the risk of limiting the discussion to the topics the researchers want to hear about rather than revealing the participants’ own perspectives.”8 in response, we did employ a latina cultural insider as moderator to enhance trust, and she not only followed the semi-structured interview guidelines, but also offered participants multiple opportunities to add their own perspectives.
generalizability does not conceptually fit with small samples chosen specifically for their homogeneous characteristics typical of qualitative research.25 thus we do not suggest extrapolation of our findings beyond our sample, but offer numerous illustrative quotations to enable readers to determine the depend-ability and transferability of findings to their settings.
from the technology perspective, given the initial stage of technology development and budget constraints, we did not have three fully developed systems for the focus group demonstrations.
instead we showed a video of the prototype mock up version with handouts showing pictures of the components.
the caregivers, however, did not have any apparent difficulty perceiving the system design, features, and intention.
conclusions we engaged latino/hispanic caregivers as partners in our smart dresser system development.
we found that they had predominantly similar dementia-related dressing issues to previously reported research with white and african american caregivers, but several differences due to cultural perspectives, linguistics, and geographic location.
both the similarities and differences have important implications for future technology iterations as we aim to address the needs and desires of as many diverse caregivers as possible.
our participants viewed dress as a new and needed means to record memory loss and its’ progression, provide mental stimulation, physical exercise, and privacy in dressing, using an aide that always has a calm voice and never gets upset when repeatedly prompting the pwd.
these are fertile areas for hypothesis generation.
future research is needed to ascertain whether the caregivers’ positive attitudes towards this technology translate into technology adoption and improved outcomes when dress is ultimately tested as an in-home intervention for with pwd and their caregivers.
meanwhile, the participants’ enthusiasm for embracing new technologies to assist with caregiving should encourage other technology developers to pursue other innovative offerings, mindful of endusers’ wants and in alignment with our person-centered model for cognitive adaptive intervention techologies©.
in summary, findings from this study uniquely document the impressions and input of latino/hispanic caregiving participants, a greatly under-represented minority group in the technology intervention development literature, and contribute to bridging the digital disparities divide.
@highlight
objective to gain an understanding of latino/hispanic caregivers’ dementia-related dressing issues, their impressions of using a “smart” context-aware dresser to coach dressing, and recommendations to improve its acceptability.
method the same latina moderator conducted all the caregiver focus groups.
she followed a semi-structured interview guide that was previously used with white and african american family caregivers who experienced alzheimer’s disease related dressing challenges.
from that study, the preservation of self model emerged.
using a deductive qualitative analytic approach, we applied the thematic domains from the preservation of self model to ascertain relevance to latino/hispanic caregivers.
results twenty latino/hispanic experienced caregivers were recruited, enrolled, and participated in one of three focus groups.
the majority were female (75%) and either the spouse (25%) or adult child (35%).
striking similarities occurred with the dressing challenges and alignment with the preservation of self model.
ethnic differences arose in concerns over assimilation weakening the latino culture of family caregiving.
regional clothing preferences were noted.
technology improvement recommendations for our system, called dress, included developing bilingual prompting dialogs and video modules using the local vernacular to improve cultural sensitivity.
caregivers identified the potential for the technology to enable user privacy, empowerment, and exercise as well as offering respite time for themselves.
conclusion findings suggest dementia-related dressing issues were shared in common by different racial/ethnic groups but the response to them was influenced by cultural dynamics.
for the first time latino/hispanic voices are heard to reflect their positive technology impressions, concerns, and recommendations in order to begin to address the cultural digital disparities divide.
