1. introduction the extracellular matrix (ecm) is composed by a variety of proteins, glycoproteins, proteoglycans, and polysaccharides that are endowed with distinct physical and biochemical properties [1].
for long the ecm has been viewed as a scaffold with mere mechanical properties aimed at maintaining tissue morphology.
a growing amount of evidences support instead the notion that ecm is surprisingly versatile and dynamic and can profoundly affect cell behavior [2].
in fact, through direct or indirect mechanisms the ecm modulates the function of the adjacent cells during development but also in the adulthood under normal as well as pathological conditions [3].
for its crucial role in assuring proper tissue homeostasis and function, the deposition and remodeling of the ecm components are tightly regulated [4].
if this regulation is lost, the matrix loses its organization and this leads to an impaired cell behavior and to a consequent break down of tissue function and homeostasis.
in fact, abnormal ecm is one of the most distinctive traits that can be observed in many pathologies, including fibrosis and cancer [5].
cancer is one of the major causes of mortality accounting for millions of deaths worldwide.
several ecm components have been shown to play a critical role, not only during its onset but also during metastasis, which is responsible for the 90% of all the cancer-related deaths [6,7,8,9,10].
in this context, the activation of proteases leads to the release of matrix fragments that act directly on cancer cells influencing their viability, apoptotic rate and/or metastatic potential [11,12,13,14,15,16].
matrix remodeling leads also to the release of growth factors and cytokines of which the ecm represent a vital reservoir.
the thus altered tumor microenvironment not only directly affects tumor cell behavior, but also other important processes such as angiogenesis.
angiogenesis, the process of the formation of new blood vessel from pre-existing vasculature, plays an indispensable role both in physiological and pathological conditions.
it occurs during development and maturation, as well as during the healing of injured tissues and reproduction in the female population and is indispensable to grant the supply of nutrients and oxygen to the tissues.
the angiogenic process is also usurped by a number of pathologies including inflammation, autoimmune diseases and cancer [17].
notably an imbalanced vascularization can contribute to the development of these diseases [18].
in autoimmune diseases an excessive angiogenesis can promote inflammatory responses and, as a consequence, exacerbate the disorder.
in cancer, angiogenesis is required to allow and efficient growth of the restlessly proliferating tumor cells.
the imbalanced angiogenic signals released during tumor onset and progression lead to the development of aberrantly tortuous and leaky vessels.
the altered vasculature not only represents an important root for metastatic spreading, but also affects the delivery of chemotherapy drugs [19,20].
along these lines, a recent view about the therapies targeting angiogenesis is that they should induce the formation of a proficient vasculature that would favor the distribution of the chemotherapy drugs within the tumors.
angiogenesis can be not only an accomplice of the disease, but also be its direct cause as demonstrated for macular degeneration and diabetic retinopathy [21].
for its primary role in tissue trophism and homeostasis, the angiogenic process is tightly regulated by a plethora of factors.
in fact, the list of molecules affecting angiogenesis is growing and includes growth factors, bioactive lipids, complex polysaccharides and also several ecm components.
the most important cell type activated during the angiogenic process is the endothelial cell (ec).
these cells form the inner cell lining of blood vessels and are present as a single-layered epithelium adjacent to the lumen of the vessels.
ecs are normally quiescent and characterized by a very low proliferative rate.
in part this is due to the strong anchorage of these cells, to the tight cell junctions that grant structural continuity and limit vascular leak.
the release of growth factors and the onset of strong pro-angiogenic stimuli loosen these restrictions.
as a consequence, ecs change their behavior and begin to proliferate and migrate invading the surrounding tissues.
this is followed by a resolution state where the ecs re-acquire the quiescent state.
despite a gradient of cytokines or other agonists is necessary to prompt ec migration, the movement of these cells is strictly dependent on their adhesion to the ecm and also for this reason these constituents play a key role in this process [22,23,24].
the number of ecm molecules that have been shown to influence angiogenesis is increasing and this depends not only on their adhesive properties but also due to their intrinsic capacity to directly affect ec function.
given the variety of ecm constituents, to study the contribution of the microenvironment in this context is extremely complex.
to exacerbate the scenario, the fragmentation of ecm molecules occurring during remodeling leads to the formation of peptides that can often display opposite effects compared to the intact molecules of origin [25].
the aim of this article is to review a number of ecm molecules displaying a prominent role during angiogenesis and to summarize the major mechanisms impinging on ec function thus affecting the formation of new blood vessels.
a schematic representation of the major classes of ecm molecules involved in angiogenesis is reported in figure 1 and the molecules/fragments taken into account along with their respective functions summarized in table a1.
2. thrombospondins: endogenous angiogenesis inhibitors thrombospondins (tsps) are a family of large ecm glycoproteins including five members (tsp-1 to tsp-5) [26].
tsp-1 and tsp-2 have been extensively studied for their antiangiogenic properties.
tsp-1 was the first to be identified as a naturally occurring angiogenic inhibitor [27].
since this seminal paper, numerous have been the studies indicating that both tsp-1 and tsp-2 inhibit angiogenesis in multiple in vitro and in vivo assays [28,29].
accordingly, the over-expression of these two molecules by tumor cells is associated with an impaired tumor growth in mice [30,31,32,33].
interestingly, the simultaneous over-expression of both the molecules leads to additive effects, suggesting that tsp-1 and tsp-2 act by distinct mechanisms [31].
tsp-1 and tsp-2 specifically induce apoptosis in microvascular ecs leading to an impaired ec function and prejudiced tubule formation in vitro [34,35].
the molecular mechanism involves the binding to the transmembrane glycoprotein cd36 [34,36,37].
the interaction with the receptor results in the association of src family kinases fyn or yes, which in turn lead to apoptosis through the phosphorylation of c-jun n-terminal kinase (jnk) and caspases [38].
it is interesting to note that the ecm non only supports cell survival through integrins engagement, but can also negatively affect cell viability in some circumstances.
in order to pinpoint the region(s) of tsp-1 responsible for the anti-angiogenic activity, synthetic peptides based on the protein sequence have been created and employed [28,35,39].
one of the first synthetic peptide generated contains the csvtcg amino acidic sequence and was active in inhibiting the fgf-2-induced neovascularization of the rat cornea [28].
some of the active sequences mapped are common to both tsp-1 and tsp-2, which indicates that they share common mechanisms of action.
tsps determine the ec phenotype through the binding to cell membrane or cell-associated molecules including integrins, cd36, cd47 and proteoglycans [40].
the multiple interactions on the ec surface may result in the assembly of molecular complexes able to trigger several signal transduction pathways, which may be the key of their strong effects.
tsp-1 interacts and modulates the function of several cytokines/growth factors, proteases and ecm molecules [41], which suggests the possibility to develop new anti-angiogenic drugs [39,42,43].
both tsp-1 and tsp-2 contain the thrombospondin type 1 repeat (tsr), an essential module for the binding to β1 integrins, to cd36 and to the transforming growth factor β (tgf-β) [44].
notably, a therapeutic agent based on the second tsr has been developed [44] and is in clinical trials for several malignancies [45,46].
thus, the studies on tsp-1 and tsp-2 have lead to important findings that have the translational potential to generate new promising tools for clinical practice.
the drugs based on endogenous antiangiogenic molecules may in fact enclose the advantage not to induce harsh side effects during the treatments.
3. fibronectin: key function in pathological angiogenesis fibronectin is strongly expressed around developing vessels during embryogenesis but is barely detectable in the adult vasculature [47].
nonetheless, during pathological angiogenesis, the expression of the molecule is turned back on [48,49].
fibronectin forms dimers composed of two similar monomers, which are organized into type i, type ii and type iii repeats.
different isoforms are present and are generated by alternative splicing within the eiiia, eiiib and v regions.
fibronectin interacts with different ecm components including tenascin, thrombospondin, heparin, collagen and fibrinogen [50].
however its effects do not only rely on the molecular network with which fibronectin is connected.
in fact, through the rgd motif, fibronectin binds to integrin receptors and in particular to integrin α5β1, which is markedly up-regulated during tumor-associated angiogenesis [51].
the deposition of fibronectin in a 3d cell-derived ecm appears to be imperative for matrix assembly and vascular morphogenesis [52].
fibronectin prompts ec survival, whereas the blockage of its polymerization induces an impairment of ec proliferation and tube formation both in vitro and in vivo [48,53].
the importance of this molecule in angiogenesis is highlighted by the fact that, whereas the lack of the splice variants eiiia or eiiib does not lead to obvious defects, the double knockout mice show hemorrhages and severe vascular defects [54,55,56].
given its wide distribution and interaction with other molecules involved in angiogenesis, it is likely that the altered expression of fibronectin observed in a number of pathologies such as fibrosis and cancer, may significantly impact on the development of new vessels and on the efficacy of anti-angiogenic therapy.
4. collagens: a major source of anti-angiogenic fragments the synthesis and deposition of various collagens is known to affect ec survival and vessel formation.
those principally involved in angiogenesis are: type i, type iv, type xv and type xviii collagen.
type i collagen is the main ecm constituent to which proliferating ecs are exposed in an injured tissue.
the interaction of collagen i with α1β1, α2β1, ανβ3 and ανβ5 integrins induces the activation of mitogen-activated protein (map) kinase pathway supporting ec survival [57,58].
moreover, the binding of collagen i to α1β1 and α2β1 integrins, suppresses c adenosine monophosphate (camp)-dependent protein kinase a (pka), resulting in the reorganization of the actin fibers and in cell shape changes [59].
collagen i is also important for lumen formation since it is required for the coalescence of pinocytic intracellular vacuoles [60,61].
thus, a major role of this collagen can be recognized in the first stages of the angiogenic process.
type iv collagen is one of the major constituents of the basement membrane [62,63], and is composed of six genetically distinct α chains (α 1–6) [64].
ec adhesion and migration are prompted by the triple-helical part of collagen iv, whereas the non collagenous domain nc1 does not support ec migration.
instead, the nc1 domains compete with intact collagen iv for the binding to integrins, inhibiting ec proliferation and tube formation [65,66].
in the early stages of tumor development, collagen iv exerts a pro-angiogenic function, once cryptic domains are exposed by mmp cleavage [67].
in contrast, in the late stages, it displays anti-angiogenic properties due to the release of arresten, canstatin and tumstatin derived from the α1, α2 and α3 chains, respectively [68,69,70].
arresten inhibits ec migration and tumor growth through the engagement of integrin α1β1 and inhibition of map kinase [65,71].
similarly, canstatin also inhibits ec migration and tube formation [72] and impairs angiopoietin-1-induced angiogenesis and lymphangiogenesis [73].
the mechanisms of action involve the binding to integrins ανβ3 and ανβ5, and inhibition of protein kinase b (pkb) also known as akt focal adhesion kinase (fak) and mammalian target of rapamycin (mtor) [74].
in addition, canstatin induces fas-dependent ec death, similarly to what observed with tsps, despite through different mechanisms [75].
finally, tumstatin binds to ανβ3 integrin though two distinct sites and displays anti-angiogenic and anti-tumor activity [76,77].
thus, as observed for other ecm molecules, collagen iv displays an opposite function once the angiogenic stimulus is turned on and the proteases are activated.
this likely represents a feedback mechanism able to halt the persistence of the pro-angiogenic signals.
it can also be pointed out that the various fragments activate different molecular pathways thus amplifying the mechanisms of action.
type xv collagen is a component of the vascular basement membrane [78].
its carboxy-terminal globular non-collagenous (nc) domain called restin displays a high homology with endostatin and inhibits ec migration [79,80,81].
type xv collagen deficient mice develop normally but display collapsed capillaries and ec degeneration in the heart and skeletal muscle, and this suggests that the molecule could exert an important role in microvessels stabilization [82].
type xviii collagen is found in different epithelial and vascular basement membranes.
the proteolitic cleavage of the nc1 domain of the α1 chain by cathepsin l, b and k or mmps releases the anti-angiogenic fragment endostatin [83,84].
endostatin significantly reduces ec invasion in vitro through the blockage of matrix metalloproteinase 2 (mmp-2) [85].
the fragment also inhibits fgf-2 and vegf-induced ec proliferation and migration [86,87].
relying on its anti-angiogenic properties, endostatin displays potent anti-tumoral effects [88,89,90,91].
remarkably, the treatment with the recombinant fragment induces vessel normalization and, as a consequence an improved chemotherapy efficacy [92].
clinical trials have also been attempted with seesawing results: some deluded the expectations [93,94], whereas others demonstrated a potential benefit [91,95].
it is possible that this may depend on the tumor type and the quality of the vasculature characterizing each tumor.
in addition, the microenvironment of the specific tumors and its intrinsic matrix composition may also impinge of the activity of endostatin.
taken together, first the importance of this family of molecules in angiogenesis is highlighted by the fact that some of the members are intrinsic components of the vascular basement membrane.
given that vessel integrity affects vascular efficacy, an altered expression of these molecules may profoundly affect drug delivery and efficacy.
second, the pivotal role of this family in this context is that it represents an important source of fragments displaying strong angiogenic activities.
as discussed for tsps, these fragments represent a vital reservoir for the development of new drugs that may display high anti-angiogenic activity and low toxicity.
5. laminins: multiple chains for multiple functions the expression of laminins varies between cell types and during development [96].
several sequences within the α, β and γ chains of laminins play a role in angiogenesis.
the activation of mmp-9 following hypoxia leads to the degradation of laminin, which associates with an enhanced vascular pruning [97].
the rgd and ikvav peptides present within the laminin sequence display important angiogenic functions, but to exert their activity they need to be unmasked by proteases [98].
the α4 (in particular laminin 411, α4:β1:γ1 and laminin 421, α4:β1:γ1), and α5 chains of laminin are the most abundant in the vascular basement membranes and thus play a major role in this context [99,100].
in particular, the α4 chain of laminin represents a high affinity ligand for ανβ3, α3β1 and α6β1 integrins and is required for ec adhesion and migration [101].
interestingly, the α4 chain and its receptor melanoma cell adhesion molecule (mcam) are highly expressed in the blood vessels of renal cell carcinomas and the levels of expression may serve to predict the patients’ outcome [102].
the importance of laminin 411 is also highlighted by the fact that, by activating the notch-δ-like 4 signaling pathway, may regulate tip cell formation and affect vascular density [103].
on the other hand, laminin α5 chain-based synthetic peptides inhibit angiogenesis and block cell binding to fgf-2 [104].
other studies report a complementary function for laminin α4 and α5: laminin α4 knockout mice show bleeding during embryogenesis resulting in a perinatal anemia, which is rescued 3 to 4 weeks postnatally once laminin α5 expression is turned on [105].
it has also been suggested that laminin 511 is required to maintain the β1 integrin-dependent anchorage of ecs in shear stress conditions and thus may be important to the formation of functional vessels [106,107].
in 3d ec cultures laminin is required for ec aggregation in end-to-end networks and the effect is α6 integrin dependent; the engagement of α6 integrin by laminin increases vascular endothelial growth factor receptor 2 (vegfr2) expression and vascular endothelial growth factor (vegf) uptake by ec [108].
laminin exerts an important role also during ec sprouting, in fact it has been recently demonstrated that, once bound to integrin α6β1, the receptor is sequestered from the podosome rosettes, key structures in sprouting angiogenesis [109].
also for this family of molecules, characterized by different chain arrangements, the effect on angiogenesis is complex and occurs through the interaction and/or activation of major signaling pathways in ecs.
as suggested by the results obtained with the use of the knockout models, the different molecules may display overlapping functions.
interestingly, since these molecules affect ec tip formation and sprouting angiogenesis they may be required in the early stages of angiogenesis.
on the other side, the presence of these molecules in the blood vessels’ basement membrane suggests a role in the maintenance of vascular homeostasis.
6. proteoglycans: complex functions from the protein core and carbohydrate chains proteoglycans (pgs) are complex macromolecules composed of a core protein carrying one or more covalently linked glycosaminoglycan (gag) chains, whose number and type may differ to a great extent [110,111].
pgs perform multiple functions in cancer and angiogenesis by virtue of their polyhedric nature and their ability to interact with different ligands and receptors [112,113,114].
during tumor development and growth, pg expression is markedly modified within the tumor microenvironment impacting on cancer cell signaling and angiogenesis [115].
heparan sulfate pg (hspg) such as syndecans and glypicans are regulators of cancer progression and angiogenesis and serve as biomarkers for early detection and/or as pharmacological targets [116,117,118].
notably, high concentrations of condroitin sulfate pg (cspg), in particular versican and decorin, have been reported in the tumor stroma [111,119,120].
the major pgs affecting tumor angiogenesis are described below.
perlecan is a ubiquitous multimodular proteoglycan consisting of five domains sharing homology with growth factors, immunoglobulins and adhesion molecules [121,122,123].
given its widespread distribution [124,125] and its ability to interact with various molecules perlecan regulates various biological processes.
either via the protein core or the heparan sulfate chains, perlecan binds other ecm components as laminin, fibronectin and ecm1 and several growth factors including fibroblast growth factor 1 (fgf-1), fgf-2, fgf-7, fgf-9 and fgf-18, fgf-binding protein, platelet-derived growth factor (pdgf), hepatocyte growth factor (hgf), activin a, vegf and progranulin [126,127,128,129,130,131,132].
the central role of perlecan in angiogenesis has been demonstrated by several independent studies and in various in vitro and in vivo models [133,134,135].
collectively, these studies indicate that perlecan exerts a pro-angiogenic function by binding and presenting vegf-a, pdgf and various fgfs to their cognate receptors and modulating their activity [136,137,138,139,140,141,142].
during tumor angiogenesis and cancer growth the perlecan protein core is degraded by proteases and the heparan sulfate chains are removed by heparanases.
as a consequence, a plethora of growth factors trapped within the molecule are released affecting angiogenesis and cancer progression [114,143].
interestingly, perlecan expression is often deregulated during cancer progression, generally leading to enhanced tumor invasiveness [144,145,146,147].
this may likely depend both on its structural role in the vessels’ basements membranes and its direct role in affecting angiogenesis.
endorepellin is the c-terminal processed form of perlecan and, in contrast to the pro-angiogenic n-terminal domain, displays an opposite function: it inhibits ec migration, capillary morphogenesis, and in vivo angiogenesis [148,149,150,151].
the angiostatic function of endorepellin is in part due to its interaction with α2β1 integrin and activation of a signaling cascade leading to dissolution of the actin cytoskeleton, disruption of focal adhesions and the inhibition of ec migration [149].
furthermore, the engagement of α2β1 integrin by endorepellin triggers the activation of the tyrosine phosphatase src homology region 2 domain-containing phosphatase-1 (shp-1) which, in turn, dephosphorylates and inactivates various receptor tyrosine kinases (rtks) including vegfr2 [152].
endorepellin is also able to directly interact with vegfr2 at the ec surface inducing the transcriptional repression of hif-1α and vegf-a [153].
the binding of endorepellin with vegfr2 is concurrent with its binding to α2β1 integrin and the dual receptor antagonism concur in the inhibition of ec migration and blood vessel maturation [154,155].
more recently, it was also demonstrated that endorepellin evokes autophagy via vegfr2 signaling contributing to the angiostatic function of the fragment [156,157].
thus, similarly to what observed with collagens, the cleavage of perlecan gives rise to a fragment displaying an opposite function, which may serve to counterbalance the angiogenic stimulus.
decorin is a member of the small leucine-rich proteoglycan (slrp) family and its structural features enable the binding to numerous other ecm molecules, growth factors and cytokines modulating angiogenesis with different mechanisms [158].
the binding to type i, type vi collagen and fibronectin affects collagen fibril formation and modulates the ecm rigidity and stiffness, structural properties known to influence angiogenesis [159,160,161].
as other ecm molecule, decorin modulates the activity of pro-angiogenic growth factors including vegf, pdgf, fgf, insulin growth factor (igf) and angiopoietin by sequestering them and influencing their availability [162,163,164,165].
decorin controls also the bioavailability of tgf-β whose release depends on the activity of different proteases involved in angiogenesis [166,167].
furthermore, soluble decorin is a high affinity antagonistic ligand for several key receptors tyrosine kinases including epithelial growth factor receptor (egfr), hgf receptor, igf-1 receptor and vegfr2 [168].
the engagement of decorin with cell surface receptors can either activate or inhibit the function of the receptor, depending on the physiological state of the tissue [169].
more recently, decorin has emerged as a soluble pro-autophagic cue [170].
this effect is mediated via a direct interaction with vegfr2 which causes activation of amp kinase signaling that ultimately culminate in a paternally-expressed gene 3 (peg3)/beclin1/microtubule-associated proteins 1 light chain 3a (lc3) dependent autophagic program [171,172].
thus, depending on the microenvironment in which angiogenesis occurs, decorin can exhibit either a pro- or an anti-angiogenic activity [165].
nevertheless, in tumor-associated angiogenesis and in various inflammatory processes, the antiangiogenic activity is predominant, providing a potential basis for the development of decorin-based therapies [173,174,175].
biglycan shares about 65% overall homology with decorin.
through the binding to vegfa and activation of vegfr2 biglycan exerts a pro-angiogenic stimulus in fracture healing processes [176].
the pro-angiogenic function is also the result of its interaction with and inactivation of endostatin [177].
in colon cancer, the over-expression of biglycan induces vegf up-regulation and angiogenesis and thus the molecule may be a promising target for the development of anti-angiogenic strategies [178].
thus, the efficacy of anti-angiogenic therapy may depend also on the expression of biglycan in the tumor microenvironment.
the syndecan family comprises four distinct genes encoding single-pass transmembrane protein cores.
the ectodomain of syndecans is natively disordered and this characteristic allows syndecans to interact with a variety of proteins and ligands, thereby providing enrichment in their biological function [114,179].
syndecan-1 is a key regulator of angiogenesis and this mainly occurs through the interaction with igf-1 receptor.
this interaction is essential for the crucial cross-talk taking place between vegfr2, the ανβ3 integrin and ve-cadherin during angiogenesis [180].
syndecan-1 also modulates the vegf-vegfr2 signaling thus promoting ec proliferation and survival [181,182].
in breast cancer, stromal syndecan-1 promotes fgf-2 and vegf signaling and its expression in patients correlates with both vessel density and total vessel area [183].
in contrast, syndecan-2 impairs angiogenesis in human microvascular ecs [184].
syndecans’ levels at the cell surface are regulated by proteolytic cleavage.
in myeloma cells it was shown that syndecan-1 is shed and the binding of vegf through its heparan sulfate chains stimulated tumor angiogenesis further supporting cancer growth [185].
similar to what observed with syndecan-1, the shed ectodomains of syndecan-2 and syndecan-4 modulate angiogenesis.
shed syndecan-2 inhibits angiogenesis via a paracrine interaction with cluster of differentiation 148 (cd148), which in turn deactivates the α1β1 and α2β1 integrins, two main angiogenesis receptors [186].
the ectodomain of syndecan-4 is cleaved by the secreted metalloprotease a disintegrin and metalloproinase with thrombospondin motifs 1 (adamts1).
the ectodomain in turn induces an altered distribution of actin stress fibers and a significant decrease of ras homolog gene family member a (rhoa) activity, thus promoting ec migration and favoring angiogenesis [187,188].
glypicans are cell-surface pgs that share similarity with syndecans and interact with a multitude of ecm proteins, chemokines, growth factors and receptors [112].
glypican-1 is the most prevalent member of the family expressed in ecs and in the vascular system.
it is frequently overexpressed in different human malignancies including pancreatic carcinoma and breast cancer [189].
glypican-1 is highly expressed in gliomas and this may contribute to the malignancy of this highly angiogenic tumor [190].
glypican acts as a co-receptor or promoter of many angiogenic growth factors, including vegf, fgfs, pdgf, heparin-binding egf (hb-egf), hgf, and igf-1 [191].
a recent study indicates that the delivery of glypican-1 by nanoliposomes to the site of ischemic injury could function as an enhancer for growth factor activity, thus improving the response to local angiogenic therapies for the treatment of ischemia [192].
this represents another important example of the potential employment of ecm molecules/fragments for therapy purposes.
lumican is localized in the peripheral blood vessels of adult human lungs and in the thickened intima of the coronary artery and displays binding affinity for αν integrins [193,194].
lumican expression by ecs increases during the resolution phase of angiogenesis, when vessels return to a state of angiostasis [195].
the angiostatic function of this molecule is exerted through the inhibition of integrin α2β1 activity and reduction of mmp-14 expression in ecs [196].
in different tumor models lumican over-expression impaired tumor growth due to a reduced vascular density [197] likely associated with fas-induced ec apoptosis [198].
as summarized in this section, proteoglycans are multifaceted molecules whose protein core is composed by a variety of modules.
they are composed of intricate sugar chains which enable these glycoproteins to sequester and modulate the activity of different growth factors.
their gpi-anchored, transmembrane or extracellular nature enables them to affect different stages of angiogenesis during ec migration to form new vessels.
not only proteoglycans themselves offer the potential to develop new tools to halt angiogenesis, but also the enzymes that cleave these molecules, thus liberating their activity, can be viewed as a possible therapeutic target.
7. hyaluronan: not only a mere glue ha is a large polysaccharide composed of repeating n-acetylglucosamine and glucuronic acid disaccharide units.
under physiological conditions, ha can be composed of up to 25,000 disaccharide units, which become smaller and more dispersed in a pathological status [199].
numerous studies have shown that ha signaling plays an important role in angiogenesis, mainly by influencing ec behavior.
the biophysical functions of ha vary depending on its molecular size which is firmly regulated by the concerted activities of biosynthetic and degradation processes.
for instance, low molecular weight ha (lmw-ha, generally < 200 kda) was shown to prompt inflammation and angiogenesis [200] and stimulate ec proliferation, motility and tubule formation [201].
these oligosaccharides are able to interact with two critical ec receptors: cd44, playing a major role in ec adhesion and proliferation, and rhamm (receptor for ha-mediated motility), essential for ec invasion [202,203,204].
the role of lmw-ha in affecting angiogenesis during wound healing, diabetic mellitus and endometriosis, suggests the possibility to modulate ha as a putative therapeutic approach [205,206].
in contrast, high molecular weight ha (hmw-ha) was reported to be anti-angiogenic [207,208] and immunosuppressive [209].
despite these evidences, their role in angiogenesis is controversial since lmw-ha was also shown to inhibit angiogenesis impairing the cxc ligand 12 (cxcl12)/cxc receptor 4 (cxcr4) pathway, as opposed to what observed with hmw-ha [210].
in addition, hmw-ha seems to stimulate angiogenesis cooperating with versican and inducing fgf-2 expression [211].
thus, the angiogenic properties of lmw-ha and hmw-ha may vary depending on the composition of the microenvironment.
nevertheless, a high ha expression was shown to correlate with increased angiogenesis and poor prognosis [212] and the assessment of this molecule may represent an important mean for the development of new prognostic tools [199].
thus, given the controversial effect of this polysaccharide in angiogenesis, further preclinical analyses must be carried out to better clarify their role in blood vessel formation and verify their putative potential in clinics.
8. the eden family: two members with opposite functions the acronym eden (emi domain endowed) designates a family of ecm glycoproteins characterized by the presence of a cystein-rich emi domain at the n-terminus [213,214,215,216].
this family of proteins can be clustered in distinct groups based on the molecular characteristics and the arrangements of the domains.
the first group comprises the molecules containing the emi domain at the n-terminus, the distinctive domain of the family, followed by a coiled-coil region and a gc1q domain at the c-terminus.
this group includes multimerin1 [217], multimerin2 [218], emilin1 [219], and emilin2 [220].
the second group comprises only one molecule, emilin3 which lacks the gc1q domain and is required for notochord formation [221,222].
the third cluster includes two genes, emu1 and emu2 small collagenous molecules which share with the family only the presence of emi domain [222].
while some of these molecules are characterized by a wide distribution in most connective tissues, like emilin1 and emilin2, the expression of other molecules such as that of multimerin2 (mmrn2) is more restricted.
despite their molecular affinity, two of them, i.e.
mmrn2 and emilin2, exert an opposite function during angiogenesis.
mmrn2, also known as endoglyx-1, was identified during a screening for new antigenic markers of the vascular endothelium and was found to be expressed only at the level of the blood vessel endothelium [223].
in neoplastic tissues mmrn2 is deposited along tumor capillaries and in the “hot spots” of neoangiogenesis [223].
the role of this molecule was first described in a paper by lorenzon et al.
[224], where it was found that mmrn2 primarily impinged on ec migration.
this depends on its ability to sequester vegf-a and inhibit vegfr-2 activation [224,225].
the binding capability has been pinpointed in a region towards the n-terminus of the molecule [225].
the vegf-binding activity primarily occurs through the carbohydrate chains, since their removal significantly compromises, the binding [225].
in addition, the molecule seems also to affect the redistribution of vegfr2 receptor at the ec surface and to be the reservoir of different members of the vegf family of cytokines including vegf-c, vegf-d and placental growth factor (plgf) [225].
when over-expressed in the tumor microenvironment the molecule and its active fragment display a potent anti-tumoral effect [224,225].
these investigations suggest that the activity is indirect and hinges on an impaired vascularization.
a positive role in affecting sprouting angiogenesis has also been reported, thanks to the interaction with the tumor endothelial marker clec14a [226,227].
this indicates that the molecule may display different effects during angiogenesis, depending on the stage of vessels development.
anyhow, given the presence of the molecule along all the blood vessels it is conceivable that it might exert a homeostatic role, thus halting the development of new vessels unless a strong pro-angiogenic signal is released.
under these conditions, the protein could be degraded by the proteases secreted by ecs during migration to allow an efficient sprouting.
preliminary results generated in our laboratory support this hypothesis, still we have only begun to scratch the surface to assess the role of this molecule in angiogenesis and vessel homeostasis (figure 2).
emilin2 was cloned following a two-yeast hybrid screening and is characterized by a proline-rich segment between the coiled-coil region and the collagenous stalk [220].
emilin2 displays a low expression in adult aorta, small intestine and appendix, whereas the highest levels of the protein can be detected in fetal heart starting at e8.5 and reaching the highest levels at e11.5 and adult lung mice [228].
at the functional level, emilin2 significantly impairs the growth of a number of tumor types inducing tumor cell apoptotic death and impairing wnt signaling [11,15].
the emilin2 gene is frequently methylated in breast, lung and colorectal tumors and this suppression correlates with poor clinical outcome and increased limph node metastasis in breast cancer patients [229].
interestingly, and unexpectedly, emilin-2 also stimulates the development of new vessels [230,231].
the molecular mechanisms by which emilin2 affect ecs behavior are being investigated in our laboratory and involve the over-production of cytokines which, in turn, promote ec proliferation and migration (figure 3).
furthermore, tumor vessels developed in emilin2-deprived microenvironments display a worsen integrity of the basal lamina suggesting that it might also affect vessel perfusion and drug delivery (unpublished observations).
thus, despite the similar domain arrangements, emilin2 and mmrn2 exert opposite functions.
this may depend on the fact that the angiogenic activity of mmrn2 occurs through the coiled-coil region, which shares low homology with that of emilin2, of which the pro-angiogenic region has not been identified yet.
9. the ccn family of proteins as regulators of vascular development and pathological angiogenesis the connective tissue growth factor cystein rich protein and nephroblastoma overexpressed gene (ccn) family of proteins includes six members (ccn1–ccn6) that share conserved functional domains.
these proteins have been shown to be reservoirs of growth factors and to promote intracellular signaling.
this occurs through the interaction with cell surface integrins, receptors, or other ecm molecules [232].
these molecules have been extensively studied and their role in the modulation of the proliferation, migration and adhesion of ec, among other cells, established.
despite the homology, the function of the different ccn proteins is exclusive due to the specific expression patterns [233].
for this reason, their correct deposition in many physiologic processes is essential and an unbalanced secretion of these molecules often leads to severe disorders contributing to cancer progression and the onset of vascular diseases.
the ccn1 (cyr61) protein is expressed by ecs and vascular smooth muscle cells (vmsc); cardiac expression occurs at e8.5 and persists until e11.5 during mouse embryo development.
the importance of this molecule in angiogenesis is highlighted by the fact that ccn1 null mice die at e14.5 due to vascular defects [234].
the mechanism of action involves the engagement of integrin αvβ3 and the promotion of ec adhesion and migration [235].
ccn1 stimulates tumor growth and is associated with an increased intra-tumor vascularization [235].
by promoting the differentiation of progenitor ecs, ccn1 supports the re-endothelialization after vascular injury [236].
in addition, by targeting vegf, src homology 2 domain phosphatase-1 and notch signaling, ccn1 affects the development of retinal vessels [237].
the ccn2 protein (ctgf) shares with ccn1 similar expression patterns and it is not only expressed by ecs and vsmc but also by pericytes and regulates the interaction of these cells with ecs [238].
ccn2 null mice die shortly after birth due to severe skeletal and vascular defects associated with an impaired pericyte recruitment and basement membrane organization [239].
given the importance of pericytes in maintaining vascular stability and affecting their efficiency, it is likely that an altered expression of the molecule may also affect drug delivery.
ccn2 induces a hif-1α-dependent vegf expression and this occurs through the up-regulation of mir-210 via the activation of phosphoinositol 3 kinase (pi3k), pkb, extracellular signal-regulated kinase (erk) and nuclear factor kappa-light-chain-enhancer of activated b cells (nf-κb)/ets-domain containing protein 1 (elk1), leading to increased angiogenesis [240].
the ccn3 (nov) protein is structurally similar to ccn1 and 2 but displays a divergent function protecting from aberrant excessive vessel growth [241].
ccn3 supports ec adhesion and/or migration through integrins ανβ3, α5β1, α6β1 and through heparan sulfate proteoglycans inducing corneal vascularization [242].
it was recently demonstrated that ccn3 plays also a key role in the development of abdominal aortic aneurysm [243].
ccn3 stimulates the expression of vegf in prostate cancer cells activating the focal adhesion kinase (fak)/pkb/nf-κb signaling pathway.
furthermore, ccn3 stimulates the recruitment of macrophages which are skewed to an m2 phenotype, thus leading to enhanced tumor angiogenesis [244].
by modifying this key cellular microenvironmental component ccn3 is thus able to deeply affect cancer growth both directly, affecting cancer cell behavior, and indirectly, affecting angiogenesis.
the ccn4 (wisp1) protein is a major regulator of skeletal development and only recently a role in vsmc migration and proliferation has been recognized [245].
a stimulation of vegf-a expression was also demonstrated for ccn4 and it occurs via the engagement of integrin αvβ3 and the consequent activation of the fak/c-src pathway.
this leads to the transactivation of the egfr/erk/hif1-α, which prompts the development of new blood vessels [246].
the ccn5 (wisp2) protein is expressed early and persists throughout embryonic development; it is expressed by ec, vsmc and heart myocardium suggesting a role in vascular function [247].
indeed, recent evidences indicate that ccn5 exerts potent anti-angiogenic effects in an aortic ring vessel outgrowth model, and this angiostatic activity is abrogated by its cleavage [248].
thus, its cleavage may be a mechanism through which, under a strong angiogenic stimulus, the potent anti-angiogenic properties of ccn5 are turned off.
unlike all the other members of the family, ccn6 (wisp3) has not so far been demonstrated to play a role in vascular development.
also for this family of molecules the evidences indicating an involvement in angiogenesis are growing.
given their dual action on cancer cells and vascular cells they thus represent a promising source for the development of new anti-tumor drugs.
as indicated above ccn2, ccn3 and ccn4 induce vegf activation.
thus, in case of high expression levels of these molecules, it should be taken into account that anti-angiogenic therapies aimed at blocking vegf activity may be hampered.
10. conclusions in this review, we report same examples of the intricate and complex regulations exerted by components of the ecm and deeply affecting the angiogenic process.
for this reason, one can conceive that the concentration and processing of these molecules in the tumor microenvironment could be taken into account as an approach to predict the therapeutic efficacy.
in fact, through their action these molecules can impinge on drug delivery and efficacy by modifying the vessels’ efficiency.
in addition, for their prominent role in vessel formation the ecm composition should be taken into account to predict the efficacy of anti-angiogenic approaches.
finally, their endogenous nature offers the potential for the development of new more efficacious and less toxic treatments of angiogenesis-dependent diseases.
@highlight
the extracellular matrix (ecm) is a complex network of proteins, glycoproteins, proteoglycans, and polysaccharides.
through multiple interactions with each other and the cell surface receptors, not only the ecm determines the physical and mechanical properties of the tissues, but also profoundly influences cell behavior and many physiological and pathological processes.
one of the functions that have been extensively explored is its impingement on angiogenesis.
the strong impact of the ecm in this context is both direct and indirect by virtue of its ability to interact and/or store several growth factors and cytokines.
the aim of this review is to provide some examples of the complex molecular mechanisms that are elicited by these molecules in promoting or weakening the angiogenic processes.
the scenario is intricate, since matrix remodeling often generates fragments displaying opposite effects compared to those exerted by the whole molecules.
thus, the balance will tilt towards angiogenesis or angiostasis depending on the relative expression of pro- or anti-angiogenetic molecules/fragments composing the matrix of a given tissue.
one of the vital aspects of this field of research is that, for its endogenous nature, the ecm can be viewed as a reservoir to draw from for the development of new more efficacious therapies to treat angiogenesis-dependent pathologies.
