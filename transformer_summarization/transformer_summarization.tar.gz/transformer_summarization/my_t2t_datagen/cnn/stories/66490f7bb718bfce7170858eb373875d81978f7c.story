introduction an essential part of the treatment for advanced non-small cell lung cancer (nsclc) is therapy tailored to the particular histology and mutation status of individual patients (1).
tumor cells with somatic mutations of the tyrosine kinase domain of the epidermal growth factor receptor (egfr) respond well to tyrosine kinase inhibitors (tki) (2).
the ras pathway, a major signaling pathway activated by egfr, correlates with egfr tki resistance in the presence of gene mutations that encode the v-ki-ras2 kirsten rat sarcoma viral oncogene homolog (kras) domain (3).
in addition, nsclc incorporating a fusion gene located between the anaplastic lymphoma kinase (alk) gene and the echinoderm microtubule-associated protein-like 4 (eml4) gene responds well to alk inhibitors such as crizotinib (4).
fewer than 30% of patients are able to undergo diagnostic surgery for lung cancer; therefore, most diagnoses arise from small biopsies acquired by bronchoscopy or percutaneous needle aspiration (pcna).
however, these are associated with some limitations regarding mediastinal staging (5).
endobronchial ultrasound-guided transbronchial needle aspiration (ebus-tbna) is a minimally-invasive alternative to mediastinoscopy for the diagnosis and staging of nsclc (6).
ebus-tbna can be initially performed to simultaneously diagnose and determine the mediastinal stage in cases of suspected mediastinal metastasis identified via integrated positron emission tomography/computed tomography (pet/ct).
to provide treatment tailored to individual patients, an analysis of the lung cancer subtypes and genotypes, and in particular egfr/kras mutations and alk fusion genes, is critical (7).
several studies that used small nsclc tissue samples obtained via ebus-tbna have proved that such pathologic classification is feasible (8,9).
as well as accurate cell typing, ebus-tbna can also be used to detect egfr and kras mutations in cell blocks possessing tumor cells (10), as well as alk fusion genes in metastatic lymph node samples (11).
in this study, we performed simultaneous histologic classification and a mutation analysis (including egfr, kras, and alk gene rearrangement) using metastatic lymph node or lung tissue samples obtained by ebus-tbna.
the efficacy of a triple gene analysis using these samples was investigated in patients with suspected metastatic cancer of the lymph nodes or a primary lung mass near the bronchus that made it possible to carry out ebus-tbna tissue sampling.
materials and methods patients between may 2011 and may 2013, patients at the samsung medical center (seoul, south korea) with suspected primary lung cancer were retrospectively enrolled in this study.
ebus-tbna was performed on suspected metastatic lymph nodes or lung masses to obtain tissue samples for diagnosis and a mutational analysis.
if malignant cells were histologically detected, then mutation tests for egfr, kras, and eml4-alk were routinely performed at the discretion of the pathologist, except in cases of small cell lung cancer and extrathoracic malignancy.
most of the enrolled patients underwent chest ct and integrated pet/ct prior to ebus-tbna.
the acquisition of the integrated pet/ct images was undertaken using the ge discovery ls pet/ct system (ge healthcare, milwaukee, usa) consisting of a ge advance nxi pet scanner and a ge lightspeed plus 8-slice ct scanner.
we considered a lymph node or lung mass to be positive for malignancy if the maximum standardized uptake value (suvmax) was greater than 2.5 on 18f-fluorodeoxy glucose (fdg) pet/ct (12).
the institutional review board of the samsung medical center approved this study and waived the requirement for informed consent from each patient.
all medical records and personnel information was anonymized and assigned to subject identification code prior to data analysis.
ebus-tbna ebus-tbna was performed with a flexible convex probe ultrasonic puncture bronchoscope with a linear scanning transducer set to a frequency of 7.5 mhz (cp-ebus, bf-uc206f-ol8, olympus, tokyo, japan) (6,13).
the procedure was carried out on an inpatient basis under local anesthesia and conscious sedation with midazolam.
the indications for ebus-tbna in the mediastinal or hilar lymph nodes were the presence of either of these lymph nodes with a short axis diameter ≥10 mm on chest ct and a lymph node with a suvmax greater than 2.5. ebus-tbna was also used to acquire lung mass tissue close to the bronchus, particularly when located in an area where pcna would be difficult or dangerous to perform (14).
all aspirate specimens were expelled onto glass slides, smeared, immediately fixed, and then sent for cytological and/or histological examination.
rapid on-site cytopathological evaluation was not carried out.
pathology with hematoxylin and eosin staining was recorded and classed as benign if it predominantly contained lymphocytes, but no evident malignant cells, or as malignant if it contained clearly malignant cells.
pathological and molecular processing of ebus-tbna samples core samples obtained from a 22-gauge needle were processed using standard histopathologic techniques.
the fresh specimen was placed in a formaldehyde solution, which acted as a fixing agent.
after wax infiltration and paraffin embedding, the specimen was mounted on a slide and diagnosed histologically using immunohistochemistry (ihc).
to classify lung cancer, ihc was performed using monoclonal antibodies applied to ck, p53, p56, p63, ttf-1, and alk.
the novocastra mouse monoclonal antibody p80 alk (clone 5a4, ncl-alk, leica, wetzlar, germany) was used for the immunostaining of alk.
if lung cancer was diagnosed, then the microdissection of tumor cells was done to extract dna from the paraffin-embedded tissue specimens.
a mutational analysis of egfr exons 18-21 and kras codons 12, 13, and 61 was then undertaken.
direct sequencing was utilized for mutations of the egfr exons 18-21. some samples were analyzed with a peptide nucleic acid (pna)-mediated real-time polymerase chain reaction (pcr) clamping method that enables the detection of egfr mutants down to approximately 1% mutant-to-wild type, followed by direct sequencing to confirm the detection of egfr mutations.
a kras mutational analysis was simultaneously performed with the extracted dna using direct sequencing or pna-mediated real-time pcr clamping in codons 12 and 13 of exon 2. the rearrangement of the alk locus on chromosome 2p23 was detected using the vysis alk break-apart fluorescence in situ hybridization (fish) probe (abbott molecular, des plaines, usa).
an expert pathologist (choi yr) from the department of pathology selected samples containing sufficient tumor cells to conduct a qualified analysis.
the positive criteria for eml4-alk translocation was defined as a count of more than 50 cells and >15% of the counted cells displaying green and red signals separated by at least two signal diameters and/or an isolated red signal.
the translocation was considered to be negative if the samples did not fulfil the above criteria.
statistical analysis clinical characteristics and the mutation status are presented as median (range) values for continuous variables and as numbers (percentage) for categorical variables.
a comparison between the eml4-alk fusion positive and negative groups was performed with fisher's exact test.
concordance between the alk ihc and alk fish methods was estimated with k-coefficients.
a p value <0.05 was taken to indicate statistical significance based on a two-sided hypothesis.
the ibm spss statistics for windows software package (ver.
22.0; ibm corp., armonk, usa) was used for the data analysis.
results clinical characteristics of patients with nsclc table 1 lists the baseline characteristics of the 109 patients included in this study.
a total of 155 patients with suspected primary lung cancer underwent diagnostic ebus-tbna.
forty-six patients were excluded prior to analysis because they were diagnosed with small cell lung cancer, benign disease, or extrathoracic metastasis, or because the results were non-diagnostic.
the median aspiration number of ebus-tbna per node and lung mass was 2.0 (range, 1-5) and 3.0 (range, 2-5), respectively.
the samples diagnosed to be nsclc were processed before undergoing ihc for histological classification and gene analysis (fig.
1).
the histology of the metastatic lymph nodes or lung tissue specimens in 109 patients revealed 66 adenocarcinoma (60.6%), 10 favor adenocarcinoma (9.2%), 24 squamous cell carcinoma (22.0%), 5 favor squamous cell carcinoma (4.6%), and 4 nsclc-not otherwise specified (3.7%), respectively.
in total, 69 patients were smokers (63.3%), compared to 40 non-smokers (36.7%).
table 1. clinical characteristics of the patients with nsclc.
characteristics patients (n=109) gender male 77 (70.6) female 32 (29.4) age, y 63.3 ± 9.64 histology of metastatic lymph node adenocarcinoma 66 (60.6) favor adenocarcinoma 10 (9.2) squamous cell carcinoma 24 (22.0) favor squamous cell carcinoma 5 (4.6) nsclc-nos 4 (3.7) clinical stage ii 4 (3.7) iii 50 (45.9) iv 51 (46.8) recurrence 4 (3.7) smoking non-smoker 40 (36.7) smoker 69 (63.3) data are presented as the means ± sd or as n (%), unless otherwise indicated.
nsclc: non-small cell lung cancer, nos: not otherwise specified figure 1. diagnostic algorithm of the study patients.
egfr: epidermal growth factor receptor, kras: v-ki-ras2 kirsten rat sarcoma viral oncogene homolog, alk: anaplastic lymphoma kinase, nsclc: non-small cell lung cancer mutation status of samples obtained by ebus-tbna table 2 summarizes the mutation status of egfr/kras mutations, and alk rearrangement.
a total of 109 ebus-tbna samples underwent a mutation analysis.
among the 76 patients with adenocarcinoma, egfr mutations were interpreted as positive in 22 samples (28.9%), kras mutations in 12 (12.8%) samples, and alk rearrangement in 5 samples (7.1%).
fig.
2 shows representative images regarding the pathology and mutational tests including egfr, kras and alk.
among those patients with squamous cell carcinoma, egfr mutations were interpreted as positive in one sample (3.4%); kras mutations were also interpreted as positive in one sample (3.4%).
however, there was no positive interpretation regarding alk rearrangements.
triple gene testing for egfr/kras mutations and alk rearrangement was simultaneously performed for 101 samples because the alk-fish test was not performed for 8 samples.
the mean tumor cell percentage was 40% [interquartile range (iqr): 20-70] for adenocarcinoma, 30% (iqr: 10-60) for squamous cell carcinoma, and 30% (iqr: 20-70) for nsclc-nos.
sufficient samples in terms of both quantity and quality were obtained via ebus-tbna to enable the testing of 109 consecutive nsclc tissue specimens.
however, the alk rearrangement test was not able to be carried out in 4 out of 101 consecutive samples.
there were no residual tissue blocks containing tumor cells in order to carry ou the alk rearrangement test after the analysis of egfr and kras mutation.
the median duration of the entire process, from ebus-tbna to the final reports, was 14 days (range: 6-37 days).
table 2. mutation status according to the histologic subtyping.
adenocarcinoma squamous cell carcinoma nsclc-nos subjects, n 76 29 4 gender, m:f 50:26 (1.9:1) 25:4 (6.3:1) 2:2 (1:1) age, y 62.05 (53-70) 68.0 (61-71) 62.0 (56-74) tumor cell percentage 40% (20-70) 30% (10-60) 30% (20-70) egfr mutation positive exon 19 deletion e746-a750del 5 0 0 l747-p749del 1 0 0 l747-p753del 2 0 0 e746-a750del 2 0 0 l747-s7521del 0 1 0 exon 19 del and ins.
t751-i759 1 0 0 exon 19 + exon 20 l747-a750del+ t790m 1 0 0 exon 20 a770-v772 dup 1 0 0 exon 21 l858r 8 0 0 l861r 1 0 0 kras mutation positive 12 10 1 0 13 1 0 0 61 1 0 0 alk fish positive 5 0 0 negative 64 24 4 na 1 3 0 data are presented as n (%) or as the median (iqr) values.
nsclc: non-small cell lung cancer, nos: not otherwise specified, egfr: epidermal growth factor receptor, kras: v-ki-ras2 kirsten rat sarcoma viral oncogene homolog, alk: anaplastic lymphoma kinase figure 2. representative images of the samples obtained by ebus-tbna.
a, carcinoma cells are positive for alk with a membranous pattern of staining.
the alk fluorescence in situ hybridization test shows break apart rearrangement in 40 of 50 non-overlapping nuclei: one red, one green, and one fusion signal.
b, metastatic adenocarcinoma cells occupy about 5% of total specimen volume.
real-time polymerase chain reaction test detects a deletion mutation in exon 19: c.2235_2,249 del 15 (p.e746_a750 del); the standard cyclic threshold (ct) is 34 and sample ct is 27.5436. c, metastatic adenocarcinoma cells occupy about 70% of the total specimen volume.
kras sequencing shows a missense mutation in the 12th codon: c.34g>t (p.g12c).
eml4-alk fusion gene in nsclc the frequency of lung cancer incorporating the eml4-alk fusion gene was 5 (4.9%) out of 101 patients, with a median age of 57.0 years.
comparison of the clinical characteristics between eml4-alk fusion positive and negative patients is detailed in table 3. the smoking status of the patients with lung cancer incorporating fusion genes was significantly lower (0.0 pack-year, iqr 0-0.75) compared to the patients with lung cancer and no alk gene rearrangement (20.0 pack year, iqr 0-40).
all lung cancer cases which included the eml4-alk fusion gene had adenocarcinoma and no positive egfr/kras mutations.
on the other hand, lung cancer that was negative for fusion genes in 22.8% of the egfr mutation positive cases and 11.9% of the kras mutations.
the alk ihc and eml4-alk fish methods closely correlated with the 5 alk ihc positive and 92 alk negative cases.
all alk ihc positive cases revealed eml4-alk fusion at the alk locus on chromosome 2p23.
table 3. comparison of the patient characteristics between eml4-alk fusion positive and negative nsclc.
characteristics eml4-alk fusion p value positive (n=5) negative (n=92) age 57.0 (49-93) 64.0 (55-71) 0.096 gender, female 3 (60) 28 (30.4) 0.087 smoking status, py 0.0 (0-0.75) 20.0 (0-40) 0.023 metastasis brain 0 (0.0) 9 (9.8) 0.404 bone 0 (0.0) 15 (16.3) 0.616 pleura 1 (20.0) 20 (21.7) 0.962 histology of ln 0.739 adenocarcinoma 5 (100) 64 (69.6) sqc 0 (0.0) 24 (26.0) nsclc-nos 0 (0.0) 4 (4.3) alk ihc 0.000 positive 5 (100) 0 (0.0) negative 0 (0.0) 92 (100) egfr mutation status 0.440 positive 0 (0.0) 21 (22.8) negative 5 (100) 71 (77.2) kras mutation status 0.627 positive 0 (0.0) 11 (12.0) negative 5 (100) 81 (88.0) data are presented as n (%) or as the median (iqr) values.
py: pack-year, ln: lymph node, sqc: squamous cell carcinoma, ihc: immunohistochemistry, eml4-alk: echinoderm microtubule-associated protein-like 4-anaplastic lymphoma kinase discussion this study showed that the ebus-tbna procedure could provide sufficient aspiration samples for 100 % (egfr and kras mutations) and in 96% (alk gene rearrangement) of the enrolled patients when they were processed consecutively.
a routine triple gene analysis following pathologic subtyping was feasible in 96% of our study samples.
the egfr gene is frequently expressed in nsclc and somatic mutations in exons 18-21 have been shown to demonstrate a relationship with the treatment responses to egfr tki (2).
eml4-alk rearrangement should also be identified to predict the response from the alk inhibitor (15).
such genetic information is a key to providing personalized treatments for patients with advanced nsclc.
previous studies regarding gene analyses for egfr and kras concluded that the use of ebus-tbna in advanced lung cancer allowed for the adequate interpretation of mutations (16).
however, the quality of such interpretation using samples obtained by ebus-tbna has only rarely been investigated.
folch et al.
described the success and failure rate of egfr mutations and alk translocations from nodal tissue specimens using ebus-tbna and other diagnostic methods.
ebus-tbna was able to be performed in 42 out of 207 cases, resulting in a success rate of 95.2% in egfr mutations, 90.5% in kras mutations, and 90.5% in alk fish (17).
in contrast, our study used samples obtained via ebus-tbna alone, and a total of 109 cases were enrolled providing a high success rate of 100% in egfr/kras mutations and 96% in alk translocations.
the alk translocation rate for adenocarcinoma was 7.1%.
there was no overlap between egfr, kras, and alk mutations.
pathologist-interpreted alk immunohistochemistry was performed in all nsclc cases.
the concordance rate of alk ihc in the small samples obtained by ebus-tbna was perfectly matched in our study.
this result shows that alk translocation ihc could be employed as a screening method for alk rearrangement prior to alk fish in ebus-tbna-sampled tissues.
ebus-tbna is a non-invasive procedure performed under conscious sedation to diagnose cancer of the mediastinal and hilar lymph nodes.
our institute has issued a protocol to reduce the time interval from the initial biopsy to the pathologic diagnosis and interpretation of gene mutations, since treatment delays affect the prognosis of advanced lung cancer (18).
ebus-tbna can be performed as an initial procedure for simultaneous diagnosis and mediastinal staging if pet/ct reveals a significant mediastinal lymph node uptake in a patient with suspected lung cancer.
in this study, we demonstrated that small samples obtained by ebus-tbna provided good quality subtyping for nsclc with mediastinal metastasis.
of those patients diagnosed with nsclc in our study, only 3.7% had nsclc-nos.
the most common pathologic nsclc classifications was adenocarcinoma (60.6%) and favor adenocarcinoma (9.2%), followed by squamous cell carcinoma (22%), and favor squamous cell carcinoma (4.6%).
from the ihc results, 96.3% of the sampled tissues were classified by the time lung cancer was pathologically diagnosed.
a multicenter study of 774 patients from the uk suggested that small samples obtained via ebus-tbna could be used to classify the nsclc subtypes in 77% of cases (8).
however, this study was limited in that it did not perform routine ihc.
our data indicate a higher rate of lung cancer subtypes because we routinely performed ihc in all tissues obtained by ebus-tbna.
the median time lapse between ebus-tbna and the final reports, including the mediastinal stage, tumor diagnosis with pathologic subtype, and genetic information (egfr/kras mutations, and alk rearrangement) was 14 days (range: 6-37 days).
past practice was to request a mutational analysis after the patient had been diagnosed with lung cancer via bronchoscopy or pcna.
following diagnosis, ebus-tbna was then performed for mediastinal staging when the patient showed a significant mediastinal uptake on pet/ct.
however, this led to delays in treatment because clinicians required information on the mediastinal stage, pathologic subtype, and mutation status before any decisions on treatment could be made.
the protocol in place at our institute requires ebus-tbna to be performed initially to confirm the lung cancer staging or diagnosis, pathologic subtype, and genetic status of egfr, kras, and eml4-alk in patients suspected of having advanced lung cancer following pet/ct.
our study is associated with some limitations.
a recent analysis of the data from a large number of patients has reported that alk rearrangements are mutually exclusive, with mutations in either egfr or kras (19).
therefore, to be cost-effective, eml4-alk fusion gene assessment should not be undertaken in samples harboring egfr mutations.
second, the alk ihc results were expressed as either positive or negative, and a scoring system according to ihc expression was not adopted.
at the time we conducted our study there was little evidence that alk ihc was a useful screening tool for alk gene rearrangement.
we also analyzed alk gene arrangement despite the presence of positive alk ihc cases.
third, we analyzed multiple genotypes using direct sequencing or a pna-mediated real-time pcr clamping method.
the sensitivity of these two methods in detecting egfr/kras mutations may differ.
further studies using the pna-mediated real-time pcr clamping method may be required to validate this suggestion.
in addition, the alk fish results using small biopsy samples from ebus-tbna may differ from those obtained with excision samples.
fourth, there was no information of the comparison data from samples obtained by transbronchial lung biopsy (tblb) for the triple mutation analysis.
the use of ebus-tbna samples may be further supported if we compared the detection rate of triple mutations from samples obtained between ebus-tbna and tblb.
in conclusion, small tissue samples obtained via ebus-tbna were found to be sufficient to successfully detect triple mutations in advanced lung cancer.
this demonstrates the usefulness of ebus-tbna as an initial modality with regard to the treatment of lung cancer.
the authors state that they have no conflict of interest (coi).
@highlight
objective a mutational analysis of tumor tissue samples is an important part of advanced lung cancer treatment strategies.
this study evaluated the efficacy of a triple gene analysis using samples obtained via endobronchial ultrasound-guided transbronchial needle aspiration (ebus-tbna).
methods either metastatic lymph nodes or primary lung mass samples obtained by ebus-tbna were collected between may 2011 and may 2013. we consecutively analyzed epidermal growth factor receptor (egfr), v-ki-ras2 kirsten rat sarcoma viral oncogene homolog (kras), and anaplastic lymphoma kinase (alk) fusion genes using remnant tissue samples.
results a total of 109 patients were diagnosed with non-small cell lung cancer (nsclc).
of these, 70% were adenocarcinoma, 27% squamous cell carcinoma with nsclc, and 3% were related to other types of lung cancer.
egfr mutations were detected in 23 cases (21.1%), kras mutations in 13 cases (11.9%), and alk fusion genes in 5 cases (4.9%).
the alk fusion genes could not be analyzed in four cases because of insufficient tissue samples remaining after routine histochemistry and an egfr/kras mutation analysis.
we found that small biopsy samples from ebus-tbna were adequate for performing a triple gene analysis in 97 patients (96%).
alk fusion protein immunohistochemistry (ihc) was 100% consistent with fluorescence in situ hybridization (fish).
conclusion small samples obtained by ebus-tbna were found to be sufficient for performing a triple gene analysis following routine histology and ihc.
alk ihc showed a very good concordance with fish for detecting alk fusion genes.
