introduction the durability of the bond between resin and tooth substrate has noteworthy importance for the prolonged clinical existence of composite restorations.
however, the long-term stability of the resin-bonded dentin is still questionable.
various factors have been ascribed for degradation of resin-dentin interface such as the hydrophilic monomers incorporated in simplified adhesives,[1] water concentration in self-etch adhesives,[1] inadequate infiltration of resin monomers within the hybrid layer, proteolytic breakdown of exposed collagen fibrils by activated endogenous collagenolytic enzymes,[2] high permeability of the bonded interface, phase separation within the hybrid layer and suboptimal polymerization.
[3] during the hybrid layer formation, the discrepancy between the depth of demineralized collagen layer and resin infiltration can lead to denuded exposed collagen fibrils at the bottom of the hybrid layer which are less resistant to denaturation and fatigue breakdown after the function.
the water present in the voids in between these uncovered collagen fibrils may also aid in hydrolysis of collagen by the activated endogenous and exogenous collagenolytic and gelatinolytic enzymes (matrix metalloproteinases [mmps] and cysteine cathepsins).
[4] mmps or matrixins are a family of twenty host-derived proteolytic enzymes, a class of zinc- and calcium-dependent endopeptidases that are stucked inside the mineralized dentin matrix during the tooth development.
they can degrade all extracellular matrix components, making them important in many biological and pathological processes.
human dentin contains at least mmp-2, mmp-8, mmp-9, and mmp-20.
[5] mmps are synthesized and mostly secreted as inactive proenzymes (zymogens) and get exposed and activated by acidic agents during adhesive bonding procedures.
mild acids have been shown to be able to activate mmps.
[4] both etch and rinse, and self-etch adhesives have mild acidity, therefore can release and activate endogenous mmps during dentin bonding which can lead to hydrolytic degradation of exposed collagen fibrils.
[6] this is manifested as thinning and disappearance of collagen fibrils from incompletely infiltrated hybrid layers in aged, bonded dentin resulting in decreasing bond strength over long-term.
[7] bond strength and durability seem to rely on the quality of the hybrid layer (i.e., on the proper impregnation of the dentin substrate) rather than on the thickness or morphology of the hybrid layer/resin tags.
various biomaterials (natural, synthetic, and physical methods) have been introduced to function as mmp inhibitor (mmpi) and collagen cross-linker such as carbodiimide (edc), proanthocyanidin (pa), chlorhexidine (chx), galardin, and epigallocatechin-gallate (egcg) to improve the long-term bonding efficacy of contemporary dental adhesives.
[8] a literature search was performed across the electronic databases (pubmed, ebsco host, and google search engine) to identify manuscripts for inclusion, using the keywords: carbodiimide, dentin bonding, durability, resin-dentin interface, and collagen cross-linking.
relevant articles from the reference lists of the retrieved articles were also searched.
an attempt was made to include all the research articles that evaluated the role of edc in stabilizing the rein-dentin bond.
in addition to this, review articles that suggested the use of edc as one of the strategies to optimize dentin bonding were also included.
thirty-five articles were finally included.
no publication year limit was used, and the last search was made in february 2016. the aim of this review is to present an overview of edc including its properties, detailed description of its mechanism of collagen cross-linking and mmp inhibition, cytotoxicity and its effect on resin-dentin bond stabilization when used for dentin surface pretreatment before adhesive application.
dentin biomodification exposed collagen fibrils present at the base of the hybrid layer represent a delicate substrate which is vulnerable to degradation by most host-derived enzymes, i.e., mmps and cysteine cathepsins.
[4] therefore, if we could bio-modify the dentin substrate by pretreating with mmpis and collagen cross-linkers (ccl) as dentin bio-modifiers, a more stabilized and durable adhesive interface can be achieved.
dentin biomodification is a bio-inspired strategy which is based on multi-mechanistic interactions between dentin and these agents for improving the durability of resin-dentin bond by using several natural and synthetic agents.
it can be used to create a more resistant, stable, and insoluble collagen network which serves as a stable substrate for dental adhesive restorations.
dentin biomodification through collagen cross-linking and mmp inhibition can be achieved by either synthetic (carbodiimide, glutaraldehyde, chx, tetracyclines, quaternary ammonium compounds, ascorbic acid) or natural products (catechins, oligomeric pas, genipin, hesperidin, and other polyphenols) and products activated by physical methods such as ultraviolet-a activated riboflavin.
[9] these biomaterials can be obtained from plant extracts such as catechins (ecg, egc, gcg, egcg) camellia sinensis (green tea), genipin – gardenia jasminoides, polyphenols-theobroma cacao (cocoa seed), vitis vinifera (grape seed), pomegranate rind and bark, cloves, bearberry leaves.
as two different types of proteases (mmp and cysteine cathepsins) present in dentin matrix responsible for degradation of hybrid layer collagen, we need to have two different classes of inhibitors and this makes the approach more complicated.
therefore, use of collagen cross-linkers can be an alternative way to inactivate all types of endogenous proteases present in dentin matrix with a single cross-linking agent.
as we know, denuded demineralized dentin collagen fibrils at the base of the hybrid layer are weaker than the resin impregnated demineralized dentin collagen and certainly from the dentin collagen which is not demineralized.
although treatment with enzyme inhibitors prevents degradation of these vulnerable collagen fibrils, they do not strengthen the collagen fibrils.
[7] therefore, besides providing protection from matrix-bound proteases, strengthening should also be done to improve the mechanical stability and durability of resin-dentin interface.
hence, collagen cross-linkers with protease inhibiting property would be a promising technique to preserve the denuded collagen fibrils.
collagen cross-linking is of two types either endogenous or exogenous.
exogenously collagen cross-linking can be induced by physical methods or chemical agents.
these exogenous cross-links pull fibers close together, forms covalent, or ionic bond between peptide chains.
[10] this results in interfiber bond formation which produces a more dense and smoother structure and provides more strength by preventing the sliding of fibers and chains under mechanical stress.
[11] thus, increasing the number of cross-links in dentin collagen can be an interesting approach to enhance the mechanical properties of dentin matrix, simultaneously reducing the biodegradation rates of collagen thereby improving the quality and longevity of adhesive restorations.
[1213] these exogenous cross-linking agents can be used either before adhesive bonding or can be incorporated directly into the adhesive system [figure 1].
figure 1 incorporating biomodifiers in dentin bonding after the enormous use of glutaraldehyde (gd) and various other well-known crosslinking agents such as natural polyphenols (pa, grape seed, green tea, cocoa seed, sumac berries, or curcumin) capable of stabilizing collagen structure through creating multiple hydrogen bonds between collagen polypeptides,[14] a newer synthetic cross-linking agent, carbodiimide has gained interest and recently shown to inhibit protease activity[15] without significant cytotoxicity unlike gd which was associated with cytotoxicity.
[16] carbodiimide 1-ethyl-3-(3-dimethylaminopropyl) carbodiimide hydrochloride or edc is a synthetic cross-linking agent which when applied directly to demineralized dentin has been found to improve the bond strength and structural integrity of the resin/dentin interface over time by preventing the enzymatic and/or hydrolytic degradation, through the formation of inter- and intra-molecular crosslinks[12] [table 1].
it is the most stable cyanamide isomer and produces cross-links which are very stable.
additionally in medical field also, edc has been used to support drug delivery system development, bioprosthetic heart valve construction,[42] preparation of collagen scaffolds,[43] etc.
table 1 literature review of studies evaluating the effect of carbodiimide cross linking mechanism edc is known as a zero-length cross-linking agent,[44] due to its ability to cross-link peptides to one another without introducing additional linking groups.
it contains a functional group (rn=c=nr) and is capable of forming covalent peptide bonds between proteins nonspecifically by activation of free carboxyl group of glutamic acid and aspartic acid present in protein molecules.
[45] it results in the formation of o-acylisourea intermediate that reacts with the epsilon amino group of lysine or hydroxylysine in an adjacent polypeptide chain to form a stable, covalent amide bond.
improved resistance to collagenase challenge and increased mechanical properties of collagen-based materials have been reported following treatment with edc.
[46] edc causes cross-linking to occur in dentin collagen as well as in dentin matrix-bound mmps.
it is found that when collagen cross-linkers are applied on demineralized dentin, cross-linking occurs more rapidly in mmps as compared to collagen.
[1530] this could be due to better accessibility of carboxyl and amino groups in mmps than in collagen.
[47] thus, it becomes clear that edc is a potent mmpi and its mmp inhibition effect is much quicker than its cross-linking effect.
matrix metalloproteinases inhibition mechanism type i collagen molecules are synthesized biologically from a predecessor, procollagen, by cleavage at both its globular c- and n-terminal ends called telopeptides.
perumal et al.
demonstrated that the cleavage site is fully protected by the c-telopeptide (the terminal end of the collagen molecule) blocking the mmps to reach that place.
[47] therefore, the site must be exposed by removing this telopeptide through proteolytical action of telopeptidase or by mechanical damage before mmp can bind to the substrate which facilitates the unwinding/dissociation of triple-helix before collagenolysis.
for degrading collagen, this “unwinding” is mandatory which permits mmps catalytic site to cut the peptide.
this creates enough space for enzyme's active site to further break the specific peptide bond between glycine-isoleucine in peptide chains.
[48] alternatively, damage caused, for example, by physical loading cause some changes in fibril structure and thereby exposes the first collagen peptide chain to be cleaved by mmp.
it provides independence for movement of other chains and thereby promoting their subsequent cleavage.
[47] collagen molecules away from the initial cleavage site would also become easily available for cleavage by mmps, leading to further degradation.
[47] thus, to prevent the further degradation of collagen, edc when used as dentin bio-modifier, increases the modulus of elasticity of collagen and makes it more difficult for mmps to unwind the collagen triple-helix structure.
the proposed mechanisms to explain mmp inactivation by cross-linkers such as edc are (1) conformational changes in three-dimensional structure of enzyme such as irreversible changes in the catalytic domain or allosteric inhibition of other degrading modular domains.
[2] (2) inactivation of the active sites of dentin proteases by reducing the molecular mobility of the active site or by changing negatively charged ionized carboxyl groups into positively charged amides.
(3) finally, it can cross-link both helical and especially telopeptide domains in collagen, restricting telopeptidases to remove the bulky telopeptides from the specific peptide bond of collagenases.
[15] dentin stabilization with carbodiimide: role in enhancing the durability of resin-dentin bond edc causes stiffening of collagen, inactivates the catalytic site of proteases, reduces the mobility of enzymes by creating a new peptide bond across adjacent peptides.
therefore, it can be anticipated that mmp inactivation by cross-linking agents should last much longer than the inhibition by mmpi alone.
the biomodification of collagen by extrinsic cross-linkers like edc can induce the formation of additional inter- and intra-molecular cross-links,[12] increasing the ultimate tensile strength (uts) and elastic modulus of demineralized dentin.
[29] bedran-russo et al.
[12] evaluated the effect of edc/n-hydroxysuccinimide (nhs) on the resin-dentin bond and found that different application time (10 min, 30 min, 1 h, 2 h, 4 h) lead to significant increase in dentin stiffness irrespective of different solutions (distilled water, 2-(n-morpholino) ethanesulfonic acid-mes, ethanol) used.
edc/nhs groups showed improved collagenase resistance, highest uts and improved durability of resin-dentin bond even after 1 year.
tezvergil-mutluay et al.
[15] evaluated the inhibitory effects of five edc concentrations (0.01m, 0.02m, 0.05m, 0.1m, 0.3m) and five incubation times (1, 5, 10, 20, 30 min) on soluble rhmmp-9 and on endogenous proteinases from completely demineralized dentin beams.
hydrolysis of collagen matrix was measured by a decrease in modulus of elasticity (e), dry mass of the beams, and an increase in hydroxyproline (hyp) content of hydrolysates derived from the incubation medium.
all edc concentrations and pretreatment times inactivated mmp-9 by 98%–100% but 0.3m edc showed a significant increase in elastic modulus and decrease in hyp content when compared to control.
it was concluded that edc application for 1 min may be a clinically relevant and effective means for inactivating soluble rhmmp-9 and matrix-bound dentin proteinases.
scheffel et al.
[29] evaluated the effect of edc on elastic modulus (e), mmps activity, hyp release and thermal denaturation temperature of demineralized dentin collagen.
all cross-linking agents decreased mmp activity and hyp release and increased thermal degradation temperature (tdt).
it was concluded that edc concentrations between 0.5m and 2m, for only 30 s significantly increased collagen stiffness.
however, when the reaction time was increased to 60 s of treatment, edc significantly increased the elastic modulus at 1m or 2m concentrations.
all these treatment times and concentrations were sufficient to reduce matrix-bound mmp activity.
edc was found to be more effective mmp inactivator than it was as collagen cross-linker at both periods of time (i.e., 30 s and 60 s).
tempesta et al., (2013)[24] evaluated the effect of carbodiimide cross-linking on bond strength to radicular dentin and stated that edc pretreatment at 0.3m concentration for 1 min showed no significant difference in bond strength when luting fiber post to endodontically treated teeth when compared with control.
navarra et al.
[27] evaluated the effect of edc-cross linking on tdt of dentin as an improved tdt is an indirect indicator of a more resistant and highly cross-linked collagen network.
however, they concluded that 0.5m, 0.1m, 1m edc treatment for 10, 20, 30, 40, 50, or 60 min did not increase tdt when compared with untreated control group.
mazzoni et al.
[28] using zymography and in situ zymography techniques, evaluated the ability of edc cross-linker to inhibit mmp activity.
zymograms revealed increased expression of dentin endogenous mmp-2 and-9 after adhesive application, while the use of 0.3m edc for 30 min as a primer inactivated dentin gelatinases.
in situ zymography technique also showed that hybrid layers of tested adhesives also exhibited intense collagenolytic activity, while almost no fluorescence signal was detected when specimens were pretreated with edc.
thus, it was concluded that edc could contribute to inactivate endogenous dentin mmps within the hybrid layer created by etch-and-rinse adhesives.
scheffel et al.
[30] evaluated the effect of edc or pa cross-linking agent and mmpi, chx, on acid-etched dentin.
dentin beams were etched for 15 s with 37% phosphoric acid, rinsed and immersed in either deionized water or 0.1m edc, 0.5m edc, 0.5m edc + 35% hydroxyethyl methacrylate (hema), 5% pa, and 2% chx for 60 s. dentin treatment with cross-linking agents was effective to significantly reduce mmp activity; 0.5m edc and 5% pa showed the best results.
scheffel et al.
[36] showed that 0.5 mol/l edc applied on dentin for a short time, such as 30 and 60 s, was capable of preventing resin-dentin bond degradation after up to 12 months of aging in artificial saliva.
these findings agree are in agreement with mazzoni et al.,[23] who also found that of 0.3 mol/l edc water solution application for 1 min on demineralized dentin produce significant mmps inactivation and preserve bond strength over time.
effect of solvents used with carbodiimide solution-n-hydroxysuccinimide/hydroxyethyl methacrylate/acetone/water/ethanol/2-(n-morpholino) ethanesulfonic acid n-hydroxysuccinimide adding nhs to the edc-containing solution produces collagen matrix with good biocompatibility, higher cellular differentiation potential and with increased resistance against enzymatic degradation, as it increases the number of induced collagen cross-links and prevents the hydrolysis of activated carboxyl groups.
[49] bedran-russo et al.
found that edc/nhs may be used as a promising tool for inducing exogenous collagen cross-links resulting in increased mechanical properties and stability of dentin-resin interfaces.
[12] concentration of carbodiimide/n-hydroxysuccinimide on collagen crosslinking the degree of collagen matrices crosslinking could be controlled by changing edc/nhs concentration.
yang reported that edc showed maximum crosslinking up to 2 mg/ml concentration, with (edc: nhs ratio 4:1) no further increase in crosslinking when higher concentration was used.
[50] effect on collagen microstructure by carbodiimide/n-hydroxysuccinimide crosslinking cross-linking with edc/nhs solution resulted in highly aligned fibrillar structure.
more aligned structure in case of cross-linked fiber is likely to support the superior mechanics, reduced swelling ratio, and increased proteolytic resistance.
[51] effect on swelling ratio edc/nhs-crosslinking reduced susceptibility to enzymatic degradation of collagen by decreasing swelling ratios as compared to uncrosslinked collagen.
[51] swelling ratio is a measure to assess the extent of water sorption achieved by demineralized dentin.
decrease in swelling ratio occurs following exogenous cross-linking of dentin matrix as the dense cross-linked collagen matrix impedes water sorption.
enzymatic stability even a low degree of edc/nhs-collagen crosslinking (0·5 mg/ml) was found to be able to dramatically reduce the rate of enzymatic degradation and preserve the matrix ultrastructure against bacterial collagenases.
[50] hydrolytic cleavage of collagen catalyzed by bacterial collagenases occur, particularly in nonpolar regions.
it involves either a single alpha-chain or simultaneously across the three chains of the triple helix in a lateral fashion.
however, crosslinking encouraged by edc/nhs can occur inside the alpha chain, in between the alpha chains, or as intermolecular or interfibrillar linkages, which blocks collagenase's ability to cleave alpha-chain linkages more successfully.
hydroxyethyl methacrylate scheffel et al.
reported that 0.5m edc mixed with 35% hema did not influence edc crosslinking of mmps, signifying that edc can be combined with primers in adhesive systems.
[30] acetone versus water/ethanol various solvents used for edc solution have been found to affect its cross linking potential.
recently ekambaram et al.
found that if acetone was used as a solvent for making edc solution, the modulus of elasticity was significantly increased, swelling ratio was significantly decreased along with the preservation of uts of demineralized dentin, unlike the results which were found when water and ethanol were used as solvent.
[35] thus, it can be concluded that edc potential to cross-link dentin collagen can be enhanced using acetone as a solvent.
when acetone and water are mixed, acetone effectively facilitates the removal of water from demineralized dentin as acetone has a much higher vapor pressure at room temperature than do ethanol and water.
[52] due to its dehydrating potential, acetone helps to prevent hydrolysis of the activated carboxyl group of dentin collagen.
the stability of these activated carboxyl groups determines the degree of collagen cross-linking.
as acetone removes water from demineralized dentin, the amino acids of the collagen come closer, improving cross-linking.
[53] the dense cross-linking created by edc in acetone induces steric hindrance in collagen molecule, blocking the matrix accessibility to enzyme thus reduces collagenase adsorption.
moreover, the dense matrix network may also mask the enzyme cleavage sites on the collagen and improve matrix resistance to enzymatic degradation.
[54] eliminates need for n-hydroxysuccinimide using acetone as a solvent for edc in dentin collagen cross-linking treatment also eliminates the need for adding nhs as an extra step in the preparation of the cross-linking solution, and reduces the cost of cross-linking treatment.
effect on matrix metalloproteinases activity using acetone would also reduce the collagenolytic actions of endogenous enzymes, as mmps and cysteine cathepsins are hydrolases and are dependent on water for breakdown of the demineralized dentin collagen, thereby promoting durable resin/dentin bonds.
[2] effect on swelling ratio decrease in swelling ratio of demineralized dentin cross-linked by edc in acetone occurs due to enhanced ability of the collagen fibrils to form inter-peptide bonds in case of acetone saturation.
[54] removing water from demineralized collagen matrix by acetone also leads to loss of plasticizing effect thereby leading to stiffening of the collagen matrix.
this stiffening along with the interpeptide bond formation between collagen fibrils leads to a decrease in swelling ratio.
[55] the cross-linked collagen matrix is dense and therefore less prone to creep rupture or cyclic fatigue rupture, even after extended periods of intraoral function.
[54] effect of treatment time on mechanical properties of collagen edc increases the durability of resin-dentin bonds by improving the mechanical properties of the collagen matrix.
[6] however, the longer application time (30 min-4 h) required for this procedure is clinically objectionable.
[12] tezvergil-mutluay et al.
indicated that even 1 min pretreatment of carbodiimide on acid-etched dentin is adequate to inactivate protease activity endogenous enzymes within dentin without significantly stiffening the collagen.
[15] carbodiimide cytotoxicity edc has been used as a substitute to gd, another extensively used cross-linker.
it presents very low cytotoxicity when compared to gd as the urea derivative a by-product formed during cross-linking releases and gets easily rinsed off from the collagen and leaves no chemicals as residues.
moreover, it does not contain any potentially cytotoxic aldehyde residuals.
the various edc concentrations used earlier in separate experiments did not produce any trans-dentinal effects which are cytotoxic to odontoblast-like cells and did not affect cell viability, making edc safe for in vivo application.
scheffel et al.
proved that the use of edc as cross-linking agent in dental practice is safe and can be used to enhance the quality of resin-dentin bond.
[36] conclusion the treatment of demineralized dentin with edc could be a simple, practical, and clinically applicable method to reduce collagen degradation in the hybrid layer, being an efficient alternative to make resin-dentin bonds more durable.
most of the researches regarding the role of edc in improving resin-dentin bond durability has been done using etch and rinse adhesives.
effect of edc on the bonding efficacy of self-etch adhesives still needs to be evaluated.
moreover concentration of edc, time of application and solvent compatibility are some factors which needs to be elucidated.
at present, only preliminary research is available with most of the biomodifying agents including edc being used as dentin pretreatment before adhesive application, further research is required to incorporate edc as part of etchant/adhesive system to develop bio-active adhesives which will reduce an extra step in the clinical protocol.
at present, it is difficult to ascertain whether collagen cross-linking ability or protease (mmps and cathepsins) inhibition property of edc plays an equally important role or one factor predominates over the other in increasing the durability of resin-dentin bond.
further studies are needed to better understand the effects of edc application in vitro and to demonstrate its efficacy in vivo.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
clinical longevity of composite resin restorations is a significant problem in adhesive dentistry.
most of the current simplified adhesives present good immediate bonding, but the bond strength gradually falls over a period due to biodegradation at the resin-dentin interface.
various strategies have been proposed to improve the durability of resin-dentin bond including the use of matrix metalloproteinases inhibitors and collagen cross-linkers, biomimetic remineralization, ethanol wet bonding, to improve the physical and mechanical properties of the bonding substrate, i.e., dentin.
however, all are under preliminary research and without any conclusive evidence.
therefore, this paper addresses the current challenge in dental adhesion, i.e., poor durability of resin-dentin bond and introduces the concept of dentin biomodification as an alternative way for improving the long-term bonding effectiveness of current adhesives to dentin and also provides an overview of a synthetic collagen cross-linking agent carbodiimide (edc) including its mechanism of action, literature review of studies evaluating edc, variables associated with its use and its cytotoxicity.
search was performed across the electronic databases (pubmed, ebsco host, and google search engine) to identify manuscripts for inclusion, using the keywords: carbodiimide, dentin bonding, durability, resin-dentin interface, and collagen cross-linking.
thirty-five articles were finally included, and the last search was made in february 2016.
