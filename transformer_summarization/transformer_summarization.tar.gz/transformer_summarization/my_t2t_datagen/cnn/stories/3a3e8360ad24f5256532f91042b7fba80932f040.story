introduction proximal humerus fracture comprises 4–5% of all fractures.1 the treatment of displaced proximal humerus fracture is controversial.
it varies from conservative to surgical management.
surgical management includes close reduction and percutaneous pinning, open reduction, and internal fixation with locking compression proximal humerus plate and hemiarthroplasty.2 the main aim of treatment are an anatomical reduction of fracture, preservation of vascularity of humeral head, and good functional outcome of the shoulder.
primarily, shoulder hemiarthroplasty is indicated in patients with grossly displaced three and four part fractures or fracture dislocations, split head fractures, impacted fractures with loss of over 40% articular surface, and anatomical neck fractures of proximal humerus.3456 three or four part fracture and fracture dislocations comprise 5% of all proximal humerus fractures.7 neer had described good and satisfactory results after primary shoulder hemiarthroplasty in displaced three and four part fractures.8 the first generation monoblock prostheses were used by neer (1970).8 later on, the second generation modular prostheses were introduced which provided better soft tissue balancing and good range of motion.
in 1991, the third generation prostheses were introduced which recreates the anatomy of proximal humerus more accurately and were adaptable to the individual bony anatomy.910 success of shoulder hemiarthroplasty depends on soft tissue integrity with reattachment of the tuberosities (rotator cuff), bone quality, glenoid bone stock, stem height, version of the prosthesis, and soft tissue balancing.
in this study, we are proposing to study the functional outcome after primary hemiarthroplasty in three or four part proximal humerus fracture and to compare the results with other similar published studies.
materials and methods 29 patients of three or four part or comminuted proximal humerus fractures (graded according to neer's classification) based on anteroposterior and oblique radiographs of the shoulder who underwent hemiarthroplasty between april 2009 and december 2013 were included in this retrospective study.
all patients had acute injuries and were operated within 1-week of injury.
computed tomography (ct) scan was done in all patients [figure 1b].
ct scan images gave us the fracture pattern and displacement of the fragments, which helped in planning the surgical management.
patients were followed up on outdoor basis and were assessed according to a predetermined protocol.
clinical and functional assessments were done by constant score.11 constant score consists of 0–100 points for the single shoulder.
it is divided into subjective and objective components.
subjective component consists of pain (15 points) and activities of daily living (sleep, work, and recreation/sports activities) (20 points).
objective component consists of a range of motion (40 points) and power of muscles (25 points) around shoulder.
figure 1 (a) preoperative x-ray of proximal humerus fracture dislocation of the right side.
(b) computed tomography scan of proximal humerus fracture dislocation.
(c) immediate postoperative x-ray of hemiarthroplasty.
(d) 1-year-old postoperative x-ray of hemiarthroplasty radiological assessment was done with x-rays of shoulder in anteroposterior and axial views, if possible [figures 1a, c, d and 2a, b].
x-rays were evaluated to assess tuberosity position and its bony union with the proximal humerus, any resorption of tuberosity, distance of top of the humeral head from acromion, and development of radiolucency at bone cement interface.
figure 2 (a) x-ray (l) humerus with shoulder joint showing three part comminuted fracture of the proximal humerus.
(b) 1-year-old postoperative x-ray of hemiarthroplasty (c) clinical photograph showing forward flexion after 1 year.
(d) clinical photograph showing abduction after 1 year postoperative infection and loosening of implant were also recorded.
for postoperative infection, assessment of wound healing and hematological parameters like complete blood counts with erythrocyte sedimentation rate and c-reactive protein levels were recorded at regular intervals.
for loosening of implants, serial radiographs were assessed to see any signs of radiolucency at bone cement interphase.
patients were followed postoperatively at 1 week, 2 week (at the time of suture removal), monthly for next 3 months, and then 3 monthly till the last followup.
patients were followed till the radiological bony union of the tuberosities was seen.
operative procedure all patients were operated in a “beach chair position” under general anesthesia.
in this position we can hyperextend the proximal humerus for canal reaming, cementation, and implantation of prosthesis.
to avoid complications of hypotension associated with this position, the head was never elevated beyond 45°.
calf pumps were used in all cases.
the standard deltopectoral approach was used.
the lesser and greater tuberosities were meticulously dissected with their tendinous attachments.
the tuberosities were later reattached to the proximal humerus for stability of the prosthesis.
the size of the prosthetic head was measured according to the anatomical head.
cemented prosthesis (global advantage shoulder arthroplasty system, depuy, j & j, warsaw, usa) was used in all cases.
pressurized cementing (simplex p bone cement, stryker, michigan, usa) was done by cement gun.
all prosthesis were inserted in 20–30° of retroversion by external rotating and adducting the arm.
the height of the prosthetic stem was determined by the metaphyseal calcar.
in case of severe comminution, pectoralis major insertion was taken as a reference point.
anatomically, prosthetic humeral head lies approximately 5.6 cm proximal to the superior border of the pectoralis major tendon.12 fixations of the tuberosities around the prosthesis were done by making drill holes and were tied to the prosthesis and proximal humerus using ethibond no.
5 sutures (ethicon inc., somerville, nj, usa).
ethibond sutures were passed through the holes over fin and neck of the prosthesis to tightly secure the tuberosities with their soft tissue attachments [figure 3a and b].
one patient also had a fracture of glenoid, anteroinferior articular surface, which needed screw fixation.
the glenoid margins were assessed during the surgery and all osteophytes impinging the soft tissues were carefully removed.
figure 3 (a) photograph showing tuberosity fixation technique through prosthesis.
(b) peroperative photograph showing final tuberosity fixation with the prosthesis postoperatively, shoulder immobilizer was given to all the patients.
pendulum shoulder exercises were started on the 1st postoperative day.
passive anterior elevation and passive abduction started after 1 week and gradually increased.
active shoulder movements were started after 6 weeks when radiological evidence of consolidation of the tuberosities was seen.
results all patients were operated by senior surgeon (rks).
mean followup was 18.28 months (range 12–24 months).
twenty nine patients were included in the study.
three died and two were lost in followup, so a total of 24 patients were finally included in the study.
all the three deaths were caused due to preexisting comorbid conditions, like uncontrolled diabetes mellitus with chronic renal failure in one patient and coronary arterial disease leading to myocardial infarction in two patients.
patients were divided into two groups according to age.
patients with >55 year age were defined as elderly and <55 years as younger age group patients.
twenty patients were elderly (>55 years).
four patients were in younger age group.
in this group of patients, there was marked comminution of the fracture fragments or four part fracture dislocation, so osteosynthesis was not attempted.
mean age was 63.25 years (range 45–79 years).
sixteen patients were male and eight were female.
mean constant score was 56.62 (range 42.5-65.5) points at final followup.
anterior elevation of more than 150° was present in 2 patients and from 90° to 150° in 19 patients [figure 2b and c].
less than 90° of anterior elevation was present in three patients.
mean anterior elevation was 118.2°(range 75°-150°).
functional range of abduction for shoulder was 60–120°.
twenty two patients in our study had a functional range of abduction [figure 2d].
one patient had <60° and one patient had 135° of active abduction.
mean active abduction was 102° (range 50° - 135°).
mean external rotation was 22° (range 15° - 30°).
internal rotation was not satisfactory in five patients according to constant scoring system.
proximal migration of tuberosity was present in four patients.
these patients had decreased abduction with impingement.
no pain to mild pain was present in 21 patients.
three patients had moderate pain at their final followup.
nineteen (i.e., 79.16%) patients were satisfied about their functional outcome.
twelve patients had arthritis of glenoid with marginal osteophytes impinging the soft tissues.
in such cases, removal of osteophytes was done.
tuberosity migration in four patients and higher placement of prosthetic stem in one patient were the causes of discomfort in five patients.
one patient had radiolucency in cement mantle but was not progressive.
clinically, this patient had mild pain on elevation above horizontal level.
there were no intraoperative complications.
no cases of neurological injury, infection, and instability were noted.
heterotrophic calcification was not found in any case.
the revision was not done in any case.
discussion the purpose of this study was to evaluate functional outcome and complications after primary hemiarthroplasty in proximal humerus fracture.
primary hemiarthroplasty in displaced three and four part proximal humerus fracture was initially proposed by neer8 and had found to have good results as compared to conservative management.
primary hemiarthroplasty is indicated in elderly patients with displaced three or four part fractures or fracture dislocation.
in younger patients, with complex, grossly comminuted, or displaced fractures, primary hemiarthroplasty can be considered as a primary treatment.
initial varus alignment >20° is also consider a viable indication of primary hemiarthroplasty because of high failure rate in osteosynthesis.13 results of primary hemiarthroplasty are better than secondary hemiarthroplasty in cases of posttraumatic malunion, nonunion, and avascular necrosis of proximal humerus.141516 we used constant score for functional evaluation which is universally accepted and validated.11 the major aims of hemiarthroplasty in fracture of proximal humerus are pain relief, adequate shoulder function, patient satisfaction, and strength.
meticulous surgical technique and anatomical tuberosity fixation correlate directly with the outcome.
factors that affect the tuberosity union are positioning of prosthesis, stable fixation of tuberosity, and bone quality (rate of nonunion are higher in elderly and in osteoporotic bone).13 higher placement of prosthesis is associated with higher risk of tuberosity nonunion.13 hence, the assessment of stem height at the time of implantation is important.
during surgery, in neutral position, there should be a gap of at least 1 cm or one finger width between the implant and the acromion.
boileau et al.17 showed that tuberosity healing was a major determinant of functional outcome.
in their study, 23% patients had detachment and migration of tuberosity, while in our study that was only 16.67%.
modern prosthesis has holes over proximal end of the prosthesis for better attachment and integration of tuberosities.
anatomical healing of tuberosity gives good functional outcome due to the restoration of rotator cuff anatomy.
tuberosity migration was the main complication in our study and produced inferior results in four patients (16.67%).
castricini et al.18 performed primary shoulder hemiarthroplasty in 57 patients.
mean constant score was 59.2 at mean followup of 52 months in their study which reflects good function.
in our study, mean constant score was 56.62 after mean followup of 18.28 months.
although constant score remains low in primary hemiarthroplasty, it is acceptable in low demanding elderly patients.
major advantage of hemiarthroplasty is pain relief which is the main factor for patient satisfaction.
castricini et al.
mentioned very satisfactory results in 91% patient in spite of low constant score.
kontakis et al.
had done a large systemic review of literature with primary shoulder hemiarthroplasty for proximal humerus fracture.19 they reviewed 16 similar studies with 810 shoulder hemiarthroplasty done for three or four part proximal humerus fracture and fracture dislocations.
the mean active anterior elevation was 105.7° (10–180°) and mean abduction was 92.4° (15–170°).
in their study, the main complication was associated with tuberosity healing which occurred in 11.15% cases.
heterotrophic ossification was found in 8.8% cases, and proximal migration of humerus head was in 6.8% cases.
the mean constant score was 56.63 (11–98).
in our study, no patient had severe pain.
three patients had moderate pain at their final followup, while 21 patients had zero to mild pain.
severe pain in hemiarthroplasty was related to the stiffness of shoulder.
early passive movement of shoulder was started in all patients, so stiffness did not develop in any patient.
our study showed that older age and comminution of fracture had significantly affected tuberosity healing.
the pain free adequate range of motion of shoulder is the primary goal in shoulder hemiarthroplasty.
tuberosity healing plays the main role in good range of motion and is an important determinant of functional outcome.
reoperation rate in shoulder hemiarthroplasty is very low and requires in situations of infection, loosening of cement mantle, and instability.
our study had no control group, shorter mean followup of 18.28 months and small sample size (n = 29) were limitations of this study.
further study with large sample size and longer followups are required to access the factors related to wear rate and implant loosening.
it is an institutional study done to assess the results of comminuted proximal humerus and to compare the results with the studies done previously.
it is a limitation that no new information has been derived.
to conclude this study showed that hemiarthroplasty in a grossly comminuted proximal humerus fracture is a viable alternative to osteosynthesis.
tuberosity healing plays a main role in good range of motion and better functional outcome after shoulder hemiarthroplasty.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
background: several modalities of treatment are being used for the management of proximal humerus fractures.
primary hemiarthroplasty in proximal humerus fracture is indicated in three or four part fracture or fracture dislocations.
it is also indicated if fracture involves a large area of articular cartilage loss and viability of head is doubtful.
we studied the functional outcome of hemiarthroplasty in comminuted proximal humerus fracture.
materials and methods: 29 patients of three or four part proximal humerus fractures, (according to neer's classification) who underwent primary shoulder hemiarthroplasty were included in this retrospective study.
20 patients were of more than 55 years of age.
functional evaluation based on constant score and radiological assessment by periodic x-rays were done.
all patients were operated in a ‘beach chair position’.
the lesser and greater tuberosities were dissected with their tendinous attachments and were later reattached to the proximal humerus for stability of the prosthesis.
cemented prosthesis was used in all cases.
results: three patients died and two patients were lost to followup during the course of the study, so 24 patients were finally included in the study.
mean constant score was 56.62 (range 42.5-65.5) after mean followup of 18.28 months (range 12-24 months).
mean anterior elevation was 118.2° (range 75°-150°) and mean active abduction was 102°(range 50°-135°).
nineteen patients (79.16%) were satisfied about their functional outcome.
proximal migration of tuberosity was present in four patients.
these patients had decreased abduction with impingement.
one patient had higher placement of prosthesis and one patient had radiolucency at bone cement interface.
there were no heterotopic ossification, dislocation, superficial, or deep infection.
conclusion: this study showed that hemiarthroplasty in a grossly comminuted proximal humerus fracture is a viable alternative to osteosynthesis.
tuberosity healing plays a main role in good range of motion and better functional outcome after shoulder hemiarthroplasty.
