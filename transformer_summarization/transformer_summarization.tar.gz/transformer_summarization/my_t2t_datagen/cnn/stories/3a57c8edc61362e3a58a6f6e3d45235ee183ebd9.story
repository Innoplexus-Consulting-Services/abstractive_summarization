introduction takayasu arteritis (ta) is a rare, inflammatory disease of the aorta and its major branches.
the etiology is still unknown, but some factors have been described to play a probable role in the pathogenesis of ta: the infection of mycobacterium tuberculosis, genetic factors (presence of hla-b52, hla-b39, hla-dr b1-1301/1302) and autoimmune processes (there are some diseases which occur more frequently in patients with ta, e.g.
rheumatoid arthritis, systemic lupus erythematosus, seronegative spondyloarthropathies, anterior uveitis) [1].
the disease is more common in young women in south-west asia, south and central america and africa [1].
the predominance of women ranges from 1 : 1.3 in india to 1 : 9 in japan [2].
the general incidence is estimated to be 0.8–2.6/1,000,000 per year [3].
the inflammation starts in the adventitia and expands towards the inner layers, causing stenosis and occlusions as well as dilatations and aneurysms of vessels [1].
the patient may present a wide spectrum of symptoms, depending on the localization of pathological changes, but the most common are a weak pulse or its absence on the brachial artery and a difference in the systolic pressure above 10 mm hg between the upper extremities.
increased erythrocyte sedimentation rate (esr) and concentration of c-reactive protein (crp) are common.
to visualize changes in vessels, doppler sonography and computed tomography angiography (cta) are helpful.
treatment of ta is based on glucocorticoids in large doses.
because of the high rate of relapse during tapering of corticosteroids, it is also necessary to use immunosuppressants such as methotrexate, azathioprine, mycophenolate mofetil, cyclosporine a, cyclophosphamide or leflunomide [3].
there are some clinical trials on the use of biological drugs in ta – the outcomes seem promising, but it is still necessary to conduct some other tests [4–6].
another way of treatment is angiosurgery.
endovascular interventions should be performed after remission is achieved, because of the high risk of restenosis [3] (except life-threatening changes, which need to be treated as soon as possible).
case report a 42-year-old woman without relevant past medical history was admitted to the department of rheumatology in june 2015, because of weakness, joint pain, periodical feverishness, a feeling of dryness in the mouth, eyes and vagina and chronic anemia.
the symptoms started about two years earlier.
in addition the patient observed a tumor on the back of her neck which appeared in january 2015. physical examination revealed a weak pulse on the upper extremities, difficulty to measure blood pressure, tumor of the neck, painful in palpation, erythema of the face and neckline, enlarged tonsils and pain of the knee joints, without swelling.
laboratory tests showed increased esr (106 mm/h), crp (56 mg/l), slight anemia (hemoglobin 11.3 g/dl), elevated concentration of immunoglobulins, presence of rheumatoid factor (rf) and anti-nuclear antibodies (anas) titer 1 : 1000 with specific ro52 antibodies and slight erythrocyturia without proteinuria.
the immunofixation excluded the presence of monoclonal proteins.
because of mouth and eye dryness a minor labial salivary gland biopsy was performed.
histopathological assessment confirmed monocellular cell infiltrations in minor salivary glands fulfilling criteria of focus score 1. chest x-ray revealed changes which suggested atelectasis or inflammation – for this reason high-resolution computed tomography (hrct) was performed.
it showed parenchymal consolidation, enlarged paratracheal and para-aortic lymph nodes and thickening of walls of the ascending aorta, aortic arch and its branches (fig.
1).
doppler ultrasonography revealed significant thickening of the walls of the common carotid arteries (cca) on both sides (fig.
2) and critical stenosis of the left subclavian artery and slighter stenosis of the right one.
the diagnosis of takayasu arteritis was made (on the basis of classification criteria published by the american college of rheumatology (acr) in 1990, presented in table i [7]), but the neck tumor needed further diagnostics.
table i classification criteria of takayasu arteritis (american college of rheumatology, 1990 [7]) age at disease onset ≤ 40 years claudication of extremities, especially the upper decreased brachial artery pulse difference of > 10 mm hg in systolic blood pressure between arms bruit over subclavian arteries or aorta arteriogram abnormality a diagnosis of takayasu arteritis requires presence of at least 3 of 6 criteria fig.
1 axial image of computed tomography angiography (cta) – marker on thickening of aortic wall.
fig.
2 doppler ultrasonography of affected vessels.
a) evident, smooth thickening of the common carotid artery wall, particuraly in the birurcation (up to 2.8 mm).
b) stenosis of the left sublavian artery.
courtesy of rafał małecki, md, phd.
computed tomography of the neck showed a mass 3.3 × 3.0 × 7.0 cm in size within soft tissues with contrast enhancement similar to the muscles.
this tumor was penetrating between spinous processes of c1/c2, c2/c3 and c3/c5.
the patient was consulted with a neurosurgeon – the biopsy was planned after the magnetic resonance imaging (mri), and there was no need to delay the treatment with glucocorticoids.
the patient took three intravenous infusions of methylprednisolone, 500 mg each.
after that oral prednisone in a dose of 20 mg per day was prescribed.
the therapy resulted in reduction in esr (55 mm/h) and normalization of crp (1.72 mg/l) and the patient was discharged.
in august the patient was admitted again to evaluate the course of the disease and treatment.
she reported improvement and the tumor on her neck was significantly smaller.
the blood tests showed a further decrease in esr (34 mm/h), normal level of crp (3.72 mg/l), leucocytosis related to the therapy with glucocorticoids and hypercholesterolemia.
doppler ultrasonography revealed smaller inflammatory infiltration of both cca and less enlarged lymph nodes.
mri of the neck showed thickening of paravertebral soft tissues, encompassing a nuchal ligament, sized 7.5 mm × 22 mm × 28 mm.
the image suggested inflammatory infiltration, probably of autoimmune etiology (fig.
3).
the patient was consulted again with a neurosurgeon – the mass was considered an inflammatory infiltration and the biopsy was not necessary.
during that hospitalization two infusions of methylprednisolone were administered, 500 mg each, the dose of prednisone was decreased to 15 mg per day and methotrexate in a dose of 15 mg per week was prescribed.
fig.
3 magnetic resonance after contrast: coronal image of paraspinal soft tissue tumor.
in september the next evaluation was performed – laboratory tests were similar (esr 36 mm/h, crp 2.25 mg/l) and the image of doppler ultrasonography of cca was stable.
because of critical stenosis of the left subclavian artery and arm claudication angio-ct was performed (fig.
4) and the patient was qualified for angiosurgical treatment.
percutaneous balloon angioplasty with implantation of two stents within the left subclavian artery was performed.
after angiosurgical intervention normal blood circulation in the upper left limb with presence of a pulse was found.
the patient reported improvement until 6 weeks after angioplasty, when she notified fatigue and a weak pulse in the left upper limb.
doppler ultrasound was not enough to assess potential changes in the upper extremities, but the ct angiography did not reveal critical stenosis or progression of the inflammatory process, but stenosis occurred behind the stent.
these results were consulted with the angiosurgeon, who decided not to perform a reoperation if there was no critical stenosis, due to the risk of frequent recurrence after surgical interventions.
after the operation clopidogrel in a dose of 75 mg per day was prescribed and acetylsalicylic acid was maintained in the treatment.
table ii presents stages of therapy used and its results.
table ii stages of therapy performed stage result inducing remission: methylprednisolone i.v.
3 × 500 mg prednisone p.o.
20 mg/day remission achieved: decrease in esr from 106 mm/h to 34 mm/h normal level of crp (from 56 mg/l) significant reduction of neck tumor maintaining remission: – methylprednisolone i.v.
2 × 500 mg – prednisone p.o.
15 mg/day – methotrexate p.o.
15 mg/week stable course of disease: esr 34–36 mm/h normal level of crp improvement reported by patient surgical treatment: percutaneous balloon angioplasty with implantation of two stents within left subclavian artery normal blood circulation in upper left limb with presence of pulseimprovement reported by patient fig.
4 coronal reconstruction of computed tomography angiography (cta): stenosis of subclavian artery.
discussion ta is a rare, life-threatening disease without intensive treatment.
the 5-year survival is 92.9%, and 10-year survival is 87.2% [8].
that is why early diagnosis and intensive treatment are so important to prevent serious complications such as stroke, cardiac failure, renovascular hypertension, pulmonary hypertension, pulmonary embolism or acute limb ischemia.
the main causes of death in patients with ta are congestive heart failure and renal failure [9].
to monitor the disease activity, criteria published by kerr (1994) are used (table iii) [10].
these criteria are useful not only to evaluate the effectiveness of a treatment, but also to choose a safe time to conduct endovascular interventions.
table iii criteria of disease activity [10] systemic symptoms, e.g.
fever, myalgia, arthralgia (other causes excluded) ischemia or inflammation, e.g.
claudication, bruit, carotidynia elevated esr arteriogram abnormality active disease is defined by new occurrence or deterioration of 2 or more criteria the therapy of ta includes glucocorticoids, immunosuppressive agents and biological drugs (as mentioned above, more clinical trials are still required).
in this case the initial dose of prednisone was lower than that recommended by the acr [11] due to three pulses of methylprednisolone administered at the beginning of treatment.
it is recommended that the initial high-dose should be maintained for a month and tapered gradually, so at 3 months the dose should be between 10 and 15 mg per day.
in addition, immunosuppressive agents, such as azathioprine (2 mg/kg/day) and methotrexate (20–25 mg/week), are recommended [11].
in our patient we chose methotrexate in a starting dose of 15 mg per week.
this therapy resulted in maintaining remission, so the dose was not increased.
in case of flare the target dose of 20–25 mg per week should be considered.
the discussed therapy is not the only treatment needed to ensure the patient’s complete care.
one of the important complications of ta is arterial hypertension, mostly caused by involvement of the main renal arteries and its large branches.
new-onset hypertension is reported in about 45% of takayasu arteritis cases, and its frequency in the course of the disease increases to 60% [12].
the difficulty lies in measuring the blood pressure – it cannot be performed on pathologically changed arteries, so in the majority of patients it is necessary to measure it on the tibias.
our patient developed arterial hypertension and tachycardia, so first bisoprolol and next perindopril were introduced to the therapy.
angio-ct of the abdominal aorta did not reveal features of stenosis or inflammation of the renal arteries.
we also advised the patient to take acetylsalicylic acid (in a dose of 75 mg per day), because antiplatelet therapy was considered to be associated with a lower frequency of ischemic events [13].
another important issue of monitoring patients with ta is echocardiography with assessment of aortic regurgitation and left ventricular hypertrophy, due to arterial hypertension [14].
it is noteworthy that we observed the presence of a palpable mass at the back of the patient’s neck, which may suggest its oncological background.
ct of the neck revealed a tumor within the soft tissue with contrast enhancement similar to the muscles.
the neurosurgeons suggested that the biopsy of this lesion is necessary, but first mri of this area should be performed.
while waiting until mri could be conducted we started treatment with pulses of methylprednisolone considering our patient’s condition.
after 8 weeks mri was performed, and it showed significant reduction of tumor size and suggested an image typical for inflammatory infiltration.
the patient was consulted with a neurosurgeon once again, and considering reduction of the tumor in mri imaging and in palpation, the good response to glucocorticoids, and reduction in ers and crp levels, no biopsy was performed at this time.
it is difficult to find a similar case report with an inflammatory tumor in the course of takayasu disease in the literature.
a case with a painful palpable tumor in the right lateral neck, which turned out to be calcified thrombus in the bulb of right common carotid artery, has been reported [15].
the patient was admitted to our department to diagnose for suspected sjögren syndrome, because of dryness in the mouth, eyes and vagina, chronic anemia, elevated ers and crp, and presence of rheumatoid factor (rf) and anti-nuclear antibody.
during physical examination we found difficulties in measuring blood pressure and a weak pulse on the upper limbs, so we started diagnostics for large vessel vasculitis, and it was found to be the patient’s main problem.
biopsy of the salivary gland also revealed an early stage of sjögren disease.
despite absence of anti-ro and anti-la antibodies, the diagnosis was made based on criteria published by the acr in 2012 [16] (positive rheumatoid factor and ana titer 1 : 320 and positive labial salivary gland biopsy were found).
takayasu arteritis may be associated with other autoimmunological disorders, and the most frequent are disseminated lupus erythematosus, scleroderma, pyoderma gangrenosum, rheumatoid arthritis, ankylosing spondylitis, still’s disease, leśniowski-crohn disease, colitis ulcerosa, sarcoidosis, behçet disease and immune glomerulonephritis [17].
the patient is still under the care of the department of rheumatology.
it is important to provide regular echocardiography and control the blood pressure, parameters of inflammation, renal function and degree of stenosis of large vessels, because proper treatment resulting in maintaining remission gives a chance to prevent serious complications leading even to premature death.
@highlight
takayasu arteritis is a rare, idiopathic inflammatory disease of the aorta and its major branches, usually affecting young women of asian descent.
in the course of the disease stenosis, occlusions as well as dilatations and aneurysms of vessels occur.
because of many possible localizations of pathological changes, the symptoms have a wide range, but the most common are a weak pulse or its absence on the brachial artery and a difference in systolic pressure above 10 mm hg between the upper extremities.
here we present a case report of a young woman with takayasu arteritis, who presented a palpable mass in the back of her neck, significantly diminished after treatment with glucocorticoids.
