introduction conjoined twins are identical twins whose bodies are joined in utero.
it is a rare phenomenon, with an estimated incidence ranging from 1 in 50,000 births to 1 in 200,000 births.
[1] they are monozygotic and monochorionic identical twins who develop with a single placenta from a single fertilised ovum.
here, we report the successful anaesthetic management of a case of ischiopagus twins’ separation stressing the importance of a multidisciplinary approach, thorough pre-operative evaluation to assess organ sharing and cross circulation, meticulous planning, as well as vigilant intra-operative monitoring and intensive post-operative care.
case report the twins were born to a primigravida as a full-term normal vaginal delivery.
the diagnosis was missed during the antenatal period, and after delivery, the babies were referred to our centre for expert management.
they were classified as ischiopagus tetrapus [figure 1].
the parents provided consent for reporting the details of their babies.
figure 1 ischiopagus tetrapus conjoined twins pre-operative evaluation revealed that baby a had normal facial features whereas baby b had dysmorphic facies, cleft lip and palate and a large cystic hygroma.
imaging studies revealed that they had a shared pelvis and a communicating spinal canal with a small meningocele.
while baby a had a normal cardiopulmonary system, baby b had non-aerated lungs with visible tracheal shadow in chest x-ray [figure 2] and a univentricular heart with multiple other cardiac anomalies.
in view of the above findings, baby b was diagnosed to be non-salvageable and considered to be a parasite, and hence, an early separation was planned.
both babies also had anorectal and urogenital malformation, and a colostomy was performed for baby a on the second post-natal day under local anaesthesia.
the babies were nursed in the neonatal intensive care unit (icu).
the baby a was fed with expressed breast milk, and baby b with parenteral nutrition, supplemented with vitamin k injections and fresh frozen plasma transfusions to prepare them for surgery.
figure 2 x-ray of the conjoined twins the non-salvageability of the parasitic twin was explained to the parents, and after detailed discussion, a decision to separate the twins to save the healthy baby was taken.
written informed consent, after explaining every detail, was obtained from the parents.
a multidisciplinary team including paediatric surgeons, anaesthesiologists, cardiothoracic surgeons, neurosurgeons and orthopaedic surgeons was formed to plan the surgery.
anaesthetic plan was formulated to ventilate both the babies.
ventilating baby b, in addition, avoided the shunt effects due to cross-circulation between the babies.
the surgery was planned to be conducted on the post-natal day 13. two anaesthesia machines and monitors were kept ready for each baby, and two anaesthesiologists were present to handle each baby.
it was planned to intubate baby a first, followed by baby b to supplement oxygenation.
on the day of surgery, the twins were brought to the warm theatre and pre-induction monitors were attached.
the monitors included non-invasive blood pressure and pulse oximeter.
there was no disparity between the vitals of the two babies, except that baby b had an oxygen saturation of 93% only while baby a had 100% saturation.
their combined weight was 3.25 kg.
intravenous (iv) access was obtained in baby a using a 24-gauge cannula and injection atropine 0.12 mg was administered iv.
the heart rate of baby b also increased from 144/min to 184/min, confirming the presence of cross-circulation.
baby a was pre-medicated with midazolam and fentanyl, induced using thiopentone, intubated after administering succinylcholine and was maintained on nitrous oxide, isoflurane and atracurium.
laryngeal structures of the baby b could not be identified during laryngoscopy, and intubation was unsuccessful even after multiple attempts.
hence, it was decided to insufflate oxygen through nasal catheters.
baby b was given additional fentanyl and midazolam.
maintenance fluid therapy utilised consisted of 0.18% saline and 4% dextrose.
post-induction monitors included oesophageal stethoscope, temperature probe, urinary catheter and central venous catheter.
to prevent hypothermia, babies were placed on warming mattresses and fluid warmers were used.
initially, vascular, bladder and ureter separation was performed, followed by vertebrotomy at the lower lumbar spinal levels and the parasitic child was separated.
later, the lower limbs of the parasitic child that were still attached to baby a were disarticulated.
there was massive blood loss which was replaced using 390 ml fresh whole blood, 30 ml fresh frozen plasma and 150 ml platelet-rich plasma.
the baby did not show signs of haemodynamic instability and the rest of the intra-operative period was uneventful.
at the end of surgery, baby was shifted to the neonatal icu for elective post-operative ventilation.
intensive monitoring was continued in the post-operative period to detect any haemodynamic instability, hypothermia, hypoxia, acid–base and electrolyte imbalance.
haematocrit, electrolytes and acid–base status were within normal limits.
iv paracetamol was given for post-operative analgesia and the baby was extubated, the following day without any complication.
discussion perioperative management of conjoined twins requires a multidisciplinary approach and teamwork.
this rare but fascinating congenital problem is of considerable interest to anaesthesiologists.
conjoined twins are classified depending on the site of union of their body parts as thoracopagus (40%) - thorax, omphalopagus (33%) - lower abdomen, pyopagus (19%) - sacrum, ischiopagus (6%) - pelvis, parapagus (5%) - lateral union of lower half or craniopagus (2%) - skull.
[2345] parasitic twins are asymmetrical twins, of whom one is either small or less formed.
foetus in foetus is an asymmetrical intra-parasitic twin.
each type of conjoined twins has challenges specific to their type of conjunction.
possible involvement of pelvis, gastrointestinal and genitourinary tract in ischiopagus makes them the complicated type of conjoined twins.
[6] rehearsal in the operating room may be done pre-operatively involving all concerned, assigning specific tasks to each member of the team.
anaesthetists should ensure the availability of a double supply of all necessary equipment: anaesthesia machines, monitors, infusion pumps, fluid warmers and temperature control devices.
the operating theatre should be arranged to suit the type of twins; with thoracopagus and craniopagus twins, it is helpful to have the anaesthetic machines at the same end of the table; whereas with ischiopagus twins’ surgery, it becomes necessary to have the machines at the opposite ends of the operating table.
colour coding can be used to identify each infant's lines, monitors, equipment, and drugs.
choice of anaesthetic induction technique depends as usual on the factors such as presence of an iv access before induction, presence of difficult airway, haemodynamic stability of each infant and preference of the anaesthetist.
the presence of cross-circulation can be tested by administering atropine to one baby and assessing the changes in heart rate in the other baby.
[7] in the presence of cross-circulation, there is possibility of passage of drugs given to one twin to the other which may cause sedation and airway obstruction in the other and the anaesthesiologist must be aware of this possibility.
[8] regardless of the presence and degree of cross-circulation, drugs should be administered as they would be given for two separate infants.
in most cases of symmetric twins, both the infants weigh almost the same; hence, it is a routine practice to take their combined weight and half it to arrive at the weight of each infant.
anomalies of the airway and peculiar positioning can pose significant challenges during intubation.
[9] the amount of intra-operative blood loss is mainly dependent on the extent of fusion and the complexity of the organ involvement.
vigilant intra-operative monitoring utilising invasive arterial and central venous lines is necessary.
serial estimation of haematocrit, acid–base status and electrolytes are also needed.
a major concern during separation surgery is hypothermia caused by an extensive surgical wound increasing heat losses and long duration of surgery.
[10] cardiovascular collapse can occur at the point of separation which has been attributed to adrenal insufficiency.
[11] immediate post-operative problems are mostly related to the consequences of massive blood transfusion, prolonged duration of surgery and alterations in pre-operative anatomy.
cardiovascular and respiratory complications are the most common causes of perioperative mortality.
conclusion anaesthetic concerns during the intra-operative management of conjoined twins’ separation surgery include the need to care for two babies, presence of cross-circulation, other congenital anomalies of the babies, problems of paediatric age group, massive blood loss, long duration surgery, intraoperative hypothermia and necessity of excellent pre-operative planning and rehearsal.
detailed pre-operative evaluation, planning and multidisciplinary approach are the basis of successful management of conjoined twins separation.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
conjoined twins are a rare congenital anomaly of unknown aetiology.
we report the successful anaesthetic management of separation of ischiopagus tetrapus conjoined twins.
the importance of a multidisciplinary approach, thorough pre-operative evaluation and planning, vigilant monitoring and anticipation of complications such as massive blood and fluid loss, haemodynamic instability, hypothermia and intensive, post-operative care are emphasised.
