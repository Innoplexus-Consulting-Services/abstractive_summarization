introduction intravaginal testicular torsion (itt) is a genuine surgical emergency, affecting mainly adolescents and young adults.
after a few hours, ischemic injury leads to testicular necrosis or atrophy.
in order to reduce organ loss, the time between the beginning of symptoms and treatment must be reduced.
the importance of swift treatment for itt has been recognized for more than a century.
nash, in 1893, was able to salvage a testicle by timely intervention (1).
three decades later, thorek (2) noted that, in both of his cases, the organ would have been saved had immediate surgery been undertaken.
fortunately, testicular salvage rates have been improving, although not everywhere (3, 4).
moreover, it is not unusual to see testicular necrosis with short duration of symptoms, suggesting that the outcome of itt is not exclusively governed by the duration of ischemia.
one candidate risk factor is the testicular rotation, i.e., the number of turns of the spermatic cord, that appears to damage the organ in a dose-dependent manner: more turns, more vascular occlusion, more ischemia (5, 6).
age is also cited as another risk factor, but reports diverge as to which ages are at increased risk.
a worse prognosis associated with younger ages has been attributed to difficulties in communicating symptoms, and to reliance in potentially misleading clinical diagnosis (7–9).
on the other hand, older patients were reported to have worse outcomes by holding up to seek medical attention, as well as to diagnostic delays due to the perception that itt is rare in older adults (10–12).
we found ourselves in a favorable position to investigate the influence of these additional risk factors on the outcome of itt.
our case load is maximized by the referral of all patients suspected of itt in our region, a result of the continuous presence of an urologist in our emergency department.
hence, we expect to, with the use of multivariate logistic regression, understand the relationship between ischemia time, testicular rotation and age in the surgical outcome of itt.
patients and methods data collection and definition of variables following institutional review board approval, we retrieved the medical records of all patients surgically treated for itt from january 1, 2012 to january 31, 2014. recovered data included: the patient's ages; date and time of symptoms, as well as date and time of urological examination and operation, as date-time variables; the number of turns (rotation) taken by the testicle, as quantified by the surgeon at operation, in π radians (1.0π radian=180°); and surgical outcome (binary: orchidectomy or orchidopexy).
the decision to remove the organ was taken by the surgeon if, after surgical detorsion and placement of the organ at a saline bath at 37°c for at least 20 minutes, no bright red arterial parenchymal bleeding was seen following a stab incision of the tunica albuginea.
only intravaginal torsion cases were included.
presentation delay (prd) was calculated subtracting date and time of surgery from date and time of symptom's onset.
surgical waiting times, or surgical delay (surgd) was calculated as the difference between date and time of hospitalization and date and time of surgery.
treatment delay (trd) equaled the arithmetic sum of presentation and surgical delays.
all variables were included in an electronic spreadsheet for statistical analysis.
statistical analysis we first tested for differences in the explanatory variables according to surgical outcome: orchidectomy or orchidopexy.
the second stage of the analysis involved multivariate logistic regression.
we also studied surgd in the subset of patients with prd less than 24 hours, as, by our unit's treatment algorithm, patients examined within 24 hours are offered immediate surgery, whereas those with later presentation are first examined with doppler ultrasound, and offered surgery if results indicate itt.
all analysis was conducted with the r statistical language, version 3.2.3 (13) and its package rms (14).
statistical significance was established at p<0.05 and confidence intervals (ci) at 0.95. non-parametric analysis the explanatory variables age, trd, prd, surgd, and rotation did not distribute normally, so differences were evaluated with the mann–whitney test.
also, because of non-normalcy of distributions, the relationship between age and prd was studied with kendall's rank-based correlation test.
logistic regression backwards step-down logistic regression, removing all cases with missing values, included, initially, the main effects of the predictor variables: age, prd, surgd and rotation, as well as the 2–way interactions: prd x rotation and surgd x rotation.
we did not include trd in the initial model, since it is the linear combination of prd and surgd.
the minimal adequate model was selected with akaike's information criteria (aic).
probabilities, odds ratios (or) and relative odds ratios (ror) were computed from the final model's coefficients.
confidence intervals and statistical significance for model parameters, probabilities, or and ror were also established at 0.95 and at p<0.05.
results we identified a total of 142 itt patients, most of them adolescents (median age 15.8 years, iqr 4.7 years).
median surgd equaled 5.0 hours, contrasting with a median prd of 24.5 hours (table-1).
in 25 cases we could not recover information on rotation, so analysis involving this variable was performed on the remaining 117 cases.
overall, 75 patients (52.8%) underwent orchidectomy.
table 1 overall results.
n = 142 median range iqr age (years) 15.8 8.1 – 42.3 4.7 prd (hours) 24.5 1.1 – 609.0 77.0 surgd (hours) 5.4 0.5 – 145.5 18.0 trd (hours) 30.0 2.83 – 681.0 101.5 n = 117 rotation (π radians) 2.0 0.0 - 6.0 1.0 prd = presentation delay; surgd = surgical delay; trd = treatment delay; rotation = testicular rotation; iqr = interquartile range bivariate analysis age age was not significantly different between patients with patients undergoing orchidectomy or orchidopexy (15.7 vs. 15.8 years, p=0.89, figure-1, table-2).
also, there was no correlation between age and prd (kendall's tau=-0.02, p=0.76).
figure 1 age distribution of patients either submitted to orchidopexy or orchidectomy.
table 2 bivariate analysis.
overall orchidectomy orchidopexy p (mw) n 142 75 (52,8%) 67 (47,2%) age (years) range 8.0 – 42.3 8.0 – 42.3 8.8 – 34.6 0.965 median (iqr) 15.8 (4.7) 15.7 (4.6) 15.8 (5.9) prd (hours) range 1.1 – 609 3.2 – 609.0 1.1 – 100.0 <0.001 median (iqr) 24.5 (77.0) 79.5 (110.8) 8.0 (8.4) surgd (hours) range 0.5 – 146.0 0.5 – 146.0 0.5 – 51.0 <0.001 median (iqr) 5.3 (18.0) 14.0 (24.5) 2.7 (3.0) surgd with prd < 24 hours range 1.0 – 15.5 1.0 – 15.5 1.0 – 10.5 0.176 median (iqr) 2.7 (2.5) 4.0 (2.2) 2.5 (2.5) n 117 61 56 rotation (π radians) range 0.0 – 6.0 1.0 – 6.0 0.0 – 5.0 <0.001 median (iqr) 2.0 (1.0) 3.0 (2.0) 2.0 (1.0) age (years) range 8.1 – 42.3 8.1 – 42.3 8.9 – 34.6 0.773 median (iqr) 15.9 (5.6) 15.8 (4.4) 16.0 (5.8) prd (hours) range 1.1 – 609.0 3.2 – 609.0 1.1 – 100.0 <0.001 median (iqr) 25.8 (80.9) 85.0 (113.0) 8.4 (10.5) surgd (hours) range 0.5 – 114.0 0.5 – 114.0 0.5 – 51.0 <0.001 median (iqr) 5.8 (19.3) 16.0 (25.0) 3.0 (3.2) surgd with prd < 24 hours range 1.0 – 10.5 1.0 – 5.7 1.0 – 10.5 0.688 median (iqr) 2.9 (2.9) 4.0 (2.0) 2.8 (2.5) upper part of the table with n = 142, full dataset; lower part of the table with n = 117, dataset with complete variable information.
iqr = interquartile range; prd = presentation delay; surgd = surgical delay; rotation = testicular rotation; mw = mann–whitney's test.
treatment delay trd was significantly longer in patients that underwent orchidectomy (median 101.5 vs. 10.5 hours, p < 0.001).
both components of trd: prd (median 79.5 vs. 8.0 hours, p < 0.001, figure-2) and surgd (median 14.0 vs. 2.7 hours, p < 0.001), were also significantly longer in patients with lost testicles.
surgd was significantly different between patients with prd shorter or longer than 24 hours (median 2.7 vs 19.0 hours, p < 0.001).
however, among patients presenting before 24 hours of symptoms, surgd was not significantly different between orchidectomy and orchidopexy cases (median 4.0 vs 2.5 hours, p = 0.1; figure-3).
twelve patients presenting before 24 hours underwent orchidectomy, including a case with prd shorter than 4 hours.
in contrast, 10 patients with prd longer than 24 hours had their testicles preserved, including a patient symptomatic for 100 hours.
figure 2 distribution of presentation delay between patients either submitted to orchidectomy or orchidopexy.
figure 3 a: distribution of treatment, presentation and surgical delay among all patients; b: distribution of surgical delay between patients either submitted to orchidectomy or orchidopexy, with presentation delay < 24 hours rotation among the 117 patients analyzed, 61 (52.1%) underwent orchidectomy and 56 (47.9%) orchidopexy.
ages, prd and surgd had a similar distribution when compared with the full dataset (table-2), but rotation was significantly different between patients submitted to orchidectomy or orchidopexy (median 3.0π vs. 2.0π radians, p < 0.001, figure-4).
all patients with rotation greater than 5.0π radians underwent orchidectomy, whereas all patients with less than 2.0π radians had their testicles surgically salvaged.
figure 4 differences in the magnitude of torsion (rotation, in π radian) between patients either submitted to orchidectomy or orchidopexy.
logistic regression the minimal adequate model included only prd (z = −4.64, p < 0.001) and rotation (z = −3.41, p < 0.001) as adverse predictors of surgical outcome (table-3, figure-4).
rotation decreased the likelihood of orchidopexy after controlling for prd.
the ror for orchidectomy with an increasing rotation of 1.0π to 2.0π radians, with prd fixed at 6 hours, equaled 2.30 (ci 1.42 – 3.10), whereas the ror increasing prd from 6 to 12 hours with a 2.0π radians rotation was computed at 1.43 (1.23 – 1.66).
table-4 contains the probabilities of orchidopexy according to prd and rotation, computed from the fitted model.
table 3 results of multivariate logistic regression.
parameter estimate (ci) se or (ci) p 1 4.19 (2.57, 5.82) 0.83 - <0.001 prd (hour) −0.06 (−0.08, −0.03) 0.01 0.94 (0.92, 0.97) <0.001 rotation (π radian) −0.83 (−1.31, −0.35) 0.24 0.43 (0.27, 0.70) <0.001 se = standard error; ci95 = 0.95 confidence interval; or = odds ratio for testicular salvage, by increasing the explanatory variables by one unit; prd = presentation delay in hours; rotation, magnitude of rotation, in complete turns.
table 4 probabilities of testicular salvage, computed from the model.
prd (hours) rotation (π radians) 6 12 24 1 0.953 (0.718, 0.995) 0.934 (0.605, 0.994) 0.874 (0.358, 0.990) 2 0.898 (0.450, 0.993) 0.860 (0.331, 0.991) 0.751 (0.152, 0.986) 4 0.624 (0.078, 0.995) 0.538 (0.049, 0.982) 0.363 (0.018, 0.973) probability (with 0.95 confidence intervals).
prd = presentation delay; rotation, magnitude of rotation of the spermatic cord.
discussion we observed an overall low surgical salvage rate (47.2%) with rather long trd and prd, reiterating that time is key when treating testicular torsion, for prolonged ischemia times are unequivocally associated with disappointing salvage rates (3, 15, 16).
limited knowledge of this fact may partially explain the 10% salvage rate often seen until 40 years ago (17), and, thankfully, there has been a trend towards better salvage rates in the last decades.
williams (18), in 1979, salvaged 69% of his cases, and jones (7), in 1986, 75%.
the best salvage rate so far recorded, 97.6%, comes from ireland (19), even though at a cost of a 52.9% false-positive rate.
a noteworthy example of diagnostic shrewdness can be seen in the work of sparks (20), from rugby, england, presenting a 96% salvage rate as early as 1972. delays in treating testicular torsion are sometimes attributed to the lack of diagnostic acumen of emergency department staff, which can lead to medico-legal consequences.
however, such argumentation overlooks the fact that treatment delays have two main components: the time interval between the beginning of symptoms and evaluation by the final assistant physician, and the interval between clinical evaluation and treatment itself.
we were able to see that, in our population, the time before urological evaluation (presentation delay, prd) was the dominant component of the delay in treatment.
elsewhere, there are examples that the responsibility for treatment delay may not lie solely with the emergency department staff, which can, point-of-fact, attain high diagnostic accuracy (6, 7, 21).
investigators from california noted that patients' transfers from primary and secondary to tertiary facilities was an independent risk factor for orchidectomy (22).
in addition, an english study (15) revealed that caregivers waited in average 32 hours (range 3–240 hours) to bring a patient with acute scrotum to medical attention.
this extended time was claimed to be responsible for their 45% salvage rate.
there is disagreement about the role of age in the prognosis of testicular torsion.
one can find evidence attributing worse prognosis to younger (7–9, 23), older (10–12), as well as to patients at extremes of age, i.e., younger than 10 and older than 40 years (22).
we, however, were unable to find any relationship between surgical testicular salvage and age, in both bivariate and logistic regression analysis.
therefore, among the subjects of our study, age did not influence surgical outcome.
in contrast, testicular rotation appears to play an important role in surgical outcome.
the existence of some relationship between the amount of rotation, duration of ischemia and surgical outcome has been known for almost a century (2).
there is experimental evidence (24) that 3 or 4 complete turns produce irreversible ischemic changes as early as 2 hours, whereas one turn can be tolerated for 12 hours, even though infarction inevitably occurs after 24 hours.
williamson asserted that there is no absolute time beyond which one can assume that infarction is inevitable (6).
in his study, one organ was found necrotic after only 4 hours' ischemia, and 2 testicles were viable after 25 days of symptoms.
in an analysis of 186 testicular torsion cases, sessions (25) observed that salvaged testis twisted less than lost organs (360° vs. 540°).
despite the impressive number of cases, the data was not submitted to multivariate analysis, so the relative prognostic significance of time and magnitude of torsion was not investigated.
a similar relationship was found by cummings, that observed that mean rotation in salvaged cases was 412°, contrasting with 630° in non-viable testicles (11).
from kuwait, al-hunayan (26) was able to salvage 2 organs after 48 hours of ischemia, and noted that both had less one turn.
tryfonas (27), following 25 of his 75 treated cases, noticed that if rotation was greater than 360°, atrophy ensued after only 4 hours, in a manner similar to what occurred in all cases with ischemia lasting for more than 24 hours.
he also noticed no later atrophy between 12 and 24 hours with rotations between 180° and 360°.
in a study from china (4), median rotation in salvaged organs was significantly less than in lost organs: 360° (90°–540°) vs. 540° (90° – 960°) (r = −0.953, p = 0.011).
these investigators called attention to 4 orchidectomy cases with less than 6 hours of symptoms, all of which had greater then 720° rotation.
in our analysis, both presentation delay and rotation were significantly and independently associated with greater orchidectomy rates in itt.
rotation had a crucial influence in surgical outcome, lowering the probability of orchidopexy even with very short treatment delays, in a dose–dependent manner.
the first consequence of our findings is that one has to deal with greater uncertainty in forecasting surgical testicular salvage in itt, even with short treatment delays, since it is impossible to know the cord's rotation beforehand.
therefore, diagnostic imaging may not be affordable, for even minimal increases in treatment delay can cost dearly.
one might, nevertheless, institute measures to reduce testicular ischemia, such as manual detorsion: manual detorsion can be successful even when converting a 4.0π radian to a 2.0π radian torsion, which could allow some testicular perfusion.
furthermore, there is some experimental evidence that ischemic injury can be reduced with local hypothermia (28, 29), a very simple measure.
there is ongoing research on pharmacological therapy to reduce ischemic injury (30), but the possibility of serious adverse effects requires careful clinical consideration.
the second consequence is that surgical treatment should not be withheld with the argument that the testicle is all but lost, even in patients with long delays in presentation (>24 hours).
ten of our patients (7%) in such situation had their testicles surgically salvaged, including one with 100 hours of symptoms.
one should keep in mind that patients with a single twist of the spermatic cord might preserve some testicular irrigation, and have a viable testis at surgical exploration.
moreover, the patient might be suffering from intermittent torsion, which explains finding a non-rotated testicle, even if typical symptoms are present.
this study has several drawbacks worth mentioning.
the response variable of our analysis was surgical outcome, which is not the same as treatment outcome.
treatment outcomes will be most likely worse than surgical outcomes, since some surgically salvaged organs will eventually atrophy.
thus, even with our low surgical salvage rates, our results might have represented an optimistic scenario.
regarding our logistic model, we included rotation as a continuous variable, even though it was recorded at discrete intervals.
on the other hand, the rotation of the cord must occur continuously: a 4.0π radian rotation has necessarily gone through lesser degrees, and, indeed, can be medically or spontaneously converted to a lesser degree.
furthermore, we also acknowledge the possibility of a non-linear effect of rotation on testicular perfusion, and recommend additional caution in the interpretation of the regression results.
lastly, we also did not have access to data on patient referrals and prior treatments, e.g., manual detorsion, so the use of treatment delay and its components as a surrogate for the duration of ischemia might be negatively biased.
conclusions we have demonstrated, with non-parametric and multivariate logistic regression analysis, that both presentation delay, the dominant component of treatment delay for testicular torsion in our population, and testicular rotation were independently and inversely associated with surgical salvage in intravaginal testicular torsion.
most importantly, that testicular rotation exerts a multiplicative effect on ischemia time.
the exclusion of other causes of acute scrotum by imaging studies is currently accepted practice, provided surgery is not postponed.
however, our results demonstrate that this might be a dangerous path, for there seems to be no safe period in intravaginal testicular torsion.
@highlight
abstract purpose to investigate the roles of age, testicular rotation and time in the surgical outcome of intravaginal testicular torsion (itt).
patients and methods we retrieved the records of all itt patients treated in our unit from january 2012 to january 2014. explanatory variables were: age (years); presentation delay (prd, time between symptoms and hospitalization); surgical delay (surgd, time between hospitalization and surgery) and testicular rotation (rotation), with surgical outcome (orchidopexy, orchidectomy) as response variable.
differences in prd, surgd, age and rotation by surgical outcome were evaluated non-parametrically.
step-down logistic regression included age, prd, surgd and rotation as predictors.
statistical significance and confidence intervals (ci) were set at p<0.05 and 0.95. odds ratios (or) were computed from the model's coefficients.
results complete variable information was available for 117 patients, and most (61, 52.1%) underwent orchidectomy.
ages were similar between orchidectomy and orchidopexy patients (median 15.8 vs. 16.0 years, p=0.78).
in contrast, prd (85.0 vs. 8.4 hours, p<0.001), surgd (3.0 vs. 16.0 hours, p<0.001) were different between orchidectomy and orchidopexy patients.
surgd was similar with prd<24 hours (4.0 vs. 2.8, p=0.1).
orchidectomy patients had greater rotation (3.0π vs. 2.0π radians, p<0.001).
logistic regression revealed that prd (or 0.94; 0.92–0.97; p<0.001) and rotation (or 0.43; 0.27–0.70; p<0.001) were inversely associated with orchidopexy.
conclusion testicular rotation exerts a multiplicative effect on prd, so time should not be regarded as the sole predictor of surgical outcome in itt.
