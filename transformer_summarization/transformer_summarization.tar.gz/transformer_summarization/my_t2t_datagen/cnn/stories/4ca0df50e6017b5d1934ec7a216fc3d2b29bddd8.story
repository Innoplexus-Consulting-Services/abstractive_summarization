introduction the main goal of root canal treatment is to achieve optimal cleaning and shaping conditions prior to the filling process [1].
in this scenario, biomechanical preparation is paramount when endodontic instruments are used in association with auxiliary chemical substances [2, 3].
regardless of the instrument and technique employed, the action of endodontic instruments against dentinal walls inevitably promotes the formation of a smear layer of granular appearance, containing both inorganic and organic materials [2, 4, 5].
smear layer removal is strictly related to treatment success, and has been shown to be directly correlated with the irrigation process, and consequently with neutralization of the root canal microbiota [4, 6-8].
sodium hypochlorite (naocl) is a widely used endodontic irrigant, especially due to its antimicrobial properties and the ability to dissolve organic materials [7].
however, it does not act on the inorganic contents of the smear layer, and therefore requires the associated use of a chelating agent [7, 8].
some chelating agents have the ability to bind to metallic ions of a particular molecular complex, among those agents, the use of ethylenediaminetetraacetic acid (edta) is a consensus [2, 9, 10].
the reaction with calcium ions in dentin results in calcium chelation, with decalcification of the dentin structure [10].
however, the combined use of irrigating and chelating solutions promotes smear layer removal and microhardness reduction and can enhance dentin erosion [11].
biocompatible solutions can minimize the aggression to dental structures.
in this scenario, options such as citric acid, lactic acid, and apple vinegar have emerged as potential substitutes for traditional chelators/edta [9, 12, 13].
chitosan, for instance, is a natural polysaccharide that has been tested as an alternative material in dentistry, due to its biocompatibility, biodegradability and bioadhesion in the human body [14].
this substance is produced through deacetylation of chitin, obtained from shrimp and crab shells [14,15].
in endodontics, it has been used as an intracanal medication in association with calcium hydroxide paste and as a chelating agent to help reduce root dentin microhardness [3, 4, 16].
dentin permeability affects the action of intracanal medications and especially the filling of the root canal system [10].
there is controversy in the literature regarding the application time of irrigating and chelating substances [17].
it is known that these agents are used in root canals in different ways, with or without agitation (hand files, motor-driven systems, lentullo files, sonic and ultrasonic systems), as supplementary agents to improve results [18, 19].
thus, the aim of this study was to assess, using atomic absorption spectrometry, the amount of calcium ions released after the use of 0.2% chitosan and 17% edta associated with different protocols of agitation.
materials and methodology the study protocol was approved by the research ethics committee of university of cuiabá, cuiabá, brazil (caae 44419815000005165).
ninety extracted human maxillary canines, single-rooted, with fully formed apices and straight root canals (r<5) [20], were used.
the teeth exhibited no defects, no calcifications, no internal or external root resorption, no prosthetic crowns or dental posts, no previous root canal treatment and no aberrant canal morphology.
all teeth had a single canal and a single apical foramen as evidenced by buccal and proximal radiographic examinations.
root apices were inspected under a stereoscopic microscope (expert dn; müller optronic, erfurt, germany), and root canals were explored with a #.08 k-file (dentsply maillefer, ballaigues, switzerland).
to improve standardization, only teeth measuring between 20 and 22 mm confirmed using a millimeter ruler (dentsply maillefer, ballaigues, switzerland) were included in the study.
the diameter of the foramina of all teeth was standardized using a #.15 k-file (dentsply maillefer, ballaigues, switzerland).
specimens were disinfected using 2.5% naocl and stored in 0.1% thymol solution at 4°c until use.
standard access cavities were made using round diamond burs (#.1011 and #.1012; kg sorensen, barueri, sp, brazil) coupled to a high speed handpiece with air/water spray cooling.
the apical patency of all root canals was confirmed using a #.10 k-file (dentsply maillefer, ballaigues, switzerland), and canals with a patency greater than iso 15 were discarded.
working length was determined using a #.15 k-file (dentsply maillefer, ballaigues, switzerland), which was introduced into the root canal until its tip became visible at the apical foramen using an operating microscope (opmi pico; carl zeiss, oberkochen, germany).
working length was set to 1 mm short of that length.
specimens were randomly assigned to two broad experimental groups according to the chelating solution employed (0.2% chitosan or 17% edta); there was also a control group in which distilled water was used.
then, the groups were randomly assigned to three subgroups, according to the protocol of agitation (manual, sonic, and ultrasonic agitation).
the final groups were as follows: 1) 0.2% chitosan and manual agitation; 2) 0.2% chitosan and sonic agitation; 3) 0.2% chitosan and ultrasonic agitation; 4) 17% edta and manual agitation; 5) 17% edta and sonic agitation; 6) 17% edta and ultrasonic agitation; 7) distilled water and manual agitation; 8) distilled water and sonic agitation; and 9) distilled water and ultrasonic agitation.
specimens were instrumented using a #.40.08 waveone large-file (dentsply-maillefer, ballaigues, switzerland) activated by an x-smart plus motor (dentsply-maillefer, ballaigues, switzerland) set according to manufacturer instructions.
for cervical enlargement, a #.02 la axxess bur (sybronendo, orange, ca, usa) was used, driven by intramatic 2068 (kavo, joinvile, santa catarina, brazil) and intramatic 181dbn micromotors (kavo, joinvile, santa catarina, brazil) operating at 5000 rpm.
the la axxess bur was used until the operator felt resistance to penetrate.
final preflaring depths ranged from 12 to 14 mm.
four milliliters of 2.5% naocl was used as irrigant after each instrument.
a navitip 31ga (ultradent, south jordan, ut, usa) irrigation needle was used which was 1 mm short of the working length.
final irrigation was performed with 3 ml of bi-distilled water.
patency was assessed using a #.10 k-file.
each instrument was used to prepare one root canal and then discarded.
all root canals were prepared by a single experienced endodontist.
subsequently, canals were irrigated and filled with 5 ml of one of the solutions investigated: 17% edta (biodinâmica, ibiporã, pr, brazil), 0.2% chitosan (naturallis, várzea grande, mt, brazil), or distilled water, as a final irrigant.
then, the solutions were agitated for 3 min according to the protocol of agitation assigned (manual, sonic, or ultrasonic).
in the groups subjected to sonic agitation, the endoactivatortm device (dentsply, tulsa dental specialities, usa) with a #.35/04 tip was used.
the device was introduced up to 2 mm short of the working length.
in the ultrasonic groups, the chelating solution was activated using a #.15 file (satelec, acteon, france) driven by an ultrasonic device (piezo-electric mts; multi task cart, obtura spartan, usa) at 4/10-scale power in accordance with manufacturer instructions.
finally, in the manual groups, the chelating solutions were agitated manually using a #.40 k-file (dentsply-maillefer, ballaigues, switzerland).
in all groups, following activation, root canals were washed with saline solution and dried with paper points.
extruded debris and irrigant solutions were collected in a container fitted with a rubber stopper and individually prepared to support each tooth with its apex suspended within the container, according to the method described by myers and montgomery [21].
each specimen was attached to the rubber stopper using cyanoacrylate-based adhesive (super bonder; loctite of brazil, henkel ltda., são paulo, sp, brazil), and 1/2 q1 sealing tape (tigre as, joinville, sc, brazil), which was used to protect the specimen rubber stopper interface.
the container was vented with a 25-g needle (injex indústria cirúrgica ltda., ourinhos, sp, brazil) inserted through the rubber stopper to equalize pressures.
once instrumentation was completed, teeth were separated from the container.
debris adhered to the surface of the root were collected by rinsing the specimens with 1 ml of bi-distilled water.
containers were then placed in an incubator at 70°c for 5 days for moisture evaporation before weighing the debris.
concentration of calcium ions (atomic absorption spectrometry) the contents extruded from the instrumented tooth were transferred to a 100-ml teflon tube.
a mixture of 7 ml of nitric acid (65% by volume) and 21 ml of hydrochloric acid (37% by volume) was added to the teflon tube and kept aside for 2 hours.
after that, the tube was loosely capped and transferred to a hood provided with exhaust ventilation.
the tube was placed on a heating block, heated to 80°c and kept heated for 150 min to allow the temperature to stabilize.
after the reaction, the tube was cooled to room temperature, and the mixture was filtered using grade 40 paper filter (whatman, ge, healthcare life sciences, pittsburgh, pa, usa); distilled water was added to the resulting filtrate until a volume of 50 ml was reached.
a blank test was performed in parallel, using the same procedure and the same amounts of all reagents, but omitting the test specimen.
for the analysis of calcium ion concentration, a specific pattern was determined from universal standards (merck, darmstadt, germany).
micropipettes (boeco, germany) with adjustable volumes of 5-50 µl, 50-200 µl, and 100-1000 µl were used for the preparation of standard solutions and specimens.
the standard was prepared by adding appropriate amounts of aqueous analyte stock solutions plus 1 g of material to 10-ml volumetric flasks, which were then completed with bi-distilled water.
bi-distilled water was used for adjustment, and the washing procedure was performed in a 250-ml separatory funnel to which 50 ml of bi-distilled water and 100 ml of a solution of 1.0% (v/v) nitric acid were added; the resulting mixture was heated to 70°c.
then the separatory funnel was shaken vigorously for 5 min, and the extraction procedure was repeated until no analytes were detected in the specimen using the flame atomic absorption spectrometer (varian ind.
com.
ltda., são paulo, sp, brazil).
analytical curves were prepared in the concentration range of 0.0-0.8 mg l−1, using bi-distilled water as medium.
the reading parameter for calcium was determined considering the electric current, wavelength, and slit aperture of the device.
the amounts of calcium ions released in the different groups were compared using analysis of variance (anova) and the kolmogorov-smirnov and levene tests followed by tukey’s post-hoc test.
significance was set at p<0.05.
statistical analyses were performed using the statistical package for the social sciences (spss) version 18.0 for windows (spss inc., chicago, il, usa).
results considering the chelating agents tested, 0.2% chitosan showed the highest amount of calcium ions released (168.38 ± 6.52), 17% edta showed intermediate results (58.59 ± 26.20), and distilled water showed the lowest values (2.52 ± 0.86).
differences were significant across all three groups (p<0.05).
table 1 shows the results obtained with the different protocols of agitation combined with different chelating agents.
considering the different protocols of agitation tested, ultrasonic agitation yielded the highest results, followed by sonic agitation and manual agitation, respectively (all comparisons, p<0.05).
within each agitation group, association with 0.2% chitosan always showed significantly higher values (p<0.05).
discussion several advances in dentistry originate from scientific developments in the biomaterials sector, particularly with the release of materials for use in dental practice [22].
in the present study, the decalcification properties of two chelators were evaluated when associated with different protocols of agitation.
chelating agents play an important role in the process of removing smear layer, as they increase dentin permeability [23, 24].
we assessed the effectiveness of two chelating substances (0.2% chitosan and 17% edta) based on the amount of calcium ions released, using atomic absorption spectrometry.
this tool allowed to quantify the concentration of calcium ions present in the substance after irrigation, as previously used by other authors [12].
the calcium ions present in the dentin are released when in contact with chelating agents [2, 23].
smear layer removal by 17% edta combined with 5% naocl [2] is known to reduce root dentin microhardness, thus facilitating instrumentation [3].
however, edta has an erosive effect on dentin and attacks periapical tissues; in addition, it is considered a pollutant [24].
in the present study, 0.2% chitosan was associated with the highest amounts of calcium ions released, followed by 17% edta and distilled water, respectively (all p<0.05).
edta and chitosan are known to act on root dentin demineralization, which is in line with the results of the present study [25].
concerning the application time of chelating agents, the use of solutions for more than 5 min has been shown not to have an effect on their ability to remove calcium [26].
solutions applied for 3 min, in turn, have proved effective in removing smear layer and smear plug, with minimal erosive effect [24].
chitosan presents some other advantages over edta: it is biocompatible, biodegradable, bioadhesive, and atoxic [27].
it could be used as a final irrigant, as it may act as both a chelating agent and an antibiofilm agent [28].
in addition, 0.2% chitosan is efficient in removing smear layer from the middle and apical thirds of root canals (demineralization capacity) [25].
another major advantage of chitosan is its ability to control the release of calcium ions from calcium hydroxide when used as a vehicle, for up to 30 days [16].
finally, it has the capacity to remineralize the dentin, allowing for the investigation of new types of therapies [29].
regarding the other variable analyzed in this study, namely, mechanical agitation of chelating substances, ultrasonic agitation showed the highest amount of calcium ions released in the spectrometric analysis.
this result is closely related to the intensity of the movement produced inside the root canal, as suggested by some previous studies [3, 30, 31].
the mechanisms of ultrasonic agitation are related to acoustic microstreaming and hydrodynamic cavitation, which result in formation and implosion of vapor bubbles; sonic activation, in turn, cannot promote cavitation as a result of the low oscillation speed [32, 33].
lui, et al.
[34] described the use of ultrasonic irrigation following instrumentation/during the final irrigation and found that ultrasonics improved smear layer removal, which corroborates the findings of this study.
the protocols employed by the two studies are different, especially with regard to application time: whereas lui et al.
used 1 min of ultrasonic irrigation with 17% edta and obtained clean, smear-free dentinal walls [34], in this study we used 0.2% chitosan and 17% edta for 3 min.
nevertheless, the results obtained were similar.
it seems that the ultrasonic technique alone or combined with naocl is unable to obtain good results [35].
conversely, some chelators can have their ability to remove smear layer enhanced by ultrasonic devices [34].
considering the satisfactory results obtained in this study with 0.2% chitosan combined with ultrasonic agitation, and the superior characteristics of this biopolymer [2, 3, 12, 24], further studies (especially with a focus on cytotoxicity and genotoxicity) are important to investigate the use of this substance as an irrigating agent.
conclusion considering the experimental conditions of this study, 0.2% chitosan combined with ultrasonic agitation yielded the highest amounts of calcium ions released.
@highlight
background: the main goal of endodontic treatment is to achieve cleaning and shaping prior to the filling process.
objective: this study aimed to evaluate, using atomic absorption spectrometry, the release of calcium ions after the use of different chelating agents and protocols of agitation.
method: ninety human canine teeth were randomly assigned to one of nine groups (n=10), as follows: 1) 0.2% chitosan and manual agitation; 2) 0.2% chitosan and sonic agitation; 3) 0.2% chitosan and ultrasonic agitation; 4) 17% edta and manual agitation; 5) 17% edta and sonic agitation; 6) 17% edta and ultrasonic agitation; 7) distilled water and manual agitation; 8) distilled water and sonic agitation; 9) distilled water and ultrasonic agitation.
following instrumentation, all chelating substances remained inside the root canal for 3 min.
then the fluid was collected for the identification and quantification of calcium ions.
the amount of calcium ions released in each group was compared using analysis of variance (anova) and the kolmogorov-smirnov and levene tests followed by tukey’s post-hoc test.
significance was set at 5%.
results: the groups in which 0.2% chitosan was used showed the highest concentration of calcium ions (p<0.05).
concerning the agitation method, ultrasonic agitation showed the greatest values, followed by sonic and manual agitation (all comparisons, p<0.05).
conclusion: the present findings suggest that, among the combinations here tested, chitosan associated with ultrasonic agitation yielded the greatest release of calcium ions.
