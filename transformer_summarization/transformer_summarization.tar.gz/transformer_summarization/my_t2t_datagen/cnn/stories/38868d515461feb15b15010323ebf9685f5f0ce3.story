background the drug adrenaline has been an integral component of advanced life support from the birth of modern cardiopulmonary resuscitation in the early 1960s.
in guidelines written originally in 1961, peter safar recommended the use of very large doses of adrenaline: 10 mg intravenously or 0.5 mg intra-cardiac1 and adrenaline has continued to be recommended ever since.
the international liaison committee on resuscitation (ilcor) synthesised the available evidence for adrenaline in 20102 and re-assessed the evidence in october 20153 noting that whilst it may improve the return of spontaneous circulation (rosc) and short-term survival, there is insufficient evidence to know if adrenaline had beneficial or harmful effects on survival to discharge from hospital and on neurological outcomes.
ilcor has called for placebo-controlled trials to evaluate the use of any vasopressor in adult and paediatric cardiac arrest.
summary of clinical evidence at the time of initiating the study, a systematic review of the literature identified two relevant randomised, placebo controlled trials and 16 observational studies.4 the paca trial,5 aimed to enrol 5000 patients but at the time the study closed, only 601 patients had been randomised.
the relatively small numbers led to the results having large uncertainty.
rosc [short term survival] was higher in those receiving adrenaline (64/272 (23.5%) vs. 22/262 (8.4%); or 3.4, 95% ci 2.0–5.6), but there was not clear evidence of a benefit in survival to hospital discharge [long term survival]: adrenaline 11 (4.0%) vs. placebo 5 (1.9%) (or 2.2, 95% ci 0.7–6.3).
in addition to the study's imprecision, interpretation of the findings is limited by a large number of post randomisation exclusions (n = 67, 11%).
a second randomised study compared intravenous (iv) cannulation and injection of drugs (including adrenaline) versus no iv cannula or drugs amongst 851 patients with ohca.6 the patients in the iv group had better short-term survival (rosc 165/418 (40%) vs. 107/433 (25%), or 1.99, 95% ci 1.48–2.67)); however, there was no clear difference in long term survival outcomes (survival to hospital discharge (iv arm 44/418 (10.5%) vs. no iv arm 40/433 (9.2%) or 1.16 (95%ci 0.74–1.82), or favourable neurological outcome (cerebral performance category [cpc] 1–2: iv 9.8% vs. no iv 8.1% or 1.24 (0.77–1.98).
the higher rate of rosc was seen mainly in the patients with initial non-shockable rhythms (asystole and pea): 29% (iv) vs. 11% (no iv).
the rate of rosc was 59% (iv) vs. 53% (no iv) in those patients with an initial rhythm of vf/vt.
observational studies allow large amounts of data to be collected but are often limited by bias, and confounding.
statistical techniques can be used to adjust for differences in measured confounding variables, however unknown confounders may still lead to biased results.
this is illustrated by two propensity score matched analyses from the same cohort of patients.
the studies used slightly different statistical models produced different results.
one showed worse long term neurologically outcomes (odds ratio 0.21, 95% confidence interval 0.1 to 0.44),7 whereas the other study showed marginal benefit (1.57, 1.04–2.37).8 meta-analyses of such studies should be interpreted with caution but show better short term outcomes (return of spontaneous circulation) and either no difference or worse long term survival and neurological outcomes.9, 10 (table 1) this creates the paradox of better short term survival at the cost of worse long term outcomes, in other words a ‘double-edged sword’.11 mechanisms of action a detailed review of the mechanism of action for adrenaline in cardiac arrest has been published previously.12 in brief, potentially beneficial effects are attributed to stimulation of α receptors in vascular smooth muscle, causing vasoconstriction.
this increases aortic diastolic pressure, which in turn leads to increased coronary perfusion pressures, which is associated with an increased chance of rosc.
potentially harmful effects are α and β receptor mediated and include reduced cerebral micro-vascular blood flow and exacerbation of cerebral injury,13, 14, 15 cardiovascular instability after rosc6, 16 and adverse immunomodulatory17, 18 and metabolic effects.19, 20, 21, 22 experimental studies have shown that β-blocker treatment may mitigate some of these harms.23 clinicians’ views on the safety and effectiveness of adrenaline to assess attitudes of the uk clinical community on the role of adrenaline for the treatment of cardiac arrest we conducted a written survey of 213 attendees (doctors, nurses, paramedics) at the resuscitation council (uk) annual scientific symposium in september 2012. respondents expressed their agreement to a series of statements on a 7 point likert scale (1 = strongly disagree, 7 strongly agree).
respondents reported that they believed that adrenaline increased short term survival (median score 6 (iqr 6–7), but disagreed that it improved long term outcomes (median score 2 (iqr 2–3)).
there was greatest uncertainty about the balance of risks and benefits of iv adrenaline (fig.
1a).
respondents felt the most pressing future research need for the nhs was a trial comparing adrenaline to placebo (fig.
1b).
summary the use of adrenaline in cardiac arrest increases the chances that the heart is restarted [rosc] but there remains doubt as to whether this is translated into improved or worse long term survival and neurological outcomes.
the pre-hospital assessment of the role of adrenaline: measuring the effectiveness of drug administration in cardiac arrest (paramedic-2) trial seeks to establish whether the use of intravenous adrenaline, administered in accordance with current cardiac arrest guidelines is helpful or harmful.
trial design trial summary this is a pragmatic, individually randomised, double blind, controlled trial and parallel economic evaluation.
the primary objective of this trial is to determine the clinical effectiveness of adrenaline in the treatment of ohca.
the primary outcome will be 30-day survival.
secondary objectives of the trial are to evaluate the effects of adrenaline on short and long term survival, cognitive and neurological outcomes and to establish the cost-effectiveness of using adrenaline.
the study outcomes are summarised in table 2. further information on the selection and measurement of outcome measures is available in the on-line supplement.
the study seeks to enrol 8000 participants in 3 years which includes a 6-month internal pilot to evaluate whether recruitment rate, compliance with allocated intervention and that the approach to data collection and follow-up works effectively.
the pilot phase started in december 2014 and the main trial started in july 2015. the pilot ran seamlessly into the main trial and the data from the pilot will be included in the main study results.
the study findings should be available for presentation in 2018. the trial flow diagram is presented in fig.
2. the study is being co-ordinated by warwick clinical trials unit in partnership with five research sites: london ambulance service nhs trust, north east ambulance service nhs foundation trust, south central ambulance service nhs foundation trust, welsh ambulance service nhs trust, west midlands ambulance service nhs foundation trust.
eligibility criteria patients will be eligible if they are in cardiac arrest in an out of hospital environment and advanced life support is initiated by an ambulance service clinician.
exclusion criteria at the time of arrest will be: known or apparent pregnancy; known or apparently aged under 16 years; cardiac arrest thought to be caused by anaphylaxis or life-threatening asthma; adrenaline given prior to arrival of the enrolling ambulance service clinician.
randomisation and blinding randomisation will use a system of pre-randomised, numbered treatment packs containing 10 pre-filled syringes of adrenaline (1 mg) or placebo.
the randomisation allocation will be 1:1 (active: control).
the packs for either intervention will be identical in appearance thus ensuring allocation concealment for the attending clinicians, research paramedics and trial administration team.
the pre-randomised sequence will be prepared by the trial statistician and only he/she will be able to link the drug pack number to the allocation of adrenaline or placebo.
however, all statistical analyses will use masked allocation to avoid the revelation of the true allocation.
the sequence will be generated using simple randomisation to ensure approximate balance between numbers of patients receiving adrenaline and placebo within each ambulance service.
when ambulance service personnel identify an eligible patient, randomisation will be achieved by opening one of the packs carried by the vehicle attending the arrest.
trial intervention participants will receive resuscitation according to the resuscitation council (uk) advanced life support guidelines, except that standard adrenaline will be substituted with the trial drug drawn from a single trial treatment pack.
participants enrolled in the intervention arm will receive adrenaline 1 mg contained in 3 ml pre-filled syringes.
participants in the control arm will receive 0.9% saline formulated as identical 3 ml pre-filled syringes.
each treatment pack will contain 10 treatment doses.
after this clinicians will review the appropriateness of continued resuscitation and either transfer to hospital or terminate resuscitation efforts.
trial interventions will cease when the patient arrives in an emergency department or when resuscitation efforts are discontinued.
treatment after admission to hospital will be at the discretion of the attending clinician.
sample size the basis for our sample size estimate is summarised in the electronic supplement.
the target sample size will be 8000, which is expected to give a width of the 95% ci for the risk ratio of approximately 0.4 or slightly less; for a risk ratio of 1.25 the 95% ci is 1.07–1.46, and for risk ratio of 1.0 it is 0.84–1.19.
there is a trade-off between precision and practicality in setting a target sample size; above 8000, there is only a small improvement in precision, but the difficulty and time needed to recruit this number increase significantly.
using a conventional significance test based sample size calculation, this sample size would give 93% power to detect an increase in survival of 2% (from 6% to 8%), with (two-sided) type i error rate of 5%.
we expect very few missing data for survival outcomes; in a previous trial we ascertained survival status for over 99% of randomised patients, and we have therefore not adjusted the sample size estimates to account for missing data.24 ethical/legal considerations and trial registration we have previously reported our assessment of the ethical considerations for this trial.25 further details are contained in the on-line supplementary material.
the oxford research ethics committee c (rec: 14/sc/0157) and medical healthcare regulatory authority (mhra) (eudract:2014-000792-11) approved the study protocol.
the trial registration number is isrctn73485024.
provision of general information about the trial we issued a national press release in august 2014 which received substantial national and regional media coverage.
additional information has been distributed by ambulance services in each of the regions.
in addition study information leaflets (fig.
3) have been distributed via pharmacies, emergency departments, local councils, libraries, register of births and deaths offices, foundation trust members and general practitioner surgeries.
patient and public facing information was designed with extensive input from our lay advisory group.
full details about the trial are available on the study website: www.warwick.ac.uk/paramedic2.
for those that do not wish to participate we have developed a system to allow individuals to decline participation in the trial based on the approach used by the north american resuscitation outcome consortium.
an online form can be completed on the website or the team can be contacted by phone or email.
a stainless steel “no study” bracelet will be issued to the person's home address and with the person's permission, their home address will be passed to their local ambulance service to register their wishes.
they will also be asked to inform those close to them of their wishes and that those wishes will be respected by the treating paramedics.
paramedics are trained to look for the bracelet.
enrolment, consent and follow-up cardiac arrest outside a hospital is a sudden, unexpected event.
the victim becomes unconscious rapidly and thus loses mental capacity.
treatment must be initiated immediately making it impractical to obtain informed consent from the patient or legal representatives.
authorisation to enrol patients under waiver of consent regulations was granted by the research ethics committee.
once the initial emergency has passed, patients (or their legal representative (usually a relative) if the patient lacks capacity) will be provided with written information about the study and consent to continue in the follow-up elements of the study will be sought.
full information about our approach to informing patients and their relatives about the trial and their follow-up can be found in the on-line supplement.
statistical analysis the primary analysis will be by intention to treat, comparing the outcomes between all participants randomised to adrenaline and all those randomised to placebo.
results will be presented as estimates of the treatment effect with 95% confidence intervals.
dichotomous outcomes (survival to 30 days, survived event, and survival to hospital discharge, 3, 6 and 12 months) will be analysed using logistic regression models, both unadjusted and adjusted for appropriate covariates which are selected a priori in agreement with the data monitoring committee and trial steering committee.
survival and other time to event outcomes will be analysed using time to event techniques.
continuous outcomes will be analysed by regression methods and the results presented as the difference in means between the groups and 95% confidence intervals.
modified rankin scale (mrs) will be analysed by ordinal logistic regression and presented using odds ratios and 95% confidence intervals.
reporting of analyses will follow consort guidelines.
the following exploratory analyses will be used to investigate potential moderators of the treatment effect of adrenaline by fitting interaction terms in the logistic or linear regression models described above:•age•witnessed cardiac arrest versus not witnessed•bystander cpr versus no bystander cpr•type of initial rhythm (vf/vt, pea, asystole)•time of 999 call to administration of adrenaline•aetiology of cardiac arrest (presumed cardiac versus non-cardiac).
economic evaluation the economic evaluation will be conducted from the recommended nhs and personal social services (pss) perspective.26 sources for data collection are summarised in the on-line supplement.
the main results of the economic evaluation will be expressed in terms of incremental cost per quality-adjusted life year (qaly) gained.
this incremental cost-effectiveness analysis will be expressed as: (i) incremental cost per additional survivor to 30 days post-cardiac arrest; (ii) incremental cost per additional neurologically intact (modified rankin scale (mrs) 0–3) survivor; and (iii) incremental cost per quality-adjusted life year (qaly) gained.
results will be presented using incremental cost-effectiveness ratios (icers) and cost-effectiveness acceptability curves (ceacs) generated via non-parametric bootstrapping.
heterogeneity in the trial population will be explored by formulating a net-benefit value for each patient from the observed costs and effects, and then constructing a regression model with a treatment variable and covariates such as age, gender, duration of ohca and study site.
the magnitude and significance of the coefficients on the interaction between the covariates and the treatment variable should provide an estimate of the cost-effectiveness of adrenaline by sub-group.
due to the known limitations of within-trial economic evaluations27 we will also construct a decision-analytical model to model beyond the parameters of the proposed trial the cost-effectiveness of adrenaline in this clinical population.
survival analysis models will be used to estimate life expectancy with and without adrenaline beyond the time horizon of the trial.
long term costs and health consequences will be discounted to present values using discount rates recommended for health technology appraisal in the united kingdom.
a series of probabilistic sensitivity analyses will be undertaken to explore the implications of parameter uncertainty on the incremental cost-effectiveness ratios.
oversight the study is sponsored by the university of warwick.
a trial steering committee (tsc) (with a majority of independent members, including patient/public representatives) will meet at least annually to maintain oversight of the trial.
a data monitoring committee (dmc) of independent experts with relevant clinical research, and statistical experience will monitor the accumulating interim data every 3 months or as they consider appropriate.
at each interim point, the monitoring of the study involves comparison of the primary outcome against statistical boundaries which have been constructed using the alpha spending approach.
in particular, the overall desired significance level has been maintained using the pocock and o’brien fleming type spending function.
the upper and lower boundaries have adopted asymmetric stopping rules, which has allowed us to be conservative for harm but less conservative for efficacy at early stages of trial.
the dmc will advise the chair of the tsc if, in their view, the randomised comparisons have provided both (i) ‘proof beyond reasonable doubt’ that for all, or some, the treatment is clearly indicated or clearly contra-indicated and (ii) evidence that might reasonably be expected to materially influence future patient management.
following a report from the dmc, the steering committee will decide what actions, if any, are required.
unless the dmc request cessation of the trial the steering committee and the collaborators will remain ignorant of the interim results.
patient and public involvement (ppi) we sought guidance from patients and the public during the conception, design and running of the trial.
we held a community engagement event (supported by west midlands south clrn) in late november 2012 where we presented the scientific rationale behind this trial to a group of 280 lay-people who were interested in first aid.
after preparing the talk in collaboration with one of our ppi representatives (john long) to ensure concepts were presented in plain, understandable english, we delivered the presentation and addressed questions/queries from the group.
we explained the concept of short term and longer-term outcomes and briefly sought community views about priorities for outcomes and their views on a trial of adrenaline for out of hospital cardiac arrest.
we received responses from 243 participants.
ninety-five percent of respondents prioritised long-term survival over short-term survival (hours to days).
participants broadly agreed there was a need for further research about adrenaline as a treatment for cardiac arrest (86% agreed, 8% neither agree nor disagreed, 6% disagreed).
patient and public representatives serve on our trial management group and study steering committee.
in addition we consulted user groups via the clinical research ambassador group and university/user teaching and research action partnership and resuscitation council (uk) and established a patient advisory group to assist with the design of supporting material and our approach to sharing information about the study.
conclusion the international liaison committee on resuscitation has highlighted uncertainty about the safety and effectiveness of adrenaline as a treatment for cardiac arrest.
the paramedic-2 trial is a pragmatic, individually randomised, double blind, controlled trial and economic evaluation designed to determine if adrenaline affects 30 day survival in victims of out-of-hospital cardiac arrest.
funding this project is funded by the national institute for health research hta programme (project number hta – 12/127/126) this paper presents independent research funded by the national institute for health research (nihr).
the views expressed are those of the author(s) and not necessarily those of the nhs, the nihr or the department of health.
gdp is supported as a director of research for the intensive care foundation and nihr senior investigator.
conflict of interest statement all applicants, or their employers, received funding from the national institute for health research to conduct this work.
@highlight
despite its use since the 1960s, the safety or effectiveness of adrenaline as a treatment for cardiac arrest has never been comprehensively evaluated in a clinical trial.
although most studies have found that adrenaline increases the chance of return of spontaneous circulation for short periods, many studies found harmful effects on the brain and raise concern that adrenaline may reduce overall survival and/or good neurological outcome.
the paramedic-2 trial seeks to determine if adrenaline is safe and effective in out-of-hospital cardiac arrest.
this is a pragmatic, individually randomised, double blind, controlled trial with a parallel economic evaluation.
participants will be eligible if they are in cardiac arrest in the out-of-hospital environment and advanced life support is initiated.
exclusions are cardiac arrest as a result of anaphylaxis or life threatening asthma, and patient known or appearing to be under 16 or pregnant.
8000 participants treated by 5 uk ambulance services will be randomised between december 2014 and august 2017 to adrenaline (intervention) or placebo (control) through opening pre-randomised drug packs.
clinical outcomes are survival to 30 days (primary outcome), hospital discharge, 3, 6 and 12 months, health related quality of life, and neurological and cognitive outcomes (secondary outcomes).
trial registration (isrctn73485024).
