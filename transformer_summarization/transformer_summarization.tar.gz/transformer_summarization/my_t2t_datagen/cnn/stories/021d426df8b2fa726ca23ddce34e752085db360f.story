introduction cryopreservation of embryo and oocyte are two valuable methods, used to increase the success of infertility treatment.
there are two common methods, used for the cryopreservation of embryos: slow freezing and vitrification (1).
in slow freezing, embryos are exposed to a gradual decrease in temperature, and are then transferred to liquid nitrogen for storage.
vitrification was initially reported in 1985 (2).
in this method, the concentration of cryoprotectants is increased and embryos are directly plunged into liquid nitrogen so that they are cooled at a very high speed rate (over 20,000°c/ minute).
in this situation, intraand extra-cellular liquids become solid without ice crystal formation.
this kind of freezing, as a result, is called vitrification.
high speed cooling and warming rates are the most critical factors to preserve embryos during the process, which can prevent the formation of ice crystals in the intraand extra-cellular space (3).
this method has gained growing worldwide recognition among experts in assisted reproductive technology (art) laboratories since it was initially used by researchers in an attempt to demonstrate the practicality of vitrification technique, which is commonly used for the cryopreservation of mammalian embryos.
this can be attributed to the fact that vitrification has several noticeable merits, which can make it distinct from the conventional slow-freezing method (4).
notable advantages of vitrification over the conventional slow-freezing method are that is simpler, less expensive, more efficient and rapid.
this can lead to higher survival and developmental rates when compared to the results of slow-freezing method (5,6).
in one study has demonstrated that the efficiency of embryo cryopreservation depended not only on the cryopreservation method, but also on the developmental stage of the embryos (7).
although several previous studies have already attempted to systematically evaluate the most suitable developmental stage for mouse embryo cryopreservation, there are conflicting results in the literature.
some studies have concluded 2-cell stage (8) is the best for vitrification while the others have noted 8-cell (4), morula (9) or blastocyst (1) as the most optimal stage for embryo cryopreservation and cryotolerance.
moreover, there have been a limited number of published studies investigating the reaction of different stages of mammalian embryo to the stress of cryopreservation and thawing (1,4,8,16).
with the limited number of published studies and the conflicting reports in mind, we decided to carry out our investigation.
in this study, we vitrified mouse embryos at various developmental stages (2-cell, 4-cell, 8-cell, morula and blastocyst) through the cryotop method; so that we could determine the optimal embryonic developmental stage for cryopreservation.
it is recognized that the results obtained through mouse embryos could not be extrapolated to human embryos.
however, it is hoped that the findings of the current study could provide some empirical insights for prospective researchers with regard to the choice of an optimal developmental stage for the vitrification of human embryos.
materials and methods experimental design in this experimental study, 2-cell stage mouse embryos were obtained from 6 to 8 weeks-old nmri female mice superovulated with 7/5 iu of pregnant mare serum gonadotropin (pmsg, hipra, spain) given intraperitoneally.
the process was followed by intraperitoneal injection of 7/5 iu of human chorionic gonadotropin (hcg, lg life sciences, korea) after 48 hours.
these mice were then mated with adult male mice of the same strain immediately after the injection of hcg, and were checked for mating the following day morning.
the mated female mice were sacrificed by cervical dislocation 44-48 hours after the hcg injection, their oviducts were removed, and the 2-cell embryos were flushed from oviducts.
this procedure was performed at room temperature (25°c) and the flushing medium was comprised of a ham’s f10 with hepes (ham’s f10-hepes, sigma, germany) and 20% human serum albumin (hsa, bio test, germany).
it is worth mentioning that only morphologically normal embryos were used for the sake of this study.
after the initial wash in flushing medium, 2-cell embryos were randomly divided into two groups.
the embryos in the first group were vitrified, and those of the second group were transferred to t6 medium containing 10% hsa for continuous culture at 37°c, in the air with 6% co2humidified incubator.
the embryo culture process lasted for four days, following 52-54, 66-68, 72, 96 hours after hcg injection, embryos at 4-cell, 8-cell, morula, blastocyst stage, respectively, were isolated from culture medium, and they were subsequently vitrified.
vitrification mouse embryos at 2-cell, 4-cell, 8-cell, morula and blastocyst stages were vitrified by a twosteps procedure through the cryotop as a carrier, as described by kuwayama et al.
(5).
embryos were initially equilibrated in vitrification solution 1 (vs1) comprising 7.5% (v/v) ethylene glycol (eg, sigma, germany) and 7.5% (v/v) dimethyl sulfoxide (dmso, sigma, germany) at room temperature for 8 to 10 minutes.
they were subsequently placed in vitrification solution 2 (vs2) consisting of 15% (v/v) eg, 15% (v/v) dmso and 0.5 mol/l sucrose (sigma, germany).
in less than 2 minutes, 4-5 embryos in minimal vitrification solution were placed on the inner surface of the cryotop carrier (kitazato, japan).
after that, the cryotop was vertically dipped into liquid nitrogen.
then it was inserted into a protective straw-cap before it was cryostored in liquid nitrogen.
thawing after cryo-storage for 10-14 days, the embryos were thawed.
briefly, the cryotop containing the embryos were removed from the protective straw-cap and dipped into thawing solution 1 (ts1), containing 1.0 mol/l sucrose, at 37°c.
after 1 minute equilibration in ts1, the embryos were moved into thawing solution 2 (ts2), containing 0.5 m sucrose, for 3 minutes.
subsequently, embryos were washed for 5 minutes in three drops of ham’s f10-hepes medium with 20% hsa at 37°c (4).
after that, embryos were cultured in t6 medium with 10% hsa under mineral oil at 37°c, in air with 6% co2humidified incubator.
the survival rate of embryos was assessed by observing the lightness and intactness of blastomers and zona pellucida.
development of the embryos were maintained and monitored until they reached the blastocyst and hatching stages.
the survival rate, blastocyst formation, and the hatching rate were all recorded and compared among the groups.
statistical analysis the data were statistically analyzed using the statistical package for social sciences (spss, version 15.0).
one-way anova and tukey’s post-hoc tests were used to compare and analyze the post-vitrification survival rates, blastocyst formation rates, and hatching rates among the experimental groups.
results have been reported as mean ± sd.
a p value<0.05 was considered significant.
ethical considerations this project has been approved by the ethic committee of mazandaran university of medical sciences (sari, iran) with code no.
91-108. results embryonic development, after vitrification and the subsequent thawing are summarized in table 1. no statistically difference was observed in the post-vitrification survival rates of vitrified mouse embryos at the 2-cell (82.1%), 4-cell (83.2%), 8-cell (85.8%), morula (77%) and blastocyst (60.5%) stages (p>0.05) (fig .1,2).
the blastocyst formation and hatching rate for the vitrified 2-cell embryos group were the lowest, 56.5% ± 23.4 and 21.2% ± 14.7 respectively (p<0.05).
on the other hand, hatching rate of blastocysts were highest (59.8% ± 25.7, p<0.05).
hatching rate of vitrified 4-cell, 8-cell and blastocysts were significantly higher than that of 2-cell embryos (p<0.05).
table 1 mouse embryonic development after early cleavage-stage embryo vitrification-warming stage of vitrification embryos (n) survival rate (%) ± sd blastocysts formation (%) ± sd hatched(%) ± sd vitrified 2-cell 157 82.1%±16.8 56.5%±23.4 21.2%±14.7 vitrified 4-cell 145 83.2%±11 79.8%±13.6 49.1%±25.5* vitrified 8-cell 166 85.8%±22.4 84%±21.2* 50.6%±25.7* vitrified morula 180 77%±17.8 75.8%±21 30%±16.3 vitrified blastocyst 140 60.5%±22.3 - 59.8%±25.7* * ; significantly different from those of 2-cell embryos within the same column (p>0.05).
fig.1 different cleavage stages of fresh mouse embryos in the culture medium.
a.
2-cell embryos, b.
4-cell embryos, c. 8-cell embryos.
different cleavage stages of vitrified mouse embryo 2 hours after thawing in the culture medium.
a.
2-cell embryos, b.
4-cell embryos, and c. 8-cell embryos (magnification: ×200).
fig.2 different cleavage stages of fresh mouse embryos in the culture medium.
a. morula embryos, b. blastocyst embryos.
different cleavage stages of vitrified mouse embryos 2 hours after thawing in the culture medium.
a. morula embryos and b. blastocyst embryos (magnification: ×200).
discussion despite the fact that there are many advances in the field of cryopreservation of embryo, there is no agreement on the optimal developmental stage for cryopreservation of embryo.
in the current study, we vitrified different stages of mouse embryos through the cryotop method.
there was no significant difference in survival rate after thawing the vitrified embryos at 2-cell, 4-cell, 8-cell, morula and blastocyst stages.
this finding is consistent with the results of studies performed by zhou et al.
(1) and zhang et al.
(4), which showed that there was no difference in survival rates among preimplantation mouse embryos.
in contrast, yan et al.
(8) reported that mouse 2-cell embryos had the best tolerance for cryopreservation, but they used the open-pulled straw (ops) method for vitrification.
differences in the survival rate may be due to the different strains of mice used in various studies.
investigators have shown that genotype could significantly influence post-thaw viability of frozen mouse embryos.
in addition to genotype, such other factors as thawing temperature and the culture medium may also contribute to differences in the survival rates (17).
zhou et al.
(1) demonstrated that early blastocyst stage is the most feasible stage for mouse embryo cryopreservation.
blastocyst is more complex and different from the earlier stages of development, whereby it contains an inner cell mass, a trophoblastic layer and a blastocoelic cavity.
regarding to various cell types presented in blastocyst, there is a greater chance for different metabolic activities and permeability when compared to the earlier stages of development (18).
generally, developmental stage of blastocyst (19), types of the cryoprotectants (20), exposure time to equilibration with vitrification solutions (19) and type of the carriers (21) can all affect the survival rates of the blastocyst.
although the survival rates for various embryonic stages were similar, in our study blastocyst formation in 2-cell stage embryos were significantly lower than that of 8-cell stage embryos.
however, the rates of blastocyst formation for 4-cell, 8-cell and morula stages were similar.
zhang et al.
(4), reported similar results to the demonstrated findings by zhou et al.
(1), conducted by ops method, indicating that blastocyst rate of the vitrified 1-cell and 2-cell embryos were lower than those of the vitrified 4-cell, 8-cell and morula embryos.
graves-herring and boone (22) cryopreserved mouse 2-cell and 8-cell embryos in either an openor closed-stripper tip or an openor closed-cbs nozzle.
the 8-cell provided a higher blastocyst rate than the 2-cell stage embryos, vitrified using the same manner.
according to our research, hatching rate of 2-cell embryos was significantly lower than that of the 4-cell, 8-cell and blastocyst stages embryos.
this finding correlates with that of zhang et al.
(4), indicating that hatching rate of the vitrified 2-cell embryos were significantly lower than that of the vitrified 8-cell embryos.
in the vitrified 4-cell embryo group, hatching rate was significantly lower than that of the vitrified 8-cell embryo groups.
our study, however, showed a similar hatching rate for 4and 8-cell embryos.
on the other hand, in a study performed by păcală et al.
(18), hatching rates of the morula stage embryos were higher than that of the blastocyst stage embryos.
in this study, glycerol was used as a permeating cryoprotective agent.
there is experimental proof that permeability co-efficiency of glycerol is increased from the 1-cell to the blastocyst stage in mice.
after thawing, increase in glycerol absorption needs much time to efflux from the embryo (23).
it must be noted that is essential for 2-cell embryos to be kept in culture medium for several days until they reach their blastocyst and hatching stages.
2-cell embryos also need to withstand with any kind of stress, induced by cold, being out of the incubator for investigations and potential recordings, and above all, the harmful effects of culture medium during this period.
it is logic that some embryos sustained damage by various prevailing peripheral stresses, leading to lower overall blastocyst formation and decreased hatching rate.
a study by lane et al.
(24) demonstrated that vitrification of hamster 2-cell embryos inhibited the activity of two transport proteins (na+/h+ antiporter an hco-/clexchanger), which are responsible for the regulation of intracellular ph, playing a key regulatory role in metabolism, energy production, and cell division.
it is proposed that similar reactions may affect mouse 2-cell embryos.
conclusion from the obtained results, it appears that developmental potential of mouse 2-cell embryos is more impacted by vitrification compared to 4-cell or 8-cell stage.
the success of vitrification technique depends on the developmental stage of embryo and the utilized method.
cryotop method is suitable for vitrification of mouse cleavage-stage embryos from 2-cell stage to blastocyst, with the same effect on the survival rate.
embryos at 4-cell and 8-cell stages are at the most suitable options for vitrification, using cryotop method.
they can show highest tolerance to the stress of freezing as well as thawing.
they can also yield highest level of post-vitrification developmental competence among early cleavage stage embryos.
@highlight
background vitrification has been shown as one of the most effective methods of cryopreservation for mammalian embryos.
however, there is no consensus which stage of embryonic development is the most appropriate for vitrification with subsequent maximal development after thawing.
this study was carried out to explore and compare the effect(s) of vitrification on mouse 2-cell, 4-cell, 8-cell, morula and blastocyst stage embryos and subsequent blast formation and hatching after thawing.
materials and methods in this experimental study, 2-cell embryos were obtained from the oviducts of super ovulated female nmri mice.
some embryos were randomly selected and vitrified through a two-step media protocol and cryotop.
other embryos were cultured to assess their development.
during the ensuing days, some of these cultured embryos were vitrified at 4-cell, 8-cell, morula and blastocyst stages.
after 10 to 14 days, the embryos were thawed to assess their survival and also cultured to determine the rate of blastocyst formation and hatching.
the results were analyzed using one-way anova and tukey’s post-hoc tests.
results there was no significant difference in the survival rates of vitrified embryos at 2-cell, 4-cell, 8-cell, morula and blastocyst stages after thawing (p>0.05).
the blastocyst formation rate of vitrified 8-cell embryos was significantly higher than that of 2-cell embryos (p<0.05).
the hatching rate of vitrified 4-cell, 8-cell and blastocysts were significantly higher than that of 2-cell embryos (p<0.05).
conclusion vitrification is suitable for cryopreservation of all stages of mouse embryonic development.
however, the best tolerance for vitrification was observed at 4and 8-cell stages of development.
accordingly, the development of vitrified embryos to blastocysts, following thawing, was most efficacious for 4 and 8-cell embryos.
compared to mouse 2-cell embryos, embryos vitrified as blastocysts had the highest rate of hatching.
