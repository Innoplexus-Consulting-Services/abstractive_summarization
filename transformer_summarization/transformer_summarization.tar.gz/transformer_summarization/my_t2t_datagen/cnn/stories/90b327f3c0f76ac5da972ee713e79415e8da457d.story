introduction the word correlation is used in day-to-day life to denote some form of association.
in statistics, correlation analysis quantifies the strength of the association between two numerical variables.
if the association is “strong” then an attempt may be made mathematically to develop a predictive relationship between the two variables so that given the value of one, the value of the other may be predicted from it and vice versa.
defining this mathematical relationship as an equation is the essence of regression analysis.
correlation and regression analysis are therefore like two sides of the same coin.
the scatter plot when exploring the relationship between two numerical variables, the first and essential step is to graphically depict the relationship on a scatter plot or scatter diagram or scattergram.
this is simply a bivariate plot of one variable against the other.
before plotting, one or both variables may be logarithmically transformed to obtain a more normal distribution.
on a scatter diagram, it is customary to plot the independent variable on the x-axis and the dependent variable on the y-axis.
however, “independent” and “dependent” distinction can be puzzling at times.
for instance, if we are exploring the relationship between age and stature in children, it is reasonable to assume that age is the “independent” variable on which the height depends.
so customarily, we will plot age on the x-axis and height on the y-axis.
however, if we are exploring the relationship between serum potassium and venous plasma glucose levels, which variable do we treat as the “dependent” variable?
in such cases, it usually does not matter which variable is attributed to a particular axis of the scatter diagram.
if our intention is to draw inferences about one variable (the outcome or response variable) from the other (the predictor or explanatory variable), the observations from which the inferences are to be made are usually placed on the horizontal axis.
once plotted, the closer the points lie to a straight line; the stronger is the linear relationship between two variables.
examine the two scatter plots presented in figure 1. in figure 1a, the individual dots representing the paired xy values are obviously, closely approximating a straight line and the value of y increases as the value of x increases.
this type of relationship is referred to as direct linear relationship.
in figure 1b, the dots are also approximating a straight line, though not so closely, as in figure 1a.
moreover, the value of y is declining as that of x is increasing.
this type of relationship is an inverse or reciprocal linear relationship.
figure 1 scatter diagram depicting direct and inverse linear relationships now inspect the scatter plot shown in figure 2. in this instance, there also is a strong relation between the dose of the drug and the response – the response is low to begin with, rises steadily in the subsequent portion of the dose range, but then tends to decline with further increase in dose.
it is clear that although the relationship is strong it cannot be approximated by a single straight line but can be described by an appropriate curved line.
the association, in this case, is curvilinear rather than linear.
we are going to discuss correlation and regression assuming linear relationship between the variables in question.
although many biological phenomena will show nonlinear relationships, the mathematics of these are more complex and beyond the scope of this module.
figure 2 scatter diagram depicting a curvilinear relationship the correlation coefficient to quantify the strength of the relationship between two variables shown to have a linear relationship on the scatter plot, we calculate the correlation coefficient.
the coefficient takes values only between −1 and +1, with the numerical magnitude depicting the strength of the relationship, and the sign indicating its direction.
thus, the sign accompanying a correlation coefficient is not a +or −sign in the arithmetic sense.
rather the plus sign denotes a direct relationship, whereas minus denotes an inverse relationship.
if both variables x and y are normally distributed, we calculate pearson's product moment correlation coefficient r or pearson's correlation coefficient r, or simply r (after karl pearson).
it is calculated as the covariance of the two variables divided by the product of their standard deviations (sds), and the term “product moment” in the name derives from the mathematical nature of the relationship.
a value of r close to +1 indicates a strong direct linear relationship (i.e., one variable increases with the other; as in figure 3a).
a value close to −1 indicates a strong inverse linear relationship (i.e., one variable decreases as the other increases; figure 3b).
a value close to 0 indicates a random scatter of the values [figure 3c]; alternatively, there could be a nonlinear relationship between the variables [figure 3d].
the scatter plot is indispensable in checking the assumption of a linear relationship and it is meaningless to calculate a correlation coefficient without such a relation between the two variables.
in between the state of “no correlation at all” (r = 0) and “perfect correlation” (r = 1), interim values of the correlation coefficient are interpreted by convention.
thus, values >0.7 may be regarded as “strong” correlation, values between 0.50 and 0.70 may be interpreted as “good” correlation, between 0.3 and 0.5 may be treated as “fair” or “moderate” correlation, and any value <0.30 would be poor correlation.
however, we must remember that the interpretation of a correlation coefficient depends on the context and purposes.
a correlation of 0.85 may be very low if one is verifying a physical law using high-quality instruments or trying to derive the standard curve for a quantitative assay but may be regarded as very high in the clinical context.
figure 3 scatter diagram depicting relationship patterns between two variables note that the correlation coefficient has no units and is, therefore, a dimensionless statistic.
the position of x and y can be interchanged on a scatter plot without affecting the value of r. if one or both variables in a correlation analysis is/are not normally distributed a rank correlation coefficient that depends on the rank order of the values rather than the actual observed values can be calculated.
examples include spearman's rho (ρ) (after charles edward spearman) and kendall's tau (τ) (after maurice george kendall) statistics.
in essence spearman's rank correlation coefficient rho, which is the more frequently used nonparametric correlation, is simply pearson's product moment correlation coefficient calculated for the rank values of x and y rather than their actual values.
it is also appropriate to use ρ rather than r when at least one variable is measured on an ordinal scale or when the sample size is small (say n ≤10); ρ is also less sensitive to deviations from linear relation than r. although less often used, kendall's tau is another nonparametric correlation offered by many statistical packages.
some statisticians recommend that it should be used, rather than spearman's coefficient, when the data set is small with the possibility of a large number of tied ranks.
this means that if we rank all of the scores and many scores have the same rank, kendall's tau should be used.
it is also considered to be a more accurate gauge of the correlation in the underlying population.
hypothesis test of correlation and confidence interval for correlation coefficient when we calculate the correlation coefficient for sample data, we quantify the strength of the linear relationship between two variables measured in the sample.
a high correlation coefficient value indicates a strong correlation for the sample.
however, what about the relationship in the population as a whole from which the sample has been drawn?
a significance test, based on the t distribution, addresses this question.
it allows us to test whether the association might have occurred merely by chance or whether it is a true association.
this significance test is applied with the null hypothesis that the population correlation coefficient equals 0. for any given value of r and taking the sample size into consideration, p values can be obtained from most statistical packages.
as usual, p < 0.05 indicates that there is sufficient evidence to suggest that the true (population) correlation coefficient is not 0 and that the linear relationship between the two variables observed in the sample also holds for the underlying population.
however, although the hypothesis test indicates whether there is a linear relationship, it gives no indication of the strength of that association.
this additional information can be obtained from the 95% confidence interval (ci) for the population correlation coefficient.
calculation of this ci requires r to be transformed to give a normal distribution by making use of fisher's z transformation.
the width of the ci depends on the sample size, and it is possible to calculate the sample size required for a given level of accuracy.
coefficient of determination when exploring linear relationship between numerical variables, a part of the variation in one of the variables can be thought of as being due to its relationship with the other variable with the rest due to undetermined (often random) causes.
a coefficient of determination can be calculated to denote the proportion of the variability of y that can be attributed to its linear relation with x. this is taken simply as r multiplied by itself that is r2.
it is also denoted as r2.
for any given value of r, the r2 will denote a value that is closer to 0 and will be devoid of a sign.
thus, if r is +0.7 or −0.7, r2 will be 0.49. we can interpret this 0.49 figures as that 49% of the variability in y is due to variation of x. values of r2 close to 1 imply that most of the variability in y is explained by its linear relationship with x. the value (1 −r2) has sometimes been referred to as the coefficient of alienation.
in statistical modeling, the r2 statistics gives information about the goodness of fit of a model.
in regression, it denotes how well the regression line approximates the real data points.
an r2 of 1 indicates that the regression line perfectly fits the data.
note that values of r2 outside the range 0–1 can occur where it is used to measure the agreement between observed and modeled values, and the modeled values are not obtained by linear regression.
point biserial and biserial correlation the point biserial correlation is a special case of the product-moment correlation, in which one variable is continuous, and the other variable is binary.
the point biserial correlation coefficient measures the association between a binary variable x, taking values 0 or 1, and a continuous numerical variable y. it is assumed that for each value of x, the distribution of y is normal, with different means but same variance.
it is often abbreviated as rpb.
the binary variable frequently has categories such as yes or no, present or absent, success or failure, etc.
if the variable x is not naturally dichotomous but is artificially dichotomized, we calculate the biserial correlation coefficient rb instead of the point-biserial correlation coefficient.
although not often used, an example where we may apply the point biserial correlation coefficient would be in cancer studies.
how strong is the association between administering the anticancer drug (active drug vs. placebo) and the length of survival after treatment?
the value would be interpreted in the same way as pearson's r. thus, the value would range from −1 to +1, where −1 indicates a perfect inverse association, +1 indicates a perfect direct association, and 0 indicates no association at all.
take another example.
suppose we want to calculate the correlation between intelligence quotient and the score on a certain test, but all the test scores are not available with us although we know whether each subject passed or failed.
we could then use the biserial correlation.
the phi coefficient the phi coefficient (also called the mean square contingency coefficient) is a measure of association for two binary variables.
it is denoted as φ or rφ.
also introduced by karl pearson, this statistic is similar to the pearson's correlation coefficient in its derivation.
in fact, a pearson's correlation coefficient estimated for two binary variables will return the phi coefficient.
the interpretation of the phi coefficient requires caution.
it has a maximum value that is determined by the distribution of the two variables.
if both have a 50/50 split, values of phi will range from −1 to +1.
application of the phi coefficient is particularly seen in educational and psychological research, in which the use of dichotomous variables is frequent.
suppose we are interested in exploring whether in a group of students opting for university courses, there is gender preference for physical sciences or life sciences.
here, we have two binary variables – gender (male or female) and discipline (physical science or life science).
we can arrange the data as a 2 × 2 contingency table and calculate the phi coefficient.
simple linear regression if two variables are highly correlated, it is then feasible to predict the value of one (the dependent variable) from the value of the other (the independent variable) using regression techniques.
in simple linear regression, the value of one variable (x) is used to predict the value of the other variable (y) by means of a simple mathematical function, the linear regression equation, which quantifies the straight-line relationship between the two variables.
this straight line, or regression line, is actually the “line of best fit” for the data points on the scatter plot showing the relationship between the variables in question.
the regression line has the general formula: y = a + bx.
where “a” and “b” are two constants denoting the intercept of the line on the y-axis (y-intercept) and the gradient (slope) of the line, respectively.
the other name for b is the “regression coefficient.” physically, “b” represents the change in y, for every 1 unit change in x; while “a” represents the value that y would take, if x is 0. once the values of a and b have been established, the expected value of y can be predicted for any given value of x, and vice versa.
thus, a model for predicting y from x is established.
there may be situations, in which a straight line passing through the origin will be appropriate for the data, and in these cases, the equation of the regression line simplifies to y = bx.
but how do we fit a straight line to a scattered set of points which seem to be in linear relationship?
if the points are not all on a single straight line, we can, by eye estimation, draw multiple lines that seem to fit the series of data points on the scatter diagram.
but which is the line of best fit?
this problem had mathematicians stumped literally for centuries.
the solution was in the form of the method of least squares, which was first published by the french mathematician adrien-marie legendre in 1805 but used earlier by carl friedrich gauss in germany in 1795 to calculate the orbit of celestial bodies.
gauss developed the idea further and today is known as the father of regression.
look at figure 4. when we have a scattered series of dot which are lying approximately but not exactly on a straight line, we can, by eye estimation, draw a number of lines that seem to fit the series.
but which is the line of best fit?
the method of least squares, in essence, selects the line that would provide the least sum of squares for the vertical residuals or offsets.
in figure 4, it is line b as is shown in the lower panel.
for a particular value of x, the vertical distance between the observed and fitted value of y is known as the residual or offset.
since some of the residuals are above and some below the line of best fit, we require a +or −sign to mathematically denote the residuals.
squaring removes the effect of the −sign.
the method of least squares finds the values of “a” and “b” that minimizes the sum of the squares of all the residuals.
the method of least squares is not the only technique, but is regarded as the simplest technique for linear regression, that is for the task of finding the straight line of best fit for a series of points depicting a linear relationship on a scatter diagram.
figure 4 the principle of the method of least squares for linear regression.
the sum of the squared “residuals” is the least for the line of best fit you may wonder why the statistical procedure of fitting a line is called “regression” which in common usage means “going backward.” interestingly, the term was used neither by legendre or gauss but is attributed to the english scientist francis galton who had a keen interest in heredity.
in victorian england, galton measured the heights of 202 fathers and their first born adult sons and plotted them on a graph of median height versus height group.
the scatter for fathers and sons approximated to two lines that intersected at a point representing the average height of the adult english population.
studying this plot, galton made the very interesting observation that tall fathers tend to have tall sons but they are not as tall as their fathers, and short fathers tend to have short sons but they are not as short as their fathers; and in the course of just two or three generations the height of individuals tended to go back or “regress” to the mean population height.
he published a famous paper titled “regression towards mediocrity in hereditary stature.” this phenomenon of regression to the mean can be observed in many biological variables.
the term regression subsequently somehow got attached to the procedure of line fitting itself.
note that in our discussion above; we have discussed the predictive relationship between two numerical variables.
this is simple linear regression.
if the value of y requires more than one numerical variable for a reasonable prediction, we are encountering the situation called multiple linear regression.
we will be discussing the basics of this in a future module.
pitfalls in correlation and regression analysis correlation and linear regression analysis are based on certain assumptions pertaining to the data sets.
if these assumptions are not met, conclusions drawn can be misleading.
both assume that the relationship between the two variables is linear.
the observations have to be independent – they are not independent if there is more than one pair of observations (that is repeat measurements) from one individual.
for correlation, both variables should be random variables although for regression, only the response variable y needs to be random.
inspecting a scatter plot is of utmost importance before estimation of the correlation coefficient for many reasons: a nonlinear relationship may exist between two variables that would be inadequately described, or possibly even undetected, by the correlation coefficient.
for instance, the correlation coefficient if calculated for the set of data points in figure 2, would be almost zero, but we will be grossly wrong if we conclude that there is no association between the variables.
the zero coefficient only tells us that there is no linear (straight-line) association between the variables, when in reality there is a clear curvilinear (curved-line) association between theman outlier may create a false correlation.
inspect the scatter plot in figure 5a.
the r value of 0.923 suggests a strong correlation.
however, a closer look makes it obvious that the series of dots is actually quite scattered, and the apparent correlation is being created by the outlier point.
this kind of outlier is called univariate outlier.
if we consider the x value of this point, it is way beyond the range of rest of the x values; similarly, the y value of the point is much beyond the range of y values for the rest of the dots.
an univariate outlier is easy to spot by simply sorting the values or constructing boxplotsconversely, an outlier can also spoil a correlation.
the scatter plot in figure 5b suggests only moderate correlation at r value of 0.583, but closer inspection reveals that a single bivariate outlier reduces what is otherwise an almost perfect association between the variables.
note that the deviant case is not an outlier in the usual univariate sense.
individually, its x value and y value are unexceptional.
what is exceptional is the combination of values on the two variables that it exhibits, making it an outlier, and this would be evident only on a scatter plotclustering within datasets may also inflate a correlation.
look at figure 5c.
two clusters are evident, and individually they do not appear to show strong correlation.
however, combining the two suggests a decent correlation.
this combination may be undesirable in real life.
clustering within datasets may be a pointer that the sampling has not really been random.
figure 5 examples of misleading correlations when using a regression equation for prediction, errors in prediction may not be just random but may also be due to inadequacies in the model.
in particular, extrapolating beyond the range of observed data can be risky and is best avoided.
consider the simple regression equation: weight = a + b × height.
suppose we give a height value of 0. the corresponding weight value, strangely, is not 0 but equals a. what is the matter here?
is the equation derived through regression faulty?
the fact is that the equation is not at fault, but we are trying to extrapolate its use beyond the range of values used in deriving the equation through least squares regression.
this is a common pitfall.
equations derived from one sample should not be automatically applied to another sample.
equations derived from adults, for instance, should not be applied to children.
correlation is not causation one of the common errors in interpreting the correlation coefficient is failure to consider that there may be a third variable related to both of the variables being investigated, which is responsible for the apparent correlation.
therefore, it is wrong to infer that there is cause and effect relationship between two variables that are correlated, even if the correlation is strong.
in other words, correlation does not imply causation.
as a now widely stated example, numerous epidemiological studies showed that women taking combined hormone replacement therapy (hrt) also had a lower-than-average incidence of coronary heart disease (chd).
the correlation was strong leading researchers to propose that hrt was protective against chd.
however, subsequent randomized controlled trials showed that hrt causes a small but statistically significant increase in the risk of chd.
reanalysis of the data from the epidemiological studies showed that women undertaking hrt were more likely to be from higher socioeconomic groups, with better-than-average diet and exercise regimens.
the use of hrt and decreased the incidence of chd were coincident effects of a common cause (i.e., the benefits associated with a higher socioeconomic status), rather than a direct cause and effect, as had been supposed.
correlation may simply be due to chance.
for example, one could compute r between the abdominal circumference of subjects and their shoe sizes, intelligence, or income.
irrespective of the value of r, these associations would make no sense.
for any two correlated variables, a and b, the following relationships are possible: a causes b or vice versa (direct causation)a causes c which causes b or the other way round (indirect causation)a causes b and b causes a (bidirectional or cyclic causation)a and b are consequences of a common cause but do not cause each otherthere is no causal connection between a and b; the correlation is just coincidence.
thus, causality ascertainment requires consideration of several other factors, including temporal relationship, dose-effect relationship, effect of dechallenge and rechallenge, and biological plausibility.
of course, a strong correlation may be an initial pointer that a cause-effect relationship exists, but per se it is not sufficient to infer causality.
there must also be no reasonable alternative explanation that challenges causality.
establishing causality is one of the most daunting challenges in both public health and drug research.
carefully controlled studies are needed to address this question.
assessing agreement in the past correlation has been used to assess this degree of agreement between sets of paired measurements.
however, correlation quantifies the relationship between numerical variables and has limitations if used for assessing comparability between methods.
two sets of measurements would be perfectly correlated if the scatter diagram shows that they all lie on a single straight line, but they are not likely to be in perfect agreement unless this line passes through the origin.
it is very likely that two tests designed to measure the same variable would return figures that would be strongly correlated, but that does not automatically mean that the repeat measurements are also in strong agreement.
data which seem to be in poor agreement can produce quite high correlations.
in addition, a change in scale of measurement does not affect the correlation, but it can affect the agreement.
bland-altman plot bland and altman devised a simple but informative graphical method of comparing repeat measurements.
when repeat measurements have been taken on a series of subjects or samples, the difference between pairs of measurements (y-axis) is plotted against the arithmetic mean of the corresponding measurements (x-axis).
the resulting scatter diagram such as figure is the bland–altman plot (after john martin bland and douglas g. altman, who first proposed it in 1983 and then popularized it through a lancet paper in 1986) an example of which is given in figure 6. the repeat measurements could represent results of two different assay methods or scores from the same subjects by two different raters.
figure 6 example of a bland–altman plot used to compare two test methods.
the bias line with the limits of agreement is provided computer software that draws a bland–altman plot can usually add a ‘bias’ line parallel to the x-axis.
this represents the difference between the means of the two sets of measurements.
lines denoting 95% limits of agreement (mean difference ± 1.96 sd of the difference) can be added on either side of the bias line.
alternatively, lines denoting 95% confidence limits of mean of differences can be drawn surrounding the bias line.
bland–altman plots are generally interpreted informally.
three things may be looked at: how big is the average discrepancy between the methods, which is indicated by the position of the bias line.
this discrepancy may be too large to accept clinically.
however, if the differences within mean ± 1.96 sd are not clinically important, the two methods may be used interchangeablywhether the scatter around the bias line is too much, with a number of points falling outside the 95% agreement limit lineswhether the difference between the methods tends to get larger or smaller as the values increase.
if it does, as is indicated in figure 7, it indicates the existence of a proportional bias which means that the methods do not agree equally through the range of measurements.
figure 7 example of a bland–altman plot showing proportional bias.
in this case, the difference between the methods first tends to narrow down and then increase as the value of measurements increase the bland–altman plot may also be used to assess the repeatability of a method by comparing repeated measurements on a series of subjects or samples by that single method.
a coefficient of repeatability can be calculated as 1.96 times the sd of the differences between the paired measurements.
since the same method is used for the repeated measurements, it is expected that the mean difference should be zero.
this can be checked from the plot.
intraclass correlation coefficient although originally introduced in genetics to judge sibling correlations, the intraclass correlation coefficient (icc) statistic is now most often used to assess the consistency, or conformity, of measurements made by multiple observers measuring the same parameter or two or more raters scoring the same set of subjects.
the methods of icc calculation have evolved over time.
the earliest work on intraclass correlations focused on paired measurements, and the first icc statistics to be proposed was modifications of the pearson's correlation coefficient (which can be regarded interclass correlation) calculations.
beginning with ronald fisher, the intraclass correlation has been regarded within the framework of analysis of variance and its calculation is now based on the true (between subject) variance and variance of the measurement error (during repeat measurement).
the icc takes a value between 0 and 1. complete inter-rater agreement is indicated by a value of 1 but this is seldom achieved.
arbitrarily, the agreement boundaries proposed are <0.40: poor; 0.40–0.60: fair; 0.60–0.74: good, and >0.75: strong.
software may report two coefficients with their respective 95% cis.
icc for single measures is an index for the reliability of the multiple ratings by a single typical rater.
icc for average measures is an index for the reliability of different raters averaged together.
this icc is always slightly higher than the single measures icc.
software may also offer different models for icc calculation.
one model assumes that all subjects were rated by the same raters.
a different model may be used when this precondition is not true.
the model may test for consistency when systematic differences between raters are irrelevant, or absolute agreement, when systematic differences are relevant.
some published examples of the use of correlation analysis are provided in the box 1. box 1 examples of correlation and agreement analysis from published literature finally, note that assessing agreement between categorical variables requires different indices such as cohen's kappa.
this will be discussed in a future module.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
correlation and linear regression are the most commonly used techniques for quantifying the association between two numeric variables.
correlation quantifies the strength of the linear relationship between paired variables, expressing this as a correlation coefficient.
if both variables x and y are normally distributed, we calculate pearson's correlation coefficient (r).
if normality assumption is not met for one or both variables in a correlation analysis, a rank correlation coefficient, such as spearman's rho (ρ) may be calculated.
a hypothesis test of correlation tests whether the linear relationship between the two variables holds in the underlying population, in which case it returns a p < 0.05. a 95% confidence interval of the correlation coefficient can also be calculated for an idea of the correlation in the population.
the value r2 denotes the proportion of the variability of the dependent variable y that can be attributed to its linear relation with the independent variable x and is called the coefficient of determination.
linear regression is a technique that attempts to link two correlated variables x and y in the form of a mathematical equation (y = a + bx), such that given the value of one variable the other may be predicted.
in general, the method of least squares is applied to obtain the equation of the regression line.
correlation and linear regression analysis are based on certain assumptions pertaining to the data sets.
if these assumptions are not met, misleading conclusions may be drawn.
the first assumption is that of linear relationship between the two variables.
a scatter plot is essential before embarking on any correlation-regression analysis to show that this is indeed the case.
outliers or clustering within data sets can distort the correlation coefficient value.
finally, it is vital to remember that though strong correlation can be a pointer toward causation, the two are not synonymous.
