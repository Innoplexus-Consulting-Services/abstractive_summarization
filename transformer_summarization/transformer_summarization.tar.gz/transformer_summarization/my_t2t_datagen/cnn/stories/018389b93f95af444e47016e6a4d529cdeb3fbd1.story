1 introduction melanoma is one of the most rapidly increasing human malignancies in populations of caucasian descent [1].
since both young and old individuals are affected by this cancer form, it places a substantial economic burden on societies [2].
melanoma is subdivided into histopathological subtypes, with the most common being superficial spreading melanoma (ssm), nodular melanoma (nm), lentigo maligna melanoma (lmm), and acral lentiginous melanoma (alm) [3].
histologic subdivisions are based on differences in cytological and architectural features, growth patterns and, to some extent, the site on the body [4].
the subtypes are important for aetiological and diagnostic purposes, but not necessarily for prognosis as this often depends on the lesion thickness [5].
genetic vulnerability is known to prime certain individuals for melanomagenesis [6].
moreover, sun exposure, nevi count, and a fair pigmentation phenotype can increase susceptibility to melanoma; however, their significance differs among the subtypes [7].
previously, we found that children who were one height z-score taller than their peers had approximately a 20% higher risk of developing adult melanoma in a population of danish schoolchildren [8].
this suggests that mechanisms regulating childhood height may also contribute to melanoma development in adulthood.
nonetheless, it remains unknown if the future risk of specific melanoma variants is related to height in childhood.
therefore, this study investigated whether childhood height was associated with the risk of morphologically different cutaneous melanoma variants in adulthood by analysing data from the same danish cohort of children.
2 methods 2.1 study population in the copenhagen municipality, physicians and nurses annually measured the height and weight of danish children who attended public and private schools.
these measurements are contained in the electronic copenhagen school health records register, including information on body size on 372,636 danish children, born from 1930 to 1989 [9].
information exists for each child from the ages of 7–13 years until 1983 as subsequently the children were only measured at school entry and exit.
using the lamda mu sigma method [10], height was converted into z-scores according to age-, sex- and birth cohort-specific (5-year interval) references.
since april 2, 1968, all danish citizens have been assigned a personal identification number [11], enabling record linkages to national health registers.
one is the national danish cancer registry which was established in 1942 and contains information on malignancies [12].
until 1994, the danish cancer registry classified cancers using the international classification of diseases (icd) version 7 and thereafter according to icd-10.
in the period of 1978–2004, the first version of the international classification of diseases for oncology (icd-o-1) was used followed by the third version (icd-o-3) to describe cancer morphology.
in 2004, the danish cancer registry was modernised and cancers diagnosed from 1978 to 2004 were converted into icd-10 and icd-o-3 [12].
in this study, the identification numbers were used to identify melanoma cases according to icd-10 (c43) and they were subdivided into histological categories in agreement with icd-o-3: ssm (8743), nm (8721), alm (8744), lmm (8742), and melanoma not otherwise specified (nos) (8720).
the variants were analysed separately, and individuals with other forms of melanoma were censored.
vital status for each individual was obtained from the danish civil registration system [11].
follow-up began on january 1, 1978, or age 15 years, whichever came later.
from an initial population of 372,636 individuals, we excluded individuals who did not have an identification number (n = 42,668), who were deceased, emigrated, or lost to follow-up prior to january 1, 1978, or before age 15 years (n = 7628), who were diagnosed with melanoma prior to 1978 (n = 96) or before age 15 years (n = 5), who were missing the date at melanoma diagnosis (n = 4) or missing height or weight values at all ages (n = 6033) or who had outlying measures of height or body mass index (kg/m2) (z-score <−4.5 or >4.5) at all ages (n = 9), resulting in an eligible cohort of 316,193 individuals (160,013 men, 156,180 women) (supplementary fig.
1).
in analyses investigating associations between change in height and the melanoma variants, we only included children who had measurements at both ages 7 and 13 years (total 254,499; 127,717 men, 126,782 women).
follow-up ended on the date of a melanoma diagnosis, emigration, death, loss to follow-up, or december 31, 2012 (date of the last available update from the danish cancer registry), whichever came first.
2.2 statistical methods associations between childhood height z-scores and the different melanoma variants were assessed using cox proportional hazards regressions with age as the underlying time metric.
associations between growth patterns in height z-scores from the ages of 7–13 years and the melanoma variants were examined using the same approach.
analyses were stratified by birth cohort (5-year intervals: 1930–1934, …, 1985–1989).
the linearity of the associations was investigated by testing against a restricted cubic spline (five knots).
the proportional hazard assumption was examined by modelling a time-varying effect in the cox regression model.
potential interactions between height and either birth cohort (1930–1934, …, 1955–1989) or sex on associations with the melanoma variants were assessed using likelihood ratio tests.
we detected no signs of departures from linearity, violations of the proportional hazards assumptions, or birth cohort effects.
significant differences were not detected between the sexes (all p > 0.11); thus, all analyses were stratified by sex.
the statistical analyses were conducted using stata (version 12.1).
the study was approved by the danish data protection agency.
in accordance with danish law, informed consent is not required for purely register-based studies of preexisting information.
3 results during 9.1 million person-years of follow-up, 2223 cases of melanoma were identified (1018 men, 1205 women).
most melanoma cases were categorised as ssm (60%) with the remaining cases being melanoma nos (27.5%), nm (8.5%), lmm (2%), alm (0.6%), and other rare melanoma forms (1.5%).
the melanoma variants were similarly distributed in men and women, but the median age at diagnosis varied by morphology and sex, ranging from 51 to 67 years (table 1).
due to the limited number of cases, alm and the rare melanomas were not investigated further.
at ages 7–13 years, one increase in height z-score was positively associated with ssm, melanoma nos, and nm in adulthood (fig.
1, supplementary tables 1–3).
to put these associations into perspective, one z-score in height at age 13 years corresponds to approximately 8 cm in boys and 6.9 cm in girls.
for the lmm subtype, the hazard ratios (hrs) at ages 7–13 years were in the positive direction, but only borderline statistically significant at 8 years (fig.
1, supplementary table 4).
in the analyses investigating if growth patterns of height in children from 7 to 13 years were associated with the various melanomas in adulthood, we conducted separate analyses including 1172 ssm cases (509 men, 663 women), 519 melanoma nos cases (249 men, 270 women), 165 nm cases (92 men, 73 women), and 42 lmm cases (16 men, 26 women).
as few children changed ±1 z-score in height between the ages of 7 and 13 years, the effects of change per ±0.5 z-score were analysed.
compared with an average child (reference: z-score 0 at both ages 7 and 13), a child who was tall at 7 years, but average height at 13 years (z-score 0.5 at 7 years and z-score 0 at 13 years) had a significantly increased risk of developing ssm (p = 0.015) or melanoma nos (p = 0.009) (table 2).
compared with the average child, a child who was persistently tall at 7 and 13 years (z-score 0.5 at 7 years and z-score 0.5 at 13 years) had significantly higher risk of developing ssm (p < 0.001), melanoma nos (p < 0.001), or nm (p = 0.010) (table 2).
however, in comparison to the average child, a child who was average at 7 years but tall at 13 years (z-score 0 at 7 years and z-score 0.5 at 13 years) did not have a significantly increased risk of developing any of the examined melanoma variants (table 2).
a comparison between children who grew tall between 7 and 13 years and children who were persistently tall revealed that the persistently tall children had significantly higher risks of developing ssm (hr 1.07, 95% confidence intervals [ci]: 1.01–1.14, p = 0.015) or melanoma nos (hr 1.12, 95% ci: 1.03–1.22, p = 0.009), but not nm (hr 1.05, 95% ci: 0.90–1.23, p = 0.527) or lmm (hr 1.08, 95% ci: 0.79–1.46, p = 0.636).
4 discussion in this study, taller childhood height was positively associated with developing ssm, melanoma nos and nm, but not lmm, in adulthood.
height trajectories in childhood were associated with melanoma variants.
specifically, persistently tall children had significantly increased risks of developing ssm, nm or melanoma nos when compared with average height children, and ssm or melanoma nos when compared to children who grew tall between age 7 and 13 years.
in the present study, the associations between childhood height and the ssm, nm, and melanoma nos variants were similar to the height-melanoma associations we previously reported for all subtypes combined [8].
although the height-lmm associations were positive, they were not statistically significant, likely because of a lack of power due to the small number of lmm cases (n = 44).
collectively, these results demonstrate that childhood height is an indicator of risk for several melanoma variants and does not only reflect a height-melanoma association driven by the predominant subtype of ssm.
in our study, 27.5% of the melanomas were classified as melanoma nos, and this is as expected [13].
recently, fewer melanomas are classified as nos (3.6% of melanomas in 2014) [14], likely resulting from the addition of diagnostic categories and fewer centres conducting histopathological examinations, reflecting that more tumours are categorised in greater detail than before.
it is therefore likely that most of the melanoma nos tumours in our study would be classified today as one of the most frequent melanoma types and only a small subset would be other rare tumour forms (desmoplastic melanoma, clear cell melanoma etc.).
accordingly, our results for melanoma nos are comparable with results for ssm and nm; the two most common forms in this study.
we found that height growth patterns in childhood were differently associated with the melanoma variants.
children who were tall at the age of 7 years had significantly increased risks of ssm and melanoma nos, whereas persistently tall children had increased risks of ssm, melanoma nos, and nm.
these results suggest that tall stature at 7 years and/or persistent tallness at 7 and 13 years are indicators of risk for melanomagenesis in adulthood.
since our cohort does not include children younger than 7 years of age, we are unable to explore the possibility that even younger ages are of particular importance for future melanoma predisposition.
comparisons with other studies are challenging as most have not investigated childhood height, and this is presumably due to a lack of appropriate data resources.
a large body of adult literature supports associations between height and melanomagenesis; however, these studies did not subcategorise melanoma according to morphology and considered the disease as one biological entity [15], [16], [17], [18], [19], [20], [21], [22], [23], [24].
nonetheless, a separation of melanoma into histological subtypes suggests that tall adults are predisposed to the development of ssm but not nm and lmm [25].
given our findings and that melanoma development occurs over a period of 20–40 years [26], these results indicate that the susceptibility to this disease already originates in childhood.
although it has been suggested that melanoma mortality will decrease in the near future due to changes in sun habits among children [27], the lack of birth cohort effects in the present study suggests that the height-melanoma associations reflect biological mechanisms that have remained stable across time.
the mechanisms interconnecting height and cancer are not well understood; however, they likely act cooperatively during the complex manifestation of carcinogenesis.
it is possible that height is a biomarker for other underlying processes affecting both stature and cancer development.
a recent large-scale study identified almost 700 genetic variants that are responsible for approximately 20% of the heritability for height [28].
it can be speculated that some of these genetic variants also affect malignant transformation.
moreover, a recent study found a positive association between height and nevi count which is known to be a strong risk factor for melanoma development [29].
another postulated height-melanoma mechanism is that taller individuals have an increased risk of cancer because of a greater number of cells and thus a higher rate of cell divisions within tissues [30].
in accord with this hypothesis, the proliferation of melanocytes accelerates during childhood [31], increasing the number of cells capable of acquiring detrimental lesions that could predispose children to future melanoma development.
notably, a site-dependent susceptibility to melanomagenesis has been suggested [32], indicating that particular body areas are more vulnerable for malignant transformation.
with regards to the association between height and melanoma, studies that investigated the anatomical site distribution of melanomas found that the lesions occur mainly on the trunk in men and on the lower extremities in women [33], [34], [35], [36], [37], [38], although there are recent indications that women are starting to exhibit more centrally located tumours [39].
the diverse localisation of melanomas has been linked to different sun exposure patterns and sunscreen use between the sexes [37], [38].
however, children already display a sex-specific spreading of nevi that is similar to the melanoma distribution in adults, suggesting that the location of melanoma could be influenced by other factors in addition to differences in sun exposure [40], [41], [42].
it may also be speculated whether the distribution of nevi is interconnected with sex-specific height growth patterns during childhood.
boys and girls exhibit distinct growth patterns where diverse body parts grow at different time points.
in girls, the peak height velocity occurs between the peak of leg and trunk length velocities, whereas the peak height velocity in boys is closer to the peak of trunk length growth [43].
hence, the spurt in boys final height is mainly attributable to an increase in trunk rather than leg length [43].
accordingly, the sex-specific growth spurts during childhood could potentially accelerate mitotic activity and malignant transformation of melanocytes, explaining why the trunk and legs might be more susceptible to melanoma development in men and women, respectively.
the present study has several strengths including its large size, its long follow-up with a minimal loss of individuals, and its inclusion of measured height values in contrast with self-reported measurements.
moreover, the unique design of the cohort enabled us to investigate the effects of changes in height in childhood and their associations with different melanoma variants in adulthood.
however, the study may be limited by the lack of information on particular height components (leg and trunk length) and established melanoma risk factors including genetic status, nevi count, pigmentation phenotype, and sun habits.
in conclusion, childhood height is positively and significantly associated with developing adult ssm, melanoma nos, and nm.
moreover, children's height patterns are linked with the risk of developing different melanoma variants.
these results suggest that childhood height is an indicator of risk for the majority of melanoma variants and is not only a phenomenon restricted to the predominant subtypes.
collectively, these results expand the current knowledge of the underlying risk factors for the different melanoma variants and offer insight into the complex interplay between height in childhood and future melanomagenesis.
conflict of interest statement none declared.
funding this research was financially supported by the european research council under the european union's seventh framework programme (fp/2007-2013)/erc grant agreement no.
281419, childgrowth2cancer awarded to jennifer lyn baker.
the funder had no influence in the design and conduct of the study; collection, management, analysis, and interpretation of the data; preparation, review or approval of the manuscript; and decision to submit the manuscript for publication.
@highlight
aim of the study melanoma subtypes have different aetiological characteristics.
child height is positively associated with adult melanoma; however, a clarification of associations with specific melanoma variants is necessary for an improved understanding of risk factors underlying the histologic entities.
this study investigated associations between childhood height and future development of cutaneous melanoma variants.
method a cohort study of 316,193 individuals from the copenhagen school health records register, with measured heights at ages 7–13 years who were born from 1930 to 1989. melanoma cases were identified via linkage to the national danish cancer registry and subdivided into subtypes.
cox proportional hazards regressions were performed.
results a total of 2223 cases of melanoma distributed as 60% superficial spreading melanoma (ssm), 27.5% melanoma not otherwise specified (nos), 8.5% nodular melanoma (nm), and 2% lentigo maligna melanoma (lmm).
the remaining rare melanoma forms were not analysed.
childhood height was positively and significantly associated with ssm, melanoma nos, and nm, but not lmm, in adulthood.
per height z-score at age 13 years, the hazard ratios were 1.20 (95% confidence intervals [ci]: 1.13–1.27) for ssm, 1.19 (95% ci: 1.09–1.29) for melanoma nos, and 1.21 (95% ci: 1.04–1.41) for nm.
further, growth patterns were linked to the melanoma variants with persistently tall children having an increased risk of developing ssm, melanoma nos, or nm.
conclusion childhood height is positively associated with the majority of the melanoma variants.
these results suggest that the underlying processes contributing to childhood height and growth patterns interconnect early-life events with the predisposition to melanomagenesis in adulthood.
