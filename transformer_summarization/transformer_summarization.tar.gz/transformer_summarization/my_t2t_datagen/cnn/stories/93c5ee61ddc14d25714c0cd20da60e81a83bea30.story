low-cost medicines of assured quality can improve medication adherence, reduce health-care spending, and provide benefit for patients with limited income and health programs with constrained budgets.
however, there is apprehension among physicians, professional bodies, and patients, that low-cost medicines may be clinically inferior to the high-cost innovator brands (ibs).
hypertension is one of the major risk factors for cardiovascular and cerebrovascular diseases.
[1] it is a silent, invisible killer that rarely causes symptoms.
worldwide, hypertension is estimated to cause 7.5 million deaths, about 12.8% of the total of all deaths.
[2] although this remains a vexing problem, hypertension can be prevented and is controllable.
[345] amlodipine is a calcium channel blocker (ccb) widely used as an antihypertensive.
[6] in india, besides ib of amlodipine, various low-cost brands (lcbs) are also available.
however, there are no published clinical trials comparing effectiveness and safety of ib versus lcb amlodipine in hypertension.
this randomized, crossover, noninferiority trial was conducted to evaluate clinical effectiveness and safety of lcb versus ib amlodipine in hypertension with respect to systolic blood pressure (sbp) reduction.
accordingly, our primary study end-points were (a) sbp reduction from baseline to study end and (b) proportion of patients experiencing at least one treatment-emergent adverse event (ae), and our secondary end-points were (a) sbp change at each visit from baseline level and (b) changes of diastolic blood pressure (dbp) from baseline to study end.
materials and methods this phase iv, randomized, controlled, single-blinded, crossover, noninferiority trial was initiated after approval by the institutional ethics committee and was registered in the clinical trial registry of india (ctri/2015/01/005390).
recruitment was done from the medicine outpatient department of the hospital.
adult patients (age 18–70 years) of either gender, newly diagnosed with stage 1 hypertension (joint national committee 7 - sbp: 140–159 mmhg or dbp: 90–99 mmhg),[7] or isolated systolic hypertension with sbp 140–159 and dbp <90 mmhg were included in the study.
patients with blood pressure (bp) more than 160 (systolic)/99 (diastolic) or conditions amlodipine were considered contraindicated (history of hypersensitivity to ccb) and pregnant, lactating women, or those on prior antihypertensives were excluded from the study.
sample size was calculated assuming a noninferiority margin of 10 mmhg, a true mean difference of 5 mmhg, a standard deviation of 10 mm in sbp, 80% power, 5% level of significance, and considering 15% dropout rate, 28 evaluable patients were required.
a fixed block randomization strategy (block size of six) with equal allocation ratio was done using randomization software.
allocation concealment was done by sealed sequentially numbered opaque envelopes.
the study physician who clinically assessed the patients was aware, but the patients themselves were unaware of the treatment allocation schedule.
as it was a 2 × 2 crossover study, so after initial assessment for eligibility, patients were enrolled and randomized to be included either in sequence 1 (lcb/ib) or in sequence 2 (ib/lcb).
each sequence consisted of two periods, 6 weeks each with a wash-out period of 1 week in between.
the study drug was amlodipine 5 mg once daily orally at 8 am either ib or lcb, in their respective periods in a crossover manner.
tablet amlogard (pfizer limited) and tablet amlopen (morepen laboratories limited) were used as ib and lcb of amlodipine, respectively.
at baseline visit, data regarding age, gender, weight, pulse rate and bp were recorded and electrocardiogram was done.
bp was measured using aneroid manometer and standard size cuff.
trough bp and pulse rate were measured in duplicate with the patient in the sitting position; mean values were calculated and recorded.
tolerability was assessed by taking history, and compliance was assessed by pill counts.
both groups received standard treatment for other concomitant diseases if present.
advice regarding lifestyle modification to control hypertension was given to all patients.
data were captured at baseline visit and the end of 2, 4, and 6 weeks in each period.
an intention to treat analysis was performed for determination of efficacy and safety analysis (i.e., all patients who had taken at least one dose of the study medication).
summary statistics of numeric variables were expressed as mean and standard deviation and categorical data as proportions.
numeric parametric data were analyzed using paired t-test, unpaired t-test, and repeated measures analysis of variance (anova) according to the condition; categorical data were analyzed by fisher's exact test.
the 95% confidence interval (ci) of the difference between means was determined and p; 0.05 was considered statistically significant.
cost minimization analysis was calculated as percentage of cost difference between lcb and ib amlodipine.
adherence to medication by pill count method was calculated as the number of prescribed pills corrected for the number of returned pills divided by the period (in days) multiplied by 100%.
an adherence level of at least 90% was defined as good.
results a total of thirty patients were screened, of which 28 (13 in sequence 1 and 15 in sequence 2) were enrolled.
reasons for screen failure were not meeting inclusion criteria (n1; 1) and unwillingness to participate in the study (n = 1).
out of 28, 27 patients completed the study (lost to follow-up = 1) [annexure 1].
baseline demographic characteristics such as age, gender, body weight, pulse rate, sbp, and dpb between sequence 1 and 2 were comparable (p value for all these variables were >0.05) [table 1].
in the assessment of efficacy of lcb and ib amlodipine on lowering bp, we found that both of these drugs reduced bp in their respective periods in each sequence.
in period 1 of sequence 1, mean reduction of sbp and dbp by lcb amlodipine was 24.46 ± 5.78 mmhg (p < 0.0001) and 10.53 ± 1.50 mmhg (p < 0.0001), respectively.
in period 2 of sequence 1, mean reduction of sbp and dbp by ib amlodipine was 27.33 ± 3.68 mmhg (p < 0.0001) and 12.08 ± 3.11 mmhg (p < 0.0001), respectively.
in this sequence, reduction of bp by lcb amlodipine and ib amlodipine was comparable (p = 0.15 for sbp and 0.13 for dbp).
in period 1 of sequence 2, mean reduction of sbp and dbp by ib amlodipine was 28.71 ± 4.54 (p < 0.0001) and 12.21 ± 2.75 mmhg (p < 0.0001), respectively.
in period 2 of sequence 2, mean reduction of sbp and dbp by lcb amlodipine was 27.07 ± 6.57 mmhg (p < 0.0001) and 11.93 ± 2.20 mmhg (p < 0.0001), respectively.
in this sequence also, reduction of bp by ib amlodipine and lcb amlodipine was comparable (p = 0.47 for sbp and 0.73 for dbp).
table 1 baseline demographic variables of patients with hypertension (n=13 for sequence 1, n=15 for sequence 2) when considering the effect of lcb and ib amlodipine on total patients (patients in both sequences), we found that bp was reduced significantly by both of these drugs.
mean reduction of sbp and dbp by lcb amlodipine was 25.82 ± 6.14 mmhg (p < 0.0001) and 11.23 ± 1.99 mmhg (p < 0.0001), respectively.
mean reduction of sbp and dbp by ib amlodipine was 28.08 ± 4.15 mmhg (p < 0.0001) and 12.15 ± 2.87 mmhg (p < 0.0001), respectively.
reduction of bp by these two drugs were comparable (p = 0.15 for sbp and 0.17 for dbp) [figure 1].
figure 1 change of blood pressure (mean ± standard deviation) in different study visits we measured the change of sbp from baseline to each visit (repeated measures anova).
significant reduction (p < 0.0001) of sbp was found from baseline to each visit in both lcb and ib amlodipine (sequence 1 + sequence 2).
in case of lcb group, a significant reduction (p < 0.05) of sbp was found in all the pairs.
however, in case of ib group, a significant reduction (p < 0.05) of sbp was found in all the pairs, except the pair of first and second follow-ups.
we found that the lower bound of the 95% ci of the difference in reduction of sbp (−5.04 mmhg) and dbp (−2.26 mmhg) between the lcb and ib group was within this noninferiority margin of 10 mmhg, indicating lcb amlodipine was noninferior to ib amlodipine [table 2].
table 2 noninferiority of low cost brand amlodipine to innovator brand amlodipine (noninferiority margin: 10 mmhg) lcb and ib amlodipine were comparable regarding their ae profile.
lcb amlodipine was associated with headache, ankle edema, malaise, nausea, and diarrhea in five subjects (17.87%).
on the other hand, ib amlodipine was associated with headache, nausea, pain abdomen, dizziness, malaise, vertigo, and back pain with a total of seven different aes in seven patients (25%).
no significant difference was found between these two groups (p = 0.75).
we compared the cost of both drugs in cost minimization analysis and found that ib amlodipine (inr 68.92/10 tablets) was 160.07% more expensive than its lcb version (inr 26.50/10 tablets).
the adherence rates were also comparable with 85.19% of patients in lcb amlodipine group and 88.47% of patients in ib amlodipine group showed good adherence and the difference was not statistically significant (p = 1.00).
discussion hypertension is an important modifiable risk factor for cardiovascular, cerebrovascular, and renal disease.
concerns about medication costs and drug safety have led to growing attention to the use of lcb drugs.
our study demonstrated that lcb amlodipine is statistically noninferior to ib with respect to sbp reduction in patients with stage 1 or isolated systolic hypertension.
it was cheaper than ib, with comparable safety and tolerability profiles.
a phase iii, 8-week, multicenter, prospective, randomized, double-blinded, parallel group clinical trial had compared the effects of amlodipine camsylate (low-cost generic) versus amlodipine besylate (innovator) in korean adults with mild to moderate hypertension and the study concluded that the effectiveness and tolerability were not significantly different.
[8] in another double-blinded, randomized, three-sequence crossover study conducted in iran, it was found that there was no statistical difference in lowering bp among three different brands of amlodipine and it recommended that the brand which had the lowest price could be the first choice.
[9] conclusion our study concluded that lcb amlodipine was noninferior to its ib counterpart regarding effectiveness and safety.
lcb amlodipine can therefore be considered as a cost-effective alternative.
however, further studies with longer treatment duration will provide more evidence in this field.
financial support and sponsorship departmental fund supported the study.
conflicts of interest there are no conflicts of interest.
@highlight
objectives: a single-blinded, randomized, crossover, noninferiority trial was conducted to evaluate clinical effectiveness and safety of low-cost brand (lcb) versus innovator brand (ib) amlodipine in essential hypertension.
materials and methods: the primary end-point was change of systolic blood pressure (bp) from baseline to study end.
adult patients with stage 1 hypertension or isolated systolic hypertension were randomized to receive 5 mg amlodipine lcb or ib once daily for 6 weeks in each period in a 2 × 2 crossover manner with three follow-up visits in each sequence.
in 28 evaluable patients, the reduction of systolic bp (sbp), diastolic bp, and safety profile between two brands was comparable.
results: the lower bound of the 95% confidence interval of the difference in reduction of sbp (−5.04 mmhg) was within the noninferiority margin of 10 mmhg.
conclusion: lcb amlodipine is noninferior to ib in terms of bp reduction and is a cost-effective alternative as it is less expensive than ib.
