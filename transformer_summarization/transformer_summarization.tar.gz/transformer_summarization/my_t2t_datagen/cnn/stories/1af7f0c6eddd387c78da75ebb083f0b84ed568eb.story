allergic rhinitis (ar) is a global health problem.
it is the cause of major illness and disability worldwide.
[1] estimates indicate that 10%–25% of population worldwide is affected by ar.
[2] the main symptoms of ar include nasal congestion, rhinorrhea, itching, sneezing, and nonnasal symptoms such as burning, itching and watery eyes, or itching ears and palate.
these symptoms can have a considerable toll on patient's quality of life by interfering with cognitive and emotional functioning.
[3] the estimated annual cost attributable to ar in the united states ranges from $1.4 billion to nearly $6 billion in direct cost annually.
[4] today's antiallergic therapy is based on avoidance of the causative allergen, symptomatic pharmacotherapy, specific immunotherapy, and education.
[5] oral/intranasal h1-antihistaminics, decongestants, leukotrienes receptor antagonists, and intranasal corticosteroids are the pillars in the management of ar.
the second-generation antihistamines have become increasingly popular because of their comparable efficacy and lower incidence of adverse effects relative to the first-generation counterparts.
[67] levocetirizine, a potent second-generation histamine (h1) receptor antagonist, is effective against persistent ar and thus improves the quality of life and reduces comorbidities and societal costs.
[8] fexofenadine is a selective, nonsedating, second-generation h1 receptor antagonist which has an additional impact on the inflammatory mediators.
[9] montelukast is a highly selective type i receptor antagonist of leukotriene d4.
the leukotriene modifiers have both anti-inflammatory and bronchodilator properties.
[10] the literature search establishes that addition of an antihistamine to montelukast has an added benefit.
[11] the combination therapy of montelukast with antihistamine provides enhancing and complimentary effects, thereby reducing the symptoms effectively.
[12] the results with concomitant levocetirizine and montelukast treatment are better as compared to monotherapy with levocetirizine on symptoms and quality of life in ar.
[13] fexofenadine along with montelukast is more effective than antihistaminic alone in the control of ar symptoms.
there is literature available for the comparisons of concomitant levocetirizine and montelukast with monotherapy or placebo and comparisons of concomitant fexofenadine and montelukast with monotherapy or placebo.
however, scanty data are available regarding the comparisons of concomitant montelukast-levocetirizine with montelukast-fexofenadine.
therefore, we aimed to compare the efficacy, safety, and cost-effectiveness of these combinations in patients of ar.
materials and methods seventy patients with ar participated in a prospective, randomized, double-blind, parallel, active-controlled, comparative 4-week trial approved by the institutional ethics committee of indira gandhi government medical college and hospital, nagpur, from march 2014 to october 2014. the trial procedure was designed in accordance with the ethical standards laid down by icmr's ethical guidelines for biomedical research on human subjects.
informed consent was obtained prior to the inclusion of patients in the study.
the inclusion criteria were patients from outpatient department of ent between the age group of 18–65 years of either gender having moderate-severe intermittent or mild persistent ar according to original aria classification.
the study inclusion criteria required the patients with total nasal symptom score (tnss) of 5 or higher, not treated with antihistaminics in the previous week.
tnss is the intensity of nasal symptoms (rhinorrhea, nasal itching, nasal obstruction, and sneezing) using a 4-point likert scale from 0 to 3 (0 = no symptom, 1 = mild, 2 = moderate, and 3 = severe).
[10] the tnss was obtained from the sum of all four individual symptom scores, with a total possible score ranging from 0 (no symptoms) to 12 (maximum symptom intensity).
patients willing to sign written informed consent, complying with the study procedure, free of any clinically significant disease, and having normal electrocardiography (ecg) were included in the study.
exclusion criteria denied the participation of children, pregnant female, nursing mothers, patients with asthma requiring chronic use of inhaled or systemic corticosteroids, history of failure to improve symptoms with antihistaminic drug treatment in the past, history of allergies to study medication or tolerance to antihistamines, and use of study drug in the past 7 days.
in addition, patients with significant hematopoietic, cardiovascular, hepatic, renal, neurologic, psychiatric, or autoimmune diseases were excluded from the study.
patients with ar were divided randomly into two groups, a and b of 35 each.
sample size was calculated with standard deviation taken from previous study and level of significance set at 0.05 with power as 80%.
block randomization procedure was used for random allocation of study drugs, that is, montelukast-levocetirizine and montelukast-fexofenadine with block size of 4 in equal proportion to ensure uniform allocation ratio (1:1).
the study being double blind, the drugs were identical in shape, size, weight, texture, and packing.
the randomized treatment allocation sequence was generated by a statistician using random number table.
it was handed over along with identical plastic containers filled with study drugs to a third person not directly involved in this study.
this person labeled the containers according to random allocation sequence of patients with drugs provided.
the code of this random allocation sequence was retained in a sealed envelope and was opened only after completion of the study during the analysis of data.
the patients as well as the investigators were unaware of the treatment administered.
drugs were issued to the patients for the duration of 1 week at a time.
patients were given a new supply of drug at the end of every week.
patients were asked to bring the unused drugs and containers during follow-up till the completion of the study (4 weeks).
the medical compliance of the patients was determined from the unused tablet number.
the returned tablets were discarded.
drugs were decoded at the end of the trial.
group a received one tablet of montelukast 10 mg plus levocetirizine 5 mg fixed-dose combination daily.
group b was treated with fixed-dose combination of montelukast 10 mg plus fexofenadine 120 mg once daily.
the same dosage was maintained throughout the study.
the patients were given an 8-day symptom diary at visit one (screening visit).
a few extra day diaries were given in case if patient does not report on the scheduled day.
a recording of tnss parameter was expected from the patients.
no comorbid condition was observed in these patients during the study period.
after the study period was over, the patients were handed over to the treating physician.
efficacy was evaluated by the change in tnss from baseline.
improvement in the scores by two or more points was considered significant.
[10] for cost-effectiveness analysis, only direct cost parameters were taken into consideration.
direct cost parameters were cost of medications used, medical procedures, and hospitalization charges, if any.
cost-effectiveness ratio of both treatment groups was calculated based on the following formula: cost-effectiveness ratio = cost/outcome outcome was measured in terms of effectiveness.
tnss parameter was the main effectiveness parameter.
routine investigations such as ecg, total leukocyte count, differential leukocyte count, liver function test, and kidney function test were performed in each patient at baseline and at the end of the study.
general clinical safety was monitored by vigilant follow-up of patients for the treatment of emergent adverse events, if any, and recorded in the case report form.
patients with adverse drug reaction were managed appropriately.
results were expressed as mean (standard deviation).
group difference was ascertained by using mann–whitney rank-sum test or un-paired t- test.
difference within group was compared by wilcoxon test or nonparametric friedman test with dunn's multiple comparison post hoc test.
a two-tailed p < 0.05 was considered statistically significant.
graphpad prism version 5.00 software manufactured by graphpad software, inc., ca 92037, usa was used for statistical analysis.
results among the seventy patients randomized and allocated to the treatment, 65 patients completed the study according to the protocol.
two patients lost to follow-up at the end of the 1st week in montelukast-levocetirizine group, i.e., group a and three patients lost to follow-up at the end of 2nd week in montelukast-fexofenadine group, i.e., group b and were not integrated in the analysis [figure 1].
the two groups were homogeneous with respect to baseline demographic data [table 1].
figure 1 study flow chart table 1 baseline demographic characteristics of allergic rhinitis patients evaluation of tnss revealed statistically significant difference (p < 0.0001) when compared from baseline to 4th week in group a. baseline tnss was 11.15 and 10.68 in group a and group b, respectively.
reduction in this parameter first become apparent in the 2nd week and maintained till 4th week.
similar results were obtained in group b, but the reduction in this parameter was more as compared to group a as shown in table 2. the mean change of tnss score was 8 in group a and 9.46 in group b from baseline to 4th week.
the mean change of tnss was statistically significant (p < 0.0033) in group b as compared to group a [table 3].
the differential eosinophil count showed no significant change in any group when compared from baseline to 4th week.
table 2 total nasal symptom score at baseline and at 2 weeks and 4 weeks after the initiation of treatment in group a and group b patients with allergic rhinitis table 3 comparison of group a and group b treatment on total nasal symptom score at 4 weeks in patients with allergic rhinitis cost-effectiveness was evaluated by calculating cost-effectiveness ratio.
the treatment modality having low cost-effectiveness ratio is considered as superior in terms of cost.
the cost of treatment in group a and group b was rs.
184.8 per patient rs.
282.8 per patient, respectively, for the duration of 4 weeks.
the cost-effectiveness ratio was less in group a than in group b [table 4].
table 4 difference in cost-effectiveness ratio in group a and group b patients with allergic rhinitis overall incidence of adverse effects [table 5] was 15% and 22% in group a and group b, respectively.
there was no serious adverse event reported in both the groups.
the adverse effects reported in both groups did not require reduction in dose or any other therapy for the treatment of adverse effects.
fisher's exact test was applied to compare the incidence of adverse effect between two groups which was not significant.
table 5 adverse drug reactions in group a and group b patients with allergic rhinitis discussion this is the first double blind study to compare the combinations of montelukast-levocetirizine and montelukast-fexofenadine with respect to efficacy, safety and cost effectiveness.
after extensive literature search, we could retrieve only one randomized, open labeled, prospective, comparative, multicentric study comparing only efficacy and safety of the fixed dose combination of montelukast-levocetirizine and montelukast-fexofenadine.
moreover, in india patients have less affordability for costly medicines.
so, we considered it worthwhile to conduct this double blind study in indian set up comparing the efficacy, safety and cost effectiveness of these fixed dose combination.
the baseline data show no significant difference between the study groups with respect to demographic parameters.
this proves the homogeneity of the study patients in the two groups.
the efficacy of drugs was assessed by tnss, and the change was significant in both groups at 4th week.
the mean change in tnss was significant in montelukast-fexofenadine group as compared to montelukast-levocetirizine group.
the additional anti-inflammatory effect of fexofenadine and bronchodilator effect of montelukast might be the reason of this change.
there are studies where concomitant therapy of levocetirizine with montelukast showed statistically significant improvement in nasal symptoms as compared to monotherapy.
[1214] another study found significant improvement in the quality of life of patients suffering from ar with combination of montelukast-levocetirizine.
[15] some studies have shown that levocetirizine alone and montelukast alone were effective on nasal symptoms and inflammatory markers, but the combined treatment offered an even better symptom control.
[8] a study found that montelukast-fexofenadine showed significantly better control of ar symptoms as compared to groups using antihistaminic alone or with placebo.
[16] however, due to paucity of data regarding the comparison of the study combinations, we were unable to compare our results.
change in differential eosinophil count was not significant in both groups.
safety was assessed by change in ecg and adverse drug reaction.
the incidence of adverse effect was not significant in both the groups.
the adverse effects reported in both the groups did not require reduction in dose or any therapy for the treatment.
to compare the cost-effectiveness of the two drugs, only the direct cost of the drug treatment was taken into consideration.
the cost-effectiveness ratio was less in montelukast-levocetirizine group throughout the treatment of ar as compared to montelukast-fexofenadine group.
for pharmacoeconomic analysis, treatment modality having less cost-effectiveness ratio is considered as superior.
the cost of montelukast-levocetirizine group was rs.
6.6 per day whereas it was rs.
10.07 per day in montelukast-fexofenadine group.
although the efficacy assessed by tnss was more in montelukast-fexofenadine group as compared to montelukast-levocetirizine throughout the study, by observing the cost-effectiveness ratio, montelukast-levocetirizine combination was cost-effective as compared to montelukast-fexofenadine for the treatment of ar.
a study showed that levocetirizine is a cost-effective option with clinically meaningful improvement in quality of life as compared with other second-generation antihistamines and leukotriene antagonist.
[417] however, after in-depth search, we could not find any study related to our finding, as there were no cost-effective studies done earlier between montelukast-fexofenadine combination and montelukast-levocetirizine in patients of ar.
hence, this study is unique in comparing the two fixed-dose combinations commonly available in the market.
although the present study was double-blind with small sample size and was of short duration, the value of its result cannot be ignored.
however, studies with larger sample size and longer follow-up periods may yield more meaningful data to compare montelukast-fexofenadine combination and montelukast-levocetirizine combination.
conclusion the mean change of tnss was significant in montelukast-fexofenadine group as compared to montelukast-levocetirizine group.
however, the cost-effectiveness ratio was less in montelukast-levocetirizine group than in montelukast-fexofenadine group.
although the decrease in tnss was more in montelukast-fexofenadine group, montelukast-levocetirizine combination is more cost-effective.
however, the prescription preference of the drug lies with the prescriber seeing the condition and affordability of the patient.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
objectives: allergic rhinitis (ar) is a global health problem.
almost 10%–25% of population worldwide is affected by ar.
oral/intranasal h1-antihistamine, decongestants, leukotriene receptor antagonists, and intranasal corticosteroids are the pillars in the management of ar.
the combination therapy of montelukast with antihistaminic provides enhancing and complimentary effects, thereby reducing the symptoms effectively, but there are scanty data regarding the comparisons of combinations.
therefore, we aimed to compare the efficacy, safety, and cost-effectiveness of montelukast-levocetirizine and montelukast-fexofenadine combination in patients of ar.
materials and methods: seventy patients with ar participated in a prospective, randomized, double-blind, parallel, active-controlled, comparative 4-week trial.
the patients between the age group of 18–65 years of either gender having moderate-severe intermittent or mild persistent ar were included in the study.
the study inclusion criteria required the patients with total nasal symptom score (tnss) of 5 or higher.
the patients were randomly divided into two treatment groups with montelukast-levocetirizine (10 mg and 5 mg) in one group and montelukast-fexofenadine (10 mg and 120 mg) in another group.
tnss parameter was the main effectiveness parameter.
results: evaluation of tnss revealed significant difference (p < 0.05) when compared from baseline to 4th week in both groups.
the mean change of tnss, i.e., 9.46 was significant (p < 0.05) in montelukast-fexofenadine group.
the cost-effectiveness ratio was less in montelukast-levocetirizine group than in montelukast-fexofenadine group.
conclusion: the decrease in tnss was more in montelukast-fexofenadine group, but the cost-effectiveness is more with montelukast-levocetirizine combination.
