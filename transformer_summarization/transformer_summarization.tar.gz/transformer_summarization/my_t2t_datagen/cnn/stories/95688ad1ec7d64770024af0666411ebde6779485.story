introduction malignant mesothelioma is a neoplasm that originates from the mesothelial cells lining the pleura, peritoneum, tunica vaginalis of the testis and pericardium (1).
primary pericardial mesothelioma is extremely rare, accounting for 0.8% of all cases of mesothelioma and 2-3% of all pericardial tumors (1,2).
the diagnosis of pericardial mesothelioma is difficult and it is usually only made at autopsy.
patients mostly present with dyspnea on exertion caused by an accumulation of pericardial effusion (3), and the prognosis is very poor with a median survival period of six months from diagnosis (4).
we herein report a patient with primary pericardial mesothelioma who showed a long survival without any aggressive treatment after the onset of cardiac tamponade.
case report a 67-year-old japanese man with a smoking history of 50 pack years was taken by ambulance to a local hospital in january 2010 because of palpitation and dyspnea that had worsened over the course of a week.
an echocardiographic examination revealed significant pericardial effusion with right ventricular diastolic collapse suggestive of cardiac tamponade.
he was then transferred to kurume university hospital for further evaluation and management.
the patient had an unremarkable medical history and no history of exposure to asbestos.
chest radiography revealed an enlargement of the cardiac silhouette and bilateral pleural effusion (fig.
1a).
electrocardiography demonstrated a sinus rhythm of 100 beats per minute and a low-voltage qrs complex.
computed tomography (ct) demonstrated pericardial and bilateral pleural effusion without any tumorous lesions on the pleura or pericardium, or in the lung (fig.
1b).
emergency pericardiocentesis was performed under echocardiographic guidance to achieve an improvement of his circulatory dynamics, and bloody pericardial effusion was drained (fig.
1c).
although a cytological examination revealed a tiny amount of atypical cells suggestive of malignancy, the information obtained was inadequate to make a definitive diagnosis (fig.
1d).
one week after pericardiocentesis, ultrasonography and chest radiography demonstrated a reaccumulation of the pericardial effusion.
surgical pericardial fenestration and pericardial biopsy were to create a window to the left thoracic cavity and thus make a histological diagnosis.
macroscopically, the parietal pericardium had become diffusely thickened measuring approximately 8 mm in thickness, while the visceral pericardium showed a thickness of approximately 5 mm (fig.
2a and b).
there were no nodular lesions in either the parietal and visceral pericardium.
furthermore, the pleural surface was smooth any without nodular lesions.
a histological examination of the resected pericardium specimen revealed spindle-shaped atypical cells with nucleoli among infiltrating lymphocytes (fig.
2c and d).
immunohistochemistry showed the atypical cells to be diffusely positive for cam5.2 and wt1, focally positive for calretinin, and negative for ttf-1 (fig.
2e and f).
although these findings suggested the possibility of malignant sarcomatoid mesothelioma, distinguishing the specimen from reactive mesothelial cells proved to be impossible.
after pericardial fenestration, no reaccumulation of pericardial effusion occurred, and the patient was closely followed up thereafter.
figure 1. a: chest radiography demonstrated an enlarged heart shadow and bilateral pleural effusion.
b: chest computed tomography revealed pericardial and pleural effusion.
c: an echocardiographic examination revealed significant pericardial effusion with right ventricular diastolic collapse.
d: cytological findings of pericardial effusion showed a small amount of atypical cells suggestive of malignancy.
figure 2. a, b: macroscopically, there is thickening of the pericardium and no nodular lesion of the parietal or visceral pericardium or pleura.
c, d: histologically, the resected pericardium specimen revealed spindle-shaped atypical cells with nucleoli among the infiltrating lymphocytes.
e, f: atypical cells were diffusely positive for cam5.2 and wt1.
chest radiography was performed in every two or three months for 21 months after discharge, there was no appearance of any tumorous lesion or effusion.
however, multiple pleural tumors which were absent at least before three months emerged in the left thoracic cavity in november 2011 (fig.
3a and b).
ct-guided biopsy of the pleural tumor was performed, and a histological examination demonstrated malignant cells in the form of spindle-shaped cells showing similar features to the tissue obtained by pericardium biopsy at the onset of cardiac tamponade (fig.
3c and d).
moreover, these malignant cells were immunohistochemically identical to the samples collected previously from the pericardium, showing positivity for calretinin, wt1, ae1/ae3, and cam5.2, and negativity for cea and ttf-1.
based on these findings, the final pathological diagnosis was sarcomatoid type primary pericardial malignant mesothelioma.
it was considered that these pleural tumors had likely resulted from the dissemination of pericardial mesothelioma cells due to pericardial fenestration of the left thoracic cavity.
figure 3. a, b: chest radiography and computed tomography demonstrated pleural tumors in the left thoracic cavity at 21 months after the onset of cardiac tamponade.
c, d: histological findings demonstrated the presence of malignant spindle-shaped cells.
the first-line systemic chemotherapy was a combination with cisplatin and pemetrexed every three weeks for four cycles, which resulted in a partial response, and then continued with maintenance pemetrexed monotherapy.
however, after 14 cycles of pemetrexed maintenance therapy the tumor appeared in the cardiac chamber, and therefore second-line chemotherapy with carboplatin and gemcitabine was conducted every three weeks for three cycles.
however, the disease progressed, and thereafter the patient received supportive care in the palliative care unit, and died in november 2013. discussion primary malignant pericardial mesothelioma is a highly unusual malignancy, with a reported prevalence of 0.0022% in an autopsy series (5).
pericardial mesothelioma can be categorized histologically as either epithelioid type, sarcomatoid type, biphasic type or desmoplastic type, as is the case for malignant pleural mesothelioma (6).
although pleural mesothelioma has been shown to be related to asbestos exposure, pericardial mesothelioma shows a less frequent association with asbestos (7).
several risk factors for pericardial mesothelioma have been reported, including infection with simian virus 40, a genetic predisposition, and prior radiation therapy (8).
our patient had no history of asbestos exposure, and no asbestos bodies were evident in tissue samples of the pericardium and pleural nodule.
furthermore, there was no evidence of any other risk factors, and therefore the pathogenesis of pericardial mesothelioma in this patient was unclear.
cardiac decompensation is the most frequent initial symptom of pericardial mesothelioma, and this is caused by pericardial effusion, cardiac tamponade or constrictive pericarditis.
pericardiocentesis or pericardial fenestration can be performed to alleviate the onset of heart failure, and a diagnosis can be made from specimens obtained in this way.
however, it is difficult to morphologically distinguish malignant mesothelioma from reactive mesothelial cells, and the antemortem diagnostic yield is reported to be only 20% (9).
although our patient also exhibited cardiac decompensation due to pericardial effusion and therefore underwent palliative pericardiocentesis and pericardial fenestration, we were unable to make a definitive diagnosis of mesothelioma at the time that cardiac tamponade appeared.
pleural dissemination was detected by a careful follow-up, thus allowing us to eventually make a diagnosis of malignant mesothelioma.
the prognosis of pericardial mesothelioma is very poor and no standard treatment guidelines have been established.
nilsson et al.
reviewed 30 cases of primary pericardial mesothelioma.
the median survival time from the first symptoms in the review was six months (10).
although resection may be curative in cases of localized disease, most cases are diagnosed at an advanced stage due to the lack of early symptoms.
systemic chemotherapy is performed in cases of advanced malignant pericardial mesothelioma as well as pleural mesothelioma (11).
among the histological subtypes of mesothelioma, the sarcomatoid type shows a poor response to chemotherapy, and it is thus associated with metastasis and a short survival (12).
the present case was unusual in that the patient had a relatively long progression-free period without treatment, and received chemotherapy with cisplatin and pemetrexed only after the disease had progressed.
the response was initially favorable, but this proved to only be a temporary phenomenon.
in conclusion, we herein described a rare case of sarcomatoid type primary malignant pericardial mesothelioma with a long-term survival after the onset of cardiac tamponade.
although pericardial mesothelioma is an uncommon malignancy, clinicians should include this possibility in the differential diagnosis when encountering patients with cryptogenic pericardial effusion.
the authors state that they have no conflict of interest (coi).
@highlight
primary pericardial malignant mesothelioma is a very rare clinical entity and its prognosis is very poor.
we herein report a 67-year-old man who presented with pericardial mesothelioma that was diagnosed 21 months after the onset of cardiac tamponade as the initial manifestation.
despite undergoing pericardiocentesis and surgical pericardial fenestration at the onset of cardiac tamponade, we were unable to make a conclusive diagnosis of mesothelioma based on the cytological and histological findings.
this unusual case had a relatively long progression-free period without treatment before the appearance of pleural tumors that showed the histological features of malignant sarcomatoid mesothelioma.
