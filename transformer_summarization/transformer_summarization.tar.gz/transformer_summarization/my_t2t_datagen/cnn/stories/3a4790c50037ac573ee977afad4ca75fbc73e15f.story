renal clear-cell carcinoma (rcc) is the most common type of kidney tumour in adults (85%) and accounts for 3% of all malignancies (ferlay et al, 2013; siegel et al, 2016).
surgery represents the gold standard for the treatment of clinically localised rcc (ljungberg et al, 2015).
although oncological outcomes (in tumours measuring <4 cm) are similar in radical nephrectomy (rn) and in nephron sparing surgery (nss), the incidence of long-term morbidity due to the development of chronic kidney disease (ckd) is higher in the case of rn due to the loss of nephron mass (capitanio et al, 2016).
chronic kidney disease affects quality of life and life expectancy and has important health-economic implications being associated with increased cardiovascular risk, metabolic syndromes and end-stage kidney disease (nashar and egan, 2014).
even though several mechanisms for the decay in renal function following rn have been hypothesised, no predictive markers are currently available to inform clinicians of the risk of developing ckd and to tailor surveillance and secondary prevention programs (capitanio et al, 2016).
micrornas (mirs) are short (19–24 nucleotides) non-protein coding rnas fine tuning cell homeostasis by controlling gene expression at post-transcriptional level (fabbri et al, 2009; winter et al, 2009).
mirs are implicated in renal physiology regulating ion transport, electrolytes and acid–base equilibrium, as well as blood pressure (elvira-matelot et al, 2010; mladinov et al, 2013; trionfini et al, 2015).
mirs deregulation is common to many cancers as well as infectious, cardiovascular, metabolic and kidney diseases and it can be exploited for screening, diagnosis and treatment (catto et al, 2011; mendell and olson, 2012; fasanaro et al, 2015; trionfini et al, 2015).
in the current study, we aimed to test mir deregulation in ‘normal' kidney tissue in patients with and without deterioration in renal function after rn for rcc, in order to define predictive biomarkers of ckd.
materials and methods study population one-hundred and five patients treated with rn for rcc at san raffaele hospital (milan, italy) between 2008 and 2013 were eligible for the study.
the project has been approved by the relevant ethic committee (approval 2007/29082007/v3) and informed consent is available for each patient.
the inclusion criteria of the study were: (a) age >18 and <80 years; (b) clear-cell carcinoma histology; (c) resectable rcc and absence of metastatic within the initial 12 months from diagnosis; (d) no history of other malignancies; (e) normal renal function prior to rn, estimated glomerular fraction rate (egfr)>60 ml min-1 (ckd-epi formula 2009 (eknoyan et al, 2013)), serum creatinine <1.1 mg dl-1 and no urinary abnormalities (i.e., proteinuria); (f) absence of primitive, secondary, hereditary or acquired glomerulopathies; (g) absence of kidney stone disease, myeloproliferative disorders and autoimmune diseases (i.e., vasculitis and systemic infections); (h) absence of chronic nephrotoxic drug therapy (e.g., lithium, nsaid).
all patients underwent postoperative review 1 month after rn and 6-month follow-up with physical examination, lab test and ct scan thereafter.
twelve renal biopsies (cortex only) from kidney donors (remuzzi score ⩽4 (remuzzi et al, 1999)) were collected from the archives of the surgical pathology unit at padua university (padua, italy) and used as controls (ethic committee approval #: 0011418–02/03/2015).
pathology review haematoxylin and eosin-stained slides from 100 formalin-fixed paraffin-embedded tissues were reviewed by a pathologist.
only samples >3 cm distance from rcc were considered.
renal cortex and medulla were manually micro-dissected in order to separate the glomerular region from the loop of henle and collecting ducts.
twenty cases were excluded due to inadequate representation of the cortex region (<10 glomeruli on × 10 field of view), because this might have impaired the yield of rna from the glomeruli.
total rna extraction was performed using ambion recover all isolation kit (life technologies, carlsbad, ca, usa), according to the manufacturer's instructions.
the purity and quality of extracted rna was determined by bio-analyser (agilent technologies, santa clara, ca, usa).
nine samples were discarded due to poor rna purity/quality.
nanostring ncounter and bioinformatics analysis mir expression was analysed using the ncounter human v2 mir expression assay kit (nanostring, seattle, wa, usa) as we previously described (valeri et al, 2014).
this assay detects 800 endogenous mirs, 5 housekeeping transcripts plus 6 positive and 6 negative controls.
about 150 ng of each total rna sample was used as input into the ncounter human mir sample preparation.
hybridisation was conducted for 16 h at 65 °c.
subsequently, the strip tubes were placed into the ncounter prep station for automated sample purification and subsequent reporter capture.
each sample was scanned for 555 fields of view on the ncounter digital analyzer (nanostring).
data were extracted using the ncounter rcc collector (nanostring).
two samples, one medulla from a patient with normal kidney function (nkf) and one cortex from a healthy kidney donor, failed quality control and were excluded from further analysis.
raw data, which are proportional to copy number, were log-transformed and normalised by the quantile method after application of a manufacturer-supplied correction factor for several mir (cascione et al, 2013).
data were filtered to exclude relatively invariant features (iqr=0.5) and features below the detection threshold (defined for each sample by a cutoff corresponding to ∼2 × s.d.
of negative control probes plus the mean of them) in at least half of the samples.
after the pre-processing steps described above, we plotted the relative differences in transcriptional profile between the samples using multidimensional scaling plot.
using r/bioconductor and the filtered data set, significance analysis of microarrays was employed with a contrast matrix for the comparisons (cascione et al, 2013).
p-values were used to rank mirs of interest, and correction for multiple comparisons was performed using the benjamini–hocheberg method (benjamini and hochberg, 1995).
raw data that were above background, as well as the corresponding quantile-normalised data, were imported into multiexperiment viewer (http://mev.tm4.org/) for visual inspection.
heatmaps were generated using the euclidean distance as metric distance and a single clustering as linkage criterion.
only mirs with a t-test p-value <0.1 were included in the heatmaps.
the colour red indicates strong expression of a mir, whereas a blue point mirrors a reduced level of a determined mir.
microrna expression data have been submitted to geo under accession number gse80247.
rt–pcr analysis expression of four of the most importantly dysregulated mirs detected using nanostring ncounter analysis (hsa-mir-193b-3p, hsa-mir-365a-3p, hsa-mir-363b-3p and hsa-mir-139b-5p) was investigated by rt–pcr using taqman assays (life technologies).
comparative rt–pcr was run in triplicate, including no template controls and endogenous control gene rnu48.
the fold difference for each sample was obtained using the δct method.
mir-193b in situ hybridisation analysis locked nucleic acid (lna) probes with complementarity to mir-193b-3p were labelled with 5′-biotin and synthesised using exiqon (vedbaek, denmark).
tissue sections were digested with ish protease 1 (ventana medical systems, milan, italy) and ish was performed as we previously described (nuovo et al, 2012).
positive (u6; exiqon) and negative scrambled lna probes (exiqon) were used as controls.
only cytoplasmic mir staining was retained for scoring purposes.
statistical analyses the end point of the study was the rate of de novo post-rn ckd defined as stage 3a-3b-4 calculated 12 months after surgery (eknoyan et al, 2013).
first, the mann–whitney test was used to compare the statistical significance of differences in the distribution of each mir of interest according to ckd.
second, multivariable logistic regression analysis (mva) was used to construct a baseline model predicting the ckd relying on clinical predictors only.
such predictors were factors suggestive for increased risk of post-surgical ckd, and consisted of age, gender, baseline egfr, clinical tumour size (defined as the largest tumour dimension at preoperative imaging) and presence of diabetes.
third, each mir of interest was independently added to the baseline model, and the concordance index of each mir-inclusive model was compared with that of the baseline model.
fourth, the net benefit of the baseline model and of each mir-inclusive model was assessed using decision curve analysis (vickers and elkin, 2006).
results baseline clinical characteristics and measure of clinical outcome of the originally collected one-hundred and five patients with histologically proven, rcc treated with curative rn, 71 patients were included in our study for clinical and molecular predictors of ckd (34 patients were excluded from the analysis and details are shown in figure 1).
patient characteristics are summarised in table 1. fourteen (20%) patients suffered from type ii diabetes control by oral hypoglycaemic agents at the time of diagnosis; no patients had type i diabetes (table 1).
histological review of resection specimen ruled out signs of pre-existing nephropathy in all these patients.
similarly, none of the patients showed biochemical signs of ckd with normal renal function in the absence of proteinuria.
physiological fluctuations in the egfr are common in the post-rn setting, relate to compensatory nephron hyperfiltration in the contralateral kidney and, usually, occur within the initial 6 months from the operation.
given that several lines of evidence suggest that a reduction in egfr at 12 months from rn is associated with increased risk of ckd (westland et al, 2014), our end point measurement was performed 12 months post rn.
thirty-eight (54%) patients experienced a reduction in egfr, developing a mild to severe ckd 12 months post rn.
(supplementary figure s1a and 1b).
identification of micrornas associated with ckd in the training cohort in order to define mirs discriminating patients who developed ckd at 12 months post rn and patients with nkf, we performed mir expression analysis in a randomly selected training cohort of 12 ckd and 12 nkf patients.
as ckd can be related to different abnormalities affecting the nephron, the cortex and medulla were dissected and tested for mir expression separately.
nine mirs were upregulated and one was downregulated >1.5-fold (p-value ⩽0.05) in the comparison between ckd and nkf patients (irrespective of the anatomic location) (supplementary table s1).
when the analysis compared the medulla of ckd and nkf patients, ten mirs were found to be overexpressed more than 1.5-fold in ckd patients.
no mir showed statistically significant downregulation >1.5-fold (figure 2 and supplementary table s2).
conversely, when the analysis focused on the cortex, two mirs were found to be upregulated and one mir was downregulated >1.5-fold in ckd patients (supplementary figure s2 and supplementary table s3).
shortlisting and validation of mirs found to be deregulated in ckd vs nkf patients for the validation of mirs associated with the development of ckd, we focused on mirs upregulated in the comparison between medulla of ckd vs nkf patients based on the following observations: (1) ckd is largely due to early tubular dysfunction, which promotes increased sodium reabsorption and glomerular hyperfiltration (capitanio et al, 2016); (2) the comparison between medulla of ckd vs nkf provided more significantly deregulated mirs than the comparison between cortex of the same patients; (3) overexpressed rather than silenced mirs might be easier to detect in tissues and biological fluids.
expression of the four mirs (mir-193b-3p, mir-365a-3p, mir-363b-3p and mir-139b-5p) deregulated in the medulla of ckd vs nkf patients detected in the training cohort by ncounter was confirmed in the same cohort (n=23) and validated in the remaining patients (n=47) by rt–pcr.
all four mirs were confirmed as significantly upregulated in the cortex of ckd patients (supplementary table s4).
clinical and molecular predictors of ckd in order to define clinical markers of ckd we performed a mva, which showed that gender (odds ratio (or) 6.07; p=0.02) and preoperative egfr (or 0.93; p=0.02) are independent predictors of ckd (base model (table 2)).
the area under the curve (auc) of the base model was 81%.
when each mir was included in the base model, each mir emerged as an independent predictor of ckd after adjustment for clinical variables.
specifically, mir-193b-3p (or 2.28; p=0.002), mir-363b-3p, (or 6.28; p=0.04), mir-139b-5p (or 5.86; p=0.01) and mir-365a-3p (or 2.18; p=0.01) were all associated with an increased risk of ckd.
moreover, after the inclusion of mir-193b-3p, mir363b-3p, mir139b-5p and mir365a-3p, the auc of the base model increased to 88%, 83%, 86% and 86%, respectively (table 2).
at decision curve analyses (dca), the inclusion of each mir into a baseline model predicting ckd using only clinical variables yielded a higher net benefit (figure 3).
in order to test whether the inclusion of multiple mirs to the basic model would yield higher predictive value, we selected model 1 (table 2) as our base model (clinical-pathological variables+mir-193b-3p) and we added mir-363b-3p, mir-139b-5p and mir-365a-3p expression individually.
none of these mirs increased the clinical and/or statistical power of the predictive model including mir-193b-3p alone (all p>0.05).
moreover, the inclusion of mir-363b, mir-139b and mir-365a in such model was associated with an auc of 0.88, 0.89 and 0.89, respectively, which do not differ from the auc of our original model 1 including clinical-pathological parameters+mir-193b expression (0.88).
on the basis of these observations, we focused our attention on mir-193b-3p alone for further analysis.
mir-193b-3p tissue of origin mir expression is organ and tissue dependent (lim et al, 2005).
in order to validate the observations gathered from ncounter and rt–pcr data and provide insights in the role of these mirs in ckd pathogenesis, we performed mir-193b-3p ish analysis in medulla and cortex tissues in samples characterised by high and low mir-193b-3p expression at ncounter and rt–pcr analysis in patients with high preoperative egfr.
in cases with low mir-193b-3p expression, faint mir-193b-3p staining was observed in the collector ducts (medulla), distal convoluted tubule and glomerular endothelial cells (cortex).
high-mir-193b-3p cases were characterised by strong mir expression in the inflammatory infiltrate and in fibroblasts present in both renal regions.
moreover, in keeping with the ncounter expression data, significant mir-193b-3p overexpression was observed in atrophic and swollen tubules and in ducts within the medulla (figure 4).
cancer can cause re-wiring of mir and gene expression in adjacent surrounding tissues (volinia et al, 2010).
in order to test whether mir-193b-3p expression changes in renal parenchyma were caused by the cancer, we compared global mir expression in patients who underwent rn for rcc with healthy kidney donors.
even though a global mir deregulation was observed in ‘normal' tissues surrounding cancer compared with healthy donors, mir-193b-3p was not among the deregulated mirs (supplementary figures s3 and s4 and supplementary table s5).
to support this observation, we also analysed mir-193b-3p expression in rcc patients in the cancer genome atlas (tcga (cancer genome atlas research n, 2013)) data set for whom cancer and matching normal mir-seq data were available.
comparison of cancer and adjacent tissues confirmed that mir-193b-3p is overexpressed by 40% (p<0.0001) in normal tissues adjacent to the cancer (supplementary figure s5).
discussion three quarters of patients affected by stage i–ii rcc will survive more than 5 years from the initial diagnosis (karakiewicz et al, 2007).
although several efforts to improve oncological outcome in early and metastatic rcc patients are ongoing, little has been done to reduce comorbidities and improve quality of life and outcome in cancer survivors.
the incidence of ckd is increasing worldwide and the association between rn and increased risk of ckd is well documented (mariusdottir et al, 2013), highlighting the unmet need for predictive biomarkers that might enable us to tailor patients' surveillance and treatment.
mir deregulation has been studied in rcc and diabetes-related kidney disorders (catto et al, 2011; trionfini et al, 2015), but no study has linked mir deregulation with the risk of developing ckd in rn patients.
our study led to two main conclusions: (1) the use of mir-193b-3p improves the predictive value of clinical nomograms in estimating the risk of ckd; (2) mir-193b-3p upregulation is associated with morphological features of inflammation, fibrosis and atrophy in patients with no preoperative clinical or biochemical evidence of kidney disease.
our data rely on the retrospective analysis of a limited cohort of patients, thus are not intended to change clinical practice.
however, while prospective validation studies are ongoing, questions and avenues of future research have arisen.
mir-193b-3p has been previously characterised as a regulator of transcription factors such as myb (mets et al, 2015), downstream effector of mapk (ikeda et al, 2012) pathway and regulator of cell steaminess (haetscher et al, 2015) in different tumour types including pancreatic cancers and leukaemia.
similarly, mir-193b-3p dysregulation has been detected in rheumatic disorders (iwamoto et al, 2016), pre-eclampsia (xu et al, 2014), as well as inflammation in white adipose tissues (arner et al, 2012) through the regulation of inflammatory chemokines.
in our cohort, mir-193b-3p overexpression is associated with inflammation and atrophy and can be detected in tubular, ductal and inflammatory cells suggesting crosstalk between different compartments in promoting inflammation and fibrosis.
a reasonable question is whether the cancer is promoting inflammatory changes and mir-193b-3p overexpression.
it is worth noticing that mir-193b-3p upregulation was independent of tumour and/or kidney size and no evidence of compression from the cancer was observed on histological review, excluding an indirect effect of malignancy in promoting an inflammatory/hypoxic reaction in the normal counterpart.
exosome transfer of mir has been widely studied in the interaction between tumour and its surrounding tissues (neviani and fabbri, 2015), thus it is legitimate to speculate that overexpression of mir-193b-3p in cancer could have driven the phenotype we observed.
some observations, however, argue against this theory, as the analysis of an independent cohort of rcc cases and matching controls included in the tcga data set revealed a downregulation of mir-193b-3p in cancer compared with normal tissues; an observation that fits with several reports suggesting a tumour suppressor role for mir-193b-3p (gastaldi et al, 2014; mets et al, 2015).
further evidence supporting this hypothesis is represented by the comparison of rcc-matched normal tissues vs healthy kidney donors.
even though a general re-wiring of mir expression, possibly due to the cancer microenvironment, was observed, mir-193b-3p was not found to be deregulated in this comparison, suggesting that its upregulation might be independent from cancer.
a mva for ckd suggested that basal egfr was an independent predictor of ckd; however, even patients with high basal egfr experienced a pathological reduction in glomerular filtration.
as suggested by ish analysis these patients showed early morphological signs of tubular-glomerular sclerosis associated with mir-193b-3p upregulation providing an explanation for the improved predictive value of the dca when both parameters were included.
similar to our observations, mir-193b-3p has been found to be upregulated in tissues and urine in patients with kidney interstitial fibrosis, tubular atrophy and acute kidney rejection, suggesting that this mir might be involved in pro-inflammatory feedback involving the interstitial compartment (wilflingseder et al, 2013; maluf et al, 2014).
the observation that mir-193b-3p upregulation appears independent from the cancer microenvironment and common to other inflammatory tubular-interstitial nephropathies led us to speculate that it might be indicative of a pre-existing, clinically and biochemically undetectable, disease potentially also affecting the contralateral kidney.
in this scenario, the acute loss of nephron mass caused by nephrectomy could trigger hyperfiltration mechanisms, which in the presence of tubular atrophy and fibrosis in the remaining kidney could irreversibly compromise the tubular-glomerular feedback.
under these circumstances, afferent arteriolar vasodilatation, increased renal perfusion and stress for the glomeruli might translate into ckd within 12 months from the operation.
an interesting consideration is whether mir-193b-3p might be combined with other mirs to form a signature and whether this would be more accurate in defining the prognosis of rn patients than mir-193b-3p alone.
we tested this hypothesis and we showed that including multiple mirs in the predictive model does not increase the performance of the model.
two potential explanations might justify this observation: (a) there is collinearity in mir-193b-3p and mir-363b-3p, mir-139b-5p and mir-365a-3p expression and as such there is no added predictive value in incorporating them together; (b) the number of events (patients with egfr derangement at 12 months post rn) in our study is too limited to pick up a difference in predictive value.
although the identification of mir-193b-3p targets is beyond the scope of our work, it is worth mentioning that several key features of ckd, such as inflammatory cell infiltration, tubular cell atrophy, mesangial cell hypertrophy and podocyte apoptosis, are linked to transforming growth factor-β (tgf-β) pathway activation (trionfini et al, 2015).
interestingly mir-193b-3p has been shown to target tgf-β2- and tgfbr3 3′-untranslated regions suggesting a potential modulation of the pathway (thiery, 2003; hou et al, 2015; zhou et al, 2016).
our data suggest that integrating mir-193b-3p expression with clinical variables leads to a highly sensitive predictive model for the determination of risk of comorbidities in patients undergoing rn for rcc.
validation of our findings in prospective cohorts of patients receiving rn and nss for kidney cancer is currently ongoing.
matched analysis of tissues, plasma and urine will test the robustness of this marker and its applicability to clinical practice.
@highlight
background: a significant proportion of patients undergoing radical nephrectomy (rn) for clear-cell renal cell carcinoma (rcc) develop chronic kidney disease (ckd) within a few years following surgery.
chronic kidney disease has important health, social and economic impact and no predictive biomarkers are currently available.
micrornas (mirs) are small non-coding rnas implicated in several pathological processes.
methods: primary objective of our study was to define mirs whose deregulation is predictive of ckd in patients treated with rn.
ribonucleic acid from formalin-fixed paraffin embedded renal parenchyma (cortex and medulla isolated separately) situated >3 cm from the matching rcc was tested for mir expression using ncounter nanostring technology in 71 consecutive patients treated with rn for rcc.
validation was performed by rt–pcr and in situ hybridisation.
end point was post-rn ckd measured 12 months post-operatively.
multivariable logistic regression and decision curve analysis were used to test the statistical and clinical impact of predictors of ckd.
results: the overexpression of mir-193b-3p was associated with high risk of developing ckd in patients undergoing rn for rcc and emerged as an independent predictor of ckd.
the addition of mir-193b-3p to a predictive model based on clinical variables (including sex and estimated glomerular filtration rate) increased the sensitivity of the predictive model from 81 to 88%.
in situ hybridisation showed that mir-193b-3p overexpression was associated with tubule-interstitial inflammation and fibrosis in patients with no clinical or biochemical evidence of pre-rn nephropathy.
conclusions: mir-193b-3p might represent a useful biomarker to tailor and implement surveillance strategies for patients at high risk of developing ckd following rn.
