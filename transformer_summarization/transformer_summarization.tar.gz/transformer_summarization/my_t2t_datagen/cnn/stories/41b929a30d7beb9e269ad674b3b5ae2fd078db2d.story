introduction oscillatory brain activities in gamma frequency band play an important role in selecting and integrating sensory-relevant information into a coherent perception (herrmann et al., 2004).
it has been reported that gamma band activation participates in pain perception.
the power of gamma oscillations increases after brief nociceptive laser stimulations in healthy human beings (gross et al., 2007; tiemann et al., 2010; schulz et al., 2011; zhang et al., 2012; hu et al., 2014; liu et al., 2015a,b) and in normal rats (wang et al., 2011), indicating that gamma oscillations are related to experimental acute pain lasting for milliseconds to seconds.
such gamma activity is focused on somatosensory cortex and positively correlated with the perceived pain intensity measured by the subjective rating of pain sensation on human beings (gross et al., 2007; zhang et al., 2012; hu et al., 2014; liu et al., 2015a) and with convert pain processing in patients with chronic disorders of consciousness (naro et al., 2016).
recent recordings from deep brain structures on human beings discovered that laser nociceptive stimulation on skin could induce gamma activation in brain regions like the parasylvian, the thalamus, right amygdala, and the hippocampus (liu et al., 2015a,b).
besides brief acute pain, gamma activity also participates in tonic ongoing pain which lasts for minutes.
recent studies found that human subjects had strong gamma activity when they received heat stimulation for 5 or 10 min (peng et al., 2014; schulz et al., 2015) and when they were under medium tonic muscle pain condition (li et al., 2016).
these gamma activity engaged the prefrontal cortex and the frontal-central areas, which are responsible for the emotional and cognitive components of pain, were positively correlated with subjective pain intensity (peng et al., 2014; schulz et al., 2015; li et al., 2016).
thus, gamma activity is considered to participate in experimental acute pain and tonic pain as well.
gamma oscillation was shown to participate in the abnormal working memory of chronic pain (cardoso-cruz et al., 2013); however, whether oscillatory gamma oscillations play a role in the pain perception in chronic pain is unknown and of great interest.
unlike acute and tonic pain, chronic pain is a pathological, ongoing, and long-lasting condition (merskey and bogduk, 1994), featured by its persistence and maintenance of pain.
chronic pain is a complex disease with enhanced and prolonged processing of pain-related sensory, emotion, and cognitive components (apkarian et al., 2011).
considering gamma activity participates in the sensory, emotional, and cognitive components of pain processing (gross et al., 2007; liu et al., 2015a; schulz et al., 2015), we hypothesize that gamma activity is also involved in chronic pain.
in the present study, we aimed to investigate oscillations at the gamma frequency band and its modulation in the development of chronic pain condition.
considering electrocorticogram (ecog) signals from rats could provide high level of signal to noise and facilitate longitudinal study, we measured ecog signals from rats with chronic inflammatory pain development, analyzed the oscillatory gamma activities, and correlated it with the hyperalgesia of chronic pain rats.
materials and methods animals thirteen adult male sprague-dawley rats (300–350 g) were provided by department of experimental animal sciences, peking university health science center.
animals were housed in individual cages (12-h light/12-h dark, room temperature around 22°c) with free access to food throughout the experiment.
all experimental procedures were approved by the animal care and use committee of peking university health science center and were in accordance with the guidelines of international association for the study of pain.
surgery for recording electrode implantation after rats were anesthetized with sodium pentobarbital (50 mg/kg, i.p.
), 14 electrodes made of stainless steel (tip diameter 1 mm, impedance 300–350 ω) were implanted epidurally.
the locations of the electrodes were determined according to the method by shaw et al.
(1999) and hu et al.
(2015) (figure 1a).
electrodes were then fixed to the skull with dental cement.
the surgery lasted for about 35 min and penicillin was injected (60,000 u, i.m.)
to prevent possible infections.
figure 1 eeg electrode locations and the thermal hyperalgesia in chronic inflammatory pain rats.
(a) sketch map of eeg electrode locations: electrodes 4 and 9 [anterior (a) 0.0 mm, lateral (l) ±4.5 mm]; electrodes 3 and 10 (a −3.0 mm, l ±4.5 mm); electrodes 6 and 7 (a +4.5 mm, l ±1.5 mm); electrodes 2, 5, 8, 11 (a ±1.5 mm, l ±1.5 mm); electrodes 1 and 12 (a −4.5 mm, l ±1.5 mm).
electrode 13 was set as a reference electrode and positioned 2 mm caudal to the lambda.
the ground electrode (gnd) was positioned 4 mm caudal to the lambda.
(b) the laser energy that elicited pain response in cfa rats was significantly lower than that in control rats from day 7 to day 28, indicating thermal hyperalgesia developed.
*p < 0.05; **p < 0.01; ***p < 0.001 compared with the ns control group.
in the following 3 days after surgery, rats were housed individually and allowed to habituate to the recording environment for 1 h every day.
chronic inflammatory pain model induced by monoarthritis chronic inflammatory pain model of monoarthritis was established by injection of complete freund's adjuvant (cfa) (butler et al., 1992).
in brief, the procedure was as follows: mycobacterium butyricum (60.0 mg), paraffin oil (6.0 ml, sigma-aldrich), nacl 0.9% (4 ml), and tween 80 (1 ml) were mixed and then autoclaved.
after the rat was anesthetized with sodium pentobarbital (50 mg/kg, i.p.
), the cfa mixture (50 μl) was injected into left tibio-tarsal joint cavity to establish monoarthritis chronic inflammatory pain model (cfa group).
rats in the control group were injected with an equal volume of 0.9 % nacl solution instead (ns group).
measurement of pain threshold and hyperalgesia we applied the nociceptive laser withdrawal test to evaluate the pain threshold and hyperalgesia of rats (kao and jaw, 2011; wang et al., 2011).
it estimates the intensity of pain based on the intensity of nociceptive stimuli which could induce the hindpaw withdrawal response.
prior to eeg recording, thermal pain threshold of rat was determined by an ascending series of laser beams (wavelength 10.6 μm, beam diameter 2.5 mm, pulse width 20 ms).
the stimulation interval was at least 40 s to avoid possible thermal sensitization.
the energy level that generated 4–5 hindpaw withdrawal responses out of six stimuli was chosen.
the higher energy level that elicited pain response indicated the lower hyperalgesia of a rat.
each stimulus was targeted at a slightly different position of the planta to avoid unnecessary injury or sensitization of the skin.
recording of spontaneous ecog seven days after implantation of the electrodes, ecog was recorded at four time points, including before cfa or ns injection as well as 7, 14, and 28 days after injection (denoted as d0, d7, d14, and d28, respectively).
the electrical signals from 13 electrodes were recorded through digital pre-amplifier using eeg/erp software (cognitrace erp, ant inc., the netherlands).
the rats were awake and walked freely in a plastic cage (40 × 40 × 30 cm3 in volume) with an apertured bottom (5 mm) without any stimulation during the recording.
prior to the spontaneous ecog recordings, rats were allowed to habituate the environment for about 5 min.
then, ecog was recorded for another 20 min.
all signals were referenced to the electrode located 2 mm caudal to the lambda.
data were recorded at a sampling frequency of 512 hz.
the behavior of the rat was video-taped simultaneously.
pre-processing of the eeg data pre-processing of the eeg data was performed using the matlab-based eeglab toolbox (http://sccn.ucsd.edu/eeglab/).
only when a rat was awake and quiet on video display (detected by a blinded experimenter), the spontaneous eeg data during this period was picked out and band-pass filter was set between 1.5 and 45 hz to remove the 50 hz line noise artifacts.
after removing environmental artifacts of large amplitude, the eeg signals were re-referenced to the averaged signal across all channels.
the length of final data segments was not significantly different between groups [f(1, 44) = 0.73, p > 0.05] and among different time points [f(3, 44) = 1.07, p > 0.05].
wavelet power spectrum for spontaneous eeg a continuous wavelet transform was used to decompose the eeg data.
in this approach, the wavelet coefficients were produced through the convolution of a parent wavelet function with the analyzed signal.
here, a morlet wavelet was applied with a wavelet central angle frequency of 8 hz as in our previous report (li et al., 2007).
based on the morlet wavelet transform, wavelet power of the eeg data at different frequencies was obtained and used to describe the variance of the data.
the wavelet power spectrum was used to obtain the power of oscillatory activity at gamma frequency band (30–45 hz) in the spontaneous eeg data.
the frequency resolution was 0.5 hz.
frequency band was defined as delta (1.5–4 hz), theta (4–8 hz), alpha (8–12 hz), beta 1 (12–20 hz), beta 2 (20–30 hz), and gamma (30–45 hz).
phase amplitude coupling phase amplitude coupling was estimated by the method described by canolty et al.
(2006), because this method can not only detect the presence of phase amplitude coupling, but also assess the intensity of the coupling (tort et al., 2010).
continuous 1-min eeg epoch was chosen for the analysis.
eeg signal was firstly filtered at frequencies from 2 to 20 hz and from 30 to 45 hz with step of 1 hz.
then, both the amplitude and the phase of the low frequency and high frequency were extracted by hilbert transformation.
a complex-valued signal was further constructed by combining the high frequency amplitude time series with the low frequency phase time series.
the modulation index was obtained by measuring the degree of asymmetry of the probability density function of the complex-valued signal.
comparing the modulation index of signal with that of 100 surrogated data generated by shifting the amplitude time series, the normalized modulation index was obtained.
statistical analysis we tested the assumptions of analysis of variance (anova) for all the variables, including levene's test for testing the homogeneity of variance, the shapiro-wilk for testing the normality and the mauchly's for testing sphericity.
since all variables met the normal distribution and sphericity which is the key variation assumptions for repeated anova, statistical analysis was performed using two-way mixed anova with recording time (day) as a repeated factor.
post hoc tests were performed using bonferroni correction.
p < 0.05 was considered as statistically significant.
for cross-frequency coupling, two-way anova was performed with channels and groups as variables.
results enhanced gamma activity in chronic inflammatory pain rats first, in order to test cfa rats developed hyperalgesia of chronic pain, pain intensity were compared between cfa rats and control rat.
as shown in figure 1b, pain intensity, the laser energy that elicited pain response, was significantly different between cfa rats and control rats [f(1, 11) = 18.25, p < 0.01], and there was significant interaction between groups and days [f(3, 33) = 9.65, p < 0.001].
the laser energy of cfa rats was significantly lower than that of control rats from day 7 (p < 0.05, bonferroni post hoc test) to day 28 (p < 0.001, bonferroni post hoc test), indicating a hyperalgesia in chronic pain rats.
next, we investigated whether the oscillatory activity changed dynamically during the development of chronic pain.
thus, the power spectrum of spontaneous ecog at each frequency was calculated for cfa rats at each time point.
the averaged power spectrum across all ecog recording channels showed that power at higher frequency became stronger during the development of chronic pain (figure 2a).
in order to explore which frequency band altered under chronic pain condition, the power at each frequency band was compared between two groups.
due to the spontaneous ecog signal, we failed to apply band separation method (magri et al., 2012) but applied the traditional frequency band-wise analysis alternatively.
so, as shown in figure 2b, it was found that gamma band activities in cfa rats were significantly higher, but activities at other frequency bands were not different between two groups.
the power at gamma frequency was significantly higher in the cfa group than that in the ns group [f(1, 11) = 4.90, p < 0.05], and the main effect of time showed that gamma power increased over time [f(3, 33) = 10.94, p < 0.005].
no interaction effect was observed [f(3, 33) = 1.77, p > 0.05].
the increased power at gamma frequency in cfa inflammatory pain rats occurred at day 28 after cfa injection (p < 0.05, bonferroni post hoc test).
these results indicated that gamma activity from the whole brain areas was enhanced in cfa rats.
figure 2 enhanced gamma power in chronic pain.
(a) power spectrum during the development of chronic pain.
(b) grand average power (mean ± sem) of each frequency band in cfa group and in ns control group at different days after cfa injection.
gamma band power was significantly higher at day 28 in the cfa chronic pain group compared with that in ns control group (*p < 0.05).
(c) gamma power over channels 3 and 10 was increased in the cfa chronic pain group (upper) compared with that in the ns group (below).
(d) negative correlation between gamma power over channels 3 and 10 and the hyperalgesia in chronic pain rats at d7, d14, and d28 after cfa injection (pearson γ = −0.45, p < 0.05).
furthermore, we calculated the spatial distribution of the gamma power over the electrodes to figure out the areas where the enhanced gamma activities located.
the topography of gamma-band power over the electrodes in two groups at each time point was calculated and plotted.
as shown in figure 2c, compared with the ns group, the cfa group showed increased gamma power in channels 3 and 10 at day 28 [f(1, 11) = 5.05, p < 0.05; p < 0.05, bonferroni post hoc test].
the main effect of time was significant [f(3, 33) = 15.66, p < 0.0001], indicating that gamma power increased gradually during the development of chronic inflammatory pain.
no interaction effect was observed [f(3, 33) = 0.97, p > 0.05].
gamma activity correlated with hyperalgesia to explore the potential function of enhanced gamma activity in chronic pain and to test whether gamma activity participates in hyperalgesia, gamma power averaged across recording channels was further correlated with hyperalgesia measured with the laser energy that elicited pain response.
data at d7, d14, and d28 from chronic pain rats were collected.
a significant negative correlation between gamma power and the laser energy was observed (pearson γ = −0.45, p < 0.05; figure 2d), indicating a correlation of stronger gamma power with lower laser energy, i.e., stronger gamma power, higher hyperalgesia.
enhanced coupling between the phase of theta and the amplitude of gamma in chronic inflammatory pain rats since gamma power is coupling with theta phase in acute pain (wang et al., 2011) and it is usually modulated by the phase of theta oscillation, we further tested whether theta phase modulates gamma activity in chronic inflammatory pain.
coupling between the amplitude of gamma and the phase of low frequency (2–20 hz) was calculated for each channel for both groups at day 28, and the difference value of cross-frequency coupling index averaged across channels between chronic pain and control was plotted.
figure 3a showed the gamma amplitude was coupling with the phase of oscillations mainly at the theta frequency band (4–8 hz).
then, we compared the theta-gamma phase amplitude coupling between chronic pain and control condition.
results showed that the phase-amplitude coupling between theta band and gamma band was significantly different between two groups [f(1, 11) = 4.02, p < 0.05; figure 3b], indicating that the theta phase significantly modulated the gamma power in chronic inflammatory pain.
figure 3 enhanced coupling between gamma amplitude and theta phase.
(a) difference of phase-amplitude coupling between chronic pain and control.
(b) gamma power had strong modulation index with theta phase in cfa chronic pain rats.
discussion in the present study, we found a significant increase of gamma oscillatory activity in rats with chronic inflammatory pain.
the enhanced gamma activity correlated with the hyperalgesia and had a coupling with the phase of theta oscillation.
enhanced gamma activity in rats with chronic inflammatory pain although there are several studies on gamma oscillations in experimental brief and tonic pain in healthy human beings and in normal rats (croft et al., 2002; gross et al., 2007; wang et al., 2011; hu et al., 2014; liu et al., 2015b,a; schulz et al., 2015; li et al., 2016), as well as convert pain in patients with chronic disorders of consciousness (naro et al., 2016), knowledge about the spontaneous and task-free gamma oscillatory activity in pathological, long-lasting chronic pain state are still in expectation.
our present study found that ecog gamma activity increased under chronic inflammatory pain condition in a cfa monoarthritis model of rats.
this cfa model mimics the whole processes from acute stage to chronic stage of inflammatory pain (butler et al., 1992).
results showed that gamma power gradually reached a significantly high level at the chronic pain states.
these findings suggested that the enhanced gamma oscillatory activity was related to long-lasting pain condition, and extended our understanding of gamma activity from physiological pain to pathological pain conditions.
we found that gamma activity under chronic inflammatory pain condition enhanced over two electrodes over bilateral brain regions.
the location of these electrodes was at 3.0 mm posterior and ±4.5 mm lateral to the bregma.
according to the atlas of rat brain (george paxinos, 2004), these areas are the location of primary somatosensory cortices.
primary somatosensory cortex encodes the sensory component of pain.
this is in line with previous studies that brief painful stimuli evoked gamma activity in the primary somatosensory cortex of human beings (gross et al., 2007).
the gamma activity induced by brief noxious stimulus was observed in the contralateral somatosensory cortex as measured by magnetoencephalography (meg) and local filed potentials from human beings.
unlike gamma activity induced by brief pain, the gamma activity in our chronic pain model increased in bilateral brain.
because the channel location of ecog is less accurate than the source location of meg and the local field potentials, increased activity in bilateral brain areas cannot rule out the contribution from activities of other brain regions which exhibited bilateral activation during chronic pain (hashmi et al., 2013).
increased gamma activity may result from the increased gabaergic activity.
it is known that neurotransmitter gaba is critical for the generation of gamma oscillation and thus the gamma activity depends on gaba activity (barr et al., 2013).
a recent study showed increased gaba concentrations in inflammatory pain rats (amirmohseni et al., 2016).
so, the increased gamma activity in chronic inflammatory pain was consistent with the increased gaba concentration.
correlation of gamma oscillation with hyperalgesia correlation analysis showed that gamma power was positively correlated to hyperalgesia of chronic pain (figure 3).
previous studies demonstrated that gamma oscillatory activity encoded acute or tonic subjective pain intensity on human beings (gross et al., 2007; wang et al., 2011; peng et al., 2014; tiemann et al., 2015), our current study on cfa pain rats extended the explanation of this correlation of gamma power with pain intensity under chronic inflammatory pain condition.
first, the measurement of pain intensity was different.
in the studies on brief or tonic pain, pain intensity was evaluated by subjective rating induced by painful stimulus.
it reflected the intensity of pain perception to painful stimulus.
in our chronic pain conditions, pain intensity was measured by the laser energy that could elicit pain response.
it reflected the pain sensitivity or the intensity of hyperalgesia and allodynia of rats but not perception of a single stimulus.
second, the eeg recording and analysis were different.
in brief or acute pain conditions, eeg was recorded with external stimulation to estimate stimulus-induced gamma activity.
in our present study, ongoing eeg was used to estimate the brain activities in resting state in chronic pain conditions.
therefore, our observations likely indicated that the activity of neural gamma oscillations at resting state correlated to hyperalgesia and severity of chronic pain.
indeed, a recent research which showed that the pre-stimulus spontaneous gamma oscillations predict the subsequent pain perception was consistent with our findings (tu et al., 2016).
it should be noted that except the brain activities in resting state, ongoing eeg signals may contain activities related to inflammatory ongoing pain.
however, a recent research reported that the ongoing pain was transient in rats with chronic inflammatory pain, appearing at 24 h after inflammation induction but disappearing at 4 days (okun et al., 2011).
accordingly, our ecog signals from d7, d14, and d28 hardly reflect the ongoing pain, and it was also the reason that we did not measure the ongoing pain behavior and correlated with gamma oscillation.
cross-frequency coupling between gamma amplitude and theta phase it is known that gamma frequency activities generate from the recurrent inhibitory–excitatory neural network.
in the cortical network, this local gamma network receives inputs from thalamic inputs and other brain areas.
these inputs exhibits phase variations in the low frequency range (mazzoni et al., 2010, 2011).
cross frequency coupling between phase of low frequency and gamma power reflects the modulation of sensory and other inputs to local neural networks (mazzoni et al., 2010, 2011).
thus, the enhanced cross-frequency coupling in chronic pain suggested that modulation from thalamic and other areas to primary sensory cortices is increased in chronic pain.
this is supported by clinic findings that the theta frequency from the thalamic nuclei is increased in chronic pain (stern et al., 2006) and is consistent with idea that connectivity of brain network serving in pain is increased in chronic pain conditions (baliki et al., 2014).
limitations our study is interesting but preliminary.
there are several factors need to be considered.
first, the rat model of chronic pain cannot fully represent chronic pain patients.
however, ecog of rats could prevent the contamination of muscle activity which is usually accompanied by pain and allow chronic recordings along the development of chronic pain.
second, ecogs were recorded at resting state for several minutes to reflect the brain state under chronic pain condition.
but, it is unavailable for accurate estimation of the function of gamma activities in the present study, because there is no specific event-related information in the ongoing eeg signals.
third, due to limited channels of rat ecog, source location of gamma activity and cross-frequency coupling are hard to be estimated.
besides, small sample size is a weak point because of long time recordings.
nevertheless, our results provide first evidence for the enhanced gamma activity in chronic pain conditions even without external painful stimulation.
our results demonstrate that the gamma power is enhanced in chronic inflammatory pain and correlated with hyperalgesia.
it extends our understanding about gamma activity in pain that gamma power serves as a possible biomarker of severity of chronic pain.
author contributions jw (the first author) carried out the ecog recording and data analysis, participated in the study design and drafted the manuscript.
jw (the second author) carried out the ecog recording and the preprocessing of data.
gx participated in the design of the study.
xl carried out the data analysis and helped to draft the manuscript.
yw conceived of the study, and participated in its design and helped to draft the manuscript.
all authors read and approved the final manuscript.
conflict of interest statement the authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.
@highlight
it has been reported that oscillatory gamma activity participates in brief acute pain and tonic ongoing pain.
it is of great interest to determine whether the gamma activity is involved in chronic pain since chronic pain is a more severe pathological condition characterized by pain persistency.
to investigate the oscillatory gamma activity in chronic pain, in the present study, we recorded spontaneous electrocorticogram (ecog) signals during chronic pain development in rats with chronic inflammatory pain induced by monoarthritis.
power spectrum analysis of ecog data showed that gamma power increased significantly at the late stage of chronic inflammatory pain.
the increased gamma activity occurred mainly at electrodes over primary somatosensory cortices.
in rats with chronic pain, the gamma power was positively correlated with the hyperalgesia measured by laser energy that elicited hindpaw withdrawal response.
furthermore, an increased coupling between the amplitude of gamma power and the phase of theta oscillations was observed in chronic inflammatory pain condition.
these results indicate an enhanced spontaneous gamma activity in chronic pain and suggest a potential biomarker for the severity of chronic pain.
