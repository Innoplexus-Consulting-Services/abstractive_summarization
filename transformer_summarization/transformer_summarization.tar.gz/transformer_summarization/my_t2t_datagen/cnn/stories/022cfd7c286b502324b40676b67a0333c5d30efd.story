group b streptococcus (gbs) is a major cause of invasive infections in neonates.
gbs also causes invasive disease in adults, with incidence rates that have been increasing in north america, particularly among the elderly (1).
a serologic reaction directed against the polysaccharide capsule permits the classification of gbs into 10 serotypes: ia, ib, and ii–ix (2).
serotype v strains are most frequently associated with invasive infections in adults in north america (3,4).
multilocus sequence typing (mlst) permits differentiation of gbs strains into >700 sequence types (sts), which are grouped into a few clonal complexes (ccs) (5).
a recent study found that 92% of serotype v gbs strains recovered from the blood of nonpregnant adults in houston, texas, usa, and toronto, ontario, canada, belonged to st1 (4).
homologous recombination occurs frequently in gbs and can involve vast areas of the genome in some lineages (6,7).
recombination leading to capsular switching has been reported numerous times in gbs (3,6,8).
capsular switching might result from a single recombination event that replaces the cps locus encoding the capsular biosynthetic machinery, leaving the rest of the genome unchanged.
however, it is also possible that receiving strains acquire a donor cps locus and additional genetic material from the same or other donor strain(s).
because multiple recombination events can endow the receiving gbs strain with an enhanced virulence arsenal, obtaining information about additional genome changes is important.
the study we investigated 111 st1 gbs isolates collected by the toronto invasive bacterial diseases network during 2009–2015.
this network is a population-based surveillance system for invasive bacterial diseases in metropolitan toronto and peel region, ontario, canada (total population under surveillance ≈5.5 million) that includes all hospitals (n = 28) providing care to and all laboratories (n = 25) processing sterile site cultures from residents of the population area.
mlst and serotyping were performed as previously described (4,5,9).
most (103) of these st1 strains were serotype v, but 8 st1 isolates were found to be serotype ib, ii, iv, vi, vii, or viii (table).
these 8 strains represent an opportunity to investigate in more detail the molecular underpinnings of capsular switching in gbs.
to this end, we sequenced the genomes of all 8 strains.
we extracted genomic dna by using the qiagen dna minikit (qiagen, toronto, ontario, canada) and prepared genomic libraries by using nextera xt kits (illumina, san diego, ca, usa).
we sequenced libraries as paired-end reads with illumina hiseq (101 bp + 101 bp) or miseq (150 bp + 150 bp) instruments and deposited whole-genome sequencing data in the sequence read archive of the national center for biotechnology information (table).
table characteristics of 8 non–serotype v sequence type 1 group b streptococcus isolates collected by the toronto invasive bacterial diseases network, ontario, canada, 2009–2015* strain name serotype year isolated age group of patient source sra accession no.
ngbs217 ib 2011 0–6 d blood srr3030375 ngbs748 ii 2010 7–89 d blood srr3030378 ngbs814 ii 2011 >60 y blood srr3030379 ngbs1098 iv 2012 7–89 d blood srr3030380 ngbs209 vi 2011 >60 y blood srr3030374 ngbs537 vi 2012 19–59 y blood srr3030376 ngbs015 vii 2009 >60 y blood srr3030373 ngbs621 viii 2012 19–59 y blood srr3030377 *sequence types as determined by multilocus sequence typing.
sra, sequence read archive.
we next performed de novo genome assemblies using the a5 pipeline (10) and assessed the cps loci of the 8 strains.
in all cases, blastn (http://blast.ncbi.nlm.nih.gov) comparisons identified the cps locus expected for the serotype identified by latex agglutination.
to characterize recombination leading to capsular switching, we first used the variant ascertainment algorithm vaal (11) to identify polymorphisms in each strain relative to the genome of serotype v st1 strain ss1 (genbank accession no.
cp010867).
the number of polymorphisms identified varied greatly between strains of the different serotypes.
strains of serotypes ib, ii, and iv had a relatively small number of polymorphisms, including single-nucleotide polymorphisms and small insertion/deletions, relative to the serotype v st1 reference.
the serotype ib strain had 1,437 polymorphisms, the 2 serotype ii strains had 1,115 and 816, respectively, whereas the serotype iv strain had 256. however, strains of the other 3 serotypes had a substantially higher number of polymorphisms relative to the genome of the serotype v st1 strain ss1.
the 2 serotype vi strains had 12,703 and 9,406 polymorphisms, respectively, the serotype vii strain had 4,117, and the serotype viii strain had 3,471. by using custom scripts and the r software environment (https://www.r-project.org), we created plots of polymorphism distribution relative to the genome of the reference strain with a sliding window of 5 kbp.
we observed a nonrandom polymorphism distribution in all 8 strains (technical appendix).
we next plotted the polymorphisms identified in the strains against the genome of serotype v reference strain ss1 by using brig (12) and assessed recombination by using bratnextgen (run with 20 iterations and 100 replicates at p = 0.05) (13).
the analysis showed that serotype ib, ii, and iv strains had a genome background similar to the st1 serotype v reference strain but that each had experienced horizontal transfer of genome sequences of differing sizes, all of which included the cps locus.
namely, serotype ib strain ngbs217 had exchanged a dna region of ≈200 kb and acquired a cpsib locus (figure, panel a).
serotype ii strains ngbs814 and ngbs748 had exchanged dna regions of ≈189 kb and ≈152 kb, respectively, and gained a cpsii locus (figure, panel b).
recombination in the serotype iv strain ngbs1098 was less extensive (≈79 kb) but resulted in acquisition of a cpsiv locus (figure, panel c).
thus, in strains of these 3 serotypes, capsular switching most likely resulted from a single recombination event that replaced the original cpsv locus of the receiving strains with those of the donor strains but left the rest of the genome of the receiving strains unchanged.
we speculate that these recombination events most likely occurred by conjugation and that dna exchange took place in the human gut or urogenital tract.
these body sites can be colonized by multiserotype gbs populations (14).
figure extent of recombination among 8 non–serotype v sequence type (st) 1 group b streptococcus isolates collected by the toronto invasive bacterial diseases network, ontario, canada, 2009–2015.
a) serotype ib strain ngbs217.
b) serotype ii strains ngbs748 and ngbs814.
c) serotype iv strain ngbs1098.
d) serotype vi strains ngbs209 and ngbs537.
e) serotype vii strain ngbs015.
f) serotype viii strain ngbs621.
polymorphisms identified in non–serotype v st1 strains (illustrated in different colors, with each line representing a polymorphism) are plotted against the genome sequence of reference serotype v st1 strain ss1 (innermost circle).
the cps locus is shown in gold in the outermost circle.
genome landmarks, such as genes used in the multilocus sequence typing scheme (adhp, atr, tkt, glck, sdha, glna, and phes) are shown in light blue.
mobile genetic elements of strain ss1 are depicted in black.
polymorphisms mapping to mobile genetic elements identified in the various non–serotype v st1 strains were not included in the analysis.
st1, sequence type 1. in contrast with those results, the genomes of strains of serotypes vi, vii, and viii differed extensively from the reference serotype v strain.
indeed, recombination detected by bratnextgen involved >50% of the genomes of these isolates, even though they were found to be st1 by mlst (figure, panels d–f).
based on the available data, it is difficult to ascertain if those strains were originally st1 strains that acquired a cps locus and many other genomic regions by recombination in apparently multiple recombination events or, alternatively, if the isolates under investigation originally possessed the cps locus corresponding to their serotype and acquired by recombination from unknown st1 donors the different portions of the genome that contain all genes used in the mlst scheme.
in the latter scenario, and in particular for serotype vi strains, the increased number of polymorphisms in st1-like areas of the genome suggests that the putative st1 donor was genetically not closely related to the serotype v st1 reference strain ss1.
conclusions our data suggest that extensive recombination might be a key contributor to clonal diversification and emergence of gbs serotypes vi, vii, and viii, which are less often identified in north america but have substantial regional dominance in other geographic areas (15).
mlst is a useful approach to begin to examine the genetic relationships of gbs strains.
in some cases, particularly when temporally and geographically related isolates are evaluated, this approach also permits initial prediction of recombination events (3,5–8).
whole-genome sequencing extends mlst capabilities and enables precise identification and characterization of genetic variation attributable to extensive recombination in this opportunistic pathogen.
although the polysaccharide-based, trivalent conjugate gbs vaccine under development offers great promise, frequent capsular switching suggests that subunit vaccines based on antigens expressed by all gbs serotypes might offer enhanced protection.
technical appendix results of a sliding-window analysis of the distribution of single-nucleotide polymorphisms identified in the genomes of 8 non–serotype v sequence type 1 group b streptococcus isolates collected by the toronto invasive bacterial diseases network, 2009–2015, relative to the genome of serotype v sequence type 1 reference strain ss1.
@highlight
we report several cases of recombination events leading to capsular switching among sequence type (st) 1 group b streptococcus strains.
these strains otherwise shared a common genome backbone with serotype v st1 strains.
however, the genomes of st1 serotype v strains and those of serotypes vi, vii, and viii strains differed substantially.
