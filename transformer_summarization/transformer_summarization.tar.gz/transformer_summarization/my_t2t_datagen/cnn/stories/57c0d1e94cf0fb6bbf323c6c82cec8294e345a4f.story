introduction β -galactosidase (e.c 3.2.1.23), so called β-gal, is an important enzyme used in dairy industry and found abundantly in biological systems and microorganisms[1].
β-gal hydrolyzes the lactose (milk sugar) to its components, galactose and glucose.
the enzyme is used for the improvement of milk and its derivatives for consumption by people with lactose intolerance, for prevention of lactose crystallization in frozen and condensed milk products and also for the increase of the sweetening properties of lactose[2,3].
since a large number of people in different countries of the world[4] suffer from lactose intolerance, this matter makes the enzyme even more important.
in addition to health area, difficulties with lactose falls within two other main fields: food technology and environment[5].
from the food technology point of view, β-gal catalyzes transgalactosylation reaction, and lactose serves as a galactosyl donor and an acceptor to form di-, tri- or higher galactooligosaccharides[6,7].
galactooligosaccharides are now considered as a probiotic food ingredient and have been demonstrated to promote the growth and the establishment of bifidobacteria in intestine[8,9], thus exerting a beneficial effect on the human host[10].
until now, numerous studies concerning the production of galactooligosaccharides have been reported[11-15].
it has been indicated that galactooligosaccharides production from lactose is quite different in the final products and yields depending on the source of β-gal[15].
lactose is associated with the high biochemical and chemical oxygen demand (bod and cod) content of whey.
β-gal is used commercially in lactose hydrolysis[16], which is an important application of this enzyme in food industry.
β-gal is found in nature and is able to release a wide range of compounds.
the filamentous fungus aspergillus niger is capable of producing different extracellular enzymes and has previously been used by various researchers for enzyme production[17-19].
in the present study, we have tried to establish optimal conditions for the highest production of β-gal by a. niger atcc 9142 using indigenous and inexpensive wastes under solid-state fermentation (ssf) conditions with the assist of statistical experimental designs.
materials and methods strain and culture media a. niger atcc 9142 was obtained from iranian research organization for science and technology (irost).
materials used in this study were obtained from merck co., germany.
culture conditions and fermentation process for preparation of pre-culture, one loop of fungal spores from slant tubes of potato dextrose agar medium was inoculated in a pre-culture medium plate, and the plate was kept at 30°c for 48 h. the pre-culture medium consisted of a potato dextrose agar enriched by 1 g/l yeast extract and 1 g/l glucose.
in fact, yeast extract and glucose were implemented as the supplementation of nitrogen and carbon sources to improve the growth of fungi.
rice and wheat straw with different percentages of peanut pod were used as solid substrates for ssf.
mixed substrates (10 g) transferred to 500-ml erlenmeyer flasks was moistened with the mineral medium [2.0 g (nh4)2so4, 5.0 g kh2po4 and 0.4 g mgso4.7h2o per liter] to reach the final moisture content of 70% (w/v).
after sterilization, the flasks were inoculated with pre-culture under sterile conditions.
the flasks were then incubated at 30±1ºc.
after the incubation period of fermentation, extraction of the enzyme was carried out, and the supernatant was used for analytical assays.
experimental design and analytical methods the taguchi method applies fractional factorial experimental designs, called orthogonal arrays, to reduce the number of experiments while obtaining statistically meaningful and worthwhile results.
the selection of a suitable orthogonal array depends on the number of control parameters and their levels.
an experimental l16 array from the taguchi method was applied for the optimization of the enzyme production[5].
five factors were selected: peanut pod (0, 30, 70 and 95% w/w), carbon/nitrogen (c/n) ratio (0.1, 1, 2 and 3% w/v), incubation time (69, 120, 144 and 168 h), type of solid substrate (wheat straw and rice straw) and lactose concentration (0 and 5% w/v).
inner arrays employed to assign the considered factors are shown in table 1. for each experimental trial of the independent variables in the experimental design, the dependent parameter (enzyme production) was determined.
the enzyme activity is shown in table 2. a fractional factorial design with 16 different choice sets was used.
three factors at 4 levels and 2 factors at 2 levels were also examined.
normally, in the classical combination method using full factorial experimentation would require 43×22=256 experiments to capture the effective parameters[5].
analysis of variance (anova) was generated, and the effect of terms was determined (table 3).
the significance of all terms was judged statistically by computing the p<0.05.
the data analyses and optimization process were generated using minitab statistical software version 15[5].
table 1 assignment of experimental factors in taguchi’s optimization method experiment number c1 c2 c3 c4 c5 a b c d e 1 1 1 1 1 1 2 1 2 2 1 1 3 1 3 3 2 2 4 1 4 4 2 2 5 2 1 2 2 2 6 2 2 1 2 2 7 2 3 4 1 1 8 2 4 3 1 1 9 3 1 3 1 2 10 3 2 4 1 2 11 3 3 1 2 1 12 3 4 2 2 1 13 4 1 4 2 1 14 4 2 3 2 1 15 4 3 2 1 2 16 4 4 1 1 2 c, column; a, peanut pod; b, c/n ratio; c, incubation time; d, solid substrate; e, lactose table 2 experimental l16 orthogonal array and results of the β-galactosidase activity experiment number factor levels enzyme activity (u/mg) peanut pod c/n ratio incubation time solid substrate lactose concentration 1 0 0.1 96 ws 0 8809 2 0 1.0 120 ws 0 3942 3 0 2.0 144 rs 5 2689 4 0 3.0 168 rs 5 82 5 30 0.1 120 rs 5 3613 6 30 1.0 96 rs 5 451 7 30 2.0 168 ws 0 4353 8 30 3.0 144 ws 0 4681 9 70 0.1 144 ws 5 3757 10 70 1.0 168 ws 5 2587 11 70 2.0 96 rs 0 4209 12 70 3.0 120 rs 0 1909 13 95 0.1 168 rs 0 1498 14 95 1.0 144 rs 0 2915 15 95 2.0 120 ws 5 1067 16 95 3.0 96 ws 5 164 ws, wheat straw; rs, rice straw table 3 analysis of variance (anova) of the regression parameters for the taguchi method source df seq.
ss adj.
ss adj.
ms f value p value peanut pod 3 13897678 13897678 4632559 2.14 0.238 c/n 3 15836903 15836903 5278968 2.43 0.205 time (day) 3 5451074 5451074 1817025 0.84 0.539 solid state 1 8655364 8655364 8655364 3.99 0.116 lactose 1 19536400 19536400 19536400 9.01 0.040 residual error 4 8675465 8675465 2168866 total 15 72052884 df, the degrees of freedom; seq.
ss, sequential sums of squares; adj.
ss, adjusted sums of squares; adj.
ms, adjusted mean square enzyme assay the crude enzyme solution was diluted to a final volume of 0.5 ml with 0.1 m potassium phosphate buffer (ph 7.0) and then was added to 0.5 ml of 6 mm ortho-nitrophenyl-β-d-galactopyranoside in the same buffer.
the reaction mixture was incubated at 30°c for 20 min.
the reaction was ended by adding 2 ml 0.1 m na2co3.
β-gal assay was carried out spectrophotometrically.
the enzyme activity was determined according to the slope of a standard calibration curve of ortho-nitrophenol (fig.
1).
the favorable regression of equation is indicative the accuracy of calculations and measurements.
the concentration of ortho-nitrophenol released from ortho-nitrophenyl-β-d-galactopyranoside was determined by measuring the absorbance at 420 nm.
the enzyme activity was expressed as specific activity (u/mg), and one unit of β-gal activity (u) was defined as the amount of enzyme that liberates 1 µmol of ortho-nitrophenol per minute.
fig 1 standard calibration curve of o-nitrophenol (onp) results the influence of various solid-state substrates i.e.
peanut pod, wheat straw and rice straw on the production of β-gal by a. niger atcc 9142 are shown in figures 2a-2c.
the solid substrates screening showed that the wheat straw was the most suitable substrate for the production of the enzyme.
furthermore, the effects of different c/n ratios, the incubation time and different concentrations of lactose (as inducer) on the enzyme activity are indicated in figures 2d-f. fig 2 effect of (a) peanut pod, (b) wheat straw, (c) rice straw, (d) carbon/nitrogen ratio, (e) incubation time, (f) lactose (as inducer) on the enzyme activity.
considering the various applied c/n ratios, the maximum enzyme production yield was found to be at 0.2% (w/v) (fig.
2d).
the optimum incubation time for enzyme activity in the crude extract was 144 h (fig.
2e).
the effect of different concentration of lactose (0 and 5% w/v), as an inducer, on the β-gal production was also studied.
the results showed that the addition of lactose to the basal medium did not have any significant impact on the enzyme production (fig.
2f).
the enzyme activity exposed to different carbohydrates and mixed substrates ratios is demonstrated in figures 3 and 4. as shown in figure 3, glucose (0.1-%w/v) had the highest effect on the induction of β-gal.
fig.
3 the effect of different carbohydrates on the induction of β-galactosidase in a. niger.
lac, lactose; glu, glocuse fig.
4 enzyme activity of β-galactosidase using mixed substrates (a) peanut pod (pp) with rice straw (rs), (b) peanut pod with wheat straw (ws).
the combination of rice straw and peanut pod led to an increasing in β-gal activity (approximately two-fold), as compared to the use of rice straw individually (fig.
4a).
however, for enzyme production, the use of wheat straw alone was more suitable than its combination with peanut pod (fig.
4b).
the closer of r2 value to unity, the better the empirical models fits the actual data[20].
by the analysis of variance, the r2 value of this model was determined to be 0.879. therefore, the developed model could adequately represent the real relationship among the parameters chosen (fig.
5).
fig.5 relationship between the calculated yield of β-galactosidase and experimental data.
cal, calculated; expt., experimental the experimental conditions for each run are included in table 1. the orthogonal array designs of experimental parameters and the enzyme activity for each trail are shown in table 2. as it is shown in table 3, the analysis of variance (anova) of the regression parameters for the taguchi experimental design was evaluated.
response table for means is shown for parameters in table 4. table 4 response table for means level peanut pod c/n time (day) solid state lactose 1 3937 4419 3408 3670 4040 2 3275 2474 2633 2199 1830 3 3116 3136 3567 4 1411 1709 2130 delta 2526 2710 1437 1471 2210 rank 2 1 5 4 3 discussion β-gal is one of the most important enzymes used in food processing and offers nutritional, technological and environmental applications.
in the present study, the production of β-gal by ssf was measured and affected by a variety of physicochemical factors.
the results indicated that all solid-state substrates could be used as suitable and low-cost substrates for β-gal production.
the solid substrate screening showed that wheat straw was the most appropriate substrate for the growth of a. niger atcc 9142. the highest β-gal activity was obtained at 8809 u/mg using wheat straw.
nizamuddin et al.
[21] reported that wheat bran and rice husk support the maximal growth and β-gal production by a. oryzae.
we found that the combination of 30% (w/w) rice straw with 70% (w/w) peanut pod led to ca.
two-fold increase in supernatant β-gal activity (fig.
4a).
however, the combination of peanut pod and wheat straw resulted in dry culture, subsequent decrease in microbial growth and lower production level of β-gal.
the substrate level or water content is a critical factor in ssf.
therefore, an increase in substrate concentration or a decrease in water level leads to reduced solubility and minimizes heat exchange, oxygen transfer and low availability of nutrients to the culture, which affects microbial activity and results in decreased productivity[5].
the results of this study are useful to demonstrate the importance of solid-state fermentation for the production of β-gal using cost-free or low-cost agricultural by-products, which can be used as substrate(s).
the solid substrates used in this study offer significant benefits due to cheaper cost and abundant availability and the potential for production of high levels of enzyme.
low and high amounts of carbohydrates can reduce yield of production[22].
a suitable concentration of carbohydrates raises the efficiency of production.
hence, investigations have been carried out to reveal the effect of various concentrations of glucose and yeast extract (0.1-3% [w/v]), as c/n sources, on the enzyme activity.
glucose and yeast extract were used as c/n sources, respectively.
numerous investigators have reported the carbon source regulation of β-gal biosynthesis in various microorganisms[23-28].
all of these studies have indicated that the role of carbon source in the biosynthesis of β-gal may vary and depend on the microorganisms used.
siddique et al.
[29] have enhanced the production of β-gal using five organic nitrogen i.e.
ammonium sulfate, corn steep liquor, diammonium phosphate, fish meal and urea with wheat bran, as a substrate, under ssf by a. niger.
the highest level of β-gal activity was produced with corn steep liquor.
however, the effectiveness of the supplementation of these nutrients for the production of β-gal has not been studied to a great extent.
supplementation of nitrogenous sources especially yeast extract increases the amount of nutrients available to the bacteria, which could explain why there was an increase in the viable population of the organisms.
this elevation may be attributed to the growth factors in addition to the nitrogen compounds present in yeast extract[30,31].
in experiments performed by nizamuddin et al.
[21], the optimization of β-gal was carried out in ssf.
the fungal culture utilized several carbon sources for the β-gal induction.
glucose serves as the most suitable carbon source, followed by lactose, maltose and sucrose.
among the various nitrogen sources, sodium nitrate has been found to be the most promising[15].
our results indicated that optimum ratio of c/n for enzyme activity in the crude extract was 0.1 % (w/v) (fig.
2d).
the culture with added lactose had a relatively constant decrease in enzyme induction in the presence of glucose (fig.
3).
this behavior can be expected in the presence of glucose and can be explained by the mechanism of catabolite repression, which will slow the rate of induction for a while[31].
catabolic repression is the positive control of transcription.
glucose inhibits the synthesis of some inducible enzymes even in the presence of an inducer.
this phenomenon is called catabolic repression or glucose effect and causes through the inhibition of camp synthesis.
the camp is required for the initiation of transcription of many inducible enzymes[32].
catabolite repression is one of the two known regulatory systems affecting the lac operon in the presence of glucose.
it has previously been shown that the production of the lac operon enzymes can be induced to a high level using lactose analog in place of lactose while growing in a media devoid of any sugars.
however, by the addition of glucose, the rate of induction would be severely repressed[33].
in the present investigation, the effect of incubation time of fermentation medium for enzyme production was studied in different time periods 96, 120, 144 and 168 hours.
incubation period is one of the major factors in cost effective production.
basil[34] observed that the addition of certain agricultural by-products (molasses and whey) to growth medium can enhance lactase activity.
similarly, eratt et al.
[35] and sumitra et al.
[36] reported that lactose and maltose improve the α-amylase activity on rice bran medium produced by a. oryzae.
in contrast, srinivas et al.
[37] found a negative effect up to three days of fermentation and then turned positive with the presence of lactose, as a carbon source, for α-gal production by a. niger.
based on our results, the highest enzyme activity was observed at 144 h, and the enzyme activity indicated a periodic fluctuation over time (fig.
2e).
this phenomenon might be due to a change in the ph of the medium or denaturation and/or decomposition of β-gal as a result of interactions with other compounds in the fermented medium[5].
similar findings have also been reported by khayati et al.
[5], sandhya et al.
[38] and gupta et al.[39].
in conclusion, solid-state fermentation is well suited for the production of β-gal because of its abundant and cost-effectiveness.
@highlight
background: enzymatic hydrolysis of lactose is one of the most important biotechnological processes in the food industry, which is accomplished by enzyme β-galactosidase (β-gal, β-d-galactoside galactohydrolase, ec 3.2.1.23), trivial called lactase.
orthogonal arrays design is an appropriate option for the optimization of biotechnological processes for the production of microbial enzymes.
methods: design of experimental (doe) methodology using taguchi orthogonal array (oa) was employed to screen the most significant levels of parameters, including the solid substrates (wheat straw, rice straw, and peanut pod), the carbon/nitrogen (c/n) ratios, the incubation time, and the inducer.
the level of β-gal production was measured by a photometric enzyme activity assay using the artificial substrate ortho-nitrophenyl-β-d-galactopyranoside.
results: the results showed that c/n ratio (0.2% [w/v], incubation time (144 hour), and solid substrate (wheat straw) were the best conditions determined by the design of experiments using the taguchi approach.
conclusion: our finding showed that the use of rice straw and peanut pod, as solid-state substrates, led to 2.041-folds increase in the production of the enzyme, as compared to rice straw.
in addition, the presence of an inducer did not have any significant impact on the enzyme production levels.
