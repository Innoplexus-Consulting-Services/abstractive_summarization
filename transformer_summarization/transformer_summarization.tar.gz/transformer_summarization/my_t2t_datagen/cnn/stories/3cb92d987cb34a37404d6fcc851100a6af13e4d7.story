1. background divergence times are often estimated by combining fossil information with a phylogenetic hypothesis.
in a classical clock-based ‘node-dating’ framework, a tree of extant taxa with branch lengths representing character changes is dated with reference to a set of fossil calibrations that constrain the minimum age for particular nodes.
however, multiple important divergences within the tree of life are not bracketed by extant lineages (e.g.
origin of birds) and thus cannot be estimated using molecular data.
more recently, ‘tip-dating’ approaches have allowed extinct taxa to be included as terminals, with phylogenetic inference and divergence time estimation occurring simultaneously without reference to node calibrations.
this opens up the possibility for using character change from molecular or morphological sources (or both) when estimating divergences between extinct and extant lineages, or even among entirely extinct lineages.
independently of these advancements, palaeontologists have been using stratigraphic ages to directly date divergences on existing phylogenies.
often constructed from both morphological cladograms and taxonomy, these lack measures of character change [1], with their strength instead relying on the stratigraphic distribution of fossils [2].
we term these ‘a posteriori’ time-scaling (apt) approaches.
most of these apt approaches work independently of inferred amounts of character change (but see [3]), relying solely on occurrence data.
broadly speaking, three types are typically applied: (i) minimum-age dating [4], (ii) extending branch durations by adding a constant [5] and (iii) branch duration sharing [3].
the latter two utilize a minimum age (based on first appearances) dated tree as a preliminary step.
these approaches suffer from arbitrary choices of required variables and make strong assumptions of the quality of the fossil record without reference to said fossil record.
while bayesian tip-dating methods have recently become accessible to completely extinct clades ([6]; other papers in special feature), their availability has also coincided with improvements in apt approaches [7].
here, we assemble a novel phylogenetic hypothesis for mesozoic dinosaurs and time-scale it using two different probabilistic apt methods—cal3 [7] and a new method developed from the node-dating approach of hedman [8].
we use these results to ask three questions involving major evolutionary transitions: (i) when did dinosauria originate?, (ii) when did birds originate?
and (iii) how old is the avian crown?
the first two involve dating the divergence of an extinct lineage, but the latter considers a split among extant taxa, thus permitting comparisons between our estimates and those from published clock-based analyses.
2. material and methods a novel ‘metatree’ approach (electronic supplementary material, figures s1, s2)—which operates in a similar way to formal supertree approaches, but generates source trees directly from character-taxon matrices rather than published figures (see the electronic supplementary material)—generated 1000 phylogenetic hypotheses containing 962 separate operational taxonomic units (otus).
of these, 100 were sampled at random to account for phylogenetic uncertainty (a larger number being computationally prohibitive).
ages came from fossil occurrence data in the paleobiology database and primary literature.
divergence times were then estimated for three nodes on the tree: (i) the origin of dinosaurs (inclusive and exclusive of the potential oldest dinosaur, nyasasaurus [9]), (ii) the origin of avialae (inclusive or exclusive of the purported earliest bird, aurornis [10]) and (iii) the origin of crown birds (neornithes).
we first applied the cal3 method of bapst [7], which requires a priori estimates of diversification and sampling rates to draw likely divergence dates under a birth–death-sampling model and operates in a similar manner to the fossilized birth–death (fbd) process [11].
sampling and extinction estimates were obtained by stochastically sampling sets of congruent taxon ranges from the occurrence data, via the function ‘seqtimelist’ in the r package palaeotree [12].
we calculated maximum-likelihood estimates of sampling and extinction rates using the resulting range frequency distributions [13], and used our extinction rate estimates as a proxy for speciation rate.
to account for the uncertainty in these rate estimates, each cal3 tree was time-scaled with a different set of estimated rates.
as the cal3 approach is stochastic, we applied it 1000 times and aggregated the results into distributions.
next, we applied a novel algorithm based on the node-dating approach of hedman [8].
not all nodes can be appropriately dated using this algorithm (electronic supplementary material, figure s4), and thus, we utilized a novel approach to obtain missing dates via a randomization process (electronic supplementary material).
again, 1000 dates were estimated for each node on each tree.
thus for the three nodes distributions were produced from 100 000 point estimates for both the cal3 and hedman approaches.
tree searches were performed in tnt [14] and all other analyses in r [15].
3. results the main results are summarized in figure 1 and electronic supplementary material, table s2.
overall, the cal3 and hedman approaches broadly agree (mean difference between median estimates = 5.4 ma).
however, the shapes of the distributions often vary (figure 1), with the hedman approach giving less precise estimates (mean highest posterior density (hpd) width is 6.3 ma greater than for cal3).
the probability of a permian origin for dinosaurs depends on whether nyasasaurus is (2.6%, cal3; 9.6%, hedman), or is not (0.2%, cal3; 1.0%, hedman) considered a dinosaur.
conversely, the difference in the median age estimate is minimal regardless of whether archaeopteryx or aurornis is considered the earliest bird (2.8 ma, cal3; 0.4 ma, hedman), despite a 7 ma difference in their lower bounds.
finally, the 95% hpd width for crown birds is the largest for any node (23.4 ma, cal3; 39.5 ma, hedman) due to both greater phylogenetic uncertainty and a poorer fossil record, creating overlap with multiple published clock-based estimates.
figure 1.comparison of probabilistic apt dates (red bars, cal3; blue bars, hedman; see the text) for key nodes in dinosaur phylogeny: dinosauria i (nyasasaurus as sister to dinosauria), dinosauria ii (nyasasaurus nested within dinosauria), avialae i (archaeopteryx as first bird), avialae ii (aurornis as first bird) and neornithes (crown birds).
asterisks mark minimum bound or ‘traditional’ palaeontological estimate.
molecular and morphological clock dates for neornithes are shown in the lower right corner (a–j; electronic supplementary material, table s3): circles indicate mean and horizontal bars the 95% hpd.
silhouettes were taken from public domain images on phylopic.org (aurornis, gareth monger; eoraptor, scott hartman; vegavis, matt martyniuk), or modified with kind permission from works by sergio pérez (archaeopteryx) and nobu tamura (nyasasaurus).
4. discussion application of our metatree approach results in a well resolved strict consensus (electronic supplementary material, figure s3) which we attribute to the inclusion of a taxonomy ‘tree’ and our weighting scheme (see the electronic supplementary material), which create superior overlap and conflict resolution (compared with formal supertrees), respectively.
remaining topological uncertainty is distal to the main nodes under consideration, situated primarily among the long-necked sauropodomorphs and extinct bird clade enantiornithes.
if nyasasaurus is the oldest dinosaur, it significantly increases the age of the dinosaurian node.
however, even if this taxon falls just outside the clade the upper 95% hpd does not exclude an early triassic age—an older value than most macroevolutionary studies apply [16].
proper resolution of this positional uncertainty would require a larger archosaur phylogeny and illustrates the general difficulty of estimating root values.
the absence of phylogenetic uncertainty at this node also coincides with the narrowest hpd width (greatest precision) and closest agreement between cal3 and hedman estimates.
this is to be expected as the major source of difference between cal3 and hedman is the latter approach's greater sensitivity to the order of outgroups.
although aurornis may be a troodontid rather than a bird [17], either position does not seem to affect the estimated bird origin age here.
given the demonstrated volatility of dinosaur phylogeny [18], this is an encouraging result for the robustness of both approaches.
the bird node also confirms that there is no consistent, and hence predictable, bias between both methods in terms of median age: here (unlike the root) cal3 returns the older median value.
published age estimates for neornithes vary considerably (figure 1).
this uncertainty is in part due to a worse fossil record in crown- versus stem-birds, as well as the credibility of the neornithine affinities of some late cretaceous taxa [19] which make calibrating clock-based approaches difficult.
our methods also seem to capture this signal, as suggested by the largest hpd widths for both cal3 and hedman.
both approaches also share the same level of accuracy as their clock-based comparisons: 95% hpds overlap with all but one published estimate.
furthermore, both apt median age estimates fall within the range of mean clock-based ages.
the neornithine node also illustrates the larger variability in distribution shape for the hedman approach.
this reflects the reliance on the order and age of outgroups that produce the distributions on which the hedman approach is conditioned.
overall both of our probabilistic apt approaches are broadly congruent with clock-based estimates and each other, suggestive of robustness.
thus, not only is it feasible to apply cal3 to vertebrate data (see also [20]), cal3 and hedman should be preferred over apts that ignore fossil record quality.
between these approaches and the fbd model [11], adequate divergence dating is available independently of whether lineages are still extant or have character information available.
it is also conceivable that these distributions could inform priors on specific divergences in clock-based approaches, such as node- or tip-dating constraints.
however, there is still room for improvement.
ideally, phylogenies dated with apt methods contain almost all taxa known from the fossil record, like the metatree constructed here, but this may be impossible for some groups.
(for example, many invertebrate macrofossil species have never been included in a phylogenetic hypothesis [2].)
both apt approaches used here also make simplistic assumptions about sampling, which may vary considerably over time and space [21], and future approaches should relax such constraints as some implementations of the fbd model already allow.
regardless, the increasing ability to calculate robust divergence dates for phylogenies of fossil taxa opens more intersections on the tree of life to dating and subsequent macroevolutionary analyses.
supplementary material figure s1 supplementary material figure s2 supplementary material figure s3 supplementary material figure s4 supplementary material supplementary information
@highlight
branch lengths—measured in character changes—are an essential requirement of clock-based divergence estimation, regardless of whether the fossil calibrations used represent nodes or tips.
however, a separate set of divergence time approaches are typically used to date palaeontological trees, which may lack such branch lengths.
among these methods, sophisticated probabilistic approaches have recently emerged, in contrast with simpler algorithms relying on minimum node ages.
here, using a novel phylogenetic hypothesis for mesozoic dinosaurs, we apply two such approaches to estimate divergence times for: (i) dinosauria, (ii) avialae (the earliest birds) and (iii) neornithes (crown birds).
we find: (i) the plausibility of a permian origin for dinosaurs to be dependent on whether nyasasaurus is the oldest dinosaur, (ii) a middle to late jurassic origin of avian flight regardless of whether archaeopteryx or aurornis is considered the first bird and (iii) a late cretaceous origin for neornithes that is broadly congruent with other node- and tip-dating estimates.
demonstrating the feasibility of probabilistic time-scaling further opens up divergence estimation to the rich histories of extinct biodiversity in the fossil record, even in the absence of detailed character data.
