introduction multiple myeloma (mm) and amyloid light (al) amyloidosis represent a malignant proliferation of plasma cells derived from a single clone.
myeloma kidney is predominantly contributed by the cast nephropathy, and patients with this kind of involvement suffer from renal insufficiency.
[1] however, 75% of patients with al amyloidosis are detected to have proteinuria.
the extent of proteinuria can vary from mild to massive (>20 g/day).
in these patients, the circulating light chains are taken up by the macrophages.
within macrophages, they undergo partial metabolism and ultimately secreted as a misfolded protein.
[23] the median age at diagnosis is 70 years; it is uncommon under age 40. males are more commonly affected than females.
there are very few cases of mm in young patients.
[4] we are discussing a young female of indian origin, who presented with kyphoscoliosis and pedal edema and detected to be suffering from the biclonal variety of mm and renal amyloidosis.
she was also detected to have severe vitamin d deficiency.
case report a 40-year-old woman presented with gradually progressive painless spinal deformity following fall 2 years back.
she also complained of anorexia and mild bipedal swelling.
as her pedal edema was progressive for last 3 months and she did not respond to treatment in local hospitals, she visited our institution.
the clinical finding was kyphoscoliosis and pitting bipedal edema extending up to the knee.
the patient had pallor, but no clubbing, jaundice, or organomegaly.
blood pressure was 130/86 mm of hg and pulse rate was 82/min.
her body mass index was 19 kg/m2.
other systems were within normal limit.
laboratory investigations showed hemoglobin 8 g/dl, white blood cells 5800/cmm, differential count showed polymorphs 58%, lymphocytes 36%, eosinophils 3%, monocytes 4%, basophils 1%, and platelet-adequate.
other blood reports were erythrocyte sedimentation rate 120 mm/h, urea 18 mg/dl, creatinine 0.7 mg/dl, serum albumin 2 mg/dl, total protein 7 mg/dl, bilirubin 0.6 mg/dl, alkaline phosphatase 248 u/l, alanine transaminase 38 u/l, aspartate transaminase 34 u/l, serum sodium 136 mmol/l, potassium 4.4 mmol/l, calcium 8 mg/dl, phosphate 4.3 mg/dl, and vitamin d level was 1.38 ng/ml.
urine for routine and microscopic examination revealed albumin ++++.
urine culture was negative.
urine 24-h protein was 9 g. parathyroid hormone was 38.3 pg/ml.
serum for anti-hiv 1 and 2, hepatitis b surface antigen, and anti-hepatitis c virus were negative.
thyroid profile was within normal limits.
there was marrow edema in d5, d6, d7, d9, d10, and l4 vertebral bodies and posterior elements with a subtle decrease in anterior height in magnetic resonance imaging spine.
serum protein electrophoresis showed an m-peak in the gamma fraction (serum m-protein was 2760 mg/dl) (90% contributed by igg and 18% by iga), and immunofixation electrophoresis revealed the presence of biclonal igg and iga and lambda light chain paraproteins [figure 1].
serum igg, iga, and igm were 2500 mg/dl (reference interval: 870–1700 mg/dl); 498 mg/dl (reference interval: 110–410 mg/dl), and 125 mg/dl (reference interval: 35–220 mg/dl), respectively.
serum free light chain ratio (kappa/lambda) was 0.029. urinary bence jones protein was negative.
skeletal survey showed no lytic lesion.
bone marrow biopsy revealed 62% of plasma cells including some bi-nucleate form.
serum β2-microglobulin was 2.2 mg/l.
renal biopsy demonstrated lambda light chain deposition and positive birefringence of congo red-stained material under polarized light [figures 2–4].
in the background of this finding, an echocardiography and nerve conduction study was done to exclude other system involvements due to amyloidosis.
both studies revealed no abnormality.
these results led to the diagnosis of al chain amyloidosis in a patient with the biclonal variety of mm.
at the time of diagnosis, she had stage 2 disease according to the international staging system (calculated by serum β2-microglobulin and albumin).
figure 1 biclonal pattern of immunoglobulin protein on immunofixation figure 2 lambda light chain staining on renal biopsy figure 3 congo red staining shows amyloid deposition in renal biopsy figure 4 congo red staining under polarized light the patient was started on combination therapy with vincristine, adriamycin, and dexamethasone.
zoledronic acid and vitamin d supplementation were also given.
after two cycles, her m protein in serum was reduced and she was also improving symptomatically.
after four cycles, hematopoietic stem cell transplantation was planned.
but after that, she failed to follow-up for next 1½ months.
she again got admitted due to respiratory infection.
in spite of oral as well as intravenous antibiotics, her condition deteriorated.
she succumbed within 4 months of initiation of therapy.
discussion biclonal plasma cell myeloma (pcm) producing two different isotypes of igs is an exceedingly rare entity.
in an extensive review of 1027 pcm patients, only 2% had a biclonal gammopathy on protein electrophoresis studies.
however, the survey did not specify which combinations of biclonal m-proteins were present.
other reports have described the combinations of biclonal gammopathies, including igd/igg, igg/igm, iga/igg, and kappa/lambda light chain biclonal gammopathies.
[5] case report is there about iga/igm biclonal variety also.
[6] the pathology behind biclonal gammopathy is not clear until now.
biclonal gammopathy may result from the expansion of two clones of plasma cells.
they produce an unrelated monoclonal ig.
otherwise, two monoclonal proteins can be produced by a single clone of plasma cells.
[5] interestingly, our patient had no hypercalcemia and renal failure.
detection of biclonal variety (igg and iga) of mm with renal amyloidosis and massive proteinuria in a 40-year-old indian female is exceedingly rare.
she had presented with painless spinal deformity associated with severe vitamin d deficiency that are also unusual as presenting features of mm.
moreover, mm is common above the age of 70 years and in male patients.
but in this case, the patient was a 40-year-old female.
this is also an unusual age for the development of mm.
the significant proportion of circulating vitamin d is bound to vitamin d binding protein (dbp).
about 10–15% is bound to albumin.
less than 1% of circulating vitamin d remains in an unbound form.
increased urinary loss of dbp has been suggested to result in lowering of vitamin d levels in patients losing protein through urine.
[7] al amyloidosis is found in up to 30% of patients who present with mm; conversely, mm is present in up to 20% of patients who present with al amyloidosis.
autopsy studies in patients with myeloma found cast nephropathy in 30–50%, light-chain deposition disease in 2–3%, and amyloidosis in 4–5% of cases.
[7] renal involvement in myeloma may be caused by the cast nephropathy of the distal tubule.
on the other hand, deposition of al amyloid protein in glomeruli results in massive fibrillar involvement.
therefore, almost mm patients present with renal impairment.
on the contrary, patients of al amyloidosis present with a nephrotic syndrome with severe hypoalbuminemia.
[1] renal involvement in myeloma is various according to the involvement of tubule, glomerulus, or effect of drugs used for the treatment of myeloma.
hence, renal involvement in an important issue in myeloma patients.
newer agents (bortezomib, thalidomide, and lenalidomide) are now available in the treatment of myeloma.
[23] we are hopeful that treatment of the primary disease will provide favorable renal outcome also.
patients secreting lambda light chains have a significantly shorter overall survival than those secreting kappa light chains.
the exact cause of this is unclear.
[8] our case is unique because of the age of the patient, female sex, indian ethnicity, and association of renal amyloidosis leading to massive proteinuria and vitamin d loss.
with increased awareness about this rare disease of the biclonal variety of mm, we hope that further data regarding characterization, behavior, and prognosis will be derived in future.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
in amyloidosis, there is an extracellular deposition of beta-sheet fibrils.
over 25 proteins have been demonstrated to form amyloid.
one of them is ig amyloid light (al) chains.
we are presenting a 40-year-old female who presented with progressive kyphoscoliosis for last 2 years following a minor trauma and bilateral pedal edema for last 3 months.
on further investigation, we found that she had a biclonal variety of mm with amyloidosis of kidney leading to massive proteinuria.
very few case reports are available where patient with biclonal variety of mm develop renal amyloidosis.
