introduction in 2011, the number of patients with diabetes mellitus (dm) in japan was estimated to be approximately 10.7 million.
although the absolute number of obese individuals in japan is less than in europe and the united states, the prevalence of dm is high in this country.
this is reportedly due to genetically low insulin secretion capacity as well as insulin resistance in individuals with excess visceral adipose tissue (vat) and fatty liver (1).
visceral fat obesity and metabolic syndrome are linked to atherosclerosis related to high insulin resistance, oxidative stress (2), adipokine dysregulation, and excess free fatty acids (which causes vascular dysfunction) (3).
furthermore, the pathological process of atherosclerosis is known to be initiated by vascular endothelial dysfunction (4).
particularly in patients with type 2 dm (t2dm), vascular endothelial dysfunction plays an important role in the progression of macrovasculopathies (5).
it was reported in the framingham heart study that vascular endothelial function assessed by peripheral arterial tonometry (endo-pat) was worse in diabetic patients than in healthy individuals (6).
in addition, we have also reported that the standard deviation (sd) and the mean amplitude of glycemic excursions (mage), i.e.
indices of fluctuations in blood glucose as determined by continuous glucose monitoring (cgm), correlate significantly with vascular endothelial function (7).
several studies have reported a positive relationship between atherosclerosis and obesity or excess vat in subjects with vascular endothelial dysfunction assessed via flow-mediated dilatation (fmd).
however, no studies in patients with t2dm have used endo-pat to assess the relationship between vascular endothelial dysfunction and obesity or excess vat.
the purpose of this retrospective study was to determine the association between vascular endothelial function and excess vat using endo-pat in japanese patients with t2dm.
materials and methods subjects the study subjects were in-patients with t2dm admitted to the department of endocrinology, metabolism and diabetes, university of occupational and environmental health japan, between november 2010 and march 2014. patients on insulin therapy or thiazolidine, with type 1 diabetes mellitus, who were pregnant or planning to become pregnant, and those with arrhythmias confirmed by electrocardiography (ecg) were excluded from the study.
the institutional review board of the university of occupational and environmental health approved this study.
study design each participant had their reactive hyperemia index (rhi) measured using an endo-pat 2000 under fasting conditions within 7 days of hospitalization.
changes in prescribed medications, including oral glucose-lowering agents, before endo-pat were prohibited.
vat and subcutaneous adipose tissue (sat) were measured via computed tomography (ct).
blood samples were collected under fasting conditions in the morning for measurement of fasting plasma glucose (fpg), hemoglobin a1c (hba1c), immunoreactive insulin (iri), triglyceride (tg), low-density lipoprotein cholesterol (ldl-c), high-density lipoprotein cholesterol (hdl-c), high-molecular-weight adiponectin (hmw-an), aspartate amino transferase (ast), alanine amino transferase (alt), γ-glutamyltranspeptidase (γ-gtp), creatinine (cre), and estimated glomerular filtration rate (egfr).
the primary endpoint was the correlation between vat and natural logarithmic-scaled rhi (l_rhi).
the secondary endpoint was the correlation between l_rhi and sat, vat/sat, abdominal circumference (ac), the homeostasis model assessment for insulin resistance (homa-ir), urinary c-peptide reactivity (u-cpr), hmw-an, and alt.
measurements blood samples were collected early in the morning after at least 12-h fasting, through a venous line placed in the median vein using an indwelling catheter.
pg level was measured with the glucose oxidase method.
hba1c was measured via high-performance liquid chromatography (hplc) using a tosoh hlc-723g8 (tosoh, kyoto, japan).
hba1c (%) was estimated as the national glycohemoglobin standardization program (ngsp) equivalent value, which was calculated as hba1c (ngsp) (%) = hba1c (jds) (%) + 0.4%, considering the relationship of hba1c (ngsp) values to hba1c (jds) (%) values determined by the japanese standard and measurement method.
homa-ir, which represents insulin resistance, was calculated using the following formula: homa-ir = fasting glucose level × fasting insulin level ÷ 405. measurement of lipid profiles and other markers was outsourced to srl co. (tokyo, japan).
plasma lipid was measured with a hitachi 7,350 autoanalyzer (hitachi, tokyo, japan).
ldl-c was measured using the colestest ldl (sekisui medical, tokyo, japan) by the direct method.
hdl-c was measured using the colestest nhdl (sekisui medical) by the direct method.
tg was measured using the pureanto stg-n (sekisui medical) by the enzymatic method.
hmw-an was measured via a chemiluminescent enzyme immunoassay.
u-c-peptide reactivity (cpr) level was measured in 24-h urine samples.
assessment of endothelial function with endo-pat the vascular endothelial function was assessed in all 71 patients using the endo-pat 2000. the method used for digital measurement of vascular endothelial function using pat has been described in detail previously (8).
after a 30-min acclimatization period in a room controlled for temperature and light, the baseline pulse amplitude was recorded in fasting patients over a period of 5 min before the induction of ischemia.
ischemia was induced by placing a blood pressure cuff on the upper arm, while the opposite arm served as a control.
the pat probes were placed on one finger of each hand.
after 5 min, the blood pressure cuff was inflated to 60 mmhg above the systolic pressure or to 200 mmhg for 5 min and then deflated to induce reactive hyperemia.
as a measure of reactive hyperemia, rhi was calculated as the ratio of the average amplitude of the pat signal over 1 min, beginning 1.5 min after cuff deflation (control arm, a; occluded arm, c) divided by the average amplitude of the pat signal over the 2.5-min time period before cuff inflation (baseline) (control arm, b; occluded arm, d).
thus, rhi = [(c/d) / (a/b) × baseline correction].
because rhi has a heteroscedastic error structure, we used natural logarithm transformation in all analyses.
statistical analysis data were expressed as the mean ± sd.
normality was determined using the shapiro-wilk test.
values of rhi showed skewed distribution, and accordingly, we used l_rhi in the present study.
for two-sample comparison, the two sample t-test was used.
for univariate analysis, we used pearson correlation analysis for normally distributed variables and spearman rank correlation for variables with skewed distribution.
a multivariate stepwise regression analysis was conducted using rhi as the dependent variable and several parameters found to be significantly related to l_rhi on univariate analysis.
the level of significance was set as p<0.05.
all statistical analyses were performed using the statistical software package for social association, version 22.0 (spss inc., chicago, usa).
results clinical characteristics the demographic details are shown in table 1. of the 71 participants, 37 were men and 34 were women.
the mean age of participants was 56.5±12.1 years.
the participants were mildly obese, with a mean body mass index (bmi) of 26.0±6.0 kg/m2 and a large amount of vat (144.0±63.4 cm2).
blood glucose was generally poorly controlled on admission, with a mean hba1c level of 9.0±1.8%.
in addition, participants tended to be insulin-resistant, with a mean homa-ir of 3.2±2.9 and u-cpr level of 78.4±56.3 μg/day.
other findings included ldl-c level of 123.9±36.5 mg/dl, hdl-c level of 49.6±14.1 mg/dl, and tg level of 165.4±120.5 mg/dl, indicating hypertriglyceridemia.
table 1. baseline characteristics and laboratory data of all patients.
parameter mean ± sd (range) parameter mean ± sd (range) sex (male: female) (37:34) hba1c (%) 9.0 ± 1.8 (6.2-13.7) age (years) 56.5 ± 12.1 (22-84) fpg (mg/dl) 152.6 ± 49.0 (74-306) diabetic duration (years) 5.7 ± 6.2 (1-22) homa-ir 3.2 ± 2.9 (0.4-13.5) body weight (kg) 66.9 ± 18.0 (38.0-140.0) u-c peptide (μg/day) 78.4 ± 56.3 (8.8-297.8) body mass index (kg/m2) 26.0 ± 6.0 (16.7-53.8) ast (iu/l) 30.2 ± 26.2 (9-188) ac (cm) 92.7 ± 13.9 (61-154) alt (iu/l) 36.3 ± 32.1 (6-207) vat (cm2) 144.0 ± 63.4 (7-352) γ-gtp (iu/l) 68.3 ± 92.7 (4-553) sat (cm2) 186.0 ± 119.9 (13-650) cre (mg/dl) 0.7 ± 0.2 (0.3-1.4) v/s 0.95 ± 0.51 (0.22-3.04) egfr (ml/min) 90.0 ± 28.2 (39.2-212.6) sbp (mmhg) 128.7 ± 21.2 (90-199) ldl-c (mg/dl) 123.9 ± 36.5 (65-249) dbp (mmhg) 73.5 ± 11.9 (44-100) hdl-c (mg/dl) 49.6 ± 14.1 (29-94) use of sulfonyl urea 20/28.2 tg (mg/dl) 165.4 ± 120.5 (59-809) (n/%) use of dpp4-i (n/%) 28/39.4 l_rhi 0.56 ± 0.24 (0.03-1.03) use of statin (n/%) 25/35.2 rhi 1.80 ± 0.44 (1.03-2.81) use of arb (n/%) 21/29.6 hmw-an (μg/ml) 5.0 ± 7.0 (0.2-52.5) data are mean ± sd or number (range: minimum-maximum).
hba1c levels were converted to ngsp levels (formula: ngsp = jds + 0.4%).
ac: abdominal circumference, vat: visceral adipose tissues, sat: subcutaneous adipose tissues, v/s: vat sat ratio, sbp: systolic blood pressure, dbp: diastolic blood pressure, dpp4-i: dipeptidyl peptidase 4-inhibitor, arb: angiotensin ii receptor blocker, hba1c: hemoglobin a1c, fpg: fasting plasma glucose, homa-ir: homeostasis model assessment insulin resistance, ast: aminotransferase, alt: alanine aminotransferase, γ-gtp: γ-glutamyl transpeptidase, egfr: estimated glomerular filtration rate, ldl: lowdensity lipoprotein, hdl: high-density lipoprotein, tg: triglyceride, l_rhi: the natural logarithmic scaled reactive hyperemia index, hmw-an: high molecular weight-adiponectin efficacy outcome vat correlated significantly with homa-ir and urinary c peptide excretion rate and negatively with hmw-an, hdl-c, and l_rhi (figure).
table 2 shows the correlation between l_rhi and various clinical and laboratory parameters.
there was a negative correlation between vat and l_rhi, the primary endpoint (p=0.042, r=-0.242, table 2, figure).
however, l_rhi did not correlate with sat, vat/sat, ac, homa-ir, u-cpr, hmw-an, or alt, the secondary endpoints (table 2).
figure.
results of a univariate analysis using the pearson correlation analysis for normally distributed variables and spearman rank correlation for variables with skewed distribution.
correlation was assessed between excess visceral adipose tissue (vat) and (a) natural logarithmic reactive hyperemia index (l_rhi), (b) high-molecular-weight adiponectin (hmw-an), (c) homeostasis model assessment for insulin resistance (homa-ir), (d) high-density lipoprotein cholesterol (hdl-c), and (e) urinary c-peptide reactivity (u-cpr).
table 2. univariate linear regression analysis for predicting l_rhi.
variable univariate analysis r p value age -0.135 0.261 duration of diabetes -0.017 0.891 body mass index -0.041 0.733 ac -0.057 0.637 vat -0.242 0.042 sat -0.003 0.979 vat/sat -0.139 0.248 hba1c -0.057 0.638 fpg -0.131 0.277 homa-ir -0.054 0.659 u-c peptide -0.087 0.483 ast -0.021 0.864 alt -0.063 0.599 ast/alt 0.026 0.832 γ-gtp -0.067 0.577 egfr 0.053 0.658 ldl-c 0.015 0.899 hdl-c 0.038 0.755 tg 0.067 0.577 hmw-an 0.130 0.280 abbreviations as in table 1. with regard to univariate analysis, we used pearson correlation analysis for normally distributed variables and spearman rank correlation for variables with skewed distribution.
with regard to the factors known to affect l_rhi level, there were no relationships between l_rhi and sex or the use or non-use of medications, such as sulfonylureas, dipeptidyl peptidase-4 (dpp-4) inhibitors, statins, and angiotensin ii receptor blockers (arb) at admission (data not shown).
a linear multivariate analysis with the forced entry method using age, sex, vat and a history of smoking as independent variables and l_rhi as the dependent variable revealed a lack of any determinants of l_rhi, as our study enrolled only 71 participants and over half used medications which affect rhi.
discussion the present study used endo-pat to demonstrate that excess vat correlated with vascular endothelial dysfunction in japanese patients with t2dm.
the framingham offspring study examined the association between atherosclerosis and excess vat and reported that percent fmd (%fmd), after multivariate adjustment, correlated negatively with vat but not with sat (9).
in a study using endo-pat, rhi correlated negatively with bmi, fpg, and homa-ir in obese pre-diabetic patients.
however, no reference was made to the relationship between rhi and visceral fat accumulation (10).
our study is important because there are no previous studies that used endo-pat in patients with t2dm to show the association between excess vat and vascular endothelial dysfunction.
furthermore, bmi, which correlated negatively with rhi in the aforementioned study (10), did not correlate with rhi in the present study, indicating that vat is a more important factor in vascular endothelial dysfunction in japan because of the smaller percentage of obese people than in the united states and europe.
how can excess vat affect the pathological process of atherosclerosis?
torigoe et al.
(11) showed a positive correlation between %fmd and hmw-an in healthy subjects.
furthermore, narita et al.
(12) reported that the intima-media thickness (determined by carotid artery ultrasonography) correlated negatively with an and positively with homa-ir and leptin/an, whereas %fmd correlated negatively with leptin and leptin/an (but not with an) in healthy subjects.
these reports suggest the importance of adipocytokine secretion abnormalities.
another intervention study that used endo-pat reported that an eight-week high-fat diet in healthy subjects reduced rhi and increased body weight, bmi, ac, vat, high-sensitivity c-reactive protein, leptin, fpg, and homa-ir (13).
vat correlated significantly with homa-ir and urinary c peptide excretion rate and negatively with hmw-an and hdl-c in the present study.
these results suggest that excess vat induced insulin resistance and hypoadiponectinemia (figure).
however, with regard to the mechanism of vascular endothelial dysfunction with excess vat, there was no correlation between l_rhi and hmw-an in this study.
this observation might be due to secretion abnormalities of other adipocytokines, such as leptin, oxidative stress, and inflammatory cytokines.
this study is associated with some limitations.
first, it was a retrospective study involving a small sample size.
therefore, a prospective study with a larger number of patients is needed for future validation.
second, we did not examine adipocytokines other than hmw-an, oxidative stress, or inflammatory cytokines.
third, although patients using insulin and thiazolidinediones were excluded, many patients already on oral glucose-lowering agents, such as sulfonylureas and dpp-4 inhibitors, statins, and arbs were included.
these factors may account for the failure to identify the mechanism through which excess vat can cause vascular endothelial dysfunction.
future studies involving a larger number of untreated patients are thus needed.
in this study using endo-pat, we found that excess vat worsens the vascular endothelial function in japanese patients with t2dm.
the authors state that they have no conflict of interest (coi).
@highlight
objective visceral fat obesity and metabolic syndrome correlate with atherosclerosis in part due to insulin resistance and various other factors.
the aim of this study was to determine the relationship between vascular endothelial dysfunction and excess visceral adipose tissue (vat) in japanese patients with type 2 diabetes mellitus (t2dm).
methods in 71 t2dm patients, the reactive hyperemia index (rhi) was measured using an endo-pat 2000, and vat and subcutaneous adipose tissue (sat) were measured via ct. we also measured various metabolic markers, including high-molecular-weight adiponectin (hmw-an).
results vat correlated negatively with the natural logarithm of rhi (l_rhi), the primary endpoint (p=0.042, r=-0.242).
l_rhi did not correlate with sat, vat/sat, abdominal circumference, homeostasis model assessment for insulin resistance, urinary c-peptide reactivity, hmw-an, or alanine amino transferase, the secondary endpoints.
a linear multivariate analysis via the forced entry method using age, sex, vat, and smoking history as independent variables and l_rhi as the dependent variable revealed a lack of any determinants of l_rhi.
conclusion excess vat worsens the vascular endothelial function, represented by rhi which was analyzed using endo-pat, in japanese patients with t2dm.
