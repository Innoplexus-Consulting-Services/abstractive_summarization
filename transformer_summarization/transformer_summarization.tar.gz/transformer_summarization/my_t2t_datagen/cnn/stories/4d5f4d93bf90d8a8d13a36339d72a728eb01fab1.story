introduction dementia is a common clinical symptom in elderly population and also its prevalence increased among younger population.
dementia and cognitive disorders are characterized by dependency and disability and defined as a major problem in both high- and low-income countries.12 patients with mild cognitive disorder and dementia in developing countries are usually underdetected due to low awareness and routine care of elderly.3 studies forecast that a number of people affected by dementia will double every 20 years, and by 2040, 81.1 million people will be affected by dementia,4 and recent studies estimate a greater statistics that by 2040, 90.3 million people will be affected by dementia.5 dementia affects both men and women, and its prevalence as alzheimer's disease (ad) is higher among elderly women.67 in the united states, ad is the sixth leading cause of death and its related costs are increasing worldwide that require cost-effective methods for early diagnosis and care.89 ad as a neurodegenerative disorder causes dementia and its origin is unknown.
one of the major pathologies of ad is neuron degeneration and the atrophy of hippocampus so because of that, ad called as hippocampal dementia and hippocampus size can be used for ad evaluation and progression of ad.101112 some risk factors of ad and hippocampal damage are hypertension, diabetes, and dyslipidemia and also diet-related disorders related to ad.1314 hippocampus is a region in the brain with dense concentration of thyroid hormone receptors, therefore, during lifetime thyroid hormones have much effects on this region.1516 studies demonstrated that maternal or acquired hypothyroidism and thyroid hormone disorders cause reduction in the size of hippocampus and related to memory dysfunction and cognitive disorders.1718 subclinical thyroid disorders are common problems.
according to the studies, the prevalence of subclinical hypothyroidism is 4–20% in adult population,19 so evaluation of serum thyroid-stimulating hormone (tsh) levels seems to be useful in predicting dementia disorders.
the purpose of the present study was to investigate the relationship between tsh level and the size of hippocampus in patients with mild cognitive disorders.
materials and methods in a descriptive-analytical study which was conducted from february 2013 to february 2015, patients with symptoms of mild cognitive disorders were referred to take brain magnetic resonance image (mri) in radiology center of tabriz university of medical sciences, tabriz, iran (a radiology clinic under the supervision of tabriz university of medical sciences), were evaluated.
inclusion criteria included lack of pathology in mri brain imaging and age of 50–60 years.
exclusion criteria were consisted of chronic conditions such as hypertension, diabetes, cancer, and posttraumatic stress disorder (ptsd), smoker patients, chronic alcohol consumption and also history of thyroid disorders, and family history of ad or other cognitive disorders in first-degree relatives.
finally, based on purpose of the study and in accordance with inclusion and exclusion criteria, 41 patients were studied.
brain mri images were obtained using 1.5 tesla siemens power.
imaging protocol included images of axial, coronal, and sagittal sequences t1-weighted ([repetition time (tr)/echo time (te)] 552/12) and sequence t2-weighted ([tr/te] 4000/120) which had been set on the device as default settings.
demographic characteristics of patients and their past medical histories were collected.
the right hippocampal and left hippocampal volume was calculated by mri at coronal t1-weighted, and also we measured overall brain volume as a confounding factor.
level of serum tsh level was measured in main laboratory of imam reza hospital of tabriz university of medical sciences, tabriz, iran (which is a referral center in the north west of iran).
the present study protocol was approved by the ethics committee of tabriz university of medical sciences based on helsinki declaration.
spss software package version 16.0 for windows (spss inc., chicago, il, usa) was used for statistical analysis.
data were reported as mean ± standard deviation and also as frequency and percentage.
to evaluate the correlation between variables, pearson correlation coefficient (r) was calculated and student's t-test was used to compare quantitative variables.
in all results, p ≥ 0.05 was considered statistically significant.
results of the total 41 patients, 21 (51.22%) were male and 20 patients (48.78%) were female and male to female ratio was 1.05:1. mean age of patients was 54.09 ± 3.11 years, and there was no history of chronic disease, malignant, and ptsd in any patient.
the left and right hippocampus of patients average volumes were 1.62 ± 0.39 and 1.61 ± 0.42 ml, respectively.
mean size of patients’ brains was 1185.90 ± 137.85 ml.
since patients’ brains size as a confounding factor, we calculated the left and right hippocampus to the brain size separately.
mean ratios of the left and right hippocampal volume to brain volume were 0.0014 ± 0.00032 and 0.0014 ± 0.00034, respectively.
between male and female, there was no significant difference in the size of left and right hippocampus (p = 0.111, p = 0.080, respectively).
there was no significant correlation found between patients age and the size of left and right hippocampus (p = 0.068, p = 0.165, respectively); in addition there was no significant correlation found between patients’ age and brain volume (p = 0.330).
mean serum tsh level of patients was 1.55 ± 1.45 uu/ml.
all serum tsh levels of patients were in normal range (0.5–6 uu/ml).
table 1 shows the correlation between serum tsh levels with the size of right and left hippocampal volume and their ratio to brain volume.
table 1 correlation between serum thyroid-stimulating hormone levels with the size of right and left hippocampal volume and their ratio to brain volume there was slight negative correlation between serum tsh levels and right/left hippocampal volume and their ratio to brain, but these correlations were not statistically significant.
in general, no significant correlation between tsh levels with the size of the hippocampus was seen.
discussion in ad and other cognitive disorders, changes in temporal lobe and atrophy of hippocampus are as a sensitive marker.
studies recommended assessing temporal lobe changes in cognitive disorders by computerized tomography scan or mri.20 previous studies reported thyroid hormone disorders, especially hypothyroidism, have significant alterations in the hippocampus.21 we conducted the present descriptive study to investigate serum tsh level correlation with hippocampal volume in patients with symptoms of mild cognitive disorders.
according to the present study, serum tsh level had slightly negative correlation with the right and left hippocampal volumes.
due to total brain volume as a contributing factor of hippocampal volume, we calculated the right and left hippocampal volume to brain volume ratio.
furthermore, the correlation between serum tsh level with the right and left hippocampal volume to brain volume ratio was slightly negative, and finally, correlations were not statistically significant.
the mri study of 11 untreated hypothyroid adults and 9 age-matched control subjects, reported a significant reduction in the right hippocampal volume in hypothyroid patients.18 although correlations between levels of serum tsh and hippocampal volume in the present study were not statistically significant, like previous studies, our finding in the present study, propose that high levels of tsh can be associated with reduction in hippocampus size.
prior studies reported hippocampal volume reduction in hypothyroidism, so thyroid dysfunctions can influence hippocampal formation and have an impact on dementia disorders.2223 a similar study on 21 adult rats showed that dysthyroidism (hypo- and hyper-thyroidism) effects on morphology of hippocampal neurons.24 another study on rats manifested that thyroid hormones have role in regulation of hippocampal neurogenesis.
this study stated that alteration in hippocampal neurogenesis and cognitive disorders may be attributed to adult-onset hypothyroidism.25 according to the studies, thyroid disorders, especially hypothyroidism, effect hippocampal formation and have a role in causing and development of dementia.
therefore, high levels of tsh in subclinical hypothyroid cases may be correlated with hippocampal degeneration and cognitive disorders, so we have to consider tsh levels and thyroid disorders in prevention and treatment of dementia disorders.
conclusion based on results of this study and with consideration of findings of previous studies, thyroid hormone regulates the hippocampal functions and also have main role in structural integrity of neurons in the hippocampal, so evaluation of thyroid function and tsh levels can help us in prevention, management, and treatment of dementia disorders and cognitive diseases.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
background: cognitive disorders and dementia are common problems, and alzheimer's disease is one of the major leading causes of death worldwide.
thyroid hormone disorders as a common problem effect on hippocampus size which as a prognostic factor in dementia.
the aim of the present study was to investigate the relationship between serum thyroid-stimulating hormone (tsh) level and the size of hippocampus in patients with mild cognitive disorders.
materials and methods: in a descriptive-analytical study, 41 patients with symptoms of mild cognitive disorders whom referred to take the brain magnetic resonance image (mri) in a radiology center under the direction of tabriz university of medical sciences (tabriz, iran) were evaluated.
the right and left hippocampal and brain volume was calculated by mri at coronal t1-weighted.
serum tsh level was also measured in these patients.
correlation between serum tsh level and hippocampal volume size was evaluated.
results: male to female ratio was 1.05:1 with mean age of 54.09 ± 3.11 years.
mean serum tsh level of patients was 1.55 ± 1.45 uu/ml.
the right and left hippocampal volumes were 1.61 ± 0.42 and 1.62 ± 0.39 ml, respectively.
there were slight negative correlations between the right and left hippocampal volumes with tsh level (r = −0.133 and r = −0.092, respectively).
correlations between the right and left hippocampal volumes with tsh level were not statistically significant (p = 0.406, p = 0.566, respectively).
conclusion: based on findings of the present study, there was a weak negative correlation between serum level of tsh with the right and left hippocampal and brain volume ratio, but the correlation was not statistically significant.
it seems that controlling of clinical or subclinical hypothyroidism may have a role in slowing of dementia progression and also have a preventive role.
