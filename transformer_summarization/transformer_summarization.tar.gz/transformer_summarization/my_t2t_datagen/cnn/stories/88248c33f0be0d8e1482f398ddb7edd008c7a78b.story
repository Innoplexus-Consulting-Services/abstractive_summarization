introduction the ability to adjust the transcriptional output in response to ever-changing environmental conditions lies at the core of organismal development.
the complex cytoarchitecture of the mammalian cortex provides a superb example of how extracellular and intracellular stimuli cooperate to transform a pool of undifferentiated neural progenitor cells (npcs) into a highly organized layered tissue.
each cortical layer contains morphologically and functionally distinct subsets of neurons (kwan et al., 2012) that derive from multipotent npcs generated in the ventricular zone (vz) of the embryonic brain.
all developmental steps that lead to the formation of the mature cortex depend on the expression of specific genes that are necessary for npc proliferation and, at later stages, neuronal migration and laminar specification.
epigenetic modifications and changes of chromatin structure are emerging as fundamental mechanisms that regulate gene expression during brain development (hirabayashi and gotoh, 2010, riccio, 2010).
chromatin is a highly dynamic structure that can be modified by a number of mechanisms, including dna methylation, histone post-translational modifications, and atp-dependent remodeling of chromatin (borrelli et al., 2008).
the latter mechanism uses energy released by hydrolysis of atp to induce nucleosome sliding, facilitating the recruitment of transcriptional complexes (narlikar et al., 2013) that activate or inhibit gene expression.
the nucleosome remodeling and deacetylase (nurd) complex couples atp-dependent chromatin remodeling with histone deacetylase activity (tong et al., 1998, xue et al., 1998, zhang et al., 1998).
nurd is composed of six core subunits, each encoded by homologous gene families (bowen et al., 2004).
the atpase activity of nurd is provided by the chromodomain-helicase dna-binding proteins (chds) 3, 4, or 5, and deacetylase activity by hdac1 or hdac2.
additional core subunits include methyl-cpg-binding domain proteins (mbds) 1, 2, or 3; metastasis-associated proteins (mtas) 1, 2, or 3; the histone-binding proteins rbbp4 or rbbp7; and the nuclear zinc-finger proteins gata2a or gata2b (basta and rauchman, 2015, lai and wade, 2011).
nurd has been linked to a number of basic cellular functions that take place during development, including the maintenance of genome integrity and cell-cycle progression (lai and wade, 2011).
recent studies have also linked nurd to regulation of gene expression during embryonic stem cell (esc) differentiation and lineage commitment of pluripotent cells (kashiwagi et al., 2007, reynolds et al., 2012a, zhang et al., 2011).
while nurd has been implicated in the transcriptional repression of polycomb-regulated genes in escs (reynolds et al., 2012b) and in differentiated neurons (egan et al., 2013), the role of nurd in the developing nervous system remains largely unknown.
here, we show that nurd represents a major chromatin remodeling complex in the developing mouse cortex.
we found that a sequential switch of chds within the complex results in the combinatorial assembly of nurd complexes that regulate the transcription of genes necessary for neural progenitor proliferation, radial migration, and cortical layer specification.
results nurd is the major nuclear complex associated with hdac2 in the developing cortex recent work from our lab (nott et al., 2008, nott et al., 2013) and others (hagelkruys et al., 2014, hagelkruys et al., 2015) demonstrated that the class i histone deacetylases hdac1 and hdac2 control the expression of genes necessary for neuronal development.
class i hdacs do not bind dna directly and are found within large multiprotein complexes that confer target specificity (haberland et al., 2009).
to identify hdac2-containing complexes in the embryonic mouse brain, we performed mass spectrometry of proteins that co-immunoprecipitate with hdac2 during cortical development.
cortices were dissected at embryonic day 12.5 (e12.5), e15.5, and e18.5, and cell lysates were incubated with hdac2 antibody or normal immunoglobulin g (igg).
immunoprecipitated proteins were proteolytically digested and analyzed by mass spectrometry (figure s1a).
the relative abundance of identified proteins was calculated using normalized spectra abundance factors (nsafs).
proteins enriched in hdac2 immunoprecipitates are listed in figure s1b and table s1.
strikingly, all known subunits of the nurd complex were associated with hdac2 at all embryonic stages (figure s1b).
subunits of the corest (rest corepressor 1) and msin3 complexes were also detected (figure s1b).
hdac2 co-immunoprecipitation followed by western blot analysis of chd3, chd4, chd5, mta1, mta2, and rbbp7 confirmed the findings of mass spectrometry analysis and revealed that the association of chds with hdac2 changed according to developmental stage (figures 1a and 1b).
while chd4 co-immunoprecipitated with hdac2 at e12.5 and e15.5, chd3 and chd5 were not detected at e12.5 and became part of the nurd complex at later stages of cortical development.
chd3 co-immunoprecipitated with hdac2 at both e15.5 and e18.5, whereas chd5 was detected predominantly at e18.5.
importantly, co-immunoprecipitation experiments confirmed mutually exclusive occupancy of chd3, chd4, and chd5 within nurd complexes (figure 1c).
glycerol gradient analysis performed on e15.5 cortices indicated that 78% of chds co-sediment as a complex in fractions that also contain the nurd subunits mta1, mta2, and mbd3 (figures 1d and s1c).
taken together, these results indicate that the composition of nurd complex changes during cortical development and that chd3, chd4, and chd5 occupancy within the complex is mutually exclusive.
chds are developmentally regulated in the cortex the mouse cortex is formed between e11 and e18 in a characteristic inside-out manner, with deep layers (layers iv–vi) generated first and more superficial layers (layers ii and iii) generated later (florio and huttner, 2014).
neurons that will eventually occupy the external layers of the cortex must migrate through the deeper layers in order to reach their final location.
during migration and laminar formation, neurons mostly maintain the molecular properties acquired at early stages, although their laminar identity is further specified by postmitotic factors that contribute to the establishment of mature neuronal identity (kwan et al., 2012).
to investigate the expression of chds at different stages of cortical development, mouse cortices were dissected at e12.5, e15.5, and e18.5 and subjected to qrt-pcr and western blot analyses (figures s2a and s2b).
at e12.5, chd3 and chd5 were expressed at relatively low levels that increased at e15.5 and e18.5.
in contrast, chd4 expression remained constant throughout development.
immunostaining of coronal sections confirmed that chd4 was the only chd detected at e12.5, with strong expression observed in npcs (figure s2c).
at later stages (e15.5 and e18.5), chd3 and chd5 were also expressed and found in differentiated neurons of the nascent cortical plate (cp), where they co-localized with the deep layer neuronal marker ctip2 (figures s2c and s3).
a similar expression pattern was observed when neural progenitors isolated from e14.5 rat cortices were differentiated in vitro and immunostained for chds and either nestin, a marker of npcs, or the neuronal marker map2 (figures s4a and s4b).
co-immunoprecipitation experiments confirmed that hdac2 and the core nurd subunit mta2 mostly interact with chd4 in npcs, whereas differentiation correlates with a decline in chd4 interaction and association of both chd3 and chd5 (figures s4c and s4d).
thus, the atpase activity of nurd is mostly mediated by chd4 in npcs, whereas this function is largely provided by chd3 and chd5 at later differentiation stages.
given that the occupancy of chds within the nurd complex is mutually exclusive (figure 1c), a possible interpretation of these findings is that the coexistence of distinct nurd complexes within neurons may be necessary to regulate diverse molecular functions.
deletion of chd4 causes premature cell-cycle exit of npcs and depletion of intermediate progenitor cells to investigate the role of chds during cortical development, we first analyzed the cortex of mice carrying a conditional mutation of the chd4 gene (williams et al., 2004).
chd4 floxed mice were crossed with transgenic mice carrying cre recombinase under the control of the nestin promoter, which results in deletion of chd4 in the nervous system from early embryonic stages (dubois et al., 2006).
most mice lacking chd4 (chd4fl/fl/nestin-cre) died at birth and at e18.5 the brain was significantly smaller than control littermates (chd4fl/fl and chd4wt/wt/nestin-cre; figure 2a), showing remarkable reduction of cortical thickness (figure 2b).
although tunel staining performed at both e13.5 and e16.5 showed no increase in cell death in chd4fl/fl/nestin-cre cortices compared to control littermates (figures 2c and 2d), we observed a reduction of the number of cells expressing the proliferation marker ki67 (figures 2f and 2g).
edu (5-ethynyl-2’-deoxyuridine) labeling coupled with ki-67 immunostaining revealed that in chd4fl/fl/nestin-cre cortices, npcs prematurely exited the cell cycle (figures 2f and 2g), and this event was associated with increased apoptosis at e18.5 (figure 2e).
thus, in cortices lacking chd4, a proportion of npcs precociously exit the cell cycle, fail to differentiate, and die.
progenitor cells, such as radial glia (rg) and apical progenitors (aps), are located in the vz and express the transcription factors pax6 and sox2 (götz et al., 1998, graham et al., 2003).
to study whether deletion of chd4 affected npc number, cortices of chd4fl/fl/nestin-cre mice and control littermates were immunostained for pax6 and sox2.
at e13.5 and e16.5, the number of cells expressing pax6 in the vz was unchanged (figures 3a and 3b), whereas at e16.5, the number of sox2-expressing cells was slightly increased (figure 3c).
however, when pax6 and sox2 immunostaining were combined with a 2 hr edu pulse, it revealed a significant reduction in the number of actively proliferating apical progenitors in chd4fl/fl/nestin-cre mice (figures 3b and 3c).
rg and aps divide at the apical surface and give rise to neurons as well as another neuronal progenitor cell type called intermediate progenitor cells (ipcs, also known as basal progenitors) (noctor et al., 2004).
ipcs divide in a basal position within the vz and subventricular zone (svz) and express the transcription factor tbr2 (also known as eomes) (englund et al., 2005).
in lissencephalic rodents, ipcs represent the principal neurogenic cells and are considered to be responsible for the amplification of neuronal cell number that drove cortical expansion during evolution (martínez-cerdeño et al., 2006).
to investigate whether chd4 influences ipc number, cortices of chd4fl/fl/nestin-cre mice were immunostained for tbr2 and analyzed using confocal microscopy.
in the absence of chd4, the number of tbr2-expressing cells was reduced at e13.5 and e16.5 (figures 3a and 3d), and edu pulse experiments demonstrated a striking reduction of proliferating tbr2-positive ipcs at e16.5 (figure 3d).
because symmetric division of ipcs is necessary for the expansion of neuronal output their depletion may account for the cortical thinness observed in chd4fl/fl/nestin-cre mice.
deletion of chd4 alters cortical lamination to ask how ipc depletion affected the formation of cortical layers we analyzed a number of markers specific for either upper (ii and iii) or deeper (iv–vi) layer neurons.
e18.5 chd4fl/fl/nestin-cre and control cortices were immunostained for upper (satb2 and cux1) (alcamo et al., 2008, britanova et al., 2008, nieto et al., 2004) or deeper (tbr1 and ctip2) (arlotta et al., 2005, hevner et al., 2001) layer-specific markers.
in the absence of chd4, the number of neurons expressing tbr1 and ctip2 was unchanged (figures 3e and 3f).
in contrast, upper layer thickness and the number of neurons expressing satb2 and cux1 were greatly reduced (figures 3e and 3f).
although ipcs generate neurons that populate all cortical layers (sessa et al., 2008), they are the most abundant cell type in the svz, which develops between e13 and e15, at a time when deeper layer neurons are already generated.
thus, in chd4fl/fl/nestin-cre mice ipc depletion in the svz severely and specifically affects the formation of the upper layers of the cortex.
chd3, chd4, and chd5 regulate distinct aspects of neural radial migration contrary to chd4, chd3, and chd5 expression is very low in neural progenitors and increases steadily during the late stages of neurogenesis, when neurons migrate radially to populate the cp (figure s2).
in the developing cortex, chd3 and chd5 show similar, albeit not entirely overlapping, expression profiles.
chd3 is expressed in neurons that have reached the cp, whereas chd5 was also detected in the svz (figure s2c).
to ask whether chd3 and chd5 influence specific aspects of neuronal differentiation and radial migration, we employed the in utero electroporation technique.
we tested the suitability of this approach by comparing the defects observed in the cortex of chd4fl/fl/nestin-cre mice with chd4fl/fl embryos subjected to in utero electroporation using either empty vector (ev) or cre-containing vector.
brains were electroporated at e14.5 and tbr2 expression was analyzed 24 hr later.
electroporation with the cre vector resulted in a striking reduction of tbr2-positive cells comparable to chd4fl/fl/nestin-cre mice (figures s5a and 3d).
similarly, electroporation of e14.5 brains with a chd4-specific small hairpin rna (shrna) decreased both npc proliferation and the number of ipcs (figures s5b–s5d) compared to control shrna (shctl).
next, we performed in utero electroporation at e13.5 using shrna targeting either chd5 or chd3 (shchd5 and shchd3, respectively), shctl, or an ev (figure 4).
potential non-specific effects were ruled out by co-electroporation of rescue vectors encoding human chd5 and chd3.
five days after electroporation, cortices were dissected and neural migration was assessed by counting the number of gfp expressing cells that had reached the cp.
npcs are electroporated in the vz, exit the cell cycle and migrate radially crossing the svz and iz to reach their final position in the cp.
most neurons electroporated with shchd5 accumulated within the iz and failed to reach the cp, whereas these defects were absent in brains electroporated with ev or shctl and were completely rescued by co-electroporation with hchd5 (figure 4a).
newly generated postmitotic neurons are initially multipolar and transiently grow a variable number of immature neurites.
this phase precedes the establishment of neuronal polarity that is essential for radial migration (barnes and polleux, 2009).
to test whether abnormal neuronal polarization was responsible for the defects of radial migration, we analyzed the morphology of postmitotic neurons within the svz of embryos electroporated with shctl or shchd5.
lack of chd5 resulted in the accumulation of multipolar neurons within the iz (figure 4b), suggesting that chd5 contributes to the establishment of neuronal polarity.
because chd3 is confined to postmitotic, differentiated neurons (figures s2c and s4b), we reasoned that it may influence the late stages of cortical development.
e13.5 embryos were electroporated with ev, shctl, shchd3, or shchd3 + hchd3 and after 5 days, cortices were immunostained for gfp and chd3.
knockdown of chd3 induced a delay of neuronal migration, with a significant number of cells retained in the deeper layers (iv–vi) and fewer neurons reaching the upper layers (ii and iii) of the cortex (figure 4c).
similarly to chd5, multipolar cells accumulated in the deeper layers of the cp (figure 4d), suggesting that also in this case abnormalities of neuronal polarity may contribute to radial neural migration defects.
when brains of chd4fl/fl mice were electroporated with ev or vector expressing cre, radial migration and neuronal polarity were not affected (figure s5e).
these findings show that chd3, chd4, and chd5 have non-overlapping roles during cortical development and further support the hypothesis that they are part of distinct nurd complexes.
chd3 and chd5 differentially regulate cortical layer specification neuronal differentiation, radial migration and laminar identity are known to be co-regulated processes (kwan et al., 2012).
it is therefore possible that chd5 and chd3 influence the transcription of genes that control both neural migration and layer positioning.
we first investigated whether the early defects of neural radial migration in neurons lacking chd5 depended on abnormal differentiation of npcs.
brains electroporated with ev, shctl, shchd5, or shchd5 + hchd5 were immunostained for the neural progenitor markers pax6 and ki67.
in contrast to published data (egan et al., 2013), we did not find that knockdown of chd5 caused persistent expression of progenitor markers (figures s5f and s5g).
instead, in brains electroporated with shchd5, a remarkable number of neurons that did not migrate toward the cp expressed the upper layer markers cux1 and satb2 (figures 5a and 5b).
because these neurons never reach layers ii to iii, they give rise to an ectopic layer located beneath the cp.
we next asked whether the defects of late neural radial migration caused by inhibition of chd3 are coupled with abnormalities of laminar identity.
e13.5 embryos were electroporated with shchd3 or control vectors and after 5 days, brains were immunostained for the layer-specific markers tbr1, sox5, brn2, and cux1.
neurons lacking chd3 were more likely to express tbr1 and sox5 (figures 5c and 5d), which are transcription factors that regulate laminar positioning and differentiation of deeper cortical layers (hevner et al., 2001, lai et al., 2008), whereas a lower number of neurons expressed the upper layer markers brn2 and cux1 (dominguez et al., 2012, nieto et al., 2004) (figures 5e and 5f).
thus, despite being largely co-expressed, deletion of chd5 or chd3 results in strikingly different cortical defects.
chd5 is necessary during early radial migration and does not affect the expression of laminar-specific markers.
in contrast, chd3 promotes late neural radial migration and layer specification, implicating that it may influence the expression of genes that couple radial migration with laminar identity.
non-redundant functions of chd3, chd4, and chd5 during cortical development we reasoned that if chd3, chd4, and chd5 regulate non-overlapping aspects of cortical development, the abnormalities observed in brains lacking one of them should not be reverted by co-expression of a rescue vector encoding another.
first, we confirmed that mchd4, hchd3, and hchd5 rescue constructs were expressed in cells transfected with shchd3 or shchd5.
overexpressed chds were easily detected in postmitotic neurons depleted of either chd5 or chd3 (figures 4a, 4c, and s6a–s6c) and were incorporated within nurd complexes under these conditions (figure s6d).
we used cortices depleted of chd3 or chd5, because these proteins are more likely to be functionally redundant due to a similar pattern of expression (figure s2c).
in brains co-electroporated with shchd5 and either hchd3 or mchd4, the number of neurons that reached the cp (figures 6a, 6c, and 6d) and ectopic expression of the upper layer markers satb2 and cux1 (figures 6a and 6b) were comparable to neurons electroporated with shchd5 alone.
when similar experiments were performed in brains electroporated with shchd3, expression of mchd4 did not rescue the neural radial migration defects (figures 6e and 6g) or change the number of cells expressing cux1 and tbr1 (figures 6e and 6f).
moreover, co-electroporation of shchd3 and hchd5 did not influence the number of neurons expressing cux1 or tbr1 (figures 6e and 6f), whereas radial migration defects were rescued under these conditions (figures 6e and 6h), suggesting that chd5 may provide functional compensation in regards to neuronal migration.
thus, chd3, chd4, and chd5 have distinct and mostly non-redundant functions during cortical development that depend on their mutually exclusive inclusion within nurd complexes.
chd subunits are recruited to distinct gene promoters first, we analyzed the transcriptional profile of the developing cortex by performing microarray analysis of mrna purified from e12.5, e15.5, or e18.5 cortices (mouse wg-6 v2.0 expression beadchip illumina, n = 4 for condition).
30,869 transcripts were identified, 3,627 of which (corresponding to 2,835 genes) were differentially expressed during development (fold change of ±2 coupled with a false discovery rate [fdr] < 0.01) (figures s7a and s7b; table s2).
the transcription factors sox2, pax6, and tbr2 were of particular interest, as they were developmentally regulated (figure s7c).
sox2 and pax6 are both expressed in npcs; sox2 maintains apical progenitors in a proliferative state (graham et al., 2003), and pax6 regulates cell-cycle length of apical progenitors and ipc specification (englund et al., 2005).
tbr2 is necessary for ipc proliferation and neurogenesis (arnold et al., 2008), and ablation of either pax6 or tbr2 results in a substantial loss of cortical progenitors (quinn et al., 2007, sessa et al., 2008).
to avoid potential confounding issues due to the cellular heterogeneity of the cortex, experiments were performed on npcs maintained in vitro for 2 days or cultured in differentiating conditions for 7 days (postmitotic neurons [pmns]) (figure s4a).
binding of chd subunits to sox2, pax6, and tbr2 promoters in npcs and pmns was assessed by chromatin immunoprecipitation (chip) assay.
chd4 was bound to sox2, pax6, and tbr2 gene promoters at much greater levels in npcs than in pmns (figure 7a).
conversely, the recruitment of chd3 to the same regions was higher in pmns than in npcs, whereas chd5 binding remained unchanged.
the switch of chd4 to chd3 binding correlated with transcriptional inhibition, suggesting that, at least for these genes, the role of nurd complexes on gene expression may depend on the incorporation of specific chd subunits.
as expected, levels of sox2, pax6, and tbr2 were remarkably reduced in npcs obtained from chd4 null mice (figure 7b).
to identify putative transcription factors that may be involved in the recruitment of chd4-containing nurd complexes to target genes, we investigated whether sox2 was bound to promoters occupied by chd4.
sox2 represented an interesting candidate, as it interacts with chd4 in neural stem cells (engelen et al., 2011).
chip experiments demonstrated that similar to chd4, sox2 was recruited to sox2, pax6, and tbr2 promoters in npcs, and binding was significantly reduced in pmns (figure 7c).
strikingly, ectopic expression of hchd3 at e13.5 had an effect similar to ablation of chd4 and caused a reduction of pax6, sox2, and tbr2 expression in npcs (figure 7d), indicating that the composition of nurd complexes may represent a mechanism by which pax6, sox2, and tbr2 expression is developmentally regulated.
chd5 and chd3 binding was tested on the promoters of doublecortin (dcx) and apolipoprotein e receptor 2 (apoer2), two genes that regulate neural radial migration and cortical lamination (francis et al., 1999, gleeson et al., 1999, trommsdorff et al., 1999).
enrichment of chd5 was detected on both promoters in pmns (figure 7e), whereas chd3 binding was unchanged in npcs and pmns.
a similar result was observed when the promoter of rhoa, a gene that regulates numerous aspects of neuronal migration in the cortex (cappello, 2013), was analyzed (figure 7e).
moreover, electroporation of shchd5, but not shchd3, reduced dcx and rhoa levels in migrating cortical neurons (figure 7f).
thus, chd3 and chd5 exhibit specificity in regards to both recruitment to target genes and transcriptional regulation at these regions.
discussion during brain development, chromatin remodeling is essential for the expression of genes that regulate the differentiation of pluripotent cells into mature neurons.
a number of components of the baf (brg1- and brm-associated factors) complex, for example, undergo subunit switch during neuronal differentiation, generating unique complexes that activate specific transcriptional programs (yoo and crabtree, 2009).
in this study, we show that nurd represents a major atp-dependent chromatin remodeling complex in the developing mouse brain.
nurd has been increasingly linked with transcriptional regulation of genes necessary for cell differentiation and growth (basta and rauchman, 2015).
in addition to transcriptional repression and silencing, nurd has more complex effects on gene expression, including transcriptional activation, regulation of enhancers, and inactivation of activity-dependent genes (shimbo et al., 2013, yang et al., 2016).
one important function of nurd is to maintain progenitor cell populations and to inhibit the expression of pluripotency and polycomb-regulated genes (egan et al., 2013, reynolds et al., 2012a, reynolds et al., 2012b).
at least nine chds have been identified so far, and several have been implicated in brain functions (basta and rauchman, 2015).
chd4, for example, induces presynaptic differentiation of cerebellar granule neurons and regulates the transcription of genes necessary for establishing synaptic connectivity and neurotransmission in purkinje cells (yamada et al., 2014).
chd4 has also been shown to be responsible for the inactivation of activity-dependent genes in the cerebellum, by promoting deposition of the histone variant h2a.z at these loci (yang et al., 2016).
most chds are expressed in neurons (micucci et al., 2015); however, mass spectrometry analysis indicated that only chd3, chd4, and chd5 are associated with nurd in the embryonic cortex (figures 1 and s1).
knockdown of chd5 in the developing cortex induces severe defects of neural radial migration (egan et al., 2013).
in cortical neurons, depletion of chd5 alters the expression of neuron-specific genes, transcription factors, and, surprisingly, the baf45b subunit of the baf complex (potts et al., 2011), perhaps suggesting a functional link between two major chromatin remodeling complexes.
we found that in the brain, chd3, chd4, and chd5 undergo a developmentally regulated subunit exchange that results in the assembly of stage-specific nurd complexes (figure 1a).
importantly, deletion or inhibition of each chd has distinct effects on cortical development.
conditional deletion of chd4 induced premature cell-cycle exit of npcs (figures 2f and 2g) that led to a depletion of ipcs (figure 3d) and may have contributed to the reduced size of the cortex observed in chd4fl/fl/nestin-cre mice (figure 2a).
interestingly, chd3, chd4, and chd5 are all detected in postmitotic neurons (figure s3), yet they exert distinct and mostly non-overlapping functions.
lack of chd5 affects the early stages of neural migration (figure 4a) and induces ectopic expression of the upper layer markers cux1 and satb2 (figures 5a and 5b), whereas chd3 is necessary for the late stages of neural radial migration (figure 4c) and laminar specification (figures 5c–5f).
rescue experiments using human and mouse chds showed little functional redundancy among chd3, chd4, and chd5 (figure 6), indicating that intracellular expression of a chd protein in and of itself is not sufficient to compensate for the specific developmental defects.
hdac2 co-immunoprecipitated with all nurd subunits; however, it should be noted that loss of hdac2 is not expected to resemble the defects observed in cortices lacking chd3, chd4, or chd5.
hdac2 is part of many nuclear complexes; therefore, its effect on gene expression is not limited to its inclusion within nurd.
moreover, there is a significant functional redundancy between hdac1 and hdac2, perhaps even within the nurd complex, which can recruit both deacetylases (montgomery et al., 2009).
in contrast, we found little functional compensation among chd3, chd4, and chd5 (figure 6); thus, inhibition of only one chd is expected to induce defects that are distinct from loss of hdac1 and/or hdac2.
analysis of the remaining nurd core subunits indicated that, in many instances, their inclusion within nurd complexes is also developmentally regulated (figure s1) and may undergo developmental switch.
of note, deletion of mbd3 results in cortical defects strikingly similar to the abnormalities observed in brains lacking chd4 (knock et al., 2015), suggesting that mbd3 and chd4 may be part of nurd complexes that regulate genes necessary for determining ipc number and upper layer specification.
the majority (78%) of nurd subunits co-sediment as a complex (figures 1d and s1c); however, it is possible that at least some cortical defects depend on chds acting independently.
chd4, for example, interacts with the histone acetyl transferase p300 in thymocytes (williams et al., 2004) and regulates the expression of the γ-globin gene in an mbd2-independent manner (amaya et al., 2013).
further investigation will be needed to define whether there is an nurd-independent role for chds during cortical development.
how do nurd complexes containing different chds regulate the expression of specific genes?
chromatin remodeling factors usually lack sequence-specific dna-binding ability; therefore, nurd complexes may interact with transcription factors that mediate their targeting to regulatory elements, such as gene promoters and enhancers.
in lymphocytes, nurd interacts with the transcription factor ikaros, which mediates nurd recruitment to genes necessary for lymphoid differentiation (zhang et al., 2011), and in neuroblastoma cell lines, nurd complexes associate with ctip2 (topark-ngarm et al., 2006).
we found that in npcs, the transcription factor sox2 is recruited to promoters of chd4-target genes and that this binding decreases upon differentiation to pmns (figure 7c).
since chd4 and sox2 interact in escs (engelen et al., 2011), this represents a potential mechanism through which chd4-containing nurd complexes may be recruited to specific genomic loci.
in addition, post-translational modifications of nurd subunits may also influence the composition of nurd complexes and their recruitment to chromatin.
finally, our study highlights the potential role of nurd complexes in establishing cortical connectivity.
mutations in a number of atp-dependent chromatin remodeling enzymes have been associated with autism spectrum disorders, intellectual disability, and epilepsy (neale et al., 2012, o’roak et al., 2012, allen et al., 2013).
further studies will be necessary to determine the role of atp-dependent chromatin remodeling enzymes during the establishment of neuronal circuitry in early brain development and how alteration of their function contributes to neurodevelopmental defects.
experimental procedures animals all animal experiments were approved by the ucl animal welfare and ethical review body and carried out in accordance to appropriate uk home office licenses.
wt, nestin-cre and chd4fl/fl conditional knockout mice were of c57bl/6j background.
nestin-cre heterozygous mice were purchased from jackson laboratory (strain b6.cg(sjl)-tgn(nescre)1kln).
chd4 homozygous mice were crossed with nestin-cre heterozygous mice to obtain chd4fl/+/nestin-cre offspring.
chd4fl/+/nestin-cre heterozygous mice were intercrossed with either chd4fl/+/nestin-cre heterozygous or chd4fl/fl homozygous mice to generate chd4 null and control littermates.
whole-sample mass spectrometry hdac2-containing complexes were immunoprecipitated with hdac2 antibody, and immune complexes were eluted from the beads in elution buffer containing 0.5% progenta anionic acid labile surfactant i (aals i) (protea).
samples were digested by the sequential addition of lys-c and trypsin proteases, desalted using c-18 stagetips, and fractionated online using microscale c18 reverse-phase chromatography as previously described (wohlschlegel, 2009).
tandem mass spectrometry (ms/ms) spectra were acquired in a data-dependent manner on a q-exactive mass spectrometer (thermo fisher scientific).
peptide identifications were generated from ms/ms spectra by searching the uniprot swissprot (may 2010 release) protein database using the prolucid algorithm.
peptide identifications were filtered using dtaselect and required at least two peptides per protein and a decoy-database estimated false-positive rate of less than 5% (elias and gygi, 2007).
nsaf values were calculated for each protein in order to determine the approximate degree of enrichment of putative hdac2-interacting proteins (florens et al., 2006).
nuclear protein extraction and glycerol gradient co-sedimentation nuclear protein extraction from e15.5 cortices was carried out according to a protocol obtained from the crabtree lab (http://crablab.stanford.edu/protocolsneuronextra.htm).
extracts were run on 10%–40% glycerol gradients as previously described (staahl et al., 2013) and analyzed by sds-page.
in utero electroporation timed-pregnant mice (e13.5 and e14.5) were anesthetized with isoflurane in oxygen carrier (abbot laboratories), and uterine horns were exposed through a small incision in the ventral peritoneum.
plasmid dna solution (2–5 μg/μl), prepared using the endofree plasmid purification kit (qiagen), was mixed with 0.05% fast green (sigma) and injected through the uterine wall into the lateral ventricles of the embryos using pulled borosilicate needles and a femtojet microinjector (eppendorf).
five electrical pulses were applied at 35 v (50 ms duration) across the uterine wall at 950-ms intervals using 5-mm platinum tweezertrodes (harvard apparatus) and an ecm-830 btx square wave electroporator (harvard apparatus).
the uterine horns were then replaced in the abdominal cavity, and the abdomen wall and skin were sutured.
pregnant mice were sacrificed 24 hr, 3 days, or 5 days following surgery, and embryos were subjected to immunofluorescence analyses to study neural radial migration and expression of proliferation and laminar-specific markers.
statistical analysis data are presented as mean ± sem.
statistics for multiple comparisons was performed using either unpaired t test or one- or two-way anova followed by appropriate post-test indicated in the figure legends.
all analysis was performed using graphpad prism version 6.0 for macintosh (graphpad software) (∗ p < 0.05, ∗∗ p < 0.01, ∗∗∗ p < 0.001, and ∗∗∗∗ p < 0.0001 for all statistical analysis).
author contributions j.n.
performed most experiments and helped conceive the project and write the manuscript.
j.g.s.
performed experiments shown in figures 1c, 1d, 7d, s1, s4, and s7 and helped write the manuscript.
w.t.s.
performed the experiments shown in figure 7b.
m.m.g.h.
helped with in utero electroporation.
a.n.
performed the initial co-immunoprecipitation experiments.
w.d.b., a.a.v., and j.a.w.
performed the mass spectrometry, and r.m.
was responsible for bioinformatics analysis.
a.r.
conceived the project and wrote the manuscript.
@highlight
summary histone modifications and chromatin remodeling represent universal mechanisms by which cells adapt their transcriptional response to rapidly changing environmental conditions.
extensive chromatin remodeling takes place during neuronal development, allowing the transition of pluripotent cells into differentiated neurons.
here, we report that the nurd complex, which couples atp-dependent chromatin remodeling with histone deacetylase activity, regulates mouse brain development.
subunit exchange of chds, the core atpase subunits of the nurd complex, is required for distinct aspects of cortical development.
whereas chd4 promotes the early proliferation of progenitors, chd5 facilitates neuronal migration and chd3 ensures proper layer specification.
inhibition of each chd leads to defects of neuronal differentiation and migration, which cannot be rescued by expressing heterologous chds.
finally, we demonstrate that nurd complexes containing specific chds are recruited to regulatory elements and modulate the expression of genes essential for brain development.
