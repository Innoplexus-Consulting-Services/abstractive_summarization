indroduction subcutaneous panniculitis like t cell lymphoma (sptcl; α/β t cell subtype) is a distinct variant of cutaneous t cell lymphomas, which presents as inflammatory subcutaneous nodules and typical histology.
we hereby report a rare case of sptcl with macrophage activation syndrome, successfully treated by cyclosporine and oral steroids.
case report we report a case of a 17-year-old male presenting with chronic, recurrent febrile episodes since past 2 years associated with concomitant swelling in right periorbital region.
the fever was high grade, intermittent, not associated with rigors, and used to subside after taking antipyretics or systemic steroids for few hours or days.
the swelling on right side of face also flared following the spikes of fever, but never resolved completely even with various treatments such asantihistamines or steroids.
other significant symptoms included anorexia, pedal edema, and generalized weakness.
the patient was febrile (100.4°f), ambulatory with tachycardia (100/min), had pallor, mild hepatosplenomegaly, and pedal edema.
on mucocutaneous examination, the patient had generalized involvement (though initially he was aware of facial swelling and erythema only) in the form of indurated, firm and mildly tender subcutaneous plaques, which were confluent and ill defined at lower back, anterior neck, and legs, but were discretely palpable on upper/mid trunk and right side of face [figure 1a and c].
the plaques varied in size from 2 to 20 cm and the local skin appeared tight and infiltrated.
overlying surface showed mild brownish hyperpigmentation, superficial thin scaling, and dull erythema, especially on right cheek and periorbital region.
the erythema and swelling on face was mimicking angioedema on first look.
there were two discrete mildly infiltrated patches of scarring alopecia of about 2 cm size at occipital scalp, with sparse and easily pluckable hair over them [figure 1b].
there was no lymphadenopathy or mucosal involvement clinically.
figure 1 (a) angioedema-like swelling on face.
(b) scarring alopecia on posterior scalp.
(c) shiny infiltration on shins.
(d) six weeks after the treatment—complete resolution of the swelling the routine investigations revealed anemia (hb 8.9gm%; anisopikilocytosis and mild hypochromia in red blood cells).
the corrected reticulocyte count was 0.9%, whereas serum lactate dehydrogenase levels were high (1496; normal range < 248).
the total leukocyte counts and platelet counts were near lower range of normal (4200/µl and 1,260,000/µl, respectively), there wasneutrophilic picture (85%) and relative lymphopenia (12%), but without any atypical lymphocytes on peripheral smear.
the erythrocyte sedimentation rate was 12 mm after 1 h. antinuclear antibody titers were positive (1:32), whereas ds-dna and antiphospholipid antibodies were negative.
other investigations such as liver function test, hiv 1 and 2 elisa, hbsag, anti-hcv antibodies, blood and urine cultures, renal function test, and serum electrophoresis were noncontributory.
the fibrinogen clotting activitywas decreased (54.1; normal 200–400mg%), whereas activated prothrombine time (aptt) was prolonged (55.5 s, control 27.5), although without clinical evidence of hemorrhage anywhere.
there was presence of severe hypoalbuminemia (1.75 g/dl; range 3.5–5.2 g/dl) and hypertriglyceridemia (205 mg/dl; n<200) and increased serum ferritin (4538; normal range 7–140 ng/ml).
we kept the clinical differentials of subcutaneous panniculitis-like t-cell lymphoma (sptcl) and atypical scleredemaadultorum.
two skin biopsies were taken from back and scalp, both of which showed deep panniculitic infiltration by typical and atypical lymphocytes mimicking lobular panniculitis.
there was rimming of adipocytes by lymphocytes, which is typical of sptcl.
the dermis and epidermis were relatively spared [figure 2a–c].
immunohistochemistry revealed positive cd3 and cd8 markers, whereas cd4, cd56, and cd20 were negative [figure 3a–f].
these features suggested the diagnosis of α/β type of sptcl.
figure 2 (a) low power view (h and e; 40× magnification) showing predominantly subcutis involvement.
(b) higher magnification (h and e; 100×) showing lobular panniculitis-like picture.
(c) rimming of adipocytes by atypical lymphocytes (h and e; 400×).
(d and e) bone marrow aspiration (wright giemsa stain; d-200x and e-400x) showing hemophagocytosis figure 3 immunohistochemistry panel showing cd4 and cd 20 (figure 3b and 3c respectively) with cd3 and cd8 positivity (figure 3a and 3d, 3e, 3f respectively) bone marrow aspirate showed evidence of increased number of macrophages engulfing erythrocytes, platelets, and erythrocyte precursors (hemophagocytosis) [figure 2d and e].
computed tomography (ct) scan of chest revealed moderate pleural effusions with small patchy lower lobe infiltration.
contrast enhanced ct abdomen found mild ascites and mild hepatosplenomegaly but no space occupying lesions or lymphadenopathy.
mri brain and paranasal sinuses were normal.
persistent high-grade fever, hepatosplenomegaly, hypoalbuminemia, pancytopenia, raised activated prothrombin time, hypo-fibrinogenemia, increased serum ferritin, hypertriglyceridemia, and evidence of hyperactive macrophages on bone marrow aspirate suggested the features of macrophage activation syndrome in our patient.
the patient was started on oral prednisolone (1mg/kg/day), and oral cyclosporine (2mg/kg/day; 100 mg) was added after initial two weeks.
the plaques and fever started subsiding within 1 week of adding cyclosporine to the regimen and almost completely resolved in about 6 weeks.
the patient is being followed up carefully while prednisolone is being tapered slowly (now 10 mg prednisolone once daily plus oral cyclosporine 100 mg once a day).
steroid-induced acne are prominent, otherwise no major clinical or biochemical adverse effects have been encountered [figure 1d].
a repeat biopsy from chest (previously involved site) performed after 3 months showed no features of panniculitis or atypical lymphocytes.
after 7months of treatment, he is symptom free and without any palpable skin lesion or systemic features.
discussion sptcl is a distinct variant of cutaneous t-cell lymphomas, which presents as inflammatory subcutaneous nodules, lobular panniculitis with adipocyte rimming by atypical lymphocytes, and cd3+ cd8+ cd4- cd56- immunohistochemistry profile.
[1] the γ/δ t-cell variant (cd3+ cd4− cd8− cd56+/−) has a much more aggressive behavior especially in adults and does not respond as readily to immunosuppressive therapy or chemotherapy as the α/β t-cell subtype.
[2] in fact, many authors keep out γ/δ t-cell variant from the designation of sptcl.
progressive cases or with concomitant systemic complications such asthe present case (hemophagocytosis) should be offered definitive treatments.
[34] facial swelling as the presenting feature of sptcl has been mentioned by other authors as well.
[56] any atypical skin lesion with apparent subcutaneous inflammatory component should include differential of sptcl.
[5] rarely, sptcl could also imitate dermatomyositis by displaying heliotrope rash as well as proximal muscle weakness.
[7] our case had generalized induration of skin on trunk and limbs suggesting a clinical differential of scleredemaadultorum, although the induration was patchy at places.
the present case displayed characteristic lobular panniculitis-like infiltration by atypical lymphocytes around the adipocytes.
important histopathological differentials include lupus panniculitis, in which the features can be so closely overlapping with sptcl that a spectral continuum has been proposed between them.
[8] in our case, serum antinuclear antibody positivity provided some credence to the possible histological differential of lupus panniculitis; however, the immunophenotyping studies concluded the diagnosis in favor of α/β sptcl.
although anthralin-based chemotherapy has been the most commonly used regimen for sptcl previously, watchful wait, systemic corticosteroids, or other immunosuppressive agents are now the preferred treatments in uncomplicated cases.
several refractory as well as naïve cases of sptcl (with or without hps) have been successfully treated and kept in long-term remissions by cyclosporine alone or with other immunosuppressive agents.
[9101112] we combined high-dose oral steroids with cyclosporine to control the severe systemic symptoms (persisting high-grade fever and hps).
macrophage activation syndrome (mas) has been previously also described in association with sptcl in adults and children.
[13] the presence of mas or hemophagocytosis (hps) might change the management approach and outcome in sptcl.
[14] one study reported 5-year overall survival rates of 91% and 46% in sptcl patients without and with an hps, respectively.
[1] in sptcl without associated hps, careful observation, systemic steroids or other immunosuppressive agents could be considered first, whereas in cases of solitary or localized skin lesions, radiotherapy with electrons is advised.
bexarotene has also been found to be effective in sptcl.
multiagent chemotherapy can be reserved for the cases with progressive or resistant disease or in cases with hps.
[1] some cases had benefit from hematopoietic stem cell transplant following chemotherapy.
[15] in our case, all the parameters including hps and cytopenias improved with steroids and cyclosporine.
conclusion the present case displayed interesting clinical and histological features of sptcl and was successfully treated by oral steroids and cyclosporine.
declaration of patient consent the authors certify that they have obtained all appropriate patient consent forms.
in the form the patient(s) has/have given his/her/their consent for his/her/their images and other clinical information to be reported in the journal.
the patients understand that their names and initials will not be published and due efforts will be made to conceal their identity, but anonymity cannot be guaranteed.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
subcutaneous panniculitis-like t-cell lymphoma (sptcl; α/β t-cell subtype) is a distinct variantof cutaneous t-cell lymphomas, which presents as inflammatory subcutaneous nodules.
a 17-year-old male presented with recurrent fever with concomitant facial swelling, pedal edema, hepatosplenomegaly, and mildly tender subcutaneous plaques in generalized distribution along with patches of scarring alopecia on scalp.
there were features of macrophage activation syndrome in the form of hemophagocytosis in the bone marrow, pancytopenia, high serum lactate dehydrogenase levels, low fibrinogen clotting activity, prolonged activated prothrombine time (aptt), increased serum ferritin, hypoalbuminemia, and hypertriglyceridemia.
histopathology showed lobular panniculitis-like infiltration by atypical lymphocytes rimming the adipocytes.
immunohistochemistry revealed positive cd3 and cd8 markers, whereas cd4, cd56, and cd20 were negative, consistent with the diagnosis of α/β type of sptcl.
treatment with oral prednisolone (1mg/kg/day) and cyclosporine (2mg/kg/day; 100 mg) led to rapid subsidence of fever, plaques, and abnormal hematological parameters within a few weeks.
