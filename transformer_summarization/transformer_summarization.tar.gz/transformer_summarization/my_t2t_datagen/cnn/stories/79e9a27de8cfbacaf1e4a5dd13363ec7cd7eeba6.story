introduction due to advancements in technology and the emergence of innovative technology in the field of infertility, currently few spouses are unable to fulfill their aspirations to produce children.
although these methods are efficient, they raise many juridical questions.
answering these questions impacts the quality and methods of treatment.
one of these problems is that physicians encounter multiple pregnancies.
this possibility increases as a result of ovarian stimulation and infertility treatments.
recent decades show these statistical trends where, from 1980 to 2009, only in america have the numbers of twins or triplets increased to 76%, an increase from 18.9 to 33.3 for each 1000 births (1).
a risk of multiple pregnancies exists both for the mother and the fetuses.
hence, selective reduction of the fetuses is a strategy suggested by physicians.
the aim of this paper is to investigate the permissibility or impermissibility of fetal reduction from the shiite view.
however, it is necessary to define selective reduction or multifetal pregnancy reduction (2).
the meaning of selective reduction is the removal of one or several fetuses in a pregnancy that has greater than one fetus with the intent to achieve a pregnancy with twin fetuses or one fetus.
in this step, the physician aborts the surplus fetuses that have been implanted to the patient’s womb to increase her chances of fertility or these fetuses formed because of stimulating drugs that caused the release of several ovules.
one method has been used for more than two decades to prevent morbidity (3).
usually, this method requires injection of potassium chloride (kcl) into the heart of one or more fetuses (4), among other methods.
before investigating the ordinance of different features of reduction, it is necessary to clarify the general ordinance that pertains to the shia regarding reduction of fetuses.
materials and methods this analytical-descriptive research was undertaken at imam sadiq university in october, 2015. we reviewed a number of islamic resources about the fetus, its life, and conducted a bibliography study on the basis of medical and legal resources.
the resources included books, articles, and internet sources.
the study was based on comparative and annalistic studies.
this analytical-descriptive research gathered relevant data in the form of a literature search.
after a description of the fundamentals and definitions, juridical texts were subsequently analyzed and the order of reduction inevitably determined by taking into consideration the rules that governed the abortion provisions or general juridical rules and principles which exist in islamic sources.
finally, we compared the shiite perspective with the uk law.
in some cases reduction is permitted according to islamic instructions.
in the current research we sought to enumerate the cases permitted by islam.
we have determined the criteria for selection of the fetuses for the reduction process by investigating the primary ordinance of islamic jurisdiction.
the primary ordinance is introduced beside the secondary ordinance.
it is an ordinance that law makers will generate according to the discretion and the loss that has originated in the issue, such as prohibition of wine or murdering.
the secondary ordinance is an ordinance issued when there is an emergency, loss, or necessity such as removal of the ordinance of prohibition of wine at the time of an emergency (5).
the second ordinance is studied according to the relationship of the conditions that the reduction has suggested.
results a study of the permissibility of multifetal pregnancy reduction is dependent upon investigation into the primary and secondary ordinances of fetal reduction followed by the jurisprudence position.
in each case of embryo reduction the conditions should be defined.
criteria for selection in fetal reduction and conducting a comparative study of the shiite perspective versus uk law were the final steps to remove possible legal gaps in this area.
investigation about the primary and secondary ordinances of fetal reduction fetal reduction and abortion have one consequence-cessation of a life.
however in fetal reduction, unlike abortion, the pregnancy is not terminated.
hence it seems that specifying the first and second ordinances of abortion would be sufficient.
hence, we can transmit this ordinance to fetal reduction which is a new phenomenon.
primary ordinance in view of imamiyah jurisdiction, the fetus is a respectful existence.
the quran as well as the prophet and imams (pbut) behavior that are defined as "tradition, logical reason, and consensus" state that abortion is illegal.
according to imamiyah jurisdiction, even "blood money" is defined for the seed of a human being (sperm) prior to entry into a woman’s womb (6,7).
then, this sum of money differs when the fetus grows in the mother’s womb where five stages (seed, clot, lump, bones, and bone clothed by flesh) are defined (7).
therefore, abortion is not permitted in islam.
according to verses 12 to 14 of sura al-mumenoon in the quran, fetal life includes two basic stages: i. from the beginning of combining the ovule with the sperm until ensoulment (the time when the fetus possesses a sprit) and ii.
from ensoulment until birth.
there is no unique belief about the time when a fetus possesses a spirit.
in the view of most jurisdictions, when the embryo is in the fourth month, he or she possesses a sprit (8).
in the first stage before ensoulment the fetus is similar to a plant rather than a human being.
however, its killing is taboo according to narratives.
in the second stage, killing of the fetus is also taboo.
although there is no difference among the shia about the illegality of an abortion after ensoulment (9), its reasons are various.
some jurists, according to surah al-anaam verse 151 of the quran (8,10), consider the fetus to be human.
in this case, an abortion is regarded as a murder and meets the criteria for retaliation (11,13).
in this verse allah says: "you do not kill the soul which god has sanctifiedexcept in the course of justice".
others deny this justification and retaliation against abortion.
they believe that abortion is illegal because according to certain narratives (14), the blood money of a fetus after ensoulment is equal to a human.
this group claims that the mother’s and fetus’s lives are the same and there is no preference between them.
other justifications have been mentioned about the illegality of abortion.
each contains impediments.
the authors (as some jurists have said) believe that the mentioned reasons are not acceptable for proving equality between the mother’s and fetus’s lives.
this statement is also confirmed by the fact that jurists prefer the mother's life when the her life conflicts with an abortion.
in this case the abortion is permitted.
if the value of the fetus’s and the mother’s lives are equal, there is no rationale for this judgment.
on the one hand, what is said in the quran cannot be true about a fetus since it is talking about murdering a human.
on the other hand, the equality of blood money for the mother and fetus cannot prove the similarity between a mother and a fetus.
therefore the only justifications about the illegality of abortion are what our imams have said in the narratives.
after all, abortion is illegal and taboo in shia where there is a consensus.
abortion is taboo is enough to prove that despite specified cases, abortion is not permissible in other cases.
logical thinking also prohibits oppression and it is likely to say that abortion is a type of oppression.
abortion is a form of aggression toward a person who cannot defend himor herself (15).
according to islam, the fetus is respected from the beginning because of its genesis and it enjoys the right to life.
agreement of the spouse is not enough for fetus reduction.
creation of the fetus is the result of parental sexual flow and not enough to allow them to destroy the fetus after reproduction.
although fetus reduction in islam is prohibited, some cases known as secondary ordinances are permitted as discussed below.
secondary ordinance although abortion is taboo in islam, it is permitted in cases of emergency, hardship, and loss.
islamic jurisdiction has defined two specific cases in which abortion is permitted.
first, when maintaining the fetus endangers the mother’s life.
this case is known as "tazaahom" means the possibility of gathering two ordinances simultaneously while they are in existence but there is an inability to obey both ordinances (16).
the ordinance "necessity to protect the mother’s life" contrasts the ordinance of "necessity to protect the fetus’s life", as the mother’s life is more important than the fetus’s life.
therefore the mother’s life is preferred (17) because the mother is a real human being whereas the fetus is potentially a human.
this preference is enough to save the mother’s life.
likewise, crimes against the mother deserve "retaliation" whereas those against the fetus deserve "blood money".
this is the reason that the mother's life is preferred (15).
other reasons, for example, consider abortion to be a means of self-defense for the mother.
according to the defense theory, saving the mother’s life is preferred, because if the mother dies, the fetus will also die (18,19).
of note, in cases where the survival of the fetus results in birth defects or intolerable pain for the mother and protecting the fetus outside of the womb is not possible, the following rules (a and b) permit abortions as tolerating this loss is difficult for the mother (20).
rule a states: "juridical regulation of negating difficulties and troubles".
this rule says that whatever causes a problem or risk is negated by islamic law makers.
the best evidence comes from verse 87 of surah almumanoon in the quran: "there is no difficulty in your religion" (21).
rule b is the "rule of negation of loss".
the contingency of this act is that no man is permitted to cause loss to others in order to prevent his own loss.
it is not permissible to cause loss to him to prevent loss to others (22).
the second case occurs when the fetus is deformed and defective.
in such cases, since the birth of a deformed baby will create a severe hardship for the parent, abortion is permitted before ensoulment.
however another perspective exists.
according to this view, although tolerating an illness is difficult, it is a "test" for the parents and the fetus.
according to islamic view, allah tests his slaves (verse 145 of surah al-baqara) (23).
then, as killing patients and defective people is not permitted, killing a defective fetus is also not permissible.
permission to kill the fetus in such cases is limited to the stage where the fetus does not have a spirit.
after ensoulment, as this act considers the rights of all assignees, one cannot derive a benefit for someone (mother) and cause loss for others (fetus) (15,20,24).
therefore, it should be considered that in all cases where selective reduction is permitted, this permission is limited to the stage where the fetus does not possess a spirit.
after this stage, fetus reduction is illegal with the exception of tazaahom.
by taking into consideration the abovementioned, if cases of multiple fetuses where continuation of pregnancy causes any hazard for the mother, the fetus reduction is considered secondary and it is not necessary to obtain the husband’s permission.
to the extent possible, the number of transferred fetuses should be minimal so that selective decrease of fetuses will be unnecessary.
in order to prevent multifetal pregnancy, the number of transferred fetuses should be minimal or small doses of medication (stimulating drugs that caused the release of several ovules) should be prescribed.
however this will decrease the chances of fertilization.
for example, if after ovary stimulation, more than three follicles have matured, the cycle should be cancelled at both ovaries to prevent multiple pregnancies.
in assisted reproductive technology (art) implantation, fewer fetuses are recommended.
in elective single embryo transfer (eset) it is recommended to choose only one high quality fetus.
unfortunately, the high cost of infertility treatment and small success rate result in the implantation of multiple fetuses in the mothers’ womb to increase the chances of childbirth (25).
in this regard, to counteract, some countries have approved acts in which under any circumstances, it is not permissible to transfer more than one fetus by the physicians (26).
however, the duration of treatment following the implantation of one fetus and high treatment cost encourage the implantation of more fetuses.
even in cases where the transfer of more than one embryo to the mother’s womb is justifiable, it is clear that most mothers prefer not to be faced with reduction of the fetuses.
in such cases the mothers may encounter extreme psychological problems because of the length of time spent waiting to have children (27).
in such cases, embryo implantation should be completely controlled in a way that the possibility of multiple pregnancies decreases.
when fertility centers compete to attract more patients and increase the rate of fertility and their own success, it is necessary to prevent them from misusing patients by persuading them to implant more embryos, after which reduction of the fetuses becomes necessary.
defining the position of jurisprudence for each case of embryo reduction by taking into consideration the conditions considering the risk of continuation of multiple pregnancies for fetuses, jurisprudence have posed the following assumptions (28).
1 the conditions that reduction of embryos will not endanger the mother’s life for continuation of pregnancy and the fetuses do not have any defect and no damage entreats them.
in these cases, fetal reduction is illegal.
physicians and well-informed parents are persecuted for their civil and penal responsibilities.
hence, reduction of fetuses in cases where there is no risk for the mother or the fetus is not permitted.
the general ordinance of fetus reduction is considered.
as previously stated in the primary ordinance, according to islam, the fetus is respected from the beginning of its genesis and it has the right to live.
therefore abortion and reduction are illegal.
2 during the pregnancy, the medical test shows the existence of abnormalities.
in this case, reduction is approved in some fetuses.
in such cases, the fetus deficiency is the reason for reduction.
after approval of damage and hardship for the parents, an abortion is permitted according to the criterion of the secondary ordinance because the juridical evidences of prohibition of abortion do not include these cases according to some jurisprudence (15).
3 continuation of multiple pregnancies is dangerous for the fetuses.
according to resources, cases where a deficiency in the fetus is the reason for reduction are defined as "selective termination of pregnancy" whereas cases that the reason of reduction is the risk for mothers and fetuses are called "fetal reduction of multiple pregnancies" (29).
cases where reduction of the fetus is chosen as a guarantee for healthiness of the pregnancy have different ordinances according to whether multiple pregnancies occurred naturally or by implantation and the physician.
natural multiple pregnancies occur when the number of fertilized ova are more than one or when there is a mutation in embryo’s cells during division.
artificial multiple pregnancy occurs when the physician decides to implant several fetuses as a cure for infertility.
the physicians, after receiving permission from the patient, stimulate the ovary with medications or implant several fetuses into the womb.
then, permission of reduction of the fetuses under two conditions is assumed.
for example, multiple pregnancies are natural and preservation of surplus embryos endangers the lives of all embryos.
here, keeping each embryo conflicts (in the exact meaning of tazaahom) with the lives of the others.
because the situation is equal for all, the priority of one embryo over the others is considered “preference without any logical reason”.
preference without any logical reason means that one thing is preferred over the other in instances where both have equal features and without any special goal.
this is an impossible issue.
most philosophers assume this is a reasonable rule and obvious, in a way that obviousness is evident such as the "premise of unity is half of two" (30).
in such cases no embryo is preferred over another.
in such cases one cannot delay and endanger the life of all fetuses.
so, referring to the jurisprudence rule of "al-maysoure la yasqoto bel-masoure" we cannot eliminate all embryos.
inevitably we should act according to an acceptable criterion.
according to this rule, when someone is obliged to do something, he or she should do it according to his or her capabilities.
it is mentioned as "what one cannot do completely, he should not abandon it completely" (31).
in another interpretation, the lawmaker orders to something that is composed of several parts, and some parts have obstruction and some parts do not.
in cases where the parts do not have any obstruction, they should not avoided (32).
in the second situation where multiple gestation is artificial and maintaining all the embryos would endanger the lives of all embryos.
in this case, continuing with the pregnancy is a conflict between the mother’s life and multiple synthetic pregnancies, which has emerged as a result of the decision of the parents.
this can induce doubt that this agreement is subject to the legal rule of "emergency optionally does not negate arbitration".
the purpose of this rule is that of someone who is obliged engages in a taboo activity, in a way that he or she cannot act according to the rule.
regarding that his inability to perform the task that has been caused by incorrect disposal (conscious possession), his or her responsibility will not decrease (21).
in this way, by an incorrect decision, the mother’s situation is so that she cannot preserve her fetus.
thus, fetal reduction is not possible for her.
if she does so, she will be prosecuted.
we can say that conscious multiple pregnancies will put her in a situation that cannot defend herself against the emergency of abortion.
in response to this question it is accepted that "regarding legal reasons and principles, if the situation of a person is a result of an adverse selection, this situation puts him out of the emergency, whereas in such circumstances it is impossible to have a bad choice" (28).
it should be added that, according to the aforementioned rule, the distinction between "those emergency situations that cause irresponsibility" and "avoidance willfully" is that the person with the bad choice cannot fulfill her duties, whereas in multiple pregnancies the physician and parents try to achieve the best results for the treatment of infertility.
in this case, as with the first one, reduction of the fetuses is permitted unless the mother is in a position in which she is forced to reduce the fetus because of her previous adverse possession.
even when the parents demand implantation of more embryos to enhance the chances for fertility, it is the responsibility of the physician to implant fewer embryos to avoid fetal reduction.
implantation of surplus embryos by the physician is the exact case for adverse selection that results in prohibition of the fetus reduction.
of note, according to the fact that the result of both fetal reduction and abortion is the same (fetal deaths), fetal reduction (which is fully justified medically) is legally permitted in countries where abortion is not illegal, even without any medical reason.
criterion for selection in fetal reduction the reasons for permission of reduction of the fetuses include: deficiency, importance, ease, random choice, parents’ right, and governmental ordinance.
according to the deficiency criterion in cases where reduction of the fetus is necessary, if a fetus is defective, this fetus would be the goal for reduction.
this case has been discussed previously.
importance.
in terms of the ordinance that each fetus is preserved by reduction of another fetus, these ordinances conflict (in the exact meaning of tazaahom) with each other because a pregnant women should choose one of two ways: i. keep all fetuses which ultimately results in the deaths of all the fetuses or ii.
reduction of some fetuses that ends in the deaths of those fetuses and continuation of pregnancy for the other fetuses.
when there is a conflict (in the exact meaning of tazaahom) between two or more discretions, it is important to consider the most important discretion (33).
in order to enforce the rule of the most important discretion it is supposed that if it is possible to predict the importance of survival of one fetus over the others, the protection of that fetus is preferred (28).
in cases that there is a considerable defect or deformity in the fetus compared to the others, the criterion is to reduce this fetus and keep the others.
however the meaning of defection is not those defections that lawmakers have issued regarding the rule of reduction, but the purpose is that some fetuses are less healthy.
realization of such criterion is the decision of the physician.
ease.
this criterion is defined as "regarding the risk of reduction of the fetuses, when the above criteria are not met, the fetus that its reduction is easier will be chosen for the purpose of reduction".
the assumption that the criterion of ease as an independent criterion comparing importance is not true.
the reason is that the ease of reduction of one fetus over the other fetus in fact is the criterion of choosing the most important one.
therefore, we cannot think of the ease criterion as an independent criterion.
this criterion depends on the specialist perspective.
random choice or parental rights.
if the conditions are equal, choice of one fetus over the others is a preference without a logical reason.
if the above conditions are not met, the physician or the parents can select the fetus for reduction just by random selection (lottery) or "absence of constraints rule".
the meaning of "absence of constraints rule" is that in cases where no difference exists between two affairs and one is not preferred over the other and there is no possibility of collection of those two affairs, then the person who is obliged to choose is free to choose according to wisdom (16).
the jurisprudence perspectives differ regarding random choice and picking up.
according to recent perspective, the parents are free to choose the gender of the fetus, but it seems that random choice is more common among jurisprudences (34,36).
of note, the number of reductions is a specialized issue and the parents can only comment about the choice.
therefore, the parents’ demands for reduction of more fetuses to reach one fetus pregnancy is not acceptable.
of course, choosing according to gender can cause serious ethical and even legal challenges in the field of gender discrimination.
in other countries, this issue is also considered and although the parents have the right to choose the gender of the fetus when they are deciding to reduce the number of fetuses, considering other discretions such as the necessity of gender balance in society is accounted as an obstruction for the right of choosing according to gender (37).
governmental criterion.
those previously mentioned criteria refer to the situations where the governor (religious ruling) did not order any writ.
protection of public rights makes governments ignore individual discretion.
if the governor orders any writ, none of these criteria will be enforced.
one example of such cases is that the number of genders is not equal.
this issue causes many problems.
therefore, selecting gender to stabilize the society is chosen by the government (38).
in cases that the doctor legally allowed elimination of one or more embryos in multiple pregnancies, deficiency in the fetuses (if one is defective) and importance (if there is any reason to prefer one fetus) can be criterions for selection of the goal of reduction.
if the conditions of all fetuses are equal, the parents or the physician choose the fetuses by lottery or by picking them up (absence of constraints rule).
each perspective has its own devotees.
of note, if parents are permitted to choose, the recognition of the number of reductions is due to the physician.
it seems that to prevent parents and physicians from misusing this situation in favor of single fetus pregnancy, passing an act by lawmakers is necessary.
comparative study (shiite perspective versus the uk law) the first references to abortion in uk law appeared in the 13thcentury.
the law followed the church’s teachings that abortion was acceptable until ‘quickening’ (which, it was believed was when the soul entered the fetus).
in the ellenborough act (1803), the punishment of abortion after ‘quickening’ (i.e., when movement is felt at 16-20 weeks) was the death penalty although previously the punishment had been less severe.
the legal situation remained the same for centuries.
in 1861 (the offences against the person act), this penalty was reduced to life imprisonment.
in 1929, infant life preservation act created a new crime of killing a viable fetus (at that time fixed at 28 weeks) in all cases except when the woman’s life was at risk.
these laws caused thousands of women to resort to back-street abortions to prevent unwanted pregnancies or the need for abortions which led to permanent damage or death.
for example, in 1923-33, 15% of maternal deaths were due to illegal abortions.
in 1936, the abortion law reform association (alra) was established with the aim to campaign for the legalization of abortion.
in 1967, the abortion act sponsored by david steel, mp became a law and came into effect on april 27, 1968. this act legalized abortion under certain conditions.
in 1990, the 1967 act was amended by the human fertilization and embryology act, which reduced the original time limit of 28 weeks to 24 weeks for most abortions (39).
currently, abortion is legal on a wide number of grounds in england, wales, and scotland since the abortion act of 1967, which is one of the most liberal abortion laws in europe.
grounds for abortion under this act include: i. situations where the continuance of the pregnancy would involve risk to the life of the pregnant woman greater than if the pregnancy were terminated, ii.
termination is necessary to prevent grave permanent injury to the physical or mental health of the pregnant woman, iii.
the pregnancy has not exceeded its 24thweek and continuance of the pregnancy would involve risk, greater than if the pregnancy were terminated, of injury to the physical or mental health of the pregnant woman, iv.
pregnancy has not exceeded its 24thweek and continuance of the pregnancy would involve risk, greater than if the pregnancy were terminated, of injury to the physical or mental health of any existing children of the family of the pregnant woman, v. there is a substantial risk that if the child were born it would suffer from physical or mental abnormalities as to be seriously handicapped, vi.
to save the life of the pregnant woman, and vii.
to prevent grave permanent injury to the physical or mental health of the pregnant woman (40).
in 1999 approximately 8000 women who lived abroad travelled to england to have an abortion (41).
the law that regulates selective reduction is contained in four separate statutes: offences against the person act 1861 (oapa), infant life preservation act 1929 (ilpa), abortion act of 1967, and human fertilization and embryology act of 1990, section 37 (5) which amended the provisions of the abortion act sensibly to legalize the practice of selective reduction.
with the exception of the 1990 act, when these laws were framed, it was impossible to imagine that one or more fetuses might be destroyed, allowing others to survive to term.
section 58 of the oapa prohibits the performance of an act "with intent to procure the miscarriage of a woman with child" (42).
in a comparison between the uk law and shiite perspective, two points can be made.
first, it is clear that in the uk the cases in which abortion is allowed are much more than allowed by shia law.
according to the shia law, as previously mentioned, only the mother’s survival and fetus’s disability are the examples of harm that justify abortion.
while in the first chapter of the abortion act of 1968 in the uk, mental or physical health of the mother or other children in the family are permissions for abortion.
generally it can be claimed that by the year 1929 the english parliament had a penal view toward abortion and the maximum protection was devoted to the fetus.
however, the future laws, especially in 1990, legislations have preferred the mother’s life to the fetus.
in shia, the mother’s life preference over the fetus’s life is only legitimate when mother’s life would be at risk with continuation of pregnancy.
therefore, the shia’s point of view is closer to the former english laws.
the reason can be the effects of religion on these former regulations and the further amendments have followed the aim of decreasing illegal abortions and its fatal results.
second, despite the different perspective about abortion mentioned above, it is important to note that reduction of fetuses is specified in english law while shia resources have not discussed it as a treatment.
the authors of this article have attempted to determine the regulations of reduction in shia books and their general principles and rules (such as abortion rules).
therefore, this issue should be studied by shia in detail and the result should be passed as a law.
however, no important contrast can be seen between shia and english points of view about reduction.
two reasons prove this claim.
first, treatment and saving other fetuses are the basic goals in reduction.
second, the main difference between shia and english view in the field of abortion concerns the mother’s and other children’s mental and physical health.
however mental and physical health has no place in reduction.
discussion briefly, arbitrary choice is a strategy that the physicians suggest to eliminate the danger of multifetal pregnancy for mothers and the fetuses, that cause failure of the pregnancy.
the aim of arbitrary choice is to reduce the number of fetuses to only one or two.
any order is not provided specifically about the criteria for embryo reduction in juridical sources.
therefore, it will inevitably be determined by the rules that govern abortion provisions or general juridical rules and principles which exist in islamic sources (in primary and secondary ordinances).
the primary ordinance of intentional death of a fetus in shiite view is sanctity and its prohibition.
however if there is an emergency, loss or hardship for the mother, the ordinance is secondary.
as some jurists have stated, reduction of the fetuses before ensoulment of the fetus is permitted (10,14), but the authors believe that when the fetus endangers the mother’s life, there is no different between before and after ensoulment.
the jurisprudence position in each example of fetus reduction defines reduction according to three premises: i. the conditions that multiple pregnancies will not entreat the mother or continuation of pregnancy and the fetuses are free of deficiency and there is no risk for them.
in such cases reduction of embryos is forbidden, ii.
some of the fetuses are defective where, according to the secondary ordinance, reduction is permitted, and iii.
continuation of multiple pregnancies has risks for the fetuses.
such case raise the following assumptions: in a natural multiple pregnancy, if protection of the surplus fetuses endangers the life of all fetuses, we cannot act according to the lack of preference and cause the death of all fetuses.
therefore we should act according to an acceptable criterion.
in artificial multiple pregnancies, the physicians are obliged to reduce the number of fetuses to avoid the situation of reduction, otherwise reduction of the fetuses is not permitted.
if they do so, they will be prosecuted.
a comparison between english and shia rules about abortion and reduction indicates that in england abortion is more widely accepted and apart from mother survival or fetus disability, the mother’s or other children’s mental and physical health can justify abortion.
however, the shia consider abortion cases other than mother survival or fetus disability to be forbidden and taboo.
disregarding this difference, reduction by the aim of saving other fetuses is permitted in both systems and similarities can be seen in this field.
conclusion in an emergency situation, reduction of the fetuses is permitted.
to choose the goal of reduction, the criterion is defection in fetuses or importance.
the importance means if there is a reason to protect one fetus, (for example one of them is healthier); the other fetuses will be the goal of reduction.
if the conditions are equal, the parents or the physicians can choose the fetus.
it is noteworthy that if the choice of parents is permitted, choosing the number of them is due to the physician’s discretion.
finally the ordinance of the government and the existence of a rule are superior to other rules.
lack of any resource about various aspects of reduction (such as legal, moral and jurisprudence) is one of the most important limitations of this study.
therefore, an investigation into the relevant provisions of reduction in details such as civil liability of the physician and medical staff in embryo transfer or fetal reduction can be a suitable topic for future research.
@highlight
background advancements in medical technology have significantly increased the possibility of successful infertility treatment.
medical interventions in the initial process of pregnancy that intend to increase the chances of pregnancy create the risk of multifetal pregnancies for both mothers and fetuses.
physicians attempt to reduce the numbers of fetuses in order to decrease this risk and guarantee the continuation of pregnancy.
the aim of this paper is to understand the shiite instruction in terms of the risks multifetal pregnancies have for fetuses and if it is permissible to reduce the numbers of fetuses.
an affirmative answer will lead to the development of islamic criteria for reduction of the number of embryos.
materials and methods this analytical-descriptive research gathered relevant data as a literature search.
we reviewed a number of islamic resources that pertained to the fetus; after a description of the fundamentals and definitions, we subsequently analyzed juridical texts.
the order of reduction was inevitably determined by taking into consideration the rules that governed the abortion provisions or general juridical rules.
we also investigated the uk law as a comparison to the shiite perspective.
results the primary ordinance states that termination of an embryo is not permitted and is considered taboo.
however, fetal reductions that occur in emergency situations where there is no option or ordinary indication are permitted before the time of ensoulment.
the goal of reduction can be chosen from different ways.
conclusion according to shiite sources, fetal reduction is permitted.
defective fetuses are the criteria for selective reduction.
if none are defective, the criteria are possibility and facility.
but if the possibility of selection is equally for more than one fetus, the criterion is importance (for example one fetus is healthier).
