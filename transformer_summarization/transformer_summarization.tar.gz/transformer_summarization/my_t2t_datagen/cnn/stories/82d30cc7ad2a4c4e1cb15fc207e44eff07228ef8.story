introduction griscelli syndrome (gs) is an autosomal recessive multisystem genetic disorder of partial albinism along with neurological and/or immunological defects.
it was first reported by griscelli et al.
in two unrelated patients in 1978.
[1] three different types are caused by defects in three different genes.
the products of these three genes work closely together in the transport of melanocyte.
characteristic hypopigmentation is a common feature among individuals with gs1, gs2, and gs3.
till date around 80 case reports have been described in the literature.
case report a 9-year-old boy came to skin department with the complaint of lightening of skin and hair since infancy.
there was no history of fever, jaundice, abdominal pain, convulsions, or photosensitivity.
he was born out of nonconsanguineous marriage, with uneventful antenatal or perinatal period.
his physical development was normal.
his younger sibling had no similar complaints.
on cutaneous examination he had silvery gray (leaden) hair [figure 1], eyebrows, and eyelashes.
bronze tan hyperpigmentation over fair skin was noticed on face and other exposed sites [figure 2].
teeth and nails appeared normal.
systemic examination was insignificant.
there was no hepatosplenomegaly, and central nervous system, respiratory and cardiac system examination was within normal limits.
ophthalmological examination did not reveal any abnormality.
figure 1 silvery gray hair figure 2 bronze tan hyperpigmentation over extremities his investigations revealed normal hematological profile and normal immunoglobulin levels.
on light microscopic examination of hair, uneven clusters of aggregated melanin pigment, accumulated mainly in the medullary area of the shaft was seen instead of the homogeneous distribution of small pigment granules as seen in normal hair [figure 3].
skin biopsy showed increased deposition of melanosomes in melanocytes in the dermal layer with poorly pigmented adjacent keratinocytes.
figure 3 uneven clusters of aggregated melanin pigment in medullary area of hair shaft x20 on the basis of clinical presentation, absence of neurological and immunological abnormality, and characteristic microscopic findings of hair shaft and skin, patient was diagnosed as griscelli syndrome type 3. discussion gs also known as “partial albinism with immunodeficiency” was first described by griscelli and siccardi in 1978. gs is very rare in almost all populations, although most cases have been reported from turkish and mediterranean populations.
it is an autosomal recessive disorder resulting in pigmentary dilution of the skin and hair with the presence of large clumps of pigment in hair shafts due to accumulation of melanosomes in melanocytes.
the transport of melanosomes from the cell center to cell periphery involves a bidirectional transport.
this transport takes place along microtubule tracks with the help of the motor proteins, dyneins, and kinesins.
myosin va (myo5a), which is a processive motor protein, attaches to melanosomes through interaction with mlph and rab27a.
the tripartite complex, which is composed of rab27a, mlph, and myo5a, has roles in vesicle transport and membrane trafficking processes.
[2] if any member of the tripartite complex is defective, melanosome transport is impaired.
melanosomes are not captured in the periphery, not transferred from melanocytes to keratinocytes, and perinuclear accumulation of melanosome occurs.
this results in skin hypopigmentation and silvery gray hair.
molecular studies have revealed mutations within each member of the tripartite complex causing the three main types of gs.
all the 3 types present with pigmentary dilution, that is, silvery gray hair, pale skin with persistent capacity for tanning when sun-exposed, and ocular alterations secondary to pigment diminution.
although phenotypically similar, prognosis of each type varies depending on neurological or hematological findings.
type 1 gs presents with severe primary neurological impairment in the form of severe developmental delay, muscular hypotonia, and mental retardation occurring early in life.
[3] it results from mutations of the myosin 5a gene (myo5a), which encodes an organelle motor protein, myosin 5a (myova), and has a determining role in neuron function.
gs2 is caused by mutations in the gene encoding the small gtpase rab27a.
[4] rab27a-deficiency causes defects in the exocytosis of cytotoxic granules from t cells and natural killer (nk) cells (accounting for an impaired cytotoxicity) and melanosome exocytosis.
a history of severe infections, absence of delayed type cutaneous hypersensitivity, hypogammaglobulinemia are all characteristic features of type 2 gs.
hemophagocytic lymphohistiocytosis (hlh), an accelerated form, is characterized by overwhelming t cell and macrophage activation that leads to fever, splenomegaly, cytopenia, hypofibrinogenemia, and/or hypertriglyceridemia and hyperferritinemia.
it can prove fatal if not treated promptly.
chemotherapy can be given to achieve remission; however, allogeneic hematopoietic stem cell transplantation is the only currently available curative treatment for gs2.
[5] melanophilin gene defect responsible for type 3 gs presents with hypopigmentation of skin and hair without any systemic involvement.
[6] the prognosis for patients with gs3 is good, and these patients do not require any treatment.
a very close differential diagnosis of gs is chediak–higashi syndrome, which also presents with partial albinism and recurrent infections.
differentiation of gs from chediak–higashi syndrome can be made on the basis of abnormal vacuolation in the granulocytes in peripheral blood film, associated with decreased nitroblue tetrazolium test with biopsies of skin, hair, and schwann cells showing abnormal membrane-bound lysosome-like organelles.
[7] the hair shaft also contains a typical pattern of uneven accumulation of large pigment granules but in gs the clusters of melanin pigment on the hair shaft are six times larger than in chs.
hair hypopigmentation characterized by a silvery gray sheen and the presence of large melanin clumps, unevenly distributed in the hair shaft is the distinguishing feature of gs.
as treatment, prognosis and genetic counselling differ to a great extent among various types, accurate genetic diagnosis early in life certainly plays a crucial role.
declaration of patient consent the authors certify that they have obtained all appropriate patient consent forms.
in the form the patient(s) has/have given his/her/their consent for his/her/their images and other clinical information to be reported in the journal.
the patients understand that their names and initials will not be published and due efforts will be made to conceal their identity, but anonymity cannot be guaranteed.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
griscelli syndrome (gs) is a rare autosomal recessive multisystem disorder of pigmentary dilution of skin, silver gray hair, variable immunodeficiency, neurological impairment, and abnormal accumulation of melanosomes in melanocytes.
gs type 3 is characterized by hypomelanosis with no immunological and neurological manifestation.
prognosis is very good in type 3 gs and usually require no active intervention, as opposed to type 1 and 2 where early diagnosis and treatment plays a crucial role in patient's survival.
the characteristic phenotypic appearance, especially the pigment dilution of the patient's hair, is emphasized here.
