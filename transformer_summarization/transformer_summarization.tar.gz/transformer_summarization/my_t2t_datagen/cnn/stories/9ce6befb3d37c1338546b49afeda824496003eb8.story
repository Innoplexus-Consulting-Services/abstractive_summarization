introduction percutaneous nephrolithotomy (pcnl) is now the treatment of choice for surgical management of large renal stones.
fluoroscopy has traditionally been the method for obtaining access to the pelvicalyceal system.
later ultrasonography access to the pelvicalyceal system has been introduced and popularised by some researchers (1–8).
it has previously been shown that ultrasonography guided pcnl is equivalent to or even sometimes better than fluoroscopy guided pcnl in terms of stone free rate (1, 5, 9), operation duration (5), bleeding (5, 9) and complications (5).
a perfect percutaneous access tract to the pelvicalyceal system should be made through the tip of renal papilla in the targeted calyx and to be along the axis of renal calyx (10) so that the guide wire is passed into the pelvis and/or ureter.
in fluoroscopy guided pcnl, entry to the targeted calyx is evident by 2 directional fluoroscopy images.
there is a concern with ultrasonography guided pcnl for entry into the previously selected calyx especially for urologists who are not familiar with ultrasonography.
we could not find any publication evaluating the precision of ultrasonography in targeting the desired calyx in the desired direction and through renal papillae.
the aim of this study was to access the effectiveness of ultrasonography guided pcnl renal access in entering the targeted calyx and in the direction of renal pelvis.
materials and methods patients who were candidate for pcnl in labbafinejad hospital and were operated by one fellow during may-june 2014 were included.
pcnl cases included patients with large renal stones (>2cm) or patients with renal stones >1.5cm in horseshoe kidneys.
no specific exclusion criteria were applied and typical cases for pcnl within the study period were included.
the operating fellow had prior experience in fluoroscopy guided pcnl (>400 cases) and in ultrasonography guided pcnl (>50 cases).
pcnl was done according to the standard protocol described before (3).
in brief, cystoscopy was done in lithotomy position and a 4–6f ureteral catheter was inserted.
then the patient was turned into prone position.
ultrasonography was done by siui apogee 3800 (guangdong, china) ultrasonography machine.
a convex abdominal probe was placed on the flank of the patient parallel to the long axis of the kidney so that the 2d view included all possible calices from superior to inferior poles (figure-1).
the calyx which had been selected for access based on preoperative imaging (ivp or ct scan) was identified by ultrasonography.
then an 18y gauge shiba needle was advanced through a needle holder attached to the side of the ultrasonography probe.
entering the target calyx was confirmed by viewing the needle path on the ultrasonography monitor.
then the needle obturator was removed and saline was infused through the ureteral catheter.
the outflow of urine from the needle proved the presence of the needle in the pelvicalyceal system.
the guide wire was passed through the needle into the pc system until resistance was felt.
then radio-opaque contrast was injected through ureteral catheter and after opacifying the pelvicalyceal system, needle path and guide wire route were documented by fluoroscopy (figure-2).
if the entered calyx was different or not appropriate for pcnl or the calyx was entered from positions other than the papillae, the needle and guide wire were withdrawn and access was obtained under fluoroscopy guidance.
the use of fluoroscopy here was as to confirm the accuracy of ultrasonography guided access and not as an adjuvant to ultrasonography guided access.
in patients whom the obtained access was judged wrong and not feasible for safe pcnl by fluoroscopic images, a second access was obtained by means of fluoroscopy and the ultrasonography taken access was considered as failed.
figure 1 ultrasonography probe was hold on the back of the patient parallel to the long axis of the kidney.
figure 2 documentation of guide wire entry site and angle by fluoroscopy after injecting contrast media from ureteral catheter.
in this case guide wire was passed from proper entry site and coiled in renal pelvis in this study proper entry site into renal calyx was defined as entry from the surface of renal papillae and not from the lateral walls of the calyx or any other entry sites.
proper entry direction was defined as the direction or angle that leads to renal pelvis (figure-3).
tract was dilated by guidance of fluoroscopy/ultrasonography and pcnl was performed by pneumatic lithoclast and stone fragments were removed by forceps.
figure 3 definition of proper entry site and angle in this study.
proper entry site was defined as the surface of renal papillae (from point a to point b).
proper entry angle was defined as an angle that leads to renal pelvis (parallel to the axis of entered renal calyx).
placement of nephrostomy or removal of ureteral catheter was done according to the judgement of the attending surgeons.
the ethics of this study was approved by the local committee institutional board review.
all patients were informed about the study and informed consent obtained.
results 52 patients were enrolled during the study period.
5 patients were excluded from the study and their data is not presented in the below sections.
reasons for exclusion from the study were: fat body resulting in poor ultrasonic view of the kidney (1 patient), ectopic kidney with poor ultrasonic view (1 patient), high lying kidneys with poor longitudinal ultrasonic view because of rib shadows or stones in superior calices making ultrasonic view of the stone by ultrasonic probe in longitudinal view difficult (3 cases).
details of the 47 remaining patients and their operations have been outlined in table-1.
as explained in the methods section, access phase was totally guided by ultrasonography in all patients.
tract dilation was ultrasonography guided in 7 patients and with fluoroscopy guidance in 40 patients.
no case of bowel injury or solid organ injury was observed in the studied patients.
successful entry into targeted calyx was observed in 43 cases (91%).
successful entry, proper entry site and appropriate direction (all) were observed in 34 cases (72%).
in cases with proper entered calyx (n=43), appropriate entry site and coiling of guide wire were observed in 38 and 39 cases (88% and 91% respectively).
table 1 patients' demographic data and operations' characteristics.
variable* age, years 46.9±12.6 gender, male/female 34/13 positive hx of pcnl 17 (36) positive hx of oss 6 (13) side, left/right 30/17 access, l/mid/u 25/20/2 hydronephrosis, n/mod/s 23/17/7 stone location, u/mid/l/p/mul/stag 2/2/12/13/10/8 operation duration, minutes 55.3±21.7 transfusion 1 (2) stone free rate 41 (87) hx = history; pcnl = percutaneous nephrolithotomy; oss = open stone surgery; l = lower pole; mid = middle pole; u = upper pole; n = nil-minimal; mod = moderate; s = severe; p = pelvis; mul = multiple stone locations; stag = staghorn * data is presented as mean±sd, n(%) or n/n table-2 compares the factors affecting false entered calyx.
the percent of falsely entered calices increases steadily from 4% to 50% when the accessed calices changes from lower calices to upper calices (table-2).
false entered calices were observed in 17% of patients with nil-minimal hydronephrosis compared to 0% in patients with moderate or severe hydronephrosis.
if hydronephrosis is recategorized into nil-minimal versus moderate-severe (2 categories) then the observed differences are statistically significant (fisher p-value=0.049).
age, side of operation, gender, history of open stone surgery or pcnl and stone location were not associated with false entered calices.
table 2 the association of false entered calyx with studied variables.
factors† wrong entered calyx p-value yes no age, years 54.7±10.3 46.0±12.2 0.17 access lower pole 1(4) 24(96) 0.10* middle pole 2(10) 18(90) upper pole 1(50) 1(50) side right 2(12) 15(88) 0.61 left 2(7) 28(93) hydronephrosis nil-minimal 4(17) 19(83) 0.06* moderate 0(0) 17(100) severe 0(0) 7(100) gender male 2(6) 32(94) 0.30 female 2(15) 11(85) hx of oss yes 1(17) 5(83) 0.43 no 3(7) 38(93) hx of pcnl yes 1(6) 16(94) 1.0 no 3(10) 27(90) stone location upper pole 1(50) 1(50) 0.14 middle pole 0(0) 2(100) lower pole 0(0) 12(100) pelvis 1(8) 12(92) multiple sites 2(20) 8(80) staghorn 0(0) 8(100) oss = open stone surgery; pcnl = percutaneous nephrolithotomy * chi square p-value for linear by linear association † data are presented as mean±sd or n (%) table-3 compares factors influencing proper entry site and coiling of calyx in patients in whom the entered calyx was right (n=43).
false entry site was observed in the only patient with upper pole access to the upper pole stone.
(we excluded 3 patients with upper-middle pole stones in whom rib shadows precluded good longitudinal view of the kidney by ultrasonography probe).
the percent of false entry site constantly decreased from 16% in nil-minimal hydronephrosis to 0% in severe hydronephrosis, however this difference was not statistically significant.
false entry site was more often observed on the right side pcnls (p=0.04).
failure of the guide wire to coil in calyx/pelvis was not associated with any studied variables.
failure to coil was observed in 3 patients (16%) with nil-minimal hydronephrosis, no case with moderate hydronephrosis and 1 case with severe hydronephrosis (table-3).
the patient with severe hydronephrosis in whom the guide wire failed to coil was a 53 years old male with staghorn left kidney stone that occupied the whole pelvis and most renal calices leaving little free space for guide wire to coil or move freely in the calyx.
table 3 the associations of false entry site or failure of guide wire to coil with studied variables.
factors† false entry site p-value failure to coil p-value yes no yes no age, years 45.4±13.6 46.1±12.2 0.90 55.5±2.4 45.0±12.4 0.10 access upper pole 1(100) 0(0) 0.12 0(0) 1(100) 0.12 middle pole 2(11) 16(89) 2(11) 16(89) lower pole 2(8) 22(92) 2(8) 22(92) side right 4(27) 11(73) 0.04 3(20) 12(80) left 1(4) 27(96) 1(4) 27(96) 0.11 hydronephrosis nil-minimal 3(16) 16(84) 0.83 3(16) 16(84) 0.26 moderate 2(12) 15(88) 0(0) 17(100) severe 0(0) 7(100) 1(14) 6(86) gender male 4(12) 28(88) 1.0 3(9) 29(91) 1.0 female 1(9) 10(91) 1(9) 10(91) hx of oss yes 2(40) 3(60) 0.09 0(0) 5(100) 1.0 no 3(8) 35(92) 4(11) 34(89) hx of pcnl yes 3(19) 13(81) 0.34 2(12) 14(88) 0.62 no 2(7) 25(93) 2(7) 25(93) stone location upper pole 1(100) 0(0) 0.29 0(0) 1(100) 0.55 middle pole 0(0) 2(100) 0(0) 2(100) lower pole 1(8) 11(92) 1(8) 11(92) pelvis 2(17) 10(83) 0(0) 12(100) multiple* 1(12) 7(88) 1(12) 7(88) staghorn 0(0) 8(100) 2(25) 6(75) oss = open stone surgery; pcnl = percutaneous nephrolithotomy * multiple stone locations † data are presented as mean±sd or n(%) discussion a perfect access for pcnl should pass from the papillae into the collecting system and direction of the needle path should be coincident with the long axis of the target calyx (11).
there have been reports about the safety and success of ultrasonography directed renal access or solo-sono pcnl (1–6, 12).
nevertheless, we could neither find any article describing the success of ultrasonography in targeting the access to the pre-selected calyx nor we could find publications describing the situations regarding renal anatomy or stone morphology that make ultrasonography directed renal pcnl difficult or bothersome.
in this study, we observed a high success rate for entering targeted calyx by ultrasonography guided renal access.
reasons for failure were: 1) minimal/no hydronephrosis in the target calyx.
the absence of hydronephrosis makes identification of the stone and its surrounding calyx difficult on ultrasonography especially by less experienced urology surgeons.
we usually inject normal saline through ureteral catheter in patients with nil-minimal hydronephrosis to augment the magnitude of hydronephrosis during the access phase of the operation.
another alternative can be injection of diuretic agents before the access phase so that the access time is roughly in the peak action duration of the diuretic agent 2).
failure to enter the preselected calyx was less often observed in lower calices in comparison with middle to upper calices.
therefore, in difficult or borderline cases, selection of lower calyx for entry especially in equivocal cases may be associated with a higher success rate.
as illustrated in the methods section, appropriate entry site in this study was defined as the convex area of the tip of the calyx and not its lateral walls (figure-3).
reasons for false entry site were: 1) stones in superior calices.
to avoid shadows of ribs, we placed the ultrasonography probe beneath the rib cage.
as a result, the angle of the needle, its path length and the visibility of the stone were more difficult when the stone was in the superior calices.
also, the path of the needle is from near the inferior pole of the kidney toward its superior pole.
then it seems imperative that the entry to the superior calyx will be from its lateral walls not from the convex surface of its papillae (figure-3).
to overcome such a problem, it is possible to place the ultrasonography probe transversely on the patient flank instead of placing it vertically and perform the access beneath the ribs or even from the window between the ribs.
this was not included in the study protocol and it is possible that the identification of the target calyx in relation to other calices would be more difficult on a transverse plan.
our personal experience is that it is possible to perform intercostal access by ultrasonography guidance when ultrasonography probe is placed transversely between ribs.
in this method, the target calyx can be selected by cephalic-caudal movement of ultrasonography probe.
however, more experience is required due to rib shadows and narrow entry space on skin 2).
high lying kidneys.
the same points and problems described for superior pole stones are also pertinent to high lying kidneys.
after experiencing false entry site in the patient with superior pole stone, we excluded high lying kidneys when the ultrasonography view of the whole kidney was not possible because of rib shadows.
in univariate analysis, right side pcnls were associated with more frequent false entry sites (table-3).
after performing a multivariable logistic regression analysis, the association of laterality was no longer statistically significant when hydronephrosis and accessed calyx were included in the equation.
in order to use ultrasonography for taking access in pcnl, there should be a clear view of the kidney calices on ultrasonography monitor.
in situations in which this image is not clear, the success of ultrasonography in properly targeting the access calyx, its entry site or entry angle can be impaired.
in our limited experience, this scenario happened in the following situations 1).
a very fat patient with normal lying kidney with a 2cm stone in the lower calyx, 2) one muscular patient with body mass index of 27 with low lying mal-rotated kidney with a pelvis stone, 3) three patients with stones in middle or upper kidney calices so that when the ultrasonography probe was placed longitudinally beneath the ribs, the view of the whole kidney or the segment containing the stone was not clear.
in a few cases we tried to overcome this problem by angling the ultrasonography probe end caudally and pressing it on the patient back below the ribs but in these cases, this simple manoeuver could not solve the problem.
nevertheless, in such cases it is possible to obtain access to lower calyx without the need to observe the calices containing stones on ultrasonography monitor and then perform pcnl.
in the protocol of the current study, we requested to have the image of kidney calices and containing stones which was not possible in the above cases but just for the sake of performing pcnl, it is enough to obtain ultrasonography guided access through a lower calyx and then perform pcnl by rigid or flexible nephroscope.
having mentioned these solutions, we think it is still safer to have fluoroscopy equipment at hand in such cases in case of failed ultrasonography guided access.
we do acknowledge the operator dependency of ultrasonography a limitation of the results of this study.
the experience of the operator can influence the obtained results.
nevertheless, there has been a publication by japtag et al.
in which the guidance of access by fluoroscopy versus ultrasonography yielded similar outcomes in hands of a trainee urologist with little prior experience in pcnl (13).
it is necessary here to emphasize that fluoroscopy was not used in this study as an adjuvant to ultrasonography for accessing the kidney but only to verify the access taken by the surgeon.
in cases that the access was judged wrong by fluoroscopic images, a second access was taken by means of fluoroscopy and the ultrasonography access was considered as failed and analysed accordingly.
conclusions although it is feasible to access a preselected calyx by ultrasonography guidance during pcnl, but entry to the calyx from the appropriate site and direction is another problem and needs more experience.
in patients with minimal hydronephrosis, upper pole access or high lying kidneys this success rate is lower or the entry site into the calyx is less perfect.
in such cases, it is advisable to have fluoroscopy equipment at hand.
@highlight
abstract objectives: to evaluate the success of ultrasonography directed renal access in entering the target calyx from proper entry site and in the direction of renal pelvis during percutaneous nephrolithotomy (pcnl).
materials and methods: pcnl cases who were operated on by one fellow from may-june 2014 were included in this study.
a vertically placed ultrasound probe on the patient flank in prone position was used to identify the preselected target calyx.
needle was advanced through needle holder and fluoroscopy was used to document the entered calyx, site and angle of entry.
results: successful entering to the target calyx was achieved in 43 cases (91%).
successful entry with appropriate entry site and angle was observed in 34 cases (72%).
reasons for failure were minimal hydronephrosis, upper pole access and high lying kidneys.
conclusions: although it is feasible to access a preselected calyx by ultrasonography guidance during pcnl, but entry to the calyx from the appropriate site and direction is another problem and needs more experience.
in cases of minimal hydronephrosis, superior pole access or high lying kidneys, ultrasonography is less successful and should be used with care.
