1. introduction as arctic warming has significantly exceeded that of lower latitudes in recent decades [1], indigenous peoples have reported symptoms of accelerating change, even while characterizing extreme weather events as ‘normal’ in the context of life lived on land and/or sea [2,3].
in the eurasian arctic, the rapid retreat and thinning of sea ice in the barents and kara seas (bks) are critical components of feedbacks to arctic and global climate change [1,4].
coincidentally, autumn and winter rain-on-snow (ros) events, resulting in ice-encrusted pastures and mass starvation of semi-domesticated reindeer (rangifer tarandus), have increased in frequency and intensity across the northwest russian arctic [5,6].
this region is home to the world's largest and most productive reindeer herds.
warmer/wetter winters have negatively affected the much smaller wild reindeer populations on high arctic svalbard [7,8].
in the low arctic, there is an urgent need to understand whether and how regional sea ice loss is driving major ros events over mainland russia and, crucially, the implications of such events for the region's ancient and unique social–ecological systems (ses).
at the circumpolar level, it has been proposed that increases in arctic terrestrial primary productivity are linked to sea ice decline and thinning [9–11].
however, evidence based on tundra shrub dendroclimatology from nenets autonomous okrug and yamal-nenets autonomous okrug (ynao) does not support such a linkage in the bks region: in recent decades, the trend of increasing deciduous shrub growth appears closely tied to more frequent and intense summer high-pressure systems over west siberia [12].
while attention has focused on summer temperature coupled with contraction of summer reindeer pastures due to incremental hydrocarbon development [13], autumn and winter warming have been severe, leading to large changes in regional biota [6,14,15].
in particular, a major ros event during autumn/winter 2013–2014 led to the starvation of 61 000 reindeer out of a population of ca 275 000 animals on the yamal peninsula [14].
historically, 2013–2014 is the region's largest recorded mortality episode, and sits within a pattern of more frequent and intense autumn/winter ros events [5,6].
if sea ice loss is driving increasingly severe ros events and high reindeer mortality, it will have serious implications for the future of tundra nenets nomadism.
here, we review evidence for autumn atmospheric warming and precipitation increases over arctic coastal lands in proximity to the bks and their links to sea ice loss.
we consider how both recent (2006 and 2013) and historic ros events have shaped nenets strategies for coping with extreme weather from the perspective of recent literature, including modelling efforts, and empirical measures of sea ice and associated atmospheric conditions.
we also explore nenets strategies for adaptation to ros events in recent decades and into the future.
2. material and methods around 6000 of the approximately 30 000 indigenous yamal nenets of west siberia are reindeer nomads who migrate up to 1200 km annually between lichen woodlands (winter pastures) south of the ob river and northern shrub–graminoid tundra (spring/summer/autumn pastures) on the yamal peninsula [13].
the total reindeer population in ynao was 705 000 in january 2016, of which 394 000 were privately owned.
migratory units range in size from 100 to several thousand animals.
between march 2014 and april 2016, we surveyed 60 herders and administrators in the yamalski and priuralski raions, representing the yarsalinskaia and baidaratskaia tundras (electronic supplementary material, s1).
via intensive participant observation in all seasons with nenets nomads, we created a detailed oral history of herding strategies and movements over several decades.
we combed archives of atmospheric infrared sounder (airs) data to search for both seasonal and date-specific anomalies in atmospheric conditions over the bks in two winters with high reindeer mortality (2006–2007 and 2013–2014).
archives of advanced scatterometer (ascat; electronic supplementary material, s2) data were similarly searched to detect the autumn 2013 ros event over land.
sea ice extent was estimated using special sensor microwave imager/sounder (ssmis; electronic supplementary material, s3).
we checked for precipitation anomalies using european reanalysis (era)-interim data, a global atmospheric reanalysis from the european centre for medium-range weather forecasts, which provides medium-range forecast data for this region.
the findings from the combined quantitative and qualitative (i.e.
participatory) approaches are coupled with a literature review that focuses on modelling of bks ice loss.
3. results during the period 5–10 november 2006 (the date of the 2006–2007 winter ros event) and 5–10 november 2013, ssmis shows that bks ice was steadily decreasing (electronic supplementary material, s4).
herders reported that the most recent catastrophic ros event (serad po in nenets language, i.e.
bad/distress year) began on 8–9 november 2013 with about 24 h of rain, after which temperatures dropped and remained below freezing for the remainder of the autumn and throughout the winter.
ascat data accurately detected the severe icing of pastures beginning 10 november 2013 over most of the southern yamal peninsula, an area covering ca 27 058 km2 (figure 1a).
autumn airs data indicate anomalously high total precipitable water over nenets okrug on 6 november 2006 and 8 november 2013, and over ynao on 7 november 2006 and 8–9 november 2013 (figure 1b–f).
according to airs data, air temperatures were anomalously high over nenets okrug on 6 november 2006 and ynao on 7 november 2006. anomalous high air temperatures characterized both regions on 6–9 november 2013, followed by cold anomalies over the yamal peninsula on 10 november 2013 (figure 1g–i).
airs detected positive sensible heat fluxes from the surface to the atmosphere over the barents sea (bs) on 5–7 november 2006 and the kara sea (ks) on 8–9 november 2006. in 2013, positive sensible heat flux was detected over the bs on 5–8 november and the ks on 9 november.
era-interim data forecasted high precipitation anomalies over nenets okrug and ynao on 6–7 november 2006 and 6–7 november 2013 (figure 2a), coupled with wind advection from the south (figure 2b).
era data have close agreement with empirical data and incorporate sea ice data.
by spring–summer 2014, the private herders who had lost most or all of their animals to starvation were functionally stranded in the tundra.
with no draught reindeer to haul their camps, they resorted to full-time subsistence fishing and borrowed breeding stock to rebuild their herds, a multi-year process.
herders identified other historically bad icing events since world war ii as occurring about once per decade, e.g.
in 1947, 1954, 1974 and 1996. figure 1.ascat detected backscatter difference (db), southern yamal peninsula 10 november 2013. pink line borders severely iced pasture area; black arrow indicates reindeer herders' southward migration.
(a) airs daily total precipitable water from (b–c) 6–7 november 2006 and (d–f) 8–10 november 2013 and 925 hpa temperature (g–i) from 8–10 november 2013 for the bks region.
white indicates missing data and black outlines the coasts.
figure 2.anomalous precipitation (mm) patterns 6–7 november 2006 (left column) and 6–7 november 2013 (right column).
anomalies are to the respective monthly averages (a).
moisture transport (streamline) and convergence of moisture transport (shading: 10−7 s−1) in the 1000–850 hpa level in 2006 and 2013 (b).
moisture convergence is overall in reasonable agreement with precipitation, suggesting that convergence of increased moisture is primarily responsible for precipitation.
4. discussion warmer, wetter arctic winters over the past decade have raised concern [16,17], particularly regarding impacts of ros events on eurasian semi-domesticated and wild reindeer populations [5,7,8,14,15,18].
recent winter sea ice retreat is most pronounced in the bs [19].
this has been attributed to increasing ‘atlantification’ [19,20] and has been linked to anomalous warm advection over the bs in light ice years [21].
another factor in bks ice loss is ural blocking with a positive north atlantic oscillation (nao), which was more persistent in 2000–2013 than in 1979–1999 [22].
modelling efforts, such as atmospheric reanalyses, including the era-interim, have indicated anomalously high winter sensible heat flux in the bs [23].
in a recent circumpolar comparison, bs was the only region with significant warming in all models [23].
negative ice concentration anomalies were most pronounced in the bs, with significant precipitation increases over regions of winter sea ice loss, and atmospheric warming spreading to neighbouring landmasses around the bs [24].
however, a decrease of wintertime sea ice cover in the bks does not always result in a priori expected warming over adjacent continental areas [25].
at the same time, quantitative links between arctic sea ice retreat and increasing precipitation remain poorly constrained [26], yet important linkages between november bs ice loss and the nao sign for the following winter have been reported [11].
meteorological data show that rain fell over the central ynao on 8–9 november 2013 [7], and on 7 november 2006, but not in southern forest–tundra and northern tundra zones.
airs data for winter 2013–2014 (not shown) support herders' observations that cold weather prevailed after ice crust formed on 10 november 2013. ascat, despite low sensitivity to snow structural change relative to quikscat [5], was able to capture the event owing to its intensity and severity (figure 1a).
the era-interim pattern of moisture convergence is similar to that of precipitation detected (figure 2; electronic supplementary material, s5–s9).
although wind streamline indicates that moisture is transported from the south, this does not mean that moisture originally derived from the continent, but it would have been introduced earlier from the sea (electronic supplementary material, s10).
some of the individual elements in the chain of events that proceeds from warming → sea ice decline → increased precipitation and winter temperatures → ros events → reindeer mortality → ses resilience have been reported elsewhere [4–9,11,13,16–24].
however, (i) this is the first time the whole, integrated picture is presented for a region where the coupling between sea ice-related environmental changes and critically important semi-domesticated reindeer nomad ses is manifest quite clearly and (ii) this is the first study to propose a link between brief but spatially significant retreat of november sea ice and massive ros events over the russian mainland.
we stress the idea that sea ice declines are very likely linked with increased precipitation and higher temperatures in the bks region.
it is logical to infer that ros events will be more frequent in these situations.
the pattern of more frequent and intense autumn/winter ros events in nenets okrug and ynao mirrors that of summer high-pressure systems over west siberia.
together, the regional autumn, winter and summer warming trends present real challenges to maintaining tundra reindeer nomadism as a viable livelihood.
yet, indigenous peoples have critical data and perspectives to contribute to understanding climate change [2,3,27,28] and consciously facilitate their own social–ecological resilience through collective agency [13].
nenets oral histories documented that smaller, more nimble privately owned herds fared better than larger collective herds.
this strategy has worked well for dealing with encroaching infrastructure [13].
regional warming already exceeds the 1.5°c scenario envisioned by the cop21 paris agreement of 2015. our analysis suggests that decreasing november bks ice extent is linked to precipitation over coastal lands, putting nenets herds and herders at risk.
if bks ice continues to decline, better forecasts of autumn ice retreat coupled with additional mobile slaughterhouses could help to buffer against reindeer starvation following future ros events.
even a few days of early warning could make a critical difference.
this could be achieved via combined use of empirical data coupled with era-reanalysis.
realizing mutual coexistence of tundra nomadism within the arctic's largest natural gas complex under a warming climate will require meaningful consultation, as well as ready access to—and careful interpretation of—real-time meteorological and sea ice data and modelling.
supplementary material supplementary material 1
@highlight
sea ice loss is accelerating in the barents and kara seas (bks).
assessing potential linkages between sea ice retreat/thinning and the region's ancient and unique social–ecological systems is a pressing task.
tundra nomadism remains a vitally important livelihood for indigenous nenets and their large reindeer herds.
warming summer air temperatures have been linked to more frequent and sustained summer high-pressure systems over west siberia, russia, but not to sea ice retreat.
at the same time, autumn/winter rain-on-snow (ros) events have become more frequent and intense.
here, we review evidence for autumn atmospheric warming and precipitation increases over arctic coastal lands in proximity to bks ice loss.
two major ros events during november 2006 and 2013 led to massive winter reindeer mortality episodes on the yamal peninsula.
fieldwork with migratory herders has revealed that the ecological and socio-economic impacts from the catastrophic 2013 event will unfold for years to come.
the suggested link between sea ice loss, more frequent and intense ros events and high reindeer mortality has serious implications for the future of tundra nenets nomadism.
