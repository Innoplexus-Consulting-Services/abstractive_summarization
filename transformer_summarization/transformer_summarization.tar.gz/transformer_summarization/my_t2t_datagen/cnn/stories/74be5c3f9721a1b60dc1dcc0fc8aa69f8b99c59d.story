introduction endometriosis is an estrogen dependent gynecologic disease with lasting implications for many women's fertility, somatic health, and overall quality of life.
endometriosis is seen in approximately 10-15% of adult women aged 25-35 years old (1).
this disorder occurs when the endometrial tissue (cells that line the uterus) grows in other areas of the body.
endometriosis causes varying degrees of painful symptoms and infertility in infected individuals (2).
the standard treatment of endometriosis in women who have suitable number of babies is surgery, including hysterectomy, bilateral salpingo-oophorectomy (3).
cancer antigen 125 (ca-125) is a glycoprotein biomarker that is used in women with pelvic masses such as endometriosis and maybe is useful in practice of patients suspicious to endometriosis (3).
it serves as an ovarian cancer biomarker, especially for monitoring of ovarian cancer therapy and early recurrences (4, 5).
ca-125 levels have been found to be significantly higher in women with moderate or severe endometriosis (6).
it was reported that preoperative serum ca-125 level could be used as an important predictor for patients with endometrial conditions.
most common benign gynecological conditions associated with high serum ca-125 are ovarian endometrioma and deeply infiltrating endometriosis (7).
due to endometriosis similarity and ovarian malignancy in radiological markers and ca-125 serum level and the effect of surgery on ovarian reserve in women with endometriosis, our main goal was to evaluate the correlation between ca-125 serum level and the clinic pathological characteristics in women referred to our center.
our specific goal was to determine the best ca-125 cut-off level in pre- and postmenopausal women with endometriosis.
it seems preoperative serum ca-125 levels can be used as a guide to perform aggressive surgical staging with regards to initial treatment modalities as well as to predict prognosis (9, 10).
there are so many clues that elevated preoperative serum ca-125 levels were strongly correlated with advanced-stage disease, higher grade, deep myometrial invasion, lymph node metastases, presence of extra-uterine spread of the tumor and poor prognosis (11, 12).
hetergenecity of adnexal mass is one of the most common endometriosis features.
also higher level of ca125 is common in women with endometriosis.
both of these points are important for patient selection for surgery suspected to malignancy.
in older and menopausal women these characteristics help to surgeons to do surgery as soon as possible.
materials and methods this cross-sectional study was conducted on 87 women suspected endometriosis with pelvic pain, dysmenorrhea, or dyspareunia referred to obstetrics and gynecology department of shahid sadoughi hospital, between march 2013 and july 2014 for laparoscopy or laparotomy.
the study was approved by the shahid sadoughi medical science university ethics committee.
a written informed consent was obtained from all patients.
the subjects were free to participate in the study.
inclusion criteria were women with pelvic pain, dysmenorrhea, or dyspareunia, suspected endometriosis, and aged 21-54 years.
as a matter of fact women within 45-54 years who radiological findings showed endometriosis were entered to the study.
blood samples were preoperatively obtained from all ca-125 participants levels measurement up to 2 days before surgery.
serum ca-125 levels were determined by sandwich type enzyme-linked immunosorbent assay (elisa) kit monoclonal (roche, germany).
the upper normal value of serum ca-125 levels was considered 35 u/ml.
all women with history of medical or surgical treatments for endometriosis in the past three months, previous history of pelvic surgery, history of pelvic inflammatory disease, and a suspected or certain diagnosis of malignancy in premenopausal women, women with chronic pelvic pain resulting only from musculoskeletal, infectious, neurologic, gastrointestinal or psychiatric causes, refusal to participate in the study pregnancy and lactation were excluded.
endometriosis was diagnosed according to the clinical symptoms and sonographic findings and was staged according to the classification of the american society for reproductive medicine, as revised in 1996 (23).
preoperative pain was assessed by visual analogue scale and analgesic usage (vas).
all subjects completed a preoperative questionnaire concerning on menstrual history, marital status, age, body mass index, professional activity, medical and surgical history and characteristics of pain symptoms.
women completed the questionnaire alone, without any assistance of others.
women were questioned for pain symptoms within three months before the surgery.
pelvic pain was assessed by a visual analogue scale (vas; 0 absence of pain, 10 unbearable pain).
vas is a suitable and well-proved tool for the measurement of pelvic pain associated with endometriosis.
surgical finding such as the adhesions severity, the extent and location of endometriosis and stage of endometriosis were recorded in a checklist by gynecologic laparoscopy specialist.
stage of endometriosis was assigned according to revised-american fertility society (r-afs) stages i-iv and score of adhesion were defined according to the revised the modified american fertility society mafs scoring method for adhesions (3).
statistical analysis data were analyzed using spss statistical software (spss, chicago, il, usa).
the data on serum ca-125 levels in the patients did not have a normal distribution.
therefore, a nonparametric test was used to evaluate its relation with clinic pathological characteristic.
the levels of serum ca-125 in different group were analyzed using mann-whitney u test and a pearson 2 test.
receiver operating characteristic (roc) curve analysis was used to find a cut-off level of ca-125 in serum with optimal diagnostic sensitivity and specificity.
for all analyses, values of p<0.05 were considered significant.
results the mean age of participants was 32.22±6.91 (ranged, 21-54 years).
out of 87 women, 12 cases were in menopausal age referred with pain and underwent surgery for suspected cancer.
however, the surgery results shown that they were suffering from endometriosis.
the mean serum ca-125 level of women with endometriosis was 49.93±4.30 u/ml (range, 2-191 u/ml).
association between preoperative serum ca-125 and clinicopathological characteristics are listed in table i. the elevated ca-125 level was significantly associated with clinicopathological parameters, including stage of disease (p≤0.001), adhesion score (p=0.04), and lesion size (p=0.02) and preoperative ca-125.
there was no significant differences in age (p=0.76), marital status (p=0.85), patient’s complaints (p=0.20), and pelvic pain score (p=0.70) associated to presurgical ca125 serum level.
the best cut-off level based menopausal or postmenopusal status-, the ca-125 serum levels was 37 u/ml for premenopause patients with 57% sensitivity, and 50% specificity, and 35 u/ml for postmenopause patients with 70% sensitivity, and 59% specificity.
table i association between preoperative serum ca-125 and clinicopathological characteristics characteristic serum ca-125 level p-value age (yrs) ≤40 55.22 ± 13.27 0.76 >40 52.21 ± 12.59 marital status single 35.27 ± 12.47 0.85 married 40.81 ± 4.59 stage of disease 1 29.38 ± 5.81 ≤0.001 2 53.20 ± 6.64 3 56.12 ± 6.88 4 49.91 ± 7.51 adhesion score 1-2 29.38 ± 5.81 0.04 3-4 53.20 ± 6.64 5-6 56.12 ± 6.88 complaint pelvic pain 47.67 ± 5.20 0.20 infertility 45.12 ± 1.98 infertility + pain 61.90 ± 20.7 aub 32.40 ± 8.30 aub + pain 60.65 ± 8.99 lesion size (cm) ≤4.5 49.91 ± 7.51 0.02 5-11 49.69 ± 5.32 vas 2 52.80 ± 14.55 0.70 2-5 43.93 ± 4.65 6-9 55.43 ± 8.46 data presented as mean±se.
aub: abnormal uterine bleeding vas: visual analogue scale discussion the mean serum ca-125 level of women with endometriosis was 49.93±4.30 u/ml (range, 2-191 u/ml) in this study.
amara and colleagues found that ca-125 serum levels were higher in endometriosis patients when compared to control group during both periods of menstrual cycle (13).
also, emin and co-workers showed that ca-125 frequently elevated in patients with endometriosis (14).
in the current study, there was no significant difference in terms of age, marital status, and complaints associated to presurgical ca125 level.
our data showed that serum ca-125 level in patients with pelvic pain, infertility, and infertility with pain has been increased.
however, there was no significant association between serum ca-125 level and the complaints that referred to our clinic.
ramos et al reported a significant increased ca-125 serum level in the infertile endometriosis women than fertile and never tried ones (15).
it was reported a correlation between ca-125 levels and the proliferative activity of epithelial cells in the endometriosis lesions, because the disease is an inflammatory process associated with a change in immune cell functions (16, 17).
in this study, we have found a strong association between preoperatively elevated ca-125 levels and advanced stage of disease.
our finding runs in agreement with previous studies in which advanced endometriosis was associated with high level of ca-125 in the serum (18).
amaral et al reported that women with more advanced degrees of endometriosis showed higher ca-125 levels in both serum and peritoneal fluid (13).
it seems the elevation of ca-125 in women with endometriosis is because of its higher concentration in ectopic than in entopic endometrium (13, 18).
moreover, it may be due to inflammatory reactions, which alters the endothelial permeability leading the marker to reach the circulation (13).
therefore, preoperative serum ca-125 assessment should be considered in all patients with suspected advanced disease stage or presence of unfavorable histology in endometrial biopsy as an adjunct to the stage prediction of disease and subsequent patient management.
moreover, serum ca-125 levels were notably higher in women with larger adhesions to the peritoneum, fallopian tube, ovary, omentum, colon, and cul-de-sac, or with ruptured endometrioma (18).
it was also found that women with endometriosis with preoperative ca-125 more than 65 iu/ml are at high risk for intense pelvic adhesions (18).
also franssen et al reported that menstruation and adhesions appears to be the main factors affecting pretreatment serum ca-125 level in patients with endometriosis (15).
garzetti and co-workers found that serum ca-125 concentration is directly correlated to the adhesion score and peritoneal (19).
besides, it was reported that ca-125 increases the invasiveness of a benign endometriosis cell line and affects cell adhesion in vitro (19).
the normal ca-125 level in postmenopausal women is <15 u/ml, which is significantly lower than in premenopausal women (20, 21).
in a meta-analysis, bedaiwy and falcone reviewed the medline database for studies about ca-125 performance in testing endometriosis.
most studies included in the meta-analysis accepted the value of 35 u/ml as a cut-off level for ca-125 serum concentration (22).
in the current study, the preoperative serum cut-off level of ca-125 (37 u/ml) in premenopausal patients was slightly higher than postmenopausal patients (35 u/ml).
the value is normal range for ca-125 concentration in postmenopausal patients.
the sensitivity and specificity were 57%, 50% for premenopausal patients and 70% and 59% in the postmenopausal patients, respectively.
the results of the bedaiwy and falcone meta-analysis showed that sensitivity of serum ca-125 was varied in a wide range from 24-94% (22).
in a study, szubert et al reported that the sensitivity of serum concentration of ca-125 in the diagnosis of disease was 68% reaching up to 91.67% for the diagnosis of advanced stages of endometriosis.
considerably, they have reported, the cut-off value in serum suggesting endometriosis with 68% sensitivity is 11 u/ml (7).
therefore, the best cut-off level was different for premenopausal or ≤50 years and menopausal or >50 years patients.
conclusion preoperative serum ca-125 is an important predictor for patients with endometriosis and it should be taken into consideration when surgical management is suspected, especially if the stage of disease, lesion size and adhesion score are undertaken.
@highlight
background: cancer antigen 125 (ca-125) is a glycoprotein biomarker that is used in women with pelvic masses such as endometriosis and maybe is useful in practice of patients suspicious to endometriosis.
objective: the aim of this study was to evaluate the association between preoperative serum ca-125 levels and clinic pathological characteristic in women with endometriosis, and find out the best serum ca-125 levels cut-off in pre and post menopause women.
materials and methods: serum ca-125 levels in 87 women aged 21-54 years suspected to endometriosis with pelvic pain, dysmenorrhea, or dyspareunia were measured preoperatively.
also the association between clinic pathological characteristic and serum ca-125 level were analyzed.
results: the mean age of women was 32.22±6.91.
the mean serum ca-125 level was 49.93±4.30 u/ml.
there was a significant correlation between the endometriosis stage, lesion size, adhesion score and preoperative ca-125 plasma concentration.
however, we did not found significant differences in age, marital status, patient’s complaints, and pelvic pain associated to ca125 serum level.
the suggested preoperative serum cut-off levels in premenopausal and postmenopausal patients were 37 u/ml and 35 u/ml, respectively.
conclusion: according to the results, preoperative serum ca-125 is an important predictor for patients with endometriosis and it should be taken into consideration when surgical management is suspected, especially if stage of disease, lesion size and adhesion score are undertaken.
