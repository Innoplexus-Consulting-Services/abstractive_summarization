1. background living camelids are divided into two subfamilies within the camelidae: the camelini, or old world camels (e.g.
bactrian and dromedary camels), and the lamini, or new world camels (llamas, alpacas, guanacoes and vicuñas).
although it is known that camelids possess a carotid rete (cr) [1–9], there are few complete cranial arterial descriptions for this clade, outside of dromedaries.
in particular, there are no current, widely available descriptions of the entire cranial arterial system of new world camelids, in spite of behaviours, habitats and growing economic uses that lend import to thorough and accurate documentation of camelid cranial arteries.
formerly distributed throughout a variety of environments, including temperate regions of north america and europe, living members of the camelidae are now found in specialized habitats.
the geographical ranges of lamini camelids are restricted to the andes mountains of south america, where they are high altitude specialists and routinely encounter extremes in temperature and lengthy periods without meteoric water [10–13].
this oxygen and water depravation, as well as the extremely high and low environmental temperatures these animals routinely encounter can result in negative consequences for unspecialized mammals; as such, new world camelids have a number of physiological specializations for coping with the hypoxia and low atmospheric pressures endemic to high altitudes, particularly within the cardiopulmonary system [14–17].
the cr, a cranial arterial meshwork well developed in artiodactyls, may facilitate some of these extreme aspects of lamini ecology.
the cr is a subdural arterial meshwork that supplies the majority of oxygenated blood bound for the brain of nearly all artiodactyls.
the rete is housed within the cavernous venous sinus, which receives venous blood that has been warmed or evaporatively cooled by the maxilloturbinates [18–21].
the high surface area of the arterial meshwork enables rapid heat exchange between the arterial and pooled venous blood.
the result of this exchange is thermal conditioning of the blood bound for the brain, which in turn leads to a suite of physiological consequences that may benefit high-altitude artiodactyl species.
first, the cr may protect the brain from altitude hypoxia, as suggested by caputa [21].
second, in the arid habitats of camelini, the cr plays a role in selective brain cooling [22,23].
continuity between the carotid and ophthalmic retia [4] may further play a role in moderating the temperature of the globe of the eye to protect the animal's vision [24,25].
overall, living camelids probably benefit from the increased water economy furnished by cr-mediated hypothalamic cooling [26–35].
in spite of the range of plausible physiological benefits imparted by possession of a cr, there is currently, to my knowledge, no comprehensive documentation of the cranial arteries of the lamini outside of a detailed description of the intracranial cerebral arterial circle by kiełtyka-kurc et al.
[9].
additionally, camelids are notable for their elongated necks––morphology that may result in atypical haemodynamic and developmental patterns.
although doubt has been cast on a haemodynamic role for the cr in long-necked artiodactyls [36], ontogenetic changes have been documented in the cranial arterial patterns of other long-necked artiodactyls, such as giraffes [37].
fully mature adult artiodactyls frequently lack an internal carotid artery (ica) even though arterial development begins from the same embryonic scaffolding as other mammals [38–40].
with the exception of tragulids and perhaps dromedaries [4,9,41,42], the artiodactyl ica diminishes in diameter or obliterates at a variable point during ontogeny.
some documented artiodactyls lose a patent internal carotid in prenatal ontogenetic stages (sus scrofa scrofa and giraffa camelopardalis [37,39,43–46]), others maintain a patent vessel until shortly after parturition (capra hircus hircus, ovis aries [46]) and still others possess a patent internal carotid until sexual maturity (bos taurus, bubalis bubalis [46–48]).
evidence within old world camelids (camelus dromedarius) suggests that the ica may persist through the animal's entire life [1,2,4,6,9,39].
although the developmental mechanism driving the elimination of the artiodactyl ica is currently unknown, emergent patterns from the few documented taxa suggest that patency is maintained further into life in artiodactyls with larger body sizes or longer gestation periods, with the exception of giraffes [37].
this study aims to fully describe adult and neonatal cranial arterial patterns of the alpaca, vicugna pacos, in order to document structures important for oxygen metabolism and thermoregulation, as well as to establish a baseline for potential ontogenetic shifts in arterial morphology within a long-necked and large-bodied artiodactyl.
2. material and methods four cadaveric alpaca heads were obtained from the collection of s. williams at ohio university: two mature males, one mature female and one near-term stillborn of unknown sex.
all specimens died of natural causes during the course of unrelated research studies.
no animals were sacrificed for the purpose of this study.
shortly after death, the adult alpacas were stored frozen and the stillborn alpaca was preserved in formaldehyde.
data collection follows the methods of holliday et al.
[49] and o'brien & williams [50], wherein specimens are injected with a radiopaque injection medium, computerized tomography (ct) scanned and then digitally rendered in three dimensions.
these more recently derived methods allow soft and hard tissue interactions to be examined in tandem, without the need to destroy either material.
for all specimens, either the right or left common carotid artery (cca) was cannulated (18-gauge angiographic cannula for the stillborn specimen or ⅛-inch pvc tubing (nalgene) in the adult specimens).
cannulae were fixed in place with surgical ligature and adhesive.
the arterial system was then manually flushed with warm water for 10 min, followed by perfusion with 90–300 ml of 10% one-point anticoagulant solution (depending on specimen size).
a higher concentration of anticoagulant was used to flush the formalin-preserved specimen to assist removal and breakdown of blood clots (33% one-point).
following initial specimen preparation, radiopaque latex vascular injection was conducted, following the criteria for complete perfusion outlined in o'brien & williams [50].
all specimens were manually injected with a solution of 40% liquid polibar plus barium sulfate suspension (baso4, e-z-em, westbury, ny) in 60% red liquid latex injection medium (ward's, rochester, ny).
perfusion continued until latex emerged from the contralateral cca.
the volume of injected medium ranged from 5 ml in the stillborn specimen to 30 ml in the adult specimens.
acetic acid (10% glacial acetic acid solution) was used to set any extravasated latex.
for clarity in digital rendering, the venous system was not perfused.
following radiopaque latex injection, specimens were ct scanned at the holzer clinic in athens, ohio, on a philips brilliance 64-slice ct scanner.
scan resolution for all specimens was 0.67 mm slice thickness, 150 kv and 80 ma, yielding an initial voxel size of 0.693359 × 0.693359 × 0.5. the resultant data were up-sampled to improve resolution in avizo (version 7.0; vsg).
grey-scale values were averaged across voxels and smaller specimens were up-sampled to a size of 0.1 × 0.1 × 0.1 mm, whereas larger specimens were up-sampled to 0.3 × 0.3 × 0.3 mm.
up-sampling decreases the average voxel size without affecting the inherent quality of the data.
this technique generates a visually smoother surface upon reconstruction.
because a 40% barium solution yields stark contrast between hard tissues (cartilage and bone), the skull and arteries were segmented based on distinctive grey-scale values.
manual segmentation was then employed to verify the accuracy of the model.
segmented morphology was then rendered in three dimensions with minimal use of smoothing algorithms (setting of 2 on a scale of 10).
note that vascular nomenclature largely follows that codified in the nomina anatomica veterinaria (2012), with accepted terminology in latin following the first reference to a vessel.
3. description: results and discussion 3.1. cranial arteries of the adult alpaca 3.1.1. branches of the external carotid artery overall, the branching patterns of cranial arteries were conserved among adult specimens.
the branches of the external carotid artery (eca) of the alpaca are summarized in the electronic supplementary material, table s1 and visualized in figures 1–4.
the eca (arteria [a.]
carotis externa) begins to branch extensively deep to the condylar process of the mandible.
the first major branch of the eca is the occipital artery (a. occipitalis; figure 1).
from the superior surface of the eca, the occipital artery shares a short trunk with the ica (a. carotis interna) and the condylar artery (figures 1–3).
the trunk uniting these arteries is variable—the vessels may arise in close proximity to each other or from a common trunk, as described (figures 1–3).
as the occipital artery ascends, it scours the deep surface of the jugular process and the posterior surface of the temporal crest (mastoid contribution; crista supramastoidea).
the artery terminates by splitting into smaller branches that permeate the occipital region (nuchal ligament (ligamentum nuchae) and muscles) and a larger caudal meningeal artery (figures 1 and 2).
the latter enters the cranium via a large mastoid foramen (foramen mastoideum) before radiating across the caudal half of the meninges.
the ica itself is reduced in calibre, and the vessel does not leave a medial bullar groove as it ascends to the basicranium as in other artiodactyls with a homologous ica (figures 2 and 3; see e.g.
moschiola [42]; tragulus [51]).
as the ica enters the basicranium, it traverses the promontorial foramen, coursing within a carotid canal in close association with the promontorium of the petrosal.
the ventral surface of the petrosal is scoured by a slight transpromontorial sulcus.
this sulcus corresponds to direct contact by the ica of non-artiodactylan mammals [52–57]; however, in the adult alpaca, the ica does not make direct contact with the petrosal.
the presence of a transpromontorial sulcus in adult alpacas may be an effect of arterial reduction during ontogeny (see below).
upon entering the cranium, the ica leaves a notch at the rostral-most extent of the epitympanic wing (sensu [55,57]; this structure is also referred to as the ‘pole of the promontorium’ sensu [58] and the ‘anteromedial flange’ sensu [59]).
once inside the brain case, the ica communicates with the cr (figures 2–4; also illustrated for other lamini by kiełtyka-kurc et al.
[9]).
figure 1.superficial and orbital arteries of the head of the alpaca, vicugna pacos, lateral perspective.
buc, buccal artery; cdt, caudal deep temporal artery; cma, ‘common’ auricular artery; eo, external ophthalmic artery; fa, facial artery; iob, infraorbital artery; la, lingual artery; mal, malar artery; mdl, mandibular labial artery; mxl, maxillary labial artery; oc, occipital artery; opr, ophthalmic rete; rdt, rostral deep temporal artery; sta, superficial temporal artery; tfa, transverse facial artery.
figure 2.superficial and orbital arteries of the head of the alpaca, vicugna pacos, lateral perspective.
skull transparent to expose deeper arteries.
note the ica extending from the carotid artery to the braincase and the enlarged ophthalmic rete (opr).
buc, buccal artery; cdt, caudal deep temporal artery; cma, ‘common’ auricular artery; dla, deep lingual artery; eo, external ophthalmic artery; fa, facial artery; gpal, greater palatine artery; ial, inferior alveolar artery; ica, internal carotid artery; iob, infraorbital artery; la, lingual artery; ma, maxillary artery, mal, malar artery; mdl, mandibular labial artery; mxl, maxillary labial artery; opr, ophthalmic rete; rdt, rostral deep temporal artery; sta, superficial temporal artery.
figure 3.sagittal section of the skull and arteries of the alpaca, vicugna pacos.
cac, cerebral arterial circle; cma, ‘common’ auricular artery; con, condylar artery; cr, carotid rete; dla, deep lingual artery; eca, external carotid artery; gpal, greater palatine artery; ial, inferior alveolar artery; ica, internal carotid artery; iob, infraorbital artery; la, lingual artery; ma, maxillary artery; oc, occipital artery; opr, ophthalmic rete; sla, sublingual artery; spal, sphenopalatine artery.
figure 4.orbital and palatine arteries of the alpaca, vicugna pacos, from lateral (a) and (b) medial views.
aeth, anterior ethmoidal artery; buc, buccal artery; cac cerebral arterial circle; cdt, caudal deep temporal artery; cma, ‘common’ auricular artery; cr, carotid rete; eca, external carotid artery; eo, external ophthalmic artery; gpal, greater palatine artery; ial inferior alveolar artery; ica, internal carotid artery; iob, infraorbital artery; lpal, lesser palatine artery; ma, maxillary artery; mal, malar artery; oc, occipital artery; opr, ophthalmic rete; ptg, pterygoid branches; ra, ramus anastomoticus; rdt, rostral deep temporal artery; spal, sphenopalatine artery; splp, superior palpebral artery; vs, ventral spinal artery.
following the occipital and ica branches, a large artery arises from the superolateral surface of the eca, immediately posterior to the tympanohyal (os tympanohyoideum).
this artery is highly dendritic and supplies a large region equivalent to the distribution of the caudal auricular artery of other artiodactyls (a. auricularis caudalis), as well as some of the typical distribution of the superficial temporal (a. temporalis superficialis) and caudal masseteric arteries (a. masseterica profunda; figure 2).
the majority of branches from this parent artery supply the auricular region, without ramification by additional, individual auricular arteries (figure 2).
as such, a more accurate term for this vessel may be the ‘common auricular artery’.
after branching from the eca, the common auricular artery then ascends between the jugular process and the posterior surface of the auditory bulla, scoring the superior surface of the mastoid, caudal to the external acoustic meatus.
ventral to the external acoustic meatus, the common auricular artery distributes a posterolateral zygomatic branch that ramifies the temporomandibular joint (tmj) and contributes extensive, smaller arteries to the posterosuperior border of the masseter, a region typically supplied by caudal branches from the superficial temporal artery [60].
a stylomastoid artery (a. stylomastoidea) departs from the medial surface of the common auricular artery at the level of the stylomastoid foramen.
finally, at the level of the crista supramastoidea, the common auricular artery splits into rostral and caudal terminal branches.
this rostral branch is not homologous with the a. auricularis rostralis proper, which derives from the superficial temporal artery in non-camelid artiodactyls [46,60].
the caudal termination of the common auricular artery supplies the posterior scalp/superior occipital region as well as the cartilaginous pinna of the ear.
the rostral division of the common auricular artery supplies the remainder of the ear and gives off a proper branch to the posterior portion of the temporalis muscle.
in the alpaca, the lingual and facial arteries do not form a common linguofacial trunk (truncus linguofacialis), as the facial artery (a. facialis) has a separate origin on the lateral wall of the eca (figure 2).
the facial artery has a somewhat deviant course relative to other artiodactyls and many other mammals, in that it approaches the superficial facial region from the caudal border of the mandibular ramus (ramus mandibulae) instead of the ventral border of the mandible (corpus mandibulae margo ventralis).
in this respect, its course is somewhat reminiscent of the transverse facial artery (a. transversa facei).
the facial artery transmits a number of small vessels to the digastric, masseter and buccinator muscles, providing a substantial volume of the blood supply to the muscles supporting the oral cavity.
it terminates by splitting into superior and inferior labial arteries (a. labialis superior and a. labialis inferior).
the lingual artery (a. lingualis) is the third and anterior-most major branch of the eca, departing from the ventral surface of the parent vessel caudal to the greater horn of the hyoid (figures 2–4).
it distributes through the parenchyma of the tongue as expected, but has an aberrant branching pattern to ramify regions of the ventral mandibular border typically supplied by branches of the facial artery.
near the emergence of the lingual artery from the eca, the sublingual artery (a. sublingualis) parts from the lingual artery (figures 2 and 3).
the sublingual artery of the alpaca is relatively large and compensates for the absence of the submental artery.
in addition to supplying the sublingual gland, the sublingual artery courses along the ventral border of the mandible, supplying the floor of the mouth and the lingual vestibule.
the final branch of the eca is a greatly reduced and partially perfused superficial temporal artery (figures 1 and 2).
the typical distribution of the superficial temporal artery is ramified by a sizeable branch of the ‘common auricular artery’ (described above; figures 1 and 2).
the transverse facial artery originates on the anterior aspect of the superficial temporal artery and courses obliquely to curve around the caudal border of the mandibular ramus near the tmj (articulation temporomandibularis; figures 1 and 2).
it perfuses a small quadrant of the masseter and sends a terminal ramus to the capsule of the tmj.
3.1.2. branches and distribution of the maxillary artery the branches and distribution of the alpaca maxillary artery (ma) are summarized in the electronic supplementary material, table s2 and visualized in figures 1–4.
common to contemporary artiodactyls, the ma (a. maxillaris) is the major source of oxygenated blood to the brain (figures 3 and 4; [47]).
the only source of collateral flow to the cerebral arterial circle (circulus arteriosus cerebri) is through the ventral spinal artery (figure 4).
the ma distributes blood to the brain (via the cr), pterygoid muscles, palate, nasal cavity, oral cavity, ethmoidal region, frontal region, cranial sinuses, superficial facial structures above the maxillary tuberosity (including the upper lip and fleshy portion of the rostrum), the maxillary dentition, the dentary (including mandibular alveoli), and the lower lip and chin (figures 1–4).
the caudal deep temporal (cdt) artery (a. temporalis profunda caudalis) is the first major branch to arise as a dorsal branch from the ma (figures 1, 2 and 4).
this arterial offshoot courses deep to the posterior border of the coronoid process of the mandible, ultimately perfusing the temporalis muscle.
the cdt artery shares a common origin with the inferior alveolar and masseteric arteries (a. alveolaris inferior; a. masseterica), which proceed inferior and lateral to the ma, respectively (figures 1, 2 and 4).
the inferior alveolar artery enters the mandibular canal via the mandibular foramen.
as it courses through the inferior alveolar canal, the alveoli of the mandibular dentition are supplied before the artery ultimately exits the mental foramen.
the superficial distribution of the artery is to the lower lip and chin.
the masseteric artery separates from the ma/cdt complex dorsal to the inferior alveolar artery.
after separating from the ma, the masseteric artery hooks around the neck of the condylar process, after which it supplies the lateral facial/zygomatic region and its eponymous muscle (figures 1 and 2).
the dorsal termination supplies the tmj (figure 2).
deep to the coronoid process, the buccal artery (a. buccalis) emerges from the lateral surface of the ma (figures 1, 2 and 4).
this small artery traces the ventral surface of the zygomatic process before bifurcating into the inferior palpebral artery (a. palpebralis inferior) and a branch to the buccinator muscle between the coronoid process and the posterior border of the maxilla.
distal to the cdt artery on the dorsal surface of the ma, a variable number of rami connect the ma to the cr through the foramen orbitorotundum.
it is through these arteria anastomotica that the brain receives almost all of its oxygenated blood (figures 2–4).
the alpaca cr is further ramified via the ma by a ramus anastomoticus that, as in true ruminant artiodactyls (pecora), enters the brain case through the foramen ovale, as well as by a reduced but patent ica as described above (ramus anastomoticus: figure 4; ica: figures 2–4).
additional collateral contributions to the cr of the alpaca include the vertebral arteries (figure 4; a. vertebralis; via the ventral spinal artery (a. spinalis ventralis)— the vertebral arteries do not make a direct contribution to intracranial circulation).
the cerebral arterial circle and blood supply to the brain of camelids is discussed in detail by kiełtyka-kurc et al.
[9], and will therefore not be duplicated here.
these authors identify variation within cerebral arterial circle vessels for both new and old world camelids [9].
the ma then anastomoses freely with the ophthalmic rete (opr; figures 2–4; rete mirabile ophthalmicum).
near the pterygoid crest, the rostral deep temporal artery (a. temporalis profunda rostralis) departs the ma from within this periorbital anastomotic network.
immediately caudal to the opr, the rostral deep temporal artery proceeds superiorly along the anterior temporal line, sending perforating branches into the anterior border of the temporalis muscle (figures 1, 2 and 4).
also within this region, several pterygoid branches (rami pterygoidei) depart the internal surface of the ma (figure 4).
these branches have a short course before perfusing the pterygoid muscles.
the rostral termination of the ma is tripartite: the external ophthalmic (eo) artery departs medially (a. opthalmica interna) and the malar artery superiorly (a. malaris), with the infraorbital artery (a. infraorbitalis) continuing anteriorly (figures 2–4).
the infraorbital artery has two divisions: a lateral division, which continues through the infraorbital canal, and a medial division (the descending palatine artery; a. palatina descendens), which serves as the parent vessel for the greater, lesser and sphenopalatine (a. palatina major, a. palatina minor and a. sphenopalatina, respectively) arteries, which supply the soft and hard palates, the nasal septum, internal nasal vestibule and turbinates (figure 4).
3.1.3. arterial blood supply to the eye and orbit the arterial blood supply to the eye and orbit of the alpaca are summarized in the electronic supplementary material, table s3 and imaged predominantly in figure 4. the cr extends rostrally, outside of the braincase, to participate in the formation of an opr through which the eye and periorbita are supplied (figure 4).
the eyeball is directly supplied by the central artery of the retina (a. centralis retinae), which originates as a derivative of the cerebral arterial circle and exits the optic foramen within the optic nerve.
the remainder of the globe of the eye is supplied by the internal ophthalmic artery (a. ophthalmica interna), which originates from an anastomosis between the cerebral arterial circle and the cr.
the eo artery (a. ophthalmica externa) condenses from an extensive network of rami among the ma and ophthalmic and carotid retia (figures 1–4).
from this meshwork, the eo artery consolidates prior to transecting the orbital region (figure 4).
it supplies the periorbita, extraocular muscles and ethmoidal region (figure 4).
the ciliary trunk and ciliary vessels (aa.
ciliares) are not perfused.
direct branches of the ma supply the superficial periorbita.
the lacrimal artery (a. lacrimalis) is a small division of the ma, which arises slightly proximal to the carotid/opr complex.
it courses laterally towards the closed post-orbital bar, where it divides into lacrimal and superior palpebral branches (a. palpebralis superior).
collateral circulation to the superficial orbit is by the malar artery, which originates from the infraorbital artery (figures 1, 2 and 4).
prior to entering the orbital portion of the infraorbital canal, the infraorbital artery gives off the tortuous malar artery.
the malar follows the anterior margin of the orbit, contacting the lacrimal bone, and exiting the orbit via a notch near the lacrimal fossa.
in addition to the superficial orbit, the malar artery perfuses the caudal portion of the face.
the infraorbital artery is the rostral continuation of the ma.
the ma bifurcates into palatine and infraorbital arteries near the common orbital tendinous ring and courses ventral to the periorbita.
the orbital portion of the infraorbital artery has few branches, but gives rise to the malar artery, as described above.
the infraorbital artery then proceeds to the rostrolateral facial region through its eponymous canal.
upon exiting the infraorbital foramen, the infraorbital artery branches extensively across the lateral nasal and superior labial regions.
3.2. cranial arterial patterns of the stillborn alpaca a single stillborn alpaca was available as a representative of early developmental stages.
the stillborn alpaca (age estimated as proximate to full gestation) had been preserved in formalin for several years prior to injection.
as such, the arterial walls were hardened and several distributing arteries (infraorbital, labial and dorsal nasal) did not perfuse into the rostral-most soft tissues (figure 5).
the stillborn alpaca specimen included both head and neck, providing an opportunity to describe the branches of the cca (a. carotis communis) low in the neck (figure 5).
figure 5.cranial arteries of the stillborn alpaca, vicugna pacos, (a) superficial lateral perspective and (b) deep lateral perspective with supraorbital (s'orb), dentary (dent) and zygomatic (zyg) bones cut.
sectioned arteries are indicated in orange.
perfusion did not extend rostrally beyond the skull, into the soft tissue structures of the nasal and labial regions.
ala, alar artery; buc, buccal artery; cca, common carotid artery; cma, ‘common’ auricular artery; dna, dorsal nasal artery; eo, external ophthalmic artery; fa, facial artery; ica, internal carotid artery; iob, infraorbital artery; la, lingual artery; ma, maxillary artery; oc, occipital artery; opr, ophthalmic rete; sta, superficial temporal artery; tfa, transverse facial artery.
3.2.1. arteries of the neck the arteries of the neck of the stillborn alpaca are summarized in the electronic supplementary material, table s4, and all arteries are presented in figure 5. deviations in cca patterning across ontogeny may indicate an arterial mode of postural hypertension mitigation endemic to long-necked artiodactyls, such as giraffes [37].
of particular interest is an anastomosis between enlarged occipital and vertebral vessels that courses through the alar foramen of the atlas—the ‘alar artery’, first noted in giraffes [61] (a. alaris, sensu [37]).
in a description of the cerebral arteries of the closely related old world camel, camelus dromedarius, kanan [4] notes the presence of such an anastomosis, and, indeed, an alar artery is present branching from the cca of the stillborn vicugna.
this vessel therefore follows the same course in all three long-necked artiodactyl species (camelus [4]; giraffa [37]; vicugna, figure 5a).
unlike the condition described for developing giraffes (stillborn and 6 month old; [37]), the stillborn alpaca retains a large, fully patent ica (figure 5a,b).
the ica arises near the occipital artery from a common point on the superior surface of the cca, thus providing a precise demarcation between the cca and the eca.
the ica of the stillborn alpaca makes direct contact with the petrosal, unlike the adult in which the carotid canal is incompletely filled by the ica.
below this transition, the cranial thyroid (a. thyroidea cranialis) and descending pharyngeal (a. pharyngea descendens) arteries arise from the anterior surface of the cca (in order from proximal to distal).
the descending pharyngeal artery originates close to the hyoid, superior to the larynx.
3.2.2. branches of the external carotid artery and course of the internal carotid artery the branches of the eca of the stillborn alpaca are imaged in figure 5. the eca is the rostral continuation of the cca after the occipital, condylar and internal carotid arteries depart the dorsal surface of the parent artery near the jugular process.
in the stillborn alpaca, the eca primarily supplies the superficial face and scalp, and the deeper regions of the cranium below the level of the zygomatic bone (e.g.
floor of the oral cavity, portions of the cranial base).
the ica is a substantial and easily identifiable branch of the cca that arises as the caudal-most branch from a common origin with the occipital and condylar arteries.
the ica briefly courses anteriorly, medial to the occipital and condylar vessels, before ascending towards the tympanic floor on the deep surface of the large tympanic bulla.
this association leaves a groove on the medial wall of the bulla—a groove that is not present in fully developed adult skulls.
as the ica courses in close proximity to the petrosal, the artery makes direct contact with the bone, leaving a groove that remains in the adult even as the artery becomes relatively reduced in calibre.
within the open, developing tympanic floor, the ica courses antero-superiorly before anastomosing with the posterior extent of the cr on the internal surface of the basisphenoid, definitively anterior to the petrosal.
the remaining arteries follow the same pattern between the stillborn and adult specimens, and the branching patterns described in the electronic supplementary material, tables s1 through to s3 are therefore not replicated.
interestingly, the ophthalmic and carotid retia are already reasonably well developed in the stillborn specimen.
the full formation of the opr in early ontogeny may be owing to the fact that the ophthalmic vessels condense from large vascular plexuses consisting of the primordial ophthalmic, nasal, ethmoidal and cerebral vessels [62].
the extent of the cr may result from a different mechanism, which requires further investigation on comparative anatomical and proximate, mechanistic scales.
compared to other non-camelid artiodactyls, the cr of the stillborn alpaca, although well developed, is somewhat smaller than expected at parturition.
this may be owing to the presence of a patent ica.
by birth, sus, ovis, capra and giraffa possess retia that occupy nearly the entire floor of the basicranium, in the absence of an ica [37,39,46,63].
contrarily, in bos and bison, which maintain patent ica's at birth [46,48], the cr does not yet fill the compartment lateral to the sella turcica––a similar extent to that of the stillborn alpaca.
wible [39] notes that early artiodactyl embryos maintain a tubular ica associated with the intracranial surface of the basisphenoid.
these studies suggest that the ica is initially formed in artiodactyls, but degenerates or becomes stenotic across development.
this degeneration may result in hypoxia to the lateral sellar compartment.
hypoxia is a known mechanism for the recruitment of vascular endothelial growth factors [64].
the potential linkage between ica obliteration, hypoxia and rete formation should be explored in further detail and in a mechanistic context to resolve whether rete ontogeny is influenced by intrinsic developmental processes, or extrinsic factors, such as altitude and environment.
4. conclusion digital anatomical data collection and dissection techniques indicate the presence of a patent, functional ica in both stillborn and mature alpacas.
this conclusion supports recent work performed by kiełtyka-kurc et al.
[9], who describe a well-formed ica present across both new world and old world camelids.
the functional presence of this vessel is unusual in mature artiodactyls, as suid and pecoran artiodactyls are known to obliterate this vessel throughout ontogeny [1,2,4,37,39,43–48].
overall, the major cranial arterial branching patterns of the alpaca do not differ significantly from those studied in a comparative context by kiełtyka-kurc et al.
[9], nor do they differ significantly from the patterns detailed for the domestic dromedary [4,6,65].
new and old world camelids inhabit strikingly different habitats which may promote their own unique demands on the animals' cardiovascular systems.
that there are few major discrepancies between the arteries supplying the head and cr of these animals suggests that the cranial vascular patterns of camelids reflect phylogeny rather than function.
because camelids are frequently reconstructed as the earliest group of extant artiodactyls to originate [66–69], the maintenance of a patent ica in this group suggests a possible stepwise loss of this artery throughout artiodactyla.
this phenomenon should be validated on a clade-wide scale.
the stillborn specimen described in this study provides additional data regarding the timing of artiodactyl cranial artery patterning.
in the alpaca, the adult cranial arterial pattern is established prior to birth, contrary to the gradual, post-natal obliteration of the ica in bos and bubalis [46,48].
a similar phenomenon of an ontogenetically conserved pattern in the arteries supplying the brain has also been noted recently for giraffes; however, for giraffes, the ica is absent from an early age [37], rather than persistent throughout life as in camelids.
these developmental patterns are strikingly different, in spite of the fact that giraffids and camelids have long gestational periods (greater than 325 days; [70,71]) and face a similar cardiovascular burden owing to neck elongation.
a paucity of data on anatomical variation, developmental timing and genetic signalling necessitates further studies to assess whether these patterns arise through macroevolutionary, physiological and/or environmental mechanisms.
untangling the pattern and process underlying the evolution and development of the cr may help elucidate how this group came to occupy highly variable habitats—including the extreme environments preferred by alpacas and other camelids.
low specimen numbers should be interpreted conservatively, and future studies should focus on the inclusion of additional specimens, particularly earlier ontogenetic stages.
supplementary material table s1.
branches and distribution of the external carotid artery of the adult alpaca, vicugna pacos supplementary material table s2.
branches and distribution of the maxillary artery of the adult alpaca, vicugna pacos supplementary material table s3.
blood supply to the eye and orbit of the adult alpaca, vicugna pacos supplementary material table s4.
arteries in the neck of the stillborn alpaca, vicugna pacos.
model 1. adult alpaca arteries: https://figshare.com/s/014c954981edf40377b7 model 2. adult alpaca skull: https://figshare.com/s/5df961807eb70cf345d0 model 3. stillborn alpaca arteries: https://figshare.com/s/bb133750f346d5cb01e9 model 4. stillborn alpaca skull: https://figshare.com/s/c76b2958f99fc7687fff
@highlight
artiodactyl cranial arterial patterns deviate significantly from the standard mammalian pattern, most notably in the possession of a structure called the carotid rete (cr)—a subdural arterial meshwork that is housed within the cavernous venous sinus, replacing the internal carotid artery (ica).
this relationship between the cr and the cavernous sinus facilitates a suite of unique physiologies, including selective brain cooling.
the cr has been studied in a number of artiodactyls; however, to my knowledge, only a single study to date documents a subset of the cranial arteries of new world camelids (llamas, alpacas, vicugñas and guanacoes).
this study is the first complete description of the cranial arteries of a new world camelid species, the alpaca (vicugna pacos), and the first description of near-parturition cranial arterial morphology within new world camelids.
this study finds that the carotid arterial system is conserved between developmental stages in the alpaca, and differs significantly from the pattern emphasized in other long-necked ruminant artiodactyls in that a patent, homologous ica persists through the animal's life.
