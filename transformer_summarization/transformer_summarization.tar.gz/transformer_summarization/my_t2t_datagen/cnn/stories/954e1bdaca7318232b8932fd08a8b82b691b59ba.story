1 introduction pancreatic ductal adenocarcinoma (pdac) is characterised by loss of acino-lobular architecture, progressive subversion of the stromal/epithelial ratio and extracellular matrix (ecm) deposition [1].
pancreatic stellate cells (psc) are the conductors of the microenvironmental disruption contributing to pdac growth, early invasion and dismal prognosis [1], [2].
the hypovascular attribute of pdac is routinely utilised in the clinic for its diagnosis by imaging such as ct scan [3].
the hypovascular nature and diffuse fibrosis is also noted at histological examination [4].
in fact, this aspect has been highlighted in experimental conditions to account for lack of therapeutic effect of chemo- and radio-therapy [4], [5], [6].
the desmoplastic stroma is a dynamic temporally and spatially distinct compartment of pdac that is critically involved in tumour formation and progression and may influence the vascularity.
our recent studies have revealed a differential inflammatory infiltrate in the juxta-tumoral (<100 μm) and pan-stromal compartment in the human pdac, which may be due to multitude of cytokines, chemokines and adhesion molecules produced by this desmoplastic stroma [7], [8], [9], [10].
we postulated that these differences between the stromal sub-compartments may also exist for vascular density.
here, we demonstrate that pancreatic stellate cells (psc) are responsible for the changes in the observed tumoral and stromal sub-compartmental vascular density, which may be of prognostic relevance.
2 materials and methods 2.1 tissue microarray analyses tissue microarrays (tmas) were constructed with pancreatic tissues from 87 hpb (hepato-pancreatico-biliary) patients subjected to pancreatic resection (supplementary table 1) at barts health nhs trust (city and east london research ethics committee 07/0705/87) as described previously [7].
regions of tumour, stroma, and normal pancreas were marked on h&e-stained slides of the donor tissue blocks, and three 1-mm cores of each region were sampled per patient using the tissue arrayer minicore 3 (alphelys, plaisir, france).
tmas were stained with cd31 antibody (rabbit anti human ab28364 abcam, cambridge, ma) for the presence of vascular structures.
micro vascular density (mvd = number of vessels/mm2) and total vascular area (tva = area occupied by vascular structures as proportion of the total area expressed in/1000 or ‰) were considered as indices of vascularisation [11], [12], [13].
the ariol™ imaging analysis system (genetix, new milton, england) was used to determine vascular indices.
briefly, software is trained by the user to distinguish and quantify positive cells by their colour, shape and size as described previously [7].
cores were initially divided into “normal” (derived from patients) with other malignancies such as duodenal cancers or neuroendocrine tumours (pancreas more than 1 cm from tumour mass), “cancer” and “stroma” (the latter being cancer patients' tissues containing no epithelial component) for pdac or cholangiocarcinoma.
pdac-associated stroma was then divided into “juxta-tumoral” (≤100 μm from the epithelial cancer component) and “pan-stromal” [7].
the juxtatumoral compartment was marked using imaging callipers on all tma cores.
the panstromal vascular density was calculated by subtracting the tumoural and juxtatumoral area from each tma core and then dividing the relevant number of vessels by it.
ariol™ software detects the surface area occupied by structures measured.
finally, microscopically healthy looking tissues (obtained from pdac patients) surrounding tumours were also analysed (normal adjacent) and compared to the other groups.
the median values of all analysed tumour cores for each patient within different tma regions were used to determine the prognostic impact of all the indices.
2.2 isolation of ps-1, human telomerase reverse transcriptase, immortalization of ps-1 cells using the outgrowth method pancreatic stellate cells were isolated from an unused donated human pancreas (donation for transplantation) by the uk human tissue bank (ethics approval; trent mrec, 05/mre04/82).
the resulting cell strain, designated ps-1, was verified as being of stellate cell origin (grown in e4:f12 medium).
ps-1 cells were immortalized by 24 h incubation with retroviruses containing cdna encoding human telomerase reverse transcriptase (htert) derived from the am12 packaging cell line (am12-htert) with empty-vector transduced controls and selected with 1 g/ml puromycin.
immortalized cell telomerase activity was ascertained by the trap assay (telomerase repeat amplification protocol, oncor, inc.; manufacturer's instructions).
2.3 cell cultures and organotypic cultures psc (pancreatic stellate cells) and pcc (pancreatic cancer cells) such as capan1, colo357 and aspc1 were cultured in a standard manner as described before [10].
human umbilical vein endothelial cells (huvec) htert (a kind gift from prof tahara [14]) were cultured in huvec cells medium (hcm): m199 + 0.25% heparin + 20% fbs + 1% penicillin/streptomycin + 0.5% endothelial cells growth supplement (ecgs – sigma aldrich).
huvec were co-cultured with cancer cells or stellate cells (activated or atra-treated) in organotypic 3d gels.
pancreatic cancer organotypic cultures were constructed as described previously [15], with some modifications introduced to successfully co-culture huvec.
briefly, 1 ml of solution constituted of 0.35 ml type 1 collagen, 0.35 ml matrigel™, 0.2 ml hcm containing 5 × 105 huvec and 0.1 ml fbs containing 5 × 105 psc was poured in a collagen pre-coated well of a 24-well plate.
for triple cultures (huvec, psc and pcc) cancer cells were added the following day suspended in the feeding medium.
cell growth was monitored for the following seven days with dual-phase microscope.
huvec survival, early sprouting and formation of vessel-like structures were monitored.
gels were harvested on day seven, fixed in formal-saline, embedded in paraffin and cut into 4 μm sections for h&e staining and immunostaining.
2.4 all trans retinoic acid (atra) treatment atra (sigma-aldrich, dorset, england) were dissolved in 100% ethanol and used as described before [9].
pscs were rendered quiescent after treatment with 1 μm atra dissolved in medium for seven consecutive days as described before [9].
2.5 immunostaining paraffin embedded organotypic sections were dewaxed and rehydrated.
heat induced epitope retrieval in citrate buffer (ph = 6) was used for all antibodies.
sections were permeabilized with 0.2% tritonx-100 and blocked with 2% bovine serum albumin (#k45-001; paa laboratories), 0.02% fish skin gelatin (#g7765; sigma), 10% fbs (#a15-104; paa laboratories).
primary antibodies were incubated at 4 °c overnight.
fluorescent-labelled appropriate secondary antibodies (alexa fluor® 488, 546) were incubated at room temperature for 1 h and nuclei were counterstained with dapi.
controls were uniformly negative with appropriate isotype-specific immunoglobulin at matching dilution.
images were acquired and analysed using confocal microscopy (carl zeiss lsm 510).
2.6 mice aortic rings angiogenesis assay in order to study the angiogenic potential of the different cell lines the ex vivo mice aortic rings angiogenesis assay was performed as described before [16], with institutional review board approval.
briefly, 12–16 weeks old wild type mice were sacrificed and aorta was surgically removed, cleaned, cut in rings (approximately 20 rings/aorta measuring 500 μm diameter) and incubated overnight in medium (optimem + glutamax + 2.5% fbs, used throughout the experiment) at 37°, 5% co2.
the following day rings were embedded in solutions containing variable concentrations of collagen (0.5 mg/ml, 1 mg/ml, 2 mg/ml and 4 mg/ml).
on days one, four and seven the rings were fed with conditioned medium from aspc1, capan1, colo357, activated or atra-treated pscs with care being taken to ensure that the cell number is equal (atra-treated psc proliferate slowly).
to obtain conditioned medium from the above-mentioned cell lines, they were cultured in opti-mem + glutamax + 2.5% fbs for 24 h (the same medium used as negative control).
supernatant was then centrifuged, filtered and immediately used to feed the rings (supplementary fig.
1).
sprouting angiogenesis was quantified in all groups at days 6, 8 and 10 under dual-phase microscope.
rings were stained with bandeiraea simplicifolia (bsi) lectin-fitc (l9381 sigma-aldrich) and α-sma-cy3 (c619b sigma-aldrich) to obtain confocal images of the vascular structures as well as the supporting cells [16].
all experiments were run in triplicate.
2.7 statistical analysis statistical analysis and graphical data representation were done using the software prism v.6 (graphpad, la jolla, usa).
the normality of the distribution of the data was determined using d'agostino & pearson normality test.
summary data are expressed as the median with interquartile range (non-gaussian distributions).
comparisons between different groups were performed using one-way anova test with either kruskal-wallis or friedman test for multiple comparisons, and mann whitney u test for two groups.
kaplan-meier survival curves were generated for survival analyses using the log rank or gehan-breslow-wilcoxon test.
the level of significance was set at p < 0.05.
3 results 3.1 stroma specific hypovascularity of human pdac tma ariol™ analyses of normal pancreas, cholangiocarcinoma and pdac tissues from 87 patients revealed significant differences in microvascular density (mvd), total vascular area (tva), dimensions and distribution of vessels between normal and different cancer tissues (fig.
1).
interestingly, the pdac stromal compartment, but not cholangiocarcinoma stromal compartment, was significantly less vascular than either normal or tumoral tissue as measured by either mvd or tva.
within the pdac stroma, the juxtatumoral stroma (<100 μm of tumour, fig.
2a) had significantly less vessel density (mvd) than either the panstromal compartment or normal pancreas.
mvd for normal pancreas and panstromal compartment were similar (fig.
2b).
surprisingly, there was no difference when comparing normal pancreas and juxtatumoral total vascular area (tva) (fig.
2c).
we hypothesised that these subtle differences may be due to the differential distribution of vessels with different calibres.
the dimensional spectrum of vessels in the healthy tissue was homogeneous and normally distributed as compared to tumoral stroma which had a skewed distribution (fig.
2d).
whilst both stromal compartments demonstrate a heterogeneous vascular architecture, it is possible that in the juxta-tumoral stroma the microvessels are compressed by the dense stroma (fig.
2e).
we subsequently analysed those areas, within samples coming from cancer patients, looking microscopically normal (preserved acinar structure) but in close proximity to the cancer surrounding stroma.
remarkably, this normal adjacent tissue was hyper-vascularised compared to all the tissue sub-compartments previously analysed (fig.
3).
indeed, both micro vascular density (3c) and total vascular area (3d) of normal adjacent tissue resulted significantly higher than the correspondent values we had calculated in the tissue coming from healthy donors.
thus, microscopic vascular distribution in pdac does not resemble the symmetry of the cognate normal, functional organ or the heterogeneity seen on other cancers, affecting the same organ, such as cholangiocarcinoma.
we postulated that these subtle stromal compartment differences may be because of the presence of activated pancreatic stellate cells (psc) or immense extra-cellular matrix deposition in pdac stroma.
3.2 aortic ring angiogenesis assay ex vivo angiogenesis assays using mice aortic rings experiments demonstrated a pro-angiogenic feature of activated pancreatic stellate cells (apsc) and significant anti-angiogenic influence exerted by cancer cells (fig.
4a–e).
rendering psc quiescent with atra [9] reversed this pro-angiogenic effect (fig.
4h–j).
immunofluorescent staining of the rings confirmed the vascular nature of the sprouts (fig.
4k): endothelial cells were bsi-lectin positive, support cells and pericytes were αsma-positive [16].
progressively increasing concentrations of collagen within the embedding gel influences the formation of sprouts in a bimodal effect, intermediate concentrations being the most suitable for angiogenesis, as reported in the past [17], [18] (supplementary fig.
2).
3.3 3d organotypic cultures huvec cells, in the appropriate collagen/matrigel 3d mixture demonstrated the ability of early sprouting (fig.
5a) at 48 h and aggregating to form luminal structures at 72 h 3d organotypic co-cultures demonstrated strong anti-angiogenic signalling from pancreatic cancer cells (pcc).
indeed, the presence of pcc inhibited endothelial cells survival both in the ‘double’ huvec-pcc and the ‘triple’ huvec-pcc-psc organotypic cultures (fig.
5e).
there was almost no endothelial cells detectable 48–72 h after the co-culture started with any of cancer cell lines tested (fig.
5 c and d).
on the other hand, huvec were not only detectable, but also sprouting (fig.
5b) and assembling in luminal structures (fig.
5j) in the presence of apsc.
von-willebrand factor immuno-fluorescent staining confirmed the vascular nature of the circular vessel like aggregations of huvec in 3d (fig.
5g).
the number of endothelial cells (von willebrand factor positive) present 72 h after 3d double cultures was significantly lower when huvec were co-cultured with pcc than with psc (fig.
5f).
atra-induced stellate cells quiescence suppressed this pro-angiogenic activity, together with the previously shown capacity to shrink the organotypic gel (fig.
5h and i).
of note, a higher collagen concentration in the gels [2] suppressed huvec survival (data not shown).
taken together, these data draw the picture of a fibrovascular gradient, in which cancer cells signalling as well as dense ecm contribute to render the juxtatumoural the less vascular compartment, while activated stellate cells promote angiogenesis towards the edges of the tumour mass.
3.4 impact on patient survival patient data are summarised in supplementary table 1. three patients experiencing postoperative mortality (<30 days) were excluded from survival analysis.
briefly, pdac patients (n = 63) had worse prognosis than those with cholangiocarcinoma (n = 19) (median = 403 vs 544 days, p = 0.04).
in pdac patients, sex and lymph involvement did not correlate directly with the prognosis, whereas the well-differentiated grade was associated with a better outcome (supplementary fig.
3).
the prognostic value of the vascular indices tva and mvd was analysed within different areas of the neoplastic pancreas.
neither the whole tumoral nor the whole stromal compartment vascularisation showed any statistical correlation with the outcome (fig.
6a–d).
two specific stromal compartments' (juxta-tumoral stroma and normal adjacent tissue) vascular density (both mvd and tva) impacted patient's prognosis.
interestingly, the increased vascularisation of the juxtatumoral compartment was associated with prolonged survival, whereas both enhanced mvd and tva within the normal adjacent tissue was associated with worse prognosis (fig.
6e–h).
these findings would confirm the proposed model of development of pdac foci, based on a fibrovascular gradient.
for example, the most aggressive cancer exhibited the highest gradient i.e., having the less vascular juxtatumoral compartment and the most vascular normal adjacent tissue.
4 discussion in this report, we demonstrate that the stromal sub-compartment specific vascularisation is different, and is clinically relevant in human pdac.
radiologically it has been noted that intra-tumoral perfusion indices progressively increase from the core to the outer rim of pdac [17].
we suggest the activated pancreatic stellate cells (psc) may play a role in this differential vascular density.
we have previously demonstrated that increasing the psc proportion drives aggressive cancer behaviour, reiterating the concept that cancer development is dynamic: cellular behaviour as well as ecm composition are subject to spatio-temporal variations [1], [32].
this, in turn, can dictate behaviour of other critical stromal cell populations such as immune cells.
for example, cd8+ cytotoxic t cells could not infiltrate juxta-tumoral sub-compartment [7].
psc's impact on angiogenesis possibly is dependent on their activation status via modulation of secretome and the subsequent ecm composition.
psc have been shown to secrete a number of pro-angiogenic factors such as vascular endothelial growth factor (vegf) and periostin among others in a hypoxia-dependent manner.
activated psc produce excessive amount of ecm proteins, mainly collagen and fibronectin, contributing to dense stroma which is anti-angiogenic [18], [19], [20].
in our models, activated psc stimulates endothelial cell growth in 3d ‘double’ cultures and psc supernatant induces aortic rings sprouting.
we have also shown that atra-induced psc quiescence suppresses the psc angiogenic potential.
of note, the presence of cancer cells in ‘triple’ 3d organotypic influences endothelial cells adversely, but does not result in increases apoptosis (supplementary fig.
4), which in conjunction with results from aortic rings demonstrate the anti-angiogenic profile of pcc.
previously we had demonstrated that 3d organotypic cultures of psc and pcc, psc activation by pcc can alter the gel composition rendering them stiffer and contracted.
this effect might be mediated by secretion of collagen of fibronectin from activated psc or enhanced cross-linkage of existing collagen [1], [20].
thus, eliciting the individual direct and indirect contribution of psc, pcc and ecm proteins, to name just the main players, upon endothelial cell behaviour in the complex pdac micro-environment remains difficult when all constituents are admixed.
certainly targeting psc does seem to alter the vascular density in vivo [33].
collagen has previously been demonstrated to be anti-angiogenic in a number of assays [21], [22].
in our organotypic model, increasing relative concentration of collagen in the gel adversely affected endothelial cells' survival.
similarly, increasing the collagen proportion in the embedding aortic rings gel, we observed a significant reduction in sprouts.
thus, rather than an overall biological pro-angiogenic effect from the psc secretome as demonstrated by the aortic ring angiogenesis assays, psc may play a dynamic influence on pancreatic cancer vascularisation, by modulating the ecm to spatio-temporally to influence the vascular network.
in our experimental models, pcc (aspc1, colo357 and capan1) exerted a strong anti-angiogenic effect, inhibiting huvec survival in 3d co-cultures as well as sprouting angiogenesis of mice aortic rings.
a similar effect was shown in 2d cultures by erkan et al.
and was attributed to the pcc secretion of endostatin, a strong anti-angiogenic agent derived from collagen degradation [23].
paracrine endostatin secretion effect from pcc may explain the selective hypovascular nature of juxta-tumoral stroma.
however there are other possible molecular explanations for the differential vascular distribution, and indeed all of them may contribute in a spatio-temporal manner.
periostin, is expressed almost exclusively in stroma and is undetectable in healthy pancreatic [24].
activated psc secrete periostin in pdac [24], [25] and stimulate an auto-activation loop for psc, promote cancer cells survival under hypoxic conditions; thus create a tumour-supportive microenvironment [26].
moreover, periostin has been shown to promote angiogenesis, and slow down the ecm turnover inhibiting a number of matrix metalloproteinases (mmp) and promoting the activity of tissue inhibitors of metalloproteinases (timp) [26], placing periostin to be an active player in tissue remodelling.
notably, the deposition of periostin from activated psc selectively happens towards the invasive front of the cancer [24] and this may influence the angiogenic activity.
similarly, l1cam (cell adhesion molecule l1) is deposited on the invasive front of pdac [27].
l1cam recruits of endothelial cells from the expanding tumour, as well as the invasiveness of cancer cells [28].
these are possibly some of the molecular mechanisms which could explain the gradient of vascularisation observed by us.
from the analysis of our in vitro models model we propose, that the interplay remains complex and no single factor is dominant at all times in the spatio-temporal distribution of vessels in human pdac.
indeed, depleting stroma in murine pdac models, via either selective deletion of αsma positive fibroblasts or sonic hedgehog (shh) system in cancer cells, resulted in less differentiated, more vascularised and more aggressive tumours with a worsening overall survival in murine models [5], [6].
hence, modulating, rather than ablating pdac stroma may be more useful strategy [8].
current attempts to target newly formed tumoral vessels functional stabilization pathways (i.e.
notch/dll or semaphorins) could conceptually be more successful in view of our findings [29], [30], [31].
further studies are needed in order to identify selective markers of the invasive front and the hypoxic core which may further mechanistically implicate the differential vascular gradient.
conflicts of interest and disclosures all authors have nothing to disclose.
@highlight
background/objectives the vascular heterogeneity of pancreatic ductal adenocarcinoma (pdac) has never been characterised.
we analysed the heterogeneous vascular density of human pdac along with its prognostic correlation.
methods tissue microarrays of 87 patients with different pancreatico-biliary pathologies were analysed in an automated manner (ariol™) after cd31 staining to assess vascular density in juxta-tumoral and panstromal compartments.
in vitro and ex vivo assays were carried out to assess the role of psc.
results pdac has a distinct vascular density and distribution of vessels compared to cholangiocarcinoma.
the pdac juxta-tumoral stroma was hypovascular and the normal adjacent rim was hypervascular compared to the panstromal compartment.
these features adversely affected patient prognosis, suggesting a model for spatio-temporal pdac evolution.
mice aortic rings and 3d organotypic cultures demonstrated pro- and anti-angiogenic signalling from activated psc and cancer cells respectively.
atra-induced quiescence suppressed the pro-angiogenic activity of psc.
conclusion human pdac has variable vascularity at microscopic level suggesting that novel stromal directed therapies would need to be determined by pathological characteristics.
