case report a 70-year-old japanese man with a 50-year, 10 cigarettes/day smoking history presented with hoarseness.
chest computed tomography (ct) and brain magnetic resonance imaging (mri) showed a tumor in the left lung and multiple metastases to the lung, the bone, and brain.
among serum tumor markers, neuron-specific enolase (68.9 ng/ml) and progastrin-releasing peptide (862 pg/ml) were elevated.
the pathology of transbronchial biopsied specimens demonstrated acidophilic tumor cells showing a cord-like distribution with small necrosis and one mitosis in 10 high-power fields (fig.
1).
combined with immunohistochemical (ihc) findings of cd56+/chromogranin a+/synaptophysin+ (fig.
2a) and a low ki-67 labeling index (<20%), we diagnosed the tumor as atypical carcinoid.
figure 1. biopsied specimens stained with hematoxylin and eosin staining show small necrotic foci (inset) and tumor cells with fine nuclear chromatin and moderate eosinophilic cytoplasm growing in a trabecular pattern and organoid nesting arrangement.
only one mitosis was found in 10 high-power fields.
figure 2. hc for (a) synaptophysin and (b) alk.
(c) fish analysis of the alk locus using a break-apart probe strategy.
strongly positive staining for synaptophysin (bb) (a) and alk (5a4, nichirei biosciences, tokyo) (b) was observed in tumor cells.
(c) approximately 74% of the tumor cells showed rearrangement at the alk locus.
further analyses revealed that anaplastic lymphoma kinase (alk) gene rearrangement was observed by both ihc (fig.
2b) and fluorescence in situ hybridization (fish) (fig.
2c).
epidermal growth factor receptor mutations were not observed.
the patient was initially treated with carboplatin (auc5, day 1) and etoposide (100 mg/m2, days 1-3), however, the tumor size remained unchanged after four cycles of chemotherapy.
thereafter, he was treated with an alk inhibitor, crizotinib (pfizer, tokyo, japan) 250 mg po twice daily, which reduced the tumors in the lung (fig.
3a and b) and the brain (fig.
3c and d) by 42% and 53%, respectively, over 3 months.
figure 3. a chest ct scan and brain mri before and during treatment with crizotinib (a and c: may 2015, b and d: aug 2015).
crizotinib reduced the primary mass (arrows) from 26 mm (a) to 15 mm (b), and the multiple lung metastases (arrowheads) disappeared.
crizotinib also reduced the brain metastasis (arrows) from 13.3 mm (c) to 6.2 mm (d).
discussion although alk rearrangement accounts for approximately 5% of non-small cell lung carcinomas (nsclcs), alk rearrangement in neuroendocrine tumors (nets) including small cell lung carcinomas (sclcs), large cell neuroendocrine carcinomas (lcnecs), and carcinoid tumors is quite rare (1).
to date, only four net cases, two sclc cases, one lcnec case and one atypical carcinoid tumor case have been reported to have alk rearrangement (2-5).
in addition, nakamura and colleagues reported that no alk rearrangement was found among 227 nets including 52 carcinoid tumors (6).
the biopsied tissues in the present case were optimal specimens without crushing for microscopic observation, and alk rearrangement was confirmed using two methods (ihc and fish).
we thus contend that the lung tumor in the present case met the criteria of atypical carcinoid tumor, and that this atypical carcinoid tumor also had alk rearrangement.
however, a potential limitation of this case is that the pathology of transbronchial biopsied specimens may not reflect the character of the whole tumor.
the patient's outcome demonstrated that crizotinib successfully reduced his atypical carcinoid tumor.
the treatment of metastatic carcinoid tumors has not yet been established.
we first treated our patient with chemotherapy according to a previous report (7), however, the regimen was ineffective.
we then administered crizotinib, and it reduced the tumors in both the lung and brain.
however, it was also reported that nets with alk rearrangement may be resistant to alk inhibitors (2,3).
further analyses are needed to elucidate whether crizotinib may become a key tool for the treatment of carcinoid tumors with alk rearrangement.
the authors state that they have no conflict of interest (coi).
@highlight
this is the first report in which crizotinib, an anaplastic lymphoma kinase (alk) inhibitor, reduced an atypical carcinoid tumor with alk rearrangement.
a 70-year-old man developed a tumor in the left lung and multiple metastases to the lung and brain.
the pathology of transbronchial biopsied specimens demonstrated an atypical carcinoid pattern.
combined with immunohistochemical findings, we diagnosed the tumor as atypical carcinoid.
alk gene rearrangement was observed by both immunohistochemical (ihc) and fluorescence in situ hybridization.
he was treated with chemotherapy as first-line therapy, however, the tumor did not respond to chemotherapy.
thereafter, he was treated with crizotinib, which successfully reduced the tumors.
