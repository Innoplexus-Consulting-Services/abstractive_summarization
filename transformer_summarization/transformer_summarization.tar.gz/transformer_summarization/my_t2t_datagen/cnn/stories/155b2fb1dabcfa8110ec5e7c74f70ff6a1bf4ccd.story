introduction delirium is a syndrome characterised by disturbance of consciousness with change in cognition.
changes occur over a short period, and it has a fluctuating course.
[1] the incidence of delirium in the intensive care unit (icu) ranges from 45% to 87%.
[234] delirium is an independent risk factor for death in the icu, and can result in over sedation, increased duration of mechanical ventilation and increased length of icu stay.
[5] risk factors for delirium include metabolic impairment, substance withdrawal, severe sepsis, drugs like atropine, organophosphorus compound poisoning (opcp) and sleep deprivation.
[678] various drugs such as dexmedetomidine, benzodiazepines and antipsychotics have been tried to treat and prevent delirium; however, these drugs are associated with adverse effects.
[910] the endogenous hormone melatonin is very well known to influence the circadian rhythm,[11] and has effects on sleep quality and cycle which can be used in the management of delirium.
[1213] few animal studies have shown the benefit of melatonin in opcp-induced delirium, by reducing oxidative stress and lipid peroxidation of the brain caused by opcp.
however, data regarding its use in humans for the same is sparse.
[14] hence, this study was conducted with the primary aim of assessing the effect of melatonin on delirium and recovery profile in opcp patients.
methods this prospective, randomised, double-blind, placebo-controlled study was conducted between september 2014 and december 2015. after institutional ethical committee approval, informed written consent was obtained from patients’ relatives.
patients aged between 18 and 50 years, presenting with history and clinical syndrome suggestive of organophosphorus compound poisoning (opcp) with low pseudocholinesterase levels (<5320 iu/l) were included in the study.
acute physiology and chronic health evaluation ii (apache ii) scores were assessed at the time of admission and patients whose score was >20 were excluded.
postcardiac arrest patients, patients on chronic opioids and opioid antagonists, selective serotonin reuptake inhibitors, monoamine oxidase inhibitors, central nervous system depressants, warfarin, angiotensin converting enzyme inhibitors, diuretics, moderate to severe hepatic or renal dysfunction, known psychiatric disorder through history from relatives and patients with history of cardiac disease were excluded from this study.
decontamination of skin and gastrointestinal tract was done as per standard institutional protocol.
injection atropine intravenous (iv) was administered as 2 mg boluses, till signs of atropinization were achieved (heart rate >80 beats/min, systolic blood pressure >90 mm of hg, drying of oral and tracheobronchial secretions) and then it was followed by a titrated infusion to maintain heart rate of 80–100/min.
injection pralidoxime (p2am) iv 30 mg/kg was administered as loading dose, followed by 8–10 mg/kg/h infusion over 48 h. patients who developed acute respiratory failure due to opcp-induced cholinergic crisis or intermediate syndrome during admission to icu or during the course of stay in icu were intubated and mechanically ventilated.
using a computer generated randomisation scheme, patients were allocated into two groups.
the drug and the placebo (same coloured sugar tablets as melatonin) were removed from their original packs and placed in similar looking sachets numbered as per computer generated random numbers by the nurse not involved in the study.
the details of the sachet number, its contents and the patient receiving it, was maintained by the principal investigator and not revealed to others till the end of the study.
the nurse who administered the drug, the patient who received it and the doctor who observed the findings were all blinded to the contents of the sachet.
group m received tablet melatonin 3 mg, at 9 pm through the ryle's tube daily from the day of admission and group c received a placebo tablet at the same time in the same manner throughout the duration of icu stay.
delirium was assessed in two steps by confusion assessment method for icu (cam-icu).
the level of consciousness was first assessed using the richmond agitation-sedation scale (rass), (a 10-point scale ranging from +4 to −5).
rass score of 0 represents calm and alert patient and scores of −4, and −5 correspond to coma in whom delirium cannot be assessed.
patients with rass score of −3 or more were evaluated for delirium.
the cam-icu assesses patients for four features of delirium (1) acute onset of mental status changes or a fluctuating course, (2) inattention, (3) disorganised thinking and (4) altered level of consciousness.
the presence of at least three out of these four features was considered for a diagnosis of delirium.
[15] the level of sedation and delirium were assessed 3 times a day at 9 pm, 8 am and 4 pm daily (every shift), and the patient was diagnosed to have delirium if icu-cam was positive even on one occasion of assessment.
in case of agitation or intolerance to mechanical ventilation, (rass ≥2), rescue sedation with injection midazolam 1 mg iv and injection fentanyl 30 μg iv bolus followed by infusion of a drug solution containing injection midazolam (0.4 mg/ml) and injection fentanyl (5 μg/ml), was given and infusion titrated to maintain the rass scale between −2 and +1.
in those who were not intubated, injection lorazepam 4 mg iv boluses were used to maintain rass scale between −2 and +1.
primary outcome measures were, effect of melatonin on the duration of delirium during icu stay in opcp, overall prevalence of delirium and sedation (fentanyl and midazolam or lorazepam) requirement.
the requirement of atropine, number of patients requiring mechanical ventilation, the duration of mechanical ventilation and the total duration of icu stay were secondary outcome measures.
intensive monitoring of heart rate, systolic and diastolic blood pressure, oxygen saturation and electrocardiogram were done throughout the icu stay.
fluid and nutritional management was followed uniformly in both groups.
other significant events and side effects such as headache, nausea, vomiting if any were observed.
on the basis of an unpublished pilot study conducted in our icu, the average duration of delirium in opcp patients was observed to be 8.5 ± 2.5 days.
we hypothesised that melatonin administration would reduce the duration of delirium.
to detect a minimum of 25% reduction in duration of delirium, assuming normal distribution of values, at least 44 subjects would be required with 80% power and 5% probability of type i error to reject null hypothesis.
we included 56 patients for better validation of results.
for analytical purpose, delirium was categorised as present or absent.
percentage of patients with delirium was calculated by keeping number of patients having delirium on numerator with total number of patients assessed for delirium on that day as denominator.
the average of the percentage of delirium over 10 days is depicted as the prevalence of delirium.
doses of atropine, midazolam, lorazepam, fentanyl were categorised as increased, decreased or no change and ventilation requirement as present or absent.
apaache scores were categorised into ≤8 and >8.
chi-square test was used for categorical data.
multiple comparisons were performed using analysis of variance test for repeated measurements (rmanova).
paired student's t-test was used for paired numerical data with normal variance.
rmanova was done to know difference within and between groups for each independent variable.
further analysis was done using mantel–haenzel chi-square test to reduce the effect of confounding variables between groups.
time taken to be delirium free was analysed by log-rank (mantel-cox) test.
all analyses were two-tailed.
p < 0.05 was considered statistically significant.
statistical analysis was done using statistical package for social sciences (spss) version 21 software (ibm, north castle, new york).
results a total of 60 patients were screened for the study but only 56 patients were included for final analysis [figure 1].
the demographic variables, basal apache ii score and pseudocholinesterase levels were comparable between the two groups.
neither of the patients were intubated nor on vasopressors at admission [table 1].
figure 1 consort diagram showing the number of patients included and analysed table 1 demographic characteristics the average time taken to be delirium free was 9.05 ± 2.75 days in group c compared to 6 ± 2.92 days in group m. analysis done with log-rank test indicated a significant difference between the two groups (chi-square = 10.710,) (p = 0.001) [figure 2].
the overall prevalence of delirium in group m (50.85%) was lower compared to group c (84.81%) (p < 0.001).
there was a significant reduction in the prevalence of delirium in group m after day 3, compared to day 1 (p < 0.004).
less than 30% of patients in group m had delirium after day 5 compared to >50% patients in group c which was clinically and statistically significant (p < 0.001).
figure 2 kaplan–meir curve analysis done with log-rank test indicates that the time taken to be delirium free is significantly different in the two groups chi-square = 10.71, (p = 0.001).
group c (represented as group 1 in figure) took significantly longer time to be delirium free than group m (represented as group 2 in figure) (9.053 days vs. 6.0 days) the consumption of fentanyl and midazolam was also lower in group m compared to group c [table 2 and figure 3a, b].
the requirement for lorazepam and atropine was not different between the two groups [table 2].
table 2 comparison of outcome measures between two groups figure 3 (a and b) comparison of average daily requirement of fentanyl (a), midazolam and atropine (b) between groups, fentanyl and midazolam requirement was significantly lower in group m after day (p < 0.05) the mean heart rate was lower in group m compared to group c; however, it was statistically significant only on days 2, 6, 7, 8, 9 and 10. the mean arterial blood pressures were comparable between two groups throughout the period of icu stay [figure 4].
number of patients requiring mechanical ventilation was 21 (56.76%) in group c as compared to 16 (43.24%) in group m (p = 0.50).
the mean number of days of ventilation was 5.26 ± 5.52 days in group c as compared to 3.88 ± 3.52 days in group m (p = 0.26) [table 2].
both were not statistically significant.
duration of icu stay was 9.36 ± 6.35 days in group c as compared to 7.65 ± 3.58 in group m (p = 0.21) [table 2] which was not statistically significant.
figure 4 comparison of mean heart rate and mean arterial pressures between groups anova and rmanova tests were used for intergroup and intragroup comparison of drug consumption over first 4 days.
atropine (p = 0.151), lorazepam (p = 0.708) consumption showed no significant difference within or between groups.
fentanyl and midazolam consumption was significantly lower in group m compared to group c. further, stratified analysis using cochrane-mantel-hanzel chi-square test to reduce the effect of confounding variables (midazolam, fentanyl, apache score) also showed more delirium free subjects in group m compared to group c (p = 0.0010).
there was no significant association between the number of patients having delirium and the duration of mechanical ventilation.
there were no side effects observed in any of the patients such as vomiting, headache, rashes and itching following drug administration.
five patients in group c developed sepsis and one patient in group m developed ventilator-associated pneumonia.
three patients required tracheostomy in view of prolonged ventilation of >10 days in group c as compared to none in group m. there was no mortality in any of the groups during icu stay.
discussion the present study shows that time taken to be delirium free was shorter and prevalence of delirium was lower in opcp patients receiving melatonin.
the requirement of sedation was also reduced.
however, there was no difference in the duration of mechanical ventilation and icu stay.
society of critical care medicine recommends that all icu patients should be evaluated for delirium,[16] and it is evaluated by cam-icu.
the cam-icu method was originally validated by ely et al.
for assessing delirium and it was further used by other authors later on.
[417] it was found to be highly sensitive and specific, with a high inter-rater reliability, which allows easy and reliable assessment of delirium, even by non-psychiatric physicians and others.
assessment can be done even in intubated patients, who cannot speak.
[18] delirium commonly seen in opcp may be due to inhibition of acetylcholinesterase and imbalance between antioxidants and oxidants.
[7] it can also be due to pesticide itself, hypoxia, alcohol, other medical conditions and, atropine at therapeutic doses causes toxicity (delirium).
delirium is also seen during recovery from the cholinergic syndrome.
[1920] sleep rhythm is altered in opcp patients, thus contributing to delirium.
[21] delirium, sleep deprivation or excessive sedation can interfere with the assessment of patient's neck muscle weakness and general condition.
this can lead to difficulty in weaning from mechanical ventilation in opcp patients, leading to increased duration of icu stay and an overall increase in the costs.
[522] melatonin is mainly produced in the pineal gland from tryptophan,[2324] and acts through multiple receptor sites including opioidergic, benzodiazepinergic, muscarinic, nicotinic and most importantly melatonergic receptors present in the central nervous system and dorsal spinal cord.
[25] it regulates sleep-wake cycle; resets sleep cycle if it is disturbed.
[26] it has antioxidant property and reduces oxidative stress, thereby decreasing delirium.
[15] it also has additional analgesic and sedative sparing effect.
[2728] the drug melatonin (3 mg) has been approved by drug controller general of india as a sedative for sleep disorder, jet lag and circadian rhythm disorders.
[29] studies with different doses of melatonin on sleep and sedation in critically ill patients was found to be safe.
[2630] in a study assessing the pharmacokinetic property of the drug, melatonin at a dose of 3 mg, in critically ill patients had satisfactory oral bio-availability and also pharmacological levels were maintained up to 10 h following administration.
[31] hence, a dose of 3 mg melatonin was selected for the study.
studies assessing the effect of melatonin on delirium have shown contrasting results.
in a recent study, administration of 0.5 mg oral melatonin in elderly patients at night resulted in a reduction of incidence of delirium,[32] whereas a dose of 3 mg in elderly patients with hip fracture did not reduce the incidence of delirium but reduced the duration of delirium.
[33] in the present study, administration of melatonin decreased the duration of delirium and prevalence was reduced from the 3rd day significantly.
administration of oral melatonin perioperatively produced clinically relevant anxiolytic, sedative and analgesic-sparing effect in various types of surgeries.
it also reduced tourniquet-related pain and produced analgesia in orthopaedic upper limb surgeries,[272834] in the present study, it was observed that melatonin administration decreased the requirement of midazolam and fentanyl.
it has been observed that melatonin added to p2am and atropine in the treatment of acute opcp poisoning increases acetylcholinesterase activity in brain tissue, and shows a beneficial effect on brain injury by decreasing lipid peroxidation and oxidative stress in brain tissue which may explain the beneficial effects observed in our study.
[14] in a recent meta-analysis, assessing the influence of delirium on outcome in icu patients, the overall risk ratio for death in patients, severity of illness and the adjusted risk of mortality was high in patients with delirium.
[35] in similar analysis, there was increased length of stay and duration of mechanical ventilation in intensive care in patients with delirium.
[3] we did not find any difference in the number of patients requiring mechanical ventilation and duration of mechanical ventilation and icu stay which may be attributed smaller sample size.
since the primary aim of this study was to assess the effect of melatonin on the duration of delirium due to opcp and its treatment, we excluded patients with apache score >20 (severely ill).
there was attrition of data after 4 days, due to shift out of the patients to wards and hence validity of the study is limited.
we could not follow the patients in the wards, and there was data loss on retrospective analysis of their case sheets and hence we are not able to comment about hospital stay or mortality after discharge from icu.
however, none of the patients included in the study died during icu stay.
effect of melatonin on sleep quality of these patients could not be commented since sleep quality was not monitored in the present study, which is a major limitation.
in this study, we did not obtain the basal blood levels of melatonin which would have thrown further light on the possible effect of opcp on melatonin and consequently, delirium.
future multicentric studies with larger sample size, sufficiently powered enough to assess the effect of melatonin on the overall outcome of the patient may be required before using this drug on a routine basis.
conclusion melatonin when given to organophosphate compound poisoning patients at a dose of 3 mg orally reduces the prevalence and duration of delirium.
it also reduces the requirement of sedation in patients on mechanical ventilation.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
background and aims: organophosphate compound poisoning (opcp) is associated with high incidence of delirium.
melatonin has been tried in the treatment of delirium and has shown a beneficial effect in opcp.
this study was conducted to know the effect of melatonin on duration of delirium and recovery profile in opcp patients.
methods: double-blind randomised placebo control trial in which 56 patients of opcp confirmed by history and syndrome of opcp with low plasma pseudocholinesterase, aged >18 years and weighing between 50 and 100 kg, and acute physiology and chronic health evaluation ii score of <20 were studied.
group m (n = 26) received tablet melatonin 3 mg and group c (n = 30) received placebo tablet at 9 pm, every night throughout the intensive care unit (icu) stay.
delirium was assessed using the confusion assessment method for icu, thrice a day.
sedation was provided with injection midazolam, fentanyl and lorazepam.
duration of mechanical ventilation, vital parameters, icu stay, sedative and atropine requirement, were recorded.
results: the time taken to be delirium free was significantly lower in group m (6 ± 2.92 days) compared to group c (9.05 ± 2.75 days) (p = 0.001) and prevalence of delirium was significantly decreased in group m compared to group c from day 3 onwards.
the requirement of midazolam (group m - 2.98 ± 4.99 mg/day, group c - 9.68 ± 9.17 mg/day, p < 0.001) and fentanyl (group m - 94.09 ± 170.05 μg/day, group c - 189.33 ± 156.38 μg/day, p = 0.03) decreased significantly in group m. there was no significant difference in the average atropine consumption (p = 0.27), duration of mechanical ventilation (p = 0.26), icu stay (p = 0.21) and the number of patients requiring mechanical ventilation (p = 0.50).
conclusion: orally given melatonin in organophosphate compound poisoning patients reduces the duration of delirium and the requirement of sedation and analgesia.
