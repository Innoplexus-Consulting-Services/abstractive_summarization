1. background approximately 2 billion (24%) of the world's population is infected with intestinal helminth parasites, with high prevalence occurring in poor and deprived communities in tropical and subtropical regions, including sub-saharan africa [1].
helminths may impair the nutritional status in these infected individuals [2].
in sub-saharan africa the geographic overlap between the human immunodeficiency virus (hiv), intestinal helminth parasites, and malnutrition may have an additive impact on the competency of the immune system in affected hosts [3, 4].
this triple burden may lead to accelerated hiv and helminth disease progression [5–7].
potent immune responses and adequate nutrition are essential to resist infectious agents.
research suggests that individuals who are coinfected with hiv and helminths have lower biochemical levels of micronutrients [8], as well as carbohydrate and protein macronutrients [4, 9].
it has been reported that deficiencies of protein, energy, and micronutrients including iron, zinc, and vitamins impact on competent cell mediated and humoral immune responses, and the link to increased susceptibility to hiv and helminth coinfections in such cases has been demonstrated [10, 11].
thus, micronutrient and macronutrient deficiencies may predispose individuals to hiv and helminth coinfection as well as leading to exacerbated hiv progression, resulting in a vicious cycle of malnutrition, infection, and immune deficiency.
a significant proportion (approximately 54%) of south africans live under conditions of poverty [12].
furthermore, kwazulu-natal (kzn), a province of south africa, has a significant proportion of the population living in environments where there is lack of adequate sanitation (22.7%) and safe water supplies (15.8%) [13].
in these areas, the standard of living is generally poor and intestinal helminth infections are highly prevalent [14].
prevalence of intestinal helminths was found to range among adults from 11.2% in the inland region, 30.3% in the north coast region, and 29.2% in the south coast region [15].
kwazulu-natal also has the highest hiv prevalence in south africa, reported to be 37.4% in 2014 compared to the national estimate of 10.2% [16].
however, despite these data, studies of the possible deleterious effects of hiv and helminth coinfection on nutritional status among adults in kzn are lacking.
this study investigated the interaction of hiv and intestinal helminth coinfection with nutritional status as measured by body mass index (bmi) and biochemical micro- and macronutrient markers, against food intake levels, in a periurban informal setting in kzn.
2. methods 2.1. study setting the study was conducted in a periurban area, randomly selected from ethekwini enumeration areas under the ethekwini health district in the kzn province of south africa.
it comprises approximately 39,000 households with approximately 30% informal settlements [17].
poverty is widespread in this area, with low income households, and approximately 34% of the population in the area were not economically active [17].
there is generally poor access to facilities in the area [18] with about 60% households not having piped water inside the household [17].
the study site was a comprehensive primary health care clinic, providing all essential health care services, including hiv counselling and testing (hct).
recruitment was therefore purposively conducted in this clinic.
by default, the majority of clinic attendees were female.
2.2. recruitment and selection of study participants ethical approval to conduct the study was obtained from the university of kwazulu-natal biomedical research committee (brec ref: be 230/14).
permission to conduct the study was granted by the provincial and ethekwini health district office and the kzn provincial department of health.
the local political authorities granted permission to conduct the study in their area, after a series of meetings where the study objectives were explained and discussed.
during the recruitment process, information sessions were held in the reception area, to inform all the clinic attendees about the study.
those willing to participate were individually given further information.
after ensuring that the potential participants fully understood the study, they were asked to give informed consent.
they then underwent hiv pretest counselling at the hct clinic.
eligible participants were adults who were 18 years of age and older, not on antiretroviral therapy, and not pregnant, if female.
the enrolment process is outlined in figure 1.
2.3. ethical considerations the study commenced only after ethical approval and permissions from the relevant authorities were obtained.
all eligible participants gave written consent before enrolment into the study.
participants were tested for hiv status for the purpose of allocating them to either a study or a reference group.
pre- and post-hiv test counselling was provided.
the hiv infected individuals who had cd4 counts below 350 cells/μl were referred to the hct clinic and were excluded from participating in the study for ethical reasons.
the country guidelines recommend the protection of vulnerable individuals such as very sick or severely immunocompromised persons.
likewise, for classifying helminth infection status, participants were screened for intestinal parasites.
those who were found to be infected were referred to the clinic for anthelminthic treatment.
2.4. study design and sample size a cross-sectional survey of hiv and intestinal helminths prevalence including the investigation of nutritional status was conducted between june 2014 and may 2015 in the ethekwini health district in kzn.
the objective was to describe the nutritional status of individuals infected singly or dually with hiv and intestinal helminths in comparison with noninfected counterparts.
a sample size of 229 adults was calculated to detect an effect size of 0.4 with 80% power and probability of 95% between the study groups.
the study sample was to include 160 adults not infected with parasites and 69 infected with parasites, assuming that 30% of adults in kzn are infected with parasites, based on the 20.4% prevalence reported on kzn adults [15].
fifty percent of the study sample would be coinfected with hiv and 50% not be infected with hiv, assuming that 50% of kzn adults are hiv infected, based on the 2011 hiv prevalence of 37.4% among antenatal women in kzn and 2011 hiv prevalence of 38% in the ethekwini district [19].
2.5. measures participants were tested for hiv and were screened for intestinal helminth parasites.
demographic data and socioeconomic status data were collected using a structured questionnaire.
nutritional status was assessed using anthropometric measurements, micro- and macronutrient markers, and 24-hour food recall.
2.5.1. diagnosis of hiv status participants were tested for hiv status using the alere determine™ hiv-1/2 ag/ab combo rapid test kit (orgenics ltd, israel).
inconclusive results were confirmed using the uni-gold™ recombigen® hiv-1/2 rapid test kit (trinity biotech, ireland).
2.5.2. screening for intestinal helminth parasites each participant donated stool samples collected on two consecutive days.
upon arrival of the samples in the laboratory, the kato katz preparations were made on the same day.
a proportion of the sample was then preserved in 10% formol ether in the mini parasep tubes (mini parasep® faecal parasite concentrator: apacor ltd, england) for analysis the following day, by two trained personnel.
the stool samples were screened microscopically for intestinal helminth parasites eggs and ova using both the kato katz and the modified formol ether (mini parasep) methods.
however, diagnosis by egg count can be inaccurate [20], when a sample may not contain many eggs, which may be caused by light infections or by day to day variation in egg excretion [21].
egg excretion depends on immune responses to the parasite infection and genetic and environmental factors [22].
adams et al.
[22] recommended that analyses on the interaction between hiv and helminths should not only be based on the detection or nondetection of eggs in stool samples, since individuals who are infected with parasites in larval stages or male worms only, which cannot produce eggs, may be excluded.
hence, serological diagnosis of intestinal helminths, using ascaris-specific ige and ascaris-specific igg4 levels, was done, which supplemented the conventional microscopic diagnosis of helminth infection [20, 22, 23].
blood samples that were collected from each participant by a trained phlebotomist were assayed for ascaris-specific ige and ascaris-specific igg4 levels in a south african national accreditation system (sanas) accredited pathology laboratory, using the phadia® immunocap method.
ascaris-specific ige and igg4 antibodies show cross-reactivity between the antigens of different helminth parasites including trichuris trichiura [24, 25].
cut-off values of ascaris-specific ige and ascaris-specific igg4 were 0.35 ku/l and 0.15 ku/l, respectively, and any levels above the cut-off values were considered high.
infection with intestinal helminths was defined either by the presence of helminth eggs or ova in the stool samples and/or by high levels of ascaris-specific ige and/or igg4 in serum.
the participants were stratified, based on the hiv, stool, ige, and igg4 results, into four groups: (1) coinfected with hiv and intestinal helminths, (2) infected with only hiv, (3) infected with intestinal helminths only, and (4) not infected.
2.5.3. nutritional status anthropometric measurements.
weight and height were measured using a calibrated kern® mpe scale (kern & sohn, germany).
the participants were weighed with light clothing, without shoes.
the scale calculated and displayed the bmi after the weight and height were keyed into the scale.
to determine the bmi (kg/m2) of the participants, the cut-off points established by the world health organization [26] were used to classify the participants into underweight (<18.5), normal weight (18.5–24.9), overweight (25–29.9), and obese categories (≥30) for both males and females.
nutrient adequacy ratios (nars) analysis for micro- and macronutrient intake.
trained fieldworkers administered a structured questionnaire to collect 24-hour food recall data from the enrolled participants.
two food recall interviews were conducted to collect data on food items and their quantities, which were consumed the day before the day of the interview by each participant.
the first questionnaire was for that which was consumed on a weekday and the second was for that consumed on the weekend.
beverages, regular and special meals, and between-meals snacks consumed, and how they were prepared, were recorded.
three-dimensional food models and a food model booklet were used to indicate food quantities and meal portions.
demographic data indicates that most of the interviewees were the main people in their households who were responsible for the preparing and cooking of meals.
data for the two food recalls were then averaged and nutrient adequacy ratios (nars) were calculated by a trained nutrition specialist.
a nutrient adequacy ratio is the ratio of a nutrient intake divided by the recommended daily requirement for that nutrient [27].
biochemical analysis of micro- and macronutrients.
biochemical and haematologic analyses were conducted in a sanas accredited pathology laboratory.
the following biochemical markers of nutrition were analysed by a spectrophotometric autoanalyser: macronutrients: total protein, albumin, and prealbumin; micronutrients: calcium, magnesium, phosphate, zinc, iron, and ferritin.
haemoglobin, haematocrit, white cell count, and differential count levels were assayed with a haematology autoanalyser that uses flow cytometry and sodium lauryl sulphate- (sls-) haemoglobin methods.
2.6. statistical analysis descriptive statistics was used to summarize the data.
differences between the infected and uninfected groups were assessed using the kruskal wallis test for categorical variables and the wilcoxon signed rank sum test for continuous variables (p < 0.001).
the outcome variable has four levels: uninfected, hiv singly infected, helminth singly infected, and hiv-helminth coinfected, which is a multinomial outcome.
therefore, univariate and multivariate multinomial probit regression models were used to assess nutritional factors associated with each group (hiv singly infected, helminth singly infected, and hiv-helminth coinfected), and the uninfected group was used as a reference category.
final multivariate models of effects of independent variables associated with each group are presented.
regression coefficients with 95% confidence intervals (ci) are reported to indicate the strength and direction of association and a p value ≤ 0.05 to indicate the level of statistical significance.
data was analysed using the statistics packages stata 12.0 (college station, texas, stata corporation, usa), spss version 23 (ibm corporation, ny, usa), and graphpad prism version 5.01 (graphpad software, inc., usa).
3. results 3.1. characteristics of the study participants 3.1.1. sociodemographic profile of the study participants out of a total of 263 enrolled participants (figure 1), the majority of the participants (91.6%; n = 241) were female.
the average age of the study participants was 36 years, ranging from 18 to 83 years.
the majority were generally poor and 91.3% (n = 240) were unemployed.
some relied on government grants, either pension (n = 39; 14.9%) or a child support grant (n = 93; 35.5%), as their main source of income and 31.2% (n = 82) were dependent on their parents for their livelihood.
the education level of this population was low, only 3.3% had tertiary education and 67.7% (n = 178) had secondary level education, a few up to 12th grade.
about 33% were unable to access clean water; they reported having to share a public tap or use neighbours' taps or tanks and boreholes.
most of the population (54.8%) were using pit latrines while 7.6% reported not having any toilet facilities and some using public mobile toilets.
some participants (25.1%) were using flush toilets which were not connected to sewerage pipes (table 1).
3.1.2. nutrient intake of the study population nutrient adequacy ratio (nars) analysis from the 24-hour food recall showed that generally the intake of the micronutrients analysed was similar across all the groups, with the exception of iodine which was highest among the coinfected group and vitamin b12, which was lowest among this group (figure 2).
further analysis showed that various micronutrient intake levels were lower than the required daily intake (100%) for all the groups, which included calcium, magnesium, selenium, iodine, vitamin a, riboflavin (vitamin b2), pantothenate (vitamin b5), folate, vitamin b12, biotin (vitamin h), vitamin c, vitamin d, vitamin e, and vitamin k. phosphate, zinc, and thiamin (vitamin b1) were, however, close to the normal required intake.
intake levels for iron, niacin (vitamin b3), and vitamin b6 were higher than the 100% required daily intake for all the participant groups.
the macronutrient nars analysis showed that the coinfected group did not differ from the other groups, where all groups had low levels in all the macronutrient intake levels except for carbohydrates.
all the participant groups had a low mean intake (less than the 100% required daily intake) of energy, total protein, total fat, and total fibre (figure 3).
notably, the intake of carbohydrates was higher than the daily required quantity in all the participant groups, way above 100%, and it was highest in the hiv infected and the coinfected groups (figure 3).
the acceptable macronutrient distribution ranges (amdr) (fat 15–30%, protein 10–15%, and carbohydrate and fibre 55–75%) to energy showed that all the participant groups had lower contributions of total fat and total protein, less than 30% and 15%, respectively.
the contribution of carbohydrate and fibre to energy was within the acceptable range for all participant groups (figure 4).
3.2. prevalence of hiv and intestinal helminths the overall prevalence of intestinal helminths was 36.1% (n = 95) and that of hiv was also 36.1% (n = 95).
the participants who were singly infected with hiv were 23.6% (n = 62), those singly infected with helminths were also 23.6% (n = 62), those coinfected with both hiv and intestinal helminths were 12.5% (n = 33), and those uninfected with either hiv or helminths were 40.3% (n = 106).
the prevalence of helminth infection, determined by microscopic screening for parasite eggs or ova was 11.8% (n = 31), where the predominant species was ascaris lumbricoides (n = 25; 9.5%), followed by trichuris trichiura (n = 6; 2.3%).
furthermore, the serological diagnosis of helminth infection, by high levels of ascaris-specific ige and igg4, revealed a prevalence of 29.7% (n = 78).
3.3. nutritional status 3.3.1. anthropometry the body mass index (bmi) measures of nutritional status among hiv singly infected, helminth singly infected, hiv-helminth coinfected, and uninfected participants are described in table 2, showing the differences between the participant groups, although not statistically significant (p = 0.089).
in the uninfected group 39.0% of the participants were overweight and 51.3% were obese.
in the hiv-helminth coinfected group 16.9% were overweight and 5.3% were obese.
the helminth singly infected group had 26.3% of participants who were obese.
the proportions of participants who were underweight was low (n = 6).
of this number, 50% were hiv infected, 33.3% were helminth infected, and only 16.7% were coinfected and none of the uninfected group were underweight.
3.3.2. biochemical and haematologic analysis the biochemical and haematologic measures of nutritional status among hiv singly infected, helminth singly infected, hiv-helminth coinfected, and uninfected participants are described in table 2. except for bmi and phosphate, there was a statistically significant difference in biochemical and haematologic measures across the groups (p < 0.001).
the median micronutrient levels were varied among the groups although all were within the reference ranges, with transferrin and ferritin levels being lower in the coinfected group compared to the reference group.
percentage transferrin saturation levels were higher in the hiv infected and the coinfected groups compared to the other groups.
c-reactive protein, a marker of inflammation, was within range for all the participant groups.
the median biochemical levels of macronutrients (total protein, albumin, and prealbumin) varied among the groups although all were within the reference ranges.
total protein levels were lowest in the uninfected group and highest in both the hiv infected and the hiv-helminth coinfected groups.
albumin levels were lowest in the hiv infected group and highest in the uninfected group.
prealbumin levels were lowest in the hiv infected group and highest in the helminth infected group.
the haematology parameters revealed levels that were within the reference ranges.
however, the hiv and the coinfected groups had lower haemoglobin levels compared to the other groups.
the absolute eosinophil count levels were highest in the helminth infected group compared to the other groups.
3.4. associations between hiv and helminth coinfection and single infection with nutritional status the estimated coefficients of the multivariate multinomial probit model are presented in table 3. bmi was not statistically significant in all the infection groups.
relative to the uninfected group, the hiv-helminth coinfected group was associated with a significant increase in total protein [β = 0.16 (0.07–0.25), p < 0.001]; and percentage transferrin saturation was also significantly higher [β = 0.34 (0.02–0.67), p = 0.040] and ferritin significantly decreased [β = −0.03 (−0.06–0.01), p = 0.006].
the hiv singly infected group was associated with significant increase in total protein [β = 0.16 (0.08–0.24), p < 0.001] and a significant decrease in albumin [β = −0.26 (−0.45–0.08), p = 0.005].
the helminth infected group was associated with a significant increase in absolute eosinophils [β = 5.07 (1.52–8.63), p = 0.005].
4. discussion in many regions of developing countries, malnutrition is superimposed with endemic helminth and hiv infections.
the findings of this study showed that the prevalence of hiv (36.1%) and helminths (36.1%) was high in this adult population (the majority of whom were females), with notable levels of hiv-helminth coinfection.
this was against the backdrop of scant data on the prevalence of intestinal parasites in adults of kzn, where most of the prevalence studies have been conducted in schoolchildren.
the only other study on prevalence of intestinal helminth parasites in kzn among adults found overall moderate levels of helminth prevalence (20.4%) in the ethekwini district [15].
the higher hiv prevalence in this study is to be expected given the fact that the study site was situated in ethekwini district which has one of the highest hiv prevalence rates in kzn, with a 38% hiv prevalence rate among antenatal women being reported in 2011 for this district [19].
the majority of participants who were obese and overweight (66.3%) were among the uninfected group.
nutrient adequacy ratios analysis revealed a significantly increased carbohydrate intake among all groups, much above the recommended dietary allowance [28].
increased carbohydrate intake causes weight gain leading to obesity [29].
this may be expected as the general south african population is reported to have a significant proportion of adults who are overweight and obese.
the south african national health and nutrition examination survey (sanhanes-1) established that 25% and 40.1% of women are overweight and obese, respectively, and 19.6% and 11.6% men are overweight and obese, respectively [30].
this could probably be due to the general consumption of diets that are rich in refined carbohydrates [29, 31] which would be in line with the current study which revealed excessive carbohydrate intake.
despite the substantially elevated carbohydrate intake in this study population, the energy intake was low.
this may be attributed to the fact that fat and protein intake were less than the recommended daily intake.
protein and carbohydrates constitute a lower contribution to energy (16.8 kilojoules per gram each) compared to fat (37 kilojoules per gram) [32, 33], where protein, carbohydrates, fat, and fibre would all together contribute to the required 100%.
the contribution of total protein to the daily energy intake was lower than the recommended 15% [34] for all the participant groups.
this low protein-energy intake may predispose all the participant groups to protein-energy malnutrition.
the results of anthropometric measurements revealed that underweight was more common among the infected group: 50% among the hiv infected, 33% in the helminth infected group, and 17% in the coinfected group, while none of the uninfected group were underweight.
this concurs with the fact that weight loss and wasting is associated with hiv infection and some helminth infections, through a variety of mechanisms including increased energy requirements and/or reduced dietary intake and absorption, reduced appetite, inflammatory cytokines, and diarrhoea [4, 35].
further analysis showed that the hiv singly infected group was associated with higher total protein and lower albumin biochemical levels compared to the levels of the uninfected group.
similar observations were made in the hiv-helminth coinfected group with regard to significantly higher total protein accompanied by lower albumin levels.
total protein and albumin are serum proteins synthesized by the liver that are not only affected by nutritional status, but by inflammation and infection [36].
total protein comprises albumin and globulin fractions.
albumin in healthy individuals is highest in concentration in serum, usually 60% of the total protein [37].
hiv infection induces a nonspecific expansion of the globulin fraction due to the polyclonal stimulation of b cells in response to the acute or chronic stages of the infection and associated opportunistic infections [38, 39].
thus, the higher total protein seen in both the hiv singly infected group and the hiv-helminth infected group may have been as a result of prioritization in the formation of globulins and acute phase proteins in response to the hiv infection [37] and, proportionately, reduced albumin levels.
on the other hand, lower albumin levels may have been due to the increased rate of transcapillary leak of albumin into the interstitial fluid associated with infection [40].
both hiv and helminth infections have acute and chronic stages, resulting in chronic activation of the immune system.
however, in this study, it was not possible to determine the stages of both hiv and helminths as this was not within the scope of the study objective.
the low albumin finding in the current study is corroborated by a similar finding in the kannangai et al.
[41] study of hiv infected individuals, where albumin levels were low as well.
the food recall nars analysis also revealed a general low micronutrient intake where the median intake of calcium, magnesium, selenium, iodine, vitamin a, vitamin b2, vitamin b5, vitamin b12, vitamin c, vitamin d, vitamin e, vitamin h, vitamin k, and folate micronutrients was low for all the participant groups.
the expected finding would be similarly low biochemical levels since intake levels were low [42].
it had been hypothesized that all the micronutrient biochemical levels would be low in the singly and coinfected infected with hiv and helminths study groups.
hiv infection has been reported to predispose to micronutrient deficiency [43] and, likewise, helminth infections have been associated with deficiency of most of the micronutrients [44].
however, in this study, discrepant results were found where biochemical analyses showed that these micronutrients were within the reference range for all the participant groups.
biochemical markers as an indication of nutritional status are more reliable than food intake questionnaire data, and food intake data should be used as evidence of food variety rather than to indicate nutritional status [45, 46].
this discrepancy could have been due to underreported 24-hour food recall data as self-reported actual food intake may have been omitted consciously or by accident, leading to the discrepancy between infection status and biochemical micronutrient levels [47, 48] or the participants may have been taking supplements and failed to declare these during the collection of data [49].
food recall data collected over 3 days, accompanied by a food frequency questionnaire, may have given a more holistic indication of dietary consumption [50, 51].
further analysis showed that the hiv-helminth coinfected group was associated with significantly lower ferritin levels, although percentage of transferrin saturation levels were higher with nonstatistically significant lower transferrin levels.
low ferritin levels are typical of iron deficiency anaemia [52].
however, iron intake levels were higher than the daily required quantity for all the participant groups.
intestinal parasitic helminths are associated with iron deficiency anaemia [9, 53] and hiv on its own is also associated with iron deficiency anaemia [54].
intestinal helminths source nutrients from the host for their own growth, while the infection itself, either caused by hiv or helminths, may increase the host's need for nutrients [55].
thus, the lower ferritin levels in the coinfected group may indicate subclinical iron deficiency.
subclinical iron deficiency, even though it may be mild, impacts on the physiological functions that drive the development of cells and their metabolic function, which would have an effect on the immune system action against the hiv-helminth coinfection [56].
moreover, anaemia in the hiv-helminth coinfection may lead to increased hiv progression, increased mortality, and poor quality of life [57].
mupfasoni et al.
[58], in rwanda, however, found no association of intestinal helminth parasite infection with anaemia, although the authors attributed this to the fact that anaemia was uncommon in their study area.
although the eosinophil counts were within range for all the groups, the helminth infected and the dually infected groups had significantly higher levels compared to the other groups.
these results are in keeping with the classic feature of helminthiasis.
these infections are associated with increased production of eosinophils [59, 60], which are reported to decrease significantly after deworming [61, 62].
there was no significant association observed between hiv-helminth coinfection and single infections with micro- and macronutrient deficiency.
however, the results highlighted the various micro- and macronutrient intake patterns in the population.
low intake levels of calcium, magnesium, selenium, iodine, vitamin a, vitamin b2, vitamin b5, folate, vitamin b12, biotin (vitamin h), vitamin c, vitamin d, vitamin e, vitamin k, total protein, and energy were noted in all the participant groups.
this may indicate a general predisposition to micronutrient and protein-energy deficiency in the study participants and may need further nutritional investigations.
5. limitations of this study the cross-sectional design in this study is limited to determining the associations only and cannot infer causality.
a prospective cohort study design with randomised sampling would be recommended for such an investigation.
the small sample size may have resulted in the inability to determine a significant association between macro- and micronutrient levels and the coinfection.
moreover, the use of self-reported food recall data collected over two days, which relies on memory and correct estimations of quantity, is a limitation, although the value of the data is recognised since it indicated the food intake patterns in the population.
energy intake of the study participants was only about 50% of the reference nutrient intake.
however, the prevalence of overweight and obesity was almost two-thirds.
therefore the energy intake may be underestimated.
the fat intake may be underestimated as the 24-hour dietary recall may not cover the cooking oil intake.
this could result in inaccurate macronutrient contribution to energy.
in addition, the study used biased sampling since recruitment was from individuals who attended the hct clinic and thus the findings cannot be generalised to the population in the area where the study was conducted.
furthermore, the fact that the stool samples were screened microscopically for intestinal helminth parasites eggs and ova the following day is a limitation, although they were prepared and preserved on the same day of collection.
this could have significantly affected the ability to detect hookworm eggs since these rapidly disintegrate upon storage of stools.
nevertheless, this study adds value to the less studied but growing research area of hiv-helminth infection impact on nutritional status in sub-saharan africa.
6. concluding remarks helminth infection is a neglected disease globally, with more attention and priority given to hiv/aids, tb, and malaria.
the high prevalence of helminth infection observed in this adult population warrants attention, especially since hiv is endemic in the area.
however, there was no significant association between single and dual hiv and helminth infections with micro- and macronutrient deficiency in this population.
the frequent occurrence of obesity and overweight which is an additional health burden in south africa, possibly due to excessive carbohydrate intake, and the general low intake of micro- and protein-energy macronutrients observed in this study require further nutritional investigations and the current south african department of health campaign on healthy lifestyle needs strengthening [63].
future studies should investigate the nutritional, parasitic, and infectious conditions that may act as cofactors for rapid progression of hiv infection [64].
@highlight
in south africa few studies have examined the effects of the overlap of hiv and helminth infections on nutritional status.
this cross-sectional study investigated the interaction between hiv and intestinal helminths coinfection with nutritional status among kwazulu-natal adults.
participants were recruited from a comprehensive primary health care clinic and stratified based on their hiv, stool parasitology, ige, and igg4 results into four groups: the uninfected, hiv infected, helminth infected, and hiv-helminth coinfected groups.
the nutritional status was assessed using body mass index, 24-hour food recall, micro-, and macronutrient biochemical markers.
univariate and multivariate multinomial probit regression models were used to assess nutritional factors associated with singly and dually infected groups using the uninfected group as a reference category.
biochemically, the hiv-helminth coinfected group was associated with a significantly higher total protein, higher percentage of transferrin saturation, and significantly lower ferritin.
there was no significant association between single or dual infections with hiv and helminths with micro- and macronutrient deficiency; however general obesity and low micronutrient intake patterns, which may indicate a general predisposition to micronutrient and protein-energy deficiency, were observed and may need further investigations.
