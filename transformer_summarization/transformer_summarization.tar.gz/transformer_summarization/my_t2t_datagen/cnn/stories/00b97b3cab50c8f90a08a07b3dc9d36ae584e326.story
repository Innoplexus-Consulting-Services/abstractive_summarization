introduction “cirrhotic cardiomyopathy” is associated with abnormalities of heart structure and its function (1, 2).
the main clinical outcome of cirrhotic cardiomyopathy include decrement of systolic contractility, altered diastolic relaxation in response to physiologic and pharmacological agents, abnormal prolonged qt interval, and hyperdynamic state in cirrhotic patients (3, 4).
moreover, evidences have shown a correlation between cirrhotic cardiomyopathy and portal hypertension (1, 5).
the impaired contractile responsiveness to isoproterenol (β-adrenergic receptor agonist) stimulation is also resulted from examination of cirrhotic rats (6).
body of evidences has indicated that several main mechanisms underlying the development of cirrhotic cardiomyopathy, such as activation of nitric oxide signaling pathway (7).
towards the end, nitric oxide synthase (nos) inhibitors have been declared to attenuate the development of cardiomyocyte hypertrophy (8, 9).
nitric oxide (no) pathway has been determined to be involved in abnormal cardiac contractility in response to β-adrenergic receptor agonists (7, 10).
van obbergh et al (1996) have revealed the involvement of no pathway in the decreased ventricular contractility profound in cirrhotic cardiomyopathy (6).
evidences have shown that the systemic no overproduction induced by inos stimulation cause the negative inotropic effect.
this seems to be modulated by cytokines such as the tnf-α and il-1β, leading to cardiovascular dysfunction and hyperdynamic circulation in cirrhosis (8, 11).
inhibition of no synthesis in cardiomyocytes by inos blockade may play a critical role in the improvement of impaired contractility in cirrhotic patients.
therefore, we decided to utilize an inos inhibitor, like minocycline, in cirrhotic cardiomyopathy.
minocycline (7-dimethylamino-6-desoxytetracyc-line), a semi-synthetic antibiotic with high therapeutic potential, is typically used as broad-spectrum antibiotic (12, 13).
minocycline has extensively investigated as anti-apoptotic, antioxidant, as well as possible cytoprotective agent (14-16).
previous studies have clarified that minocycline exerts these effects by regulating the activity of inflammatory mediators, including no, tnf-α, il-1β, il6, scavengers of reactive oxygen species (ros) (17-19).
minocycline has a potential protective effect on cardiomyocytes against ischemic injury by decreasing myocardial oxidative stress and matrix metalloproteinase (mmp), and inhibiting poly (adp-ribose) polymerase-1 activity (20-22).
it has been shown that minocycline in pilot study is well torelated and effective in patients with chronic cholestatic liver disease, but this property has not been reported for any other tetracyclines (23).
furthermore, nos inhibitors cannot be used for long time in the treatment of a control of chronic cardiovascular complications in clinic.
however, moinocycline is void of such side effects.
in the current study, we aimed to evaluate the cardioprotective effects of minocycline in cardiac inotropic disorders in response to β-adrenoceptor stimulation and hyperdynamic state in a rat model of ccl4-induced cirrhotic cardiomyopathy, considering the involvement of nitric oxide pathway.
materials and methods ethics statement animal care and procedures performed during this study were approved by animal ethics committee of tehran university of medical sciences as well as animal care guidelines published by the department of pharmacology, school of medicine, tehran university of medical sciences.
animal’s manipulation adult male wistar rats weighing 100-130 g were obtained from animal house of experimental medicine research center of tehran university of medical sciences.
four rats per cage were housed with ad libitum access to normal rodent chow and water, under standard room temperature (22±2 °c) on a 12-hr light/dark cycle.
chemicals and reagents the following agents were used in our research study: minocycline hydrochloride, tetracycline hydrochloride, isoproterenol hydrochloride, n(ω)-nitro-l-arginine methyl ester (l-name), a non- specific nos inhibitor; and aminoguanidine (ag), a specific inos inhibitor (sigma-aldrich, st. louis, mo, usa), carbon tetrachloride (merck, germany), tnf-α assay kit (biosource, camarillo, ca), polyclonal rabbit anti-inos antibody (orb26708) and horseradish peroxidase (hrp)-conjugated anti-rabbit immuno- globulin g antibody (biorbyt co ltd., uk).
drug administration and experimental protocol liver cirrhosis was induced in animals through intraperitoneally (ip) injections of 0.4 g/kg of ccl4.
a solution of 1:6 of ccl4 in mineral oil was injected to the animals 3 times a week for 8 weeks up to ascites appearance (24).
all rats were randomly divided into five experimental groups that consist of age-and weight-matched rats.
each group was containing 10 animals.
group 1 only received drinking water and served as un-treated controls.
group 2 received ccl4 (0.4 g/kg; 3 times a week through experimental period).
group 3 received minocycline hydrochloride (50 mg/kg/d), freshly dissolved in normal saline and was administered orally in drinking water in a constant volume of 14 ml/100 g body weight for the period of 8-weeks (14, 22).
group 4 and 5 received the co-administration of ccl4 with minocycline hydrochloride (50 mg/kg/d) and tetracycline hydrochloride (50 mg/kg/d) respectively, in drinking water for 8 weeks.
in addition, in order to evaluate the role of the no pathway in the cardio protective effects of minocycline against ccl4-indiuced cirrhotic cardiomyopathy, the papillary muscles of the ccl4 and ccl4+minocycline groups were incubated with n (ω)-nitro-l-arginine methyl ester (l-name), a nonselective no synthase inhibitor, and aminoguanidine (ag), a selective inos inhibitor, in an organ bath, 40 min before stimulation with cumulative concentration of isoproterenol.
sample collection twenty four hours after end of the treatment protocol, rats were anesthetized by sodium thiopental (50 mg/kg; body weight).
after recording ecg and collecting heart blood, liver and ventricular heart muscles were excised.
liver specimens were sectioned and stained with hematoxylin and eosin (h&e) reagent.
light microscopy of stained liver sections was done for establishment and induction of cirrhosis in rats (25).
a small piece of left ventricular muscle was snap frozen in liquid nitrogen and stored at -70 °c for biochemical assay.
sections from the left ventricular muscle of each rat were prepared in order to histological evaluation and kept in 10% buffered formalin.
electrocardiography (ecg) ecg was recorded after the 8-week period before the excision of hearts.
ecg was recorded for 15 min in rats underwent light anesthesia.
needle electrodes attached to a bioamplifier (adi instruments, spain) were inserted under the skin for the limb lead at position ii.
for each ecg tracing, qt intervals were assessed.
the signals were digitized at a sampling rate of 10 khz by a powerlab system and were exhibited using lab chart 7 software (adinstrument, australia).
the q-t intervals, presented as corrected q-t (qtc), were calculated in a 5 min ecg.
the qtc was obtained using bazett’s formula (qtc = qt/ √r-r) (26).
left ventricular papillary muscle contractile study after ecg recording, left ventricular papillary muscles were excised and isolated in a cold oxygenated physiological salt solution (pss) aerated with 95% o2 and 5% co2.
physiological salt solution contains the following in mmol/l: nacl, 112; kcl, 5; cacl2, 1.8; mgcl2, 1; nah2po4, 0.5; kh2po4, 0.5; nahco3, 25; glucose, 10; and edta, 0.004 (ph=7.4) (27).
papillary muscles were attached vertically to an isometric force transducer, under a tension of 500 mg in order to get maximum contractile force.
the papillary muscles were equilibrated in a 25 ml glass chamber in an organ bath (grass 88 stimulator; grass instruments, ma, powerlab, usa) for 90 min before the assessment of any drugs were used.
the temperature of the bathing buffer was 33 °c.
after equilibration, the muscles were subjected to electrical-field stimulation at 1 hz and 30 v, which is about 20% higher than the threshold to record the contractile force.
basal contractility was defined as the stable baseline contractile force of papillary muscles before the addition of the stimulating agents.
to assess papillary muscle responsiveness to isoproterenol, the papillary muscles were stimulated by cumulative concentrations of isoproterenol (10−10 to 10−5 m) to obtain a β-adrenoceptor concentration–response curve.
maximal effect (rmax) was defined as the contractile force after addition of the highest concentration of isoproterenol (10−5 m).
for each concentration of isoproterenol, the increase in recorded contractile force was expressed as a percentage of the basal contraction (8).
the aims of these studies were to explain whether selective and non-selective nos inhibitors, ag and l-name respectively, added to the minocycline treated cirrhotic animals have additional effect on papillary muscle contractility and weather this effect is mediated by no.
for these studies, in some experimental groups, concentration response curves were constructed, 40 min after the papillary muscles were incubated with l-name at a concentration of 10−4 m and ag (10−5 m), before the administration of isoproterenol.
all doses of the drugs were selected based on pre-examination pilot studies.
measurement of intrasplenic pulp pressure (ispp) splenic pulp pressure was measured as an index for portal pressure.
under an intraperitoneal injection of sodium thiopental anesthesia (50 mg/kg; body weight) rats underwent laparatomy and the spleen was exposed by retraction on the perisplenic fat.
intrasplenic pressure was measured by a pe tube 20 gauge needle, inserted into the splenic parenchyma.
the needle was connected to a pressure transducer that was linked to a powerlab system (adinstruments, australia).
splenic pulp pressure was calibrated using a straight tube filled with saline solution and is expressed in mm h2o (28).
measurement of plasma nitrite concentration the levels of nitrite/nitrate, as indicators of no production, in plasma samples were measured using griess reagent (29).
at the end of the experiment, blood samples collected from the animals in different groups were centrifuged at 21,925 g for 1.5–3 hr at 4 °c, through a 30 kda molecular weight filter (centricon millipore, bedford, ma, usa).
briefly, after removing substances layer, the samples were loaded in a 96-well microtiter plate (100 µl).
saturated solution of 100 µl of vanadium (iii) chloride (vcl3) was added to the wells followed by the griess reagent (100 µl each).
the plates were measured using an elisa standard plate reader at 540 nm, followed by incubation at 37 °c for 30 min.
the value obtained represented the amount of plasma nitrite/nitrate.
results are expressed as micromoles.
immunohistochemistry for immunohistochemical examination, the remov-ed left ventricle samples were immediately fixed in ice-cold freshly prepared 10% formalin and then the heart pieces were embedded in paraffin.
the section blocks were cut and stored for immunohistochemistry.
after deparaffinizing, 10 μm sections of the left ventricle muscle, in xylene and rehydrating in specific decreasing concentrations of ethanol and treated with 3% hydrogen peroxide in methyl alcohol for 5 min to block endogenous peroxidases activity.
immunohisto chemical staining based on the avidin-biotin peroxidase method.
human tonsil tissue was used as positive control and reaction with polyclonal rabbit anti-inos (1:2000 dilution) antibody for 1 hr at room temperature followed by incubation with the secondary hrp-conjugated rabbit anti-rabbit immunoglobulin g antibody (1:2000 dilution) was done for 30 min at room temperature.
after washing, the sections were successively treated with tris buffer (ph 7.4) for three times.
the sections were incubated with diaminobenzidine-hydrogen peroxide solution for 10 min and with 5% cuso4 for 5 min, and ultimately counterstained with hematoxylin-eosin; quantification of inos positive cells was performed by obtaining brown-colored precipitation of cells per high power field (20×) under light microscopy.
ventricular tnf-α quantification to measure tissue tnf-α, an elisa available kit was used.
the left ventricular samples were homogenized in ice-cold phosphate-buffered saline (pbs) and centrifuged at 14,200 g for 30 min.
50 μl of the samples and standard (bovine serum albumin) were pipetted into a 96-well plate precoated with rat tnf-α specific antibody.
following addition of biotinylated anti–tnf-α solution (50 μl) to each well plate and incubated for 90 min at room temperature.
the wells were washed for 4 times with wash buffer.
then, 100 μl of streptavidin-peroxidase was added to each well, and incubated for 45 min at room temperature and repeatedly washing process for 4 times with pbs.
subsequently, exposed to 100 μl of stabilized chromogen and incubated for 20 min.
finally, 100 μl stop solution was added to each well for spectrophotometrically analysis at λ=450 nm (8).
western blot analysis western blot analysis was performed using isolated left ventricle tissues.
briefly, left ventricle samples were homogenized in buffer (20 mmol/l tris-hcl (ph 7.2), 0.2 mmol/l phenylmethylsulfonyl fluoride, and 1 mm dithiothreitol) with homogenizer.
the homogenate was centrifuged at 40,000 g and resuspended in tris buffer containing proteinase inhibitor.
40 μg of the denatured protein samples were loaded and separated on sodium dodecyl sulfate-10% polyacrylamide gel (sds-page) by electrophoresis.
then, proteins were transferred to pvdf membrane at 4 °c by wet electroblotting for 2 hr.
the consequence blots were blocked at room tempera-ture with 3% skimmed milk in 0.1% tween tris-buffered saline buffer (tbs-t) (ph 7.5) for 1 hr.
the membranes were subsequently washed with tbs-t for 3 times, and incubated overnight at 4 °c with polyclonal rabbit anti-inos primary antibody (1:1000 dilution).
those exposed to horseradish peroxidase-conjugated anti-rabbit secondary antibody (1:20000 dilution).
finally, detection of blots was performed with enhanced chemiluminescence (ecl western blot kit, amersham) method (30).
the intensity expression of inos protein was semi-quantified measured using imagej softwar (national institutes of health, bethesda, md) defining as the inos protein densitometric ratio (%).
statistical analysis the results are expressed as mean±sem.
statistical evaluation of the data was performed with an analysis of variance (one-way anova), followed by tukey’s post test in the case of 3 or more experimental groups.
to examine the comparison between 2 groups, student’s t-test was used.
for evaluation of two variables (cirrhosis vs. control and other treatment groups) analysis was performed via two-way anova followed by bonferroni post test.
statistical analyses were calculated by graphpad prism software (version 5.0, graphpad software, inc., san diego, ca, usa).
a p-value less than 0.05 were considered statistically significant.
results all animals treated with ccl4 developed cirrhosis symptoms such as weight loss, jaundice, brown urine, ascites, stiffness of the liver and significant increase in spleen weight (1.62±0.13 vs. 2.86±0.61 g in control vs. ccl4-induced cirrhotic rats, ***p<0.001) contributing to enhancement of portal hypertension.
liver damage was confirmed with microscopic evaluation by h&e staining of liver tissues sampled from cirrhotic rats.
the analysis revealed regenerative nodules of hepatocytes, extensive focal hepatocellular necrosis and bridging fibrosis between portal regions as shown in figure 1. figure 1 histological changes in liver tissue of ccl4-induced cirrhotic rats (h&e; magnification ×100 and ×400).
(a) focal hepatocellular necrosis and apoptotic cells are clearly seen (b) fatty degeneration and patchy inflammatory cells infiltration are observed evaluation of ecg parameters the influence of exposure to ccl4 and treatment with minocycline on ecg parameters is shown in figure 2. qtc intervals were assessed in control, ccl4 and minocycline-treated groups.
significant prolongation in qtc intervals were observed in ccl4-induced cirrhotic rats compared to control rats (p<0.001).
moreover, the prolonged qtc interval in cirrhotic rats was normalized by minocycline (50 mg/kg) (p<0.05).
figure 2 comparison between qt intervals (qtc) of different experimental groups.
values are expressed as mean±sem; n=6 for each group.
***p<0.001 and * p<0.05 compared to control group; #p<0.05 compared to ccl4-induced cirrhotic rats effect of minocycline on the intrasplenic pulp pressure intrasplenic pulp pressure was measured and used as an index of portal pressure.
significant differences in portal pressure were observed between control, ccl4-induced cirrhotic, minocycline and tetracycline-treated cirrhotic rats (p<0.001; figure 3).
portal pressure was gradually decreased after treatment of ccl4-induced cirrhotic rats with minocycline (p<0.05) compared to ccl4-induced cirrhotic rats, as shown in figure 3. figure 3 effect of minocycline on intrasplenic pulp pressure (ispp) of rats in different experimental groups.
values are expressed as mean±sem; n=6 in each group.
a significant reduction was observed in ispp in the ccl4+minocycline group.
also, ispp significantly decreased in minocycline group.
***p<0.001 compared to control group.
#p<0.05 compared to ccl4-induced cirrhotic rats.
$$p<0.01 compared to minocycline group however, treatment of cirrhotic rat with tetracycline failed to decrease the portal pressure in comparison with ccl4-induced cirrhotic rats.
furthermore, we observed a significant increase in portal pressure of rats treated with ccl4+minocycline in comparison with the rats received minocycline (p<0.01; figure 3).
effects of minocycline and nos inhibitors on papillary muscle contractility the effect of minocycline hcl on cardiac contractility was examined.
baseline isoproterenol-stimulated papillary muscle contractile force was significantly reduced in ccl4-induced cirrhotic rats compared to control group (74.56%±9.78% vs. 117.41%±8.55%, p<0.001, for each variable).
the maximum response (rmax) to isoproterenol stimulation was achieved at 10−5 m. also, the isoproterenol concentrations inducing half-maximal response (ec50) were −5.7±1.06 vs. −6.1±1.1 in the ccl4-induced cirrhotic and control group, respectively (figure 4a).
however, the rmax of contractile force responsiveness to isoproterenol in minocycline-treated rats was not significantly different compared to control group (figure 4b).
figure 4 cumulative concentration-response curve for isoproterenol in left ventricular papillary muscles isolated from control, ccl4-induced cirrhotic and minocycline-treated rats.
(a) the basal contractile force was significantly reduced in ccl4-induced cirrhotic rats compared to control group.
maximal response (rmax) for ccl4-induced cirrhotic rats was significantly lower than controls.
also, a right-ward shift of the concentration-response curve for isopreterenol was observed in ccl4-induced cirrhotic rats vs. controls.
***p<0.001 compared to control group.
(b) no significant differences were observed in comparison between control and minocycline-treated groups (n=6 in each group).
(c) cumulative concentration-response curve for isoproterenol in left ventricular papillary muscles isolated from ccl4, ccl4+minocycline and ccl4+tetracycline groups: treatment with minocycline (50 mg/kg) normalized the basal contractile abnormalities in ccl4-induced cirrhotic rats.
contractility was significantly elevated in ccl4+minocycline group compared to ccl4-induced cirrhotic rats (**p<0.01).
treatment with tetracycline (50 mg/kg) showed no significant changes of responsiveness to isoproterenol stimulation in ccl4-induced cirrhotic rats (n=6 in each group) a significant elevation of rmax in the resulted concentration–response curve was observed in the ccl4+minocycline group compared to ccl4-induced cirrhotic rats (figure 4c).
although treatment with minocycline normalized the basal contractile abnormalities in response to isoproterenol (p<0.01, for each variable) in the cirrhotic rats, tetracycline showed no significant change of responsiveness to isoproterenol in cirrhotic rats (figure 4c).
these data demonstrated that minocycline improves the maximal contractile force (rmax) in response to isoproterenol stimulation in cirrhotic rats.
on the other hand, when the cirrhotic papillary muscles were incubated with l-name, no significant difference in contractile response to isoproterenol stimulation was demonstrated.
in contrast, when the papillary muscles from minocycline-treated cirrhotic rats were incubated with l-name, contractile response to 10-5 m and 10-6 m of isoproterenol stimulation was significantly increased (p<0.001, figure.
5a).
when the papillary muscles from cirrhotic rats incubated with ag contractile force increased significantly (p<0.05).
in addition, incubation with ag in minocycline-treated cirrhotic rats reversed the reduced contractile response to 10-5 m (p<0.001) and 10-6m (p<0.05) of isoproterenol stimulation compared to ccl4-induced cirrhotic rats (figure 5b).
the results showed that rmax of papillary muscles isolated from ccl4-induced cirrhotic rats (74.56%±9.78%) was significantly different from the two other groups (ccl4+minocycline+l-name and ccl4+ minocycline+ag; rmax 97.21%±8.4% and 99.82%±7.8%, respectively).
furthermore, both l-name and ag exerted a positive effect on papillary muscle contractility in ccl4-induced cirrhotic rats treated with minocycline (figures 5a, b).
figure 5 (a) cumulative concentration-response curve for isoproterenol in left ventricular papillary muscles isolated from ccl4 and ccl4+minocycline groups after incubation with l-name (10-4 m).
contractility was significantly increased in ccl4+minocycline+l-name group compared to ccl4-induced cirrhotic rats in response to 10-5 m (*** p<0.001) and 10-6 m (### p<0.001) of isoproterenol (n=6 in each group).
**p<0.01 ccl4+minocycline group vs ccl4-induced cirrhotic rats.
(b) cumulative concentration-response curve for isoproterenol in left ventricular papillary muscles isolated from ccl4 and ccl4+minocycline groups after incubation with ag (10-5 m).
contractility was significantly increased in ccl4+ag group compared to ccl4-induced cirrhotic rats in response to 10-5 m of isoproterenol (*p<0.05).
also, a significant increase in contractility response was observed in ccl4+minocycline+ag group compared to ccl4-induced cirrhotic rats in response to 10-5 m (*** p<0.001) and 10-6 m (# p<0.05) of isoproterenol (n=6 in each group).n**p<0.01 ccl4+minocycline group vs ccl4-induced cirrhotic rats effects of minocycline treatment on plasma nitrite and cardiac tnf-α levels the plasma concentration of nitrite and tnf-α level in cardiac tissue are presented in table 1. tnf-α levels in cardiac homogenates showed a significant increase in ccl4 and ccl4+tetracycline groups compared to control group (p<0.001).
the results demonstrated a significant decrease of ventricular levels of tnf-α in cirrhotic animals treated with minocycline compared to ccl4-induced cirrhotic rats (p<0.01).
plasma concentration of nitrite in ccl4-induced cirrhotic rats was significantly higher than that in the control group (p<0.001).
also, our data showed that the increased plasma level of nitrite can be reduced by 8-week administration of minocycline to cirrhotic rats (p<0.01).
in contrast, treatment of tetracycline in cirrhotic rats exerted no significant effect on plasma nitrite and ventricular level of tnf-α compared to ccl4-induced cirrhotic rats.
table 1 ventricular tnf-α levels and plasma concentration of nitrite in the studied groups name source control ccl4 mino ccl4+mino ccl4+tetra tnf-α (pg/mg protein) heart 186±31 267±36a 178±31 206±31b 243±34a nitrite (µmol/l) plasma 40±3 73±6a 35±4 49±3b 64±4a values are expressed as mean±sem (n=6 in each group), a p<0.001 vs control, b p<0.01 vs ccl4 plasma concentration of nitrite in ccl4-induced cirrhotic rats was significantly higher than that in the control group (p<0.001).
also, our data showed that the increased plasma level of nitrite can be reduced by 8-week administration of minocycline to cirrhotic rats (p<0.01).
in contrast, treatment of tetracycline in cirrhotic rats exerted no significant effect on plasma nitrite and ventricular level of tnf-α compared to ccl4-induced cirrhotic rats.
ventricular inos protein expression as shown in figure 6, inos protein staining was observed in cardiomyocytes of cirrhotic rats.
the results showed significant increase of inos protein expression in cirrhotic heart in comparison with control and minocycline-treated ones.
figure 6 immunohistochemical staining of inos protein.
in the cirrhotic hearts, inos-positive cells are localized in cardiomyocytes.
no markedly immunostaining is observable on the slide resulted from control and minocycline-treated groups.
note the increased immunostaining of inos in the myocytes of the rats with cirrhosis, as well as, ccl4+tetracycline group.
in contrast, treatment with minocycline caused a decreased significantly inos immunostaining in ventricles isolated from cirrhotic rats.
(original magnification 40×) a representative immunohistochemical localization of inos protein in ventricles of all experimental groups is shown in figure 6a decreased in inos immunostaining was observed in ccl4+minocycline hearts in comparison with cirrhotic hearts (figure 6d).
these data were consistent with the results of western blot assay, confirming decreased inos protein expression in ccl4+minocycline hearts compared to cirrhotic ones (figure 7).
on the other hand, there were no significant differences in inos protein expression and localization between ccl4 and ccl4+tetracycline hearts (figures 6e, 7).
figure 7 western blot analysis of inos protein expression in hearts.
optical densitometry showed a significant difference between controls and ccl4-induced cirrhotic rats (***p<0.001).
significant decrease of optical densitometry of inos protein expression in heart isolated from minocycline- and ccl4+minocycline- groups compared to ccl4-induced cirrhotic rats (###p<0.001, n=4) discussion we evaluated the protective effects of minocycline in the rat model of ccl4-induced cirrhotic cardio-myopathy and also determined the possible involvement of nitric oxide pathway in the activity of minocycline.
in this investigation, the isolated papillary muscle contractility in response to isoproterenol stimulation was significantly impaired in ccl4-induced cirrhotic rats, which was consistent with previous findings from bile duct-ligated (bdl) animals (8).
the results demonstrated that the inhibition of the myocardial no synthesis by the minocycline reverses the impaired left ventricular papillary muscle contrac-tility response to isoproterenol, and also shortens the prolonged qtc in rats with cirrhosis.
this finding is in agreement with minocycline effect on ecg in cirrhotic rats.
minocycline normalized the prolong qtc interval in cirrhotic rats.
in addition, incubation with either l-name, non-selective nos inhibitor, or ag, selective inos inhibitor, normalized the contractile responsiveness of the isolated papillary muscles to isoproterenol stimulation in minocycline-treated rats with cirrhosis.
our results showed a marked correlation between cardiac contractility, serum nitrite levels, ventricular level of tnf-α and inos expression in the studied groups.
no is produced in endothelial cells and cardiac myocytes, modulating cardiac contractility (7).
also, no overproduction seems to play an important role in pathophysiology of cardiovascular complications in cirrhosis (8, 31).
therefore, the ability of minocycline to inhibit inos expression makes a potential of the improvement of cardiac contractility in cirrhosis.
this was confirmed by treatment of the cirrhotic rats with minocycline for an 8-week period.
these findings provide an evidence for the role of minocycline in reduction of no and subsequent increasing the responsiveness of papillary muscles to β-adrenoceptor stimulation following cirrhosis.
these findings were strengthened by observation of enhanced inotropic responsiveness to isoproterenol stimulation following incubation of the isolated papillary muscles with either l-name or ag.
the proposed mechanism underlying the effect of minocycline on cardiac contractility by decreasing no synthesis is presented as a schematic diagram in figure 8. in the current study, the increased serum levels of no metabolites, as cardio-depressant substances, in ccl4-induced cirrhotic rats were reduced by minocycline.
it seems that inhibitory effect of minocycline on no production is associated with a cgmp-mediated inhibition of voltage-dependent ca+2 current, leading to inhibition of phosphodiesterase in the heart.
this causes a reduced camp degradation or phosphorylation of cgmp-dependent protein kinase (pkg), resulting in an increased influx of calcium via l-type ca+2 channel or release of calcium from intracellular sarcoplasmic reticulum.
ultimately, actin myosin cross linking is activated to improve the myocardial contractility in cirrhotic heart (7, 32, 33).
figure 8 schematic of potential mechanisms underlying the positive inotropic effect of minocycline in cirrhotic myocyte.
the increased contractility via accelerated calcium release of cardiac l-type voltage dependent ca+2 channels or sarcoplasmic reticulum at cardiac myocytes is a downstream of blocked inos with minocycline in cirrhosis minocycline is a potent antibiotic highly effective in wide spectrum of pathologies.
minocycline has been found to exert various other biological effects in addition to its antimicrobial activity.
in our current results, the effects were found to be associated with the inhibition of inducible nitric oxide synthase (17).
also, minocycline can inhibit cell death by reducing both proapoptotic and proinflamatory mediators.
a recent pilot study conducted in sixteen patients with chronic cholestatic liver disease showed that minocycline in twice daily dose of 100 mg orally for one year is well tolerated and has potential beneficial effect on chronic cholestatic liver complications (23).
based on our current data, we found that changes of ventricular no synthase by minocycline occurs; therefore it might be the target for minocycline in terms of its ameliorating effect on cirrhotic cardiomyopathy.
on the other hand, liver cirrhosis leads to hemodynamic disorders, such as increased resistance to portal blood flow.
the increased hepatic resistance is resulted from the contraction of myofibroblasts in portal hypertensive condition.
this hepatic endothelial dysfunction can be partly attributed to modulate no bioavailability in the intrahepatic microcirculation.
in addition, lower sensitivity of hepatic stellate cells (hscs) may cause the activation of hsc, liver sinusoidal vasoconstriction, and subsequent increased hepatic resistance tone and portal hypertension (34, 35).
our data on the role of nitric oxide in portal pressure have shown that inhibition of no production by minocycline may play an essential role in the improvement of portal hypertension induced by liver cirrhosis.
the results presented herein support the potential of no to induce portal hypertension, which can be controlled by minocycline.
moreover, the elevated tissue levels of the cytokines including tnf-α and il-1β along with cardiac contractility is contributed to the overproduction of no, a negative inotropic agent, via stimulation of inos in cirrhosis (7, 36, 37).
liu et al demonstrated that the reduced isoproterenol-stimulated inotropic effect in the cirrhotic heart may be attributed to cytokine-induced stimulation of inos (8).
several studies have shown that the increased no synthesis in cirrhotic cardiac tissue is associated with the elevated tnf-α level (8, 38).
we showed that minocycline decreases the enhanced level of tnf-α, resulting in a normal inotropic effect of cirrhotic papillary muscles.
this effect is believed to be mediated by a no-dependent mechanism.
the present investigation has also demonstrated an increased cardiac inos protein expression in cirrhotic heart.
our data was consistent with the clinical and pre-clinical examinations on patients with different cardiomyopathic states (8, 39, 40).
the immunohistochemistry, as well as, western blot technique confirmed the hypothesis that distribution of inos in the ventricles of ccl4-induced cirrhotic rats and its localization in cardiomyocytes are increased.
in association to some common effects of both drugs, tetracycline lacks the effect to inhibit nitric oxide synthesis as shown by our treated group.
while, in addition to its antibacterial property, minocycline also exerts inhibitory effect on nitric oxide synthesis.
this is the main distinctive effect which we reported in our current study.
cardioprotective effect of minocycline has been reported to decrease the infarct size, as a marker of heart damage, in cardiomyocyte culture (20-22).
our study suggests that treatment of cirrhotic rats with minocycline may results in an increased cardiac contractility in response to isoproterenol and normalizes portal pressure by inhibiting no production.
all these results strongly support the findings of liu et al and van obbergh et al that an no-dependent pathway is a contributed to the pathogenesis of cirrhotic cardiomyopathy (6, 8).
the experimental study has demonstrated the critical role of minocycline in the improvement of cardiac dysfunction in ccl4-induced cirrhosis.
conclusion the present study has provided evidence that inhibition of nitric oxide synthesis may attenuate the liver cirrhosis-induced cardiac contractile dysfunction.
therefore, minocycline can exert protective effects on cirrhotic cardiomyopathy by reducing the no production.
in conclusion, our findings may open a new avenue to find novel indications for minocycline as a good candidate drug for treatment or management of patients with cirrhotic cardiomyopathy in future.
@highlight
objective(s): an increase in nitric oxide (no) production has been reported in cirrhotic cardiomyopathy and, portal hypertension.
since minocycline has been shown to inhibit no overproduction, we aimed to examine its role in a rat model of ccl4-induced cirrhotic cardiovascular complications.
materials and methods: portal pressure and inotropic responsiveness of isolated papillary muscles to isoproterenol were measured in cirrhotic rats, following minocycline (50 mg/kg/day for 8 weeks) treatment.
moreover, isolated papillary muscles were incubated with nonselective and selective nitric oxide synthase (nos) inhibitors, n (ω)-nitro-l-arginine methyl ester (l-name) and aminoguanidine (ag) respectively, in an organ bath.
ventricular expression and localization of inducible nos (inos), tumor necrosis factor-alpha (tnf-α) and serum nitrite concentration were evaluated.
results: we found a decreased portal hypertension in minocycline-treated cirrhotic rats.
cirrhosis decreased contractility in response to isoproterenol stimulation, which was significantly attenuated by minocycline.
incubation with either l-name or ag reversed the impaired contractility in cirrhotic rats.
furthermore, minocycline decreased inos expression and localization in cardiomyocytes.
a drop in serum nitrite and cardiac tnf-α level were also observed in cirrhotic rat that were treated by minocycline.
conclusion: the results suggest that minocycline may improve impaired cardiac contractility and hyperdynamic state in cirrhotic rats, and this effect could be mediated by no-dependent mechanism.
