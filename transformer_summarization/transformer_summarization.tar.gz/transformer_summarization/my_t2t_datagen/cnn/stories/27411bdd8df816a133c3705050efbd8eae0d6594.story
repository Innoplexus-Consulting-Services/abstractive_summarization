1 background and introduction 1.1 rationale the add-aspirin trial includes participants with breast, colorectal, gastro-oesophageal and prostate tumours which, together, accounts for approximately one third of all cancer cases and cancer deaths [1].
the selected disease sites are those for which (i) the evidence relating to potential benefit of aspirin is strongest; (ii) the potential impact is large (common cancers with large numbers of cases diagnosed at an early stage, or where outcomes of curative treatment are particularly poor); and (iii) recruitment is feasible.
as a low-cost pharmaceutical, feasible to administer in both resource poor and rich countries, aspirin has the potential to significantly impact on cancer outcomes worldwide.
this, combined with other possible health benefits (such as cardiovascular effects), means that aspirin warrants further investigation as an anti-cancer agent.
1.2 supporting evidence there have been well over 100 case-control and cohort studies investigating the use of aspirin and cancer risk [2].
a meta-analysis of such studies showed that aspirin use resulted in significant reductions in the risk of developing cancer, most notably in colorectal (relative risk (rr) 0.73, 95% confidence-interval (ci) 0.67–0.79), gastric (rr 0.67, ci 0.54–0.83), adenocarcinoma of the oesophagus/cardia (rr 0.67, ci 0.54–0.83), squamous cell carcinoma of the oesophagus (rr 0.64, ci 0.52–0.78), breast (rr 0.90, ci 0.85–0.95), and prostate cancer (rr 0.90, ci 0.85–0.98) [2].
observational studies have also shown improvements in survival with aspirin use after a diagnosis of breast [3], [4], [5], colorectal [6], [7], [8], [9], [10], [11], gastro-oesophageal [12], [13] and prostate cancer [14], [15], [16].
randomised data is available to indirectly substantiate these observations.
a meta-analysis of individual participant data on cancer incidence in randomised trials (designed to investigate the effect of aspirin on vascular disease) show marked reductions in cancer incidence and cancer mortality associated with regular aspirin use (greater than three years) in both the short and long-term [17], [18], [19], [20].
similarly, long-term follow-up from the women's health study, a randomised placebo-controlled trial designed to assess the effects of aspirin (100 mg on alternate days) in the primary prevention of cardiovascular disease and cancer, showed that allocation to aspirin reduced the incidence of colorectal cancer with ten years of follow-up (hazard ratio (hr) 0.80, ci 0.67–0.97) [21].
a recent meta-analysis of studies examining aspirin use after a cancer diagnosis has shown a significant reduction in cancer-specific mortality in colon cancer, but not in breast and prostate cancer, however significant heterogeneity between studies was identified [22].
furthermore, the first randomised trial specifically designed to demonstrate that aspirin can prevent the development of cancer has shown that 600 mg of aspirin daily for up to four years prevents colorectal and other cancers associated with lynch syndrome (a hereditary condition which predisposes to cancer development) hr 0.45, ci 0.26–0.79 [23].
the potential benefits of aspirin have to be weighed against the risk of adverse effects.
a number of systematic reviews and meta-analyses have examined the potential risks of adverse events [24], [25].
a recent review estimates that, depending on age and sex, regular aspirin use over a 15-year period would lead to an absolute increase in major bleeding events of between 0.16% and 0.81%.
the authors conclude that prophylactic aspirin use for a minimum of five years at a dose of 75 mg–325 mg daily has a favourable benefit-harm profile [26].
for individuals treated for cancer, with a high risk of recurrent disease, the balance could be even more favourable.
2 methods 2.1 aims the add-aspirin trial aims to assess whether regular aspirin use after standard potentially curative primary therapy can prevent recurrence and prolong survival in individuals with four common early stage solid tumours.
avoiding recurrent disease, subsequent treatment and the associated morbidity and mortality in these individuals is an important goal.
multicentre and international recruitment will allow assessment of the intervention in a range of settings, with the aim of demonstrating that implementation is both feasible and cost-effective across varying health care systems and in both the developing and developed world.
a secondary aim is to assess the potential overall health benefits of aspirin for these individuals including cardiovascular outcomes.
2.2 overview of design the add-aspirin trial investigates the use of both 100 mg daily and 300 mg daily aspirin compared with matched placebo (double-blind) in each of four different tumour types, utilising an overarching protocol.
further details of the rationale for this design are provided in the discussion section of this article.
fig.
1 shows a summary schema for the trial.
2.3 participants participants entering the add-aspirin trial have undergone potentially curative treatment (surgery or other radical treatment) for breast, colorectal, gastro-oesophageal or prostate cancer with standard neoadjuvant and/or adjuvant therapy if indicated, and may also have participated in any pre-approved trials and satisfy the eligibility criteria, summarised in fig.
2.
2.4 registration the add-aspirin trial is open to centres in every cancer research network (crn) throughout the four devolved nations of the united kingdom (uk) and will also recruit participants in india (other countries may join subsequently).
eligible participants who have provided consent and meet the timing of entry criteria are registered online (through the trial website, www.addaspirintrial.org).
the timing of entry window has been designed so that aspirin can be started at the earliest opportunity to maximise the potential benefits, whilst starting at a time when it is considered safe to do so and unlikely to compromise the curative intent of standard primary treatment.
figures describing the timing of entry criteria for each cohort are available in appendix b.
2.5 run-in period the add-aspirin trial incorporates a feasibility phase lasting approximately 2 1/2 years during which recruitment feasibility, treatment adherence and safety will be assessed.
during the feasibility phase of the study, all participants are required to complete an active run-in period after registration but prior to randomisation where they take 100 mg aspirin daily (one tablet per day) in an open-label manner for a period of approximately eight weeks.
2.6 end of run-in period assessment at the end of the run-in period, the participant's tolerance of aspirin and adherence to daily treatment will be assessed.
this approach allows those individuals who are unlikely to be able to tolerate aspirin, as well as those who are unlikely to be able to adhere to the protocol treatment schedule, to be identified.
adherence will be assessed using a combination of a participant diary card, used blister packs and patient reported adherence.
participants will be suitable for randomisation if they have taken at least 80% of their run-in treatment and have not experienced any aspirin-related severe toxicity (defined as ≥ grade 3 ctcae v4), nor any grade of gastrointestinal bleeding, active gastrointestinal ulceration, new or worsening tinnitus, macular degeneration, intracranial bleeding or hypersensitivity to aspirin.
if the investigator feels that the reason for inadequate adherence is temporary (for example, due to toxicity resulting from concomitant adjuvant treatment which has subsequently finished or a non-recurrent unrelated event), the run-in period may be extended by four or eight weeks to reassess adherence and toxicity subject to agreement from the central trial team.
those participants identified as suitable for further study participation, and who remain eligible and are willing to continue in the trial then re-confirm their consent to participate before being randomised.
2.7 randomisation following assessment at the end of the run-in period, eligible participants in the uk are randomised by phone and, in india, via the trial website.
participants undergo a double-blind randomisation.
randomisation is performed separately within each tumour-specific cohort and uses minimization algorithms based on key prognostic factors (dependent on tumour site), incorporating a random element.
within each tumour-specific cohort, participants who are below 75 years old are allocated in a 1:1:1 ratio to either 100 mg aspirin, 300 mg aspirin or a matched placebo.
participants who are 75 years old or over, are only allocated to either 100 mg aspirin or matched placebo as toxicity is thought to increase with age but the allocation ratio of 2:1 remains so that they have the same chance of receiving active treatment as the other participants.
the target randomisation figure is 9920 participants in the united kingdom (uk) and india combined.
assuming that approximately 10% of participants will not be randomised following the run-in (for reasons relating either to toxicity or adherence), it is expected that 11,000 participants will be registered to begin the run-in period.
2.8 follow-up patients are followed up at three-monthly intervals initially and then six-monthly.
adherence to treatment is verbally assessed at every follow-up visit.
in the uk, trial treatment, and active follow-up, continues for at least five years after randomisation.
long-term passive follow-up data will be obtained from routinely-collected healthcare databases for at least ten further years.
indian participants will be actively followed-up for at least ten years after randomisation.
for participants that are registered but do not go on to be randomised, active participation in the trial will end at that time.
however, passive follow-up will continue via routinely-collected healthcare datasets where consent for this has been obtained.
the trial assessment schedule for each cohort is aligned with standard practice where possible to ensure they can be implemented easily.
this is balanced with the need to ensure appropriate monitoring of patients on trial treatment and assessment of outcome measures.
the trial follow-up schedules are available in appendix c. 2.9 toxicity management participants that experience any aspirin-related severe toxicity (defined as ≥ grade 3 common terminology criteria for adverse events (ctcae v4)) or any grade of gastrointestinal bleeding, active gastrointestinal ulceration, tinnitus, macular degeneration, intracranial bleeding or hypersensitivity to aspirin are required to permanently discontinue aspirin immediately.
for those who are asymptomatic, prophylactic measures to reduce the risk of gastrointestinal toxicity from aspirin (such as proton pump inhibitor (ppi) prophylaxis and helicobacter pylori eradication) are not routinely recommended in participants at low risk of gastrointestinal complications and so are not mandated in the add-aspirin trial protocol.
however, ppi use for the duration of aspirin treatment is recommended for patients who have undergone oesophagectomy or partial gastrectomy and should also be considered for older patients (≥ 75 years), or any other participant who might be at increased risk of toxicity.
intracranial bleeding is a rare toxicity of aspirin, and hypertension can increase the risk.
those with poorly controlled hypertension have trial treatment withheld until their blood pressure is controlled.
further guidelines are available in the trial protocol.
investigators are advised to manage toxicities under the assumption that the participant is receiving the highest possible dose of the active product (300 mg aspirin), without the need for unblinding, however where knowledge of treatment allocation would alter clinical management, unblinding is possible.
unblinding can be performed via an access-controlled system available through the trial website (www.addaspirintrial.org).
2.10 sub-studies the size and diversity of the add-aspirin cohort provides opportunity to address other secondary research questions and evaluate novel methodology.
aspirin has been proposed to have a number of health benefits beyond cancer, particularly in older people.
to investigate the overall health benefits of aspirin, functional capacity is assessed using the vulnerable elders survey (ves-13) [27].
this is performed for participants that are 65 years old or over at trial registration, and five years after randomisation and can be administered in person or over the telephone.
the hypothesis that aspirin protects against cognitive decline is assessed using a short version of the montreal cognitive assessment (the moca-blind).
the moca-blind takes approximately 7 to 10 min to complete and is administered in all add-aspirin trial participants at registration, then again at one and five years after randomisation.
no training is required to administer the questionnaire, which can be conducted in person, or over the telephone.
a methodological sub-study will compare the quality and completeness of routinely-collected healthcare data with data collected within the trial, with the aim of assessing the suitability of passive follow-up data collection for investigating long-term primary and secondary outcome measures within the trial.
this will be an early validation that will determine ongoing use of routinely collected data in the trial.
a sub-study is planned to investigate methods of measuring adherence, including the collection of urine samples to measure thromboxane b2 (a direct measure of the effects of aspirin).
methodological sub-studies to improve site initiation and recruitment will also be undertaken.
2.11 translational objectives the add-aspirin trial incorporates a sample repository where a baseline blood sample and tumour sample are stored for future translational projects.
the sample repository is jointly hosted by two institutions in the uk, tayside tissue bank and the wales cancer bank.
in india, a baseline blood sample and tumour sample from selected sites will be stored at the tata memorial centre biobank.
a number of studies are expected to be initiated whilst the trial is ongoing (subject to funding), including studies to identify groups that will benefit most from aspirin use (for example, investigation of the role of tumour pik3ca mutation status), and to investigate the mechanisms underlying the anti-cancer effects of aspirin, particularly effects on platelet function and the pro-thrombotic tumour microenvironment.
3 results 3.1 outcomes tumour site-specific primary analyses will take place 5–6 years after recruitment of the last participant for that cohort, with the exact timing based on the observed numbers of events.
primary and secondary outcome measures are available in table 1. overall survival is a secondary outcome measure in all cohorts except the gastro-oesophageal cohort, where it is the primary outcome.
overall survival will also be assessed as a co-primary outcome measure in all participants after 15 years.
the longer follow-up and large sample size associated with this analysis will enable any long-term benefits of aspirin to be realised, including those unrelated to the primary cancer, for example the potential for prevention of deaths related to vascular events and second malignancies.
consideration of rates of serious toxicity (and particularly serious haemorrhage), as well as other secondary health outcomes, alongside the efficacy results will be particularly important in these analyses in order to provide an holistic assessment of the potential risks and benefits associated with different doses.
3.2 statistical considerations primary analyses will compare outcomes for participants allocated to aspirin (100 mg and 300 mg arms combined) and participants allocated to placebo, regardless of the treatment received (i.e.
intention-to-treat).
the primary analyses will include both those participants < 75 years who underwent the full randomisation and those ≥ 75 years who underwent randomisation between 100 mg aspirin or placebo only, but the dose effects of aspirin will be investigated only on those randomised between the two doses.
if an overall effect of aspirin vs. placebo is observed in the primary treatment comparison for one or more cohorts, a further analysis will be performed to investigate differences in efficacy according to aspirin dose.
this analysis will be performed only in the cohorts that show a positive result for aspirin vs. placebo and will be stratified by cohort.
by making these analyses conditional on a benefit of aspirin being observed in the primary analysis, the likelihood of a false-positive result is reduced.
the rationale for combining the data across cohorts is to maximise power, as we anticipate that any difference between doses of aspirin will be smaller than the difference between aspirin and placebo.
the trial has also established collaborative links with research groups running other aspirin cancer trials internationally with a view to future meta-analyses.
3.3 sample size breast cohort based on data from recent trials, we expect that five-year invasive disease-free survival (idfs) in the control group will be approximately 80% [29], [30], [31], [32].
717 idfs events will be required to achieve 90% power to detect a 4% (hr = 0.78) improvement in this rate.
assuming that the cohort takes 3 1/2 years to recruit, with analysis six years later, we anticipate that 3100 participants will be required to observe this number of events.
3.4 sample size colorectal cohort based on data from recent trials, we expect that five-year disease-free survival (dfs) in this cohort will be approximately 70% [33], [34].
899 dfs events will be required to achieve 90% power to detect a 5% (hr = 0.80) improvement in this rate.
assuming that the cohort takes 3 1/2 years to recruit, with analysis six years later, we anticipate that 2600 participants will be required to observe this number of events.
3.5 sample size gastro-oesophageal cohort based on data from recent trials, we expect that five-year overall survival in this cohort will be approximately 45% [35], [36], [37], [38], [39].
1120 deaths will be required to achieve 80% power to detect a 6% (hr = 0.84) improvement in this rate.
assuming that the cohort takes six years to recruit, with analysis five years later, we anticipate that 2100 participants will be required to observe this number of events.
3.6 sample size prostate cohort the radical prostatectomy and radical radiotherapy groups are powered to assess effects separately.
in the radical prostatectomy group, we anticipate that biochemical recurrence-free survival (brfs) at five years will be approximately 75% [40].
for the radical radiotherapy group, five year brfs is estimated to be approximately 65% [41].
to achieve 90% power to detect an 8% improvement in these rates, 673 brfs events will be required.
assuming that the cohort takes five years to recruit, with analysis five years later, we anticipate that 2120 participants will be required to observe this number of events.
sample size calculations for all cohorts are based on a two-sided 5% significance level and account for a degree of loss to follow-up and slower recruitment in the early stages of the trial.
target registrations have been inflated to allow a 10% dropout after the run-in period.
3.7 ethical considerations the trial will be conducted in compliance with the approved protocol, the declaration of helsinki 2008, the principles of good clinical practice (gcp), commission directive 2005/28/ec with the implementation in national legislation in the uk by statutory instrument 2004/1031 and subsequent amendments, the uk data protection act (dpa number: z5886415), and the national health service (nhs) research governance framework for health and social care (rgf).
international centres will comply with the principles of gcp as laid down by the ich topic e6 (note for guidance on gcp) and applicable national regulations.
the add-aspirin trial is registered with the international standard randomised controlled trial number isrctn74358648, and has also been submitted for registration with the clinical trials registry of india (ref/2016/06/011465).
the add-aspirin trial was approved by the south central – oxford c research ethics committee and is part of the uk national cancer research network (ncrn) portfolio.
in india, the trial has been approved by the directorate of the national cancer grid (ncg), and is part of the ncg trials portfolio.
university college london (ucl) and the tata memorial centre (tmc) are co-sponsors of the trial and have delegated responsibility for the overall management of the add-aspirin trial to the mrc ctu at ucl and tata memorial centre ctu for india.
4 discussion the clinical trials authorisation for the add-aspirin trial was granted by the medicines and healthcare products regulatory agency (mhra) on 25th november 2014, and ethics approval was given on 4th june 2014. the first participant was recruited on 8th october 2015. at the time of writing on 1st may 2016, the add-aspirin trial is recruiting across 120 centres in the uk, and is recruiting ahead of its overall projected targets, with the breast cohort the fastest recruiter.
the last of the four cohorts is now expected to complete recruitment in 2021. current recruitment figures are available at www.addaspirintrial.org.
4.1 challenges and methodological solutions there are a number of practical and operational challenges presented by a large adjuvant trial of a generic and repurposed intervention.
these include the need for cost efficiencies due to a lack of industry financial support for a trial of a generic pharmaceutical; ensuring sufficient long-term adherence in a largely asymptomatic population; and the potential for control arm contamination due to over the counter (otc) availability of aspirin.
these have been addressed using a number of contemporary methodological approaches.
4.2 overarching protocol a platform trial design was chosen because there is evidence that aspirin is potentially effective in multiple tumours.
investigating the use of both 100 mg daily and 300 mg daily aspirin across cohorts addresses uncertainty surrounding the optimal aspirin dose required to achieve anti-cancer effects, potentially saving many years of research time.
keeping all four cohorts within a single protocol ensures that the management of each cohort is as comparable as possible (with the exception of some site specific procedures).
this allows a combined analysis of overall survival as a co-primary outcome measure and cross cohort secondary analyses of toxicity, cardiovascular and other health benefits, thus increasing the overall potential impact of the trial.
in addition, this design provides the capacity to add further tumour sites and also provides a potential platform for evaluation of other repurposed agents.
an overarching protocol provides economies of scale both centrally and site level, including site set-up, regulatory approval, central staffing, coordination, oversight and data management.
the resulting cost efficiencies improve the financial viability of the trial given the lack of industry support, and provide value for money for our charitable and governmental funders.
4.3 antecedent aspirin use a proportion of individuals who are otherwise eligible for the trial will already be taking aspirin regularly.
it is conceivable that pre-existing aspirin use could alter tumour biology [42], and that those already taking aspirin might be randomised to placebo which would be unethical.
consequently a decision was made to exclude current or previous regular aspirin users.
4.4 over the counter aspirin unlike most other cancer trials, the intervention in the add-aspirin can be purchased without a prescription.
there is a risk that some potential participants might opt to not enter the trial and purchase aspirin independently.
otc availability of aspirin also leads to the potential for control arm contamination and an increased risk of toxicity if they are randomised to 300 mg aspirin.
to combat otc aspirin use, site staff are trained to re-enforce the key message that as yet, there is no clear evidence from a randomised trial that adjuvant aspirin use improves survival, and equipoise is emphasised in all information provided to potential participants.
for those already registered, site staff are trained to regularly ask about and discourage otc aspirin use.
randomisation to two doses of aspirin or placebo also leads to a 2:1 chance of receiving a potentially active agent.
4.5 timing of entry considerations the timing of trial registration has been aligned across all four cohorts to make the treatment of each as similar as possible, however a number of adjustments have been necessary to account for the variety of treatment modalities and pathways, and differences in patient characteristics between cohorts.
the timing of entry around adjuvant chemotherapy requires particular consideration.
the risk of developing dyspepsia during adjuvant chemotherapy varies according to the regimen used, the need for dexamethasone as a supportive therapy, and the incidence of risk factors in that group.
dyspepsia is a common occurrence during adjuvant chemotherapy for breast cancer and as such, patients can only register once chemotherapy is complete.
in the colorectal and gastro-oesophageal cohorts dyspepsia developing as a consequence of adjuvant chemotherapy is less common, and registration is permitted when six weeks of adjuvant chemotherapy has been administered (without developing dyspepsia and subject to acceptable platelet counts).
4.6 run-in period the run-in period was implemented after funders' concern about the risk of poor adherence.
adherence will be assessed during the run-in period using three different methods to allow a more accurate assessment.
these include a participant diary card, return of used blister packs and participant interview at an end of run-in assessment.
the run-in period provides an early opportunity to assess feasibility, in terms of early toxicity, recruitment and patient acceptability, and provides a population for the randomised phase who are more likely to tolerate and adhere to the trial treatment for the duration of the trial [43].
this strategy has also been used successfully in other aspirin trials [44], [45].
we do not believe that eight weeks of aspirin will reduce the effect between the aspirin and placebo comparison in the trial as data have consistently shown that long-term treatment (a minimum of 2 years [1], and up to 5–10 years [2], [3]) with aspirin is required for the anti-cancer effects of aspirin to become identifiable [1], [2], [3].
the use of the run-in period is being monitored carefully and will be reviewed on completion of an initial feasibility phase.
other methods of encouraging adherence include the use of blister packs labelled with days of the week, provision of diary cards, participant newsletters and promotion of the trial website which includes updates and reaction to stories related to aspirin in the news media.
4.7 drug supply aspirin is a generic drug, bayer ag donated all doses of the blinded active intervention and matched placebo, but not the packaging, labelling, blinding or distribution, which therefore represented a major operational and funding challenge.
these challenges have been met by outsourcing some of these processes and development of an in-house drug supply management system to track stock levels at sites and automatically trigger re-orders based on projected demand.
the system also includes an unblinding capability.
4.8 co-enrolment since aspirin is intended to be given following or alongside standard primary therapy, rather than replacing any element of current treatment, it will be appropriate to include participants who have already taken part in trials of primary treatments wherever possible.
this will allow assessment of the efficacy of aspirin in participants who have received both current and potentially future standard of care treatments.
including participants from other treatment trials will help to ensure the future relevance of both trials, is important for recruitment feasibility, and maximises the opportunities for patients to participate in trials.
we have found that the acceptability of co-enrolment to researchers varies by tumour group.
this may be due to variation in the amount of trial activity or even differences in patient group demographics.
our approach has been to consider co-enrolment on a trial-by-trial basis, discussing this with the relevant trial teams, with a careful assessment of any conflicts in eligibility criteria, scheduling and potential impact on safety and the results of either trial.
where concerns exist, or reassurance is required, statistical modelling is conducted to assess the potential impact on trial results (there is often limited overlap leading to negligible impact).
co-enrolment has been agreed with 16 trials to-date and is planned with other trials currently in development.
4.9 recruitment in india since aspirin is easily available worldwide, demonstrating its implementation in different resource settings will increase the global impact of the results.
recruitment in india is also important to ensure adequate recruitment in the gastro-oesophageal cohort and also allows the development of new international collaborations.
academic multi-centre trials are rare in india and the set-up of add-aspirin has helped with development of a research infrastructure for this and future trials.
recent changes in clinical regulations in india have delayed opening and the trial is anticipated to open in india later in 2016.
4.10 conclusions aspirin is a low-cost, generic drug that is easily available worldwide.
consequently, if aspirin is shown to be beneficial as an adjuvant treatment, even with a modest effect, it would change practice globally.
compared with many new agents or complex regimens, the intervention could be implemented quickly and on a broad scale, including in lower resource settings, with the potential to have a huge impact on the global cancer burden.
funding the add-aspirin trial is jointly funded by cancer research uk (cruk) (grant number c471/a15015) and the national institute health research (nihr) health technology assessment programme (hta) (project number 12/01/38).
bayer pharmaceuticals ag has agreed to provide the investigational medicinal products (imps).
in india, the sir dorabji tata trust provides funding, and cipla ltd. is providing supplies of aspirin 100 mg for the run-in period.
the add-aspirin translational sample collection is funded by cruk (c471/a19252).
the trial is coordinated and supported by the medical research council clinical trials unit at university college london (mrc ctu at ucl).
disclosures ruth e. langley has received financial support through grants from cancer research uk and the national institute for health research (nihr) health technology assessment (hta) as chief investigator of the add-aspirin trial, has received compensation from bayer and aspirin foundation for service on scientific advisory boards, and has received a supply of aspirin and placebo from bayer pharmaceuticals ag for the add-aspirin trial.
richard wilson has received a supply of aspirin and placebo from bayer pharmaceuticals ag for the focus4-b trial in metastatic colorectal cancer and for which he is the co-chief investigator.
@highlight
background there is a considerable body of pre-clinical, epidemiological and randomised data to support the hypothesis that aspirin has the potential to be an effective adjuvant cancer therapy.
methods add-aspirin is a phase iii, multi-centre, double-blind, placebo-controlled randomised trial with four parallel cohorts.
patients who have undergone potentially curative treatment for breast (n = 3100), colorectal (n = 2600), gastro-oesophageal (n = 2100) or prostate cancer (n = 2120) are registered into four tumour specific cohorts.
all cohorts recruit in the united kingdom, with the breast and gastro-oesophageal cohort also recruiting in india.
eligible participants first undertake an active run-in period where 100 mg aspirin is taken daily for approximately eight weeks.
participants who are able to adhere and tolerate aspirin then undergo a double-blind randomisation and are allocated in a 1:1:1 ratio to either 100 mg aspirin, 300 mg aspirin or a matched placebo to be taken daily for at least five years.
those participants ≥ 75 years old are only randomised to 100 mg aspirin or placebo due to increased toxicity risk.
results the primary outcome measures are invasive disease-free survival for the breast cohort, disease-free survival for the colorectal cohort, overall survival for the gastro-oesophageal cohort, and biochemical recurrence-free survival for the prostate cohort, with a co-primary outcome of overall survival across all cohorts.
secondary outcomes include adherence, toxicity including serious haemorrhage, cardiovascular events and some cohort specific measures.
conclusions the add-aspirin trial investigates whether regular aspirin use after standard therapy prevents recurrence and prolongs survival in participants with four non-metastatic common solid tumours.
