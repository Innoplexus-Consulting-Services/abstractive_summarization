introduction hypertension is one of the common problems of pregnancy and could lead to maternal and perinatal morbi-mortality.1 where present, it may result from inherent risk factors in the woman in the index pregnancy or as sequelae from previous pregnancies.
hypertensive disease in pregnancy (hdp) affects approximately 7%–10% of pregnancies.2 in nigeria estimates suggest that 5%–10% of pregnancies are complicated by hdp3 and could be higher.4 in a ghana series, 30% of maternal deaths were due to hdp; all related to eclampsia.5 pregnancy has been called a “stress test for life” in women6 with those failing the test at increased risk of long-term cardiovascular complications.7 consequently, pregnancy and child birth present an opportunity for preventive medicine when those who fail the cardiovascular stress test are identified and long-term preventive action instituted.
antenatal care (anc) clinics in africa are largely run without cardiologists.
postnatal clinics (pnc) on the other hand have multidisciplinary personnel including public health physicians.
since most patients with hdp develop cardiovascular disease (cvd) later in life,8 we felt that the cardiovascular profile of women in the 6 weeks pnc would give an idea of indicators during anc that point to later cvd, especially hypertension.
any such indicators should be sought at anc registration of subsequent pregnancies and modulated for reduced maternal and child morbid-mortality.
attention to prevention is said to be a sign of civilization9 and should be encouraged as in this study.
methods the study was a cross-sectional, descriptive study carried out on all consenting mothers on appointment at the 6 weeks postnatal outpatient clinic of jos university teaching hospital between april 15 and september 13, 2013. it was approved by the hospital research ethics committee and all procedures followed were in accordance with the ethical standards of the hospital ethics committee and the helsinki declaration of 1975 as revised in 2000. informed consent was obtained from all subjects included in the study.
relevant data were obtained through an interviewer-administered semi-structured questionnaire and from the anc folder of the index pregnancy and childbirth.
information sought included age, religion, marital status, educational attainment, and parity.
this was followed by anthropometric data: weight and height for determination of the body mass index (bmi), waist circumference (wc), hip circumference (hc), abdominal height (ah), waist-to-hip ratio (w/h), and waist-to-height ratio (w/ht).
the minimum sample size was determined using the formula n = z2 pq/d2 where z = standard deviation score at 95% (1.96), p = incidence of chronic hypertension from an obstetric predictor from a previous study (14.8%),10 q = complimentary probability, (1 − p) = 1–0.148 (0.852), d = error margin (5%); which came to 135 subjects.
weight was measured in kilograms to the nearest 0.5 kg with a standing beam scale, whereas height was measured to the nearest 0.1 m using an attached stadiometer.
wc was measured midway between the lower ribs and iliac crest with a flexible tape in expiration, and the hc measured at the level of the trochanters.
all these were in centimeters.
the ah was measured with the abdominometer conceptualized by bno which has been piloted and found to be a valid anthropometric measure.11 blood pressure was measured by standard sphygmomanometry and blood pressure ≥140/90 mmhg defined hypertension.
microsoft office excel 2007 was used for data entry and cleaning while spss version 20, manufactured by ibm, new york, usa statistical software was used for the analysis.
logistic regression was used to outline the likely positive predictors of hypertension with a p ≤ 0.05 defining statistical significance.
results over the study period, 136 women attended the pnc supervised by haa.
their ages ranged from 18 to 41 years with a mean (standard deviation [sd]) of 29.73 (5.46) years.
one hundred and ten were christians, and 26 were muslims.
most of them (135) were married; with only 1 being single.
the educational attainment was 10 for primary, 47 for secondary, and 79 for tertiary.
they were engaged in various occupations, the most common being homemakers and business women, 25.7% and 22.8%, respectively.
parity ranged from 1 to 8 with a mean (sd) of 2.5 (1.5).
to be able to determine what anthropometric and obstetric factors would predict development of hypertension postpartum, the study population was subgrouped into 3 for comparison as follows: a – normal blood pressure during anc registration and remaining normotensive at 6 weeks pnc, b – normotensive at anc registration and hypertensive at 6 weeks pnc, and c – hypertensive at anc registration.
the groups had 116, 8 and 12 subjects respectively.
table 1 shows summary data and comparison between the three groups.
table 1 comparison of anthropometric data between study groups using one-way anova, the between-group difference for the different variables turned out as shown in table 1. variables not shown in the table but relevant for the study showed between-group difference as follows: age, not significant (p = 0.178), velocity of weight gain, not significant (p = 0.569), age at first pregnancy, not significant (p = 0.355), birth weight of baby, significant (p = 0.02).
for categorical variables, between-group differences turned up as follows: history of developing hypertension in previous pregnancy, significant (p = 0.000), mode of delivery, significant (p = 0.05).
the continuous variables which showed significant between-group differences were subjected to post hoc analysis and the difference for parity was with subgroups a and b (p = 0.038); for weight, it was with subgroups a and c (p = 0.003); for height, it was with subgroups a and b (p = 0.014); for wc, it was with subgroups a and b (p = 0.001); for hc, it was with subgroups a and c (p = 0.006); for ah, it was with subgroups a and c (p = 0.02).
discussion obstetric encounters present an opportunity for preventive cardiology, which most times are not taken to the advantage of the woman; largely due to the nonexistence of obstetric-cardiac clinics.
as stated by van der merwe et al.,12 waiting times for response from the cardiologist to whom a pregnant woman with suspected cardiac morbidity encumbers anc and result in poor outcomes.
driven by the mantra that “attention to prevention is a sign of civilization,” this study used the opportunity presented by the 6 weeks pnc to determine what could be described as candidate predictors of hypertension during anc.
the study found that the traditional anthropometric indices that drive the development of hypertension also predict the development of hypertension to a statistically significant level.
these were weight, wc, hc, and w/h.
a new anthropometric index ah was also significant and given its simplicity has great utility in this area.
it has been shown to assess visceral fat that other measures may miss;13 with the ability to predict blood pressure better than other measures of central obesity.
in this population, its correlation using a portable simple appliance gives validity to this local adaptation.
if raised at anc registration, these should be addressed to avoid the development of hdp which carries variable morbi-mortality risks in pregnancy and child birth as well as on the long run.14 these indices define obesity, a chronic disease often neglected because of body size perception.
the excess fat, especially when in ectopic locations, such as the visceral organs secretes metabolically active substances which mediate auto, para, and endocrine actions leading to various components of the metabolic syndrome.15 iyoke et al.
studying an african obstetric population found that early pregnancy obesity was associated with wide-ranging poor feto-maternal outcomes that increase the risk of pregnancy and childbirth-related morbi-mortality.16 wc, hc, and bmi (though not significant here despite the tendency; p = 0.092) were among the anthropometric variables found to diagnose obesity in pregnant nigerians by okereke et al.17 whereas okereke et al.17 found w/h significant, it has been said not to be helpful in practical risk management as both could fall equally keeping the ratio the same.
consequently, w/ht was preferred as a better anthropometric tool to screen for and manage obesity.18 interestingly, that was also our finding.
ah, a new anthropometric index, which has been found a better indicator of obesity in our population11 also showed here to be a better discriminator of obesity risk than bmi.
mode of delivery especially by cesarean section (c/s) also as shown in this study predicted risk of hypertension at pnc.
such histories on anc registration should result in surveillance for hdp under skilled personnel.
c/s rates are higher in women with hdp as many would develop preeclampsia.19 infact singh et al.
in sokoto nigeria1 showed that induction of labor and c/s rates were 5 times higher in women with hdp.
c/s is also one of the morbidities of obese women.20 preterm delivered women are more likely to report hdp and to develop hypertension in later years.
that history of hypertension in a previous pregnancy was a significant predictor and did not come as surprise.
although preeclampsia/eclampsia would usually resolve after the delivery, hypertension could persist after delivery21 and usually antedate high rates of cardiometabolic disease in subsequent years.22 the mechanism linking preeclampsia with future cvd vary, including preexisting risk factors and endothelial dysfunction which is a regular feature of such pregnancies.23 therefore, including pregnancy history in the assessment of cvd risk in women is a pragmatic step in cvd control.24 in the same vein, history of big babies in previous pregnancies significantly accorded with the presence of hypertension at the pnc visit.
prepregnancy bmi and by extension indices of obesity influence birth weight.25 with these women manifesting anthropometric indices of obesity on anc registration and showing propensity for becoming hypertensive, it is not surprising that their chances of having macrosomic babies with interventional delivery are high.
a zambian study has shown that mothers of macrosomic babies are more likely than their counterparts with normal weight babies to develop hdp, be obese, and have greater c/s and interventional delivery rates.26 conclusion since most women would undergo the cardiovascular stress test of pregnancy, efforts should be made to determine what would predispose them to hdp and result in poor feto-maternal outcomes.
health education and appropriate nutrition to avoid obesity, and weight management if already existing are therefore crucial.
previous pregnancy history of hdp, macrosomic births and premature delivery (spontaneously and by c/s) should also alert the caregiver to adequate steps aimed at averting a recurrence.
these would alleviate the cardiac morbidity in postreproductive years as those patients could come down with persistent hypertension, cardiac failure, stroke, and renal failure.27 financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
background: hypertensive disease in pregnancy (hdp) accounts for high mother and child morbi-mortality and predict future cardiometabolic diseases.
this study aimed to identify obstetric predictors of hdp needing preventive action to reduce its consequences; when women present to antenatal clinic (anc).
materials and methods: cross-sectional descriptive this was an interviewer-administered semi-structured questionnaire-based study of the anthropometric, and blood pressure measurementsin attendees at the postnatal clinic (pnc) of jos university with anc records.
setting: six weeks postnatal clinic (pnc) of jos university teaching hospital (juth).
results: the following indices proved predictive of hdp and subsequent hypertension: weight (p = 0.009), hip circumference (p = 0.018), parity (p = 0.043), waist circumference (p = 0.00), abdominal height (p = 0.040), waist/height (p = 0.020), history of developing hypertension in previous pregnancy (p = 0.000), birth weight of baby (p = 0.02), and mode of delivery (p = 0.05).
conclusion: to initiate preventive action on anc registration in mitigating effects of or outrightly preventing hdp, careful check on anthropometry as well as history of hypertension or operative/preterm delivery in a previous pregnancy is necessary
