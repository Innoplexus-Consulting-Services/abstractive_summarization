introduction painful vertebral fractures are important health issues among patients with osteoporosis.
percutaneous vertebroplasty (pvp) is a minimally invasive interventional procedure in which bone cement is injected into a fractured vertebra to treat painful vertebral compression fractures (vcfs) during the last two decades.123 pvp has numerous advantages, including quickly relieving pain, improving a quality of life, few complications, and reliable safety.4 the procedure is mainly performed under the guidance of fluoroscopy via a bilateral or unilateral pedicular approach.
both bilateral or unilateral pvp achieve a similar clinical effect,256 but the unilateral pvp include less operation time/exposure, less tissue injury, and reduce cost.
however, there is complicated anatomical structure surrounding the vertebral pedicle.
the choice of the unilateral or bilateral approach is usually decided at the time of puncture on the basis of the judgment of the practitioners.
it rarely reported that how to determine the feasibility of the unilateral or bilateral approach and how to decide the puncture angle, the skin insertion site before the procedure.
in this study, the puncture angle, skin insertion site were measured, and the choice of unilateral or bilateral pedicular approach was decided based on the computed tomography (ct) image before the procedure.
we explored the difference in success rates of unilateral pvp whether using three-dimensional positioning of ct image to provide points for selection suitable puncture pvp.
materials and methods 108 patients (115 vertebral bodies) with painful osteoporotic vcfs were treated by pvp between june 2008 and january 2015 were included in this study.
there were 26 male patients and 82 female patients, and the patients’ ages ranged from 63 to 87 years.
fifty patients with 52 vertebrae were assigned to group a operated between june 2008 and june 2011.
58 patients with 63 vertebrae were assigned to group b operated between july 2011 and january 2015. in group a, routine c-arm fluoroscopic monitoring was done during each operation, and no preparations with a special measurement and puncture simulation were performed preoperatively.
in group b, preoperative ct measurements and puncture simulation were carried out before pvp.
in group a, the diseased vertebrae were distributed between t8 and l4, t6–l4 in group b. studies with the following criteria were included: (1) patients with vcf due to osteoporosis; (2) involving the lumbar and back and compression pain unresponsive to at least 8 weeks of conservative treatments; (3) pedicle intact without fracture; (4) no fracture fragment invaded the vertebral canal; (5) presence of a new fractured vertebra in magnetic resonance imaging (mri).
exclusion criteria: (1) neurological complications; (2) osteoporotic vertebral collapse of >90%; (3) fracture protruding into the vertebral canal or involving both vertebral pedicles; (4) general or local infections; (5) noncorrectable coagulation disorder; (6) serious mental illness or obvious cognitive disturbance.
preoperative measurement in group b, image measurements were performed at the midpoint layer of the perpendicular diameter through the base of the vertebral body.
the skin entry point and puncture angle were determined from the axial and sagittal image of preoperative ct at the diseased vertebra.
the target point of the needle was in the tip at the junction of the anterior and middle third of the vertebra.
all patients underwent the preoperative puncture simulation with modeling on the axial and sagittal ct image as follow [figures 1 and 2].
the tip of a needle was targeted in the anterior and middle third of the vertebral body for unilateral pvp.
unsuccessful cases caused by unilateral simultaneous puncture were treated with bilateral puncture to complete pvp [figure 3].
the tip of a needle was targeted in the anterior and middle third of the left or right half side of the vertebral body for bilateral pvp.
the puncture angle and skin insertion site were measured by radiation pacs/ris (carestream health (china) limited, beijing, china) apparatus.
figure 1 cross-sectional computed tomography scan of vertebra pedicle - a: the junction of the anterior and middle third of the vertebra.
line ab: connecting point a and the midpoint of the upper and lower edge of the pedicle.
b: junction of line ab and the skin.
line ao: posterior midline.
ob: distance beside the posterior midline of spine.
α: cross-sectional puncture angle of the vertebra figure 2 sagittal computed tomography of vertebra pedicle: o’: target point just as point a [figure 1]; line xy: horizontal line of the vertebra through the midpoint of the upper and lower edge of the pedicle (just as cross-sectional computed tomography of vertebra pedicle); line o’b’: connecting point ocle); line midpoint of the upper and lower edge of the pedicle.
b’: skin entry point.
line a’b’: the distance between b’ and line xy.
β: head or foot-sided tilt angle of the puncture figure 3 (a) the unilateral transpedicular simultaneous puncture.
(b) the bilateral transpedicular percutaneous vertebroplasty simultaneous puncture due to the narrower width of vertebral pedicle technique following the above method, the distance between the skin insertion site of the needle and the sagittal line of the spine were determined, and the puncture angle was measured by the preoperative ct in group b. group a received pvp without using preoperative ct measurements and puncture simulation.
in group a, the needle insertion point generally chosen to be 2–3 cm lateral to the middle line of the spinous process, and the final insertion site and puncture angle were decided based on a lateral fluoroscopy.
procedures were performed under c-arm fluoroscopy in both group.
with the patients in a prone position, the vertebral body was visualized fluoroscopically as having a superior and inferior endplate, and the spinous process was midline in a true anteroposterior projection.
the lateral margins are also visualized as somewhat concave margins.
medial to the lateral margins of the vertebral body are the ovoid pediculus.
the vertebral arch pedicle was displayed clearly.
on the anterioposterior fluoroscopic view of the c-arm, the skin insertion site was marked according to the measurement above.
all procedures were performed under local anesthesia using lignocaine (2%).
according to the angle of the puncture, the needle traversed within the line of the ovoid pediculus of the vertebral body.
it was crucial that the needle reach exactly to the tip with the junction of the anterior and middle third of the vertebra for unilateral pvp.
the bone-cement was injected with continuous fluoroscopic monitoring.
the cement injection should be stopped if the cement reached nearly the posterior margin of the vertebral body.
the symbol of the success of the procedure is that the puncture reaches the anterior and middle third of the vertebra and bone cement can diffuse across the mid line for unilateral pvp.
the success rate of puncture and the mean time of the operation were calculated.
complications, such as paraspinous hematoma, hemorrhage, and nerve injury, were evaluated.
the subjective pain evaluated using the visual analog scale (vas), which is divided into ten grades: 0 for no pain and 10 for a maximum of pain.
postoperative imaging studies were observed to analyze the bone-cement leakage and its distribution.
the followup was 3 months.
researchers who did the followup blinded to the type of initial procedure.
statistical analysis the statistical analysis was performed with spss 13.0 statistical software (spss inc., chicago, usa).
the average time for operation, the success rate of single puncture and complications were evaluated and compared between group a and group b. the preoperative and postoperative vas scores were compared using the pair t-test.
the value of p < 0.05 was considered significant.
all datas were shown as the mean ± standard deviation.
results preoperative puncture simulation in group b, the unilateral pvp was performed in 58 fractured vertebral bodies during simulation puncture.
in the other five fractured vertebral bodies bilateral transpedicular approach was used in group b [table 1].
table 1 measurement of the puncture angle and skin needle entry point clinical outcome in group a, technical success of unilateral pvp was 63.5% (33/52 vertebrae) [figure 4], and 92% (58/63 vertebrae) in group b [figure 5].
the overall mean procedure time in group a was 37.5 ± 5.5 min and 28.5 ± 5.5 min in group b. statistical analysis showed that the success rate of unilateral pvp in group b was significantly higher in group a, and the overall mean procedure time also significantly less than in group a (both p < 0.05).
unsuccessful cases caused by unilateral puncture in both groups were treated with bilateral puncture to complete pvp.
the average injected cement volume was 3.8 ± 1.2 ml/vertebra in group a, 3.6 ± 1.3 ml in group b. there was no statistically significant between the two groups.
the differences between preoperative and 3 months postoperative vass were statistically significance between the two groups (p < 0.05) [table 2].
figure 4 fluoroscopy x-ray dorsolumbar spine of a 73-year-old woman with vertebral compression fracture (t11) who underwent bilateral percutaneous vertebroplasty for t11 in group a.
(a) anteroposterior fluoroscopy view showing that the tip of needle was located nearly at the center of the vertebral body (b) lateral fluoroscopy view showing that the tip of the needle was located at the anterior third of the vertebral body (c) anteroposterior (d) lateral fluoroscopy views suggesting that bone cement diffused mainly in the left half of the vertbral body (e) anteroposterior (f) lateral fluroscopy view showing a similar percutaneous vertebroplasty procedure done on the right side of the vertebral body (g) anteroposterior view showing bone cement diffuse on both sides figure 5 a 68-year-old woman with vertebral compression fracture who underwent unilateral percutaneous vertebroplasty for l3 in vertebral body group b (a) preoperative mri t1w image showing low signal in l3 vertebral body (b) preoperative mri t1 stir image showing high signal, means l3 has a fresh vertebral compression fracture (arrow) (c and d) computed tomography transverse section images passed through the l3 right pedicle were selected to identify the ideal position of the needle tip.
the distance between the skin insertion site of the needle and the posterior midline was 5.2 cm.
the cross-sectional puncture angle of the vertebra was about 30°.
the skin insertion site of the needle (b’) was 1.3 cm above the point b. the head sided tilt angle of the puncture was about 10° (e) lateral fluoroscopy showing that the tip of the needle was located at the anterior third of the vertebral body.
(f) anteroposterior fluoroscopy views showing that the tip of needle was located at the centre of the vertebral body (g) anteroposterior fluoroscopy view suggested that bone-cement diffused cross the middle line table 2 clinical details of the patients in the two groups no serious complications related to the procedure were found in the two groups.
during the followed up, two patients suffered from a new compression nonadjacent fracture had been treated by pvp again in group a [figure 6].
figure 6 x-ray and mri of lumbosacral spine t2w sagittal image showing a new compression nonadjacent vertebral compression fracture at l3 occurred 2 months after percutaneous vertebroplasty and the patient underwent a second pvp discussion osteoporotic vcfs are important health issues among patients with osteoporosis, resulting in severe back pain, function decline, and potential risk of increased mortality.7 vertebroplasty and kyphoplasty are the most routinely used minimally invasive procedures to treat vcf during last two decades.8 clinical studies have reported no difference in the outcome of pain relief and quality of life improvement between pvp and penetrating keratoplasty (pkp).910 however, recently-developed radiofrequency kyphoplasty showed that pkp may cause trabecular destruction.11 pvp is both relatively simple and less traumatic procedure.
many techniques have been developed for simpler and safer procedures.121314 unilateral pedicular approach and bilateral pedicular approach are both used for pvp.1415 literature indicated that there were no statistically significant differences in clinical outcome between bilateral and unilateral pedicular approach in pvp.2 the filling volume of unilateral bone-cement injection can achieve the dynamic intensity and hardness of vertebral bodies and relieve clinical symptoms.5 as compared to bilateral pvp, unilateral pvp offers many advantages, such as reducing surgical material consumption, diminishing operation time, and reducing x-ray exposure to the patient and surgeon.1516 because of the anatomical distinctions among different vertebral body, unilateral or bilateral approach is variable.
the choice of the unilateral or bilateral approach is usually decided at the time of puncture on the basis of the judgment of the practitioners.
it rarely reported that how to determine the feasibility of the unilateral or bilateral approach and how to decide the puncture angle, the skin insertion site before the procedure.
in this study, a method of preoperative ct image measurement was used to determine the unilateral or bilateral approach before pvp procedure.
only those vertebral body that meet the above two conditions (the needle traversing throughly the pedicle and reaching the target site) can be implemented by unilateral pedicular approach.
preoperative ct puncture simulation is necessary for screening indications of unilateral pedicular approach pvp.
in group a, the needle insertion point generally chosen to be 2–3 cm lateral to the middle line of the spinous process, and the final insertion site was decided based on a lateral fluoroscopy.
the success rate of unilateral pedicular pvp was lower than group b. in group b, the unilateral pvp was performed in 58 fractured vertebral bodies during simulation puncture.
in actual operation, unilateral pvp was successfully performed and with a successful operative rate of 100% on above 58 fractured vertebral bodies.
we found that this method could increase the success rate of unilateral pedicular pvp.
in this study, no serious complications related to the procedure were found, indicating that the method can be applied to severe osteoporotic vertebral body compression fractures patients.
with unilateral pvp, the target site for puncture is the anterior and middle third of the vertebra as in the previous study.
for the procedure, the suitable puncture angle and skin insertion site is very important.
however, the puncture angle skin and the insertion site are not uniform on pvp using the unilateral pedicular approach.216 zindrick et al.17 indicated that there was difference in the vertebral body shape for different vertebral body or different people.
the surrounding anatomical structure is so complicated that the puncture can fail easily, and the failure may cause a serious consequence, such as retroperitoneal organ, lumbar artery, nerve, and spinal cord injuries.
the success rate of unilateral pvp will be improved if a larger puncture angle involved.
however, the vertebral pedicle as well as lumbar artery, nerve, and spinal cord are easily exposed to high risks of injuries.
therefore, the completion of unilateral pvp requires the accurate placement of the needle.
in this study, a method of preoperative ct image measurement was used to direct access for pvp.
we consider that targeting the tip of a needle in the vertebra is in the anterior and mid third of the vertebral body for unilateral pvp.
in general, bone-cement can diffuse cross the mid line if the puncture reaches the target.
therefore, based on this theory, we developed a simple puncture simulation method.
we measured the puncture angle and skin entry point by radiation pacs/ris apparatus of ct. in our series, we found that the puncture angle and skin entry point were different for the different vertebral segment, and the success rate of unilateral pvp is closely associated with the vertebral segment.
however, for pvp, the unilateral pedicular approach is not suitable for all vertebral bodies.
in this study, five patients were excluded from unilateral pedicular approach before procedure due to the smaller width of the vertebral pedicle.
with the preoperative ct puncture simulation, we found that it was dangerous to carry out unilateral pvp for narrow pedicle.
otherwise, this approach may increase the risk of crossing into the spinal canal, paraspinous hematoma, and hemorrhage from needle injury.1819 then based on the preoperative ct puncture simulation, the procedure was completed successfully by the bilateral pedicular approach in the five patients.
therefore, it is necessary to carefully analyze the ct image before determining the optimal approach for each vertebral segment.1520 literature indicated that the majority of the fractures in followup occurred at the adjacent vertebrae and within the first 3 months after procedure.21 during the followup, no people suffered from a new adjacent vertebral fracture.
this is further indicated that unilateral approach pvp is safe.
it is important to obtain a fairly uniform distribution of bone-cement inside the fracture vertebral body.
in the unilateral pvp, the location of cement is important mechanically although unilateral filling can control clinical pain.
once patients in whom the polymethylmethacrylate is unilateral filling or not entering into the fracture zone, a similar pvp procedure were done on the other side of the fractured vertebra.
conclusions the puncture angle and skin entry point were different between different patients and vertebral body.
these differences should be considered during pvp procedure.
preoperative ct puncture simulation is a method for screening unilateral pvp.
it also could increase the accuracy and decrease the complication rate of the unilateral pvp.
however, not all vertebral bodies are suitable for the unilateral pedicular approach.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
background: percutaneous vertebroplasty (pvp) is now widely performed to treat painful vertebral compression fractures.
previous researches have reported numerous advantages.
however, it rarely reported that how to determine the feasibility of the unilateral or bilateral approach and how to decide the puncture angle, the skin insertion site before the procedure.
the aim of this study was to discuss the feasibility of pvp using unilateral pedicular approach by the three-dimensional positioning of computed tomography (ct) image.
materials and methods: under fluoroscopic guidance, 108 patients with 115 diseased vertebral bodies underwent pvp.
the study was divided in two groups.
group a, fifty patients with 52 vertebrae received pvp without using preoperative ct measurements and puncture simulation.
group b, 58 patients with 63 vertebrae received pvp using preoperative ct measurements and puncture simulation.
the skin needle entry point and puncture angle of the transverse plane and sagittal plane were determined by the software of pacs on preoperative ct image.
the choice of unilateral or bilateral pedicular approach was decided based on the ct image before the procedure.
pvp was carried out according to the measurement result above.
the average time for a single vertebra operation, the success rate of single puncture and complications was evaluated and compared between group a and group b. results: in group a, technical success of unilateral pvp was 63.5% (33/52 vertebrae), and 92% (58/63 vertebrae) in group b. the average time of operation in groups a and b were (37.5 ± 5.5) and (28.5 ± 5.5) min, respectively.
there was a significant difference in the time of single-vertebra operation and the success rates of unilateral pvp between groups a and b. no serious complications developed during the followup period.
conclusions: the ct three-dimensional positioning measurement for pvp can increase the success rate of unilateral pvp.
