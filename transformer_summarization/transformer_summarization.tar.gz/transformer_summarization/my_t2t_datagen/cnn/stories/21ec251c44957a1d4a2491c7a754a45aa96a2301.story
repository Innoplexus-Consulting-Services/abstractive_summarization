introduction the human tim family members (tim-1, tim-3, tim-4) are commonly expressed as surface glycoproteins containing an igv domain, a mucin stalk, a transmembrane domain, and a cytoplasmic tail (1, 2).
the gene encoding tim-3 is known as havcr2, which denotes hepatitis a virus (hav) cellular receptor 2 (3).
tim-3 has important and complex roles in the regulation of immune responses.
tim-3 was originally identified as surface molecule on cd4 effector th1 cells (4, 5).
now, it is known that tim-3 is also expressed on dendritic cells, microglia, macrophages, mast cells; nk cells, activated and exhausted cd8 t cells (4, 6, 7).
the exhausted cd8t cells are generated as a consequence of prolonged immune responses to chronic infections and tumors (8).
these cells are characterized by a failure to proliferate and to exert their effector functions such as cytotoxicity and cytokine secretion in response to antigen stimulation (9).
stimulation of tim-3 by its ligand, galectin-9, results in th1 cell death, implicating a role for tim-3 in negatively regulating th1 responses.
blocking of tim-3 has been shown to increase ifn-γ secreting t cells, mediating the pathophysiology of th1-driven autoimmune diseases.
tim-3 expressed on macrophages and monocytes is implicated in phagocytosis of apoptotic cells and cross-presentation (10).
in tumors, tim-3 expression is induced on innate immune cells, leading to a suppression of innate responses to nucleic acids released from apoptotic tumor cells by interacting with hmgb1.
as discussed, tim-3 interacts with galectin-9 (gal 9) and causes exhaustion and apoptosis of antigen-specific th1 cells and ctls, which correlates with impaired antitumor immune response (11).
blocking of tim-3 interaction with its ligand would restore effector functions of exhausted cd8 t cells and its anti-tumor activity (12-14).
therefore, tim-3 blockade and treg depletion could have a synergistic effect on tumor growth inhibition (15).
tim-3 is also expressed on cancer stem cells in patients with acute myeloid leukemia (aml) and has a role in promoting myeloid-derived suppressor cells (mdsc).
furthermore, in aml cell lines (hl-60), tim-3 moderately activates the mammalian target of rapamycin (mtor, a master regulator of myeloid cell translational pathways).
this results in activation of the hypoxia-inducible factor 1 (hif-1) transcription complex, which upregulates glycolysis and expression/secretion of the pro-angiogenic vascular endothelial growth factor (vegf) (16).
in a study, anti-human tim-3 antibody blocked aml engraftment in a xenotransplant model (17).
the role of tim-3 in modulation of autoimmune diseases has been studied in experimental autoimmune encephalomyelitis (eae), as a mouse model of ms. low-level expression of tim-3 on eae th1 cells may explain their th1 resistance to inhibition induced by tim-3/ galectin-9 pathway (18).
now a day, antibodies are widely used as diagnostic and therapeutic tools in clinic.
the large size of monoclonal antibodies (mab) in some clinical situations is a drawback, which limits their penetration and distribution deep into tissues (19).
in addition, the fc portion of mabs is more likely to activate complement system or phagocytosis process in vivo rather than having solely a blocking or stimulating activity.
to overcome these limitations, fragments of antibodies have been generated.
among antibody fragments, nanobodies (nbs) have unique features, which make them appropriate tools for manipulating immune responses for therapeutic purposes (20, 21).
this unique type of antibody is found in sera of camels (dromedaries) and llamas.
these camelid antibodies lack light chains and are called heavy-chain antibodies (hcabs).
the variable domain of hcabs is named vhh, nanobody or single domain antibody, which is responsible only for antigen binding.
nbs are the smallest fully functional antigen-binding fragment of these antibodies.
it appears that nbs have very low immunogenicity for human because of a high degree of sequence similarity between vhh and human vh sequences (22, 23).
nbs are more efficient in immunotherapy, because they have small size, which enable them to access inaccessible positions in the body.
they also have high affinity and specificity for their cognate antigen.
based on the importance of blocking and/or stimulating of tim-3 signaling in different pathologic conditions, this study was aimed to design and produce a monoclonal nb with a high affinity against the tim-3 protein for further in vitro and in vivo studies.
materials and methods preparation of antigen for immunization the hek 293 cell line that expressed recombinant human tim-3 was prepared for immunization (in press).
a 6 months camelus dromedaries was intramuscularly immunized with 50 μg purified human tim-3 protein (sinobiological, inc) plus complete freund’s adjuvant (cfa, cmg company) followed by the adjuvant free lysates prepared from 5×107 human tim-3 expressing cells for 4 times every 2 weeks.
whole blood was collected before the first injection and 7 days after each injection, and the sera were isolated for measurement of the antibody titer.
library construction ten days after the last immunization, 400 ml blood was collected and peripheral blood mononuclear cells (pbmc) were separated using lymphoprep (greiner bio-one).
total rna was extracted from isolated pbmcs with the rnx plus reagent (cinnagen, iran) and cdna was synthetized with a revertaid first strand cdna synthesis kit (fermentas, germany) using oligodt primer.
nested pcr was done for vhh amplification using specific primers.
the leader-specific primer call001 (5’-gtc ctg gct gct ctt cta caa gg-3’) and ch2-specific primer call002 (5’-ggt acg tgc tgt tga act gtt cc-3’) were used for vh and vhh amplification.
pcr products were electrophoresed on a 1% agarose gel and the 600-700 bp fragments (vhh-ch2 without ch1 exon) were purified from the gel with accuprep gel purification kit (bioneer, korea).
purified bands were re-amplified using nested primers a6e (5’-gat gtg cag ctg cag gag tct ggr gga gg-3’) and primer 38 (5’-gga cta gtg cgg ccg ctg gag acg gtg acc tgg gt-3’) for framework 1 and framework 4 regions.
the phen4 phagemid vector and the amplified pcr product were digested with psti and noti restriction enzymes and then, ligated with t4 dna ligase enzyme.
recombinant vector was transformed into electro-competent escherichia coli tg1 cells.
colony pcr was done to confirm the successful cloning.
enrichment of the vhh library the vhh libraries were displayed on phages after their infection with vcsm13 helper phages.
this library was grown in 330 ml 2xty media containing 100 μg/ml ampicillin and 4% of glucose.
bacteria at mid-log phase (od=0.5 at 600 nm) were infected with 2×1012 cfu of vcsm13 helper phage.
infected bacteria were incubated for 30 min at 37 °c.
after a centrifugation, the resulted pellet was cultured in 2×ty supplied with 50 mg/ml kanamycin and incubated at 37 °c for 16 hr while shaking at 250 rpm.
the culture medium was centrifuged for 20 min at 9000 rpm at 4 °c and the supernatant was mixed with polyethylene glycol (peg)-nacl.
this was incubated for 60 min on ice.
after centrifugation for 15 min at 4000 rpm and 4 °c, the pellet was isolated and re-suspended in 1 ml of pbs.
enrichment of the specific phage was done with three rounds of in vitro selection on microtiter plates coated with 10 μg recombinant tim-3 protein.
after each selection round, binders were eluted with 100 mm triethylamine (ph 10) and immediately neutralized with 1m tris–hcl, ph 8. phage particles were finally used to infect exponentially growing e. coli tg1 bacteria.
polyclonal phage elisa, applying the extracted phages, was used for evaluation of the panning process after each round.
after three rounds of panning, individual colonies of third round were randomly picked for periplasmic extract elisa (pe-elisa) in order to detect positive clones.
in pe-elisa expression of soluble periplasmic vhhs was induced with 1 mm isopropyl-d-1-thiogalactopyranoside (iptg).
the periplasmic proteins were extracted using osmotic shock with tes buffer and extracted material containing recombinant vhh was tested for antigen recognition.
expression and characterization of vhh nanobody after pe-elisa, samples with the highest optical density (od) were selected for further experiments.
the vhh genes of the selected colonies were sub-cloned into the phen6c expression vector with bsteii and psti restriction sites.
this vector includes a c-terminal his-tag.
the recombinant phen6c was transformed into e. coli wk6 (pasteur institute, iran) and expressed nb was obtained.
briefly, the periplasmic crude extract proteins were prepared using osmotic shock and loaded on a his-select column (sigma-aldrich, germany).
after washing with pbs, the bound proteins were eluted with 500 mm imidazole.
sds-page and western blotting the purity and identity of the protein was evaluated on a15% gel with sds–page method.
the gel was stained with coomassie brilliant blue.
western blotting was done with anti-his tag antibody (abcam, uk).
for western blotting, the gel was run at a constant voltage of 100 v for 45 min using a mini protein tetra system (bio-rad, usa), in order to transfer the protein bands to the nitrocellulose membrane (cmg company).
the nitrocellulose membrane was then blocked with 5% skimmed milk in pbs-t for 16 hr at 4°c.
the membrane was washed and detection was done with 1/5000 dilution of hrp conjugated anti-his tag antibody (abcam, uk) and diaminobenzidine (dab) (cmg company) as substrate.
measurement of tim-3 nanobody affinity affinity of the purified nanobodies (nb94 and nb60) was determined using elisa method.
tim-3 antigen (havcr2 protein /sino biological inc.) was coated in a 96 well microplate wells (nunc, denmark) in different concentrations (5 and 10 μg/ml).
after washing and blocking, the nb was added at 0.001, 0.01, 0.1, 1, 10 nm concentrations.
hrp-conjugated anti-his antibody (abcam, uk) was added and the immune reactivity was assessed with tmb substrate.
the reaction was stopped with a stop solution and od was measured at 450 nm using a microplate reader (hyperion).
flowcytometric analysis the tim-3 expressing hl-60 cells (an aml cell line), induced with pma, and tim-3 expressing hek 293 cells, stably transfected, as well as tim-3 negative hek293 cells (as negative control) were used for flowcytometric analysis of anti-tim-3 nb immunoreactivity.
about 5×105 cells were washed three times and re-suspended in a total volume of 100 μl pbs.
one microgram of nb was added, and cells were incubated for 45 min on ice.
after washing with pbs, cells were incubated with 1 μg mouse anti-his-tag antibody-pe (biolegend, uk) for 1 hr on ice.
anti-tim-3-pe monoclonal antibody (mab) (biolegend, uk) was applied as positive control for another group of cells.
cells were washed with pbs and analyzed with cell quest pro software in a facs callibour (bd biosciences, usa) instrument.
cfse proliferation assay in the assay, hl-60 cells were grown in rpmi medium, induced with pma and labeled with 10 mm carboxyfluorescein-succinimidyl ester (cfse) (biolegend, uk) at 37 °c for 20 min in the dark and washed twice with pbs containing 10% fbs to remove excessive cfse.
cells were seeded at 2.5×105 cells/well in 24-well plates and incubated at 37 °c with 5% co2.
at least 24 hr before analysis, 2 μl (1 μm) galectin-9 (biolegend, uk) was added into each well.
one group was treated with our anti-tim-3 nanobody (10 µl) as the test group and a standard anti-tim-3 mab (10 µl) was added to another group as the positive control.
one group of the seeded cells was not treated with galectin-9 as the negative control.
at the appropriate point in time, cells were washed twice, re-suspended in pbs buffer, and analyzed immediately using a facs calibur flowcytometer (becton dickinson, usa).
statistical analysis paired-t-test and one way anova were applied to compare the results before and after interventions between two and more than two groups, respectively.
p<0.05 was considered as the statistical significance.
all the analyses were done using spss 20 (spss inc., chicago, il, usa).
results immunization and construction of nanobody library anti-human tim-3 antibody level was increased significantly in the serum of immunized camel (p=0.0001) 10 days after the last injection (table 1).
very low optical density in controls in compare with tests (p=0.0001) confirmed no non-specific binding (nsb) in the experiment.
then, lymphocytes were isolated from anti-coagulated blood of the immunized camel.
total rnas were purified and cdna was synthesized.
the variable domains of the heavy-chain antibodies were amplified with pcr and bands related to both classical antibody (900 bp) and heavy chain antibody (600-700 bp) were obtained (figure 1a).
table 1 camel anti-tim-3 antibody level after each round of immunization test control (non specific binding) pre-immunization 0.149±0.01 0.19±0.05 final immunization 1.7±0.2 0.141±0.04 figure 1 a. library construction.
analysis of the first pcr product with agarose gel electrophoresis (1%); the pcr product with different sizes 900, 700, and 600 bp, m shows: molecular weight marker (1 kb).
b. analysis of the second pcr product by gel electrophoresis (1%); the vhh fragment with 400 bp size is showed.
m, molecular weight marker (1 kb).
the a band shows 1000 bp.
the b band shows 700 bp.
the c band shows 400 bp in nested pcr, a 400 bp region between the framework 1 and framework 4 (vhh) was amplified (figure 1b).
the digested pcr fragments were ligated into phen4 phagemid vector and transformed into e. coli tg1.
the obtained library of transformant has 2.1×107 members.
colony pcr analysis of 25 randomly picked colonies from the library showed that the most of the colonies had a phagemid containing an inserted fragment of vhh gene (figure 2).
figure 2 colony pcr analysis of colonies from the library.
the most of the colonies had an inserted fragment of vhh gene (600 bp).
m, molecular weight marker (100 bp) we identified tim-3 nbs by bio-panning in three rounds to validate the quality of the library using phage display technology.
in elisa enrichment, we obtained a relatively enriched phage eluted from wells coated with tim-3 protein.
the third round of panning showed the highest immuno-reactivity in the polyclonal phage elisa (figure 3).
48 clones were screened from the third round of panning that bound to tim-3 recombinant protein using pe-elisa.
the nb49and nb60 clones showed the highest color intensity at 450 nm by elisa reader and selected for expression (figure 4).
figure 3 the panning process with phage elisa.
the absorbance and enrichment against tim-3 was increased and the highest enrichment was obtained in the third panning round.
the absorbance against skim milk (negative control) remained constant figure 4 periplasmic extract (pe)-elisa for selecting the most secretory anti-tim-3 vhh expressing colonies.
a selected nanobody clone showing the highest optical density at 450 nm in compare with negative control.
presented data are mean±sd of three identical repeats of the same experiment.
asterisks (*) shows statistical significance compared with control expression of soluble vhh nanobody for expression of the binder nbs, nb49 and nb60 were sub-cloned into a phen6c expression vector.
nb was expressed in fusion with n-terminal his-tag and purified by nta-affinity chromatography, with a 0.005 μg concentration.
nanobody characterization using sds-page analysis, a single 15 kda band representing for the presence of the purified nb (vhh) was observed on polyacrylamide gel.
no contamination or degraded product was detected.
western blotting confirmed the identity of the 15 kda band (figure 5).
then, using elisa method and beaty equation, the affinity of the nb was calculated as 6×10-8 m. figure 5 sds-page and western blotting.
a) sds-page analysis of nanobody purified by immobilized metal affinity chromatography (imac); lane m: molecular weight marker; lane 1: nb49 and 2: nb60 (tim-3- nanobody) eluted by 500 mm imidazole buffer.
b) lanes 1 and 2: the specific reaction of the hrp-conjugated anti-his tag antibody with nb49, nb60, respectively.
lane m: molecular weight marker a flowcytometric analysis was performed to access the specific binding activity of the nanobody to human tim-3 expressed on cell surface, compared with a standard anti-tim-3 antibody.
based on the obtained results, the frequency of tim-3 positive hek293 cells detected with our nb was almost similar with the standard anti-tim-3 antibody (80% and 85%, respectively).
the results for hl-60 cells were also similar (53% detected with the nb and 65%with the standard antibody) (figure 6).
figure 6 flowcytometry analysis.
a) hek293 stably transfected cell line, express in 85% tim-3 stained with anti-tim-3pe.b) hek293 stably transfected cell line, express in 80% tim-3 stained with anti-tim-3 nanobody, mouse anti-his pe-conjugated antibody.
c) hl-60 cell line that induce for tim-3 expression and stained with anti-tim-3 pe.
about 65% of cells showed expressed tim-3.d) hl-60 cell line that induced for tim-3 expression and stained with anti-tim-3 nanobody and anti-his pe conjugated antibody.
about 53% of cells showed expressed tim-3 cfse proliferation assay engagement of tim-3 on hl-60 cells with galectin-9 leads to the proliferation of the hl-60 cells.
here, using pma, hl-60 cells were induced to express tim-3 and then were treated with galectin-9 as a specific tim-3 ligand.
the cells proliferation was significantly increased 24 hr after treatment with galectin-9 compared with un-treated (negative) control (p=0.0001).
meanwhile, the proliferation of tim-3 expressing hl-60 cells was significantly inhibited (p=0.0001) using both the nb and the commercial antibody versus control (17.2% and16.3% versus 100%, respectively) (figure 7).
figure 7 nanobody tim-3 induced inhibition of hl-60 cell line proliferation.
tim-3 expressing hl60 cells were treated with galectin-9 to be induced for proliferation.
a) proliferation inhibition of hl-60 cells using anti-tim-3 antibody.
b) proliferation inhibition of hl-60 cells using anti-tim-3 nanobody.
in the histograms, (1) represents for hl-60 proliferation; (2) represents for hl60 cells were treated with galectin-9; and (3) represents for proliferation inhibition.
c) more than 80% inhibition of proliferation was observed using both the antibody and the nanobody.
no meaningful difference was observed between the antibody and the nanobody inhibitory effect (p>0.05).
asterisks (*) shows statistical significance compared with control discussion tim-3 exerts various important roles in the regulation of t cell responses and innate immune system.
it has three known ligands including galectin-9, phosphatidyl serin (ps), and high-mobility group protein 1 (hmgb-1).
the interaction of galectin-9-tim-3 in tim-3-expressing th1 cells leads to cell death.
ps binding by tim-3 can mediate uptake of apoptotic cells by phagocytes.
engagement of tim-3 by hmgb-1 has been shown to inhibit activation of resident dcs in the tumor micro-environment (24, 25).
more recently, it has been shown that tim-3 is present at the immune synapse and can be colocalized with phosphatases that suppress tcr signaling.
tim-3 has also been shown to inhibit innate immune cells functions like il-12 secretion and tlr-mediated activation (26, 27).
based on these important functions in immune responses, tim-3 is now considered as a promising therapeutic target for different pathologic conditions.
in the context of infectious diseases, one study has shown that the blockade of tim-3 engagement with its ligands in mouse models of chronic infections can augment t cell responses, which helps to eradicate the infection (28).
independent reports have shown that specific blocking of tim-3 and pd-1 signaling pathways improves t cell responses leading to control of viral infection in chronically infected patients (14, 24).
in a recent study, it has been reported that, in the presence of tim-3 blocking antibodies, the production of il-6, ifn-γ and tnf-α is increased in mycobacterium tuberculosis and in viral infections, which was very useful in inducing macrophage activation and restricting microbial growth (28).
several blocking mabs have been generated to target mouse and human tim-3, so far.
these include rmt3-23, 8b.2c12, 2e2, af2365, atik2a, 344823 and 344801 which differentially affect immune functions (14, 19, 29, 30).
rmt3–23 is an anti-mouse tim-3 blocking mab and has been widely used and tested in various murine tumor models including melanoma, colon adenocarcinoma, sarcoma, prostate carcinoma, and ovarian cancer.
immunotherapy with rmt3–23 mab alone was highly effective to increase tumor-infiltrating ifn-γ-producing cd4 and cd8 t cells and to suppress t regulatory (treg) functions in sarcoma and colon adenocarcinoma models (30-32).
tim-3 also is being considered as a target antigen for anti-leukemia therapy including t-cell leukemia and aml as well as for reversing t cell exhaustion and restoring anti-tumor immunity.
therefore, the success in tim-3 blockade could be a major step forward to the development of immunotherapy for the treatment of different diseases such as cancers (33).
inaccessible anatomical points are a bottleneck for obtaining acceptable clinical outcome after intervention with mabs, as some therapeutic monoclonal antibodies need to penetrate deep into such tissues to reach their targets.
in order to facilitate ab accession to inaccessible points, ab fragments such as scfv, fv, fab and hcabs have been introduced, so far.
hcabs can overcome this bottleneck as they include only a single variable domain (called vhh from camel ab), which generates high affinities towards a large spectrum of antigens.
these small domains (15 kda) can be easily produced in bacteria or yeasts and are then called domain antibodies (dabs), or nbs (34).
nbs are clearly privileged compared with conventional antibody fragments.
some reports of the use of nbs against tumor associated cell-surface markers have shown that nbs can act like normal antibodies (35-37).
heavy chain antibodies (vhh) have provided new opportunities in clinical applications of mabs.
these unique antibodies interact with the antigen by virtue of only one single variable domain.
the recombinant nbs selected from phage display libraries are well expressed, highly soluble in aqueous environments, very robust and have high sequence homology with the human variable region gene family (23).
the affinity of different antibodies has been previously reported in the range of 10-7 to 10-10m (38).
in the present work, the equilibrium dissociation constant (kd) of the anti-tim-3 nb was determined as 6×10-8 m which is a suitable affinity.
several studies shown that very high affinities can be suboptimal for therapeutic antibodies that target solid tumors.
as high affinity antibodies tightly bind their specific antigen upon the first encounter, at the periphery of the tumor, they do not penetrate deeper inside the tumor until all antigen molecules are saturated at the periphery.
by contrast, moderate binders are released from these first encountered antigens and penetrate deeper into the tumor, ultimately leading to uniform intratumoral distribution and higher tumor uptake (34).
vhhs, unlike conventional antibodies, can recognize epitopes in the inaccessible sites such as caves and clefts; hence, penetrate more deeply in different sites (34).
roovers et al have characterized a nb against epidermal growth factor receptor (egfr) and showed in vitro inhibition of egf binding to egfr and in vivo therapeutic effect on tumor in a mouse model (39).
behdani et al have shown that the vegfr2-specific nb can recognize antigen on the huvec cell surface and can inhibit in vitro endothelial tube formation and could be considered as a cancer therapy agent (36).
although many vhh phage libraries have been constructed so far, based on our surveys, no vhh against tim-3 has been reported in literature or in industry.
in the current study, we successfully prepared a novel anti-human tim-3 (cd366) nb from a camel immune library using phage display method.
we showed its high binding capacity to tim-3 comparable with a commercial antibody.
interestingly, this nb showed a high anti-proliferation effect on hl-60, an aml cell line, which was comparable with, even more than, the inhibitory effect of a standard anti-tim-3 antibody.
conclusion altogether, we have been described the successful generation of an anti-tim-3-specific nb from an immune camel library, followed by soluble expression of vhh protein and its binding capacity to tim-3 (cd366).
we also showed its high ability to block gal9/tim-3 stimulated proliferation of a leukemic cell line in vitro.
@highlight
objective(s): as t-cell immunoglobulin and mucin domain 3 (tim-3) is an immune regulatory molecule; its blocking or stimulating could alter the pattern of immune response towards a desired condition.
based on the unique features of nanobodies, we aimed to construct an anti-tim-3 nanobody as an appropriate tool for manipulating immune responses for future therapeutic purposes.
materials and methods: we immunized a camel with tim-3 antigen and then, synthesized a vhh phage: mid library from its b cell’s transcriptome using nested pcr.
library selection against tim-3antigen was performed in three rounds of panning.
using phage-elisa, the most reactive colonies were selected for sub-cloning in soluble protein expression vectors.
the nanobody was purified and confirmed with a nickel-nitrilotriacetic acid (ni-nta) column, sds-page and western blotting.
a flowcytometric analysis was performed to analyze the binding and biologic activities of thetim-3 specific nanobody with tim-3 expressing hl-60 and hek cell lines.
results: specific 15kd band representing for nanobody was observed on the gel and confirmed with western blotting.
the nanobody showed significant specific immune-reactivity against tim-3 with a relatively high binding affinity.
the nanobody significantly suppressed the proliferation of tim-3 expressing hl-60 cell line.
conclusion: finally, we successfully prepared a functional anti-humantim-3 specific nanobody with a high affinity and an anti-proliferative activity on an aml cell line in vitro.
