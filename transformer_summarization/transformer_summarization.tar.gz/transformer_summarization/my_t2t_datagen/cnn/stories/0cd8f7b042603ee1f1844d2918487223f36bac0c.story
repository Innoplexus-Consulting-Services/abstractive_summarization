chikungunya is a mosquitoborne viral disease characterized by symptoms, including fever, rash, myalgia, and polyarthralgia that are usually self-limiting and rarely fatal; however, arthralgia might persist (1).
the causative agent of this disease is chikungunya virus (chikv), which belongs to the family togaviridae, genus alphavirus (2).
genotypes of chikv include west african, east/central/south african (ecsa), and asian.
since 2000, chikv has caused unanticipated, large outbreaks in africa and asia and become a major public health concern (3).
in late 2013, chikv reached the americas and caused several explosive outbreaks (4).
chikv is predominantly transmitted by aedes aegypti and ae.
albopictus mosquitoes (1).
although chikungunya is not endemic to taiwan, aedes mosquitoes are found throughout taiwan (5).
infected travelers with high viremia who arrive or return from disease-endemic areas could lead to local transmission and outbreaks in taiwan.
the study to reduce the risk for importation and subsequent spread of arboviruses in taiwan, active (e.g., fever screening at airports and expanded screening for contact with confirmed cases) and passive (e.g., clinician- or hospital-based) surveillance systems were implemented by the central and local health departments.
serum samples from persons with suspected cases were submitted to the taiwan centers for disease control (taipei, taiwan) for confirmation of arboviral infection.
because symptoms of different arboviral infections might be similar, we performed multiplex real-time reverse transcription pcr (rt-pcr) with flavivirus consensus primers, alphavirus consensus primers, and virus-specific primers and chikv and dengue virus igm and igg elisas for samples collected from all persons with suspected arboviral infections (6,7).
chikv infection was confirmed by detection of chikv rna, isolation of chikv, seroconversion, or > 4-fold increase in igm or igg titers against chikv in paired serum samples (8).
an imported case of chikungunya was defined as disease in an infected patient who had been traveling abroad >2 weeks before onset of illness.
a total of 78 laboratory-confirmed chikungunya patients who satisfied the definition of an imported case were identified during 2006–2014.
among these patients, 6 persons had suspected chikv infections and 4 had suspected chikv and dengue virus infections.
two persons were identified though contacts of persons with confirmed cases of chikungunya.
the remaining 66 persons were initially reported as having suspected dengue infections.
we determined frequencies of imported chikungunya cases by year and country of origin (table 1).
the first imported case was detected in november of 2006. since then, imported cases have been detected every year in taiwan.
the most frequently reported countries of origin were indonesia, the philippines, and malaysia.
table 1 annual number of imported cases of chikungunya, by country of origin and genotype distribution of chikungunya virus strains from imported cases, taiwan, 2006–2014* country year total 2006 2007 2008 2009 2010 2011 2012 2013 2014 indonesia 0 3 (0,3,0) 4 (0,4,0) 4 (1,3,0) 12 (5,5,2) 0 1 (0,1,0) 17 (0,9,8) 5 (0, 5, 0) 46 (6,30,10) philippines 0 0 0 0 0 1 (0, 1, 0) 3 (0, 0, 3) 8 (0,0,8) 1 (0, 1, 0) 13 (0,2,11) malaysia 0 0 3 (3,0,0) 2 (2,0,0) 1 (0,0,1) 0 0 0 0 6 (5,0,1) thailand 0 0 0 2 (2,0,0) 0 0 0 2 (1,0,1) 0 4 (3,0,1) singapore 1 (1,0,0) 0 0 1 (1,0,0) 0 0 0 2 (0,1,1) 0 4 (2,1,1) bangladesh 0 0 1 (1,0,0) 0 0 0 0 0 0 1 (1,0,0) india 0 0 1 (1,0,0) 0 0 0 0 0 0 1 (1,0,0) myanmar 0 0 0 0 0 1 (0,0,1) 0 0 0 1 (0,0,1) cambodia 0 0 0 0 0 0 1 (0,0,1) 0 0 1 (0,0,1) guatemala 0 0 0 0 0 0 0 0 1 (0,0,1) 1 (0,0,1) total 1 (1,0,0) 3 (0,3,0) 9 (5,4,0) 9 (6,3,0) 13 (5,5,3) 2 (0,1,1) 5 (0,1,4) 29 (1,10,18) 7 (0,6,1) 78 (18,33,27) *values in parentheses indicate number of east/central/south african genotypes, asian genotypes, and unidentified chikungunya virus strains, respectively, identified in each country per year.
we found no clear seasonal difference in importation frequency among chikungunya cases (technical appendix figure).
most (57/78, 73%) cases were identified by screening for fever at airports, and 86% (67/78) were reported <7 days of illness onset.
main purposes of travel were business trips of foreign workers, tourism, and family visits (table 2).
table 2 characteristics of 78 patients with chikungunya, taiwan, 2006–2014 characteristic no.
(%) case reporting system fever screening at airports 57 (73.0) expanded screening for contacts of confirmed   case-patients 2 (3.0) clinician- or hospital-based 19 (24.3) age group, y <20 9 (11.5) 20–39 43 (55.1) 40–59 17 (22.0) >60 9 (11.5) onset day <7 67 (86.0) >7 11 (14.1) laboratory confirmation test viral rna or virus isolation 59 (76.0) serologic analysis 19 (24.3) travel purpose foreign labor 26 (33.3) tourism 25 (32.0) family visit 14 (18.0) business trip 8 (10.3) other 5 (6.4) nucleotide sequences of complete structural protein genes c-e3-e2-6k-e1 (capsid–envelope–6k) of 56 imported chikv strains were analyzed.
a phylogenetic tree was generated by using the maximal-likelihood method and a general time-reversible model in mega version 6 (http://www.megasoftware.net/) (9).
imported chikv strains were divided into 2 genotypes: ecsa and asian.
the ecsa genotype was the most common genotype of imported chikv strains before 2010; strains with this genotype were mainly from bangladesh, malaysia, india, and thailand.
the asian genotype was the most common genotype after 2011; strains with this genotype were mainly from indonesia, the philippines, and singapore (table 1).
a phylogenetic tree of asian genotype strains was constructed (figure, panel a).
figure phylogenetic analysis of chikungunya virus (chikv) isolates from imported cases of chikungunya in taiwan, 2006–2014.
trees show genetic relationships of the east/central/south african genotype (a) and asian genotype (b) of chikv isolates; clusters are shown in panel b. trees were generated by using nucleotide sequences (3,747 bp) of complete structural protein genes c-e3-e2-6k-e1 (capsid–envelope–6k) of chikv strains.
sequences obtained in this study are indicated in bold.
viruses are identified by virus/country/strain/year of isolation/genbank accession no.
strains reported in this study were submitted to genbank under accession nos.
fj807886–fj807895, fj807898, fj807899, eu192142, eu192143, hm067743, hm067744, and ku561427–ku561466.
analysis was performed by using mega version 6 software (http://www.megasoftware.net/) and the maximal-likelihood method (general time-reversible model).
bootstrap support values >75 are shown (1,000 replicates) along branches.
scale bars indicate nucleotide substitutions per site.
most of the imported strains could be grouped into 3 clusters.
cluster 1 contains chikv strains imported from indonesia during 2007–2013 and singapore during 2013. cluster 2 contains chikv strains imported from the philippines during 2011–2014.
these strains are closely related to those isolated from yap and st. martin during 2013 and from the british virgin islands during 2014. cluster 3 contains strains imported from indonesia during 2010–2014.
these data suggest that strains from indonesia have shifted from cluster 1 to cluster 3 in recent years.
a phylogenetic tree of chikv strains with the ecsa genotype was constructed (figure, panel b).
a total of 18 imported chikv strains from india and southeast asia also had the ecsa genotype.
all of these strains were grouped together and are closely related to strains from islands in the indian ocean.
although most isolates from indonesia had the asian genotype, there were 6 e1–226v variants imported from indonesia during 2009–2010 that had the ecsa genotype.
relevant amino acid changes in complete structural proteins of imported chikv strains are shown in the technical appendix table.
conclusions a total of 78 imported chikungunya cases were identified in taiwan during 2006–2014.
with the exception of 1 imported chikungunya case from guatemala, countries of origin for all imported cases were in southern and southeast asia.
the location of these countries reflects the frequency of air travel between taiwan and these countries and might also reflect the frequency and intensity of chikungunya outbreaks in these countries during the same period.
chikv has caused major outbreaks in southern and southeast asia since late 2005 (10–14).
our results are consistent with the ecsa genotype being prevalent in singapore, indonesia, malaysia and thailand during 2006– 2010. the asian genotype was prevalent in indonesia and the philippines during 2007–2014.
we found that the e1-226v variants of the ecsa genotype were imported from indonesia in 2009 (15).
our data are concordant with the chikungunya epidemic status in southeast asia, including indonesia and the philippines, in recent years (12,13).
however, the low number of imported chikungunya cases in taiwan does not allow for a meaningful statistical analysis.
because symptoms of many arboviral infections are similar, surveillance strategies in taiwan for different arboviruses are also similar.
most of the confirmed chikungunya cases were initially reported as suspected dengue cases, which indicates that it is necessary to perform diagnostic tests for chikungunya and dengue in suspected cases.
during 2006–2014, a total of 36,150 suspected cases of arboviral infections were initially screened for chikv by rt-pcr and igm/igg elisa (using the first blood sample).
most case-patients were in the acute phase of the disease.
among the remaining suspected case-patients, convalescent-phase serum samples were collected from 320 patients for testing by elisa.
results suggested that the positive rate for chikv (78/36,150, 0.22%) was low among persons with suspected cases of arboviral infection.
in addition, no indigenous chikungunya cases have been identified in this study.
most confirmatory testing was performed by using rt-pcr.
however, this testing could lead to a lower rate of laboratory-confirmed chikungunya cases because there was limited serologic testing completed for paired serum samples.
in addition, the population not captured (e.g., those with subclinical or nonacute infections) could result in an underestimation of the number of imported chikungunya cases.
to prevent spread of arbovirus diseases, well-organized integrated disease and vector surveillance systems must be properly implemented and executed.
detection of imported chikungunya cases by active and passive surveillance at an early stage is needed to implement early response activities and reduce risk for local transmission.
technical appendix additional information on imported chikungunya virus strains, taiwan, 2006–2014.
@highlight
we identified 78 imported chikungunya cases in taiwan during 2006–2014.
sixty-six (84.6%) cases were initially suspected to be dengue, which indicates the necessity for laboratory diagnostics in differentiation between dengue and chikungunya.
results also emphasize the need for active surveillance of febrile illness at points of entry.
