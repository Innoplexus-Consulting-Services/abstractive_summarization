introduction cardiopulmonary cerebral resuscitation training is an essential part of medical teaching curriculum.
[1] the primary objective of teaching basic life support (bls) and advanced cardiac life support (acls) is to learn the sequence of actions according to the american heart association (aha) guidelines and to acquire the necessary skills.
[23] in india, various surveys have shown lack of adequate knowledge of bls/acls among medical students.
[456] therefore, it has been strongly recommended to incorporate bls/acls teaching in undergraduate medical teaching curriculum.
[67] in the medical college where the study was conducted, students are first exposed to bls/acls in the first semester, following which subsequent exposures are done in small groups during their anaesthesia postings in the sixth semester and then during the internship.
in the first semester, as a routine, bls and primary acls are taught for 1 hour using a powerpoint presentation, followed by hands-on practice on mannikin in groups of 8–10 students each.
they are made to practice the bls sequence of action, airway management, ventilation, external chest compression and automated external defibrillation (aed) and the total duration remains at around 2 h. various educational methods used for bls/acls teaching are lecture-based traditional method, problem-based learning (pbl) and simulation.
the best method to teach bls algorithm is not yet defined.
recommendations on the best instructional method are still needed.
[2] many research studies have focused on the efficacy of various educational methods in bls/acls teaching in terms of the improvement in the resuscitation knowledge and clinical skills.
pbl is defined as ‘active learning stimulated by and focused around a clinical or a scientific problem’.
[8910] hybrid-pbl is incorporation of case/pbl discussion method along with the traditional lecture-based method.
[11] very few anaesthesia departments worldwide have incorporated hybrid-pbl format in their undergraduate teaching curriculum.
to the best of our knowledge, no study has evaluated the students’ satisfaction to the various aspects of hybrid-pbl format in bls/acls teaching.
the present study was aimed to compare the students’ satisfaction between traditional lecture-based method and hybrid-pbl format in teaching bls/acls algorithm during the 1st year of medical education among students.
methods a structured, questionnaire-based survey was conducted in the skills laboratory of physiology department of a university medical college over a period of 2 days.
out of the whole batch of 160 students of 1st-year medical students, those present on the 1st day were included in the survey.
a written informed consent was taken from all the participants.
students with previous exposure to bls training or having attended any related class were excluded from the survey.
the questionnaire was specially designed to evaluate students’ satisfaction with two teaching methods, i.e., lecture-based method and hybrid-pbl (group/case-based discussions in addition to the lecture-based method).
the questionnaire evaluated the student satisfaction on four aspects, i.e., learning and understanding, interest and motivation, training one's personal abilities and satisfaction and confidence acquired with the teaching method [annexure 1].
the students were directed to complete the questionnaire unaided according to a 5-point likert scale, i.e., 1 = completely disagree; 2 = disagree; 3 = moderately agree; 4 = agree; 5 = completely agree.
annexure 1 (questionnaire) click here for additional data file.
the lecture and the group discussion were planned and moderated by six aha accredited bls/acls instructors, three faculty members and three senior residents of the department of anaesthesiology.
the learning objectives for bls/acls teaching were laid at the beginning of the session.
students were also introduced to the various teaching methodologies and also briefed about the present survey.
the outline of the methodology is illustrated in figure 1. figure 1 outline of the methodology followed in the study.
el – evaluation for lecture-based method; eh – evaluation for hybrid problem-based learning method as a routine, the lecture session was carried out in a large lecture theatre with fully equipped audio-visual aids.
lecture was made interactive by asking frequent questions, giving examples and drawing conclusions.
in the practical session, students practiced the bls sequence of action, external chest compression, airway management including ventilation and aed, a practice in the institution for the past 4 years, and no changes were made in the whole method to assess the effectiveness of incorporation of case/group discussions along with lecture method (or hybrid-pbl method).
at the end of the practical session, all the students were asked to fill the questionnaire and score their satisfaction with the lecture-based method.
following the lecture, for case discussions, the students were divided into two groups according to their roll numbers; the first half of students (roll nos.
1–80) underwent the group discussion on the 1st day itself and the second half of students (roll nos.
81–160) were sent back and were called on the next day for the group discussion due to lack of time.
on the 1st day of the survey, 68 out of 80 students were present; whereas, on the 2nd day, 60 students out of 80 were present for the case discussion.
soon after the lecture, the questionnaire was collected from the students who were to appear next day for the case discussion.
for the pbl/group discussion session, students were divided, according to their roll numbers, into six groups with 10–12 students in each and were guided by a total of six aha certified instructors.
six case scenarios discussed in case discussions were adult cardiac arrest, adult respiratory arrest and paediatric cardiac arrest and use of aed, choking in adults and choking in paediatric age group.
each instructor was assigned one case scenario, and the students were moved from one station to another and 15 min was allotted for each station.
emphasis was laid more on practicing the correct bls sequence and not on the psychomotor skill acquired as it was taken care in the practical session, following the lecture.
the whole pbl session took around 90 min.
the cases and the contents discussed in each station were kept uniform.
the instructors in each group played the role of a ‘facilitator’ rather than a ‘knowledge imparter’.
at the end of the group discussions, the students were again asked to fill their satisfaction details for the hybrid-pbl format.
this time, they had been clearly instructed to fill their satisfaction with the hybrid-pbl format, by considering the incorporation of case discussions along with the lecture-based method.
based on the number of 1st-year medical students present in the medical college during our research time and after coordinating with the department of physiology, the whole batch of 160 1st-year medical students was enrolled; 146 students who were present on the 1st day were included in the study.
the questionnaire was analysed using descriptive statistics.
the questionnaire was collected and entered into microsoft excel software and then imported into the spss 20 (statistical package for the social sciences 20, chicago, il, usa) for calculating descriptive statistics such as mean and standard deviation (sd).
data are presented as the mean ± sd.
scores regarding the satisfaction between the lecture-based method and hybrid-pbl method were analysed using a two-sided paired t-test.
p < 0.05 was considered statistically significant.
results out of a batch of 160 students, 146 were present on the 1st day and were included in the survey.
then, 128 students filled and returned the questionnaire.
ten students did not complete the questionnaire; finally, 118 students were included in the study.
the response rate was therefore 80% (118/146).
there were 72 males and 46 females.
none of the students had previous bls training experience.
the results of the survey are shown in table 1 and are divided into the following four aspects [table 1].
table 1 comparison of students’ satisfaction between traditional lecture-based and hybrid problem-based learning methods the calculated cumulative mean ± sd of various domains were found to be statistically significant for hybrid-pbl method when compared with the lecture-based method, i.e., 21.7 ± 2.31 versus 18.84 ± 2.063 for learning and understanding (p = 0.006), 8.72 ± 1.13 versus 7.84 ± 1.53 for interest and motivation (p = 0.001), 24.0 ± 3.70 versus 20.28 ± 3.93 for training one's personal abilities (p = 0.001) and 10.1 ± 1.4 versus 8.97 ± 1.4 for satisfaction with the teaching method (p = 0.001) [figure 2].
figure 2 comparison of lecture method with hybrid problem-based learning method discussion in the present survey, the incorporation of hybrid-pbl format, i.e., incorporation of case/group discussions along with lecture-based method in bls/acls teaching, showed better student satisfaction when compared to the traditional lecture-based method in terms of various aspects such as learning and understanding, interest and motivation, training one's personal abilities and satisfaction with the teaching method.
overwhelmingly, majority of the students preferred hybrid-pbl format over traditional lecture-based method for bls/acls teaching.
pbl as a method of teaching bls/acls is being practiced worldwide.
the results of our survey corroborate with the findings of the study by hafezimoghadam et al.
[12] where they compared the lecture-based method with the small group discussions for teaching bls/acls in terms of both the cognitive skills and the students’ satisfaction.
no difference in the cognitive skills was observed; moreover, a combination of lecture-based method and small group discussions was preferred by the students than either of it alone.
[11] in this study, the participants evaluated the overall session, moderator, timing and place.
however, in our survey, in addition to the satisfaction with the teaching methods, we have also evaluated the satisfaction with the various other cognitive domains such as learning and understanding, interest and motivation, training one's own personal abilities and the confidence acquired.
most of the studies, based on various teaching methods in bls/acls teaching, have compared the traditional lecture-based method to the pbl method.
the results of these studies have found pbl to be better[13141516] or comparable[217] to the traditional lecture-based method in terms of the improvement in the cognitive skills.
pbl may not dramatically affect the knowledge scores but may significantly improve the knowledge retention.
[17] pbl is reported to be a better method of teaching bls and acls to undergraduate medical students than the classical lecture-based method.
[15] a previous randomised prospective trial, comparing two methods of teaching bls/acls, i.e., lecture-based multimedia presentation and case-based discussions found that both methods equally improve the level of cognitive skills among medical students.
[2] the major limitation with most of the aforementioned studies is a small sample size.
in all previous studies on bls/acls teaching, the students were divided into two groups for two different teaching methods, i.e., lecture-based method and pbl.
[21314151618] in the present survey, we studied the student satisfaction to the hybrid-pbl format by incorporating the case/group discussions along with the lecture-based method, which was practically more feasible and readily accepted by the students.
the evaluation of teaching curriculum by students is strongly recommended as a part of teaching learning process;[1719] however, the evaluation of students’ satisfaction to teaching methods, especially hybrid-pbl method, has not been studied.
in the present study, we aimed to evaluate students’ satisfaction with the hybrid-pbl format for bls/acls teaching.
the first and foremost limitation of the study was a sizable percentage of incomplete or wrongly filled questionnaires by the participants.
second, the limited clinical exposure to the first-semester students could have been a hindrance to the knowledge acquired, but this was outweighed by their great zeal to learn.
third, there may be a difference in the students’ satisfaction between the two groups, i.e., the one that completed the whole course material in 1 day and the other that came back the following day for case-based discussion.
fourth, difficulty in giving individual attention to the students in terms of the clinical skills acquired during the practical session due to factors such as limited time and huge batch.
finally, the results of the survey only reflect the medical students’ opinion to these two teaching methods and do not intend to evaluate or comment on the cognitive or psychomotor skills acquired.
conclusion implementation of hybrid-pbl format in bls/acls teaching showed overwhelmingly satisfactory results in students’ opinion and is strongly recommended for bls/acls teaching to undergraduate medical students.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
background and aims: students are exposed to basic life support (bls) and advanced cardiac life support (acls) training in the first semester in some medical colleges.
the aim of this study was to compare students’ satisfaction between lecture-based traditional method and hybrid problem-based learning (pbl) in bls/acls teaching to undergraduate medical students.
methods: we conducted a questionnaire-based, cross-sectional survey among 118 1st-year medical students from a university medical college in the city of new delhi, india.
we aimed to assess the students’ satisfaction between lecture-based and hybrid-pbl method in bls/acls teaching.
likert 5-point scale was used to assess students’ satisfaction levels between the two teaching methods.
data were collected and scores regarding the students’ satisfaction levels between these two teaching methods were analysed using a two-sided paired t-test.
results: most students preferred hybrid-pbl format over traditional lecture-based method in the following four aspects; learning and understanding, interest and motivation, training of personal abilities and being confident and satisfied with the teaching method (p < 0.05).
conclusion: implementation of hybrid-pbl format along with the lecture-based method in bls/acls teaching provided high satisfaction among undergraduate medical students.
