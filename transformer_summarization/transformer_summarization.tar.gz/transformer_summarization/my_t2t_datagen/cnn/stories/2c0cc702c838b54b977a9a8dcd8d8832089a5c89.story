introduction aluminum (al) is a non-essential and toxic element with widespread distribution in the environment and extensive use in human daily life.
al can enter human body through ingestion of foods, drinking water, drugs, inhalation of air pollutants, and during hemodialysis.
the neurotoxicity of al and its association with initiation and development of neurodegenerative disease (nd) including parkinson’s disease (pd) and alzheimer’s disease (ad) has been described in many epidemiological and experimental investigations (1, 2).
in rodents al toxicity is associated with ad-like behavioral alteration including impaired learning and cognition impairment.
furthermore, interference in cholinergic, dopaminergic and serotonergic neurotran- smission has been demonstrated in rats following al treatment.
although, the exact mechanism of al-induced neurotoxicity is not clearly described, however, several possible mechanisms have been suggested.
induction of oxidative stress (3, 4), disturbance in intracellular hemostasis of calcium ion (5, 6), increase in intracellular accumulation and structural modify-cation of beta-amyloid peptide (7), promotion of apoptosis are among the most cited mechanisms (8-10).
on the basis of these mechanisms, the impacts of several synthetic and natural substances, including antioxidant compounds, calcium channel blockers, and anti- apoptotic drugs on al-induced cytotoxicity effects have been investigated (10-12).
lithium (li) is a mood stabilizer drug with ameliorating effects on neurotoxicity induced by various toxins.
previous studies revealed improvement in behavioral and biochemical alteration in al-treated animals, following supplementation with li (4, 13).
likewise, the protective effects of ca2+ channel blockers have investigated on harmful effects of several compounds.
nimodipine (nm) is a l-type ca2+ channel blocker which crosses blood-brain barrier and enter brain due to its lipophilic properties (14).
it has been shown that nm improves learning in animal models and ad (15).
moreover, nm protects cells against oxidative stress and from toxic effects of ethanol and heat in a dose-dependent manner (16, 17).
the effects of li and nm have not investigated on al-induced cell death and apoptosis yet.
in the present study we aimed to evaluate the possible ameliorating effects of licl and nm on al-induced toxicity in the pc12 cells, a neuronal-like dopaminergic cell line which is commonly used for neurotoxicological studies (18).
to this end, pc12 cells were exposed to different concentrations of aluminum maltolate (almal) in the presence or absence of nm and /or licl.
almal is a lipophilic complex of al and maltolate that easily passes through cell membrane and leads to accumulation of al in the cells (19).
materials and methods cell culture: pc12 cell line were obtained from pasture institute (iran) and cultured in dmem (gibco) with 10% horse serum and 5% fetal bovine serum (cinagen, iran) and 1% penicillin – streptomycin (cinagen, iran) at 37 °c and 5% co2.
cells were seeded at 103 cells/well in 96 well cell culture plate or 5×104 cells/ml in t25 culture flask for each experiment and allowed to grow for 24 hr prior to treatments.
almal preparation almal was prepared from aluminum chloride hexahydrate (alcl3·6h2o) and maltol (3-hydroxy-2-methyl-4-pyrone) (sigma) as described previously by berthold et al (20).
almal stock solution was prepared in double distilled water at 25 mm concentration and sterilized using a 0.2 μm filter.
working concentrations were prepared using stock solution.
cell viability assay the effect of almal on cell viability was measured using mtt assay (21).
in brief, 103 pc12 cells/ 100 µl of culture medium were seeded into each well of a 96-well plate and cultured for 24 hr.
the cells were pretreated with different concentrations of nm (50,100, and 150 μm) or licl (0.5 and 1.0 mm) for 24 hr and then exposed with various concentrations of almal (0.25, 0.50, 1.0 and 1.5 mm) for 24 hr.
almal concentrations were chosen on the basis of our previous study (22).
doses of drugs were chosen on the basis of a dose response pilot study including different concentrations of nm (1, 10, 20, 50, 100, 150 μm) or licl (0.1, 0.25, 0.5, 1.0, 2.0 mm).
the cells were collected and subjected to mtt assay.
in brief, 20 µl of mtt (5 g/l) was added to each well and incubated for 4 hr at 37 °c.
the culture medium was then replaced with 200 µl of dimethyl sulfoxide (dmso).
the absorbance of each well was determined using an elisa reader with a 560 nm test wavelength and a 630 nm reference wavelength.
the rate of cell growth inhibition was calculated as the percentage of the control group.
annexin v apoptosis assay flow cytometric quantification of apoptotic cells was conducted using pe annexin v apoptosis detection kit i (bd pharmingen).
this method is based on binding of annexin v to phosphatidylserine on the cell surface of apoptotic cells and binding of 7-amino-actinomysin (7-aad) to nucleic acids of cells that have lost their surface membrane integrity including cells in the later stages of apoptosis.
this method was performed to identify the effects of licl and nm on almal-induced apoptosis in pc12 cells.
briefly, pc12 cells were cultured on culture flasks for 24 hr.
the cells were then treated with 1 mm of almal, almal+licl (1 mm) and almal+nm (150 μm) for 48 hr.
the cells were washed in cold pbs and suspended in 1 ml of ice cold binding buffer.
5 µl of annexin v-pe and 5 µl of 7-aad was added to 100 µl of cell suspension and gently mixed, followed by incubating for 15 min in darkness at room temperature.
the cells were acquired within 1 hr using a bd flow cytometer.
a total of 10,000 events were acquired for each sample.
cat activity evaluation control and treated cells were lysed using sonication on ice.
the cell lysates were then centrifuged at 13000 g for 20 min at 4 °c, and the supernatants were used for determination of protein concentration and cat activity.
protein concentration was determined by bradford method (23).
cat activity was measured based on the rate of decomposition of h2o2 at 25 °c, which was monitored by the decrease in absorbance at 240 nm (24).
cat activity is expressed as units/μg protein.
statistical analysis statistical analyses were performed using spss statistical program (version 15).
the represented data are mean±standard deviation (sd) of at least three independent experiments.
significant differences between groups were compared by one-way anova followed by tukey’s post hoc test.
p<0.05 was considered to be statistically significant.
results effects of almal on pc12 cells viability to evaluate the effect of almal on pc12 cells viability, the cells were treated with increasing concentration (0-1.5 mm) of almal for 24 hr and cell viability was determined using mtt assay.
cell viability of pc12 cells after treatment with 0.25, 0.5, 1.0, and 1.5 mm of almal were 94.7±0.98%, 85.1±2.7%, 79.3±3.1% and 52±4.4% of untreated control values, respectively (figure 1), which revealed a decrease in cell viability in a concentration-dependent manner (one-way anova followed by tukey’s post hoc test).
based on the above results, the concentration of 1 mm almal was used for further studies.
figure 1 effects of aluminium maltolate (almal) on cell viability of pc12 cells using mtt assay.
treatment with different concentrations of almal (0-1.5 mm) reduced viability of pc12 cells dose dependently.
the represented data are mean±sd of at least three independent experiments and were analyzed using one way anova followed by tukeys post hoc test the effect of nm and licl on almal-induced cytotoxicity treatment of pc12 cells with almal (1.0 mm) reduced cell viability to 80.7±4.5% of control group (p<0.05).
mtt assay showed that treatment with different concentrations of nm (50, 100, 150 μm) alleviated almal cytotoxicity in a dose dependent manner.
the cell viability after treatment with nm (100 and 150 μm) increased significantly compared to almal-treated group (figure 2).
mtt assay was also used to investigate the effects of treatment with different concentrations of licl on almal-induced cytotoxicity.
the cell viability after treatment with 1.0 mm licl was 92.7±0.5% which showed significant difference compared to almal-treated cells (figure 3).
figure 2 the effect of nimodipine (nm) on aluminum maltolate (almal)-induced cell death.
pc12 cells were treated with almal (1 mm) in the absence or presence of nm (50, 100, 150 μm).
cell viability was then evaluated using mtt assay.
the represented data are mean±sd of at least three independent experiments and were analyzed using one way anova followed by tukey’s post hoc test figure 3 the effect of aluminum maltolate (almal) on pc12 cell viability in the presence or absence of lithium chloride (licl).
pc12 cells were treated with almal (1 mm) in the presence or absence of licl (0.5 and 1.0 mm) and cell viability was evaluated using mtt assay.
the represented data are mean±sd of at least three independent experiments and were analysed using one-way anova followed by tukey’s post hoc test the effect of nm and licl on almal-induced apoptosis the effects of licl and nm on almal-induced apoptosis were investigated using annexinv- pe/ 7aad flowcytometric method.
the finding showed that treatment of pc12 cells with almal (1 mm) increased the percentage of apoptotic cells to 26±2.8% and reduced live cells to 69±1.6%.
co-treatment of nm (150 μm) and almal reduced the percentage of apoptotic cells and increased live cells compared to almal-treated group (p=0.002).
treatment with licl (1 mm) had no significant effects on almal-induced apoptosis (figure 4).
figure 4 the effect of nimodipine (nm) and lithium chloride (licl) on aluminum maltolate (almal)-induced apoptosis of pc12 cells.
the flow cytometric graphs (a) and a histogram (b) illustrate percentage of live and apoptotic pc12 cells in various conditions.
pc12 cells were treated with almal (1 mm), nm(150 μm) +almal (1 mm), and licl (1 mm) +almal (1 mm) for 48 hr.
the percentage of live and apoptotic cells were then measured using annexin-v- pe/ 7aad flow cytometric method.
the represented data are mean±sd of at least three independent experiments and were analyzed using one way anova followed by tukey’s post hoc test.
q1 shows viable cells (annexin v-pe -, 7-aad -), q2 shows cells in early stages of apoptosis (annexin v-pe + and 7-aad -), q3 shows cells in later stage of apoptosis (annexin v-pe + and 7-aad +), q4 shows necrotic cells (annexin v-pe - and 7-aad +).
percent of total apoptotic cells is calculated from q2+q3 *p<0.05 compared to control group (one-way anova); # p<0.05 compared to almal-treated group (one-way anova) the effect of nm and licl on cat activity in order to determine the possible protective effects of nm and licl on almal-induced oxidative stress, cat activity was measured in pc12 cells in different conditions.
the results showed that cat activity in non-treated cells was 0.275±0.04 unit/μg protein.
after treatment of pc12 cells with almal (1.0 mm) cat activity increased to 1.1±0.28 u/μg protein.
as can be seen in figure 5, nm (150 μm) and licl (1.0 mm) reduced cat activity to 0.497±0.06 and 0.7±0.029 u/μg protein, respectively which showed significant differences compared to almal-treated group (p<0.001 and p<0.01, respectively).
figure 5 the effect of nimodipine (nm) and lithium chloride (licl) on catalase activity.
pc12 cells were treated with aluminum maltolate (almal) (1.0 mm), almal+nm (1.0 mm+150 μm, respectively) and almal+licl (1.0 mm and 1.0 mm, respectively).
the represented data are mean±sd of at least three independent experiments and were analyzed using one-way anova followed by tukey’s post hoc test discussion due to wide distribution in the environment and extensive use of al in our daily life, suffering from al-induced toxic effects including neurotoxicity is unavoidable.
thus several efforts have been done to understand the cellular mechanisms of al toxicity and to make effective pharmacological interventions against al toxic effects (2, 25).
the protective role of nm and li against several neurotoxic factors has been demonstrated (26, 27).
in the present study we investigate the effect of nm and li on almal-induced cytotoxicity in pc12 cells.
the results of annexin v/ 7-aad flow cytometry showed that nm ameliorated almal-induced pc12 cell apoptosis but li failed to prevent almal-induced apoptosis.
a combination of various technical approaches including analyses of caspases 3 activation, apoptotic protein gene expression, dna fragmentation assay, and annexin v flow cytometry are performed to confirm cell apoptosis (28).
a limitation of our study is the use of only one method, annexin v/7-aad flow cytometry technique, to detect the role of apoptosis in almal-induced cytotoxicity in pc12 cells.
however, it should be noted that it is known as reliable and choice technique for accurate counting of apoptotic cells which distinguishes apoptotic from non-apoptotic cells by means of simultaneous analyses of two parameter of apoptotic cells (exposure of phosphatidylserine on the cell surface and cell membrane permeabilization of apoptotic cells) (28).
moreover, in our previous study we showed a good correlation between this technique and dna fragmentation assay (other characteristic of cell apoptosis) for detecting al-induced apoptosis (22).
the role of oxidative stress in the al-induced toxicity is well established.
h2o2 is a major component of the reactive oxygen species (ros) produced during oxidative stress.
cat protects cells against the toxic effects of h2o2 by catalyzing the conversion of h2o2 to h2o and o2.
in our previous study we showed an increase in cat activity in pc12 cells exposed to almal that was probably a response to almal-induced oxidative stress.
similar observations were reported by others after tissues exposure to some toxin (29), drugs (30) and metals (31).
in the present study, nm and licl ameliorated almal-induced cat activity, suggesting antioxidant effects of nm and licl against almal-induced oxidative stress.
however, several technical approaches such as direct measurement of ros production, quantification of reduced glutathione (gsh) and by product of lipid, protein and nucleic acid oxidation are needed to evaluate the level of oxidative stress (32).
thus, the use of only one method, cat assay, for detection of almal- induced oxidative stress is another limitation of our study.
neurons and neuron-like cell lines such as dopaminergic pc12 cells exhibit high levels of l-type voltage gated calcium channel (33).
nm is a lipophilic and specific l-type ca2+ channel antagonist that is basically used for the treatment of cerebral vasospasm and migraine headaches.
however, recent evidences have suggested that nm may exert protective effects against different condition that induced neuronal injuries.
in vivo studies revealed that nm improved trauma-induced neuronal injuries (34, 35), alcohol-induced cerebrovas -cular damage (36) and methylmercury-induced behavioral alteration (37).
moreover, in vitro studies showed that nm had a protective effect against different cytotoxic factors including alcohol, osmotic and hypoxic stress (26) as well as oxygen-glucose deprivation in pc12 cells (38).
furthermore, it has been shown that nm served as protective agents against metal-induced toxicity, including iron (39), zinc (40), cadmium (41), and arsenic (42) toxicity.
in the present study, we treated the pc12 cells with almal and nm, for duration of 48 hr.
consistence with previous studies, results of mtt assay showed that almal decreased cell viability, dose dependently (43, 44).
flow cytometric analyses showed that apoptosis was the main cause of cell death following almal treatment.
co-treatment of almal and nm, however, ameliorated al-induced cell death dose dependently.
the rate of al-induced apoptosis was also significantly reduced in the presence of nm as assessed by flow cytometric assay, indicating the role of cellular calcium influx inhibition in mediating al-induced cytotoxicity.
similar results has been reported by vota et al (45) about al-induced eryptosis of red blood cells in which long term exposure with al induced eryptosis by increasing calcium influx and induction of oxidative stress.
the exact mechanism underlying the inhibitory effects of nm on al-induced apoptosis is unclear at present.
one possible mechanism that is supported by our results is through inhibition of al-induced oxidative stress.
we used cat activity for evaluating cellular oxidative stress in this study.
close correlation of cat activity with the oxidative status of the cells and presence of available, simple, and sensitive procedure for the assay of cat activity make it a suitable tool for evaluating the cellular oxidative stress under different condition.
the inhibitory effect of nm on al-induced cat activity suggests that nm abolishes al-induced apoptosis through inhibition of calcium-induced oxidative stress.
the second possible mechanism that may participate in this process is the inhibition of al-induced amyloid beta (aβ) aggregation by nm.
aβ is documented to play a crucial role in al-induced neurotoxicity (46).
on the other hand, diltiazem, a calcium channel blocker, is reported to decrease aβ production by inhibiting calcium influx and oxidative stress.
thus it is hypothesized that nm may protect neurons against al-induced toxicity through inhibition of aβ production and aggregation.
finally, it has been reported that nm could prevent al-induced learning and memory deficit and neurodegeneration in rat (47) and mice (48).
maintaining the homeostasis of iron through suppression of heme oxygenase-1 (ho-1) expression has been proposed as a possible mechanism of nm in mediating these effects.
these results indicate that protective effects of nm in our study may be related to keeping the homeostasis of iron through blunting the expression of ho-1 (48).
further studies are needed to clarify the role of these mechanisms in the protective effect of nm under al toxicity condition.
in the second part of this study we explored the effect of licl on almal-induced toxicity.
according to mtt assay data, li increased viability of almal-treated pc12 cells at 1mm concentration.
furthermore, consistence with several previous studies, our data showed that li treatment reduced cat activity as a marker of oxidative stress.
several evidences indicated that li can ameliorate oxidative stress in various pro-oxidative conditions (49).
an increase in oxidative stress is often linked to cell death due to cellular lipids, proteins and nucleic acids oxidation.
thus, the ability of li to act as an anti-oxidant may describe its protective effect against almal-induced cell death, observed in the present study.
flowcytometric analysis, however, revealed that li had no significant effects on almal-induced apoptosis which implied that li protected against almal-induced cell death probably through inhibition of almal-induced cell necrosis or autophagy, the other causes of al-induced cell death.
in contrast to our results, study conducted by ghribi et al (50) on rabbits brain showed that pretreatment with lithium carbonate for 14 days prevents aluminum-induced apoptosis through down regulation of bax pro-apoptotic protein, up-regulation of anti-apoptotic proteins including bcl-2 and bcl-x as well as inhibition of cytochrome c translocation and caspase-3 activation.
although the reasons for these contradictory results are unclear, but it may be related, at least in part, to differences in the type of cells used in two studies (culture of pc12 cells and rabbit brain cells) and duration of li pretreatment (1 day in our study and 14 days in ghribi et al study).
it has been demonstrated that li at concentrations of 1–2 mm inhibits gsk-3, thus the observed protective effects of li in our study may be related to gsk-3 inhibition (51).
further studies are needed to elucidate the underlying mechanism of li effects on al-induced toxicity.
conclusion in summary, our data revealed the protective effects of nm and li against al-induced cell death and oxidative stress.
these findings are important in precise understanding of molecular mechanisms of al-induced toxicity and can lead to the development of pharmacological strategies to minimize al-induced neurotoxicity.
further investigations should be conducted to clarify the exact mechanism of nm and li protective effects.
@highlight
objective(s): the role of aluminum (al) in the pathogenesis of neurodegenerative diseases has been implicated in several studies.
however, the exact mechanisms of cytotoxic effects of al have not been elucidated yet.
the aim of this study was to investigate the effect of l-type calcium channel antagonist, nimodipine (nm), and lithium chloride (licl) on al-induced toxicity in pc12 cells.
materials and methods: pc12 cells were treated with al-maltolate (almal) in the presence and absence of different concentrations of nm (50-150 μm) and/or licl (0.5-1.0 mm) for 48 hr.
cell viability, apoptosis, and catalase (cat) activity, a marker of oxidative stress, were then measured using mtt, flow cytometry and enzyme assay, respectively.
results: the results showed that almal, dose dependently induced cell death, apoptosis and cat activity in the pc12 cells.
nm significantly increased cell viability and decreased apoptosis and cat activity of almal-treated cells in a dose dependent mode.
licl reduced cat activity and increased cell viability in almal-treated cells, without significant effect on apoptosis (p=0.74).
conclusion: these findings suggest that nm and li may have benefits in the prevention of al-induced cytotoxicity through decreasing oxidative stress.
