introduction what was known?
t-cell lymphomas are the common primary cutaneous lymphomasthe clinical, histological, and immunophenotypic patterns of types of cutaneous lymphomas in our country is not well studied.
cutaneous lymphomas refer to the clonal proliferation of t or b lymphocytes and rarely of natural killer cells or plasmacytoid dendritic cells.
primary cutaneous lymphomas represent the second most common group of extranodal non-hodgkin lymphoma after primary gastrointestinal lymphomas.
sixty-five percent of cutaneous lymphomas are of t-cells unlike nodal lymphomas where b-cells predominate.
the incidence of cutaneous lymphomas is showing an ascending trend which could be due to both improved diagnosis, as well as a genuine increase in disease incidence.
some types of cutaneous lymphomas like mycosis fungoides (mf) presents only on the skin until late and others like adult t-cell lymphoma/leukemia (atl) present with skin lesions indistinguishable from mf clinically and histopathologically.
[1] very few retrospective studies on clinical characteristics of primary cutaneous lymphomas are available in indian population.
[23] due to the rarity of literature, we undertook a prospective, observational study at our tertiary care institution to look into the clinical and histopathological aspects of primary cutaneous lymphomas.
materials and methods after obtaining institutional ethics committee clearance, we conducted this study at our department from january 1, 2010, to december 31, 2015. a structured questionnaire was used to collect the data including age, sex, duration of illness, presence of pruritus, family history, and occupational history.
the patients underwent examination for the type and site of skin lesions, lymph node enlargement, and hepatosplenomegaly.
complete hemogram, urine microscopy, renal and liver function tests, serum calcium and lactate dehydrogenase (ldh) levels, chest and skull radiography, and ultrasonogram of abdomen and pelvis were performed in each patient.
computed tomography of thorax and abdomen and bone marrow biopsy were carried out whenever indicated.
peripheral smear was evaluated for the total number of white blood cells, percentage of lymphocytes and atypical lymphocytes.
five milliliters of blood was collected and screened for human t-cell lymphotropic virus-1 (htlv-1) antibodies.
skin biopsy specimens stained with hematoxylin and eosin were evaluated for epidermal changes including epidermotropism and presence and size of pautrier's microabscess.
inflammatory infiltrate was carefully assessed for atypical cells.
the pattern, density, and extent of atypical cell infiltrate were carefully documented with special reference to individual cell size.
the presence of other cells and dermal papillary fibrosis whenever observed was documented.
all histology specimens were analyzed for immunohistochemistry (ihc) staining for cd3, cd4, cd8, cd20, and cd30.
ihc for cd25 was performed in selected cases.
flow cytometry was done only in two cases.
all patients diagnosed as primary cutaneous lymphomas were included in the study.
the diagnosis of the lymphoma type was established according to the world health organization/european organization for research and treatment of cancer (who/eortc) classification 2005 and the data were analyzed.
mf was staged according to the tumor-node-metastasis-blood staging and patients in stage iib with leukemia were classified as leukemic stage of mf.
all htlv-1 serology positive cases were diagnosed as atl and were classified as acute, chronic, or smoldering types based on presence or absence of hypercalcemia, lytic lesions of skull, and leukemia with >5% atypical cells.
results the study group comprised 35 patients.
twenty-five (71.4%) were males and the rest (28.6%) were females (male to female ratio - 2.5:1).
majority of patients belonged to the age group of 61–70 years [table 1 and figure 1].
mean age was 52.66 years.
exposure to cement was seen in five patients; wood in four; high heat in two; deodorants, fabric dye, pesticides, paint, and tobacco in each patient.
the duration of symptoms prior to diagnosis was 6 months and below in 13 patients (37.1%) 1 year in 8 (22.8%), 2 years in 6 (17.1%), and 5 years and more in 8 (22.8%) with a maximum duration of 14 years.
twenty-five patients had pruritus as a distressing symptom (71.4%).
table 1 age incidence figure 1 age group and sex of patients the types of cutaneous lymphoma we encountered were as follows: t-cell lymphoma in 94.3% (33/35) and b-cell lymphoma (bcl) in 5.7% (2/35).
among the t-cell lymphomas, mf contributed a majority of 57.1% (20/35) followed by atl of 17.1% (6/35).
peripheral t-cell lymphoma not otherwise specified (ptlnos) was seen in 17.1% (6/35) and anaplastic large cell lymphoma (alcl) in 2.9% (1/35).
mycosis fungoides mf patients demonstrated two peaks, both at 41–50 and 61–70.
youngest affected was of 11 years and oldest 99 years, both females.
as depicted in table 2, 60% (12/20) had a single type of skin lesion (either macules, papules or plaques).
none of the patients had nodules alone at the time of presentation.
plaque lesion alone or in combination with other morphological types was seen in 16 patients.
polymorphic plaques occurred in 25% (4 patients),[4] followed by poikilodermatous (18.7%, 3) hyperpigmented (18.7%, 3), and erythematous scaly plaques (18.7%, 3) [figure 2a–d].
one patient with hyperpigmented plaques and nodules developed leukemia.
a total of three patients (15%) presented with follicular papules and indurated plaques.
one with coexistent nodules progressed to leukemic phase [figure 3a–c].
hypopigmented macules were seen in five cases (25%) but coexisted with either hyperpigmented macules or erythematous plaques (mixed type) except in two girls of 18 years and 11 years.
one (5%) out of the twenty cases manifested purpuric papules [table 3].
table 2 type and frequency of skin lesions figure 2 (a) polymorphic plaques over the lower back.
(b) poikilodermatous plaque over the forearm.
(c) hyperpigmented plaques over buttocks.
(d) hyperpigmented plaques over palms figure 3 (a) keratotic plugs, indurated plaques, loss of eyebrows, and leonine facies.
(b) infiltrated papules and plaques with follicular prominence.
(c) follicular papules and nodules table 3 morphological types of mycosis fungoides the most common site affected was back.
the involvement of buttocks was less common and palms and soles were least involved [table 4].
two patients with follicular papules had lesions predominantly over scalp, face, and neck.
table 4 site of lesions in different types of t-cell lymphomas most prominent epidermal findings were hyperkeratosis followed by acanthosis.
epidermotropism was seen in 70% in the form of haloed lymphocytes or as pautrier's microabscess.
all the pautrier's microabscesses were of smaller size (5–10 cells).
most patients had cellular infiltrate involving both papillary and reticular dermis.
the dermal infiltrate was made of small- or medium-sized atypical cells.
it was of mild-moderate density and nodular or perivascular or diffuse in distribution.
two cases with follicular lesions had follicular, and perifollicular infiltrate of atypical cells without epidermotropism [figure 4a and b].
one patient with follicular papules and nodules demonstrated a diffuse infiltrate in addition to perifollicular, progressed to leukemic mf.
prominent dermal papillary fibrosis was noticed in 65%.
other inflammatory cells noted were plasma cells in seven patients (35%), eosinophils and neutrophils in one patient who eventually progressed to leukemic phase with >5% atypical cells [table 5].
figure 4 (a) small sized pautrier's microabscess with small sized, moderately dense atypical lymphocytic infiltrate in the papillary dermis with dermal melanophages in poikilodermatous mycosis fungoides (h and e, ×200).
(b) perifollicular infiltrates without epidermotropism in folliculotropic mycosis fungoides (h and e, ×100) table 5 histological features of cutaneous t-cell lymphomas the most common immunohistochemical pattern observed was cd3+, cd4+, cd8−, and cd30− [table 6].
rare variants such as dual positive and dual negative were observed.
both young females with hypopigmented macules showed cd4− and cd8+ phenotyping [figure 5a–c].
table 6 immunohistochemistry patterns in different t-cell lymphomas figure 5 (a) hypopigmented macule on the back of a young female.
(b) haloed lymphocytes, small sized pautrier's microabscess, and dermal papillary fibrosis (h and e, ×400).
(c) pautrier's microabscess showing cd8 positivity (3,3-diaminobenzidine, ×200) four patients (20%) were in stage ia, eleven patients (55%) were stage ib, 2 (10%) were stage iia, and 3 (15%) iib.
two patients in stage iib developed leukemia and succumbed to illness within 6 months of diagnosis.
the mean ldh was 451.5 (standard deviation [sd] 245.28).
adult t-cell lymphoma/leukemia six cases of atl were identified.
the youngest affected were two males of 31 years and oldest 75-year-old female.
among the six cases of atl, one patient presented with hypopigmented macules.
the combination of different morphological lesions was seen in 5 (83.33%).
the skin manifestations observed were hyperpigmented verrucous papules, purpuric macules and plaques, umbilicated papules, ulcerated plaques and nodules, and generalized erythema with photosensitivity.
the patient with purpuric macules and plaques had oral lesions [table 2].
back and legs were most commonly involved followed by face, chest, and forearms [table 4].
the most prominent epidermal finding was acanthosis.
epidermotropism was seen in 83.3% patients and half of them showed large pautrier's microabscess composed of 25 cells.
the dermal infiltrate was composed of medium-large sized atypical lymphoid cells.
the diffuse and marked dermal infiltrate extended up to the subcutis in a majority.
dermal papillary fibrosis was less prominent, and there was a paucity of other cells [figure 6a–d].
figure 6 (a) ulcerated plaques over the inframammary areas.
(b) diffuse and marked infiltrate of medium-large sized atypical lymphoid cells in the papillary and reticular dermis (h and e, ×100).
(c) large pautrier's microabscess in the epidermis (h and e, ×400).
(d) atypical cells with indented nuclei (h and e, ×1000) the immunohistochemical features of cells were similar to that of mf.
all patients were cd25+.
two cases of acute atl died within 6 months of diagnosis.
among the chronic atl, two patients succumbed to illness within 6 months and one patient within 1 year of diagnosis.
only one patient with smoldering atl survived throughout the study period.
the mean ldh was 1002.3 (sd 559.2).
peripheral t-cell lymphoma not otherwise specified male to female ratio was 5:1 with age ranging from 32 to 68 years.
two patients had localized lesions, and the rest four had disseminated lesions.
three patients had nodules on face and trunk, and one of them had leonine facies.
the nodules were hemorrhagic and ulcerated in two.
neither of the patients had macular lesions nor involvement of buttocks or palms and soles.
epidermotropism was noted rarely.
all except one had diffuse infiltrate composed of either small or medium sized cells, moderate-marked dense and extending up to subcutis.
dermal papillary fibrosis was characteristically less prominent.
hemorrhagic nodules demonstrated angiocentric infiltration.
all patients exhibited cd4+ and cd8− in ihc.
the mean ldh was 428 (sd 324.8).
anaplastic large cell lymphoma a single case of cutaneous alcl in a male patient aged 40 who presented with large subcutaneous nodules separated by a groove with overlying skin showing infiltrated papules, plaques, and ulcerated nodules on the right side of the trunk.
histologically characterized by diffuse infiltrate of cd30 positive large sized cells in the reticular dermis extending to subcutis [figure 7a and b].
figure 7 (a) subcutaneous nodules with “groove sign” showing infiltrated papules, plaques, and ulcerated nodules on the right side of the trunk.
(b) diffuse infiltrate of cd30 positive large-sized cells in the reticular dermis (3,3-diaminobenzidine, ×200) b-cell lymphomas one case of marginal zone bcl in 55-year-old female presented with erythematous and indurated plaques over the thigh and pubic region succumbed to illness within 6 months of diagnosis.
one case of diffuse large bcl in a 72-year-old male with ulcerated and crusted nodules over the right side of the face had an indolent course.
discussion cutaneous lymphomas are classified according to the latest and the widely accepted who/eortc classification 2005 and the who classification 2008 [table 7].
[2] table 7 world health organization-european organization for research and treatment of cancer classification of cutaneous lymphomas with primary cutaneous manifestations majority of cutaneous lymphomas in our study were of t-cells (94.3%) more or less similar to the reports from india, as well as from other asian countries like china and iran but much higher than the incidence in japan (86%), korea (74%), taiwan (74%), and the united states (71%).
a very low number of two cases of bcl constituting 5.7% in our study were identical with that of doshi and khopkar (5.6%) and similar to that from china (6%) and iran (4%).
however, a higher percentage of bcls occurs in western countries (29%) and other asian countries such as japan (13%), taiwan (26%), and korea (29%).
[345678910] in our study, mf contributed a majority (57%) of the t-cell lymphomas followed by atl (17%).
this high frequency of atl was comparable to a study of 62 cases in japan an endemic area.
[11] the presence of atl in india has not been found in any of the previous indian studies.
[34] very low incidence of atl has been reported in korea (0.2%) and taiwan (0%) similar to that in western countries (0.05%).
[8910] in our study, a total 26 patients in the mf and atl group taken together constituted 74.3%.
the similar percentage of mf alone reported by doshi and khopkar warrants htlv screening due to the clinical and histological similarity between the two entities.
a scarcity of cd30+ lymphoproliferative diseases noted in the present study (2.9%) different from previous reports from india and other countries could be due to the low number of cases.
we found a more involvement in younger age group than worldwide lymphoma peaks of 80 years.
[10] a similar age trend (<50 years) has also been reported from other asian countries such as korea, china, and iran.
[568] a consistent male predominance of more than 2-fold was noted in our study.
males demonstrated an early onset of t-cell lymphomas and females a late onset disease.
hypopigmented mf was observed exclusively in younger females.
exposure to chemical agents like aromatic halogenated hydrocarbons in the petroleum, wood and textile industries, organochlorines in pesticides and paints, radiation, and tobacco are thought to be major risk factors for cutaneous t-cell lymphoma, especially mf.
[12] we have also observed such exposures but needs to be proved with further studies.
morphology and distribution of mf lesions in the skin of color are classified as classic, consistent, and atypical.
[13] classic lesions include arcuate scaly, poikilodermatous, atrophic, and polymorphic plaques.
the predominant classic lesions in our patients were polymorphic plaques.
the term folliculotropic mf has replaced previous terminologies of mf-associated follicular mucinosis since all cases are not associated with mucinous degeneration of the hair follicles.
[14] in the present study, two patients with folliculotropic mf had mucin deposition.
hypopigmented mf associated with cd8+ immunophenotype is described almost exclusively in dark-skinned, young, female asian patients.
[15] hypopigmented mf occurred in two girls of which one had unilesional mf.
the “mixed” clinical pattern, hypopigmented patches in addition to erythematous lesions seen predominantly in caucasian patients was noted in 15% (3/20).
mixed forms tend to express cd4 cells predominantly including hypopigmented lesions as was seen in our study as well.
[15] the newly described variants include hyperpigmented, intertriginous, dyshidrotic granuloma annulare-like and cutis laxa-like mf.
[16] hyperpigmented mf was described by pavlovsky et al.
in a younger age group in fitzpatrick type iv skin with cd8+ predominant cells.
[17] however, two patients with hyperpigmented mf in our study were in their sixties with cells demonstrating cd4+ and cd8−.
one of the atypical forms, pigmented purpura-like mf is rare but documented.
[18] there was a single case of male patient with purpuric papules over lower leg.
the so-called d’emblee form of mf has been excluded and belongs to the group of primary cutaneous peripheral t-cell lymphoma, unspecified.
[14] distribution of lesions in mf may be classic involving buttocks, breast, intertriginous areas, or consistent when the lesions are on trunk and extremities or atypical with lesions only on distal extremities or palms or soles.
[13] we found that the classic distribution of lesions affecting buttocks was less frequent than a consistent distribution on back, chest, and forearm.
atypical distribution of lesions affecting palms and soles were rare.
palmar lesions were noticed in a patient exposed to fabric dyes due to unknown causes.
various types of cutaneous manifestations described in atl include hypo- and hyper-pigmented macules, erythematous, purpuric or flesh-colored papules, plaques with or without ulceration, nodules, subcutaneous induration, erythroderma, ichthyosis, vasculitic, angiodestructive, pompholyx-like, granuloma annulare-like, lichen planus-like, acanthosis nigricans-like, and vesiculobullous lesions.
[192021222324] author has reported the unusual presentation of verrucous papules, umbilicated papules, and mucosal lesions in atl.
[25] our study revealed ulcerated lesions in two patients.
most severe skin lesion was erythroderma.
involvement of face, legs, dorsal hands, and feet was noticed in atl more often than in mf.
face lesions occurred more often in ptlnos than in atl and mf.
there was a conspicuous absence of lesions on buttocks and palms and soles in ptlnos.
epidermotropism of atypical lymphocytes is the histological hallmark of mf and has been reported in 75–100% cases.
[26] however, its presence as low as 29% is also known.
[27] pautrier's microabscesses are found in <25%.
[28] we noticed epidermotropism in 70% and pautrier's microabscess in 50%.
the size of pautrier's microabscess was found to be small (5–10 cells) in all patients with mf.
poikilodermatous lesions were characterized by epidermal atrophy and dermal melanophages as known.
[29] plaque stage of mf is characterized by a dense, deep perivascular, or diffuse infiltrate of atypical lymphocytes accompanied by a variable number of eosinophils and plasma cells and papillary dermal fibrosis.
[14] we found a more superficial infiltrate involving papillary dermis, mild to moderate dense, perivascular or nodular more than diffuse accompanied by plasma cells and papillary dermal fibrosis.
alt histologically shows epidermotropism in the form of pautrier's microabscess in up to half of the cases.
[30] the results of this study are in accordance that 50% had pautrier's microabscess, and 83.3% of patients had epidermotropism which is higher than that in mf group.
all the pautrier's microabscesses in atl were larger sized in contrast to small sized pautrier in majority of mf.
three different patterns of infiltration of atypical lymphocytes reported in atl include perivascular, nodular, and diffuse.
[31] our study revealed diffuse infiltrate of marked density of medium-sized cells extending up to subcutis in a majority.
dermal papillary fibrosis which is an important recognizable factor in mf was less prominent in majority of atl.
ptlnos is characterized by solitary or disseminated plaques or nodules.
the presence of focal epidermotropism, diffuse or nodular infiltrates, subcutis involvement, and angiocentricity has been variably observed.
[14] in our study, two patients had localized lesions and the rest had disseminated plaques or nodules.
focal epidermotropism was present in a single patient and was characteristically absent in others.
the infiltrate was predominantly diffuse and extending up to subcutis comparable to that of atl, whereas dermal papillary fibrosis was absent in contrast to mf.
the atypical lymphocytes in mf classically exhibit cd3+, cd4+, and cd8− immunophenotyping.
recently rare phenotypes such as cd4+ and cd8+ dual positive have been reported presenting as sclerotic annular plaques.
[32] in our study, two cases of dual positive mf presented with polymorphic lesions, one patient with purpuric papules and another follicular papules.
hypopigmented mf was found to be cd4− and cd8+.
another cd8+ mf variant with the clinical presentation of poikilodermatous plaques has been reported.
[33] all patients with poikilodermatous plaques in our study showed the common immunophenotype of cd4+ and cd8−.
other reported immunophenotypic variants of mf include cd4/cd8 double negative, cd45ra+, and cd20+.
the former ones behave similar to classic mf although the latter appears to exhibit an aggressive clinical course.
[32] a single case of cd4/8 double negative mf in our study presented with hyperpigmented plaques and nodules and progressed to leukemic mf.
the malignant t-cells of alt were found to be cd4+, cd8−, and cd25+ in 66.7% cases as typically described.
[34] rare variants of dual positive atl have been reported with a variable prognosis.
[3536] in our study, dual positive phenotype occurred in an elderly female with ulcerated plaques and nodules who succumbed to illness within a month and a young male with hypopigmented macules with an indolent course.
mean ldh was found to be elevated in atl group than in mf (1002.3 vs. 451.5).
a higher percentage of patients with atl (83.3) died compared to that (10) with mf during the study period.
to the best of our knowledge, this is the first observational study done prospectively on clinical and pathological aspects of cutaneous lymphomas in our country.
the increasing trend in the incidence of cutaneous lymphomas is reflected in a younger age group with male predominance.
a high percentage of about 17% of adult t-cell leukemia found in our study might reveal its hidden presence in a nonendemic area.
however, the identification of dna integration of htlv-1 by southern blot could not be analyzed in this study.
the number of cases studied is limited which is a major drawback.
declaration of patient consent the authors certify that they have obtained all appropriate patient consent forms.
in the form the patient(s) has/have given his/her/their consent for his/her/their images and other clinical information to be reported in the journal.
the patients understand that their names and initials will not be published and due efforts will be made to conceal their identity, but anonymity cannot be guaranteed.
financial support and sponsorship the study was supported by a grant from the state board of medical research.
conflicts of interest there are no conflicts of interest.
what is new?
mycosis fungoides (mf) was found to be the most common t-cell lymphomas followed by adult t-cell lymphoma/leukemia (atl)atl can be differentiated from mf clinically and histologicallyimmunophenotypical variants such as dual positive and dual negative mf exist in the country.
@highlight
background: little data are available concerning clinical and pathological patterns of cutaneous lymphomas in india.
aim: to analyze the clinical and histopathological characteristics of cutaneous lymphomas in indian patients materials and methods: this is a single-center, prospective, observational study carried out from january 1, 2010, to december 31, 2015. the patients underwent clinical examination, human t-cell lymphotropic virus-1 (htlv-1) screening, skin biopsy with hematoxylin and eosin and immunohistochemistry staining.
results: among 35 cases, 33 (94.3%) were t-cell, and 2 (5.7%) were b-cell lymphomas.
the mean age was 52.66, and the male to female ratio was 2.5:1. the most common types of t-cell lymphomas included mycosis fungoides (mf) (57.1%) followed by adult t-cell lymphoma/leukemia (atl) (17.1%).
primary cutaneous peripheral t-cell lymphoma not otherwise specified was diagnosed in 17.1% and anaplastic large cell lymphoma in 2.9%.
the morphological types of mf included polymorphic, poikilodermatous, folliculotropic, hypopigmented, hyperpigmented, mixed, and purpuric.
skin manifestations of atl included ulcerated plaques and erythroderma.
epidermotropism was very marked in atl (83.3%) than in mf (70%).
larger pautrier's microabscess was noted in atl compared to smaller ones in mf.
markedly dense, diffuse infiltrate of atypical cells was noted in atl in contrast to mild to moderate nodular or perivascular infiltrate in mf.
atl had an extremely poor prognosis.
limitations: identification of dna integration of htlv-1 by southern blot could not be analyzed, and the number of cases studied is limited.
conclusions: the study showed unique patterns of subtypes of cutaneous lymphomas in our country.
variations in the clinical pattern and histopathological analysis will help to differentiate t-cell lymphoma types which have prognostic implications.
