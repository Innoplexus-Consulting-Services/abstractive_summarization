introduction rugby union is a field based team sport, requiring repeated bouts of moderate to high intensity running and activity separated by low intensity running or walking (1, 3, 15).
a rugby union match involves two teams of 15 athletes competing in two 40-min halves.
players are separated into positional groups with forwards tending to possess greater strength/power and backs tending to possess greater speed/agility.
not only have the physical characteristics of rugby union athletes been studied (3, 10), but so have their movement patterns during competitive matches through the use of global positioning systems (gps) (1, 2).
gps systems have allowed for coaches to track the amount of distance covered during a rugby union match and categorize distance covered into varying velocity zones.
previous research has shown that 64% of the distance covered during a rugby union match is spent walking/jogging, while only 24% is covered while cruising/striding, and 11% while running/sprinting (1).
however, little is known as to physical or cognitive abilities that are associated with movement patterns during rugby.
agility, defined as the ability to change direction or velocity rapidly, is considered an important skill in the sport of rugby due to the intermittent, rapid changes in direction, in a high-intensity sport (12).
previous research in professional rugby league matches has shown that change of direction speed did not correlate to attacking or defensive performance, while perceptual skills did correlate with attacking performance (6).
the ability to objectively quantify perceptual skills, such as spatial awareness, may provide insight into athlete movement patterns.
spatial awareness, in the form of 3-dimensional multiple-object-tracking speed (3dmots) testing, has been shown to distinguish between athletes of different competitive levels (4) and is related to sport-specific performance measures (11, 16).
awareness during sports can be observed through tactical maneuvers.
a common defensive tactic in rugby is to minimize the time and space in which the opponent can advance towards scoring (13).
while physically constraining space may be most effective, psychologically constraining space by positioning the defenders to alter the opposition’s perception of space is commonly utilized (13).
an athlete’s ability to make a decision and act in this space is affected by their perception of their individual ability, the task requirements, and the environment (14).
currently, the only studies to assess 3dmots and athletes have been in soccer (16) and basketball (11).
mangine and colleagues (11) correlated 3dmots threshold scores with basketball statistics; while romeas and colleagues observed improved passing accuracy decision-making when training with 3dmots.
the use of 3dmots testing in rugby union athletes has not yet occurred due to the relative novelty of the testing methodology.
therefore, there needs to be a better understanding of 3dmots and how it is related to movement patterns during rugby union matches.
once established, future research could examine the effect of training on in-game performance.
the purpose of the current study is to assess the relationship between spatial awareness, agility performance, and movement patterns during a competitive rugby match.
we hypothesize that spatial awareness will be related to the in-game movement patterns of rugby union athletes.
methods participants this study was approved by the university of central florida institutional review board.
twelve male american championship-level collegiate rugby union athletes (age: 21.2±1.4 y; weight: 85.0±16.0 kg; 7 forwards and 5 backs) volunteered for this study.
all players were starters from the same team.
all participants completed all forms of testing for the study.
protocol spatial awareness was assessed via a 3dmots test (neurotracker; cognisens athletic, inc., montreal, quebec, canada).
the procedures for the 3dmots test have been previously described by mangine and colleagues (11).
each participant wore 3d glasses and sat on a stool placed 7 ft from an 8×8 ft projection screen inside of a simulator cave for one core session.
one core session consisted of 20 trials in which participants were required to track 4 yellow balls, while ignoring 4 distractors, as they all moved through space at a set speed.
each participant was provided 5 practice trials as a familiarization.
at the start of each trial, a 3d transparent cube was presented on the screen containing 8 identical yellow balls (figure 1a).
four of the 8 balls were randomly illuminated for 2 seconds to indicate which balls were to be tracked (figure 1b).
all balls returned to yellow, then randomly moved around the transparent cube at a set speed for 8 seconds (figure 1c).
after 8 seconds, the balls stopped moving and were numbered 1–8 (figure 1d).
participants verbally selected the 4 balls they were tracking.
if they selected correctly, the balls turned white (figure 1e).
after each trial, the speed of the objects was adjusted to either increase or decrease depending on the success of the previous trial.
this pattern of trial, speed adjustment, and subsequent trial was repeated until 20 trials were completed.
at the completion of 20 trials, each participant was given a threshold score (table 1), which was considered to be the threshold for effective perception and processing of visual information sources (4).
the threshold scores obtained from the 3dmots has been correlated to sport-specific ability in professional basketball players (11).
to assess agility, 11 of the 12 participants (one held out due to injury) completed the pro agility and t drill.
all agility testing was completed on the same day, on a synthetic turf field.
the pro agility and t drill have been previously described by hoffman (8) and are depicted in figure 2a and 2b, respectively.
all timing for the agility drills was conducted using the same stopwatch by the same timer.
all athletes were given two attempts to complete each agility drill.
all athletes were provided 5 minutes of recovery between each attempt and each drill.
the best time for each drill was used for later analysis (table 1).
to track movement patterns during a single rugby match, each participant was outfitted with a 10-hz gps receiver/transmitter (minimaxx 4.0, catapult systems, victoria, australia) during an official usa rugby match.
both teams agreed to allow the gps receiver/transmitters to be worn and for data to be collected.
in addition to a gpa receiver/transmitter, the units also contained a 100-hz tri-axial accelerometer.
the procedures for gps tracking were similar to those utilized by wells and colleagues (17).
the units were powered on and given 15 minutes to acquire satellite signals.
after the pre-game warm-up, the units were placed into a harness which was positioned between the shoulder blades and under the participant’s jersey.
participants were tracked in real-time during the course of a competitive rugby match using a laptop computer with catapult sprint software (sprint v5.1) and antenna.
furthermore, substitutions and game stoppages were tracked within the computer software.
following the game, data was downloaded from the gps units and exports for analysis.
total distance covered was assessed relative to minutes played.
distance covered was divided into three velocity zones as previously described by cunniffe and colleagues (1) (table 2).
statistical analysis analysis of variance was used to compare the relative distance covered in each velocity zone and pearson product moment correlations were used to examine the relationship between distance covered in each velocity zone, agility performance, and spatial awareness.
in the event of a significant main effect of velocity zone, bonferroni-adjusted post hoc tests were run to compare the three speed zones against each other.
alpha level was set at p≤0.05 to determine statistical significance.
results the average playing time for the twelve participants was 65.9±21.6 minutes; while the average spatial awareness score was 1.35±0.59 cm.sec−1.
a significant difference (f=142.99, p<0.001, η2=0.929) was noted in distance covered per minute between the three velocity zones.
post hoc tests revealed that the distance covered during the low intensity walking/jogging (39.5±4.5 m/min) was significantly greater than the distance covered during the moderate intensity cruising/striding (20.9±6.5 m/min; p<0.001) and the high intensity running/sprinting (4.9±3.5 m/min; p<0.001).
furthermore, the distance covered during moderate intensity cruising/striding was greater (p<0.001) than distance covered during the high intensity running/sprinting.
when assessing the relationship between movement patterns and spatial awareness, distance covered during walking/jogging and running/sprinting did not correlate to spatial awareness scores (r=−0.106, p=0.740 and r=−0.175, p=0.590, respectively).
however, distance covered during cruising/striding had a significant positive relationship with spatial awareness scores (r=0.798, p<0.001).
in terms of agility performance, there was no significant relationship between the pro agility (5.06±0.28 secs) and walking/jogging (r=0.217, p=0.522), cruising/striding (r=0.321, p=0.336), and running/sprinting (r=−0.081, p=0.812).
furthermore, there was no significant relationship between the t drill (10.62±0.39 secs) and walking/jogging (r=−0.114, p=0.738), cruising/striding (r=0.095, p=0.781), and running/sprinting (r=−0.038, p=0.913).
neither the pro agility (r=0.073, p=0.830) nor t drill (r=−0.052, p=0.878) significantly correlated to spatial awareness.
discussion the results of this study showed that during a competitive collegiate rugby match, athletes covered the most distance per minute of play while walking/jogging and the least amount of distance per minute of play while running/sprinting.
these findings are consistent with previous research conducted during rugby union matches (1).
furthermore, only cruising/striding had a significant positive relationship with spatial awareness scores, indicating that players who covered the most distance at cruising/striding had higher spatial awareness scores.
interestingly, no relationships were found between the other velocity zones and spatial awareness or between agility and in-game performance.
the primary finding of this study was that spatial awareness scores only correlated to distance covered while cruising/striding.
to the authors’ knowledge this is the first study to compare movement patterns and spatial awareness from 3dmots in the sport of rugby union, or any field-based sport.
previous research using 3dmots, revealed most likely and likely positive correlations with assists, steals, turnovers, and assists-to-turnovers ratio in professional basketball players (11).
however, no study has assessed the relationship between spatial awareness and movement patterns in any athletic population.
cruising/striding speed may serve as an intermediate planning speed for rugby union athletes.
previous research has shown that attention focus switches for dissociative (external stimuli) to associative (internal stimuli) as the intensity of exercise increases (9).
the ability to track teammates and opponents while cruising/striding speed may be result of the processing of external and internal stimuli while generally attempting to navigate open space on the pitch.
future investigations should examine the differences in spatial awareness amongst different positions in rugby union and whether those values still correlate to cruising/striding for each position the lack of correlation between agility and distance covered in the three velocity zones is in agreement with previous findings from other sports.
gabbert and colleagues (6) noted that change of direction did not correlate to attacking or defensive performance in professional rugby league players.
however, reactive agility did correlate to attacking performance (6), which could be viewed as skills that require both perceptual and physiological abilities.
future research should examine the relationship between reactive agility and distance covered at different velocity zones.
furthermore, no study has utilized 3dmots in rugby league athletes or rugby union athletes of different competitive levels.
future research should compare the relationship between spatial awareness and moderate intensity running amongst different field-based sports and different levels of competition within those sports.
while spatial awareness was correlated with distance covered while cruising/striding, we cannot deduce if there is a cause and effect relationship between the spatial awareness and movement patterns.
furthermore, there is limited research assessing the trainability of spatial awareness and what effect increased awareness has on match play performance.
previous research has assessed the effectiveness of perceptual training on match performance and decision making in soccer athletes (7, 16), but no perceptual training studies have been assessed in rugby union athletes.
as the current study has established the relationship between spatial awareness and moderate intensity movement patterns, it would be prudent to determine how cognitive training alters rugby competition movement patterns.
future studies should assess the usefulness of training interventions on spatial awareness and how an increased spatial awareness effects match performance in rugby union athletes.
spatial awareness, as determined using 3dmots, appears to be related with distance covered while cruising/striding during a competitive rugby match, while agility performance did not correlate to distance covered at any speed.
spatial awareness may have an effect on the movement patterns of rugby union athletes.
this is the first study to observe a relationship between spatial awareness and moderate intensity movement during a rugby match.
while the existence of the correlation is interesting, future research should investigate the trainability of spatial awareness and the effect on rugby match performance.
spatial awareness as assessed by 3dmots may be an important skill to develop for rugby athletes.
@highlight
the purpose of the present study was to evaluate the relationship between spatial awareness, agility, and distance covered in global positioning system (gps) derived velocity zone classifications during a collegiate rugby match.
twelve american collegiate rugby union players (mean±sd; age: 21.2±1.4 y; weight: 85.0±16.0 kg; 7 forwards & 5 backs) on a single team volunteered to participate in this investigation.
the distances travelled at low (walking/jogging; <2.7m/s), moderate (cruising/striding; 2.7–5.0 m/s), and high intensities (running/sprinting; >5.0 m/s) were measured for each player using gps sensors and normalized according to playing time during an official usa rugby match.
spatial awareness was measured as visual tracking speed from one core session of a 3-dimensional multiple-object-tracking speed (3dmots) test (1.35±0.59 cm·sec-1).
agility was assessed utilizing the pro agility (5.05±0.28 sec) and t drill (10.62±0.39 sec).
analysis of variance revealed that athletes travelled the greatest distance during walking/jogging (39.5±4.5 m·min-1) and least distance during running/sprinting (4.9±3.5 m·min-1).
pearson product moment correlations revealed that only distance covered while cruising/striding (20.9±6.5 m·min-1) was correlated to spatial awareness (r=0.798, p=0.002).
agility did not correlate to distance covered at any velocity zone or spatial awareness.
spatial awareness, as determined by 3dmots, appears to be related to the moderate intensity movement patterns of rugby union athletes.
