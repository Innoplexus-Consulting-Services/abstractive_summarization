introduction saprochaete capitata is a fungus and was formerly called as geotrichum capitatum and blastoschizomyces capitatus.
it rarely causes invasive human infections, usually in immuno-compromised individuals.
it is ubiquitous in nature and can be isolated from soil, water, plants, and air.
it can also be found in the digestive tract of humans and other mammals.
so far, around 104 cases of saprochaete capitata and related species are reported in english literature.
[12] occasionally, saprochaete capitata is easily confused with candida species as they share the similar epidemiology, host predisposition, and morphological similarity.
[345] saprochaete capitata breakthrough has been reported commonly in patients suffering from hematological malignancy while being treated with echinocandins therapy.
[678] it is resistant to most antifungal agents in clinical use.
[4] to the best of our knowledge, this infection is not reported in the literature in renal transplant recipients.
here, we report the first case report of this infection in renal transplant recipients.
case report a 35-year-old male was admitted with fever and productive cough of 20 days duration.
fever was high grade and intermittent.
it was associated with copious sputum, which was foul smelling and had yellowish discoloration.
he had undergone a live related renal transplant, with sister as a donor 4 years ago.
he did not receive any induction therapy and at presentation, he was on triple immunosuppression with tacrolimus 0.5 mg twice daily, mycophenolate mofetil sodium 360 mg thrice daily, and prednisolone 5 mg once daily.
a year ago, he was admitted elsewhere with repeated episodes of diarrhea for which, he received ciprofloxacin and ceftriaxone empirically, approximately for 60 days.
six months ago, he was admitted with persistent diarrhea and stool microscopic examination revealed cysts of cryptosporidium and cyclospora.
he was treated with nitazoxanide 500 mg twice daily and metronidazole thrice daily for 14 days.
diarrhea subsided, and he was asymptomatic for 2 months.
diarrhea continues, and stool examination, endoscopy, and colonoscopy biopsies did not reveal any organism, and he was treated with ciprofloxacin and metronidazole empirically for 2 weeks; diarrhea subsided, and he was asymptomatic.
during the index episode, he presented with fever and cough of 20 days duration.
he had a hemoglobin of 11.5 g/dl, total leukocyte count of 5900/mm3 with neutrophilic predominance (n88, l6, m4, e2), and a normal platelet count of 150,000/mm3.
there was no evidence of neutropenia in the previous reports.
serum creatinine was 0.9 mg%.
throughout the hospital course, renal function was in normal range.
blood culture and urine culture did not grow any organism.
however, x-ray chest showed consolidation of right lower lobe.
high resolution computed tomography of the chest showed consolidation and nodular lesions in the lateral basal segment of right lower lobe.
sputum for gram-stain, koh smear for fungal elements, and culture did not yield any organism.
bronchoalveolar lavage was performed and culture from this fluid grew yeast.
subculture on sabouraud dextrose agar plate grew dry, white colonies in 48 h [figure 1]; gram-stain showed arthrospores and annelloconidia [figure 2], and the yeast was identified in the vitek 2 system using the vitek 2 id yst card as saprochaete capitata.
susceptibility was done using the vitek 2 ast ys 07 card.
it was sensitive to amphotericin, voriconazole, and flucytosine.
as flucytosine was not available at our center, the patient was started on conventional amphotericin b at a dose of 1 mg/kg/day along with oral voriconazole 400 mg twice a day on day 1 as a loading dose followed by 200 mg maintenance dose.
after 10 days, fever and cough subsided.
amphotericin was discontinued after 2 weeks and voriconazole was continued for 6 weeks.
figure 1 macroscopic morphology: 48 h growth on sabouraud's dextrose agar with chloramphenicol (300c) - dry, white colonies of saprochaete capitata figure 2 microscopic morphology: gram stained smear showing arthrospores and annelloconidia of saprochaete capitata (×400) discussion in july 2014, mazzocato et al.
reviewed the literature between 1977 and august 2013 and identified 104 cases of saprochaete capitata including cases reported by themselves.
[2] they found that the patients’ median age was 56 years, 56% were males, and half of them had acute myeloid leukemia, 22% had acute lymphoid leukemia, and 22% had other malignancies.
the majority of patients (82%) were neutropenic at the time of diagnosis, and 75% of saprochaete capitata were isolated from blood.
mortality was about 60%, and amphotericin was the most prescribed antifungal.
our patient did not have a hematological malignancy like earlier reports, and to the best of our knowledge, this is the first case identified in renal transplant recipients.
our patient was a renal transplant recipient for 4 years.
prolonged immunosuppression along with a history of repetitive antibiotic usage for a long time could be the risk factors in our case.
unlike the majority of other case reports, our patient did not have neutropenia, and he was on minimal immunosuppression at the time of infection.
here, saprochaete capitata isolate was resistant to the echinocandins such as caspofungin.
this is similar to the previously published literature from different authors that infection with saprochaete capitata is difficult to treat and carries a high mortality.
[267] saprochaete capitata seemed to have risk factor profile similar to invasive candidiasis.
it is very important to suspect this organism when culture grew candida like growth, but patient is not responding to echinocandins such as caspofungin, which is the drug of choice for invasive candidial infection; as this organism is resistant to these agents.
the patient was started on amphotericin plus voriconazole.
we did not initiate liposomal amphotericin for economic reasons.
the patient responded dramatically probably due to the early initiation of therapy.
repeat broncho alveolar lavage analysis did not grow saprochaete capitata.
conclusion saprochaete capitata is an uncommon fungal infection which mimics candida morphologically and with similar risk factor profile.
immunosuppression is the common denominator in all the cases.
one should suspect this infection when culture shows candida like infection with underlying risk factors, and the patient is not responding to caspofungin since this infection is resistant to common antifungal agents particularly caspofungin, which is the drug of choice in candidial infections.
early diagnosis and aggressive management with appropriate anti-fungal agents are essential for salvage of life.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
saprochaete capitata is a fungus that rarely causes human infections; majority of infections were reported in patients with hematological malignancies.
here, we report a case of saprochaete capitata infection in a renal transplant recipient.
to the best of our knowledge, this is the first case report of infection with this unusual organism in renal transplant recipients.
in our patient, this organism was isolated from broncho alveolar lavage, and it responded dramatically to the combination of amphotericin and voriconazole.
