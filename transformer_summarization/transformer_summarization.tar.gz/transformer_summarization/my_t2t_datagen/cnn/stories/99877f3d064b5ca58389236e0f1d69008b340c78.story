lymphogranuloma venereum (lgv) is a sexually transmitted infection caused by the invasive l genovars of chlamydia trachomatis.
since 2003, outbreaks of lgv have spread across europe and other high-income countries, mainly among hiv-infected men who have sex with men (msm) (1–5).
almost all lgv cases have been caused by the c. trachomatis l2b variant, which harbors an a/g substitution on the ompa gene at position 485, suggesting a single source of origin for the outbreaks (6,7).
recently, however, 2 c. trachomatis variants co-circulated during an lgv epidemic in spain (8).
the objective of this study was to investigate if genetic variations exist within lgv c. trachomatis strains circulating in france during 2010–2015 by sequencing of the ompa gene.
the study in january 2010, france introduced sentinel surveillance for c. trachomatis proctitis, approved by the country’s data protection authority, to monitor the lgv outbreak.
laboratories perform routine testing for c. trachomatis, and positive anorectal specimens are referred to the french national reference center for chlamydiae (bordeaux, france) for lgv testing, using a real-time pcr targeting a 36-bp deletion in the pmph gene (9).
for each patient, clinical, biological, and sexual behavior data are collected after written consent is obtained.
during january 2010–april 2015, we retrospectively selected 179 lgv-positive anorectal specimens from the surveillance samples.
to ensure that samples were representative of infections in the lgv-infected population, we used the following criteria for selecting samples for each year of the study: 1) the percentage of specimens analyzed each year was the same and corresponded to ≈12% of anorectal lgv cases diagnosed in france per year; 2) the residences of patients were classified as in the paris area versus other regions of france to respect the geographic distribution of cases during each year of the survey; 3) samples were distributed over the 12 months of each year, except 2015; and 4) specimens had a high bacterial load, defined as a cycle threshold of <30 using the pmph real-time pcr.
we analyzed 23 c. trachomatis specimens from 2010, 24 from 2011, 24 from 2012, 40 from 2013, 49 from 2014, and 19 from january–april 2015. amplification of the ompa gene was performed directly on specimens.
a 1,100-bp fragment was amplified by nested pcr, using the nlo and nro primers and pctm3 and sero2a primers (10), and sequenced in both directions.
an l genovar was confirmed for all specimens by ompa sequencing.
most specimens (52.5%, 94/179) had ompa sequences identical to that of the c. trachomatis l2b/uch-1/proctitis reference strain (genbank accession no.
am884177.1); 61 (34%) specimens had sequences identical to that of reference strain l2/434/bu (genbank accession no.
am884176.1).
in the remaining 24 specimens, we identified 4 genetic l2b ompa variants that had nonsynonymous single-nucleotide polymorphisms, compared with nucleotide sequence of the l2b/uch-1/proctitis reference strain.
one variant, l2b ompa variant 1 (designated l2bv1; genbank accession no.
jx971936), was found in 19 specimens and featured a c→a substitution at position 517 (leu173ile) (8,11).
a second variant, l2bv2 (genbank accession no.
ku518893), was detected in 1 specimen and had an a→c substitution at position 515 (lys172thr).
the third variant, l2bv3 (genbank accession no.
ku518894), was detected in 2 specimens and shared a c→a substitution at position 493 (his165asn).
the fourth variant, l2bv4 (genbank accession no.
ku18892), was detected in 2 specimens and featured a c→a point mutation at position 286 (ala96thr).
our analysis of the distribution of the c. trachomatis ompa genotype during 2010–2015 showed that the percentage of l2b strain was significantly lower in 2013 (35%, 14/40), 2014 (38.8%, 19/49), and 2015 (31.6%, 6/19) than in 2010 (86.9%, 20/23), 2011 (70.8%, 17/24), and 2012 (75%, 18/24) (p<0.05 by χ2 test) (figure).
conversely, the percentage of l2 strain was significantly higher in 2013 (52.5%, 21/40), 2014 (44.9%, 22/49), and 2015 (52.6%, 10/19) than in 2010 (4.3%, 1/23), 2011 (20.8%, 5/24), and 2012 (8.3%, 2/24) (p<0.05 by fischer exact test).
the percentage of l2b ompa variants was similar during each year of the survey (figure).
in 2012 and 2013, the distribution of l2 and l2b strains and l2b ompa variants was the same in paris and other regions of france, showing that the shift was not due to regional variation (p = 0.86 by χ2 test).
figure distribution of lymphogranuloma venereum–associated chlamydia trachomatis genotypes and variants, according to sequencing results of the ompa gene of representative patient samples, france, 2010–2015.
numbers below bars indicate no.
samples analyzed/no.
cases total (%).
all specimens were from men.
symptoms (rectal syndrome, rectal pains, anal discharge, rectal bleeding) were present in all cases, and clinical features were similar.
data about sexually transmitted bacterial co-infections (e.g., neisseria gonorrhoeae, syphilis) were available for 64.2% (115/179) of patients and showed a similar prevalence among those infected with l2b (34.6%, 18/52), l2 (35.3%, 12/34), or l2b ompa variants (38.5%, 5/13).
serologic hiv status was documented for 112 patients; results were positive for 86.8% (33/38), 79.7% (47/58), and 68.8% (11/16) of the patients carrying l2 strain, l2b strain, or l2b ompa variants, respectively (p = 0.14).
the percentage of msm was lower among patients infected with l2b ompa variants (76.9%, 10/13) than among those infected with l2 (100%, 24/24) or l2b strains (95.7%, 45/47) (p = 0.063).
having an occasional, versus a steady, sex partner was frequently reported, ranging from 76.5% (26/34) in the l2 group to 100% (8/8) in the l2b ompa variants group.
conclusions we describe a change in the molecular epidemiology of c. trachomatis strains involved in an outbreak of anorectal lgv in france.
our results show that, until 2012, the l2b strain predominated, a finding that is in agreement with reports coming from other countries in europe (12).
however, l2b is not a recently emerged strain: the strain was present in 1981 among msm in san francisco, california, usa (12).
different lgv strains have spread widely in the msm community since 2013, and prevalence of the l2 genotype has increased.
these data suggest that the co-circulation of the 2 predominant lgv strains could be the result of 2 independent introductions.
the l2 strain is more prevalent in the united states (13), and the last known outbreak was in 1992 in the caribbean area (14).
knowing the country of residence of the partner who was the possible source of infection would potentially enable identification of distinct introduction pathways for l2 and l2b strains.
our findings show that 4 genetic c. trachomatis l2b ompa variants have been circulating in france since 2010. three of the variants have amino acid changes in the variable domain ii, which has been described as a common antigenic domain for c. trachomatis.
the l2bv1 strain was identified during september 2011–march 2012 in 4 specimens collected in new york, usa, and in 1 specimen collected in spain between 2009 and 2011 (8,11).
in our study, c. trachomatis strain l2bv1 was first identified in 2011 and then each year thereafter; it was the predominant l2b ompa variant.
the 3 other variants had not been previously described.
patient characteristics did not differ with regard to clinical data, sexual behavior, or the c. trachomatis genotypes involved in lgv infections.
our results are discordant with those of rodríguez-domínguez et al.
(8), who showed less aggressive symptoms among patients infected by c. trachomatis l2 strain than those infected by l2b strain.
our results must be confirmed by genetic characterization of more specimens.
however, we observed genetic diversity of lgv c. trachomatis strains when testing as few as 12% of reported anorectal lgv patients a year.
future research might examine if the increase of lgv cases in other countries is also associated with an increase in c. trachomatis l2 strain.
@highlight
we describe a change in the molecular epidemiology of chlamydia trachomatis strains involved in an outbreak of rectal lymphogranuloma venereum in france during january 2010–april 2015. until 2012, the c. trachomatis l2b strain predominated; however, starting in 2013, most cases involved the l2 strain.
we also identified 4 genetic l2b ompa variants.
