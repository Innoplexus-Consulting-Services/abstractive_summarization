introduction human behavior in social relationships is prescribed by rules, and it is necessary to follow rules to lead a successful social life.
rules determine the relationship between the value of an action and a specific situation; therefore, humans choose their actions based on a value arising from a rule pertaining to the current situation (bunge, 2004).
when a large-scale advanced information system is operated, such as a power plant or air traffic control center, it is very important for the operator to choose the appropriate behavior within the restrictions engendered by the rules for the situation, which change dynamically to maintain the safety of the system.
tactical thinking is required to follow the rule and determine an appropriate behavior under that rule.
in addition, an interaction between the situation and the appropriate behavior are important in that tactical thinking.
cognitive control, or executive function (miyake and friedman, 2012), is an essential cognitive function that underlies the placing of a value on a situation, and choosing the appropriate response under a specific rule; the lateral prefrontal cortex (lpfc) plays a key role in cognitive control (bunge, 2004; badre, 2008; dixon, 2015).
a previous neuroimaging study suggested that the magnitude of the expected incentive is related to increased lpfc activity reflecting the cognitive control process (dixon and christoff, 2012).
enhanced lpfc activity represents the increase in cognitive load needed to perform difficult experimental tasks.
previous neuroimaging studies using a working memory task showed a robust relationship between lpfc activity and task difficulty (braver et al., 1997; manoach et al., 1997; ayaz et al., 2012; fishburn et al., 2014; ozawa et al., 2014).
other studies have suggested that the lpfc plays a key role in attentional control (rossi et al., 2009), and that activity in the lpfc represents attentional status for a task requiring sustained attention (derosière et al., 2014).
in addition, similar relationships between lpfc activity and difficulty with language processing (miura et al., 2005) and arithmetic processing (verner et al., 2013) have been reported.
those relationships are associated with the increased demand placed on cognitive resources as task difficulty increases.
increased task difficulty, and addition of an extra rule, affect the degree of cognitive control required.
however, it remains unclear how cortical activity associated with tactical thinking—to choose an appropriate behavior under the additional rule—affects cortical activity in terms of coping with a difficult situation and the original rule.
as mental workload increases after adding a specific rule, the difficulty of task execution may also increase.
however, mental workload would also increase when trying to adapt to a limitation engendered by that rule, even if the task is easy to accomplish, and, therefore, may be dissociated from the increased mental workload required with increased task difficulty.
we hypothesized that these two factors affect increased cortical activity individually, and that the effects might be different in the left and right lpfc.
to examine this hypothesis, we designed an experimental video game in which the player catches balls falling on a computer screen.
furthermore, to explore the interactive effect between task difficulty and the existence of an additional rule, to determine the outcome on cortical activity, we manipulated the difficulty of the gameplay, and added a rule that affected the score.
functional near-infrared spectroscopy (fnirs) was utilized to measure cortical activity in the prefrontal cortex in this study.
fnirs measures changes in cortical surface activity based on changes in the relative density of oxyhemoglobin (oxy-hb) and deoxyhemoglobin (villringer and chance, 1997; ferrari and quaresima, 2012).
fnirs measures activity under conditions of lower restraint of body motion compared with other neuroimaging techniques, such as functional magnetic resonance imaging and electroencephalography; therefore, the fnirs technique has been widely used to elucidate cognitive functions (masataka et al., 2015) in a neuroergonomics study (derosière et al., 2013) and to develop a brain-computer interface (bauernfeind et al., 2008; pfurtscheller et al., 2010; yanagisawa et al., 2010; strait and scheutz, 2014; naseer and hong, 2015).
from these findings, we expected to measure cortical activity even when the experimental task required continuous hand and arm actions by the player.
as a consequence, the present study conducted an fnirs experiment in which task difficulty was manipulated and a rule related to the experimental task was added to dissociate cortical activities, which increased the task difficulty and modified behavior to cope with the additional rule.
materials and methods participants twenty healthy japanese university students (18 males and two females; mean age: 21.9 ± 1.6 years, range: 20–26 years) participated in this study.
no subject had a history of neurological or psychiatric disorders.
all participants provided written informed consent to an experimental protocol approved by the research ethics committee of tohoku institute of technology, and the experiments were performed in compliance with national legislation and the code of ethical principles for medical research involving human subjects of the world medical association (declaration of helsinki).
experimental task figure 1 shows a summary of the experimental task.
the experiment consisted of one practical run and one actual run for the fnirs measurements.
the actual run consisted of four experimental task conditions in a video game involving the catching of balls using a controllable object.
as each condition had two task blocks, the actual run included eight task blocks and the order of the task blocks was shuffled for each participant.
the duration of each task block was 30 s, and the resting interval between two consecutive blocks was 30 s. in the experimental task, small squares, which represented five colors of virtual ball, fell at a constant velocity from the upper part of a computer screen.
the horizontal axis of the initial position of each square was assigned randomly.
a rectangle was also displayed on the lower part of the screen and could be operated in the horizontal direction using a computer mouse.
a score was calculated for each task block.
the participant received 100 points after catching the square with the rectangle, but lost 50 points when the square was not caught.
in addition, the participant received an additional 500 points if all five balls were caught in succession.
a total of 25–29 squares appeared during each block; the actual number was determined by a random number generator on the computer.
a perfect score for each task block was 5000–5400 points.
the number of balls of each color was equal.
the score for the current task block was indicated under the rectangle.
the participants were instructed to catch the squares using the rectangle and to obtain as high a score as possible under these rules.
figure 1 outline of the experimental task.
(a) summary of visual stimuli: small squares of five colors fell from the upper part of the screen, and an object controllable by the participant was placed in the middle part of the screen.
the current score was displayed on the lower part of the screen.
(b) setup for each task condition; easy condition with a basic rule (easy with br), easy condition with basic and additional rules (easy with br + ar), difficult condition with a basic rule (difficult with br), and difficult condition with basic and additional rules (difficult with br + ar).
task difficulty was determined by the width of the playable space.
the additional rule penalized the participant 2000 points if the red square was not caught.
the participant was made aware of the rule settings by a displayed message.
(c) timeline of experimental task: the duration of each task condition was 30 s, and the inter-task interval was 30 s. four task conditions were prepared by changing the task difficulty and adding another rule, including an easy condition with a basic rule (easy with br), an easy condition with a basic and an additional rule (easy with br + ar), a difficult condition with a basic rule (difficult with br), and a difficult condition with a basic and an additional rule (difficult with br + ar).
two task difficulty conditions (easy and difficult) were defined by the width of the playable space in which the balls fell; that is, the width of the playable space during the difficult condition was wider than that of the easy condition, although the height of the space was the same.
the scores for the experimental task under the additional rule conditions were reduced greatly when a ball of a specific color could not be caught.
the specific color was defined as red, and the participant lost 2000 points if they could not catch the red ball.
the participants were aware of this additional rule before the trial; the rule was displayed in red text on the screen during the corresponding task blocks.
the fnirs experiment consisted of a short practice run and an experimental run; the experimental run included two repetitions of each task condition.
a 30 s resting period was imposed prior to the first task block and a 30 s resting period was imposed after each task block.
thus, the total experiment time was 8 min and 30 s. the order of the task blocks was shuffled for each participant.
the participant performed only the easy without additional rule condition continuously during the practice run, and the run ended after the participant indicated that they had practiced sufficiently.
fnirs measurement the experimental task was performed using presentation software (ver.
16.1; neurobehavioral systems, albany, ca, usa) implemented on a laptop computer (hp probook 6570b; hp japan inc., tokyo, japan).
the participant was instructed to sit in a chair and to carry out the experimental task using the laptop computer with a computer mouse.
the fnirs data were measured from the forehead covering the frontal to temporal area using a 52-channel optical topography system (etg-4100; hitachi medical corp., tokyo, japan).
the arrangement of emission and detector probes and measurement channels is summarized in figure 2. the probes were arranged in a matrix with three rows and 11 columns, and a rubber holder was used to fix the position of each probe.
the distance between each emission and detector probe was 3 cm.
a probe in the third row and sixth column on the arrangement matrix was placed in the fpz position of the international 10-20 system for eeg electrode placement, and the position was adjusted slightly so the participant did not feel any pain from the rubber holder.
the positions of the probes in both right and left ends of the arrangement matrix were located in the upper side of the ears on a participant’s head.
changes in the densities of oxy-hb and deoxy-hb were measured at a 10 hz sampling frequency.
time series data for changes in the density of oxy-hb were used for the analysis.
figure 2 arrangement of the near-infrared spectroscopy (nirs) channels.
each emitter and detector probe was placed in a reticular pattern on the participant’s forehead.
the red and blue circles indicate emitter and detector probes, respectively.
the yellow rectangles indicate measurement channels, and the numbers (1–52) are the serial numbers for each channel.
data analysis the fnirs signal data were preprocessed using matlab software (r2013b; mathworks, natick, ma, usa).
the time series data from each channel were preprocessed independently.
data from channels were excluded based on the standard deviation (sd) of the entire time series (sd > 1 [mmol × mm]).
to remove signal components due to slow fluctuations in blood flow and rapid fluctuations, such as heart beat or measurement noise, the low order trend of the entire time series was removed using third-degree polynomial fitting, and a band path filter between 0.004 hz and 1 hz was utilized.
time series data of each task block were extracted together with 5 s of the resting period, just before and 25 s just after each task block.
to eliminate task blocks affected by rapid signal changes originating from motion artifacts, blocks that included signals between two consecutive samples >0.1 (mmol × mm) were discarded.
the mean signal change during the task blocks relative to the 5 s resting period just before the task block for each condition was computed for every channel.
the statistical analysis was carried out using r software (ver.
3.2.3; the r foundation for statistical computing, vienna, austria).
we focused on elucidating the hemispheric differences in cortical activity associated with changes in tactical thinking when following a rule.
the anatomical location of the signal source could not be specified precisely because of low measurement resolution and the difference in head shape of each participant.
consequently, two regions of interest (rois), corresponding to bilateral lpfcs, were defined, and the mean signal from the rois was used for the statistical analysis.
channels 29, 30, 31, 40, 41, 42, 50, 51 and 52 were selected as the rois corresponding to the left lpfc, and 22, 23, 24, 32, 33, 34, 43, 44 and 45 were selected as the rois corresponding to the right lpfc.
since the arrangement of measurement channels covered the frontal to temporal area of head, the anatomical location of rois were expected for the regions including bilateral middle and inferior frontal gyrus, premotor area and superior temporal gyrus on a participant’s head with standard size.
a three-way repeated-measures analysis of variance (anova) was performed using the mean signals of the rois for each condition; three within-subject factors were determined by the difference in task difficulty (easy or difficult), the existence of an additional rule (br or br + ar), and the location of the roi (corresponding to the left or right lpfc).
a p-value < 0.05 was considered significant.
furthermore, an additional roi was also defined on medial part of forehead which correspond to the front polar region in order to test an existence of task-related signal increase for each medial and lateral prefrontal area.
channels 25, 26, 27, 28, 35, 36, 37, 38, 39, 46, 47, 48 and 49 were selected as the roi corresponding to the front polar region.
to test the existence of task-related activity, the mean signal change of entire task blocks was calculated, and one sample t-test was performed for each roi, respectively.
and, a correlation analysis between the score of each task condition and the mean signal from each roi was performed to confirm a relationship between the task performance and the cortical activity on each lpfc region.
the bonferroni correction was used for correction of p-value for multiple comparisons.
results table 1 summarizes the mean scores obtained for each task, and the ratio between the obtained score and the perfect score for each task.
all participants received a perfect score under the easy without an additional rule condition but scores decreased when task difficulty increased or the additional rule was applied.
the two-way repeated-measures factorial anova for obtained score of each task revealed significant main effect of task difficulty (f(1,19) = 106.8884, p < 0.0000, generalized η2 = 0.7195) and the existence of additional rule (f(1,19) = 16.9618, p = 0.0006, generalized η2 = 0.0530), and significant interaction effect was also detected (f(1,19) = 11.3884, p = 0.0032, generalized η2 = 0.0245).
a post hoc analysis showed that the factor of the existence of the additional rule showed significant difference at the difficult task condition (f(1,19) = 19.8718, p = 0.0003, generalized η2 = 0.0767), but that difference was not observed under the easy task condition (f(1,19) = 19,363, p = 0.1801, generalized η2 = 0.0485).
therefore, the existence of additional rule influenced decrease of score when the task difficulty was set at difficult level.
table 1 obtained scores and the ratio between the obtained and perfect scores for each task block.
task factor score obtained ratio of the score obtained to the perfect score task difficulty existence of additional rule mean sd mean sd easy without additional rule (br) 5200 0 1.00 0 with additional rule (br + ar) 5106 301 0.98 0.06 difficult without additional rule (br) 3471 760 0.67 0.14 with additional rule (br + ar) 2998 920 0.58 0.17 figure 3 illustrates the relative changes in oxy-hb density during each task compared with the resting period just before the task for each measurement channel.
bilateral lpfcs showed a large increase in signal intensity (for right roi: mean signal = 0.0535, t(19) = 3.0103, p = 0.0107; for left roi: mean signal = 0.0767, t(19) = 5.0884, p < 0.0000), whereas the signal from the middle part of the forehead corresponding to the front polar region did not change (mean signal = 0.0147, t(19) = 1.2292, p = 0.3510).
figure 3 bar charts showing mean signal changes in oxygenated hemoglobin (oxy-hb) in each measurement channel during the task.
error bar indicate standard error of the mean.
charts enclosed by the blue frame indicate the channels selected as right and left regions of interest (rois).
table 2 shows the mean signal changes of the rois corresponding to the bilateral lpfcs, and table 3 summarizes the results of the anova for the mean signals of the rois for each condition.
and, figure 4 shows the time series for the relative changes in oxy-hb density under each task condition in both rois.
the three-way repeated-measures factorial anova revealed significant main effects of task difficulty (f(1,19) = 5.8839, p = 0.0254, generalized η2 = 0.0573), existence of an additional rule (f(1,19) = 9.4296, p = 0.0063, generalized η2 = 0.0638), and roi position (f(1,19) = 6.4378, p = 0.0201, generalized η2 = 0.0131).
in addition, significant interaction effects were detected between the additional rule and the roi position (f(1,19) = 11.7581, p = 0.0005, generalized η2 = 0.0069); a post hoc analysis indicated that the factor of the existence of the additional rule showed significant difference at the left roi (f(1,19) = 17.9952, p = 0.0004, generalized η2 = 0.1142).
and, the factor of the location of the roi showed significant difference when the task involved the additional rule (f(1,19) = 14.9463, p = 0.0010, generalized η2 = 0.0366).
therefore, the signal change on the left lpfc showed a marked increase when the additional rule was exist on the task, but degree of this effect was different in the left and right rois, the effect of the additional rule was not significant on the right lpfc (f(1,19) = 3.4856, p = 0.0774, generalized η2 = 0.0284).
table 2 observed near-infrared spectroscopy (nirs) signal changes for each task condition relative to the resting period in the right and left regions of interest (rois) on lateral prefrontal cortex (lpfc).
task factor right roi (mmol*mm) left roi (mmol*mm) task difficulty existence of additional rule mean sd mean sd easy without additional rule (br) 0.0153 0.1004 0.0219 0.0857 with additional rule (br + ar) 0.0418 0.0907 0.0819 0.0844 difficult without additional rule (br) 0.0558 0.1115 0.0620 0.1059 with additional rule (br + ar) 0.1010 0.1241 0.1409 0.1173 table 3 result of three-way repeated-measures analysis of variance (anova) for the nirs data at the right and left rois.
effects sum of squares df mean square f-value p value generalized η2 subj.
0.7612 19 0.0401 task difficulty (difficulty) 0.0988 1 0.0988 5.8839 0.0254* 0.0573 subj.
× difficulty 0.3191 19 0.0168 existence of additional rule (rule) 0.1109 1 0.1109 9.4296 0.0063* 0.0638 subj.
× rule 0.2234 19 0.0118 roi position (l/r) 0.0216 1 0.0216 6.4378 0.0201* 0.0131 subj.
× l/r 0.0636 19 0.0033 difficulty × rule 0.0035 1 0.0035 0.3454 0.5637 0.0022 subj.
× difficulty × rule 0.1946 19 0.0102 difficulty × l/r 0.0000 1 0.0000 0.0005 0.9831 0.0000 subj.
× difficulty × l/r 0.0226 19 0.0012 rule × l/r 0.0113 1 0.0113 11.7581 0.0061* 0.0069 subj.
× rule × l/r 0.0183 19 0.0010 difficulty × rule × l/r 0.0000 1 0.0000 0.0000 0.9950 0.0000 subj.
× difficulty × rule × l/r 0.0229 19 0.0012 total 1.8720 159 0.0118 a p-value with an asterisk indicates a significant difference (p < 0.05).
figure 4 time series of the mean signal changes for each task condition at the (a) right and (b) left rois on lateral prefrontal cortex (lpfc).
horizontal axis indicates elapsed time (s) from the beginning of each task block, and vertical axis indicates the relative change in oxygenated hemoglobin (oxy-hb) density (mmol × mm) from just before the rest period.
the result of correlation analysis revealed that significant correlations were not observed between the performance data and the mean signal changes of the rois.
the correlation coefficients under the easy conditions (easy with br and easy with br + ar) could not appropriately compute because of the ceiling effect of the scores.
and, the correlation coefficients under the difficult condition for each roi did not show the statistical significance (for right roi: r = 0.3195, t(18) = 1.5994, p = 0.6544 for difficult with br; r = 0.2999, t(18) = 1.3335, p = 0.7960 for difficult with br + ar; for left roi: r = 0.3520, t(18) = 1.5954, p = 0.5120 for difficult with br; r = 0.4333, t(18) = 2.0396, p = 0.2256 for difficult with br + ar).
discussion the behavioral analysis showed that scores decreased with higher task difficulty and when the additional rule was included.
score were lowest under the difficult with br + ar condition compared with those obtained under the other conditions.
thus, both factors were affected separately by subjective workload.
all participants achieved a perfect score under the easy without additional rule condition, indicating that they understood the game sufficiently well.
however, some participants only captured the red ball under the easy with br + ar condition, which consequently decreased their score.
the same tendency was observed under the difficult with br + ar condition.
these results indicate that the participants changed their behavioral tactics to avoid the risk of a large point deduction, even if the condition could not be satisfied.
thus, the change in behavioral tactics to cope with the additional rule affected mental workload and task difficulty.
as for a novel finding of this experiment, the left lpfc showed a larger nirs signal increase compared with that of the right lpfc when the additional rule existed in the task.
a significant main effect of roi location, and an interaction between the factors of task difficulty and existence of the additional rule, were detected.
the post hoc analysis showed significant simple effects, indicating that activation of the left lpfc was enhanced when the additional rule was in place.
although the patterns of fnirs signal changes while the participants performed the experimental task without an additional rule were almost the same between the left and right rois, large signal increases were observed specifically in the left roi when the additional rule existed.
thus, the specific signal increases in the left roi were induced by the existence of the additional rule, and this effect occurred independent from the increase in task workload (represented by increased signals in bilateral lpfcs).
these results suggest that the cognitive mechanism underlying the changes in behavioral tactics had a different effect on mental workload.
the participant could not miss any of the balls to achieve a high score; therefore, they were expected to catch the balls in order, closest to the limit of the fall.
moreover, if a participant decided that they could not catch a ball under the more difficult task conditions, they did not attempt to catch the ball closest to the limit of the fall but tried instead to catch the second-closest.
thus, the behavioral choice for the task without the additional rule may have been made using simple tactics throughout the task block.
in contrast, the participant avoided missing the red ball when the additional rule was present because violation of that rule resulted in a large scoring penalty.
consequently, the participant occasionally decided not to catch some balls, so they could instead catch the red ball before it fell.
thus, the behavioral choice when the additional rule existed was switched to catching of a ball with a specific color to avoid the penalty.
the participant had to judge whether the behavioral choice should be switched from the usual tactic when a red ball appeared to make such a behavioral choice during the task.
thus, the cognitive processing required to modify the behavioral choice to cope with the additional rule increased the mental workload, and the specific increase in signal intensity in the left roi, for the task with the additional rule, reflects the cortical activation underlying that cognitive processing.
mcguire and botvinick (2010) reported a relationship between the subjective cost of a decision and activity in the left lpfc.
braver et al.
(2003) suggested that transient cognitive control is associated with reinforced activation of the left lpfc compared with sustained cognitive control during task switching.
berkman and lieberman (2010) reported that motivated and approach actions activate the left dorsolateral prefrontal cortex compared with avoidance, regardless of stimulus intensity.
bunge (2004) suggested that the left ventral lpfc is associated with rule retrieval.
taken together, these results indicate that the increased signal intensity in the left lpfc is associated with an increase in the cognitive workload required to switch behavioral tactics to deal with the current situation and the additional rule.
the nirs results also revealed that signal intensity in bilateral lpfcs increased significantly during the game, and that the signal increase became highest when the difficult with br + ar condition was performed.
since decrease of the score is considered to reflect the workload for each condition, the difference of signal increase would represent the difference of workload to perform each task condition.
previous neuroimaging studies suggested that the lpfc is associated with cognitive control (bunge, 2004; badre, 2008; dixon, 2015) and has a hierarchical structure (koechlin et al., 2003; kouneiher et al., 2009).
activation of the lpfc has also been associated with various cognitive processes, such as response inhibition and task switching (kane and engle, 2002; niendam et al., 2012).
furthermore, the magnitude of the lpfc activation reflects the workload required for the working memory task (braver et al., 1997; cohen et al., 1997; jonides et al., 1997; manoach et al., 1997; herff et al., 2014; ozawa et al., 2014).
in addition, a relationship between performance on a working memory task and fnirs signal intensity from the lpfc has also been suggested (tanida et al., 2012; ogawa et al., 2014; yasumura et al., 2014).
sato et al.
(2013) demonstrated the appropriateness of recording the fnirs signal on the prefrontal cortex and its correlation with the fmri-blood-oxygen-level dependent signal obtained during a working memory task.
based on these findings, several fnirs studies have reported that activation of the lpfc can be used as an index of mental workload (ayaz et al., 2012; fishburn et al., 2014).
our results support those findings, as the magnitude of bilateral lpfc activation reflected the mental workload to perform the experimental task under each condition, and, consequently, fnirs would be useful to elucidate the cognitive state of operators who manipulate advanced information systems.
käthner et al.
(2014) demonstrated that mental workload level can be determined from event-related potential signals.
a method to measure mental workload during an actual situation may be possible by combining these neuroimaging techniques.
from the result of correlation analysis, correlation coefficients under each combination of the score and the signal change on the roi did not show the statistical significance.
it is suggested that the signal increase induced by the task execution on each roi had large individual variability within each kind of experimental condition.
the reason is considered that we manipulated the task difficulty and the existence of additional rule as the experimental factors which influences the mental workload to perform the experimental task, and as a consequence, the signal changes associating with the task performance would be reflected by not only the influence of each factor but also the interaction effect of those two factors.
and, it is inferred that a degree of the interaction effect had large individual variability associating with a subjective workload to consider the influence of each factor.
since the subjective workload might be influenced by subjective feeling of time pressure or frequency to change the behavioral choice, the subjective workload would vary with progress of the task.
thus, significant correlations were not observed within each kind of experimental condition.
by contrast, anova for the roi signals and task scores showed significant differences for those factors, and therefore, there was a marked difference of the cognitive load between each experimental condition even though the signal changes of rois included large individual variability.
it is suggested that the differences of signal changes induced by each experimental condition were larger than the fluctuation of signal change caused by individual variability.
taken together with those results, it could be a supporting evidence that our experimental manipulation could successfully act to distinguish each experimental condition in terms of the cognitive load.
some limitations of the present study should be mentioned.
the present results do not include the peripheral cognitive control processes used to perform the experimental task, such as performance monitoring or risk perception, and those processes are mainly associated with the anterior cingulate cortex (botvinick et al., 2004; ridderinkhof et al., 2004) and anterior insula (paulus et al., 2003; tom et al., 2007; rudorf et al., 2012).
because of the characteristics of the experimental task, it was expected that these processes would be involved in task execution.
however, fnirs only measures the surface side of the cerebral cortex, so signal fluctuations deeper in that cortex could not be measured during the experiment.
in conclusion, activity in the left lpfc more closely reflected the increase in cognitive control underlying the behavioral changes needed to cope with the additional rule.
this cognitive control affected the change in lpfc activity independent of the increase in task difficulty.
thus, the present results suggest that fnirs can be used to estimate cognitive processing as a source of mental workload, as well as measure the magnitude of that workload.
author contributions nm designed and conducted the experiments, analyzed data and wrote the manuscript.
ns designed and conducted the experiments.
sk gave technical support and conceptual advice.
all authors discussed the results and commented on the manuscript at all stages.
funding this study was supported by japan society for the promotion of science (jsps) kakenhi (grant no.
24700121).
conflict of interest statement the authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.
@highlight
rules prescribe human behavior and our attempts to choose appropriate behavior under a given rule.
cognitive control, a mechanism to choose and evaluate actions under a rule, is required to determine the appropriate behavior within the limitations of that rule.
consequently, such cognitive control increases mental workload.
however, the workload caused by a cognitive task might be different when an additional rule must be considered in choosing the action.
the present study was a functional near-infrared spectroscopy (fnirs) investigation of an experimental task, in which the difficulty of an operation and existence of an additional rule were manipulated to dissociate the influence of that additional rule on cognitive processing.
twenty healthy japanese volunteers participated.
the participants performed an experimental task, in which the player caught one of five colored balls from the upper part of a computer screen by operating a mouse.
four task conditions were prepared to manipulate the task difficulty, which was defined in terms of operational difficulty.
in turn, operational difficulty was determined by the width of the playable space and the existence of an additional rule, which reduced the score when a red ball was not caught.
the 52-channel fnirs data were collected from the forehead.
two regions of interest (rois) associated with the bilateral lateral prefrontal cortices (lpfcs) were determined, and a three-way repeated-measures analysis of variance (anova) was performed using the task-related signal changes from each roi.
the fnirs results revealed that bilateral lpfcs showed large signal changes with the increase in mental workload.
the anova showed a significant interaction between the existence of an additional rule and the location of the rois; that is, the left lateral prefrontal area showed a significant increase in signal intensity when the additional rule existed, and the participant occasionally decided to avoid catching a ball to successfully catch the red-colored ball.
thus, activation of the left lpfc corresponded more closely to the increase in cognitive control underlying the behavioral change made to cope with the additional rule.
