introduction what was known?
multiple myeloma is a lymphoproliferative disorder which rarely presents with skin involvement.
dermatological presentation is usually a late phenomenon in course of the disease.
although extremely rare, plasmacytoma is the most specific skin finding of multiple myeloma.
cutaneous lesions in multiple myeloma (mm) are uncommon.
[1] cutaneous plasmacytoma is a specific cutaneous finding but is an extremely rare finding and easily diagnosed by histopathology study.
[2] rarely leucocytoclastic vasculitis, urticaria, autoimmune bullous diseases, and pyoderma gangrenosum may be the initial presentation of mm.
this can pose a diagnostic challenge to the physician as the strength of association of these conditions with mm is reportedly low.
[2] we report four such patients who presented with some common skin disorders and later got diagnosed with the disease.
case reports case 1 a 45-year-old female presented with multiple purpuric, ecchymotic lesions over periorbital area, cheeks, front and back of the neck with relative sparing of covered parts for the last 2 years, with a history of minor trauma precipitating these lesions [figure 1a and b].
skin was easily fragile in most areas.
there was a history of multiple episodes of diarrhea and fever in the past 6 months.
general examination showed mild pallor and bilateral pedal edema.
routine investigations are detailed in table 1. skin biopsy finding was suggestive of a bullous lesion with amorphous eosinophilic amyloid deposits [figure 2].
serum protein electrophoresis (spe) and bone marrow aspiration (bma) confirmed it to be a case of mm [figures 3 and 4].
however, radiological evaluations of skeleton were normal.
the patient was referred to the department of clinical hematology where chemotherapy was started.
figure 1 (a and b) multiple purpuric lesion over forehead, face, and “v” area of the neck table 1 laboratory parameters of the patients figure 2 breach of epithelium with subepidermal bullae and amorphous, eosinophilic material deposition in dermis with inflammatory cell infiltrate (h and e, ×10) figure 3 serum electrophoretic pattern of patient showing prominent m-band in gamma light chain region.
the table shows individual fractions figure 4 bone marrow aspiration displaying myeloma cells (leishman stain, 10 × 100) case 2 a 21-year-old female admitted to the medicine ward with fever, severe diarrhea, and lower respiratory tract infection was referred to our department for skin rashes.
on examination, she had multiple palpable painful purpuric lesions mostly on dependent parts which had occurred several times in the past 3 months.
a few of the skin lesions were edematous and some had central necrosis or bullae formations [figure 5].
the picture was clinically suggestive of lcv with urticarial vasculitis.
the biochemical and hematological results are given in table 1. spe and bma again confirmed the diagnosis of mm.
however, the patient died within 1 week of diagnosis.
figure 5 purpuric lesions showing central necrosis and bulla formation over lower third of left leg case 3 a 56-year-old man presented with a nonhealing ulcer on the left leg for 2 months duration which had failed to respond all antibiotics tried in the past.
examination revealed an ulcer filled with pus, exudates, and pale granulation tissues [figure 6].
suspecting possibility of pyoderma gangrenosum, oral prednisolone was started at the dose of 1 mg/kg body weight and gradually tapered over a period of 2 months.
initially, he improved but then showed slow response and new lesions appeared after 1 month.
additional investigations such as spe and bma were done which showed m-band protein and myeloma cells.
figure 6 nonhealing ulcer on the left leg filled with pus and pale granulation tissue case 4 a 32-year-old cachectic male presented with large, painful eroded areas over trunk and extremities, with a history of fluid-filled vesicular lesions preceding the erosions [figure 7a and b].
he had received four doses of monthly dexamethasone, cyclophosphamide along with a diagnosis of pemphigus vulgaris at some other center.
tzanck smear for acantholytic cells and nikolsky sign were positive at few places.
oral mucosa could not be examined due to extensive submucosal fibrosis.
there was tachycardia (110/min), no hepatosplenomegaly or lymphadenopathy.
routine investigations showed low hemoglobin (6.5 g%) and developed pancytopenia on different occasions, thus requiring repeated blood transfusions.
serum ferritin level was highly raised (2029 μg/l) along with serum calcium level (20 mg/ml).
suspecting underlying hematological disorder, bone marrow biopsy was conducted which revealed mm.
figure 7 (a and b) large-eroded skin lesions over back and chest with cachetic body discussion mm is one of the common hematologic malignancies of plasma cell, occurring due to abnormal proliferation of plasma cells and commonly presenting to the physicians with bone pain, anemia, or renal failure.
cutaneous lesions are rare and even unusual during its course.
cutaneous plasmacytoma though specific occurs late in course of the disease presenting as erythematous or violaceous nodules and plaques.
[2] it can present initially with common cutaneous conditions such as lcv, amyloidosis, pyoderma gangrenosum, or vesiculobullous disorder which are very rarely described in literature.
[34] these being common and nonspecific lesions, it is difficult for the dermatologists to suspect mm from initial presentation.
the first case had typical features of systemic amyloidosis such as periorbital ecchymotic lesions (raccoon eye).
this kind of presentation is seen more associated in light chain-associated amyloidosis than aa (serum amyloid a) amyloidosis seen in chronic inflammatory conditions.
[25] there have been case reports of mm which described rare presentation as lcv.
[67] in fact, in a study of 2357 patients with diagnosis of mm, only eight patients were found to have lcv.
[8] it indicates a sign of poor prognosis with short survival rate which happened in our case also.
[9] pyoderma gangrenosum has been considered as a facultative cutaneous paraneoplastic marker[1] although many times it may not have an association with a systemic disease.
in our case, when the disease became resistant to treatment and got aggravated, a diagnosis of mm could be made on further investigations.
similarly, in the fourth case, we suspected a vesiculobullous disorder.
multiple pyoderma lesions over the body, pancytopenia on different occasions, cachectic built, highly raised serum ferritin and calcium values led us to think of some associated diseases and diagnosis of mm was made.
association of bullous disorders with mm has been reported sporadically earlier.
[10] myeloma proteins may have antibodies against basal membrane antigens resulting in bullae formation.
[10] mm is known to have a wide spectrum of presentation ranging from monoclonal gammopathy of unknown significance to total plasma cell leukemia.
[11] mm is rarely suspected from common skin disorders.
unusual presentations and nonresponsiveness to conventional therapy are important clues.
abnormal blood parameters such as low hemoglobin, pancytopenia, altered serum albumin-globulin ratio, raised erythrocyte sedimentation rate, or serum calcium/ferritin levels also gave clues in diagnosis.
declaration of patient consent the authors certify that they have obtained all appropriate patient consent forms.
in the form the patient(s) has/have given his/her/their consent for his/her/their images and other clinical information to be reported in the journal.
the patients understand that their names and initials will not be published and due efforts will be made to conceal their identity, but anonymity cannot be guaranteed.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
what is new?
our case series illustrate that dermatological manifestation may be the presenting feature of multiple myeloma even with minimal systemic manifestations.
the presenting skin lesions are also quite nonspecific and heterogeneous ranging from leukocytoclastic vasculitis, pyoderma gangrenosum, and vesiculobullous disorders.
therefore, high degree of clinical suspicion is required to arrive at an early diagnosis.
@highlight
multiple myeloma (mm) is a proliferative disorder of plasma cells which produce abnormal immunoglobulin proteins.
skin involvement is rarely found in this disorder.
they are either specific or nonspecific lesions.
we report four such interesting patients who presented to us initially with common dermatoses such as leukocytoclastic vasculitis, pyoderma gangrenosum, and vesiculobullous disorders and were subsequently diagnosed to have mm.
there were no skeletal involvements or renal function abnormality at the time of presentation.
unusual presentation, nonresponsiveness to conventional therapy, and abnormal blood parameters prompted us to suspect some underlying systemic conditions which were later confirmed to be mm after serum immunoelectrophoresis for m-band and bone marrow biopsy.
