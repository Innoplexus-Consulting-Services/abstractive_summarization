stroke being leading cause of death, acquired disability in developed and developing countries,[1] with 87% ischemic strokes.
[2] cerebral ischemia is characterized by insufficient blood flow to the brain that leads to cerebral hypoxia and causes an infarction/ischemic stroke.
cells cannot maintain electrochemical gradients leading to massive influx of calcium, excessive release of glutamate from synaptic vesicles, lipolysis, calpain activation, excitotoxicity, and oxidative stress.
the caspase-dependent apoptosis cascade is initiated.
blood-brain barrier disruption occurs and leads to vasogenic edema, a primary cause of stroke-associated mortality.
[3] reperfusion of ischemic tissues is associated with microvascular injury.
activated endothelial cells produce more reactive oxygen species (ros) but less nitric oxide following reperfusion, and the imbalance results in a subsequent inflammatory response.
[4] leukocytes, carried to the area by the newly returning blood, release a host of inflammatory factors such as interleukins as well as free radicals in response to tissue damage.
[5] the restored blood flow reintroduces oxygen within cells that damages cellular proteins, dna, and plasma membrane.
reactive species may act indirectly in redox signaling to turn on apoptosis.
[6] transgenic models with antioxidants overexpressed provided neuroprotection.
[7] flavonoids interfere nitric oxide synthase and xanthine oxidase pathway.
[8] pentapetes phoenicea (l) is an erect, half-woody plant, belonging to the family malvaceae.
[9] it is commonly known as scarlet mallow or midday flower in english.
in india, decoction of leaves was drunk for inflammatory glands.
juice is also applied to inflammatory glands.
[10] it also alleviates psychopathy and central nervous system ailments.
the presence of rutin in the hydroalcoholic extract of p. phoenicea plant was confirmed with the help of high performance thin layer chromatography studies.
[11] in vitro antiradical activity was reported.
[12] therefore, in view of ethnopharmacological facts of the plant, the present study investigated the cerebroprotective activity of methanolic extract (me) of p. phoenicea.
materials and methods chemicals and drugs glutathione (gsh), sodium dodecyl sulfate (sds), acetic acid, thiobarbituric acid (tba), reduced nicotinamide adenine dinucleotide phosphate (nadph), 1-chloro-2,4-dinitrobenzene (cdnb), ethylenediaminetetraacetic acid (edta), and nitroblue tetrazolium chloride were purchased from sigma-aldrich.
animals healthy male wistar rats (300–350 g) were obtained from the national institute of nutrition, hyderabad.
they were randomly housed in polypropylene cages, maintained in 12:12 light:dark cycle, and given access to food and water ad libitum.
the experiments on animals were approved by the institutional animal ethical committee (iaec) under the regulation of cpcsea (iaec approval no.
mrcp/cpcsea/iaec/2012-13/pcol/16).
all surgeries were performed under the thiopental sodium (40 mg/kg) anesthesia to minimize animal suffering.
plant material collection p. phoenicea plants were collected from the forests of tirupati during august 2013, were authenticated, and voucher specimen preserved at herbarium section of the department of botany, sri venkateswara university, tirupati.
plant extraction the air-dried p. phoenicea plants were powdered and successively extracted with petroleum ether, chloroform, and methanol.
petroleum ether and chloroform extracts were discarded.
subsequently, the residue was subjected to soxhlation at 55°c.
rotary vacuum evaporator was used under reduced pressure for complete removal of the solvent.
experimental protocol for global ischemia animals were divided into six groups of 10 rats each.
every group was administered with p. phoenicea me 100, 200, 400 mg/kg or vehicle or edaravone 3 mg/kg for 10 days before the experimentation and treated as follows: group i: normal saline (10 ml/kg), no ischemia induction (control)group ii: normal saline (10 ml/kg), bilateral carotid artery occlusion (bcao) for 30 min, followed by 4 h reperfusion (vehicle/ischemia)group iii: edaravone (3 mg/kg/day), bcao for 30 min and followed by 4 h reperfusion (standard)group iv: methanolic extract of p. phoenicea (me 100 mg/kg/day), bcao for 30 min, followed by 4 h reperfusiongroup v: methanolic extract of p. phoenicea (me 200 mg/kg/day), bcao for 30 min, followed by 4 h reperfusiongroup vi: methanolic extract of p. phoenicea (me 400 mg/kg/day), bcao for 30 min, followed by 4 h reperfusion.
method for global cerebral ischemia induction followed by reperfusion (i/r) before subjecting to bcao, the rats were anesthetized with thiopental sodium (40 mg/kg, i.p.)
and were placed dorsally on a surgical platform; a midline ventral incision was made in the neck region.
the trachea of the animal was exposed; following this, each of the common carotid arteries were located separately step-by-step.
the carotid artery was exposed after careful separation from the adjacent vagus nerve, with special attention.
a cotton thread was passed below the each carotid artery and a surgical knot put on both arteries for 30 min ischemia induction.
after 30 min of global ischemia, the thread was removed to allow reflow of blood through carotid arteries (reperfusion) for 4 h. the body temperature of rats was maintained around 37°c ± 5°c throughout the surgical procedure by heated surgical platform.
control animals received the same surgical procedure except bcao.
after completion of reperfusion period, the brains were excised under anesthesia for determination of brain weight biochemical parameters, histopathology, and assessment of cerebral infarct size.
preparation of postmitochondrial supernatant after bcao and reperfusion, the animals were sacrificed immediately by decapitation, brains were isolated, washed in precooled 0.9% saline and frozen at −20°c for 15 min, then subsequently blotted on filter paper, weighed, and homogenized in chilled sodium phosphate buffer (0.1 m, ph 7.4) using a remi tissue homogenizer.
homogenate was centrifuged at 10,000 rpm for 20 min at 4°c, and postmitochondrial supernatant (pms) obtained from 10% (w/v) brain tissue was stored at −10°c for further estimations.
biochemical estimations malondialdehyde to 0.2 ml of pms, freshly prepared solutions of 0.2 ml of 8.1% sds, 1.5 ml of 20% acetic acid (ph 3.5), and 1.5 ml of aqueous solution of 0.8% tba were added, and volume was made up to 4 ml with double distilled water.
then, the mixture was heated at 95°c for 60 min in a water bath on a hot plate to develop light pink color.
the mixture was allowed to cool and 5 ml of the mixture of n-butanol and pyridine (15:1 v/v) was added and vigorously shaken.
the absorbance measured spectrophotometrically at 532 nm using ultraviolet (uv)–visible spectrophotometer and the malondialdehyde (mda) content was measured from the standard graph of mda and was expressed as nmol/g wet tissue.
catalase catalase (cat) activity in tissue was determined by measuring the rate of decomposition of hydrogen peroxide (h2o2) at 240 nm, according to the method given below.
to 50 µl of pms, 1.95 ml phosphate buffer (50 mm, ph 7) and 1 ml of h2o2 (30 mm) were added to prepare the reaction mixture.
changes in absorbance were recorded at 240 nm for 1 min at 15 s interval by uv–visible spectrophotometer, and then, the activity was calculated in terms of k/min.
reduced glutathione a standard graph of reduced gsh was prepared.
to 2 ml of 0.1 m potassium phosphate buffer ph 8.4, 0.1 ml of standard or experimental sample, 0.5 ml of 5,5-dithiobisnitrobenzoic acid (dtnb) was added, and the volume was made up to 3 ml with double distilled water.
then, the mixture was incubated for 10 min at room temperature and the absorbance was measured at 412 nm in uv–visible spectrophotometer and gsh content was calculated from the standard graph.
glutathione reductase glutathione reductase (gr) activity in the tissue was determined by measuring the decrease in the absorbance caused by oxidation of nadph at 340 nm.
to 350 µl of potassium phosphate buffer (100 mm, ph 7.5), 50 µl of nadph, 500 µl of oxidized gsh, and 100 µl of the pms were added, and the volume was made up to 1 ml with distilled water.
the enzyme activity was calculated as nm nadph oxidized/min/mg protein using molar extinction coefficient of 6.22 × 103 m−1 cm−1.
glutathione peroxidase total glutathione peroxidase (gpx) was determined by measuring the rate of oxidation of gsh at 420 nm.
the reaction mixture consisted of 0.02 ml of 0.8 mm edta, 0.1 ml of 10 mm sodium azide, 0.1 ml of 2.5 mm h2o2, 0.2 ml of homogenate and was arrested by adding 0.5 ml of 10% of trichloroacetic acid, and the tubes were centrifuged at 2000 rpm for 15 min.
three milliliters of 0.3 mm of disodium hydrogen phosphate and 1 ml of 0.04% dtnb were added to the supernatant and developed color was detected at 420 nm immediately.
gpx activity was expressed as µ mole of the oxidized gsh/min/mg protein.
glutathione-s-transferase glutathione-s-transferase (gst) activity was measured.
the reaction mixture consisted of 1.425 ml phosphate buffer (0.1 m, ph 6.5), 0.2 ml reduced gsh (1 mm), 0.025 ml cdnb (1 mm), and 0.3 ml pms (1 0%, w/v) in a total volume of 2.0 ml.
the changes in absorbance were recorded at 340 nm, and the enzyme activity was calculated as nm cdnb conjugate formed/min/mg protein.
superoxide dismutase aliquot of supernatant 0.1 ml was added to 1.2 ml of 0.052 m sodium pyrophosphate buffer (ph 8.3), followed by addition of 0.1 ml of 186 μm phenazonium methosulfate, 0.3 ml of 300 μm nitroblue tetrazolium, 0.2 ml of 780 μm nadh.
the reaction mixture was incubated for 90 s at 30°c, and the reaction was stopped by the addition of 0.1 ml of glacial acetic acid.
the reaction mixture was stirred vigorously and shaken with 4.0 ml of n-butanol and centrifuged at 4000 rpm for 10 min.
the absorbance of the organic layer was measured at 560 nm.
control was prepared using 0.1 ml of distilled water devoid of 0.1 ml of homogenate.
one unit of the enzyme activity is defined as enzyme concentration required inhibiting the absorbance of chromogen production by 50% in control sample under the assay conditions.
hydrogen peroxide a volume of 0.2 ml pms was added to 0.5 ml of 10 mm potassium phosphate buffer (ph 7.0) and 1.0 ml of 1 m of potassium iodide.
the absorbance of the reaction mixture was measured at 390 nm.
the rate of h2o2 production was calculated using a standard graph of h2o2 and expressed as m h2o2/g tissue.
protein concentration protein concentration in all pms (10% w/v) samples was determined by the method of lowry et al.
using span diagnostic kit.
500 µl of working reagent and 10 ml of tissue homogenate sample (10% w/v) or standard sample were pipetted into tubes marked with test and standard.
the color formed is proportional to the protein concentration and was measured at 520–560 nm within 60 min against reagent blank and protein present in the sample.
preparation of sodium dodecyl sulfate-polyacrylamide gel electrophoresis total protein sample of pms (10% w/v) was resolved by sds-polyacrylamide gel electrophoresis.
the pms of total protein sample (30 µg) was applied per lane.
the electrophoresis was carried out in 1 × electrophoresis buffer (tris-hcl buffer [25 mm, ph 8.0], glycine [250 mm], and sds [0.1% w/v]) at 100 v at room temperature until the bromophenol blue dye front ran out of the gel.
the gels were stained with coomassie brilliant blue (0.25% w/v) r-250 in methanol (45% v/v), acetic acid (10% v/v) and subsequently destined in methanol (45% v/v), acetic acid (10% v/v).
brain weight and water content this was done by the method of fotheringham et al.
this is another study, involving the same protocol and treatments.
treatment was given to six groups of six animals each, and after bcao for 30 min and followed by 4 h reperfusion, brains were removed and immediately weighed in preweighed glass vials and wet weights were recorded.
the brains were dried to constant weight and the dry weight was recorded.
the percentage water content of each brain was calculated.
assessment of cerebral infarct volume a similar protocol was used for the assessment of cerebral infarct size.
the rats were sacrificed by cervical dislocation and the brains isolated, were stored for 2 h at −20°c.
each frozen brain was sliced into coronal sections as shown in figure 1. the slices were incubated in 2% triphenyl tetrazolium chloride (ttc) at 37°c for 30 min and placed in phosphate-buffered saline (ph 7.4) to estimate cerebral infarct size.
infarcted volume was calculated using the image-j software, developed at national institute of mental health, bethesda, maryland, usa.
figure 1 effect of pentapetes phoenicea on infarct volume in cerebral ischemia/reperfusion induced rats.
(a) sham control group; (b) vehicle + ischemia; (c) edaravone (3 mg/kg, i.p.)
+ ischemia; (d) pentapetes phoenicea methanolic extract (100 mg/kg, p.o.)
+ ischemia; (e) pentapetes phoenicea methanolic extract (200 mg/kg, p.o.)
+ ischemia; (f) pentapetes phoenicea methanolic extract (400 mg/kg, p.o.)
+ ischemia histopathology examinations brains of all the groups were isolated and fixed with 10% buffered formalin phosphate.
coronal brain sections from control and experimental groups of global ischemia were made, rinsed with cold normal saline, and were fixed with a mixture of formaldehyde (40%), glacial acetic acid, and methanol (1:1:8, v/v).
brain slices cut into 4–5 mm thickness and embedded in paraffin blocks.
brain sections of 4–6 μm thickness were cut and stained with hematoxylin and eosin.
statistical analysis cerebroprotective activity results were presented as mean ± standard error of the mean.
the statistical difference in mean values between various groups for different parameters was determined using one-way analysis of variance, followed by bartlett's test.
the diagrammatic representation and statistical analysis of the data were performed using graphpad prism version 6.0. by graphpad software, inc., california, usa.
results effect of pentapetes phoenicea on biochemical analysis the biochemical results are presented in tables 1 and 2. the results confirmed that the cerebral ischemia and reperfusion significantly decreased antioxidative activities (cat, gsh, gr, gpx, gst, and superoxide dismutase [sod]) and increased the level of lipid peroxidation (mda) and h2o2 in the injured brain tissue of rats as compared with the control group.
however, the pretreatment of rats with p. phoenicea (me 200 and 400 mg/kg) markedly increased cat, gsh, gr, gpx, gst, and sod activity.
in contrast, mda and h2o2 content in the injured brain tissue of rats decreased significantly in a dose-dependent manner in p. phoenicea extract-treated groups compared to ischemic group.
the p. phoenicea extract-treated groups exhibited dose-dependent activity with better activity elicited by me 400 mg/kg treated groups.
table 1 effect of pentapetes phoenicea on antioxidant parameters table 2 effect of pentapetes phoenicea on antioxidant parameters protein content estimation by gel electrophoresis the protein content of the tissue samples was assessed by gel electrophoresis and the results presented in figure 2 indicated that the me (200, 400 mg/kg) and edaravone-treated groups had high protein content when compared with ischemic group.
figure 2 effect of pentapetes phoenicea on protein content in cerebral ischemia/reperfusion-induced rats.
(a) sham control group; (b) vehicle + ischemia; (c) edaravone (3 mg/kg, i.p.)
+ ischemia; (d) pentapetes phoenicea methanolic extract (100 mg/kg, p.o.)
+ ischemia; (e) pentapetes phoenicea methanolic extract (200 mg/kg, p.o.)
+ ischemia; (f) pentapetes phoenicea methanolic extract (400 mg/kg, p.o.)
+ ischemia effect of pentapetes phoenicea on brain weight and water content the content of cerebral water (edema) was increased significantly in the ischemic group.
pretreatment with p. phoenicea (me 200, 400 mg/kg) produced significant reduction (p < 0.01) in water content and more than two-fold decrease in the water content was observed in treated rat as compared to ischemic group [table 3].
however, there was a significant decrease of brain weight observed in treated groups.
table 3 effect of pentapetes phoenicea on brain weight, water content, infarct volume, and protein content effect of pentapetes phoenicea on cerebral infarct volume these results [table 3] were also in support to biochemical estimations with a significant reduction in cerebral infarct size in p. phoenicea me-treated groups as compared with ischemic group.
effect of pentapetes phoenicea on histopathology the histopathology of the brains is presented in figure 3. the tissue exhibited swollen and demyelinated neurons, meningeal hemorrhage, degeneration in cerebral hemispheres occurred in regions of i/r rats of ischemic group.
there were no apparent morphological changes in control with brain sections showing normal cerebral hemisphere.
brain sections of p. phoenicea (me 100, 200 and 400 mg/kg) treated groups significantly prevented the neuronal loss when compared with ischemic group.
figure 3 effect of pentapetes phoenicea on histopathological changes in cerebral ischemia/reperfusion-induced rats.
(a) sham control group; (b) vehicle + ischemia; (c) edaravone (3 mg/kg, i.p.)
+ ischemia; (d) pentapetes phoenicea methanolic extract (100 mg/kg, p.o.)
+ ischemia; (e) pentapetes phoenicea methanolic extract (200 mg/kg, p.o.)
+ ischemia; (f) pentapetes phoenicea methanolic extract (400 mg/kg, p.o.)
+ ischemia discussion the study revealed the cerebroprotective effect, demonstrated the attenuation of brain damage and reduction of the oxidative stress in i/r-induced rats by p. phoenicea pretreatment.
the common carotid artery is the main artery supplying blood from heart to brain, and bcao is the basic experimental model for global cerebral ischemia induction in rats.
occlusion of both the carotid arteries for 30 min leads to reduction in blood supply to the brain and reperfusion aggravates the neuronal damage initiated by ischemia.
[12] reperfusion of ischemic tissues is often associated with microvascular dysfunction that is manifested as impaired endothelium-dependent dilation in arterioles, enhanced fluid filtration and leukocyte plugging in capillaries, and the trafficking of leukocytes and plasma protein extravasation in postcapillary venules.
activated endothelial cells in all segments of the microcirculation produce more oxygen radicals.
[10] it was observed that pretreatment with p. phoenicea attenuated the neuronal damage and oxidative stress.
it restored the altered antioxidant enzymes and also reduced the mda and h2o2 production induced by bcao.
oxidative stress is one of the important factors that exacerbate the brain damage induced by cerebral ischemia.
[13] the presence of many antioxidant enzymes such as cat, gpx, gr, and gst in the brain prevents these tissues from the oxidative damage by free radical formation.
[14] among various brain regions, some are more susceptible to brain ischemia due to the high rate of oxidative metabolic activity, intense production of reactive oxygen metabolites, high content of polyunsaturated fatty acids, relatively low antioxidant capacity, low repair mechanism activity, and poor plasticity in that areas.
[15] the pathophysiology of brain injury includes abrupt neuronal depolarization,[16] release of excitatory neurotransmitters, ionic shifts, changes in glucose metabolism, altered cerebral blood flow, and impaired axonal function.
the changes are well understood in experimental models.
the neurotoxic pathway in the pathophysiology of stroke alters the antioxidant enzyme levels[17] such as sod, cat, gpx, gr, gst, gsh, and mda, protein content.
the endogenous antioxidant enzyme activity of the brain impaired by i/r is particularly important, and measurement of those antioxidant enzymes after reperfusion can assess the vulnerability of the particular areas of the brain.
this study reveals that the production of mda was elevated significantly in ischemic brain regions of the rats after 4 h of reperfusion period.
the results demonstrated that mda level was markedly reduced with pretreatment of p. phoenicea and inhibited the neuronal damage from propagating lipid peroxidation as a chain reaction.
peroxidation of lipid bi-layer was reported after cerebral i/r injury.
[18] h2o2 is an electrically neutral long lasting reactive species which can pass through cell membranes and is reported to be more stable than superoxide anion, hydroxyl free radical, and other ros.
accumulation of h2o2 impairs the mitochondrial function.
therefore, h2o2 may persist for a longer time after reperfusion to produce neuronal injury.
p. phoenicea pretreatment restored the level of h2o2 in i/r rat's brain to near normal levels.
this may lead to increase in endogenous antioxidant enzymes and prevents the neuronal injury.
cat is frequently used by cells to rapidly catalyze the decomposition of h2o2 into less-reactive gaseous oxygen and water molecules.
superoxide is one of the main ros in the cell.
as a consequence, sod serves a key antioxidant role.
the physiological importance of sods is illustrated by the severe pathologies evident in mice genetically engineered to lack these enzymes.
mice lacking sod2 gene die several days after birth, amid massive oxidative stress.
[19] in this study, reduction in sod, cat activity was significantly prevented by p. phoenicea administration.
in cells, gsh is maintained in the reduced form by the enzyme gr and in turn reduces other metabolites and enzyme systems, such as ascorbate in the gsh-ascorbate cycle, gpxs, and glutaredoxins as well as reacting directly with oxidants produced by h2o2.
due to its high concentration and its central role in maintaining the cell's redox state, gsh is one of the most important cellular antioxidants.
[20] the activity of gr is used as an indicator for oxidative stress.
in i/r control group, the level of gr was significantly reduced.
the biochemical function of gpx is to reduce lipid hydroperoxides to their corresponding alcohols and to reduce free h2o2 to water.
dysfunction of gpx may result in loss of protective activity exerted by these enzymes and manifested as increased infarction in many studies.
[21] gsts, previously known as ligandins, are best known for their ability to catalyze the conjugation of the reduced form of gsh to xenobiotic substrates for the purpose of detoxification.
omega-class gst (gsto) genes, in particular, are associated with neurological diseases such as alzheimer's, parkinson's and amyotrophic lateral sclerosis; again, oxidative stress is believed to be the culprit, with decreased gsto gene expression resulting in a lowered age of onset for the diseases.
[22] in this study, p. phoenicea pretreatment significantly prevented the reduction in gpx, gr, and gst activities.
brain edema in ischemia has also been an important parameter to assess the impact on brain damage.
cerebral edema occurs as a result of ionic imbalance resulting in the osmotic pressure difference across the cellular membrane.
pathophysiology of edema is that neuronal depolarization due to energy failure, with activation of glutamate receptors, which alters ionic gradients of na+, ca2+, cl−, and k+.
as glutamate increases in the extracellular space, peri-infarct depolarization occurs.
then, as water shifts occur, cells swell resulting cerebral edema.
p. phoenicea reversed the effects on brain water content in the ischemia-reperfusion groups as compared to the ischemic group.
histopathology of brain sections also supports that p. phoenicea could exert neuroprotection on brain subjected to i/r injury.
ttc stains the viable cells of tissue into deep red color whereas the ischemic portion of the tissue with damaged mitochondria remains unstained.
the obtained compilation of results indicates that p. phoenicea is effective against stroke-related brain damage in rats and the activity can be implicated to high levels of flavonoid and phenolic content of the plant.
conclusion methanolic extract of p. phoenicea could supress neuronal loss of the ischemic brain tissue and it also elicited antioxidant activity in reperfusion induced oxidative stress.
the result of the study indicates that pretreatment with p. phoenicea enhances the antioxidant defense against bcao-induced global cerebral ischemia/reperfusion and exerts cerebroprotection.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
objectives: the study was performed to evaluate the cerebroprotective activity of methanolic extract (me) of pentapetes phoenicea - a folk medicine used as anti-inflammatory and in central nervous system ailments.
it has high phenolic and flavonoid contents including rutin.
materials and methods: global cerebral ischemia was induced in male albino wistar rats by temporary bilateral carotid artery occlusion (bcao) for 30 min, followed by 4 h reperfusion.
groups of rats were pretreated for 10 days with 100, 200, and 400 mg/kg of me of p. phoenicea and 3 mg/kg of edaravone, a marketed cerebroprotective agent, as standard.
antioxidant enzymes such as, the levels of malondialdehyde (mda), glutathione peroxidase (gpx), glutathione reductase (gr), glutathione-s-transferase (gst), superoxide dismutase (sod), catalase (cat) and hydrogen peroxide (h2o2), protein content, brain water content, cerebral infarct size and the histopathological changes were measured.
results: p. phoenicea-pretreated groups restored the biochemical parameters significantly in a dose-dependent manner.
the ischemic changes were involved with an increase in the concentration of mda and h2o2, followed by decreased sod, cat, gpx, gr, and gst activity in rat brain.
the neurodegenaration and its attenuation by p. phoenicea were confirmed by examination of triphenyl tetrazolium chloride staining and histopathological changes in the cerebral ischemic rat brains.
similarly, p. phoenicea reversed the brain water content in the ischemia-reperfusion animals.
conclusion: the result of the study indicates that the treatment with p. phoenicea enhances the antioxidant defense against bcao-induced global cerebral ischemia/reperfusion and exerts cerebroprotection.
