introduction dens invaginatus is an anatomic variation that has been described as a “tooth within a tooth” because it is a developmental defect resulting from the involution of the crown before calcification has occurred.
dens invaginatus is observed primarily in maxillary lateral incisors, and the prevalence ranges between 0.3% and 10%.
[1] dens invaginatus is challenging to treat because of the complex root canal system.
the most commonly used classification of invaginated teeth was published by oehlers in 1957.
[2] several treatments have been suggested in literature, including endodontic treatment of the invagination alone or along with the main canal, surgical treatment, or removal of the entire tooth.
[3456789101112] cone-beam computed tomography (cbct) is a three-dimensional (3d) radiographic technique that is useful for various endodontic applications, such as the diagnosis and treatment of teeth with complex or abnormal root canal anatomy.
[91314] the aim of this case report is to describe how cbct was used for diagnosing, treatment planning, and successfully managing a complex dens invaginatus case with endodontic therapy.
case report a 22-year-old male was referred by his dentist to the department of endodontics at the oral maxillofacial medical center in tel hashomer due to the abnormal anatomy of tooth 12. the patient reported a history of frequent episodes of pain (at the time, he was unable to chew or bite food, and the tooth was tender when touched).
the oral examination and the evaluation of the patient's periodontal status revealed a good oral hygiene.
a composite filling was detected on the palatal aspect of the crown and an orthodontic splint retained teeth 13–23 [figure 1].
periodontal probing revealed pocket depths of less than 3 mm, and there was no excess mobility of the tooth.
the tooth was sensitive to percussion and palpation and did not respond to a cold thermal test (endo ice, coltene whaldent inc.; cuyahoga falls, oh, usa).
the adjacent teeth responded positively to a cold test, and there was no excess mobility or sensitivity to palpation or percussion.
figure 1 tooth 12-preoperative periapical radiograph radiographic examination revealed that tooth 12 presented with dens invaginatus and had an associated apical radiolucency extending from the distal aspect of tooth 12 to the mesial aspect of tooth 13. the size of the radiolucency was over 20 mm, and the apical border was not visible on the film [figure 1].
due to the irregular anatomy of the tooth, the patient was referred for a cbct examination to visualize the exact morphology of the tooth and to clarify the size and the exact borders of the radiolucent area.
cross-sectional and longitudinal cbct (carestream 9300, france) slices revealed that the invagination extended along the entire root length.
the invagination was embedded into the mesial wall of the root canal on the coronal third, and the main canal partly surrounded the invagination in a c-shaped form.
in the middle third, the invagination was detached from the root dentin, and the main canal surrounded the invagination.
in the apical third, two separate canals were observed [figure 2].
figure 2 cone-beam computed tomography.
sagittal and coronal sections: (a) coronal third, (b) middle third, and (c) apical third the 3d lesion size was 9.73 mm × 9.49 mm × 13.9 mm [figure 3].
the lesion bordered the floor of the nasal cavity and the mesial aspect of tooth 13, and the lesion penetrated into the cortical plates of the palatal and buccal bone.
figure 3 cone-beam computed tomography for 3-dimentional measurement of the lesion based on the clinical and radiographic examination, the following diagnosis was made: pulpal necrosis, symptomatic apical periodontitis, and dens invaginatus type 3.
[2] during the first appointment, the tooth was isolated with a rubber dam, and a lingual access cavity was prepared under a surgical operating microscope (carl zeiss surgical gmbh, oberkochen, germany) based on the cbct evaluation as a guide.
the first step was to gain access to the location of the invagination by carefully cleaning the lingual pit [figure 4a].
the second step was to enter the main c-shaped canal with a buccodistal angular approach [figure 4b].
necrotic tissue was detected in both the invaginated canal and the main canal.
the working length was predetermined by cbct[15] and confirmed with an electronic apex locator (dentaport zx, morita, tokyo, japan) and a radiograph [figure 5].
figure 4 clinical photographs and cone-beam computed tomography sagittal sections: (a) access to dens, (b) main c-shaped canal figure 5 working length determination: (a) periapical radiograph, (b) preliminary cone-beam computed tomography examination biomechanical preparation of the narrow, invaginated canal was performed with nickel-titanium (niti) rotary instruments, g-files (g1, g2, micro-mega, besançon, france), revo-s files (micro-mega, besançon, france), and irrigated with 3% sodium hypochlorite (naocl).
the main c-shaped canal was prepared with a self-adjusting file (saf) 1.5-mm file (redent-nova, ra'anana, israel) and irrigated with 3% naocl using the special vatea irrigation pump (redent-nova, ra'anana, israel) with an irrigant flow of 4 ml/min.
[16] final irrigation was performed with 17% ethylene diamine tetra-acetic acid (edta) and a creamy, aqueous calcium hydroxide dressing was placed in the canals with a spiral lentulo.
the access cavity was temporized with cavit (espe, seefeld, germany) and irm (caulk, detrey dentsply, saint-quentin-yvelines, france).
at the second appointment (2 weeks later), clinical symptoms had disappeared.
after removing the calcium hydroxide with copious irrigation of naocl using the saf,[17] final irrigation with 17% edta was performed.
both canals were dried and obturated with a combination technique: cold lateral compaction of gutta-percha in the apical third using niti finger spreaders (dentsply maillefer, ballaigues, switzerland) and warm compaction in the middle and coronal thirds with b&;l alpha (b&l biotech, gunpo, korea) and machtou pluggers (dentsply maillefer, ballaigues, switzerland).
ah plus (dentsply maillefer, ballaigues, switzerland) was used as a sealer.
the access cavity was temporized with the equia glass ionomer (gc america, alsip, il., usa) [figure 6a].
figure 6 (a) postoperative clinical photograph and periapical radiograph, (b) 24-month follow-up a follow-up examination at 24 months revealed that the tooth was clinically asymptomatic, lacked tenderness to percussion and palpation, had normal mobility, and lacked deep pockets on probing.
radiographic examination revealed a reduction in the size of the lesion [figure 6b].
discussion dens invaginatus is challenging to treat because of the complex root canal system.
dens invaginatus creates abnormal anatomy in a tooth and primarily occurs in lateral maxillary incisors and occasionally in premolars.
[1819] treatment options for dens invaginatus include prophylactic treatments, endodontic treatment of the invaginated canal alone or along with the main canal, surgical treatment, or removal of the entire tooth.
[3456789101112] cbct enables a 3d evaluation of teeth with complex or abnormal root canal anatomy.
[91314] visualizing the exact anatomy of the root canal can influence treatment decisions and lead to more appropriate treatment plans.
follow-up examinations do not include cbct because of the as low as reasonably achievable principle.
in this case report, cbct enabled a 3d visualization of the abnormal anatomy and showed that the invagination occupied most of the canal.
in the coronal third of the canal, the invagination was embedded into the mesial wall, while in the middle third, the invagination was detached from the root dentin and the main canal surrounded the entire invagination.
therefore, complete removal of the invagination was impossible.
moreover, removal of the invaginated portion might have biomechanical consequences, such as weakening the tooth structure because of the loss of healthy dentin.
[2021] the main canal of the tooth and the canal created by the invagination followed the entire length and varied in their cross-sectional outlines: the main canal was c-shaped and the invagination created a narrow, round canal.
after reviewing all of the findings, we elected to perform conservative, orthograde endodontic therapy in both the invaginated portion and the main c-shaped canal with different instrumentation: the saf for the c-shaped canal[16] and niti rotary instruments for the narrow, round pseudocanal.
the subsequent warm compaction technique forced the obturation material into the area surrounding the invaginated portion in the middle third of the main canal, which was observed in the final radiograph.
our assumption was that the necrotic tissue in this area was dissolved by the synergistic effect of naocl with the saf, followed by a calcium hydroxide dressing.
[2223242526272829] conclusion this report describes the management of dens invaginatus type 3 with a 3d cbct evaluation to guide the treatment planning and clinical decision-making process for this complex, anatomical variation.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
dens invaginatus is a rare anatomic variation that is found primarily in maxillary lateral incisors.
the management of dens invaginatus is challenging for clinicians; diagnosing the type of malformation, choosing the most appropriate treatment, and carrying out treatment are complicated by the intricate root system of these teeth.
the following case report describes the diagnosis and treatment planning of dens invaginatus type 3 after cone-beam computed tomography evaluation.
