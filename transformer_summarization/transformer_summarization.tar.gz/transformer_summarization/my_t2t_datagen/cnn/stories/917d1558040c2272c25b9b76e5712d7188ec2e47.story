introduction toxic shock syndrome (tss) is an acute, systemic, toxin-mediated illness that typically results in shock and multi-organ failure (1).
it is usually caused by toxin-producing strains of staphylococcus aureus.
in the early 1980s, the use of highly absorbent tampons was associated with the occurrence of tss.
from 1990s, the incidence of menstrual tss has decreased, while that of nonmenstrual tss has increased (2).
streptococcal toxic shock syndrome (stss) due to streptococcus pyogenes was first described by bohach et al.
in 1990 (3).
group b streptococcus (gbs; streptococcus agalactiae) is a major pathogen of neonatal sepsis and meningitis.
it is also an important pathogen of invasive bacterial infections in nonpregnant adults (4).
a denmark surveillance study reported that gbs-related stss comprised about 9% of all cases caused by streptococcus (5).
recurrent menstrual tss is a well-described phenomenon caused by persistent colonization with a toxigenic s. aureus strain and persistent neutralizing antibodies.
however, recurrent nonmenstrual tss is rare for reasons that have yet to be elucidated (6).
no report has described recurrent stss due to s. agalactiae.
tumor necrosis factor-α (tnf-α) inhibitors can lead to lower respiratory infections, skin/soft tissue infections, and sepsis (7).
however, to the best of our knowledge, there has been no report of recurrent tss or stss caused by tnf-α inhibitors.
we herein report a case of recurrent tss possibly caused by s. agalactiae triggered by tnf-α inhibitors.
case report a 45-year-old woman who had cutaneous symptoms of severe pustular psoriasis for more than 30 years was first induced with infliximab (ifx) in march 2012, and received three doses.
following induction, her skin condition dramatically improved.
however, she visited the general hospital for a high fever and frequent watery diarrhea on june 2012. she was in shock and an oliguric state and was referred to our hospital.
her body temperature, blood pressure, heart rate, and oxygen saturation were 38.9°c, 77/51 mmhg, 118 bpm, and 98% on room air, respectively.
scales due to psoriasis and diffuse macular erythroderma were observed.
however, the site of cutaneous infection was not observed.
laboratory tests showed an elevated white blood cell count (20,900/mm3) and c-reactive protein (crp) (18.64 mg/dl), procalcitonin (12.88 ng/ml), and serum creatinine (2.39 mg/dl) levels.
no white blood cells or bacteria were observed in urine sediments.
chest and abdominal computed tomography found no focus of infection.
blood, urine, and vaginal secretion cultures were negative.
a nasal swab culture revealed methicillin-resistant s. aureus; however, it was negative for tss-1 toxin production.
we suspected septic shock of unknown origin and tss since the case met the criteria of tss, although the patient did not have a history of tampon use.
after the administration of 1,200 mg/day linezolid (lzd), 1,800 mg/day clindamycin (cldm), 13.5 g/day piperacillin/tazobactam (pipc/taz), and γ-globulin agents, her high fever, vital signs, and laboratory findings gradually improved.
the clinical course during her first admission is shown in fig.
1. the patient completely recovered and was discharged after three weeks of lzd administration.
because ifx was discontinued due to this episode, her psoriasis gradually deteriorated to a severe condition.
the patient strongly desired to restart ifx treatment and was made aware of the risk of infectious diseases as a complication.
ifx treatment once monthly with informed consent was restarted four months after the first episode and was administered three times, with an improvement of her psoriasis.
one month after the last ifx dose, the patient again had severe diarrhea and a high fever, was admitted to the nearest general hospital, and recovered with treatment that was similar to the first episode.
she had diarrhea, a high fever, and erythroderma indicative of shock five weeks after the second episode and was admitted to our hospital.
although no organisms were detected in the first and second episodes, s. agalactiae were detected in the blood, urine, and vaginal secretion cultures in the third episode.
drug sensitivity test results were the same for all samples, and all isolated strains were serotype type vi.
during the third admission, empiric therapy with lzd, pipc/taz, and cldm were started and de-escalated to pipc/taz and cldm after detection of the causative bacteria.
the clinical course including the psoriasis area severity index (8) of this case is summarized in fig.
2; the severity of her psoriasis and menstruation cycles did not appear to be related to these infectious episodes.
after the cessation of ifx-containing tnf-α inhibitor treatment, she has not developed either tss or stss for more than two years.
figure 1. clinical course at the first admission.
pipc/taz: piperacillin/tazobactam, cldm: clindamycin, lzd: linezolid, pct: procalcitonin figure 2. clinical course of the present case.
small arrows indicate ifx administration; large arrows indicate toxic shock syndrome episodes.
ifx: infliximab, stss: streptococcal toxic shock syndrome, pasi: psoriasis area severity index, pct: procalcitonin discussion in the present case, we could detect gbs only in the third episode.
however, we estimated that all episodes were caused by gbs, as they indicated similar clinical courses.
stss due to s. agalactiae is rare infectious disease; a total of 40 gbs-stss cases have been reported to date (9-22).
among these previous cases, 17 were men and 23 were women.
of 29 cases with available data, 22 (75.9%) were complicated with soft tissue infection, mostly necrotizing fasciitis.
the mortality rates for these infections are high at 48.6% (18/37), which is much higher than that of tss (23).
the underlying disease and risk factors are summarized in table.
the most common underlying disease was diabetes mellitus (eight cases), followed by liver cirrhosis (seven cases); only three cases were healthy (one man and two women), but two cases reported using tampons.
however, there have been no reported cases associated with the administration of tnf-α inhibitor therapy.
s. agalactiae serotypes were available in 28 of 40 cases, serotype ia, ib, ii, iii, v, vi, and vii comprised 3, 10, 2, 4, 3, 5, and 1 case, respectively.
serotype ib is the most commonly reported serotype.
a united states survey of invasive gbs disease in nonpregnant adults reported the main serotypes to be v (29.2%) and ia (24.3%), while vi was rare (0.1%) (4).
in contrast, lachenauer et al.
reported that serotypes vi (24.7%) and viii (35.6%) were predominant among gbs isolated from pregnant japanese women (24).
thus, some region or racial differences might exist.
in our case, gbs serotype vi was identified in the vaginal secretion, urine, and blood cultures in the third episode.
the reason why we could not detect the causative bacteria in the first and second episodes might be that the vaginal and urine cultures were performed after the initiation of empiric antibiotics treatments.
one possible reason for her onset is that gbs which colonized in the vagina caused sepsis through the urinary tract infection triggered by the tnf-α inhibitor, and finally resulted in stss.
table.
underlying diseases or risk factors of streptococcal toxic shock syndrome cases due to streptococcus agalactiae.
underlying diseases (risk factor) cases diabetes mellitus 8 liver cirrhosis 7 healthy (tampon usage 2) 3 splenectomy 3 cancer 2 cardiac disease 2 chronic lymphocytic leukemia 1 peripheral vascular disease 1 viral hepatitis type c 1 behcet’s disease 1 alcholic hapatopathy 1 rheumatism 1 renal disease 1 dementia 1 cholecystectomy 1 sarcoidosis 1 psoriasis with tnf-α inhibitor use (present case) 1 unknown 11 with respect to the relationship between psoriasis and tss or stss, balci et al.
reported higher s. aureus cultivation rates from skin lesions and higher superantigen production rates in patients with psoriasis compared with healthy controls (25).
furthermore, a recent study demonstrated significantly lower proliferation and secretion levels of cytokines il-2 and il-10 from regulatory t cells in response to streptococcal superantigen (strep-a) in patients with psoriasis compared with healthy controls (26).
these findings might be related to tss or stss development in patients with psoriasis, although there is no report regarding s. agalactiae superantigen and psoriasis.
however, the present patient did not have any skin infection focus at the time of each onset.
the adverse events of tnf-α inhibitor therapy include serious infections.
sepsis cases were observed in 0.3-1% of cases (7,27,28).
however, to the best of our knowledge, there are only 4 previous reports of tnf-α inhibitor-related stss (29-32).
all patients received etanercept in combination with prednisolone or methotrexate and developed necrotizing fasciitis with stss due to s. pyogenes (29-32).
although this is an extremely rare case of possible recurrent stss due to s. agalactiae infection triggered by anti-tnf-α inhibitor therapy, this report is informative for dermatologists or infectious disease specialists.
clinicians should therefore avoid restarting biological agents in patients who have a history of tss or stss.
the authors state that they have no conflict of interest (coi).
@highlight
streptococcal toxic shock syndrome caused by group b streptococcus (gbs) is a rare, but lethal disease.
we experienced a 45-year-old woman with pustular psoriasis who developed toxic shock-like syndrome during infliximab treatment.
surprisingly, similar episodes recurred three times in one year with restarting of infliximab treatments.
in the third episode, gbs were detected in blood, urine, and vaginal secretion cultures.
these episodes of shock syndrome were possibly due to gbs.
to the best of our knowledge, this is the first case report of recurrent streptococcal toxic shock syndrome possibly caused by gbs which was induced by anti-tnf-α inhibitor therapy.
the restarting of biological agents in patients with a history of toxic shock syndrome should therefore be avoided as much as possible.
