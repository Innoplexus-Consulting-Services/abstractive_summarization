introduction trichomoniasis is a common pathogenic sexually transmitted diseases (stds) caused by the motile parasitic protozoan called trichomonas vaginalis (t. vaginalis).
the world health organization (who) has estimated that there are 248 million new cases t. vaginalis each year occur in men and women and nearly 90% of these infections occurred among people living in resource-limited settings.
this parasite can live in the urogenital tract and infect any sexually active person, especially in people with multiple sexual partners and other venereal diseases (1-3).
the cumulative information suggests that t. vaginalis has an important role in increasing getting or spreading other sexually transmitted infections.
t. vaginalis is an important cofactor in promoting the spread of human immunodeficiency virus (hiv), and, may have a major impact on the epidemic dynamics of hiv in some countries (4-9).
trichomoniasis causes a wide range of symptoms, from a relatively asymptomatic condition to mild irritation and severe inflammation.
in men, the infection usually happens in the urethra, burning after urination or ejaculation, or some discharge from the penis.
among women, the clinical features include vaginal discharge, discomfort with urination, itching, redness or soreness of the genitals, and abdominal pain.
without treatment, the infection can last for months or even years (4, 10, 11).
recent evidence also suggested a link between t. vaginalis infection in males and later aggressive prostate cancer.
also in women a relationship between infection and cervical cancer, atypical pelvic inflammatory disease and infertility have been reported (12, 13).
in long-term trichomoniasis, the parasite can colonize and persist within the vagina.
in this process, lymphocytes, erythrocytes and interactions with vaginal epithelial cells are all thought to play important roles.
t. vaginalis can also bind to host extracellular matrix proteins.
experimental evidence showed that adhesion of parasite of the vaginal epithelial cells take place through specific protein- protein interactions.
adhesion of the parasite is a critical step in their virulence and pathogenesis (8, 12).
the nitroimidazoles are the only class of medications known to be effective against t. vaginalis infections.
of these drugs, metronidazole and tinidazole have been cleared and approved drugs by the food and drug administration (fda) (14).
although metronidazole has been the mainstay of treatment for several decades and the cure rate with this drug is high, the long term application of the drug has caused the development of drug-resistant to t. vaginalis, and is the main reason of treatment failure.
in addition, it was reported that metronidazole had side effects and induces hypersensitivity reactions, nausea, dizziness and manifesting as dermatological symptoms, can be occurred (15).
therefore, there is necessary to develop new effective drugs to treatment trichomoniasis.
some medicinal plants are investigated for this proposes (16).
the aromatic rhizome of zingiber officinale is the source of ginger, a spice used for centuries to add flavour in cooking and juices among these promising medicinal agents (17).
for centuries, ginger has been used in traditional medicine for stroke and heart disease, indigestion and nausea, malabsorption, bacterial and fungal infections, ulcers, cancer, diabetes and respiratory disorders.
based on different studies, ginger contains flavonoids, alkaloids, coumarins, saponins, tannin, alkaloid and glycosides and have anti-bacterial, anti-parasitic and antioxidant effects (17-20).
pharmacological components of ginger, including essential oils, zingiberol, zingiberone, zingiberene, and pungent agents such as gingerol and with other gingerol analogues such as the shogaol, paradol and zingerone have been identified (20).
phytochemical studies showed that the major components of ginger are shogaols paradol, zingerone and gingerols.
these agents have the ability to control the transformative processes of hyperproliferative, inflammation and carcinogenesis.
the phenol compounds derived from ginger (gingerol and shogaol) have many interesting physiological and pharmacological activities.
although, it has been used for centuries, this plant still attracts extensive research attention (21).
it is undoubtedly necessary the research for new therapeutic targets, which is essential to the rational development of new anti-t.vaginalis compounds structurally distinct from 5-nitroimidazoles (22, 23).
therefore, the study of plants used by indigenous medicine is important to interconnect traditional medicine and biotic environment preserving the indigenous ancient knowledge.
considering the indigenous ethnopharmacology as a contributor to the systematic screening of plants with antiprotozoal activity, and the need for new, safe and effective drugs for trichomoniasis treatment, the current study was designed to address the possible antiparasitic effect of ginger extract against t. vaginalis infection under in vitro condition.
materials and methods preparation of plant extracts the fresh ginger plant was prepared from market and approved by nutrition department of kashan university of medical sciences.
it was decoction at 60oc for 60 min [1 : 10; (w : v)].
alcoholic extracts were freeze-dried, and the work solution was prepared at 8.0  mg/ml in ultrapure water, sterilized by filtration (0.22  µm) and stored at -20oc.
parasite culture in this experimental study, 970 women were referred to kashan medical centers from october 2013 to august 2014 were examined for t. vaginalis.
from all participants vaginal discharge samples were taken.
of them, 23 samples were infected by t. vaginalis.
three isolates of t. vaginalis were cultured in a tyi-s-33 medium and the effect of the ginger extract was studied.
kashan university of medical sciences ethics committee approved the study protocol and consent form was taken from all participants.
the diagnosis was based on clinical and microscopic visualization (olympus optical microscope model bx40) of motile t. vaginalis parasites on a prepared slide from vaginal discharged.
the parasites were axenically grown in standard tyi-s33 (trypticase-yeast extract-maltose) medium (ph=6.8) supplemented with 10% fetal calf serum (fcs), vitamin mixture and 100 u/ml penicillin and streptomycin mixture at 37oc.
the culture routinely grasped a concentration of 5×105 cells/ml in 48 hr.
anti-trichomonal assay reproducible surveillance of the drug susceptibility status of the anaerobic protozoa t.vaginalis was tested as earlier described (24).
a density of 5×105, trophozoites /ml were incubated in the presence of serially diluted metronidazole (0.025-4 µg/ml) and alcoholic extract of the ginger (25-800 µg/ml) in the tyi-s33 culture media in 48-well plates at 37oc as triplicate.
metronidazole and tyi-s33 culture media without any drug were used as positive and negative controls, respectively.
cells were checked for viability at different time intervals between 12-48 hr.
the number of parasites in each well plate was counted after12, 24 and 48 hr by trypan blue staining.
after counting the number of parasites, half maximal inhibitory concentration (ic50) was determined by graph pad prism5 software(graphpad software, inc.usa) and growth inhibition percentage was calculated using the following formula: (a-b)/a×100 a=average number of trophozoites in control group, b=average number of trophozoites in test group toxicity evaluation of ginger extract the different concentrations) 25, 50, 100, 200, 400, 800 µg/ml) of gingers extract’s cytotoxic effect on mouse macrophage cells was evaluated at three different times by using mtt [3-(4,5-dimethylthiazol-2-yl) -2,5-diphenyltetrazolium bromide (25).
the peritoneum macrophages were isolated from the peritoneum of balb/c mice by injection the cold phosphate-buffered saline (pbs) and re-aspiration.
105 cells/well macrophages were seeded on each well of the 96-well plates and supplemented with 10% fcs at 37oc under 5% co2 and treated with different concentrations of the ginger extract for 24 hr.
cells treated with no extract were taken as control groups.
20 µl mtt reagents (5 mg/ml, ph 7.4) in fresh culture medium was added to each well after 48 hr, then the plates were incubated for 3-5 hr at 37oc under 5% co2.
after that, the supernatant was removed from wells and 100 µl of dimethyl sulfoxide (dmso) was added to each well.
since 15 min, optical density (od) of each well was read at 570 nm by an elisa reader.
percentage of killing macrophages was determined based on the optical absorbance in test and control groups using the following formula (18): killed macrophage (%)=1-(at-ab)/(ac-ab)×100.
ab is the od of the blank well, ac is the od of the untreated samples and at is the od of treated samples.
flow cytometry analysis of cell death the annexin-v fluos staining kit (bio-vision, usa) was used for the detection of apoptotic and necrotic cells according to the manufacturer's protocol.
briefly, trophozoites was cultured in 24-well plates (5×106 parasites/well) in the absence (negative control group) and the presence of 25, 50, 100, 200, 400 and 800 μg/ml of ginger and were incubated at 24oc.
according to the flow cytometry kit instruction, the trohozoites were collected after 48 hr incubation and centrifuged at 2000 rpm for 5 min, then supernatant was discharged, and 500μl binding buffer, 5 μl annexin-v and 5μl propidium iodide (pi) were added to the residue.
the samples were incubated at room temperature and dark condition for 5 min.
absorbed color intensity in cells was observed by flow cytometry (2005 by partec gmbh munster, germany).
the results were analyzed by flowjo software, and the level of apoptosis was determined.
statistical analysis all experiments were performed at least three times.
all data were recorded in a microsoft excel worksheet and analyzed using the spss software package (ver.
16).
results are expressed as mean±sd.
the significant differences among values were analyzed using analysis of student’s t test and variance (one-way anova) coupled with post-hoc least significance difference (lsd).
p<0.05 is considered significant.
results g rowth inhibition the number of viable t.vaginalis trophozoites was decreased compared to the control group with an exposure to ginger alcoholic extract after 12 hr and 24 hr.
the alive throphozoites were decreased significantly by increasing concentration of extract and culture time.
there were no motile and alive trophozoites at 800 µg/ml concentration of the extract after 48 hr (table i).
the number of protozoa fell to zero in a concentration of 800 µg/ml after 48 hr.
the ic50 of ginger and metronidazole against t.vaginalis after 24 hr was calculated 93.8 µg/ml and 0.0326 µg/ml respectively.
mtt assay percentage of killing macrophage cells following exposure to the different concentrations of the ginger alcoholic extract is shown in table ii.
after 12 hr ginger alcoholic extract in 25-800 µg/ml concentrations the fatality rate (%) was observed between 0.11-0.19, it was between 0.15-0.26 and 0.18-0.31 after 24 and 48 hr respectively.
toxicity of the ginger alcoholic extract at the highest concentration (800 μg/ml) and time (48 hr) was 0.31% in macrophage cells.
flow cytometric results flow cytometry results showed induced apoptosis (early and late apoptosis) following treatment trophozoeits with different concentrations of ginger ethanol extract.
early apoptosis in 25, 50, 100, 200 and 400 µg/ml were 0.70%, 0.40%, 1.27%, 1.03% and 1.53%, respectively, and also for late apoptosis these percentages were 16.3%, 28.1%, 40.8%, 67.8% and 74.7%, respectively (figure 1).
table i comparison of different concentrations of ginger ethanol extract of t. vaginalis, after 12 hr, 24 hr and 48 hr exposure ginger concentrations (g/ml µ) t. vaginalis trophozoite (× 10 4 ) 48 hr 24 hr 12 hr 25 1.76 ± 34.7 2.65 ± 37 3.51 ± 45.7 50 5 ± 25 4.73 ± 29.6 3.21 ± 36.3 100 3.5 ± 18.7 3.46 ± 24 5 ± 25 200 2 ± 10 2.52 ± 17.7 5.3 ± 20.3 400 2 ± 6 4.51 ± 9.33 2.51 ± 16.3 800 0 1.53 ± 4.7 4.51 ± 10.33 positive control (0.1μg/ml) - - 1.5 ± 8.3 negative control 6.5 ± 88.3 51.3 ± 53.66 2.51 ± 38.33 data presented as mean±sd.
(statistical comparison of groups, p=0.001) one-way anova test table ii comparison of the fatality rate (%) ginger ethanol extract on macrophages isolated from mice, 12 hr, 24 hr and 48 hr after exposure ginger concentrations ( g/ml µ) killed macrophages (%) 12 hr 24 hr 48 hr 25 0.11 0.15 0.18 50 0.12 0.16 0.20 100 0.12 0.20 0.23 200 0.13 0.21 0.24 400 0.14 0.22 0.26 800 0.19 0.26 0.31 one-way anova test.
statistical comparison of groups, p=0.001 figure 1 flow cytometry results showed the percentage of apoptotic, live and necrotic cells in treating t.vaginalis trophozoites with ginger alcoholic extract after 48 hr in different concentrations discussion trichomoniasis is one of the most common sexually transmitted diseases in humans.
individuals with this chronic infection are at high risk for hiv seroconversion (4).
however, increasing resistance to drugs such as metronidazole poses a serious problem, and new effective tactics are needed to prevent this infection.
the current medications and the first line drugs for treatment of t.vaginalis are metronidazole and tinidazole, both 5-nitroimidazole drugs, are approved by the fda for this infection.
however, using metronidazole is limited because of their high toxicity, high doses and development of drug resistance (14, 15, 26).
the present study demonstrated that administration of the ginger extract to in vitro condition has potential anti-trichomonas activity at a concentration 800 µg/ml on the iranian strain of t.vaginalis.
these findings are in the same line with a previous study that attributed the significant effect on parasite following administration of ginger to the disturbance in parasite due to the anti-parasitic activity of gingerol, shogaol, and hexahydro-curcumin, a constituent isolated from the roots of ginger which may have a direct effect on the vitality and viability of parasite (17, 20, 21).
trichomonad cytopathogenicity is a multifactorial process involving events such as cytoadherence and immune evasion.
cytoadherence is a key property for colonization and infection by t.vaginalis and is mediated principally by two groups of molecules named adhesions and cysteine proteinases (cps), which are expressed on the parasite surface.
besides, iron is an important nutrient for t. vaginalis, which it cannot be synthesized on its own and must receive it by lysis of erythrocytes (27).
it was shown that ginger has components such as saponin (28).
saponins are detergents, and there is a possibility that detergent action may affect the membrane bi-lipid layer and lead to a decrease in the cytoadherence.
saponins also inhibit proteolytic activity of parasite’s cps that are important for adherence, nutrition acquisition and virulence of the parasites.
adhesion protein ap65 is an important adhesion targeted to both surface membrane and hydrogenosome.
it is centrally involved in cytoadherence (24, 29).
according to tiwari and coworkers, saponins prevent the suppression of pro-inflammatory cytokines induced by t. vaginalis, suggesting one of the possible mechanisms of saponins against trichomonas action (30).
previous studies have also shown that treatment of t. vaginalis with pro-apoptotic drugs and metronidazole leads to a form of non-necrotic cell death with some features resembling apoptosis (16, 31).
the use of caspase inhibitors that abolish the apoptotic process in t. vaginalis strongly suggests the presence of caspase-like proteinases in this microorganism (30, 31).
induction of apoptosis or apoptosis-like cell death is one of advantages of ginger against other currently used drugs, including metronidazole, as it does not lead to provocation of an acute immune response.
so far, apoptosis has been described in at least nine species of unicellular organisms, including leishmania (32, 33).
according to the flow cytometry results in the present study, in the control group, 96.8% of cell were alive and percentages of necrosis, early apoptosis and late apoptosis were 0.310%, 0.576% and 2.33% respectively.
it was noted the alive trophozoites in a concentration of 25, 50, 100, 200, 400 µg/ml, were 80.5%, 70.9%, 55.1%, 40%, an 23.1% respectively.
in our study, mtt assay was used to determine the ic50 rate of ginger extract on the iranian strain’s t. vaginalis trophozoites’s.
we have determined an ic50 of 93.8μm for gringer and 0.0326μm for metronidazole, which is higher than reported for other plant species )16).
the reported ic50 for extract in this study and metronidazole as control test are similar investigation.
cedillo-rivera and collegeas found ic50 of 0.034 μm for metronidazole that has little difference with our study (34).
in another study, azadbakht et al showed positive effects of hydro alcoholic extracts of thymus vulgaris and myrtus communis against t. vaginalis, and reported the ic50:0.12 μm for thymus vulgaris and ic50:0.34 μm for myrtus communis, which had high effect in comparison with grion alcoholic extract that we used in the present study (35).
conclusion in conclusion, our results revealed that the ginger extract can induce apoptosis in t.vaginalis by dose- and time-depended manner in in vitro condition.
more comprehensive studies are needed to survey antitrichomonas activity of the ginger extract in in vitro and in vivo and conditions.
@highlight
background: trichomoniasis is the most common sexually transmitted protozoan diseases in the worldwide.
metronidazole is the choice drug for trichomoniasis treatment, however, metronidazole resistant trichomonas vaginalis (t.vaginalis) has been reported.
natural products are the source of most new drugs, and zingiber officinale (ginger) is widely used ingredient in the traditional medicine.
objective: the aim of the present study was to determine the effect of different concentrations of the ginger ethanol extract on the growth of t.vaginalis trophozoites in vitro.
materials and methods: in this experimental study, 970 women who were attend in kashan health centers were examined for t. vaginalis.
of them, 23 samples were infected with t.vaginalis.
three t. vaginalis isolates were cultured in a tyi-s-33 medium.
the effect of ginger ethanol extracts and its toxicity in different concentrations (25, 50, 100, 200, 400, 800 µg/ml) on mouse macrophages were measured in triplicate exam by mtt [3-(4,5-dimethylthiazol-2-yl)-2,5-diphenyltetrazolium bromide] assay.
the effect of ginger on apoptosis induction was determined by flow cytometry.
results: the ic50 of ginger and metronidazole were 93.8 and 0.0326 µg/ml, respectively.
12, 24 and 48 hr after adding different concentrations of extract on mouse macrophages, fatality rates in maximum dose (800 µg/ml) were 0.19, 0.26 and 0.31 respectively.
flow cytometry results showed the apoptosis rate following treatment with different concentrations of the extract after 48 hr were 17, 28.5, 42.1, 58.8, 76.3 and 100% respectively, while in the control group was 2.9%.
conclusion: ginger ethanol extract induces programmed death in t. vaginalis.
it is recommended that due to the known teratogenic effect of metronidazole, ginger can be considered as an alternative drug for metronidazole.
