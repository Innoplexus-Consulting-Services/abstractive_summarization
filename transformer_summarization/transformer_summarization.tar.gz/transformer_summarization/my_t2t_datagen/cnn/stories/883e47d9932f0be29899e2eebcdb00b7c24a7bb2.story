introduction rosette-forming glioneuronal tumor (rgnt) is a rare neoplasm.
this lesion was first described as a distinct entity with a series of 11 cases by komori, et al.
in 2002 [1].
this neoplasm is found in the who 2007 classification of tumours of the central nervous system within the group of “neuronal and mixed glioneuronal tumors”, a category that includes neurocytoma, ganglioglioma/gangliocytoma, dysembryoplastic neuroepithelial tumor, and similar lesions [2].
the radiologic and histopathologic features of rgnt are distinctive [1-3].
this slow growing tumor occurs predominantly in the midline, where it involves the brainstem and cerebellum.
it affects young to middle-aged adults (mean age: 33) with a female predominance of 1.9 to 1. given their location, most rgnts present with symptoms of obstructive hydrocephalus, headache, and ataxia.
rgnt is a who grade i tumor and is curable with complete resection.
these tumors are associated biologically with a favorable prognosis, but postoperative complications and deficits due to the location of the tumor are frequent.
rgnt was initially described as a fourth ventricular lesion, but similar lesions have been reported in the brainstem, cerebellum, optic chiasm, spinal cord, pineal region, and lateral and third ventricle.
a possible association of rgnt with neurofibromatosis type 1 (nf1) has been suggested [4-6].
here, we report a patient with nf-1 and an rgnt in the tectal region that extended with a cystic component into the fourth ventricle.
case presentation informed patient consent was obtained for treatment.
no identifying patient information is contained in this report.
the patient was a 41-year-old right-handed female who had been diagnosed with nf1 at age 6. with the exception of multiple cutaneous manifestations of nf1, she did well until 2002 when signs, symptoms, and radiographic evidence led to the diagnosis of a large tectal lesion with compression of the brainstem and obstructive hydrocephalus.
this was treated with a ventriculoperitoneal (vp) shunt.
she did well until 2007 when her headaches and gait imbalance recurred.
ultimately, the vp shunt was removed and an endoscopic third ventriculostomy was performed.
she continued to have headaches and dizziness.
the tumor had been followed with serial mris.
the lesion was stable until may 2012, when enlargement of a cystic component with compression of the brainstem was documented on mri (figure 1).
figure 1t1 axialill-defined mass originating from the tectal/pineal region and extending inferiorly and occupying the fourth ventricle.
hypointense on t1 images.
the patient underwent suboccipital transvermian craniotomy for subtotal resection of the tumor in october 2012. pathology showed a low cellularity neoplasm with two major components (figures 2-3).
these included glial fibrillary acidic protein (gfap)-positive areas of piloid astrocytic cells resembling pilocytic astrocytoma and other areas with synaptophysin-positive neurocytic tumor cells that formed neurocytic rosettes or perivascular pseudorosettes.
dysmorphic ganglion cells were focally noted as was focal myxoid change.
rosenthal fibers and periodic acid–schiff–diastase (pasd)-positive eosinophilic granular bodies (egbs) were seen.
mitotic figures were not identified.
the ki-67 nuclear labeling index was low at about 2% in the most proliferative areas.
figure 2h&e, 500xrosette-forming glioneuronal tumor (rgnt) neurocytic cells with round nuclei.
these cells form rosettes (arrows) and perivascular pseudorosettes (stars).
figure 3synaptophysin, 500xnote the pattern of brown synaptophysin staining around capillaries in the neurocytic perivascular pseudorosettes (stars) and in the centers of the true neurocytic rosettes (arrows).
the initial postoperative course was uneventful, and the patient was discharged for rehabilitation.
however, about 2 ½ weeks postoperatively, she developed a pseudomeningocele.
this was followed by pseudomonas meningitis and recurrent hydrocephalus.
over the next seven months, she had a very complicated course with multiple episodes of meningitis, urinary sepsis, and clostridium difficile colitis.
after a slow but progressive decline in functional status and multiple hospitalizations for complicated infections, her family made the decision for patient comfort care only.
she expired in home hospice.
discussion rosette-forming glioneuronal tumor (rgnt) is a rare tumor that was initially described as a tumor of the fourth ventricle [1-2].
this lesion has since been documented in other midline locations within the cerebellum, brainstem, and spinal cord.
fourth ventricular examples of rgnt typically present, as seen in our patient, with ataxia or headaches due to obstructive hydrocephalus [1, 3].
rgnt has a highly distinctive histological appearance with neurocytic rosettes/perivascular pseudorosettes and elements that resemble a pilocytic astrocytoma.
it was included as a grade 1 tumor entity in the who 2007 classification of tumours of the central nervous system [2].
this case elucidates the need for possible changes in surgical techniques for these tumors.
other benign tumors in eloquent areas can be treated with stereotactic means, e.g.
gamma knife, stereotactic laser-induced thermotherapy (litt), before they progress and become occlusive or a surgical emergency; should this be considered for rgnt?
also, is it worth biopsying these tumors?
all/nearly all brain tumors associated with nf1 are grade 1, often in eloquent areas.
perhaps new surgical techniques/thinking needs to be applied to avoid surgical morbidity in benign lesions?
three case reports have been published documenting patients with nf1 and rgnt [4-6].
our patient had neurofibromatosis type 1 (nf1) and so represents a fourth example of this association.
thus, the possibility of a causal relationship between nf1 and rgnt should be considered.
an intriguing recent study indicates that missense mutations of pik3ca are a common event in rgnt [7].
pik3ca is the primary catalytic component of pi3k and, thus, drives the pi3k/akt/mtor pathway, a principal regulator of cell metabolism [8].
missense mutations often lead to the gain of pik3ca function [8].
a gain-of-function mutation in the pi3k family would lead to increased activity of the pi3k/akt/mtor pathway.
both the pi3k/akt/mtor and raf/mek/erk pathways are driven by the ras oncogene [9].
these pathways control many cellular functions associated with growth, proliferation, and apoptosis and, thus, are principal players in the development of many neoplasms [8-9].
in patients with nf1, the normal regulation of ras is lost and both of these pathways show increased activity with associated tumorigenesis [9].
nf1 and its associated central nervous system tumors have been well-described in the literature and include brain and spinal cord gliomas, optic pathway gliomas, and dysembryoplastic neuroepithelial tumors (10).
conclusions nf1 and its associated central nervous system tumors have been well-described in the literature and include brain and spinal cord gliomas, optic pathway gliomas, and dysembryoplastic neuroepithelial tumors [10].
as mentioned previously, there are an increasing number of cases that have reported rgnt development in the setting of nf1, and molecular studies have implicated similar mechanisms of tumorigenesis.
therefore, a causal relationship between the loss of ras oncogene regulation leading to increased p13k/akt/mtor pathway activity and subsequent development of rgnt in patients with nf1 should be considered.
@highlight
we report the case of a 41–year-old female with neurofibromatosis type 1 (nf1) who developed a rosette-forming glioneuronal tumor (rgnt) in the tectal plate.
this tumor was diagnosed in 2002 when the patient presented with obstructive hydrocephalus, which was subsequently treated with a ventriculoperitoneal shunt and then an endoscopic third ventriculostomy.
initially thought to be a pilocytic astrocytoma, it was followed with serial magnetic resonance imaging (mri) until tumor progression and development of a large fourth ventricular cystic component prompted resection via suboccipital craniotomy.
histological examination demonstrated an rgnt, a who grade 1 tumor, with neurocytic rosettes, perivascular pseudorosettes, and elements resembling a pilocytic astrocytoma.
initially, the patient did well after her craniotomy, but postoperative complications set in that eventually led to her death.
in this case report, we describe a relatively rare tumor that, despite its benign nature, leads to frequent complications and deficits due to its surgically challenging location.
along with previously reported examples, this cases raises the possibility of a causal relationship between nf1 and rgnt.
