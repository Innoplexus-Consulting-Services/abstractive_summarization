introduction according to the world health organization (who) [1], mental health is an essential part of health that contributes to the overall well-being of every individual.
however, approximately 450 million people suffer from mental health problems worldwide [2].
working adults are particularly vulnerable in hong kong.
for instance, a survey found that 25% of the 1031 employees interviewed reported feeling down, depressed, or hopeless in the previous month, and 90% of them reported needing more mental health support at work [3].
another survey conducted among 1207 employees also showed that 82.5% and 27.6 % of the employees suffered from stress and depression because of work, respectively [4].
work stress can be detrimental to mental health and it is associated with the onset of depression and anxiety among the young working adults [5].
the hong kong mental morbidity survey (hkmms), which was the first territory-wide epidemiological study in hong kong, recruited 5719 chinese participants in the general population of hong kong and found that 13.3% of adults have common mental disorder, with individuals aged 26-35 years having significantly higher weighted prevalence (16.5%) than the general adult population [6].
in view of their vulnerability to mental health problems, prevention programs are urgently needed to promote their mental health.
as the who has suggested, mental health is not the mere absence of disease or infirmity but it also includes positive functioning and state of mind [1].
it is therefore important to provide a prevention program that does not focus only on the reduction of mental health problems or psychological distress but also promotes their positive functioning and state of mind.
in addition to working adults, emerging adults such as college students also experience high levels of stress.
they are in the midst of identity exploration [7] and the instability involved in their transitional stage of becoming full-fledged adults may expose them to higher risks of psychological disturbance.
based on a survey conducted in 2006 covering 10 tertiary education institutions in hong kong, 21%, 41%, and 27 % of the 7915 first-year students reported moderate severity or above on depression, anxiety, and stress symptoms, respectively [8].
another study also found high prevalence of depressive symptoms among college students, with 43.9% of the students reporting a score of 16 or above on the center for epidemiologic studies depression scale, which is suggestive of depressive symptoms [9].
thus, prevention and mental health promotion are also needed among college students.
besides mental health, according to the who, physical health is also one of the components that is intimately related to mental health [1].
in hong kong, it has been found that pain and sleep disturbance are prevalent, with 80.3% of the 1051 hong kong chinese adults who were interviewed indicating some pain over the past year [10] and 68.6% of the 529 hong kong college students interviewed reporting symptoms of insomnia [11].
furthermore, pain, fatigue, and sleep disturbance are highly interconnected and the presence of all 3 physical problems is associated with poorer physical and mental health [12].
since mental and physical health are highly interdependent [1], a mental health promotion program can potentially have benefits on physical health as well.
although effective treatments are available, it is noted that two-thirds of people who suffered from mental disorder did not seek help due to the stigma in seeking mental health services [13].
in the hkmms, only 26% of those with common mental disorders have sought mental health services in the past year, with only 3.9% having sought help from a psychologist [6].
internet-based interventions provide an alternative to face-to-face therapy in enhancing mental health for people who may not seek help due to stigma or other reasons.
it is anonymous, self-paced, and easily accessible.
the high scalability and penetration of internet-based interventions also offers advantages over face-to-face treatment.
increasing evidence has shown the efficacy of internet-based interventions in the treatment of anxiety and depression, as well as the promotion of mental health in the general public.
meta-analysis found the efficacy of internet-based cognitive behavioral intervention in the treatment of anxiety and depression [14,15].
in addition to cognitive behavioral therapy, mindfulness-based interventions provide another means in enhancing mental and physical health.
mindfulness is a nonjudgmental awareness of the present moment with curiosity and openness.
[16,17].
among its many training programs, mindfulness-based stress reduction (mbsr) and mindfulness-based cognitive therapy (mbct) are the most widely applied and are found to be efficacious in the treatment of depression and anxiety, as well as improving the physical and mental health conditions in the clinical and nonclinical populations [18-23].
meta-analyses have also showed that mindfulness-based training is efficacious in the reduction of stress and anxiety among working adults and college students in clinical and community settings [24,25].
although the face-to-face mindfulness-based interventions are efficacious, few have tested the efficacy when delivered through the web.
two previous feasibility and pilot studies showed preliminary evidence of internet-based mindfulness programs in improving stress in nonclinical population [26,27] and another randomized controlled trial showed the efficacy of internet-based mindfulness training in enhancing quality of life among people in the clinical population [28].
in hong kong, one study showed that an 8-week internet-based mindfulness training was efficacious in enhancing mental well-being among college students at postprogram and 3-month follow-up compared with the waitlist control [29].
taken together, the preliminary evidence supported the feasibility of internet-based mindfulness training in promoting mental health.
although much work has been done on mindfulness training and internet-based cognitive behavioral training, few have tested these internet-based interventions in asia.
also, the efficacy of internet-based mindfulness training in promoting mental health is at its early stage.
with the risks and prevalence of depression and anxiety observed among the college students and working adults, this study aimed to test the efficacy of an internet-based mindfulness training for the prevention and promotion of their physical and mental health, compared with the well-established internet-based cognitive behavioral training in a randomized controlled trial.
we hypothesized that both training could enhance the physical and mental health at postprogram and 3-month follow-up.
methods trial design this study was a 2-arm, randomized, open-label, parallel positive-control trial involving two internet-based interventions: a mindfulness training program named imind versus a cognitive-behavioral training program named icbt.
clinical ethics approval was obtained from the principal investigator’s institution (joint chinese university of hong kong–new territories east cluster clinical research ethics committee) as well as from the hospital authority kowloon central or east cluster and the department of health of hong kong.
participants the study targeted college students and young working adults and recruitment was done through (1) sending mass emails to students, teachers, and staff at different universities in hong kong; (2) distributing announcements to the staff of the hospital authority; (3) placing leaflets and posters in civil servant primary care clinics under hong kong department of health; and (4) posting advertisements in local libraries, newspapers, magazines, and social networking site facebook.
individuals who were interested in participating in the study visited our website where they were screened by completing web-based questionnaires on mental health and demographics.
inclusion criteria included (1) age 18 years or above, (2) ability to read and understand chinese, (3) computer literacy, and (4) consistent access to the internet.
exclusion criteria included (1) an indication of suicidality by a score of 1-4 (out of 6) in item 16, 21, or 28 of the mental health inventory (mhi) [30]; (2) currently receiving professional mental health services; and (3) currently taking psychotropic medication.
if participants indicated suicidality in the screening questionnaire, they were to be given a list of resources and hotline on mental health services in the community.
eligible individuals were given detailed information about the study aims, length of the program, participant involvement, and the assignment of intervention through randomization.
they were also informed that the study was conducted by the department of psychology at the chinese university of hong kong.
participants provided informed consent by clicking the “i agree” button at the bottom of the study description page.
from there, participants received an activation link via email and were then randomly assigned to 1 of the 2 conditions by computer-generated numbers.
the pre-, post-, and follow-up assessments were completed by the eligible participants on the web, instead of through supporters, so that the assessment could be free from assessors’ biases from knowing the participants’ assigned conditions.
individuals who did not meet the eligibility criteria received an on-screen message and email with a thank you note and a list of resources on mental health services in the community.
interventions imind and icbt were administered via the internet on 2 separate web pages that were in the chinese language.
functional tests were conducted before the release of the website.
each program consisted of 8 30- to 45-minute sessions.
both programs lasted for 8 weeks.
the delivery format of imind involved didactic readings (eg, nature of human suffering according to the buddhist perspective), experiential learning (eg, guided meditation), and daily life applications (eg, developing awareness on how letting go of one’s attachment could lead to inner peace).
to enhance the user experiences, we made improvement on imind based on its predecessor [29] by making the content more interactive (eg, weekly well-being tracking, built-in multimedia within each lesson, dynamic content display) and more aesthetically appealing (eg, color coordinated and theme-consistent graphics with easy-to-use navigation).
recently, scholars have started to raise concerns about contemporary mindfulness teachings for their over-simplification and deviation from its traditional buddhist root [31-33].
in response to this, our current imind program incorporated core notions in traditional buddhism including discernment, compassion, impermanence, interdependence of all beings, and nonattachment [34].
by contextualizing our mindfulness training within the traditional buddhist foundation, the training program aimed to facilitate participants to develop their own rationale behind practices.
such intentions would set the foundation for continuous and regular practices, and could potentially affect practice outcomes [35,36].
the content of icbt was organized based on macdonald and o’hara’s 10 elements of mental health [37], with mental health promotion resources from the who and government reports from the united kingdom and australia.
at the end of each session, participants were provided with homework assignments to practice what was learned and apply the skills in their daily lives.
in the imind program, videos of stretching and audios of body scan and sitting meditation were provided to the participants to guide them through their exercises.
in the icbt program, worksheets including mood diary, cognitive restructuring, and healthy lifestyle plan were provided for participants to record their responses.
all contents were developed by the research team members who were clinical psychologists and mindfulness practitioners.
the imind and icbt content was turned into the web page by elearningpro limited.
a brief overview of the session content is shown in table 1. no further revision on the content and the web page was made after the trial was launched.
screenshots of how the interventions appeared in the web page are shown in multimedia appendix 1. table 1 overview of session content.
session content (iminda) content (icbtb) 1 introduction on mindfulness introduction on mental health 2 observing thoughts, feelings, and sensations as they are stress, body reactions, and emotion regulations 3 mindful attitudes and nature of suffering cognitive distortions and strategies to cope with stress 4 being in the present moment emotion regulation 5 letting go in times of difficulties resilience in times of adversities 6 ways to stay mindful ways to increase self-esteem 7 mindful communications effective communication skills 8 review and applications review and applications aimind: internet-based mindfulness training program.
bicbt: internet-based cognitive-behavioral training program.
previous research has shown that (1) guided self-help has higher completion rates than unguided self-help [38], (2) programs with weekly telephone reminders are more efficacious than those without [39], and (3) technician-assisted telephone or email support for internet-based interventions is as efficacious as clinician-assisted telephone or email support [40,41].
given these findings, for the duration of the 8-session program in both conditions, trained first tier supporters contacted each participant weekly via telephone and email to (1) acknowledge their time spent on the program, (2) ensure their understanding of course-related instructions, (3) encourage them to continue participating, and (4) provide guidelines for homework activities.
scripted guidelines and training were provided to the supporters.
participants were instructed to call and/or email our research assistant for clarification in case of questions or problems during the course of the intervention.
when a participant fell below a score of 13 or answered 0 or 1 on any of the items on the well-being index (wbi) [42], first tier supporters would refer them to second tier supporters (who were clinical psychologists) to evaluate their mental health status, address their questions, and make referrals for more intensive treatments as needed.
each participant was monitored through weekly self-report measure (ie, the wbi) as well as their first and second tier supporters.
the first tier supporters also contacted the participants in both conditions once a month after the end of the program to maintain contact and interest in completing postprogram evaluations.
the consort e-health checklist is shown in multimedia appendix 2. measures baseline measures at baseline, participants provided demographic and background information including age, gender, education level, income, marital status, religion, and previous experience with systematic mindfulness training (ie, mindfulness-based stress reduction therapy, mbsr, or mindfulness-based cognitive therapy, mbct), regular meditation practices, cognitive-behavioral training, and yoga.
to assess the route of participation, participants also indicated how they learned about this study.
mental health measures mental well-being the who 5-item wbi [43] was used to measure overall mental well-being.
each item was rated on a 6-point likert scale from 0 (never) to 5 (all of the time).
the scale has been used among the chinese with an internal consistency of .90 [36].
in this study, the cronbach alphas of the wbi were .92, .93, and .94 at baseline, postprogram, and 3-month follow-up, respectively.
psychological distress the 18-item mhi was used to assess psychological distress [30].
each item was rated on a 6-point likert scale from 1 (all of the time) to 6 (none of the time).
previous research showed that the mhi’s internal consistency (cronbach alphas) ranged from .81 to .91, with stability coefficients ranging from .60 to .76 over a 1-year interval [44]; its validity has also been supported among the chinese.
in this study, its cronbach alphas were .93, .94, and .95, at baseline, postprogram, and 3-month follow-up, respectively.
life satisfaction life satisfaction was assessed by the 5-item satisfaction with life scale (swls) [45].
participants rated the extent to which they endorsed each item on a 6-point likert scale from 1 (strongly disagree ) to 6 (strongly agree ).
its reliability has been substantiated (eg, test-retest reliability of .84 over a 1-month interval) and its convergent validity has been demonstrated by its high correlations with other life satisfaction measures [46].
the scale has been used extensively among the chinese and its validity has also been supported among hong kong university students [47].
in this study, the cronbach alphas of the swls were .91, .91, and .90 at baseline, postprogram, and 3-month follow-up, respectively.
physical health measures energy average level of energy was measured by the visual analogue scale (vas) [48].
participants rated their average daily energy level on a 100mm long line from 0 (no energy) to 100 (a lot of energy).
its validity is supported by its usage in measuring energy or fatigue level among patients with diagnoses of fatigue-related medical conditions [49].
sleep disturbance the 4-item sleep disturbance subscale of the medical outcomes study (mos) sleep scale [50] was used to assess how well participants slept without tapping into other sleep-related medical conditions.
three items related to sleep disturbance were rated on a 6-point likert scale from 1 (all of the time) to 6 (none of the time) and 1 item related to the time needed to fall asleep was assessed on a 5-point likert scale from 1 (less than 15 minutes) to 5 (more than 60 minutes).
scores were converted to an index that ranged from 0-100 with higher scores indicating a higher level of sleep disturbance.
research has demonstrated its acceptable level of internal consistency reliability (>.70) and its responsiveness to change [50].
it has also been validated among community adults and has been used among the chinese population [51].
the cronbach alphas of mos sleep scale were .83, .70, and .70 at baseline, postprogram, and 3-month follow-up, respectively.
pain average level of pain was measured by vas [52].
participants rated their average daily pain level on a 100mm long line from 0 (no pain) to 100 (very severe pain).
it has been used in a variety of settings and is sensitive to treatment effects [53].
it has been shown to be reliable in pain assessment when compared with other subjective pain measuring methods [54].
it also showed good reliability and validity among chinese adults [55].
usage and satisfaction measures usage is defined as the time (in minutes) spent in the previous week on browsing the website and practicing the assigned homework.
participants reported these figures at the beginning of every session.
at the end of the 8-week program, attitude toward and satisfaction with the internet-based interventions were assessed using the chinese version of the 8-item client satisfaction questionnaire (csq) [56].
each item was rated on a 4-point likert scale from 1 to 4 and response options differed for different items.
the cronbach alpha of csq was .91 in this study.
credibility and expectancy at baseline, participants completed the 6-item credibility or expectancy questionnaire (ceq) that aimed to examine if expectancies or perception of treatment credibility were related to outcomes.
five items were rated on a 9-point likert scale from 1 (not at all) to 9 (very much) and 1 item was rated on an 11-point likert scale ranging from 0 (0%) to 11 (100%).
the ceq comprises 2 factors: cognitively based credibility and affectively based expectancy.
it was shown to have a total item correlation of .78 [57] and the scale has been used among chinese patients [58].
standardized scores were computed for the 2 subscales.
in this study, the cronbach alphas for credibility and expectancy were .82 and .84, respectively.
analysis all analyses were conducted using spss version 20.0 (ibm corp) .
linear mixed models were conducted to test if both conditions showed improvements in all outcomes over time.
compound symmetry covariance was used and missing data were treated using restricted maximum likelihood estimation.
model for each outcome variable consisted of the time effect, condition effect, and the interaction effect of time by condition.
when the main effect of time was significant, follow-up analyses were conducted to compare the outcomes in postprogram and follow-up program with the preprogram, and results were adjusted with bonferroni correction.
t tests were also conducted to test for equivalence in treatment expectancy and satisfaction about course content across the 2 conditions.
results recruitment and participant characteristics participants were recruited between july 2013 and march 2015. a total of 4215 registrants were screened for eligibility.
among those who registered, 932 (22.11%, 932/4215) registrants were deemed ineligible, 1202 (28.52%, 1202/4215) eligible registrants did not activate their accounts, whereas 2081 (49.37%, 2081/4215) eligible registrants proceeded with account activation followed by randomization.
our sample consisted of those who, after randomization, completed the presurvey and received course materials (n=1255).
about one-fifth of the participants (n=253) completed the entire 8-session program, 16.97% (213/1255) completed the postprogram survey, and 10.12% (127/1255) completed the 3-month follow-up (see figure 1 for the flow diagram).
no adverse events were reported during the course of the study.
participants learned about the study from a variety of avenues: work institutions or universities (36.65%, 460/1255), facebook (28.21%, 354/1255), family or relatives or friends (21.27%, 267/1255), other means such as posters and leaflets (10.92%, 137/1255), and primary care clinics (2.95%, 37/1255).
tables 2 and 3 display the baseline characteristics of the participants in both conditions.
overall, participants had a mean age of 32.62 years (sd 12.54), were predominantly female (74.34%, 933/1255), with half of them being college graduates (52.51%, 659/1255).
about one-thirds (34.6%, 434/1255) were college students and about half (51.07%, 641/1255) were working full-time (see table 1).
both conditions reported similar treatment expectancy and credibility (t<0.57, p>.30).
findings showed that both conditions expressed similar csq usage satisfaction, t211 =−0.07, p=.94.
in terms of utilization, imind condition (mean 189.89, sd 501.00) spent more time browsing the course content than their icbt counterparts (mean 135.98, sd 347.08), t1063.9 =−2.20, p=.03).
however, icbt condition (mean 240.63 minutes, sd 578.52) spent more time on homework assignment than imind condition (mean 118.42, sd 401.42), t1162.3=4.37, p<.001.
to investigate the potential causes of attrition, we compared the baseline attributes between the attrition group (did not complete postprogram assessment; n=1042) and the retention group (n=213).
no significant differences in their demographic characteristics were found, except for yoga experience.
a slightly higher percentage of participants reported having had yoga experience in the retention group (28.6%) than in the attrition group (21.8%), χ21 =4.5, p<.05.
in terms of their psychological and stress profile, the attrition group was lower in mental well-being (wbi: mean 2.04, sd 1.05; mhi: mean 3.89, sd 0.84; swls: mean 3.86, sd 1.40, t>2.32, p<.05), energy (mean 53.11, sd 26.15; t1253=−2.01; p=.05), and treatment expectancy (credibility: mean −0.05, sd 0.86; expectancy: mean −0.03, sd 0.88) at preprogram than those who completed the postprogram assessment (wbi: mean 2.25, sd 1.06; mhi: mean 4.03, sd 0.80; swls: mean 4.19, sd 1.35; energy: mean 57.04, sd 25.65; credibility: mean 0.23, sd 0.81; expectancy: mean=0.16, sd=0.83).
table 2 baseline characteristics across conditions.
characteristics icbta (n=651) imindb (n=604) age in years, mean (sd) 32.52 (12.41) 32.73 (12.68) gender, n (%) male 173 (26.6) 149 (24.7) female 478 (73.4) 455 (75.3) education, n (%) primary or below 2 (0.3) 1 (0.2) secondary 125 (19.2) 118 (19.5) bachelor or diploma 346 (53.1) 313 (51.8) master or above 178 (27.3) 172 (28.5) employment, n (%) student 226 (34.7) 208 (34.4) full-time 331 (50.8) 310 (51.3) part-time or freelance 29 (4.5) 28 (4.7) others 65 (10) 58 (9.6) religion, n (%) no religion 392 (60.2) 382 (63.1) christianity 178 (27.3) 153(25.3) catholicism 28 (4.3) 26 (4.3) buddhism 41 (6.3) 34 (5.6) others 12(1.9) 10 (1.7) systematic mindfulness training, n (%) yes 36 (5.5) 40 (6.6) no 615 (94.5) 564 (93.4) regular meditation practices, n (%) yes 60 (9.2) 57 (9.4) no 591 (90.8) 547 (90.6) yoga experience, n (%) yes 149 (22.9) 139 (23.0) no 502 (77.1) 465 (77.0) cognitive behavioral, n (%) therapy experience, n (%) yes 16 (2.5) 18 (3.0) no 635 (97.5) 586 (97.0) aicbt: internet-based cognitive behavioral training program.
bimind: internet-based mindfulness training program.
table 3 baseline characteristics across conditions.
measures icbta (n=651), mean (sd) imindb (n=604), mean (sd) well-being index 2.02 (1.05) 2.14 (1.06) mental health inventory 3.90 (0.83) 3.93 (0.83) life satisfaction scale 3.90 (1.36) 3.94 (1.43) sleep disturbance 26.92 (20.24) 26.03 (20.69) pain 26.14 (25.75) 26.31 (25.62) energy 52.01 (26.41) 55.67 (25.64) credibility or expectancy questionnaire credibility −0.02 (.86) 0.03 (0.86) expectancy 0.01 (0.86) −0.01 (0.88) aicbt: internet-based cognitive behavioral training program.
bimind: internet-based mindfulness training program.
figure 1 flow diagram of this study.
mental health measures well-being index results from the linear mixed model indicated a significant time effect (p<.001).
mental well-being significantly increased from baseline to postprogram (mean difference=−0.83, 95% ci −0.996 to −0.66, p<.001), and this increase was maintained at 3-month follow-up (mean difference=−0.73, 95% ci −0.94 to −0.51, p<.001) in both imind and icbt.
wbi was not significantly different between imind and icbt (mean difference=−0.03, 95% ci −0.20 to 0.14, p=.75), and the 2 conditions did not differ in their improvements over time (p=.56) mental health inventory the results indicated that there was a significant time effect (p<.001).
it significantly increased from baseline to postprogram in both imind and icbt (mean difference=−0.46, 95% ci −0.59 to −0.33, p<.001) and was maintained at 3-month follow-up (mean difference=−0.25, 95% ci −0.41 to −0.09, p=.001).
mhi was not significantly different between imind and icbt (mean difference=0.08, 95% ci −0.05 to 0.22, p=.22).
the interaction effect of time x condition (p=.18) was also not significant, indicating that imind and icbt showed similar improvement over time.
life satisfaction the results indicated a significant time effect (p<.001), with life satisfaction significantly increased from baseline to postprogram in both imind and icbt (mean difference=−0.77, 95% ci −0.96 to −0.59, p<.001), and this increase was maintained at 3-month follow-up (mean difference=−0.85, 95% ci −1.08 to −0.62, p<.001).
the improvement was not significantly different between imind and icbt (mean difference=−0.05, 95% ci −0.26 to 0.16, p=.62), and the time x condition interaction (p=.88), was not significant.
physical health measures energy results showed that energy improved over time (p<.001).
the improvement was significant at postprogram, (mean difference=−12.60, 95% ci −16.54 to −8.67), p<.001), and was maintained at 3-month follow-up in both imind and icbt, (mean difference=−13.42, 95% ci −18.37 to 8.47, p<.001).
the effect did not differ between imind and icbt (mean difference=−2.01, 95% ci −6.07 to 2.05, p=.33), and no significant interaction effect of time x condition (p=.67) was found.
sleep disturbance improvement was shown over time (p<.001).
the improvement was significant at postprogram (mean difference=8.12, 95% ci 5.66-10.58, p<.001), and 3-month follow-up in both imind and icbt (mean difference=7.46, 95% ci 4.39-10.53, p<.001).
the improvement was not significantly different between imind and icbt (mean difference=0.16, 95% ci −2.79 to 3.12, p<.001), and the interaction effect of time x condition (p=.91), was not significant.
pain results showed that pain significantly improved over time (p=.01).
the improvement was shown in postprogram (mean difference=3.95, 95% ci 0.27-7.63, p=.03).
no significant effect was found for the condition effect (mean difference=−0.31, 95% ci −4.29 to 3.67, p=.88), and the time by condition effect (p=.58) were not significant.
tables 4 and 5 show a summary of the means, standard errors, effect sizes, and time effects of the outcome measures across conditions.
table 4 means and standard errors across conditions.
measuresa icbtb (n=651) imindc (n=604) mean (sed) mean (se) pre post follow-up pre post follow-up mental health measures wbie 2.02 (0.04) 2.90 (0.10) 2.84 (0.12) 2.14 (0.04) 2.92 (0.10) 2.78 (0.12) mhif 3.90 (0.03) 4.43 (0.07) 4.25 (0.09) 3.93 (0.03) 4.31 (0.08) 4.08 (0.09) swlsg 3.90 (0.05) 4.69 (0.11) 4.71 (0.14) 3.94 (0.06) 4.69 (0.11) 4.82 (0.14) physical health measures energy 52.01 (0.99) 66.00 (2.26) 66.52 (2.87) 55.67 (1.03) 66.89 (2.29) 68.00 (2.89) sleep disturbance 26.92 (0.77) 19.13 (1.51) 18.03 (1.85) 26.03 (0.81) 17.58 (1.53) 19.99 (1.88) pain 26.14 (0.99) 21.04 (2.15) 23.12 (2.71) 26.31 (1.03) 23.50 (2.19) 21.43 (2.73) asignificant time effects were shown for all measures (p s<.05).
all post and follow-up scores were significantly improved compared with the prescores, except that pain did not show any improvement at follow-up compared with prescore.
interaction effect of time x condition were all nonsignificant, indicating that the improvements over time were similar across conditions.
bicbt: internet-based cognitive behavioral training program.
cimind: internet-based mindfulness training program.
dse: standard error.
ewbi: well-being index.
fmhi:mental health inventory.
gswls: satisfaction with life scale.
table 5 overall time effects and effect sizes across conditions.
measures scales icbta(n=651) imindb(n=604) overall time effect cohen's dc cohen's d post versus pre mean difference (95% ci) p value follow-up versus pre mean difference (95% ci) p value post versus pre follow-up versus pre post versus pre follow-up versus pre mental health measures wbid 0.86 0.81 0.79 0.65 −0.83 (−0.996 to −0.66) <.001 −0.73 (−0.94 to 0.51) <.001 mhie 0.70 0.46 0.51 0.20 −0.46 (−0.59 to −0.33) <.001 −0.25 (−0.41 to −0.09) .001 swlsf 0.55 0.64 0.52 0.61 −0.77 (−0.96 to −0.59) <.001 −0.85 (−1.08 to −0.62) <.001 physical health measures energy 0.56 0.58 0.45 0.49 −12.60 (16.54-8.67) <.001 −13.42 (−18.37 to −8.47) <.001 sleep disturbance 0.41 0.46 0.44 0.31 8.12 (5.66-10.58) <.001 7.46 (4.39-10.53) <.001 pain 0.21 0.12 0.11 0.20 3.95 (0.27-7.63) .03 3.95 (−0.67 to 8.57) .12 aicbt: internet-based cognitive behavioral training program.
bimind: internet-based mindfulness training program.
ccohen's d was computed from postprogram or 3-month follow-up score minus preprogram score divided by the pooled standard deviation.dwbi: well-being index.emhi: mental health inventory.fswls: satisfaction with life scale.
discussion principal findings this study developed and evaluated the efficacy of the internet-based mindfulness training in comparison with an internet-based cognitive-behavioral training on college students and young working adults in hong kong.
results showed that the internet-based mindfulness training was as efficacious as the widely supported internet cognitive-behavioral training in improving mental well-being, psychological distress, life satisfaction, energy level, sleep disturbance, and pain at the end of the 8-week program.
furthermore, users’ perceived credibility, expectancy, and satisfaction of both programs were similar.
the results are encouraging as both internet-based programs received support for their utility, satisfaction, and efficacy in mental health promotion.
given the weight of mental illness disease burden in our communities, this study shows that internet-based mindfulness and cognitive-behavioral training programs with minimal guided support can be a highly scalable and convenient way for prevention and promotion of mental and physical health among college students and young working adults in hong kong, the majority of individuals who seek help for mental health issues do not receive psychiatric and clinical psychological services in primary and secondary care settings until their problems have become severe.
in comparison with face-to-face interventions, internet-based interventions are more easily accessible and affordable and have the potential to fulfill the need for mental health promotion and prevention in community settings.
this study provided empirical support for the efficacy of internet-based cognitive-behavioral and mindfulness training programs, which can be easily incorporated into existing service provision portfolios that promote mental health and reduce psychological distress among the college students and young working adult population in hong kong.
in terms of service management, these developed internet-based interventions are highly sustainable.
in hong kong, the number of mobile phone customers reached over 8 million in june 2016, and the amount of mobile data usage has been 10-folded from 2006 to 2016, demonstrating the rapid increase of mobile phone and mobile internet usage [59].
with the high penetration of internet-based programs and the increasing prevalence of mobile phone and tablet device utilization, internet-based programs meet the public mental health goal of reaching the general public for mental health promotion and prevention under the stepped care model, especially if the current programs can be converted into mobile phone apps in the future.
although attrition may be high, given it is an easily accessible public health tool, if its dissemination in the population is wide, such internet-based mental health promotional tools can still be an important augmentation to face-to-face interventions in filling the role of mental health promotion and illness prevention that is lacking in the current mental health services system in hong kong [60].
one size does not fit all; we need myriad approaches of varying dosage and penetration rates to reach a wider population in order to prevent the tremendous mental illness burden [61,62].
thus, we believe internet-based programs still have their merits by reaching out to many more individuals at a much shorter period of time.
even if only a tenth of the thousands improved over the course of the programs, it is still worthwhile to make this accessible to individuals who may not have access or do not prefer to have face-to-face interventions.
future research should explore methods for enhancing adherence of internet-based health solutions in order to harness the expanding proliferation of technology among the public.
for instance, recent studies have begun to incorporate ecological momentary intervention components into internet-based programs so that interventions can be directed to real-time events and be more personalized [63,64].
emerging evidence has suggested efficacy of ecological momentary interventions in the enhancement of a variety of health behaviors [65].
to leverage the power of technology in the promotion of mental health, interventions that incorporate these methods may reduce attrition rate and further maximize the efficacy of the internet-based programs.
although improvements in outcomes were observed at postprogram, the improvements for pain were not maintained at 3-month follow-up.
this could be the result of reduced practice or application of skills learned on the websites.
in addition, this might also due to the low level of pain observed within this group of population.
the floor effect might have limited the possibility in detecting improvement in pain at postprogram and 3-month follow-up.
the two internet-based interventions in this study yielded similar results.
future studies can explore how individual differences may affect intervention benefits.
it may be possible that cognitive styles can play a role in the receptivity of imind and icbt and matching their styles with the treatment approach may maximize the outcome.
limitations this study has several limitations.
first, our target population was college students and young working adults.
by nature, our sample is skewed toward those who were educated or were employed.
as our programs were internet-based, it is possible that they appealed to a selective group in the population who were more comfortable in accessing interventions over the internet with their personal computers.
they might have higher mental health literacy and be more willing to participate in internet-based mental health programs.
these biases in our sample limit the generalizability of our findings to all segments of the population (eg, less educated individuals, older adults).
it is possible that the delivery of mental health materials over the internet may only be appropriate for specific segments of the populations, rather than the entire population.
future studies should focus on how internet-based interventions can cater to different segments of the populations through various adaptations.
second, the attrition rate of our study is high.
high attrition rate has been a perennial problem for internet-based interventions.
similarly high attrition rates have been reported in other internet-based mental health programs.
for example, christensen and colleagues [66] reported an attrition rate of 74% in their internet-based cognitive behavioral therapy (cbt) program for depression.
another study reported an attrition rate of 98.8% in an internet-based cbt for panic disorder [67].
a study based on the moodgym had an attrition rate of 73.9% for trial participants and 99.2% for public registrants [68].
in a more recent systematic review of internet-based interventions for anxiety and depression, the completion of protocol rates for depression sites ranged from 43% to 99% [69].
another systematic review on internet-based interventions for psychological disorders also found that there was an additional 0% to 18% of participants who would further dropout from post to follow-up assessment [70].
moreover, during the inception of our project, mobile phones and tablets were not as omnipresent as they are today.
because of that, our web-based modules were designed using adobe flash and thus only catered for desktop viewing, which may deter usage.
third, we did not include a waitlist control group in this study.
as this study aimed to compare internet-based mindfulness training with a well-established internet-based cognitive behavioral training, and previous study has found internet-based mindfulness training to have significant improvements in mental health than waitlist control [29], we decided not to have a waitlist control in this study so as not to withhold intervention from our participants.
fourth, we did not ask whether our participants received any other psychological intervention during the study period.
thus, the findings may potentially be attributed to additional intervention that the participants have received.
finally, this study found that those who quit the programs scored lower on mental health measures, energy level, mindful awareness, and treatment expectancy at the outset.
to ensure interventions are catered to those most in need, future studies should explore the reasons behind attrition and identify corresponding remedies.
as suggested by existing research, utilization can potentially be promoted via built-in incentives, personalized feedback, and user collaboration [71].
conclusions in sum, this study showed that both internet-based mindfulness training and internet-based cognitive-behavioral training were efficacious in improving mental and physical health indicators among college students and young working adults in a convenient fashion.
to leverage the power of technology in reducing mental illness burden, it is paramount for mental health professionals to work in tandem with professionals in other disciplines (eg, designers, computer scientists) in creating user-friendly programs that enable seamless integration into users’ daily lives.
@highlight
background college students and working adults are particularly vulnerable to stress and other mental health problems, and mental health promotion and prevention are needed to promote their mental health.
in recent decades, mindfulness-based training has demonstrated to be efficacious in treating physical and psychological conditions.
objective the aim of our study was to examine the efficacy of an internet-based mindfulness training program (imind) in comparison with the well-established internet-based cognitive-behavioral training program (icbt) in promoting mental health among college students and young working adults.
methods this study was a 2-arm, unblinded, randomized controlled trial comparing imind with icbt.
participants were recruited online and offline via mass emails, advertisements in newspapers and magazines, announcement and leaflets in primary care clinics, and social networking sites.
eligible participants were randomized into either the imind (n=604) or the icbt (n=651) condition.
participants received 8 web-based sessions with information and exercises related to mindfulness or cognitive-behavioral principles.
telephone or email support was provided by trained first tier supporters who were supervised by the study’s research team.
primary outcomes included mental and physical health-related measures, which were self-assessed online at preprogram, postprogram, and 3-month follow-up.
results among the 1255 study participants, 213 and 127 completed the post- and 3-month follow-up assessment, respectively.
missing data were treated using restricted maximum likelihood estimation.
both imind (n=604) and icbt (n=651) were efficacious in improving mental health, psychological distress, life satisfaction, sleep disturbance, and energy level.
conclusions both internet-based mental health programs showed potential in improving the mental health from pre- to postassessment, and such improvement was sustained at the 3-month follow-up.
the high attrition rate in this study suggests the need for refinement in future technology-based psychological programs.
mental health professionals need to team up with experts in information technology to increase personalization of web-based interventions to enhance adherence.
trial registration chinese clinical trial registry (chictr): chictr-trc-12002623; https://www2.ccrb.cuhk.edu.hk/ registry/public/191 (archived by webcite at http://www.webcitation.org/6kxt8djm4).
