1. introduction atmospheric carbon dioxide (co2) is the dominant anthropogenic greenhouse gas, and a crucial factor in global climate change [1].
however, our current knowledge about the temporal and spatial variability of atmospheric co2 is still insufficient, which leads to large uncertainties in our estimates of carbon sources and sinks [2,3,4].
ground-based observations, for example, are accurate but too spatially sparse to sufficiently infer co2 sources and sinks [3,5,6,7,8,9].
space-based measurements, on the other hand, have the potential to yield global estimates of the distribution of the atmospheric co2 vertical column (in molecules/cm2) or the co2 dry air column-averaged mole fraction (in ppm), especially in areas not covered by ground-based observations [5,10].
near and short-wave infrared (nir) measurements have sufficiently high precision and sensitivity to the planetary boundary layer, where the largest signals of sources and sinks occur [2,3,6,7,11,12,13,14,15,16].
the first nir carbon satellite instrument, sciamachy, onboard envisat that was launched in 2002 and lost in 2012, measured reflected solar radiation in the nir spectral bands [4,9].
presently, there are only two nir carbon satellite instruments orbiting the earth, which enable the retrieval of xco2 with significant sensitivity in the boundary layer (i.e., near the earth’s surface).
the two instruments are tanso, onboard gosat launched in 2009 and oco-2 launched in 2014 [12,13,14].
china’s first satellite to monitor atmospheric xco2, tansat, will be launched at the end of 2016. a flight test was conducted in september, 2015 to evaluate the performance and stability of tansat’s instruments for acquiring high resolution absorption spectra, and to reduce the risk of tansat operating problems after launch.
simultaneous ground-based measurements of geophysical parameters were also collected and can be used to evaluate the accuracy of the retrieved atmospheric xco2 estimates.
the remainder of this article is structured as follows: section 2 introduces the flight area and data used in this article.
section 3 introduces the methods used in this study, including the deployment of a full physics retrieval algorithm to retrieve xco2 in the flight test area, the use of regression modeling to estimate the approximate xco2 surface, and the use of the hasm platform to model the xco2 surface.
section 4 analyzes the retrieval results and distribution of xco2 in the flight test area.
section 5 concludes the paper and discusses future work.
2. study area and data 2.1. flight logistics and data tansat aims to deliver xco2 in ppm at a high spatial resolution in square grids measuring 3 km on a side.
an evaluation of the performance of the tansat imaging spectrometer prototype was conducted as part of flight tests on the 11th, 14th and 16th of september, 2015. the flight demand parameters, such as the flight height, flight speed, flight time, solar zenith angle, flight geometric requirements and meteorological conditions, can be seen in table 1. the flight’s spectrometer covered two of the three nir spectral bands that will be included in the final tansat spectrometer (table 2).
we can see that band 1 observed the o2 a-band spectral region (758–773 nm) at 0.044 nm spectral resolution and that band 2 covers the 1592–1625 nm spectral region with a spectral resolution of 0.13 nm.
the third tansat spectral band (2060 nm), which will provide co2 absorption and water vapour information, was not included in the prototype and flight test due to cost.
for this study, we acquired the flight test’s l1b data (calibrated and geographically located spectral radiances) from the changchun institute of optics, fine mechanics and physics, chinese academy of sciences.
they had processed the dark background and calibrated the spectral radiation for the test flight’s l1a dn (digital number) data.
samples of two nir spectral bands derived from the l1b data used in the study can be seen in figure 1 and figure 2. the x-axis shows spectral wavelengths (in nm), and the y-axis represents the spectral radiance (in w/m2/nm/sr).
band 1 contains o2 absorption information and can be used to estimate the o2 column with high near-surface sensitivity.
similarly, band 2 contains co2 weak absorption information and can be used to estimate the co2 column with high near-surface sensitivity.
2.2. study area and surface characteristics the flight test passed over xianghai reserve and chagan lake in jilin province (figure 3).
the underlying surface included several lakes, forest, grass, and wetlands, farmland, a thermal power plant and numerous cities and villages.
the test area runs from 122.205° e to 124.946° e and from 44.980° n to 45.360° n and cover an area of about 11,000 km2.
the left red box of figure 3 covers the xianghai reserve and includes the limin grassland, hedao wetland and xianghai lake.
the right red box of figure 3 shows the chagan lake area and includes the chanshan town thermal power plant, farmland, chagan lake and songyuan city.
ground synchronous observations were also collected during the flight period, and provided important auxiliary data for xco2 retrieval and simulation in the flight test area.
the observations and methods used to gather them are listed in table 3. temperature, humidity, pressure and wind profiles were obtained by sonde measurements and used to summarize the state of the atmosphere for xco2 retrieval and surface estimation (table 3).
the co2 concentration at the surface was observed with a greenhouse gas online laser analyzer.
the co2 profile gathered with a captive balloon and co2 concentration in the surface layer were used as dependent variables in the flight test area when we established the approximate xco2 surface.
aerosol optical depth and surface reflectance are also crucial factors for xco2 retrieval and were observed with a sun photometer and asd spectrometer, respectively.
3. methods we first retrieved the xco2 using a full physics retrieval algorithm.
however, it is difficult to directly analyze the spatial distribution of xco2 in the flight test area using the limited retrieval results.
the high accuracy surface modeling (hasm) method has been widely used in the simulation of climate change, co2 concentrations in the surface layer, and terrestrial land cover change [17,18,19].
we therefore used hasm to fill the gaps where there was no information on xco2 in the flight test area.
the entire workflow reproduced in figure 4 includes three main steps.
first, we used a full physics retrieval algorithm to retrieve xco2.
second, we used regression modeling to establish the approximate (i.e., not very accurate) surface of xco2 in the flight test area.
and third, we used hasm, which took the approximate surface of xco2 as its driving field and retrieved xco2 as its optimum control constraints, to simulate a high accuracy xco2 surface for the whole flight test area.
3.1. retrieval algorithm in this study, the retrieval algorithm is primarily used for simultaneously fitting the o2 a-band at 760 nm and the co2 band at 1610 nm to get column abundances of co2 and o2 based on the optimal estimation method [20].
the retrieval algorithm is an iterative retrieval method which calls the radiative transfer model with updated parameters after each iteration step.
the primary components of the flight xco2 retrieval processing workflow are summarized in figure 5. given that the atmospheric and surface states and the observing geometry for a sounding, the forward model generates radiance spectra and jacobians (as will be described in more detail in section 3.1.1 below).
this model first generates two synthetic spectra that fully resolves the solar spectrum, the absorption and scattering cross sections for each atmospheric gas and the reflecting surface.
the inverse method is based on rodger’s optimal estimation approach.
this method modifies the initial state vector to minimize differences between the observed and simulated spectra from each sounding.
this inverse method is described in more detail in section 3.1.2 below.
3.1.1. forward model synthetic spectra were generated using a radiative transfer algorithm.
losses can be caused by absorption and the scattering of the atmosphere.
the sources (i.e., gains) mainly come from atmospheric emission and multiple scattering, and the general expression of the radiative transfer is given by the following equation [21]: (1)μdi(τ,μ)dτ=i(τ,μ)−j(τ,μ) where μ is the cosine of the zenith angle, i is the specific intensity, j is the source function (multiple scattering), and τ is the optical depth.
the radiative transfer model sciatran was used to solve equation (1).
sciatran is a comprehensive software package for the modeling of radiative transfer processes in the terrestrial atmosphere and ocean in the spectral range from the ultraviolet to the thermal infrared (i.e., 0.18–40 μm) including multiple scattering processes, polarization, thermal emission and ocean-atmosphere coupling.
the software is capable of modeling spectral and angular distributions of the intensity or the stokes vector of the transmitted, scattered, reflected, and emitted radiation assuming either a plane-parallel or a spherical atmosphere [22].
the inputs and outputs of the sciatran model can be seen in the table 4. the solar irradiance spectra were acquired from dr. kurucz (http://kurucz.harvard.edu).
gas absorption and scattering cross sections were obtained from the sciatran software package which incorporates a climatological database obtained from a 2d chemical transport model.
the atmospheric state (temperature, humidity and pressure profiles), surface state and aerosol optical properties were taken from ground synchronous observations and the european centre for medium-range weather forecasts (ecmwf) reanalysis data.
a set of instrument line shape functions were provided by the changchun institute of optics, fine mechanics and physics, chinese academy of sciences.
the outputs of the forward model were synthetic spectra and jacobians.
3.1.2. inverse method the inversion was used to obtain the unknown geophysical parameters (co2 and o2 profiles) which minimize the differences between the observed and synthetic spectra from each sounding.
the inverse method is based on rodger’s optimization algorithm in which the spectrum is expressed symbolically as in equation (2): (2)y=f(x,b)+∈ where x is the unknown state vector, b is a set of quantities required by the forward model but not retrieved, f is the forward model, and ∈ are the spectral errors due to the measurements and the forward model.
to find the state vector with the maximum a posteriori probability, we minimized the cost function (equation (3)): (3)χ2=(y−f(x,b))ts∈−1(y−f(x,b))+(x−xa)tsa−1(x−xa) where s∈ is the error covariance matrix corresponding to the measurement vector, xa is the a priori state vector which holds the prior knowledge about the state vector elements and sa is the corresponding a priori error covariance matrix which specifies the uncertainties of the a priori state vector elements as well as their cross-correlations.
the levenberg-marquardt method was used to obtain the solution in an iterative manner (equation (4)): (4)xi+1=xi+s˜[kits∈−1(y−f(xi−b))−sa−1(xi−xa)] (5)s˜=(kits∈−1ki+(1+γ)sa−1)−1 where k is the jacobian or weighting function matrix consisting of the derivatives of the forward model with respect to the state vector elements k = ∂f(x,b)/∂x.
in the case of convergence, xi+1 is the most probable solution given the measurements and prior knowledge and it is then denoted as the maximum a posteriori solution x˜ of the inverse problem.
s˜ is the corresponding covariance matrix consisting of the variances of the retrieval state vector elements and their correlations.
the damping factor γ adjusts the step size of the iteration in a way which ensures that each step further minimizes the cost function.
the inverse method continued to provide iterative improvements of the solutions until both of convergence criteria listed below were achieved and we could obtain co2 and o2 column abundances: (1)the fitted residuals with root mean square error (rmse) differences between synthetic and observation spectra less than some pre-determined threshold: 0.25% for co2 and 2% for o2 window [4,13].
(2)the normalized successive difference of the state vector is less than some pre-determined threshold (1%) in the tanso-fts swir l2 algorithm (see [2] for details).
for co2 we derived column-averaged dry air mole fractions by normalizing the co2 columns with the simultaneously retrieved oxygen columns retrieved from the o2 a-band.
oxygen is an accurate proxy for the air column because its mole fraction is well known and has negligibly small variations.
then xco2 was calculated using equation (6) [4,23] as follows: (6)xco2=co2colo2col/o2mf where co2col is the retrieved absolute co2 column (in molecules/cm2), o2col is the retrieved absolute o2 column (in molecules/cm2), and o2mf (0.2095) is the assumed (column-averaged) mole fraction of o2 used to convert the o2 column into a corresponding dry air column.
3.2. derivation of approximate xco2 surface the approximate xco2 surface in the flight test area was required to establish as the driving field of hasm (described in section 3.3 below).
the processing steps used to estimate the approximate xco2 are summarized in figure 6. firstly, we used the least squares fit for the captive balloon’s co2 profiles, the surface co2 concentration in the surface layer and other synchronous ground observations to build a regression model [17,18].
secondly, we combined the regression model with the weather research and forecasting (wrf) model [24,25] to derive the approximate co2 surface for every pressure layer in the whole flight test area.
finally, the pressure weighting function was used to merge every pressure layer’s co2 surface to estimate the approximate xco2 surface.
3.2.1. initial regression model we used an ordinary least squares multivariate linear fit method to build the regression models.
the two groups of explanatory variables listed in table 5 were used to build separate regression models for the co2 concentrations in the surface layer [18] and the co2 profile.
we used the modeling spatial relationships/ordinary least square tools in arcgis to perform this work, and both models passed the f test at the 95% confidence level.
the co2 concentration in every pressure layer at every grid point in the flight test area was then calculated as follows: (7)yco2=b+∑i=1naixi where yco2 is the co2 concentration in every pressure layer, b is a constant, x represents the explanatory variables, a is the corresponding coefficient for each of the explanatory variables, and n is the number of explanatory variables.
3.2.2. wrf model wrf is a next-generation mesoscale numerical weather prediction system designed for both atmospheric research and operational forecasting needs.
the model serves a wide range of meteorological applications across scales from tens of meters to thousands of kilometers.
wrf can generate atmospheric simulations using real-world data or idealized conditions.
wrf offers operational forecasting a flexible and computationally-efficient platform for operational forecasting using initial data from the us national center for environmental prediction (ncep).
the initial data used in this study were derived from reanalysis datasets of ncep.
we generated forecasts at 20:00 each day using an integrate interval of 30 h and 1 km by 1 km grid.
physical parameters were the ysu scheme, monin obukhov scheme, wsm 6-class graupel scheme, rrtm scheme (longwave), goddard scheme (shortwave), noah-mp land-surface model and kain-fritsch (new eta) scheme respectively.
we used wrf version 3.5 to model the co2 concentration at every point using the aforementioned explanatory variables in the flight test area on an hourly basis from 10:00 to 14:00 on the 11th, 14th, and 16th of september.
we then used equation (7) to calculate the approximate co2 concentration of every pressure layer at each point in the flight test area.
3.2.3. pressure weighting function the pressure weighting function h relates the local co2 concentration specified on the discrete pressure levels to the profile-weighted average [8], so xco2 could be calculated as follows: (8)xco2=∑i=1nhiui where u denotes the co2 concentration and the subscripts refer to the layers, and: (9)hi=|(−pi+pi+1−piln(pi+1/pi))+(pi−pi−pi−1ln(pi/pi−1))|1psurf where p denotes the pressure and the subscripts again refer to the layers, and psurf denotes the surface pressure.
for the edge layers, if i = 1, only the left first term applies, that is h1=|(−p1+p2−p1ln(p2/p1))|1psurf, while if i = n, only the left second term applies, that is hn=|(pn+pn−pn−1ln(pn/pn−1))|1psurf.
the approximate co2 concentration for every pressure layer at each point in the flight test area was calculated using the methods described in section 3.2.1 and section 3.2.2. with the methods specified at this step, the approximate xco2 was obtained by averaging the approximate co2 concentration of every pressure layer, weighted by the pressure weighting function.
3.3. high accuracy surface modeling the high accuracy surface modeling [26] platform takes global approximate information (e.g., remote sensing images or model simulation results) as its driving field and local accurate information (e.g., ground observation and/or sampling data) as its optimum control constraints.
a surface can be uniquely defined by the first and the second fundamental coefficients [27,28,29,30,31] in terms of the fundamental theorem of surfaces.
the first fundamental coefficients are used to express the intrinsic geometric properties that do not depend on the shape of the surface, but only on measurements that we can carry out while on the surface itself.
the second fundamental coefficients reflect the local warping of the surface, namely its deviation from a tangent plane at the point under consideration, which can be observed from outside the surface.
the earth’s surface system or a component surface of the earth’s surface environment can be simulated with hasm when its spatial resolution is fine enough and is uniquely defined by both extrinsic and intrinsic invariants of the surface.
if a surface is a graph of a function z=f(x,y), the first fundamental coefficients e, f and g can be formulated as (10){e=1+fx2g=1+fy2f=fx·fy the second fundamental coefficients l, m and n can be formulated as (11){l=fxx1+fx2+fy2n=fyy1+fx2+fy2m=fxy1+fx2+fy2 the first and the second fundamental coefficients should satisfy the following gauss equation set: (12){fxx=γ111·fx+γ112·fy+l·(e·g−f2)−1/2fyy=γ221·fx+γ222·fy+n·(e·g−f2)−1/2fxy=γ121·fx+γ122·fy+m·(e·g−f2)−1/2 where γ111=12(g·ex−2f·fx+f·ey)·(e·g−f2)−1, γ121=12(g·ey−f·gx)·(e·g−f2)−1, γ221=12(2g·fy−g·gx−f·gy)·(e·g−f2)−1, γ112=12(2e·fx−e·ey−f·ex)·(e·g−f2)−1, γ122=12(e·gx−f·ey)·(e·g−f2)−1, γ222=12(e·gy−2f·fy+f·gx)·(e·g−f2)−1 are the christoffel symbols of the second kind which depend only on the first fundamental coefficients and their derivatives.
finite difference methods are used for solving the gauss equation set (equation (12)).
it can be simplified as the following equation set [26]: (13){a·z(n+1)=d(n)b·z(n+1)=q(n)c·z(n+1)=p(n) if fi,j is the value of z=f(x,y) at the pth sampled point (xi,yi) in the computational domain, the simulation value should be equal or approximate to the sampling value of this lattice so that the constraint equation is added to the simplified equation set (equation (13)).
the matrix formulation of the hasm master equations can be expressed as follows [26]: (14)[at bt ct λ·st][abcλ·s]z(n+1)=[at bt ct λ·st][d(n)q(n)p(n)λ·k] where the parameter λ is the weight of the sampling points and determines the contribution of the sampling points to the simulated surface.
λ could be a real number, which means all sampling points have the same weight, or a vector, which means every sampling point has its own weight.
an area affected by a sampling point in a complex region is smaller than in a flat region.
therefore, a smaller value of λ is selected in a complex region and a bigger value of λ is selected in a flat region.
high accuracy surface modeling can simulate continuous attribute variations in three-dimensional space, and has been successfully used in simulating climate change [17,32,33], constructing dems [28,29], interpolating soil properties [34,35,36] and terrestrial land cover change [19].
for this study, hasm took the approximate xco2 surface as its driving field and the flight retrieved xco2 as its optimum control constraints as shown in equation (15): (15)xsim=hasm(xinitial,xsam) where xsim is the final xco2 surface which is calculated by hasm, xinitial is the approximate xco2 surface which is obtained by regression modeling, and xsam is the retrieval xco2.
the main inputs of hasm are the retrieval xco2 and the approximate xco2 surface with the output being the high accuracy surface of xco2.
4. results 4.1. retrieval xco2 the xco2 concentrations estimated with the full physics retrieval approach for about 400 points in the flight test area covering seven kinds of underlying surface—grassland, water, wetland, farmland, a thermal power plant, urban area and forest land—are shown in figure 7. the retrieval xco2 concentrations ranged from 396.5 to 407.3 ppm with a mode of 396.5 to 397.3 ppm (figure 7).
4.2. approximate xco2 surface in the flight test area in order to model the high accuracy xco2 surface, we first established the approximate xco2 surface using an ordinary linear least squares regression model to represent the spatial relationships in the flight test area (figure 8).
from figure 3 and figure 8, we can see that the mean xco2 of this approximate surface is about 20 ppm lower than the retrieval xco2 surface, but does show the estimated spatial relationships in the flight test area.
it was used as the driving field of hasm, and the retrieval xco2 was used as the optimum control constraints to model the xco2 surface in the flight test area.
4.3. high accuracy xco2 surface the high accuracy surface model took the regression results as its driving field and the retrieval xco2 values as its optimum control constraints to more accurately estimate the xco2 surface in the whole flight test area (figure 9).
the hasm xco2 estimates in the flight test area ranged from 390.0 to 403.6 ppm.
combining the map in figure 9 with the image showing the flight test area (figure 3), we can see that xco2 is highest in songyuan city.
similarly, the xco2 in another small city, taonan, is higher as well.
the xco2 was lower in the xianghai reserve, which includes the limin grassland, hedao wetland and xianghai lake.
the aforementioned results show how human activities can increase xco2 and that the retrieval xco2 calculated in this study was sensitive to the boundary layer which may be affected by human’s activities over relatively short distances.
4.4. comparison with oco-2’s xco2 estimates the orbiting carbon observatory 2 (oco-2) which was launched on 2 july 2014, is nasa’s first dedicated earth remote sensing satellite to study xco2 from space.
oco-2 is collecting space-based global measurements of xco2 with the precision, resolution, and coverage needed to characterize sources and sinks on regional scales.
oco-2 is also able to quantify co2 variability over seasonal cycles year after year.
the oco-2 instrument flies on a dedicated spacecraft and includes three high-resolution grating spectrometers which make coincident measurements of reflected sunlight in the near-infrared co2 near 1610 and 2060 nm and in the molecular oxygen (o2) a-band at 760 nm at a resolution of 1.29 (longitude) and 2.25 km (latitude).
the xco2 (version oco2_l2_lite_fp.7r) at the 14 locations in the flight test area ranged from 396.7 to 398.3 ppm on 11–16 september 2014 (figure 10).
the corresponding hasm xco2 estimates were extracted from figure 9 and used to calculate the differences from the oco-2 xco2 estimates (table 6).
twelve of the 14 hasm xco2 estimates were higher than the corresponding oco-2 estimates (column 6, table 6) with the mean difference and standard deviation being 0.7 and 0.95 ppm, respectively.
given that the accuracy of the oco-2 xco2 estimates is about 1 ppm [37], the hasm modeling results based on the flight test of the tansat instruments fell within the expected range.
5. conclusions this paper presents the validation of xco2 based on a flight test of tansat instruments using a combination of full physics and surface modelling.
the results produced with this pair of methods were nevertheless sufficiently similar to justify using hasm to estimate the xco2 surface.
hasm took the approximate surface of xco2 as its driving field and the flight’s retrieval xco2 as its optimum control constraints to fill in the gaps across the whole flight test area.
the results showed that the xco2 in cities is higher than in other places suggesting that cities are places where human activities can lead to increased xco2 concentrations.
compared with oco-2’s xco2, the mean difference is 0.7 ppm and the standard deviation is 0.95 ppm.
due to the good matching, the surface modelling of xco2 based on the flight test of tansat instruments fell within an expected and accepted range.
the flight test in this study was conducted in good weather conditions, so we assumed the sky was clear when the retrieval xco2 estimates were acquired.
in fact, the presence of clouds and aerosols could influence xco2 and in the future, we plan to consider their impact.
moreover, the co2 strong absorption band (i.e., 2060 nm) contains additional information on co2 and h2o, but we did not use this band for the current flight test due to cost.
therefore, we will conduct xco2 retrieval using three bands from other satellite data before tansat is launched in the future.
@highlight
the tansat carbon satellite is to be launched at the end of 2016. in order to verify the performance of its instruments, a flight test of tansat instruments was conducted in jilin province in september, 2015. the flight test area covered a total area of about 11,000 km2 and the underlying surface cover included several lakes, forest land, grassland, wetland, farmland, a thermal power plant and numerous cities and villages.
we modeled the column-average dry-air mole fraction of atmospheric carbon dioxide (xco2) surface based on flight test data which measured the near- and short-wave infrared (nir) reflected solar radiation in the absorption bands at around 760 and 1610 nm.
however, it is difficult to directly analyze the spatial distribution of xco2 in the flight area using the limited flight test data and the approximate surface of xco2, which was obtained by regression modeling, which is not very accurate either.
we therefore used the high accuracy surface modeling (hasm) platform to fill the gaps where there is no information on xco2 in the flight test area, which takes the approximate surface of xco2 as its driving field and the xco2 observations retrieved from the flight test as its optimum control constraints.
high accuracy surfaces of xco2 were constructed with hasm based on the flight’s observations.
the results showed that the mean xco2 in the flight test area is about 400 ppm and that xco2 over urban areas is much higher than in other places.
compared with oco-2’s xco2, the mean difference is 0.7 ppm and the standard deviation is 0.95 ppm.
therefore, the modelling of the xco2 surface based on the flight test of the tansat instruments fell within an expected and acceptable range.
