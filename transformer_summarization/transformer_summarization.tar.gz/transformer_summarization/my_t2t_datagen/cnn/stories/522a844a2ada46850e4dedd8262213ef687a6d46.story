pulmonary fibrosis (pf) is a progressive and predominantly lethal form of several interstitial lung diseases hallmarked by scarring, hyperplasia of the alveolar cells, alveolar epithelial tissue damage, excess infiltration of fibroblasts and myofibroblasts in the lung tissue, and accumulation of extracellular matrix (ecm) within the tissue.
subsequently, the exchange of gases at the alveoli is affected resulting in lung impairment.
statistical reports estimate the median survival rate of pf as 3 years in 50% of the population affected.
globally, more than five million population have pf, and in european countries each year, incidence of pf ranges between 0.22% and 7.4% per 100,000 population; prevalence is found to be higher among males.
[1] in the present days, pf is emerging as a major public health concern with limited therapeutics.
a recent study investigated on the global burden of pf using medline and embase databases revealed that incidence and mortality of pf are correlated proportionally and are increasing over time.
[2] bleomycin (blm) is a chemotherapeutic antibiotic commonly used to treat testicular, cervical cancers and hodgkin's lymphoma.
however, blm produces pulmonary toxicity and fibrosis as a side effect in a large number of patients due to deficiency of blm hydrolase enzyme that degrades blm into nontoxic metabolites.
[3] further, blm is a well-established and best-characterized experimental model in inducing pf via producing oxidative stress and resembles the human fibrotic condition.
it can be administrated through various routes including intratracheal (it), inhalational, intravenous, intraperitoneal, and subcutaneous.
although there are multiple routes with their own pros and cons, it delivery of blm is widely practiced.
blm delivery via it route involves surgical intervention where an incision is made on the neck to expose the trachea; a complicated process associated with mortality.
besides, fibrosis is restricted to large superior airways rather than affecting the complete lung tissue in it route; therefore considered as a nonhomogeneous distribution of the fluids instilled into the lungs.
[4] further to maintain the homogenous distribution and to induce complete lung fibrosis condition, an alternative model is developed known as oropharyngeal aspiration (opa) which can overcome the limitations of both it and intranasal routes of administration.
besides, opa can also result in reducing the dose required in inducing lung fibrosis.
[5] growing line of evidence suggests that opa was used for the first time in delivering the technetium-labeled sulfur colloid to determine the mucociliary clearance using scintigraphy.
[6] later, a silicosis study was performed to know whether opa can be used as an alternative to it route and interestingly noticed that opa was simpler, superior, stress less, reproducible, and homogeneous in comparison to it administration.
[4] other study performed by egger et al.
reported the production of sustained lung fibrosis via opa administration of blm using histology studies and magnetic resonance imaging (mri) scan in c-57bl/6 and balb/c mice.
[5] a similar model refinement study of chemical-induced asthma in mice was performed where the inhalational route has been replaced by opa wherein opa mimicked condition of human asthma.
[7] further, opa administration of interleukin-13 (il-13) induced metaplasia of goblet cells and provided a simple model to investigate the agents that alter mucus production.
[8] moreover, as an alternative to the aerosol formulation, opa of burkholderia (lethal pathogen) in balb/c mice was investigated and found significant immune response compared to existing models.
[9] the present work highlights the significance of opa as a simple, reliable, noninvasive, and homogeneous route of administration compared to other existing techniques of blm-induced pf model in swiss mice.
the fibrotic responses of lungs exposed to blm are investigated using various biochemical and molecular studies along with pathological examination compared to control mice.
materials and methods materials blm sulfate (cipla labs), chloramine-t, trans-l-hydroxyproline, masson's trichrome staining kit, griess reagent, ehrlich reagent, reduced glutathione (gsh), 5,5-dithio-bis (2-nitrobenzoic acid), 2-thiobarbituric acid (tba), bovine serum albumin (bsa), sodium dodecyl sulfate (sds), glacial acetic acid, sodium nitrite, and bradford reagents were obtained from sigma-aldrich, usa.
all other chemicals were of analytical grade and were obtained commercially.
anti-α-smooth muscle actin (sma), anti-e-cadherin, horseradish peroxidase (hrp) anti-mouse and anti-rabbit antibodies were obtained from santa-cruz biotechnology inc. anti-vimentin and anti-fibronectin primary antibodies were procured from cell signaling technology.
animals male swiss albino mice (8-week-old) were used for the study and maintained with 12-h dark/light cycle in a conventional animal house at ambient temperature.
animals were acclimatized for 1 week before the experiment and provided with access to food and water ad libitum.
all the animal experiments were carried under due approval of the institutional animal ethics committee of niper-hyderabad, in accordance with the committee for the purpose of control and supervision on experiments on animals guidelines of the government of india.
oropharyngeal aspiration of bleomycin in swiss mice the animal was anesthetized using 2% isoflurane, and when light plane anesthesia was attained, the animal was placed on mouse intubation platform (penn-century, inc., wyndmoor, pa, usa) at 60° inclined angle.
water for injection was used as a vehicle in control animals.
the tongue of mice was pulled and hold with forceps, blm (2 iu/kg) was administered into the distal part of the oral cavity (oro-pharynx) using pipette, and nose was gently closed until the liquid got disappeared.
the tongue was released back till gasp of the animal was completely stopped; respiration was critically monitored and placed the animal in a vertical position.
animals were returned to the home cage after recovery of anesthesia.
the procedure of opa was performed twice on alternative days (day 0 and day 2) with 1 iu/kg each time and the study was terminated after 21 days.
lung-body weight index and lung morphology body weights were taken once in a week and lung weights were taken on the day of sacrifice, lung morphology was observed, and images were captured, followed by snap freezing of samples.
lung-body weight index was calculated to identify the potential harmful effect of blm on lung.
bronchoalveolar lavage fluid analysis mice were euthanized, a small incision was made on the trachea, and suitable catheter was used to insert into the trachea so as to collect bronchoalveolar lavage fluid (balf).
later, 1 ml of ice-cold phosphate-buffered saline was injected into lungs and balf was gently aspirated using a catheter.
the procedure was repeated thrice, and 70% recovery of collected balf was observed.
balf collected thrice of the same group were pooled, centrifuged at 5000 rpm, supernatant and pellet were separated.
total protein and albumin content were estimated in balf supernatant using commercially available kits (accurex biomedical pvt., ltd.).
bal pellets were redispersed and subjected to lymphocyte estimation.
analysis of oxidative stress parameters tris-hcl buffer was used to homogenize the lung tissues.
lipid peroxidation assay by tba-reactive substances (tbars) method was performed in total lung tissue homogenates to estimate the oxidative stress.
[10] nitric oxide estimation was done by griess reagent method, and measurement of gsh levels using gsh reductase was performed in the supernatant by ellman's method.
[11] protein concentrations of both homogenates and supernatants were estimated using bradford assay, and bsa was used as a standard.
hydroxyproline estimation the concentration of hydroxyproline in lung tissues was performed using the method as described by woessner with slight modifications.
[12] tissue homogenates were allowed to undergo acid hydrolysis for 2 h at 120°c in an autoclave.
after cooling of the samples, ph of 7.4 was adjusted and treated with chloramine-t for 20 min at room temperature followed by addition of aldehyde-perchloric acid incubated for 15 min at 60°c, samples were brought to room temperature, centrifuged, and absorbance of samples was read at 550 nm.
hydroxyproline was used as a standard.
histopathological examination and masson's trichrome staining lung tissues collected from control and blm-treated groups after the sacrifice were fixed in 10% nonbuffered formalin solution.
fresh formalin solution was replaced after 24 h of fixation and beforehand of the experiment; fixed tissues were processed using gradient alcohols and xylene, subjected to paraffin infiltration followed by the embedding of the tissue.
later, the embedded tissues were made into 5-µm thick sections using microtome and subjected to hematoxylin and eosin (h and e) staining to observe pathological changes in the tissue.
further, to estimate the excess collagen deposition in the lung tissues, sections were stained with masson's trichrome staining.
tumor necrosis factor-α, interleukin-6, and transforming growth factor-β quantification by elisa expression of pro-inflammatory cytokines including tumor necrosis factor-α (tnf-α), il-6, and pro-fibrotic cytokine transforming growth factor-β (tgf-β) in lung tissue supernatants of control and blm-treated groups was evaluated using commercially available elisa kit (ebioscience, usa).
western blot analysis lung tissues were lysed with tissue protein extraction reagent buffer mixed with protease cocktail mixture and phosphatase inhibitor using homogenizer maintained at 2000 rpm and 4°c; the supernatant was collected after centrifugation at 12,000 rpm for 10 min and stored at −20°c or used immediately.
protein concentration was determined using bradford protein estimation assay.
equal amounts of protein were separated on sds-polyacrylamide gels and transferred onto polyvinyl difluoride membrane.
after transfer, protein of interest was blocked for nonspecific binding (5% nonfat dry milk in tris-buffered saline-tween (tbst) (0.1%), incubated with primary antibody overnight.
blots were probed with anti-α-sma (mouse monoclonal antibody, dilution 1:1000); anti-vimentin (rabbit monoclonal antibody, dilution 1:1000); anti-e-cadherin (rabbit monoclonal antibody, dilution 1:1000); and anti-fibronectin (mouse monoclonal antibody, dilution 1:1000).
after overnight incubation, blots were washed thrice with tbst, each time for 10 min, and incubated with hrp-conjugated secondary antibody for 1 h at room temperature.
membranes were visualized using enhanced chemiluminescence reagents, and the protein bands were subjected to a densitometry analysis using imagej software.
the membranes were probed with β-actin antibody as an internal control and to ensure equal loading.
each blot shown is a representative of at least three independent experiments.
statistical analysis data are expressed as means ± standard error of mean (n = 6) and analyzed with unpaired t-test using graphpad prism version 5. p < 0.05 was considered statistically significant.
results lung-body weight index and lung morphology before induction of blm, there were no significant differences in body weights of the animals in all groups.
at the termination of the study, significant changes in body and organ weights were observed, evident by lung-body weight index as shown in figure 1a.
lung weights in blm-treated group were significantly increased compared to control group, may be attributed due to the accumulation of excess ecm.
further, visible morphological changes of fibrotic induction were observed in blm group as mentioned in figure 1b compared to control group.
figure 1 effect of oropharyngeal aspiration administration of bleomycin on lung index and lung morphology.
(a) change in lung index and (b) significant fibrotic induction by oropharyngeal aspiration-bleomycin on lung morphology.
data are represented as means ± standard error of mean (n = 6).
***p < 0.001 of bleomycin versus control bronchoalveolar lavage fluid analysis as total protein and its constituent albumin are abundantly expressed in alveolar epithelium, the effect of blm on these specific proteins is being investigated as mentioned in figure 2. significantly increased expression of total protein and albumin in blm-treated group reflected the altered integrity of alveolar barrier and damage to the epithelial fluid lining compared to control group where normal lung architecture is not affected.
further, significant lymphocyte accumulation in balf was noticed.
figure 2 changes in bal fluid parameters by oropharyngeal aspiration administration of bleomycin.
concentrations of (a) albumin, (b) total protein, and (c) lymphocytes in bronchoalveolar lavage.
data are represented as means ± standard error of mean (n = 6).
*p < 0.05, **p < 0.01, ***p < 0.001 of bleomycin versus control analysis of oxidative stress parameters and hydroxyproline the role of blm on biochemical parameters including lipid peroxidation, gsh levels, nitric oxide, and hydroxyproline expression was investigated as depicted in figure 3. lipid peroxidation that functions as a marker of tissue damage by oxidative stress is significantly (p < 0.01) elevated in blm-treated group as evident from tbars level expressed as microgram per milligram of tissue protein.
a significant decrease (p < 0.01) in levels of gsh (endogenous antioxidant) is noticed in blm-treated groups compared to control.
further, expression of nitric oxide is significantly (p < 0.001) enhanced in blm-treated group with that of control group.
the concentration of hydroxyproline (collagen accumulation) in blm-treated group after 21 days is significantly (p < 0.001) higher than in normal control.
figure 3 effect of oropharyngeal aspiration administration of bleomycin on biochemical parameters in lung tissues.
concentrations of (a) malondialdehyde, (b) glutathione, (c) hydroxyproline, and (d) nitric oxide.
data are represented as means ± standard error of mean (n = 6).
**p < 0.01, ***p < 0.001 of bleomycin versus control histopathological examination and masson's trichrome staining to evaluate the pathological changes and collagen deposition in lung tissues of blm-treated mice, h&e, and masson's trichrome stain were performed as shown in figure 4. in lung sections of blm-treated mice, distorted lung architecture is observed with severe thickening of alveolar walls.
besides, accumulation of inflammatory cells in lung sections significantly evidences the fibrotic progression induced by blm via opa aspiration.
moreover, dense collagen distribution in lungs is observed on opa blm administration compared to control group, revealed by masson's trichrome staining.
figure 4 pathological examination elucidating the effect of oropharyngeal aspiration administration of bleomycin using h and e and masson's trichrome staining.
(a and b) h and e lung sections, (c and d) masson's trichrome-stained lung sections of control and oropharyngeal aspiration-bleomycin group, respectively (×100) tumor necrosis factor-α, interleukin-6, and transforming growth factor-β quantification by elisa tgf-β is a key fibrotic cytokine in the progression of pf while other pro-inflammatory cytokines that exert their role in pf include tnf-α and il-6.
thus, the above-mentioned cytokines were investigated for their altered expression in blm-treated group as mentioned in figure 5. significantly elevated levels of both pro-inflammatory and fibrotic cytokines (p < 0.001) are observed in mice administered with blm via opa.
figure 5 effect of oropharyngeal aspiration administration of bleomycin on fibrotic and inflammatory cytokines.
(a) transforming growth factor-β1, (b) tumor necrosis factor-a, and (c) interleukin-6, respectively.
data are represented as means ± standard error of mean (n = 6).
*p < 0.05, ***p < 0.001 of bleomycin versus control western blot analysis stressing the importance of epithelial-mesenchymal transition (emt) in fibrosis, the effect of blm on epithelial marker e-cadherin and mesenchymal markers including α-sma, fibronectin, and vimentin was evaluated as shown in figure 6. western blot analysis revealed the decreased expression of e-cadherin (p < 0.05) and significantly increased expression of α-sma (p < 0.01), fibronectin (p < 0.001), and vimentin (p < 0.0001) in blm-treated groups compared to control group.
figure 6 significant changes in expression of epithelial and mesenchymal markers on oropharyngeal aspiration administration of bleomycin.
(a) e-cadherin, (b) α-smooth muscle actin and (c) vaimentin, and (d) ?bronectin, respectively, and respective densitometric analysis were normalized with β-actin.
*p < 0.05, **p < 0.01, ***p < 0.001, ****p < 0.0001 of bleomycin versus control discussion it instillation is a traditional and standardized model in inducing pf.
although it is a reliable and well-established model in investigating the efficacy of compounds against pf, there exist some limitations including invasive surgical intervention and nonhomogeneous disease induction.
thus, opa is emerged as a simple alternative technique to replace it instillation due to homogenous distribution and reproducibility.
opa is practiced for the first time in the last decade to assess mucociliary clearance, and then onward, it is adapted as a simple technique to screen the therapeutic compounds against respiratory disorders including asthma, assessing mucociliary function, immune system disorders, and fibrosis.
existing reports of silicosis suggested the superiority of opa model against it instillation wherein a detailed comparative study between opa and it routes using silica suspension was performed in c57bl/6 mice.
toward this context, another study is emerged to compare both opa and it routes in blm-induced fibrosis in both c57bl/6 and balb/c mice using histology and mri scan techniques.
along with the advantage of opa with respect to the route of administration, the study emphasized the significant reduction in the amount of blm dose to be administered to the mice via opa route compared to it.
the present study is designed to induce fibrosis using opa administration of blm in swiss mice and to investigate the effect of blm administered via opa by various biochemical and molecular techniques.
opa administration resulted in significant visible morphological differences after 21 days between blm-treated group and control group.
in pf induced by blm, 5%–10% decrease of body weight in blm-induced animals is being reported.
[13] however, lung weights of the blm-treated group increase due to ecm accumulation.
lung index of blm treatment group was significantly increased by 2.94 folds in comparison to control group.
increased expression of total protein and albumin levels evident from balf analysis reflects the significant alveolar epithelial damage, and results of the study revealed significantly elevated levels of both total protein (1.82 folds) and albumin (1.84 folds) in blm-treated mice consistent with the literature to that of control.
accumulated evidence explain the crucial role of oxidative and nitrative stress in blm-induced pf.
[1415] thus, lung tissues were subjected to estimation of endogenous antioxidant gsh, expression of nitric oxide, and extent of lipid peroxidation.
significant suppression of gsh expression (1.36 folds) and increase in lipid peroxidation (2.14 folds) in blm-treated group compared to control group confirmed the increased levels of oxidative stress in blm group administered via opa.
similarly, significant elevation of nitric oxide levels depicts the enhanced effect of nitrative stress (3.46 folds) in the blm-treated group.
hydroxyproline, a key biomarker in fibrotic disorders that propel the amount of collagen deposited is significantly increased in blm-treated group than control group.
accumulation of ecm and excess collagen deposition is reported to be indulged in fibrosis.
[16] as speculated, dense deposition of collagen is observed in blm-treated group as evident from histopathological examination and masson's trichrome staining techniques.
aberrant expression of pro-inflammatory cytokines including tnf-α and il-6 gain importance in pf.
[1718] thus, evaluation of these markers was investigated by elisa.
significant increase in levels of both tnf-α (2.5 folds) and il-6 (2.31 folds) were noticed in blm-treated group after 21 days with that of control group.
tgf-β1 functions as a master regulator in inducing fibrotic signaling events and its expression in fibrosis are upregulated on blm administration.
[19] the concentration of tgf-β1 significantly increased by 1.57 folds in animals administered with blm via opa compared to control group.
tgf-β1 activation stimulates emt process and hence aids in the transformation of epithelial cells into mesenchymal cells and results in accumulation of ecm in lung tissue.
[20] immunoblot analysis performed for emt markers confirmed the induction of fibrosis in the lung on blm administration via opa route.
blm treatment attenuated the expression of epithelial marker e-cadherin by 1.31 folds and increased the levels of mesenchymal markers including sma, vimentin, and fibronectin by 1.91, 15.21, and 2.38 fold change, respectively, with that of control group.
taken together, all the above-mentioned experimental results suggest the use of opa-blm model to induce pf in swiss mice.
although it comparison was not made with opa, results of all the performed parameters at both biochemical and molecular levels correlate with the reports published where blm was administered via it route.
taken together, this model of opa-blm offers a simple, reproducible, homogeneous, and noninvasive technique to induce pf in swiss mice and to identify various novel anti-fibrotic agents.
conclusion the present work demonstrates the use of opa as a simple, reliable, homogeneous, and noninvasive alternative technique to it instillation of blm for induction of pf in swiss mice.
biochemical and molecular effects of blm reflect the prominent induction of fibrotic disease, and therefore, opa-blm model may function as an alternative model to it-blm in investigating the therapeutic potential compounds in pf.
financial support and sponsorship this study was supported by the ministry of chemicals and fertilizers.
conflicts of interest there are no conflicts of interest.
@highlight
objective: pulmonary fibrosis (pf) is a progressive and predominantly lethal form of several interstitial lung diseases with limited current therapeutics; it is, therefore, essential to develop a simple, homogeneous, and noninvasive disease model to investigate possible anti-fibrotic approaches.
the present study is designed to develop oropharyngeal aspiration (opa) model of bleomycin (blm)-induced pf as a simple and alternative to intratracheal (it) administration of blm in swiss mice strain.
materials and methods: mice were divided into two groups, blm-treated and normal control.
blm via opa (2 iu/kg) was used to induce pf.
water for injection was used as a vehicle in control animals.
body weights were measured once in a week, and the study was continued for 21 days.
at the end of the study, animals were euthanized and bronchoalveolar lavage fluid was collected and subjected to lymphocytes count, estimation of albumin and protein levels.
lung tissues were collected, and various biochemical assays (malondialdehyde, glutathione, nitric oxide, hydroxyproline) and molecular techniques including elisa and western blot were performed to investigate the effect of opa-blm.
further, histopathology and masson's trichrome staining techniques were performed in lung sections.
results: opa administration of blm in swiss mice significantly induced pf, evident from lung index and morphology.
several oxidative stress parameters and hydroxyproline assay revealed the significant (p < 0.05) induction of pf.
further results obtained from histopathology, masson's trichrome staining, elisa, and western blot confirmed the significant induction of pf via opa-blm.
conclusion: blm administration by opa route in swiss mice can be used as a simple, homogeneous, and noninvasive model of inducing pf and to investigate the effect of various anti-fibrotic agents as an alternative to it-blm.
