introduction hypospadia is one of the most common congenital deformities in humans.
its incidence varies between 1:1000 and 1:100 births (1, 2).
the etiology is not fully understood, but there are theories involving testosterone deficiency, multifactorial causes, genetic predisposition, tissue remodeling and others (3).
the recommended treatment is surgery at between six and twelve months of age (4).
the choice of optimal method depends on anatomical factors, one of the main challenges in surgery for severe hypospadias is the correction of severe ventral curvatures, especially in cases where only a dorsal plication is not sufficient to straighten the penis shaft, and ventral lengthening of the corpus cavernosum is necessary.
a number of tissues have been used as grafts to restore corpora integrity after corporotomy; the main ones are the tunica vaginalis flap, the dermal allograft and the porcine intestinal submucosa (5).
we aimed to evaluate histologically in an animal model the hypothesis that surgical repair of hypospadias with severe ventral curvatures might be completed in one stage, if a graft, such as buccal mucosa, could be placed over the tunica vaginalis flap used in corporoplasty for ventral lengthening, with the addition of an onlay preputial island flap to complete the urethroplasty.
the study focuses on assessing the dogma if grafting over a flap tissue is feasible.
materials and methods we designed an experimental study approved by the institutional ethical review board.
we treated 8 male rabbits of the species oryctolagus cuniculus from a new zealand strain, weighing between 2.0kg and 2.5kg.
the sample was divided into 4 groups of 2 of animals, according to the date of euthanasia: sacrificed after 2, 4, 6 and 12 weeks.
surgical technique we obtained a 1.0 × 0.5cm buccal mucosa graft from the donor jugal area.
using sterile techniques and a 3.5 × optical magnifying glass, the penis was freed by incising the fold between the ventral penile portion and the anus, facilitating access to the urethra.
after exposing the urethra, the penile portion of it was completely separated from the corpus cavernosum, exposing the tunica albuginea.
the urethra was entirely sectioned transversally, and the urethral stumps were fixed to the corpus cavernosum with 6.0 pds suture thread, maintaining a distance of 1cm.
the left hemiscrotum (rabbits have two independent hemi scrotum) was incised and the tunica vaginalis separated from the testicle to obtain a flap that could reach the urethra.
a subcutaneous tunnel was then created, so that the flap obtained could pass through the tunnel and reach the urethra.
the corpus cavernosum exposed by the incision of the urethra was repaired with pds suture 6.0, to enable repair of a defect in it, by sectioning the tunica albuginea of the corpus cavernosum over an area of 0.5 × 0.5cm, simulating a corporotomy.
at this point, there was intense bleeding which was controlled by suturing the tunica vaginalis flap (visceral surface) to the edge of the defect of the corpus cavernosum with pds 7.0, in continuous form, along three quadrants (upper, lower, and right side), keeping the pedicle of the tunica free (figure-1).
the buccal mucosa graft was then positioned over the tunica vaginalis and sutured with continuous pds 7.0 stitches, connecting the shorter edges of the graft to the back part of the urethral stumps, thereby reconstructing the urethral plate (figure-1).
a 1.0 × 0.4cm longitudinal flap was then made out of the inner foreskin of the rabbit's penis.
for this, two anchor stitches were applied to the inner foreskin, on the ventral surface, 1cm from the boundary between the skin and the mucosa.
thus, the parietal surface of the foreskin was exposed, to comprise the lumen of the future neourethra when laid over the urethral anastomosis (figure-1).
we opted to use a flap of the ventral foreskin, avoiding transposition of the flap from the dorsal to the ventral surface, simplifying and streamlining the procedure.
in this way, after defining the flap, it was rotated from distal to proximal, thereby covering the urethral defect, to complete the neo urethroplasty.
after rotating the flap, a continuous suture of the neourethra was made with pds 7.0 thread.
following the urethroplasty, reconstruction of the penile skin was completed with the synthesis of subcutaneous tissue and genital skin, with separate stitches of catgut 4.0. the urethral catheter was withdrawn at the end of the procedure.
neither drains nor cystostomy were used postoperatively.
figure 1 step-by-step description of the technique consisting of a tunica vaginalis flap for reconstruction of the corpora after corporotomy.
a buccal mucosa graft was placed directly on top of the flap, and the urethroplasty was completed with an onlay preputial island flap.
gross histological analysis a macroscopic analysis of the rabbit's penis was conducted looking for scar healing, external appearance, and the presence of complications such as fistula or diverticulum.
to evaluate the presence of stenosis, the urethra of each animal was catheterized with a urethral tube.
the penis was sectioned at its base, preserving the corpora cavernosa and corpus spongiosum, and immediately fixed in 10% formaldehyde for a period up to 20 days.
microscopic analysis the pieces were sectioned transversally in 3mm slices, allowing the inclusion of 4 transversal segments of the same penis in each block, which were processed using the normal technique for embedding in paraffin.
slices of whole penis were included, from the glans, passing through the region that was operated on, to the base, and analyses at 40, 100, and 400 × magnification were performed with an optical microscope (nikon eclipse e 600).
the paraffin blocks were cut to a thickness of 5 microns, with a rotary paraffin microtome, and stained with hematoxylin eosin (he) and masson (tm).
a histological evaluation was conducted with an optical microscope by a single pathologist, specialized in the urogenital tract and experienced in the analysis of rabbit urethra (srra).
the pathologist had no knowledge of the date of euthanasia of each case, and analyzed all the slides on the same day at the end of the study (figure-2).
figure 2 histological aspect of the reconstructed urethra in which dorsal component consisted of a transitional urothelium and ventral component of a stratified scamous epithelium (group 8 weeks, he × 40).
the predominant inflammatory phenomena (intensity of acute and chronic inflammation), the presence and intensity of fibrosis, the type of revetment epithelium of the neourethra, and especially, any epithelial changes that occurred postoperatively were evaluated, as well as any complications.
an acute inflammatory reaction was defined as the predominant presence of polymorphonuclear leukocytes, and a chronic inflammatory reaction was defined by the predominant presence of lymphoplasmacytic infiltrate.
semiquantitative analysis of the inflammatory reaction was based on the following criteria: a score of zero for the absence of an inflammatory reaction, a score of 1 for minimal inflammation, 2 for moderate inflammation, and 3 for extensive inflammation characterized by abscesses or microabscesses for the acute type, and the presence of aggregations of lymphocytes for the chronic type.
fibrosis was characterized by the presence of fibroblasts replacing normal tissue with collagen deposits, and calculated by the distance between the urethral lumen and the beginning of the corpus cavernosum, using scores of 1 (minimal fibrosis), 2 (moderate), and 3 (maximum).
the types of epithelia considered were transitional cell epithelium (urothelium), non-keratinized stratified epithelium (buccal mucosa), and keratinized stratified epithelium (lining of the inner foreskin).
the complications looked for were fistulas, diverticula, stenosis, and dehiscence.
the results of the histological analysis of the eight animals are shown as descriptive values and frequencies, and no statistical analysis was performed.
there were no missing values to deal with.
results in the first postoperative week, intense hyperemia of the surgical wound and scrotal edema were observed in all eight animals.
in the pair of animals sacrificed at two weeks, an increase in scrotal edema was noted, with one rabbit presenting necrosis of the scrotal skin, as well as an urethro-cutaneous fistula and inflammation of the surgical site, leading to death.
the outcome of the other animal was satisfactory, and euthanasia was performed at 14 days.
in the animals in group 2 (four weeks), the presence of urethra-cutaneous fistula was noted from the second week and persisted until the time of euthanasia.
however, an apparent improvement of the scrotal edema was observed.
the presence of fistula was confirmed in both rabbits in group 3 (eight weeks).
one rabbit made good initial progress, but evolved with a voluminous urethra-cutaneous fistula and died at 53 days.
the animals in group 4 (sacrificed at 12 weeks) had good postoperative evolution.
one of the animals presented leakage of urine from the proximal edge of the wound during the first week, which stopped spontaneously.
the other animal did not have fistula.
catheterization was not possible in four of the six animals with fistula.
we consider only two of the animals, one from the 2 week group and one from the 12 week group, to have evolved without complications (table-1).
these animals were evaluated within six hours following the lethal event.
both had moisture in the genital region, indicating the presence of urethra-cutaneous fistula and difficulty inserting the tube.
after removing the tube, drainage of a large amount of urine was observed, characteristic of urinary retention caused by stenosis.
in the other animals, there were no difficulties with tube insertion.
table 1 description of surgical complications.
group animal complications group 1 (2 weeks) animal 1a necrosis of the scrotal skin/urethrocutaneous fistula/death animal 1b normal group 2 (4 weeks) animal 2a urethrocutaneous fistula animal 2b urethrocutaneous fistula group 3 (8 weeks) animal 3a urethrocutaneous fistula / death animal 3b urethrocutaneous fistula group 4 (12 weeks) animal 4a urethrocutaneous fistula (spontaneous resolution) animal 4b normal microscopic results for a better evaluation of microscopic phenomena, the inflammatory findings, fibrosis, characteristics of the epithelium, and characteristics of the chorion are shown in table-2.
table 2 microscopic findings of four groups in regards to inflammatory cells, fibrosis, epithelium and complications.
2 weeks 4 weeks 8 weeks 12 weeks polymorphonuclear infiltrate 2+ 1 to 2+ 1 to3+ 1+ fibrosis 1 to 2+ 1 to 3+ 2+ 1+ urethral epithelium stratified stratified stratified stratified transition transition transition transition epithelium epithelium epithelium epithelium complications pyocytes pyocytes fibrin crust leukocyte foreign body reaction foreign body reaction granulation tissue ulcerations discussion hypospadias repair is a challenging topic of urogenital reconstructive surgery, and many different techniques are currently being used (6).
around 10% of patients with proximal hypospadias have true chordees (7).
in our study, we made an ambitious three concept proposal to correct complex hypospadias with: 1) dorsal buccal mucosa graft for replacement urethroplasty, ventral flap of foreskin for the ventral region of the penis and tunica vaginalis flap for corporoplasty; 2) the tunica vaginalis flap overlaying the onlay buccal mucosa graft for the urethroplasty; and 3) all this in a one-stage procedure.
two stage repair is the most commonly used technique in proximal hypospadias or in hypospadias with severe chordee, where it is necessary to section the urethral plate for correction (6, 8, 9).
in fact, in cases where it is necessary to perform corporoplasty in addition to plate sectioning, there appears to be a consensus that two stage repair is preferable, with a variety of techniques used for corporoplasty (6).
however, the development of a one stage procedure for complex hypospadias is still being investigated (10).
substitution tissues possibly used in urological surgery are the arteries, veins, the ureter, the cecal appendix, the skin, bladder and buccal mucosa.
tunica vaginalis has been used extensively in surgery for the treatment of peyronie's disease and chordee (11, 12), in the prevention of fistula and to cover suture stitches.
clinical (13) and experimental studies support the use of tunica vaginalis as a flap for ventral corporoplasty (11, 13) and urethral reconstructions, with one dorsal and one ventral “onlay” flap (14).
an experimental study with rabbits comparing the tunica vaginalis as a flap with the same tissue as the graft found that the flap had good integration, but the same was not true for the graft (11).
in an experimental study with rabbits in our university (15), the buccal mucosa showed good integration results.
histological results showed no fibrosis, retraction or necrosis in 12 rabbits after 6 weeks.
that study inspired us to use buccal mucosa in our experiment.
however, while in that study only moderate, acute inflammation was seen, we observed intense inflammation in the whole sample, with ulceration and neutrophil collections in two to four weeks.
we attribute this inflammation to the surgical procedure as a whole.
in 2007, leslie et al.
analyzed the use of the tunica vaginalis as a dorsal graft associated with an onlay island flap of the foreskin in urethral reconstruction surgery in rabbits, through a histopathological analysis.
histological evaluation demonstrated good incorporation of the tissues.
the authors concluded that in rabbits, the histological evaluation of a tunica vaginalis graft, applied dorsally over the corpora cavernosa, combined with an onlay flap of the inner foreskin, presented total integration with the adjacent urothelium, good tolerance, and a low level of complications (fistula and diverticulum) (14).
the study by leslie et al.
is similar to ours in its creation of a complex surgical procedure that evaluated a dorsally applied tunica vaginalis graft, as in the analogous three-in-one technique (16).
once again it is worth noticing that even in a complex procedure, also involving a flap and a graft to perform replacement urethroplasty, we observed far fewer complications.
in the animals euthanized at 12 weeks (group 4), there was a reduction in polymorphonuclear cells and an increase in lymphoplasmacytic infiltrate.
we also noted that the characteristics of the epithelium of these rabbits were entirely different from the other groups, in which acute inflammation predominated and the squamous epithelium presented ulcerations even to the point of necrosis, probably attributable to the surgical trauma as a whole (figure-3).
in 2001, hafez et al.
compared the application of the tunica vaginalis as a flap versus a graft for the correction of a defect of the tunica albuginea.
in this evaluation, the flap showed evidence of an intact blood supply, viability of the cremasteric musculature without necrosis, and collagen remodeling at 12 weeks (11).
in contrast, our study did not identify the tunica vaginalis in the histological analysis.
we were not able to confirm the presence of the tunica vaginalis mesothelium in our slides.
thus, despite having used a technique similar to theirs, our results regarding the tunica vaginalis did not concur (11).
there was no viability of the tunica vaginalis.
we suggest that this must be related to the buccal mucosa graft that did not consolidate, leading to intense inflammation and loss of the flap.
this study was proposed with the purpose of developing, in an animal model, a surgical technique that enabled a corporoplasty to be performed with a tunica vaginalis flap and urethroplasty with a buccal mucosa graft in a single surgery.
however, we are faced with a belief in reconstructive surgery: to apply a graft directly over a flap.
we did not find any studies testing this approach, and so we decided to test it.
figure 3 histological representation of epithelial erosion and presence of necrotic tissue in the luminal area of the urethra (group 2 weeks, he × 40).
previous studies on hypospadias repair in our university presented very good results, with no natural deaths and two cases of fistula in the 16 rabbits in one study (14) and no complications in the other two (15, 17).
in contrast, we observed two deaths (at two and eight weeks) and six animals with fistula, four of which presented urinary retention and urethra stenosis.
our complications were, therefore, more frequent and more severe.
our results were very heterogeneous among the rabbits, in terms of both clinical evolution and histological results, which we must interpret carefully.
we observed unfavorable clinical outcomes overall, with all animals showing scrotal edema and intense wound hyperemia, progressing to a large number of complications.
in the first week, we observed fistula in six animals (75%), three with a high volume of urine release.
these data conflict with those from previous studies that involved only one tissue replacement.
histological findings confirm the unfavorable clinical findings, with a pattern of large structural changes, highlighting the absence of epithelialization and tissue regeneration, as well as intense inflammation and architectural lesions, producing fistula (figure-4), and complicating the repair process.
we also observed the formation of abscesses in four animals, with necrosis and a large amount of pyocites, mainly in the urethral lumen.
the technique seemed inadequate, considering the high number of complications and unfavorable clinical outcomes.
we believe that there is a multifactorial explanation for the failure of the procedure.
we understand the complicating factors to be: the complexity of the surgical procedure, the extensive tissue manipulation, with prolonged surgical time, the combined use of dorsal flap and graft, the experimental defect produced in the corpus cavernosum, and the corporoplasty with urethroplasty.
which of these factors contributed to the failure of the procedure failure is something to be investigated in larger samples, with more control groups.
therefore, we recommend performing the surgery for the correction of complex hypospadias in two stages, and discourage the use of graft over flap in clinical series.
figure 4 histological aspect of urethral ulceration and fistula formation with marked inflammatory process (group 2 weeks, he × 40).
conclusions the experimental model of complex hypospadias corrected with dorsal buccal mucosa graft for replacement urethroplasty, ventral flap of foreskin for the ventral region of the penis, and tunica vaginalis flap for corporoplasty; with the tunica vaginalis flap overlaying the onlay buccal mucosa graft for the urethroplasty; and one stage procedure, has resulted in a high number of complications, observed both histologically and in the clinical evolution of the experimental animals.
it is not recommended that this procedure for complex hypospadias be reproduced, until the reasons for the failure have been identified.
@highlight
abstract purpose: to develop a rabbit experimental study to test the hypothesis that surgical repair of hypospadias with severe ventral curvatures might be completed in one stage, if a graft, such as buccal mucosa, could be placed over the tunica vaginalis flap used in corporoplasty for ventral lengthening, with the addition of an onlay preputial island flap to complete the urethroplasty.
materials and methods: the experimental procedure with rabbits included a tunica vaginalis flap for reconstruction of the corpora after corporotomy, simulating a ventral lengthening operation.
a buccal mucosa graft was placed directly on top of the flap, and the urethroplasty was completed with an onlay preputial island flap.
eight rabbits were divided into 4 groups, sacrificed at 2, 4, 8 and 12 weeks postoperatively, and submitted to histological evaluation.
results: we observed a large number of complications, such as fistula (75%), urinary retention (50%) and stenosis (50%).
there were two deaths related to the procedure.
histological evaluation demonstrated a severe and persistent inflammatory reaction.
no viable tunica vaginalis or buccal mucosa was identified.
conclusions: in this animal model, the association of a buccal mucosa graft over the tunica vaginalis flap was not successful, and resulted in complete loss of both tissues.
