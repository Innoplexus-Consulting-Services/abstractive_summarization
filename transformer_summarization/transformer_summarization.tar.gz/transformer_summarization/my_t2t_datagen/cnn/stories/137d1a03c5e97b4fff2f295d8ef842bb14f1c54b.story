introduction systemic lupus erythematosus (sle) is a chronic autoimmune disease with multisystem involvement.
it is characterized by periods of increased disease activity caused by the inflammation of blood vessels and connective tissue.
the progression of the disease in pediatric patients is more active than in adults.
[1] in spite of the availability of various treatment options, the optimal therapy still remains to be defined.
mycophenolate mofetil (mmf) is one of the drugs used in the treatment of sle.
[23] mmf is immediately converted to mycophenolic acid (mpa) which is then metabolized to the inactive mpa glucuronide (mpag) in the liver.
[4] mmf, having a lower incidence of toxicity, is commonly prescribed by clinicians for the treatment of sle due to a favorable comparison with cyclophosphamide and corticosteroids.
kazyra et al.
reported that mmf when used in induction and remission therapy for children with sle (with and without confirmed lupus nephritis) effectively treated 71–83% of patients, with minimum side effects.
[5] falcini et al.
also reported about 69% response when mmf was used in children with sle, both with and without renal involvement, for induction and maintenance.
[3] fujinaga et al.
reported that mmf was effective as maintenance therapy without side effects when used in children with severe lupus nephritis after low-dose of intravenous cyclophosphamide was used to induce remission.
[6] zahr et al.
recommended a target area under the curve (auc)(0-12) > 35 mg.h/l to have an improved clinical efficacy in adult sle patients.
[7] sagcal-gironella et al.
also predicted an auc(0-12) above 30 mg.h/l was suggestive of an improved outcome in adolescents with sle.
[8] daleboudt et al.
reported that an mpa dose optimized to produce an mpa auc(0-12) of 60–90 mg.h/l, in adult lupus nephritis, was associated with satisfactory clinical outcome 1-year after therapy, when used after low-dose iv cyclophosphamide, although with 37.5% incidence of adverse events.
[9] neumann et al.
recommended a target mpa trough concentration between 3.5 μg/ml and 4.5 μg/ml to have an effective outcome in adult sle patients but have reported only a moderate correlation between mpa trough and auc(0-12).
[10] there are fewer studies that report the pharmacokinetics of mpa in children with sle.
[10] mina and brunner concluded that children frequently required higher doses of corticosteroids and immunosuppressants compared to adults with sle.
[11] the cost of treatment in pediatrics sle was reported roughly three times higher than in adults.
[12] the dose of mmf currently prescribed in children in our center is 1000–2000 mg/day, with the dose being adjusted according to either clinical response or biomarkers.
sagcal-gironella et al.
reported that the correlation between weight adjusted mmf dose and mpa auc(0-12) was unsatisfactory, and they reported a significant interindividual variability of 57% in the mpa auc(0-12).
[8] in our institution, performing therapeutic drug monitoring (tdm) in renal transplant patients has proved invaluable for the adjustment of the mmf dose.
limited sample strategy (lss) equations developed in other ethnic groups were not applicable to our population and a population specific lss was established for renal transplant patients of indian origin.
[13] optimization of the drug concentration is the ultimate goal of any drug regimen.
monitoring mpa auc(0-12) in children is a challenge due to a number of blood specimens required to determine the inter-dose auc(0-12).
using a lss, we can reduce the mental trauma to a child and their parents with the additional benefit of reducing the cost of the test.
[12] the purpose of this study was to establish a lss to predict the mpa auc(0-12h) in children with sle.
methods study design and patients institutional review board approval was obtained (irb number: 7699).
after informed consent was given 26 children (17 females and 9 males) diagnosed with sle, were recruited into the study between april 2012 and december 2012. children were prescribed mmf (mmf® - ipca laboratories ltd., mumbai, india) with daily doses ranging from 1000 mg to 2000 mg, administered twice daily.
three months later the child presented, after an overnight fast, for monitoring of mpa to the clinical pharmacology unit.
an intravenous cannula was inserted into a forearm vein and blood was withdrawn prior to mmf and then at 0.5 1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 8.0, and 12.0 h after the mmf dose.
plasma was separated within 10 min of blood collection and stored at −20°c until analysis.
plasma mpa was analyzed using a validated isocratic reversed phase high performance liquid chromatographic method with ultraviolet detection.
[14] statistical analysis total 12 h mpa auc was calculated using the trapezoidal rule.
the maximum concentration (cmax) and time to achieve the maximum concentration (tmax) were noted.
mpa concentrations at each of the sampling time points were correlated by linear regression analysis with the total measured mpa auc(0-12) in all 26 patients.
step-wise robust regression analysis was performed to predict auc(0-12).
subset robust regression analysis of the auc(0-12) was performed and included time points up to 3 h to develop the lss equations.
the analysis yielded equations in the form of auc(0-12) = a + a(0) × c(0) + a(1) × c(1) + a(n) × c(n), where a, a(0), and a(n) were fitted constants associated with each timed concentration, and c(0), c(1)., c(n) are concentrations at 0, 1,… nth h postdose.
bootstrap validation of the lss equations was performed using r version 3.0.1 for windows (r foundation for statistical computing, vienna, austria).
this sampling technique involved the selection of n number of observations from the original data with replacement.
this was repeated 10,000 times and the average of 10,000 bootstrap equations was obtained as the final model.
the auc(0-12) predicted for each patient by the bootstrap technique was then compared using the correlation coefficient (r2) and intraclass correlation (icc) with the total measured auc(0-12).
prediction error was assessed by calculating the percentage of absolute prediction error using the formula pe% = ([lss auc − total measured auc] × 100/total measured auc).
an absolute prediction error of < 15% was considered clinically acceptable.
absolute pe% = (| [lss auc − total measured auc] | × 100/total measured auc).
results twenty-six patients (17 girls and 9 boys) were recruited.
the age and weight were 14 ± 2.5 years and 47.6 ± 11.5 kg, respectively.
dose administered (sd) for the 3 months period was 37.16 ±9.48 mg/kg.
the creatinine in 25 patients was 0.82 ± 0.17 mg/dl.
correlation (r) between serum creatinine and auc(0-12) was −0.04.
the measured mean ± sd and median for trough concentration was 2.55 ± 1.57 μg/ml and 2.25 μg/ml and for auc(0-12) was 62.6 ± 21.67 mg.h/l and 61 mg.h/l, respectively.
the range of trough concentrations and auc(0-12) values was 0.7–5.54 μg/ml and 22.1–104.8 mg.h/l, respectively.
2/26 patients had mpa auc(0-12) < 35 mg.h/l, with a mean dose of 35.1 mg/kg while 13/26 had auc(0-12) above 60 mg.h/l, with a mean dose of 40.5 mg/kg.
11/26 patients had an auc(0-12) between 35 and 60 mg.h/l, on a mean dose of 33.6 mg/kg.
the correlation (r) between morning tough (ctroughss) and evening trough (c12) was 0.43. figure 1 shows the mean ± sd concentration time profile from the 26 patients.
figure 1 mean ± standard deviation area under concentration time profile in 26 patients interindividual variability calculated as %cv for dose normalized auc(0-12) and dose normalized ctroughss was 46.5% and 61.1%, respectively.
the subset robust regression analysis yielded two lss equations, one with four and a second with 5 points and both with a correlation coefficient (r2) above 0.86. after bootstrap validation, the correlation coefficient (r2) for the two lss equations was 0.88 (4 point) and 0.87 (5 point).
the icc and the predictive performance after bootstrap validation of the lss models are shown in table 1. table 2 shows the measured and predicted concentrations for the 4 point lss equation.
bland-altman plots for the two equations show minimal bias between the lss auc(0-12) and total measured auc(0-12).
the bland-altman plot for the 4 point lss is shown in figure 2. table 1 bias, imprecision and correlation between total measured auc(0-12) and lss predicted auc(0-12) table 2 measured auc(0-12) versus 4 point predicted lss auc(0-12) (mg.h/l) in 26 patients figure 2 bland-altman plot for the agreement between total measured mycophenolic acid auc(0-12) and 4 point limited sampling strategy estimated mycophenolic acid auc(0-12) discussion the need to optimize the dose of mmf in pediatric sle would call for therapeutic drug monitoring of mpa in clinical practice.
high interindividual variability in exposure observed in our patients is in agreement with that reported by neumann et al.
and zhar et al., which would favor tdm of mpa auc(0-12) in pediatric patients with sle.
[15] filler et al.
suggested that the trough concentration is a clinically important time point in mpa monitoring and defined a target trough ctroughss concentration between 1 and 5 μg/ml in children with autoimmune disease.
[16] in comparison, the range of trough concentrations (0.7–5.35 μg/ml) measured in our study was not significantly different.
however, it needs to be mentioned that the median ± sd dose used in their study was 25.2 ± 10.6 mg/kg in comparison to the median ± sd of 38.89 ± 9.48 mg/kg used in our patients.
earlier studies have reported a moderate correlation between mpa trough and auc(0-12) and have recommended that trough can be used for the tdm of mpa.
[916] we also observed a similar correlation in our study.
however, from our data 61.5% of our patients would have an incorrect dose change if only mpa trough (therapeutic goal: 1–5 μg/ml) was used as a replacement for mpa auc(0-12) (therapeutic goal we used was 30–60 mg.h/l).
therefore, trough may not be ideal as the sole parameter to use for tdm of mpa in pediatric sle.
sagcal-gironella et al.
reported a mean ± sd auc(0-12) of 32 ± 18.1 mg.h/l and a dose normalized mean ± sd auc(0-12) of 45 ± 24.1 mg.h/l/g of mpa.
[8] our mean ± sd auc(0-12) of 62.67 ± 21.67 mg.h/l is significantly different from this.
however, our dose normalized mean ± sd auc(0-12) of 52.3 ± 23.2 mg.h/l/g of mpa in our patients is in agreement with that of sagcal-gironella et al.
for both the 4 and 5 point lss equations 2/26 (7%) patients had > 20% difference between the predicted and measured concentrations.
6/26 (23%) of patients had over 15% difference between the predicted and the measured auc(0-12).
the two patients with > 20% difference would have led to an incorrect dosage decision.
in both equations, the bias and precision are similar.
blood collection in children is often challenging in view of the discomfort to the child and the family.
multiple blood collections over 12 h are traumatic, impractical, expensive and increases the laboratory turnaround time.
we, therefore, recommend a 4 point lss equation to predict mpa auc(0-12) in pediatric sle making tdm more feasible, reducing the trauma, the expense, and the laboratory turnaround time.
financial support and sponsorship the authors acknowledge the research committee of the christian medical college, vellore, for funding the study.
conflicts of interest there are no conflicts of interest.
@highlight
the aim of this study was to establish a limited sample strategy (lss) to predict the mycophenolic acid (mpa) area under the curve (auc)(0-12) in children with systemic lupus erythematosus (sle).
three months after initiation of mycophenolate mofetil (mmf) 26 children with sle presented for therapeutic drug monitoring of mpa.
on the day of the test, 10 specimens were collected, analyzed, and mpa auc(0-12) was calculated.
using step-wise regression analysis, lss equations were developed.
using bootstrap validation, the predictive performance was calculated.
the measured mean (standard deviation) for the trough concentration and auc(0-12) were 2.55 (1.57) μg/ml and 62.6 (21.67) mg.h/l, respectively.
the range of trough concentrations and auc(0-12) were 0.7–5.54 μg/ml and 22.1–104.8 mg.h/l, respectively.
the interindividual variability (%cv) for dose normalized auc(0-12) and dose normalized ctrough was 46.5% and 61.1%, respectively.
the correlation between the concentrations at the different time points and mpa auc(0-12) ranged from 0.05 (1.5 h) to 0.56 (4 h).
two lss equations that included 4 or 5 time points up to 3 h were developed and validated.
the 4 point lss had a correlation (r2) of 0.88 and the 5 point lss an r2 of 0.87. with respect to the 4 point and 5 point mpa lss auc(0-12), the bias was 1.92% and 1.96%, respectively, and the imprecision was 11.24% and 11.28%, respectively.
a 4 point lss which concludes within 3 h after the administration of the mmf dose was developed and validated, to determine the mpa auc(0-12) in children with sle.
