1. introduction carbonic anhydrases (cas) are a large and ancient family of enzymes present in all organisms.
cas catalyze the naturally existing reversible reaction between the hydration (h2o) of carbon dioxide (co2) and production of carbonic acid (h2co3) in the form of bicarbonate (h2co3−) and proton (h+) in living organisms.
there are six genetic families of cas: α-, β-, υ-, δ-, ζ-, and η-cas, with α-ca being the most recently evolved class and the one found mainly in mammals, and other families observed in the lower organisms [1].
evolutionary analysis has revealed 17 isoforms in the α-ca family by sequence similarities and divergences [2].
these isoforms can be further grouped based on their diverse subcellular locations: cytosol (ca1,2,3,7,13), plasma membrane (ca4,9,12,14,15,17), mitochondrion (ca5a,5b) and extracellular space (ca6).
the remaining members (ca8,10,11) are known as carps (carbonic anhydrase-related proteins) as they are catalytically inactive [2,3].
the intracellular ph of a cell is determined by the net contribution of acid-loading and acid-extruding mechanisms [4].
ions that are involved in these mechanisms include na+, h+, hco3−, and cl− that are transported in and out of cells by exchangers and transporters [5,6,7,8], whereas co2 diffuses through cell membranes.
depending upon the concentrations of the molecules (co2, h2o, h2co3−, and h+), the physiological function of cas is to dynamically regulate and maintain cellular ph homeostasis.
cas are ubiquitously expressed with different isoforms present in specific cell types [6].
for example, both ca1 and ca2 are abundant proteins in blood.
ca isoforms 2, 4, 12, 14 are expressed in the kidney where the transport of solutes and acid−base balance are highly regulated and maintained within the nephron [9].
ca3 is the predominant isoform expressed in skeletal muscles [10].
in the central nervous system (cns), ca2 was initially known to be the dominant form [11,12,13,14], though recent studies have revealed that many additional isoforms including ca5,7,4,12,14,15 and ca8,10,11 are expressed in diverse cell types in the cns [15,16,17,18,19,20,21].
in addition to the involvement in modulating, buffering, and maintaining of both intracellular and extracellular ph, cas serve important functions in the neural transmission in the cns.
it has been demonstrated that during the synaptic transmission, the intracellular ph in the synaptic terminal undergoes a transient acidification followed by a prolonged alkalinization [22,23].
ca inhibitors caused an overall acidification of this process [22].
depending on the expression of the specific isoforms, cas in the cns function in coupling the intracellular proton/bicarbonate cycle and lactate flux between glia and neurons as well as regulating the extracellular ph [24,25,26].
cas have been shown to modulate both excitatory and inhibitory neuronal transmissions in hippocampus, cerebellum, and cortex [15,26,27,28,29].
furthermore, ca4 and ca14 can be coupled to monocarboxylate transporters to modulate lactate flux between neurons and glial cells in energy consumption [24,26].
defects in cas result in the specific pathology and symptoms determined by the selective expression of the isoforms.
ca2-deficiency in human causes osteopetrosis, renal tubular acidosis, and mental retardation [30].
homozygous ca9-knockout mice have gastric hyperplasia and vacuolar degenerative changes in the brain with behavioral defects in locomotor activity and memory test [31,32].
on the other hand, ca9 is highly expressed in several cancers [33].
patients with a mutation in ca12 exhibit hyponatremia and hyperchlorhydria [34].
individuals with homozygous mutation in ca5a are reported to have lethargy, hyperlactatemia, and hyperammonemia during the neonatal period and early childhood [35].
ca6 is initially described as a gustatory protein and highly expressed in the salivary and mammary glands.
mice deficient in both copies of the ca6 gene prefer bitter taste [36,37].
polymorphism in the human ca6 gene was also linked to bitter taste perception [37].
carps are predominantly expressed in neural tissues [38].
patients with mutations in ca8 show phenotype in cerebellar ataxia, mental retardation, and disequilibrium syndrome [19], while ca8−/− mice exhibit motor dysfunction and altered calcium dynamics in cerebellar granule cells [39].
inactivation of ca10 in zebrafish leads to abnormal embryonic development and altered movement pattern [40].
ca1 is a very early marker for erythroid differentiation and the second most abundant non-heme protein in erythrocytes [41].
its expression is also detected in intestinal, vascular and corneal epithelia, synovium, and cardiac capillary endothelial cells [42,43,44,45,46].
ca1-immunoreactivity was observed in both type i and ii cells in the rat carotid body [47].
only in one study, ca1 mrna level in the mouse brain was reported to be extremely low compared with that of ca2 [48].
therefore, whether ca1 is expressed in the cns is unclear.
to date, there have been a total of seven studies reporting ca1 being the key protein as a result of unbiased screenings between normal and pathological conditions [42,43,46,49,50,51,52].
the elevated ca1 level was found in the vitreous of diabetic retinopathy which contributes to retinal hemorrhage and erythrocyte lysis via prekallikrein activation [43,53].
the increased expression of ca1 found in the synovium of patients with ankylosing spondylitis may promote dysregulated calcification and bone resorption [42].
ca1 was found to be the major antigen in cecal bacterial ag, which is associated with inflammatory bowel disease.
the dendritic cell-mediated ca1-specific production of regulatory t cells can suppress the development of colitis induced by cd4+cd25− t cells [52].
ca1, together with ca2, are increased in diabetic ischemic cardiomyopathy, and ca1 can affect apoptosis in vitro [46].
similar to ca2, ca1 has been shown to be a potential novel biomarker for early stage of non-small cell lung cancer [54].
in the current study, we report ca1 expression in spinal cord motor neurons.
in addition, a proportion of ca1s are associated with subcellular endoplasmic reticular (er) structures.
ca1 protein levels were preferentially increased in the spinal cord of patients with amyotrophic lateral sclerosis (als), while ca2 did not change in these same patients.
our in vitro cell culture data demonstrated that intracellularly expressed ca1 can induce apoptosis.
our study establishes ca1 expression in the human spinal cord and suggests that ca1 may have an important function in motor neuron degeneration in als.
2. results 2.1. carbonic anhydrase i (ca1) is expressed in human spinal cord motor neurons since ca1 has not been reported to be expressed in the cns and we are interested in the potential function of ca1 in motor neurons as well as in motor neuron degeneration in the context of als-related pathology, we first examined whether ca1 is expressed in human spinal cord motor neurons.
because ca2 is known to be the most abundant ca isoform in the cns and human ca1 (hca1) shares 59.8% identity in the amino acid sequence with human ca2 (hca2), we would like to be certain that the ca1 antibodies used in this study were ca1-specific and did not cross-react with ca2.
for this purpose, commercially available recombinant human ca1 (rhca1) and ca2 (rhca2) proteins were used in the western blot analysis (supplementary materials, figure s1).
when an equal volume (4.5 μl) of the protein solutions was used, more than three-fold excess of ca2 protein (22.5 ng) over ca1 protein (6.42 ng) was observed on the gel (supplementary materials, figure s1a, indicated by the intensity of sypro ruby-stained band between lane 1 and lane 4).
four identical blots with an equal volume (9.5 μl) of ca1 and ca2 samples loaded for each lane were then probed with three different sources of the commercially available ca1 antibodies as well as a ca2 antibody.
all ca1 antibodies recognized rhca1 without any detectable cross-immunoreactivity to rhca2 while the ca2 antibody recognized rhca2 only (supplementary materials, figure s1b).
the specificity of one of the ca1 antibodies, hrp-gαca1, was further examined using proteins from the human spinal cord (hsc).
it so happened that the broad range molecular weight standards used in our experiment contained bovine ca2 (bca2).
bovine ca2 shares 58.0% and 80.4% amino acid sequence identity with hca1 and hca2, respectively.
though hrp-gαca1 cross-reacted somewhat with bca2, it recognized one hca1 band in the spinal cord extracts (supplementary materials, figure s1c, the left panel).
in the meantime, the hrp-rbαca2 antibody recognized one hca2 band, but not hca1, while also recognizing strongly the bca2 because of the more shared identity (supplementary materials, figure s1c, the right panel).
note that hca2 is comprised of 260 amino acids and ran slightly faster than hca1 (which contains 261 amino acids) on the sds-page.
the slight difference in the sizes was readily visualized by drawing a horizontal dotted line across the center of the bands (supplementary materials, figure s1d).
therefore, we conclude that the ca1 antibodies used in this study recognize hca1 but not hca2.
when control human spinal cord paraffin sections were immuno-stained with the ca1 antibody, the immunoreactivity was distinctively observed in large-sized motor neurons in the ventral horn (figure 1a, also indicated by arrows).
at a higher magnification, an unexpected punctuated pattern with a diffuse background staining was clearly evident (figure 1b,c).
when the hrp-rbαca2 antibody was used to stain the adjacent spinal cord sections, the ca2-immunoreactivity was completely excluded from the large-sized motor neurons (figure 1d,e).
this observation is consistent with the notion that ca2 isoform is mainly expressed in oligodendrocytes and astrocytes [18], though the accurate demonstration of ca2 expression in the spinal cord was not further determined in our study.
2.2. a subpopulation of neuronal ca1 appears to be associated with the endoplasmic reticulum subcellular structure to further characterize the subcellular structures represented by the punctate ca1-immunoreactivity, the staining patterns of molecular markers from subcellular organelles including the mitochondria, endoplasmic reticulum (er), golgi, endosomes and lysosomes were compared with that of ca1 (see some examples in supplementary figure s2).
when it was obvious that the ca1 staining pattern most resembled that of an er-marker pdi (protein disulfide isomerase), double-labeling for co-localization was further conducted for pdi and ca1 antibodies only.
indeed, pdi-labeling was found to co-localize with ca1-labeling (figure 2a–c,a’–c’).
to further demonstrate the relevance and the new feature of the ca1-immunoreacitivty, two neuronal markers sm32 (against cytosolic non-phosphorylated neurofilaments) and sm31 (against phosphorylated neurofilaments present predominantly in axons) were used to double-label spinal cord sections with the ca1 antibody.
the diffusive pattern of ca1-immunoreactivity overlapped with that of sm32 (figure 2d–f,d’–f’) but not sm31 (figure 2g–i,g’–i’).
the pattern of the ca1-immunoreactivity in the spinal cord demonstrated that ca1 is expressed in motor neuron soma while ca2 is present predominantly in non-neuronal cells.
in addition, a portion of ca1 proteins in the spinal cord neurons appear to be associated with the er structure.
this is corroborated by the biochemical property of ca1 found in the 100,000× g membrane-fraction (figure 3, microsomal or “mv”).
2.3. ca1 is preferentially elevated in als spinal cord to further determine the potential function of ca1 in motor neurons, we examined ca1 protein levels in the context of motor neuron degeneration in als spinal cord.
human spinal cord proteins were extracted as two fractions: cytosolic (cyto) and microsomal (mv) from both non-neurologic disease controls and sporadic als (sals) patients (supplementary materials, table s2 for information on the samples).
the establishment and validation of this fractionation methodology was described in detail in a previous published study [55].
briefly, this differential centrifugation-based fractionation method removes nuclei and mitochondria sequentially.
the final step is the separation of the cytosolic (cyto) proteins from the membrane fraction (mv) by 100,000× g centrifugation.
membrane structures from subcellular organelles other than nuclei and mitochondria should remain in the “mv” fraction.
consequently, proteins including pdi are readily detected in the “mv” fraction (figure 3a).
initially, we determined the levels of cytosolic ca1s in larger sizes of control and als samples (supplementary materials, figure s3).
to ensure the quality of an equal amount of sample loaded for each lane, three parameters including the total amount of proteins in each lane visualized by sypro ruby-staining and the intensities of the immunoreactive signals of both actin and another abundant cytosolic protein copper, zinc superoxide dismutase (sod1) were used as the references for ca1 quantification (supplementary materials, figure s3a,b).
as expected, there is no significant difference between the control and als groups in each of the above three parameters, while ca1 level was significantly increased in als spinal cord (supplementary materials, figure s3c).
subsequently, the levels of both ca1 and ca2 proteins were determined for either “cyto” or “mv” fractions in smaller sizes of the samples due to the insufficient available spinal cord materials from some subjects for the “mv” analysis.
in these experiments, sod1 was used as the internal control for the “cyto” fraction, as its level is not expected to change in all samples as demonstrated (supplementary materials, figure s3).
in this reduced cohort, ca1 but not ca2 protein levels were increased in als patients (figure 3); as expected, the level of cytosolic sod1 protein did not differ between the two groups (figure 3a, the left panel; figure 3b, cyto-sod1).
ca2 levels were not significantly changed in either the “cyto” or “mv” fraction between the control and als samples (figure 3b, cyto-ca2 and mv-ca2).
interestingly, the membrane-associated ca1 (mv-ca1) was increased more pronouncedly when compared to the cytosolic ca1 in als spinal cord (figure 3b, cyto-ca1 vs. mv-ca1).
the er-resident protein pdi in the “mv” fraction was also examined and it was found to be increased in als spinal cord (figure 3a, the right panel and figure 3b, mv-pdi).
our data is consistent with the published data demonstrating that pdi was upregulated in als patients [56].
2.4. altered patterns of ca1 expression in als pathology to further characterize ca1 in als, we next examined the patterns of ca1 expression in als spinal cord motor neurons by immunohistochemistry (see supplementary materials, table s1 for information on the samples).
compared to the spinal cords from control subjects (figure 4a–c), a different ca1-staining pattern was observed in almost all the fewer remaining neurons in als spinal cords (figure 4d,e).
the typical punctate staining pattern in the cytoplasm of motor neurons (figure 4, indicated by black arrows) was lost in the remaining motor neurons in als spinal cord (figure 4, indicated by red arrows).
the altered ca1 appearances in als spinal cord can be the consequences of the overall degeneration and damage of motor neurons in als pathology.
2.5. long-term ca1 expression induces apoptosis in hek293 cells in order to assess whether the changes in ca1 can contribute to or compensate for als pathology, we overexpressed ca1 in hek293 cells and examined its effects on cell survival and/or apoptosis.
overexpression of gfp in hek293 cells was used as control.
the expression of either gfp or ca1 in these cells was confirmed by western blot analysis at 96 h post-induction (figure 5a,b).
while there is a leaky expression of gfp in the inducible stable gfp cell line, the presence of doxycycline (dox) induced detectable expression of both gfp and ca1 (figure 5a, lane 2 and figure 5b, lane 4, respectively).
cell survival was measured by the wst8 assay after induction of ca1 expression at different times.
while no significant toxicity resulted from induction of gfp expression in hek293 cells at the indicated times (figure 5c), expression of ca1 caused reduced survival at later times (figure 5d, both 96 h and 144 h), but not at an earlier time (figure 5d, 48 h).
when these cells were analyzed by facs for the detection of the cleaved parp-1 and caspase-3, two molecules involved in the activation of apoptosis, there were significant increases in the cleavage of both parp-1 (figure 6a,b) and caspase-3 (figure 6c,d) induced by ca1 at 96 h. the effect is specific as no changes in cleaved papr-1 and caspase-3 were seen with overexpression of gfp at the same time (figure 6).
the reduced cell survival and activation of two apoptotic markers, parp-1 and caspase-3, upon ca1-induction demonstrate that ca1 can cause cellular toxicity.
3. discussion our study has discovered that cytosolic ca1 is expressed in spinal cord motor neurons.
unexpectedly, the pattern of ca1 immunoreactivity and its co-localization with pdi in motor neurons indicates that a subpopulation of ca1 proteins is associated with the er.
more importantly, while the known cns-expressing cytosolic ca2 is not changed in als, ca1 was significantly increased with more pronounced change in the membrane-associated fraction in als spinal cord (figure 3).
the pattern of ca1-immunostaining was also altered in als spinal cord motor neurons (figure 4).
to further understand the potential involvement of ca1 in als pathology, we provide evidence that ca1 can induce apoptosis in hek293 cells.
cas are essential enzymes in cells without which many physiological functions and metabolism cannot operate normally.
it is therefore recognized that different isoforms of cas are present in all cells to regulate both the intracellular and extracellular ph for the overall cellular ph homeostasis and functions.
it also appears that more than one isoform of cas may be present in any given cell to serve physiological functions.
there was no detailed information on the identification of all ca isoforms expressed in neuronal cell-types.
ca1 is less well studied than ca2 due to the fact that it has lower catalytic activity [6].
ca1 expression has been observed in several peripheral tissues, while its expression in the cns is reported to be extremely low in comparison with ca2 [48].
our study is the first to demonstrate that ca1 expression is readily detectable in spinal cord motor neurons, adding yet new information to the diverse expression of ca isoforms, especially in the cns.
with the detection of its expression in motor neurons, the potential function of ca1 can be studied.
we detected increased levels of ca1 in als spinal cord, whereas ca2 exhibited no such changes (figure 3).
we also observed ca1 within punctate structures in the motor neurons (figure 1) that co-localized with a marker for the er (figure 2).
thus, ca1 joins other cytosolic molecules whose associations with subcellular structures have also been reported.
one of them is sod1, which was first reported to be localized in the intermembrane space of mitochondria [57] and more recently to be palmitoylated [58].
this palmitoylation was associated with the immature sod1 conformation, targeting it to membrane structures.
the increased targeting to mitochondria was observed for mutant sod1s that cause als, suggesting this non-cytosolic form of sod1 may be directly involved in disease mechanisms [58].
the observation of ca1’s association with the er bears a striking resemblance to the phenomenon of membrane-targeted sod1 and its potential involvement in als.
this conjecture is further supported by the fact that the level of membrane-associated ca1 sub-population was increased in als, and the subcellular distribution in surviving motor neurons exhibited a less pronounced punctate immunostaining (figure 4).
it is not resolved in our current study whether there is a direct link between ca1 and the er stress pathway that is relevant for als; our data provide potential reasons to hypothesize that ca1 might be able to modulate er stress responses or, alternatively, elevation of ca1 might be directly or indirectly associated with als-induced er stress.
future studies will explore this potential role of ca1 in motor neurons.
our data also imply that ca1 serves different functions from ca2 in the human spinal cord, as their expression pattern did not overlap and we did not detect any changes in ca2 during als.
our in vitro data demonstrate that ca1 can induce apoptotic pathways in hek293 cells and they reveal a new function of ca1.
this also is the first evidence to show that the intracellular ca1 can reduce cell survival, which would be via a different mechanism from the increased extracellular ca1 released during retinopathy [43] or up-regulated in other diseases [42,46].
this finding can go well (if proven) with the proposed er signaling pathway which is known to cause activation of apoptosis in the form of parp-1 and/or caspase-3 activation.
in summary, we have determined that ca1 is expressed in spinal cord motor neurons and partially co-localizes to the er in control motor neurons.
ca1 protein levels are increased in als spinal cord and ca1 immunoreactivity was observed in a more diffuse cytoplasmic distribution in als motor neurons.
our data provide a foundation to further test the hypothesis of potentially linking ca1 to er-associated activation of motor neuron death in als pathogenesis.
4. experimental section 4.1. human tissues human autopsy samples were from the brain and tissue bank for developmental disorders of the national institute of child health and human development (baltimore, ma, usa) and forbes-norris mda/als research center (san francisco, ca, usa).
informed consents were obtained from all subjects before sample collections.
handlings of all human samples were in accordance with the approved protocol by california pacific medical center internal board review (irb).
(protocol code 25.012; date of approval: 19 january 2005).
4.2. antibodies and other reagents the antibody to sod1 was as described [55].
antibodies against ca1 including gαca1 (ab6619), mαca1 (ab54912), rbαca1 (ab108367), pdi (ab5484), mito (ab3298), and giantin (ab24586) were from abcam (cambridge, ma, usa).
hrp-gαca1 (#200-1354) and the antibody against ca2 hrp-rbαca2 (#200-403-136) was from rockland (gilbertsville, pa, usa).
the actin antibody (a2066) was from sigma (st. louis, mo, usa).
the monoclonal antibodies against neurofilaments sm31 and sm32 were from sternberger-meyer immunochemical inc. (jarettsville, md, usa).
both recombinant human ca1 (#2180-ca) and ca2 (#2184-ca) were purchased from r&d systems (minneapolis, mn, usa).
the broad range molecular weight standards (#161-0317) were from biorad (hercules, ca, usa).
syrpo-ruby (#s12000) was from thermo fisher scientific (waltham, ma, usa).
polybrene (#h9268) was from sigma (st. louis, mo, usa).
4.3. cell cultures and establishing inducible stable cell lines hek293 cells were cultured and maintained in dulbecco’s modified eagle medium (dmem) containing 10% fetal bovine serum (fbs), 0.1% penicillin/streptomycin at 37 °c/5% co2.
stable cell lines with inducible expression of the proteins were established using a modified tripz lentiviral inducible system consisting of pspax2 (lentivirus packaging vector), pmd2.g (lentivirus envelope vector) and ptripz (protein expression vector) plasmids.
all plasmids were kindly provided by dr. ferdinand kappes.
the cdna of gfp or ca1 was cloned into the ptripz plasmid.
to produce lentiviral particles, lipofectamine-mediated transfection with a mixture of 900 ng of pspax2, 100 ng of pmd2.g, and 1 μg of ptripz in 6 μl of lipofectamine reagent (#11668019, life technologies, carlsbad, ca, usa) were added to 50%–70% confluent hek293 cells in a 6 cm dish.
at 18 h post-transfection, the cell medium was replaced with the medium containing 30% fetal bovine serum (fbs) and 1% penicillin/streptomycin.
the medium which contained lentiviral particles were harvested at 40 h post-transfection and filtered through 0.45 μm filters for obtaining the viral supernatant.
fresh medium containing 30% fbs was added back to the cells.
to transduce cells, hek293 cells were seeded 24 h prior to the viral transduction in 10 cm dishes.
when they reached 10%–30% confluency, the cells were transduced with the viral supernatant containing 8 μg/ml polybrene for 6 h after which the medium was changed to normal cell growth medium and incubated at 37 °c/5% co2.
at 12 h, the viral medium was harvested and filtered again.
the transduction procedure was then carried out for the second round.
the cells were transduced with the viral supernatant for 6 h again and the viral medium was replaced with normal cell growth medium after transduction.
after 24 h, the transduced cells were selected in the presence of 1 μg/ml puromycin.
after 2 weeks, pure stable cell lines were obtained from transduced cells surviving from the puromycin selection.
after the stable cell lines have been obtained, the cells were maintained in the growth medium containing 0.25 μg/ml of puromycin.
4.4. immunohistochemistry and immunofluorescent labeling the spinal cords from autopsy samples were dissected out and fixed in 4% formaldehyde.
tissues were further processed, embedded in paraffin, and sectioned at 7 μm thickness.
paraffin sections were processed for either immunohistochemistry using the dab (3,3′-diaminobenzidine tetrahydrochloride, sigma, st. louis, mo, usa) method with the vector abc kit (vector laboratories, burlingame, ca, usa) or the immunofluorescent labeling.
all sections were deparaffinized, incubated in 20% h2o2/10% methanol solution to quench any endogenous peroxidase activity (for the dab method only), heat-boiled by microwaving to expose the epitopes, and blocked in 5% normal serum in pbs/0.01% triton for 1.0 h at room temperature.
subsequently, sections were incubated with primary antibodies in pbs/1% normal serum overnight at 4 °c.
for the dab-labeling, the sections were continued for incubation with biotinylated secondary antibodies and substrates a and b. immunoreactive signals were visualized by adding dab for a brown color-development followed by counter-staining with hematoxylin.
for the immunofluorescent labeling, the sections were continued for incubation with cy3 or cy5-conjugated secondary antibodies (jackson immunoresearch laboratories, west grove, pa, usa).
all images were captured on the upright nikon microscope (eclipse ni-e, nikon inc., melville, ny, usa) equipped with a ccd (charge coupled device) camera.
4.5. western blot analysis spinal cord tissues were fractionated as described [55].
the protein concentration was determined using the bca kit (#23225, thermo fisher scientific, waltham, ma, usa).
cytosolic and microsomal proteins were separated on sds-page gels, transferred to nitrocellulose membranes, and incubated with the primary antibodies using the ecl (enhanced chemiluminescence) detection method (ge healthcare, piscataway, nj, usa).
the intensities of the immunoreactive signals were quantified using the imagej (an open source software developed by national institute of health, baltimore, md, usa).
hek293 cells in 12-well plates were lysed using the sample loading buffer (61.3 mm tris ph 8.0, 2% sds, 10% glycerol, 0.0025% bromophenol blue, 2.5% β-mercaptoethanol) and centrifuged for 30 min at 4 °c.
equal volumes of protein samples were resolved on 12% sds/page.
proteins were transferred to nitrocellulose membranes, blocked in 5% milk solution in tbst, incubated with the primary antibodies followed by 608-conjugated anti-rabbit secondary antibody (#9263223, li-cor bioscience, lincoln, ne, usa).
the signals were visualized on odyssey infra-red imager (li-cor biosciences, lincoln, ne, usa).
4.6. cell survival assay cells were plated in a 96-well plate.
the wst8 (dojindo laboratories, rockville, md, usa) assay was carried out to measure cell viability.
a total of 10 μl of the wst8 reagent was added to each well with 100 μl of the medium.
the absorbance at 450 nm was taken after 2 h incubation at 37 °c/5% co2 on a microplate reader (biotek, winooski, vt, usa).
4.7. flow cytometry analysis flow cytometry analysis was used to determine the extent of apoptotic activation induced by ca1 in hek293 at 96 h post-induction of protein expression.
cells were collected by centrifugation at 500× g for 5 min and fixed by re-suspension with pbs solution containing 4% paraformaldehyde at room temperature for 15 min.
cells were then pelleted, re-suspended in 90% methanol and 10% pbs solution, and incubated at −20 °c for 30 min to permeabilize membranes.
cells were washed twice with freshly made pbs/1% bovine serum albumin (bsa) and blocked in the same solution for 20 min at room temperature.
after blocking, cells were washed with 1% bsa/pbs and incubated with anti-caspase-3-alexa fluor 647 (bd, #560626, san diego, ca, usa) or anti-parp-1-alexa fluor 647 antibodies (bd, #558710, san diego, ca, usa) to detect apoptotic changes.
the dilutions for both anti-parp-1 and anti-caspase-3 antibodies used in the experiment were 1:200 as recommended by the manufacturer.
fluorescence signals were collected in the log mode using a facscalibur (bd, san diego, ca, usa) and data acquisition was done using the cellquest pro software (bd, san diego, ca, usa).
analysis of cell populations were performed on events gated according to the forward light scatter/side scatter parameters.
4.8. statistical analysis the statistical significance between the two data sets was assessed using the graph-pad prism software, version 5.04 (graphpad, san diego, ca, usa).
two-tailed t-tests were used and the statistical significance was set at p < 0.05.
@highlight
carbonic anhydrase i (ca1) is the cytosolic isoform of mammalian α-ca family members which are responsible for maintaining ph homeostasis in the physiology and pathology of organisms.
a subset of ca isoforms are known to be expressed and function in the central nervous system (cns).
ca1 has not been extensively characterized in the cns.
in this study, we demonstrate that ca1 is expressed in the motor neurons in human spinal cord.
unexpectedly, a subpopulation of ca1 appears to be associated with endoplasmic reticulum (er) membranes.
in addition, the membrane-associated ca1s are preferentially upregulated in amyotrophic lateral sclerosis (als) and exhibit altered distribution in motor neurons.
furthermore, long-term expression of ca1 in mammalian cells activates apoptosis.
our results suggest a previously unknown role for ca1 function in the cns and its potential involvement in motor neuron degeneration in als.
