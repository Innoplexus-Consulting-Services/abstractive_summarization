1. introduction head and neck squamous cell carcinoma (hnscc) is the sixth most common cancer diagnosed worldwide and the eighth most common cause of cancer death [1].
malignant tumors of the oral cavity, oropharynx, and larynx can be treated by surgical resection or radiotheraphy with or without chemotheraphy and have a profound impact on quality of life functions, including swallowing.
when surgery is the chosen treatment modality, the patient may experience swallowing impairment in the oral and pharyngeal phases of deglutition.
effects of various surgical procedures for oropharyngeal cancer include a reduced range of oral tongue motion, reduced oral tongue coordination, reduced posterior movement of tongue base, with prolonged bolus transit through the oropharynx, and abnormal swallowing efficiency [2–7].
approximately one-sixth of patients with prior laryngectomy present dysphagia related to the morphofunctional changes carried out on the pharynx during surgery [8–16].
a videofluoroscopic study of swallow enables the morphodynamics of the pharyngeal-esophageal tract to be accurately examined in patients with prior surgery.
in particular, the digital system enables the analysis of individual images “frame by frame” and the dynamic sequence immediately after the acquisition, which allows an immediate assessment of the findings.
these features allow an accurate tracking of the various phases of swallowing in real time, identifying the presence of functional disorders and of complications during the short- and long-term postoperative recovery [16].
the direct observation of the effectiveness of swallowing while varying a number of factors (density of the barium, position of the head) can provide information regarding certain compensatory mechanisms [16].
so, the role of imaging is fundamental for the therapist to plan rehabilitation.
in this paper, the authors aim to describe the videofluoroscopic study of swallow protocol and related swallowing impairment findings in consideration of different types of surgery.
2. the videofluoroscopic swallow study protocol in order to reliably compare studies between patients and within patients pre- and postintervention, it is essential to perform every investigation in a standardized and systematic manner.
the authors suggest logemann's protocol [17] of modified barium swallow procedure, recording the digital fluoroscopic images permanently on a dvd film.
all studies must be performed by a licensed radiology technician and a speech language pathologist and reviewed by a specialized radiologist.
the ability to record the entire study with a frame rate higher than 30 frames per second (fps) and being able to review the film in a frame-by-frame manner are essential for precise interpretation and analysis.
studies obtained at capture rates lower than 30 fps may miss significant pathology [18].
all examinations may be reviewed by an interdisciplinary panel that includes a speech language pathologist, a surgeon, and a radiologist.
patients should be weighed, measured, and given the validated ten-item eating assessment tool (eat-10) prior to the administration of barium [18] (table 1).
the eat-10 documents the level of baseline disability and helps in monitoring treatment efficacy.
the patient is positioned upright with the fluoroscopy unit in the lateral position.
the patient's head position is neutral and facing forward.
the boundaries of the fluoroscopic field in the lateral view are the lips anteriorly, nasopharynx superiorly, cervical spine posteriorly, and cervical esophagus inferiorly (seventh cervical vertebra inferiorly).
the boundaries of the fluoroscopy field in the anteroposterior (ap) view are the walls of the pharynx laterally and the nasopharynx [17].
the study protocol should proceed in a stepwise fashion.
while viewed in the lateral plane, the patient should be given two swallows of each of the following materials.
liquid barium in measured amounts is the first material used.
liquid is the first material administered, even if the patient is known to aspirate, because it is usually best to define the reason for aspiration and the amount of aspiration during the first swallows and because liquid is least likely to block airway.
after two 1 ml swallows are completed, two 3 ml liquid swallows should be given.
then, two 5 ml swallows are given.
if no aspiration occurs at 5 ml, 10 ml should be given.
second, swallows of thicker foods should be given diluting barium sulfate nectar from semisolid to semiliquid formulation.
the last material used is a cookie with a light coating of barium.
in this case, the patient is told to go ahead and swallow as soon as he or she has completed chewing [19].
when the desired number of swallows of various materials has been completed in the lateral plane, the patient should be turned to be viewed in the anteroposterior plane, evaluating the symmetry of swallow.
only swallows of those food consistencies that were most difficult for the patient should be repeated in this view [19].
it is useful to structure findings during examination in a swallowing worksheet.
the authors suggest the use of logemann's worksheet [19] for each consistency of food in the lateral view and in the anteroposterior view only for those food consistencies that were most difficult for the patient (tables 2(a)–2(d)).
in case of penetration and aspiration, the use of penetration and aspiration scale (table 3) is mandatory.
in fact, this eight-point scale assesses depth of bolus passage into the airway and the patient's response to the bolus [20].
compensatory strategies could redirect and/or improve the flow and direction of food and may change the dimensions of the pharynx, and so giving better airway protection without increasing the effort or work for the patient during the swallow.
table 4 presents the postures which have current evidence for their use and their rationale [21].
3. swallowing disorders related to specific surgical resection and reconstruction technique: what the radiologist should know to understand the swallowing disorders after surgery, the radiologist should know the exact nature and extent of the resection of the tumor and the exact nature of the reconstruction.
now, the authors show you the postoperative pictures of oral cavity and pharynx during the examination in relation to the different types of surgery.
4. findings after oral cavity and oropharyngeal surgery based on location, size, and extent of the tumor as well as the surgical reconstruction procedure, cancer in the oral cavity can significantly affect the functional outcome [2, 26–28].
according to groher [27], the removal of less than 50% of a structure involved with swallowing will not interfere or seriously impact swallowing and the resulting swallowing difficulties are temporary [28].
when more than 50% of the tongue is resected, lingual propulsion and control of material in the mouth are severely reduced, because the contact between the remaining tongue segment and the palate is lost (figure 1(a)).
the area excised and surgical procedure are prognostic indicators of the resultant dysphagia, especially, in cases of base of tongue and arytenoid cartilage resections [29].
if neural control and some tongue movement were preserved, swallowing could not be very compromised [30].
when the resection of tissue is so large that there is no sufficient tissue remaining to permit primary closure, the surgeon may need to borrow tissue from another area of the body, by means of a flap or graft [19].
this may interfere with the neural control, by the use of a nonsensate flap [31] or by hypoglossal nerve involvement [32], with resulting disorders of the bolus passage through the oropharynx and problems with chewing, controlling food in the mouth, and initiating swallowing.
when total glossectomy is required, swallowing impairment is related with the mandible and the floor of the mouth muscle resection.
in fact, when glossectomy is combined with anterior mandible resection and/or removal of these muscles, the patient loses the ability to pull the hyoid and the larynx up and forward to open the upper esophageal sphincter leading to pharyngeal dysphagia and food remaining in the pyriform sinus and in the pharynx [19, 33] (figure 1(b)).
the removal of the upper margin of the mandible and a portion of the floor of the mouth with closure of the defect with a flap has few functional changes.
the same resection by suturing the tongue into surgical defect will present severe difficulties with lost lingual control and propulsion of the bolus and mastication [19].
if sacrifice of the hyomandibular constrictors is required, the protective tilting action of the larynx is lost and there may be a risk of aspiration.
considering the location, if the tumor site is in the posterior oral cavity and oropharynx, this can be a bad prognostic indicator [7].
in fact, surgical procedure can minimize the tongue base to posterior pharyngeal wall contact with reduced pressure generation and delayed initiation of the swallow.
in many cases, this results in aspiration before the swallow or pharyngeal stasis and postswallow aspiration.
combined resections of the tongue and hard palate change the bolus passage into the pharynx.
combined resections of the soft palate and tonsillar pillars alter the bolus transport through the oral cavity and pharynx with nasopharyngeal reflux and pharyngeal stasis too (figure 2).
resection of cancer in the ipopharynx can result in significant swallowing impairment, because of alterations of muscular contraction that may cause missed pharyngeal clearance, with pharyngeal residue and risk of penetration and aspiration [34].
when bilateral neck dissections are needed, this results in poor swallowing unless the superior laryngeal nerve, hyoid bone, and epiglottis remain intact.
5. findings after partial and total laryngectomy the laryngeal complex serves two critical functions during swallowing.
first, the larynx elevates and moves anteriorly under the tongue base to move it from the path of the bolus and to assist in cricopharyngeal sphincter opening.
second, it protects the airway from aspiration by closing at three levels: the epiglottis, false vocal folds, and true vocal folds.
any surgery that compromises this closure, especially that of the true vocal folds, is likely to result in aspiration during the swallow.
tipping the patient's head forward to push the epiglottis more posteriorly could avoid the airway entrance [19].
if there is still aspiration with the chin down, head rotation to the operated side may improve airway protection.
if a supraglottic laryngectomy is required, the whole supraglottis is resected, including the pre-epiglottic space and the upper half of the thyroid cartilage.
inferiorly, the resection encompasses the petiole of the epiglottis, down to the anterior commissure, and then the ventricular folds.
posteriorly, the limit of resection passes in front of the arytenoids, sectioning the ventricular and aryepiglottic folds.
superiorly, the incision transects the valleculae along the posterior aspect of the hyoid bone.
larynx reconstruction is accomplished by a thyrohyoidopexy.
in individual cases, resection of the hyoid bone may be necessary.
in these cases, the pexy will approximate the inferior thyroid and the base of the tongue.
the laryngeal elevation is thus damaged.
if the hyoid bone is removed, laryngeal suspension and elevation are damaged.
if a laryngeal suspension procedure is performed during reconstruction, laryngeal elevation is improved and swallowing is safety enhanced [35].
horizontal supraglottic laryngectomy could be extended to the base of the tongue or to the pyriform sinus.
in contrast to total laryngectomy, in partial laryngectomy, the communication between the airways and the digestive tract remains, but the excision of some of the structures which serve to prevent the bolus passing into the trachea (epiglottis, arytenoids, or vocal cords) explains why in these patients the most common postoperative complication is aspiration.
to eliminate aspiration, these patients should occlude the airway retracting the tongue base to make contact with the anteriorly tilting arytenoid [19].
so the tongue base makes complete contact with the posterior pharyngeal wall.
if complete contact is not made, there will be residue in the pharynx that falls directly into the airway.
in supracricoid laryngectomy (scpl) for transglottic tumors with glottic and supraglottic involvement and minimal extension to the infraglottis, the hyoid bone, the cricoid cartilage, and at least one arytenoid are preserved, thus maintaining the possibility of functional reconstruction.
there are two forms of laryngeal reconstruction: cricohyoidopexy (chp), in which the cricoid cartilage is placed closer to the hyoid bone (for supraglottic tumors that are nonresectable by supraglottic laryngectomy), and cricohyoidoepiglottopexy (chep), in which the epiglottis is maintained and its lower portion is included in the suture that approximates the cricoid to the hyoid bone (for glottic region tumors) [36].
the differences between the various subtypes of supracricoid laryngectomy are related to the amount of supraglottis removed and their extension, if any, to include one arytenoid.
the key functional outcomes are airway, phonation, and swallowing without aspiration.
phonation and swallowing depend on the arytenoids being able to tilt forwards and make contact with the base of the tongue; to breathe, the arytenoids tilt posteriorly to open the airway.
an intact cricoarytenoid unit is critical for function.
sacrificing one unit increases the chance of disabling aspiration in the cases where the epiglottis is resected.
scpl initially results in severe swallowing dysfunction, most notably aspiration, but permits the eventual return to oral nutrition for most patients [37–39] (figure 3).
supratracheal laryngectomy entails the resection of the entire supraglottic, glottic, and part of the subglottic sites, sparing both or at least one functioning cricoarytenoid unit.
a standard total laryngectomy involves dissection of the larynx from above the hyoid bone to below the cricoid cartilage.
the suprahyoid muscles are dissected from the hyoid bone [40].
the thyropharyngeus muscle is shaved off the thyroid cartilage, and the cricopharyngeus muscle is removed from the cricoid cartilage.
all of these muscles are preserved and later reconstructed to form the pharyngoesophageal segment (pes) which allows for optimum voice and swallowing function [40].
once the larynx is removed, the opened trachea and pharynx remain.
the exposed upper part of the trachea is secured to an opening in the neck to form a stoma, through which the patient will breathe.
the open pharynx then is closed.
provided that enough thyropharingeal and cricopharyngeal muscle remains, these are used as a second level of closure over the repaired pharynx [40].
this second layer of closure inwardly compresses the repaired pharyngeal tissue.
at rest, this is seen on videofluoroscopy as a closed narrow area and is referred to as the pharyngoesophageal (pe) or reconstructed segment [40].
the reconstructed pharynx after laryngectomy is referred to as a neopharynx.
the ability of the pes to dilate, coupled with the power created at the base of the tongue and the length of pes which remains open, dictates the patient's ability to swallow a variety of food consistencies.
in the pharyngeal phase, the reconstruction of suprahyoids by suturing them onto the superior margin of the repaired thyroglossus pull on the reconstructed segment, helping to lift the pharynx which in turn helps to relax the reconstructed thyropharyngeus opening entrance to the esophagus.
the bolus under reduced pressure from the tongue base and pharyngeal wall contraction exerts pressure from above.
this together with gravity moves the bolus onward.
72% of laryngectomy patients reported symptoms of dysphagia [41].
before commencing the videofluoroscopic examination of these patients, a metal marker should be placed to the right side of the stoma to indicate stoma level.
patient should be placed in a lateral oblique position to observe the hypopharingeal area and upper esophagus [40].
in the anteroposterior view, following the bolus as it passes from the neopharynx through the cricopharyngeus enables the study of esophageal swallow.
it should also provide a careful assessment of the entire esophagus as far as the oesophagogastric junction for the possibility of low benign stenosis, as shown by gibbons et al.
[9] and for a gastroesophageal reflux.
classic findings after laryngectomy are pseudodiverticulum and fistula.
pseudodiverticulum is a mucosalized pouch at the base of the tongue, separated from the remaining pharynx by a posterior tissue band (pseudoepiglottis).
a large diverticulum may obstruct bolus flow.
the incidence of fistulas reported in the literature is approximately 6% and they usually develop in the immediate postoperative period [42].
they generally originate from the anterior wall in relation to the suture at the lingual base, from the borders of the transplanted musculocutaneous flaps, and from the lateral wall and the pyriformis sinuses.
in an attempt to reach the cutaneous layer, they often end blindly in an extraluminal collection [12, 42] (figure 4).
6. conclusion swallowing mechanisms are different in relation to the various types of surgery.
the more the radiologist knows of the highly diverse anatomical and functional changes involved in the surgery, the more precise the analysis is of the swallowing function at baseline and the evaluation of effectiveness of treatment strategies carried out to improve the patient's swallow.
the best rehabilitation goals in head and neck cancer patients can be attained only by a team of specialists, including a radiologist, a surgeon, a speech-language pathologist, and a deglutition therapist who can plan and initiate the appropriate therapy, monitoring the improvements over time.
@highlight
head and neck squamous cell carcinoma is the sixth most common cancer diagnosed worldwide and the eighth most common cause of cancer death.
malignant tumors of the oral cavity, oropharynx, and larynx can be treated by surgical resection or radiotheraphy with or without chemotheraphy and have a profound impact on quality of life functions, including swallowing.
when surgery is the chosen treatment modality, the patient may experience swallowing impairment in the oral and pharyngeal phases of deglutition.
a videofluoroscopic study of swallow enables the morphodynamics of the pharyngeal-esophageal tract to be accurately examined in patients with prior surgery.
these features allow an accurate tracking of the various phases of swallowing in real time, identifying the presence of functional disorders and of complications during the short- and long-term postoperative recovery.
the role of imaging is fundamental for the therapist to plan rehabilitation.
in this paper, the authors aim to describe the videofluoroscopic study of swallow protocol and related swallowing impairment findings in consideration of different types of surgery.
