introduction an increasing number of functional proteins are reported to have β solenoid structure, such as antifreeze protein [1–3], curli [4], and carbonic anhydrase enzyme [5].
formed by winding the peptide chain in a left-handed or right-handed fashion, a β solenoid structure usually has a repeat unit consisting of 2, 3, or 4 β strands that are connected by turns [6].
each of these strands form parallel β sheets with their neighboring strands.
as a result, a β solenoid structure usually has two parallel β sheets with the strands facing in different directions.
the interior of β solenoid structures contains apolar amino acid side chains that are tightly packed [6], sometimes even interdigitated [7], resulting in a predominately hydrophobic core structure.
polypeptides in β solenoid structures have been used as building blocks of fibrils via controlled self-assembly in biomaterials applications.
they have been used to create viral capsids of dna strands[8], supramolecular nanotapes [9] and ph-responsive gels [10], which find biomedical application as matrices for human cells [11], beta solenoids (for short: beta rolls) can form fibrillar structures via two different mechanisms: end-to-end assembly where the terminals are covalently attached to each other, creating a very long β solenoid, or sheet-to-sheet assembly where the sheets associate physically resulting in a stack.
peralta et al.
[12] used the former type of self-assembly to generate micron length amyloid fibrils from spruce budworm antifreeze protein, a modified β solenoid protein.
beun et al.
used the latter type of self-assembly to produced fibrils made of stacks of ph-responsive silk-collagen-like triblocks [13].
according to experimental reports, the dimensions of fibrils consisting of stacks of bombyx mori silk-inspired polypeptides with a sequence of (gagagagx)n, where a and g stand for alanine and glycine, respectively, x is a polar residue and n is the number of repeating units [13] are consistent with β-solenoid structures stacked on top of each other [14].
to obtain a better understanding of the detailed structure of these fibrils, we recently investigated the β-solenoid structure formed by (gagagagq)10 via conventional molecular dynamics (cmd) simulations and found that the most probable structure formed by this sequence is a β-roll structure, with all the hydrophobic alanine side chains pointing inward, as shown in fig 1 [7].
this structure was found to be more stable than a structure reported earlier by schor et al.
where all the hydrophobic alanine side chains pointed outwards [14].
now that the ‘ground state’ structure of the building block in the filament has been determined, we wish to learn more about how initially disordered polypeptides fold into the β-roll structure and assemble to form the filament.
10.1371/journal.pcbi.1005446.g001 fig 1 top view (a) and a side view (b) of the two-molecule β roll stack.
a typical β roll structure has two oppositely oriented β sheets (in green) that are connected by β turns (in pink) and a hydrophobic core with its hydrophobic side chains (as shown in b) buried in the roll.
two different mechanisms have been proposed regarding the folding and docking of silk-inspired polypeptides.
the first mechanism, the “template folding” (tf) mechanism, was deduced from the temporal evolution of cd spectra when the polypeptide (gagagage)n formed fibrils [13]; according to tf the peptide starts to fold into a β roll structure once it attaches to the growing end of a pre-existing filament.
the experimental growth rate of filaments is very low (one molecule-per-second) and the fibril formation is irreversible.
the second mechanism, “solution folding” (sf), proposed by schor et al.
[15], is based on atomistic simulations, also for (gagagage); it claims that a polypeptide first folds in solution into a β-roll structure before it docks to the growing end of a fibril via glu-glu side chain interactions.
both mechanisms showed up in replica exchange monte carlo simulations carried out by ni et al.
[16], of the folding pathways of silk-inspired polypeptides with sequence [eiaiaiar]12 (i is isoleucin and r is arginine).
they found that at low temperature the polypeptide folds into a β-roll configuration before docking to another molecule, but at high temperature it folds after docking to another molecule.
it is important to point out here that the folding pathways proposed by schor et al.
[15] and by ni et al [16] are based on the β-roll structure predicted by schor et al.
[14], which has all the alanine side chains pointing outwards from the β-roll.
however, as mentioned earlier, our recent study [7] found that the β-roll structure formed by the silk-inspired polypeptide (gagagagq)10 has a higher probability to have a hydrophobic core than a hydrophobic shell, i.e.
all the alanine side chains should point inwards rather than outwards.
therefore, the folding pathway of the more probable hydrophobic core structure still remains elusive.
we use an enhanced sampling method, accelerated molecular dynamics (amd), to study the unfolding behavior of a two-molecule β roll stack.
we choose this method because conventional molecular dynamics (cmd) simulations of the folding of a peptide into a β roll are too slow.
this is understandable: the experimental time scale, corresponding to the addition of a single molecule to the growing end of a fibrils is thought to take about a second [13] which is orders of magnitude away from time scales reached in md simulations.
accelerated molecular dynamics (amd) has been used on many different oligomers and polypeptides, including alanine dipeptide [17], bovine pancreatic trypsin inhibitor (bpt1) [18], g-protein coupled receptors [19], and streptavidin-biotin complex [20].
one of the advantages of amd compared to other enhanced sampling methods is that it does not require pre-defined reaction coordinates.
this allows simulations to explore a broader range of hypothetical kinetic pathways than would otherwise be possible.
in amd simulations of proteins, boost potentials are added to the potential energy; for proteins one can choose to boost either the total potential energy of the system, or the dihedral energy, or both.
the boost potential is only added to potentials below a pre-defined threshold energy; for energies above that level the original shape is retained.
amd makes barrier crossing between low energy states easier and therefore provides access to regions of conformational space that are unreachable in cmd simulations.
the long term goal of our study is to elucidate the folding mechanism of silk-inspired polypeptide, as well to identify the dominant forces that maintain the β roll configuration.
as there is no unambiguous way to choose a representative starting configuration, we decided to focus on unfolding rather than folding, which should give us clues as to the likeliness of hypothetical folding pathways.
to this end, we simulate a stack of two molecules having sequence (gagagagq)10, each folded into a β roll with a hydrophobic core (fig 1) and in explicit solvent.
amd is used to study the unfolding behavior of one of the β roll structures at systematically increased values for the threshold.
we first study the system with a stack of two β roll molecules, using the lowest threshold.
then we simulate a system with a partially-fixed bottom template and a relatively high threshold; this enables us to observe the unfolding behavior of a single molecule on top of the template, and also gives us information about which forces are most important in maintaining the β roll structure.
finally, we challenge the system with partially-fixed bottom template by a further increase of the threshold to gain a better picture of the intermediate structures that form along the entire unfolding pathway.
the major findings in this paper are the following.
first, we find that in the system without fixed atoms the molecules unfold in a step-wise fashion, and both molecules unfold completely by the end of the simulation.
the unfolding is initiated mainly from the c terminal.
second, in the stack with a partially-fixed bottom template the top molecule has more difficulty unfolding than the molecules in the stack without any fixed atoms, indicating the importance of the template in stabilizing the folded structure of a β roll molecule in a stack.
third, there is a hierarchy of hydrogen bond strengths.
lateral hydrogen bonds formed between β strands within the β sheets in a β roll structure are stronger than the vertical hydrogen bonds within the β turns; h bonds are weaker when they are closer to the sides of the β turns.
the lateral hydrogen bonds within the bottom layer in the top β roll molecule are stronger than those in the top layer, which suggests that the bottom template strengthens the hydrogen bonds within the β sheet that it contacts.
as the amd threshold on a system with partially-fixed bottom template is further increased, we find that the β roll on top tends to form hydrogen bonds with the bottom template to resist leaving it, revealing a “self-healing” property, which helps explain the toughness of the fibrils formed in the experiment.
results molecules in β roll structure unfold in a step-wise fashion we begin by describing our amd simulation results on the stack of two β roll molecules with sequence, (gagagagq)10, without fixed atoms, and at the lowest threshold as characterized by n = 2 in eq 7.
(recall that n is an integer in eq 7 that determines the magnitude of the threshold as a multiple of the acceleration factor.)
in fig 2, the order parameter of the top molecule, ω, which measures the departure of the β roll from its ideal structure, is plotted against the simulation time, revealing the striking result that molecules in the β roll structure unfold in a step-wise fashion.
in cmd simulations, ω for the top molecule remains roughly constant around 62±2, indicating that the molecule stays in the β roll structure throughout the entire simulation.
in contrast, in amd it decreases in a step-wise fashion and eventually reaches zero.
roughly, five different plateaus can be discerned in the plot: 1–28 ns (ω = 52), 32–48 ns (ω = 38), 52–66 ns (ω = 30), 70–74 ns (ω = 24), and 78–90 ns (ω = 2).
the representative structures corresponding to the different states shown in fig 2 were calculated via clustering analysis.
the step-wise unfolding of the β roll structure agrees well with single-molecule force spectroscopy (smfs) measurements by sapra et al.
on the unfolding pathways of β-barrel-forming membrane proteins, ompg [21].
by mechanically pulling on a single atom at one end of ompg they found that each β hairpin of the ompg β barrel unfolded either individually, or cooperatively with an adjacent β hairpin, causing the ompg protein to unfold in a step-wise fashion.
10.1371/journal.pcbi.1005446.g002 fig 2 order parameter, ω, of the top molecule in the stack of two β roll molecules plotted against simulation time and representative structures at each stage from clustering analysis.
the ω of the top molecule in the cmd simulations (in blue) remains at around 62, and the ω of the top molecule in the amd simulations (in black) decreases in a step-wise fashion.
the order parameter, ω, at different stages of the amd are labeled from a to j. the β roll is in a perfect condition with no strands off (a), then the first strand comes off n terminal (b); another strand comes of c terminal (c), followed by the second strand lifting off from c terminal (d), after which the second strand from c terminal goes back to the β roll (e); then the second strand comes off c terminal (f), followed by the third strand off the c terminal (g); then the third strand from the c terminal goes back (h), after that the third and the fourth strands come off c terminal simultaneously (i); finally the chain unwraps completely (j).
the representative structures of each stage generated from clustering analysis are shown below the plot, with β sheets in green, β turns in pink and random coil structures in white.
the bottom molecule is silver with a transparent representation.
the unfolding pathway of the top molecule in the stack as revealed by amd simulation can be described as follows.
the molecule starts from a perfect β roll structure (see fig 2(a) with a ω of ~ 62 and then reaches its first plateau which lasts from 1 ns to around 28 ns.
the representative structure generated from clustering analysis is shown in fig 2(b) with one strand lifted off from the n terminal.
by 28 ns, another strand from the c terminal starts to come off the β roll structure as shown in fig 2(c).
this is a transient state because the order parameter quickly moves to the second plateau that lasts from around 32 ns to 58 ns.
the representative structures that occur during this plateau are shown in fig 2(d), 2(e) and 2(f).
the majority of structures that occur during this plateau have one strand off of the c terminal and two strands off of the n terminal as in fig 2(d) and 2(f).
the second strand from the n terminal goes back to the β roll structure for a short period of time within this plateau, from around 41 ns to 44 ns, as shown in fig 2(e).
after 52 ns, the order parameter reaches another plateau, with ω ~ 30, during which the third strand peels off the β roll from the c terminal as shown in fig 2(g).
this strand goes back to the roll structure for a short period of time as shown in fig 1(h), and then quickly comes off the β roll together with the fourth strand from the c terminal at around 70 ns, as shown in fig 2(i).
after that, there are only five strands left in the β roll structure, which is not enough to maintain the configuration.
starting at 73 ns, the molecule collapses quickly and becomes a random coil structure.
some refolding events occur during the unfolding process, mainly when one loose strand goes back to its original neighbor.
for example, as shown in fig 2, the second strand comes off the c terminal at stage d, then goes back to the c terminal at stage e, and finally comes off the c terminal again at stage f. moreover, the third strand from the c terminal comes off at stage g, then goes back at stage h, and eventually comes off of the c terminal with the fourth strand at stage i. the β roll molecules thus appear to unfold in an asymmetric fashion, namely mainly from the c terminal, as evidenced by the unfolding pathway just described.
this finding agrees well with a report by alsteens et al.
based on a steered molecular dynamics (smd) simulation study in which a prototypic tpsa protein, fha [22] unfolds mainly from the c terminal.
in addition, our simulation suggests that a β roll configuration needs to have a nucleus of a certain size to maintain its structure: the sequence (gagagagq)10 needs to have at least half of its strands, 5 strands, in a β roll structure, in order to maintain the β roll configuration.
with less folded strands, it collapses and forms an amorphous configuration.
a second simulation of the two-molecule stack without fixed atoms having the same amd boost parameter (n = 2) was performed in order to check for reproducibility.
this second simulation was performed for 200 ns longer than the first simulation as the chain took longer to completely unfold.
both simulations exhibit step-wise unfolding behaviors as can be seen in fig 3, which plots the order parameter, ω, versus time for simulations 1 and 2. the two simulations go through the same stages as the unwrapping occurs, each stage is outlined in blue in fig 3. this similarity helps to support the reproducibility of our simulations of the unfolding process.
10.1371/journal.pcbi.1005446.g003 fig 3 order parameter, ω, of the top molecule in the stack of two β roll molecules plotted against simulation time of the simulation in fig 2 (black) and an additional simulation (red) with the same amd boost parameter, n = 2. the order parameters of both simulations go through 3 stages (outlined in blue) before reaching zero.
partially-fixed bottom template helps stabilize the β roll structure on top of it amd simulations are then performed on systems containing a stack of (gagagagq)10 β roll molecules with a partially-fixed bottom template at the threshold potential energy with n = 2 in eq 7. by having a partially-fixed bottom template (as defined above), molecules in the stack do not unfold simultaneously and their unfolded strands do not entangle with each other.
thus we observe the unfolding behavior of just the molecule on top.
fig 4 shows the final structures in the three different types of simulations that we ran.
the first type of simulation uses the threshold with n = 2 in eq 7 and does not have any atoms fixed.
as a result, both molecules in the stack in simulation 1 unfold completely after 80 ns; the snapshot in fig 4 (a) is taken at the point at which ω = 0 in fig 3. a similar completely unfolded state occurs after 140 ns for simulation 2 in fig 3. the second type of simulation is performed on a system that contains a partially-fixed bottom template and uses an intermediate threshold with n = 2 in eq 7. as shown in fig 4(b), the final structure of the top molecule in the stack has three unfolded strands: one off at the n terminus, and two off at the c terminus.
the third type of simulation is again for a system with partially-fixed bottom template, and uses the highest threshold with n = 2.5. now, five strands unfold from the top β roll molecule, as seen in fig 4(c).
this molecule does not unfold completely even after 300 ns of amd simulations with an increased threshold, in stark contrast to the behavior observed in the system without partially-fixed template, where the chain collapses quickly when there are only 5 strands left in the β roll.
these observations once again underline the importance of having a partially-fixed bottom template to stabilize the top β roll structure.
10.1371/journal.pcbi.1005446.g004 fig 4 the final structures from three different sets of simulations of systems with (a) a two-molecule stack of β roll structures without fixed atoms at lowest threshold, (b) a two-molecule stack of β roll molecules with partially-fixed bottom template and intermediate threshold, and (c) a two-molecules stack of β roll molecules with partially-fixed bottom template and highest threshold.
the bottom template is colored gray and is transparent.
random coil structures are in white, β turns are in pink and β sheets are in green.
unfolding of a two-molecule stack with partially-fixed bottom template reproduces that of a stack without partially-fixed bottom template the unfolding process for the top molecule in the two molecule stack with partially-fixed bottom template and boosts n = 2.0 or n = 2.5 resembles that of the molecule in the stack with no atoms fixed.
fig 5 plots the order parameters of the top molecule in the simulations with boost n = 2.5 and n = 2 against simulation time.
the top molecule in the simulation with boost n = 2.5 (fig 5a) shows that it goes through 5 stages to reach the final configuration, which has 3 strands coming off the n terminal and 2 strands coming off the c terminal.
this stepwise unfolding is similar to the unfolding behavior of the top molecule in the stack without fixed atoms and n = 2 shown in fig 2. the sequence of steps is: one strand comes off the n terminal, one strand comes off the c terminal, the second strand comes off the c terminal, the second strand comes off the n terminal, and finally the third strand comes off the n terminal.
the only difference between the unfolding process for n = 2.5 with fixed atoms and n = 2 without fixed atoms is that the strands from n terminal come off earlier when n = 2.5 than when n = 2. the top molecule in the simulation with n = 2 and partially-fixed bottom template also unfolds in a step-wise fashion as shown in fig 5b.
therefore, the unfolding behavior seems to be independent of the value of the boost potential.
10.1371/journal.pcbi.1005446.g005 fig 5 order parameter of the top molecule plotted against simulation time in simulations with partially-fixed bottom template and boosts (a) n = 2.5, and (b) n = 2. the order parameter of both molecules are divided into several stages.
each stage corresponds to the unfolding stage labeled at the top of the graph.
lateral hydrogen bonding is stronger than vertical hydrogen bonding to identify the dominant forces in the β roll structure, we plot, for the selected hydrogen bonding atom pairs indicated in fig 6, hydrogen bond potentials of mean force (pmf) versus distance in figs 7 and 8. these are based on the trajectories generated by the amd simulations with boost potential n = 2 and partially-fixed bottom template.
note that here we present the unweighted pmf versus the distance of hydrogen bonded pairs of only one of the two simulations-performed using boost potential n = 2 and partially fixed bottom template (recall that we performed two simulations for each set of parameters as shown in table 1 in the method section).
the unweighted pmf versus the distance of hydrogen bonded pairs of the other simulation is provided in the supporting information in s2 fig and s3 fig.
hydrogen bonds in a β roll configuration are categorized as being either lateral or vertical (see fig 6).
lateral hydrogen bonds refer to the ones formed between the neighboring β strands in a single β sheet, or between neighboring β turns, and vertical hydrogen bonds refer to the ones between atoms in the top and bottom of a single β turn, or between atoms in the β turns of top and bottom molecules.
all the unweighted potential of mean force profiles in fig 7 (lateral h bonds) and 8 (vertical h bonds) are calculated with three different bin sizes, resulting in three curves for each plot.
these curves match well with each other, indicating that we have enough samples for the calculation.
10.1371/journal.pcbi.1005446.g006 fig 6 illustration of lateral h-bonds and vertical h-bonds in the stack of two β roll molecules showing β strands (green) and β turns (pink) involved in the h-bonding calculation.
lateral h-bonds (blue dashed line) are between β sheets and between β turns.
vertical h-bonds (red dash-dot line) are within β turns or between a turn in the top molecule and a turn in the bottom molecule.
10.1371/journal.pcbi.1005446.g007 fig 7 unweighted pmf plotted against the distance between the lateral hydrogen bonded atom pairs shown in fig 4 (blue dashed line) from one amd simulation using boost potential n = 2 and partially-fixed bottom template.
three different bin sizes are shown in these plots.
the hydrogen bonding pairs being presented are the oxygen atom on the 51th gly residue and the hydrogen atom on the 68th ala residue (a); the hydrogen atom on the 53rd gly residue and oxygen atom on the 68th ala residue (b); the oxygen atom on the 53th gly residue and hydrogen atom on the 70th ala residue (c); the oxygen atom on the 56th gln residue and hydrogen atom on the 73rd gly residue (d); the oxygen atom on the 59th gly residue and hydrogen atom on the 76th ala residue (e); the hydrogen atom on the 61st gly residue and oxygen atom on the 76th ala residue (f); and the oxygen atom on the 61st gly residue and hydrogen atom on the 78th ala residue (g).
10.1371/journal.pcbi.1005446.t001 table 1 simulation lengths and threshold energies for the three different types of accelerated md simulations (amd).
systems (2 simulations for each parameter) simulation length (ns) thresholds used in amd characterized by na two-molecule β roll stack 100 threshold with n = 2 two-molecule β roll stack 200 threshold with n = 2 two-molecule β roll stack with partially-fixed bottom template 300 threshold with n = 2 two-molecule β roll stack with partially-fixed bottom template 400 threshold with n = 2 two-molecule β roll stack with partially-fixed bottom template 300 threshold with n = 2.5 two-molecule β roll stack with partially-fixed bottom template 400 threshold with n = 2.5 athe number of acceleration factors, αtotal, included in the threshold in eq 3. the unweighted pmfs associated with the hydrogen bonded atom pairs in figs 7 and 8 have global minima at ~ 1.9 angstroms, indicating that these atoms prefer to stay within the hydrogen bonding distance.
this reveals that the original β roll structure, in which all these atoms can form hydrogen bonds, is more stable than the unfolded structure, where only a few h bonds are possible.
the hydrogen bonding strengths are taken to be the values of the pmf at the first peak in the pmf versus distance curves.
10.1371/journal.pcbi.1005446.g008 fig 8 unweighted pmf versus the distance between the vertical hydrogen bonded atoms pairs shown in fig 4 (red dash-dot line) for one amd simulation using boost potential n = 2 and partially-fixed bottom template.
the hydrogen bonding pairs being presented are the oxygen atom on the 63rd gly residue and the hydrogen atom on the 66th ala residue (a); the oxygen atom on the 71st gly residue and the hydrogen atom on the 74th ala residue (b); the oxygen atom on the 73rd ala residue and the hydrogen atom on the 152nd residue (c).
the average hydrogen bond strengths in the two simulations with boost potential n = 2 and partially-fixed bottom template are given in fig 9. the figure shows the hydrogen bonding strengths for the lateral hydrogen bonds between β strands (green) and between β turns (pink), and the vertical hydrogen bonds within β turns (blue) and between the turns in the top and bottom molecules (yellow).
the first 3 columns represent the strengths of the lateral hydrogen bonds between the neighboring β strands in the top layer of the β roll structure as shown in fig 6. the strengths of the lateral hydrogen bonds along the β strands in both the top and bottom layers of the β roll molecule are weaker when the hydrogen bonds are closer to the β turns: e.g.
the hydrogen bonds between residues 51–68 and between residues 53–70 have a lower strength than the hydrogen bonds between residues 53–68.
the strength of the lateral hydrogen bond formed between residues 56–73, indicated by the height of the 4th bar, is weaker than the lateral hydrogen bonds within the bottom layer but stronger than the lateral hydrogen bonds within the top layer of the top β roll molecule.
something similar is observed for the hydrogen bonds between neighboring β strands in the bottom layer of the β roll structure; see the 5th, 6th and 7th columns in fig 9.
10.1371/journal.pcbi.1005446.g009 fig 9 hydrogen bonding strengths obtained from unweighted pmf profiles versus different hydrogen bonded residue pairs averaged over two amd simulations with boost potential n = 2 and partially-fixed bottom template.
lateral h-bonds between strands (green) and lateral h-bonds between turns (pink), vertical h-bonds within turns (blue) and vertical h-bond between the two molecules (yellow).
the lateral hydrogen bonds in the lower layer of the β roll structure are clearly stronger than those in the upper layer of the β roll structure.
as seen in fig 9, the 5th, 6th and 7th columns representing the hydrogen bonding strength in the bottom layer of the β roll, are higher than the first three columns representing the hydrogen bonding strength in the top layer of the β roll.
this is likely a consequence of the bottom layer in the top molecule being in direct contact with the bottom template.
the effect of stacking on the stability of the roll was investigated in our previous study [7]; there we found that stacking helps stabilize the β roll structure by increasing the number of intra-molecular hydrogen bonds in each β roll molecule.
here we see that in terms of bond energies that conclusion is confirmed.
the vertical hydrogen bonds are usually weaker than the lateral hydrogen bonds.
this can be observed by comparing the heights in fig 9 of the first 7 columns, which represent the strengths of the lateral hydrogen bonds, with the heights of the last 3 columns, which represent the strengths of the vertical hydrogen bonds.
the heights of the two blue columns in fig 9, which represent hydrogen bonds within the β turns, are smaller than those of the first 7 columns, representing the lateral hydrogen bonds.
this signifies that lateral hydrogen bonds play a more important roll than vertical hydrogen bonds in keeping the molecule in a β roll configuration.
the height of the yellow bar, which represents the average strength of the hydrogen bond between the top and bottom molecules (there is one such bond per strand), is slightly lower than that of the first three columns, indicating that the hydrogen bonds between the two molecules are almost as strong as the lateral hydrogen bonds between the β strands in the upper layer of the top molecule.
this suggests that the hydrogen bonds between the two molecules also play a significant role in maintaining the β roll structure of the top molecule.
higher threshold simulations reveal other potential structures and self-healing ability in the simulation with the highest threshold energy, where n = 2.5 in eq 7, and a partially-fixed bottom template, a new intermediate structure shows up.
it contains a β hairpin structure and an anti-parallel β sheet formed by strands from the top and bottom molecules.
fig 10(a) shows the unweighted pmf versus the distance between the hydrogen on gln (residue 24) and the oxygen on ala (residue 26).
two minima are identified in the plot, a local minimum at short distance (a) and a global minimum further out (b).
the intermediate structure associated with the local minimum is shown in fig 10(b) and its side view is shown in fig 10(c).
the structure associated with the global minimum is a distorted β roll structure as shown in fig 10(d).
the potential well of the intermediate structure is located at ~ 2 angstroms, indicating that a hydrogen bond forms between the hydrogen on gln (residue 24) and the oxygen on ala (residue 26), i.e., residues 24, 25 and 26 have formed a three-amino-acid turn.
strands 3 and 4 form an antiparallel β sheet structure.
taken together, the turn and the antiparallel structures are essentially a typical β hairpin structure.
another anti-parallel β sheet is formed between strand 2 in the top molecule and the silver strand in the bottom molecule.
a side view of this structure is seen in fig 10(c) which shows how strands 2 and 3 traverse the interface between the two molecules.
the reason this structure forms is that the first strand from the n terminal in the bottom template is not fixed and breaks loose.
this provides enough room for the second and third strands of the top molecule to reach down one layer, forming β sheets with the strand in the bottom template.
10.1371/journal.pcbi.1005446.g010 fig 10 the pmf profile of hydrogen atom on gln and the oxygen atom on ala and corresponding representative structure at each minimum.
the unweighted potential mean force associated with hydrogen atom on gln and the oxygen atom on ala is plotted against the distance between the two atoms (a).
two minima are identified, a local minimum, a, and a global minimum, b. an intermediate structure (b) and its side view (c) correspond to the energy local minimum a. a distorted β roll structure associated with the global minimum of energy, b, is shown as (d).
the anti-parallel β sheet formed by strands from the top and bottom molecules in the intermediate structure is of particular interest to us as this configuration could potentially inhibit the unfolding process.
in a long fibril with many molecules, the molecules in a β roll structure will probably not always stack as perfectly as in our starting configuration, meaning that strands from some molecules could potentially form β sheets with their folded neighbors, thus preventing the unfolding process.
we call this a self-healing ability because it seems to hinder the β roll molecule from completely unwrapping; it might be one reason why the fibrils observed in the experiments are very strong.
considering the results obtained here with respect to unfolding, we tentatively propose a hypothetical folding pathway; we emphasize that this is highly speculative and should not be considered as a conclusion supported by the simulation data obtained here, but rather as a direction for further studies.
the folding process most likely starts with docking of a disordered silk-like (gagagagx)n domain on a pre-folded molecule acting as template.
this consistent with the observation that the template provides stability to the folded roll, and with the experimental fact that secondary structure develops in parallel with fibril growth.
the disordered domain has to remain long enough in the docked state to allow for nucleation of a minimal folded part, e.g., a 5-stranded β solenoid.
this step has a very low probability and is therefore likely to be rate-determining, accounting for the very low growth rates observed experimentally11.
moreover, it also would explain why silk-like domains of higher number of repeating units, which are likely to have longer residence times and a higher nucleation probability, tend to give faster growth [23].
once nucleation has occurred, the remainder of the silk-like domain can fold to form the complete β solenoid.
discussion we used accelerated molecular dynamics (amd) simulations to investigate the unfolding of a stack of two β roll molecules, (gagagagq)10. although much is known of about the structure of the β solenoid, very little is known about the partially folded conformation of the silk-like polypeptide or the details of the folding/unfolding process.
unfolding simulations can help us understand biological processes and, when well sampled, can provide us with partially-folded structures.
amd is able to maintain the original shape of the energy landscape and let the molecule sample conformational space fairly naturally.
our goal was to identify the dominant forces that keep the silk-inspired polypeptide in a β roll configuration, to investigate the unfolding mechanism of silk-inspired polypeptides.
the β roll structure that we use in this study was obtained from our previous investigation of the stable configuration of the β roll using the same sequence (gagagaga)10. unlike the structure proposed by schor et al.
[14] where all the alanine residues pointed out, forming a hydrophobic shell, the structure used in this study possesses a hydrophobic core which we have shown to be more stable than that with a hydrophobic shell [7].
the size of the boost potential was chosen carefully.
it should not be so small that unfolding is unlikely to occur, as this would essentially be the same as a conventional md simulation and it should not be too strong, because this might induce an unrealistic unfolding process.
the number of boost potentials added to the original potential, n, was therefore chosen to reveal both the unfolding and the any spontaneous refolding of the polypeptide that occurred during the simulations.
the unfolding process of the molecule on top without any fixed atoms showed rejoining of the strands as well as unfolding.
moreover, we saw that the unfolding process can be reproduced by additional simulations with the same parameters and even by simulations with different boost potentials.
to justify the convergence of our simulations, the relaxation time of the peptide backbone vectors is estimated from the time autocorrelation function profile.
s1 fig show a plot of the time correlation function of the out-of-plane vectors (the vector that is perpendicular to the plane formed by 3 consecutive carbon atoms) of the polypeptide versus the simulation time.
the time at which this reaches zero gives a measure of the relaxation time of the peptide [7].
the relaxation time is less than 10 ns for simulations without fixed atoms, indicating that our 100ns simulation is long enough to reach equilibrium.
the 300 ns simulations with partially-fixed bottom template have relaxation times less than 100 ns, which indicates that the molecules in these systems have reached equilibrium.
by comparing the unfolding order parameter, ω, versus simulation time between cmd and amd, we found that a molecule in a stack of two β roll molecules unfolds in a step-wise fashion, i.e.
one β strand in the β roll molecule at a time, which agrees well with the experimental study on transmembrane β-barrel protein ompg by sapra et al.
[21].
we also found that it unfolds mainly from the c terminal, which matches with the simulation study on a prototypic tpsa protein, fha by alsteens et.
al [22].
through observing the unfolding and spontaneous refolding of single strand in the β roll structure, we get a better idea of the possible intermediates that might occur during the folding process.
schor et al.
[15] hypothesize that the molecule folds into a β roll structure with a hydrophobic shell by itself, then docks onto another preformed β roll molecule, a “roll n’ dock” process.
the bottom template is found to play an important role in stabilizing the β roll structure of the molecule on top.
this was concluded by comparing the final structure in three sets of simulations with systematically increased threshold energies.
at the lowest threshold energy, both molecules unfold and have a random coil structure by the end of the simulation for systems without any fixed atoms.
when the bottom template is partially fixed, the top molecule is unable to unfold completely, even by the end of 300 ns simulations, indicating the significance of the bottom template in stabilizing the molecule on top of it.
we further elucidate how the bottom template stabilizes the top β role molecule by quantifying the strengths of the various intra and inter molecular hydrogen bonds.
the lateral hydrogen bonds in the lower layer of the top molecule are stronger than those in its upper layer, indicating that the bottom template strengthens the hydrogen bonds in the lower layer of the top molecule.
we further confirm the stabilizing effect of the bottom template reported in our previous investigation, in which we concluded that the bottom template induces more intramolecular hydrogen bonds in the top molecule when it docks on to the bottom template[7].
we also found that the lateral hydrogen bonds between the β strands in a β roll configuration become weaker as they get close to the β turns.
this is due to the fact that the β turn structure is more flexible than the β sheet structure in the β roll molecule.
vertical hydrogen bonds within the β roll structure are considerably weaker than lateral hydrogen bonds, signifying the importance of lateral hydrogen bonds in stabilizing the β roll structure.
finally, an intermediate structure was found containing a β hairpin and an anti-parallel β sheet formed by strands from the top and bottom molecules, revealing the self-healing ability of the β roll stack.
the β hairpin structures can form fibrils by themselves as reported by other studies [22, 23] in which β hairpins first stack by hydrophobic interactions and then assemble via hydrogen bonds.
here we found β hairpins in the stack of two silk-inspired molecules, indicating that these β hairpins may also play a role in stabilizing silk-inspired fibrils with many molecules.
such β sheets formed between pairs of molecules, an inter-protein β sheet structure, were also reported by razzokov et al., who studied a sequence similar to ours, (gagagage)5, using replica exchange molecular dynamics[24].
overall, the strength of the fibril of β roll molecules comes not only from the stability of each individual molecule, but also from the cooperative effect provided by the anti-parallel β sheet structures formed by strands from the top and bottom molecules.
our results led us to tentatively propose a hypothetical folding pathway that is consistent with the experimental results.
methods conventional molecular dynamics in our previous paper7, we performed conventional explicit-solvent atomistic molecular dynamics simulations on a stack of two β roll molecules with a sequence (gagagagq)10 using amber 12 and the ff12sb force field.
the simulation details can be found in our previous paper[7).
the last 50 ns of those trajectories were used to calculate the time averages of the total potential energy of the system as well as the dihedral energy of the peptides.
general form of accelerated molecular dynamic the general principles of amd are as follows.
a boost potential δv(r) is added to the original potential energy surface of the system when the system’s potential energy is lower than a predefined threshold energy, e [25], as shown in fig 11. v*(r)=v(r)+δv(r),v(r)<e,v*(r)=v(r),v(r)≥e,(1) where v*(r) is the modified (boosted) potential energy, v(r) is the original potential energy (which could be the total potential energy of the system or the dihedral energy of the polypeptide) and r is a positional degree of freedom or a torsional degree of freedom, etc.
the general form of the boost potential, δv(r) is given by the equation below: δv(r)=(e−v(r))2α+e−v(r)(2) where α is the acceleration factor.
the acceleration factor is a parameter that governs the size of the boost.
as it gets smaller, the energy surface becomes flatter, thus improving the likelihood of transitions between low energy states.
the gist of the method therefore is that the global pattern of the potential energy is maintained, but barriers become smaller, allowing easier passage.
10.1371/journal.pcbi.1005446.g011 fig 11 illustration of amd simulation.
graph of v(r) versus r showing a low threshold potential energy, e, (black horizontal line) and a high threshold potential energy, e’, (blue horizontal line).
in an amd simulation, a boost δv(r) is added to the original potential energy landscape v(r) when the system potential or the dihedral energy is lower than the predefined threshold e, resulting in the boosted potential energy, v*(r) (dashed red line).
regions of the potential energy curve that are above the threshold energy maintain their original form.
if the threshold energy is increased to e’, a larger boost potential energy, δv’(r) is added to the original free energy.
in that case another free energy minimum goes below the new threshold, e’, resulting in a boost potential added to that region.
the shape of the energy surface and the position of the energy minimum remain the same after adding the boost.
dual-boost accelerated molecular dynamics dual-boost amd simulations are performed in our investigation, which means boost potential energies are added to both the total potential energy of the system and to the dihedral energy of the polypeptides.
the total potential energy of the system vtotal (r) consists of the dihedral energy vdihedral(r) and the non-dihedral energy vnon-dihedral(r) as shown below, vtotal(r)=vnon−dihedral(r)+vdihedral(r).
(3) in a dual boost amd simulation, a boost potential δvdihedral(r) is first added to the dihedral energy of the peptide as in eq 4 below, vdihedral*(r)=vdihedral(r)+δvdihedral(r)(4) where vdihedral*(r) is the modified dihedral energy of the peptide.
then a boost potential δvtotal(r) is added to the total potential energy of the system as shown in eq 5 below, vtotal*(r)={vnon−dihedral(r)+vdihedral*(r)}+δvtotal(r)(5) where vtotal*(r) is the modified total potential energy and δvtotal(r) is the boost potential energy added to the total potential energy of the system, vtotal(r).
the equations used to calculate the boost potential of the total potential energy of the system vtotal (r) and the boost potential of the dihedral energy vdihedral(r) are δvtotal(r)=(etotal−vtotal(r))2αtotal+etotal−vtotal(r)δvdihedral(r)=(edihedral−vdihedral(r))2αdihedral+edihedral−vdihedral(r)(6) where etotal and edihedral are the thresholds for the total energy and dihedral energy, and αtotal and αdihedral are the acceleration factors for the total potential energy and dihedral energy.
note that these equations are of the same form as eq 2. the pre-defined thresholds, etotal and edihedral, and the acceleration factors, αtotal and αdihedral, for the two types of boosts are calculated as below, edihedral=vavg_dihedral+3.5×nres,αdihedral=3.5×nres/5etotal=vavg_total+n×αtotal,αtotal=0.2×natoms(n=1,2,3…)(7) where vavg_dihed and vavg_total are time averages of the dihedral energy and total potential energy obtained from conventional molecular dynamics (cmd).
these are calculated only once, before running the amd simulations, to generate the value of thresholds.
the parameters nres and natoms are the number of polypeptide residues and the number of atoms in the system, respectively; n in eq 7 is an integer that determines the magnitude of the threshold as a multiple of the acceleration factor.
consequently, there are only four input parameters in an amd simulation: edihedral, αdihedral, etotal and αtotal.
all the other parameters are calculated based on these four values.
sometimes we increase the threshold of the total potential, etotal, by making the value of n in eq 7 larger, to let the system access more conformational space.
increasing the threshold of the total potential energy enables more energy minima to lie below the threshold and have boost potentials added to them.
as shown in fig 11, the third free energy minimum from the left does not get an added boost potential when the threshold is e. when the threshold to is increased to e’, the third minimum falls below the threshold, so a boost potential is added to it.
this facilitates the transition between the second and the third minima.
we used different threshold energies in different sets of simulations in our investigation, so the value of n in eq 7 varies from simulation to simulation.
amd simulation of the β roll stack we ran three types of amd simulations on the stack of two β roll molecules (gagagagq)1210 shown in fig 1 and two simulations for each set of amd boost parameter as shown in table 1. the first type of simulation uses the lowest threshold potential energy with n = 2 in eq 7. this type of simulation is performed for 100 ns.
the second and the third type of simulations use increased threshold potential energies with n = 2 and 2.5, respectively, and are performed for 300 ns each.
during the first type of simulation, no atoms are fixed.
however, during the second and the third types of simulations, 10 cα atoms in the glycine (g) residues at the bottom of the β turns on both sides of the β roll molecule are spatially fixed to maintain the bottom template’s β roll configuration, as shown in fig 12. these atoms are restrained with a force of 10 kcal/mol, and were chosen to mimic the presence of a substrate.
in experiment, a substrate is used to grow fibrils; the fibrils are found to grow perpendicular to the substrate [16,26].
fixing specific atoms in the bottom β roll molecule helps maintain the bottom molecule in a β roll configuration, while allowing some flexibility to the chain.
the simulation times, as well as the number of acceleration factors added to the average system’s total potential energy for different types of simulations are summarized in table 1.
10.1371/journal.pcbi.1005446.g012 fig 12 illustration of fixed atoms in the bottom β roll molecule with sequence (gagagagq)10 in both normal view (a) and side view (b).
the fixed atoms (cyan beads) are the cα atoms on the glycine residues on each side of the β roll below the β turns (in pink).
the parallel β sheets are in green and random structures are in white.
potential mean force calculation hydrogen bonds play a very important role in keeping the folded and stacked structure together.
we therefore pay specific attention to the strength of these bonds, by calculating potential of mean force (pmf) profiles.
potential mean force (pmf), used synonymously in the literature to indicate a free energy profile, examines the change of a system’s free energy as a function of some specific reaction coordinate, such as the lateral distance between the hydrogen bonding sites on two neighboring β strands or the vertical distance between hydrogen bonding sites within a β turn structure or between the two stacking molecules.
in this work we take as our reaction coordinates the distances between the important hydrogen bonded atoms pairs.
the strength of the hydrogen bonds can be gleaned from the height of the first peak in these pmf profiles.
the dominant forces controlling docking and folding of the β roll can then be determined by comparing the strengths of these hydrogen bonds.
usually, the free energy profiles generated from the amd simulations need to be reweighted using the boltzmann factor for the boost potential [17].
however, given the large size of our system, there is a large noise associated with reweighting the free energy profile.
therefore, and since we use the profiles only for comparative purposes, unweighted pmf profiles are presented in this paper.
a similar approach was used in a study of the free energy landscape of large systems of g-protein coupled receptors [19] by miao et al.
the unweighted potential of mean force or f(aj) is calculated as a function of the distance aj between hydrogen-bonded partners, for different atoms pairs.
the relevant equation is f(aj) = -kbtln p(aj), where p (aj) signifies the probability of finding the atoms pairs within aj (distances are divided into a number of equally distributed bins with index j), kb is the boltzmann constant, and t is the temperature of the system.
the hydrogen bonded atom pairs used to calculate the potential mean force (pmf) are constantly forming and breaking with time.
s1 table gives the hydrogen-bonding average lifetimes which were calculated in the following way.
in the hydrogen-bonding data set, we define a hydrogen bonding indicator for each pair of atoms to be 1.0 when they are hydrogen bonded and 0.0 when they are not.
the average lifetime is determined by averaging the length of time that a particular hydrogen bond is present continuously.
as shown in s1 table, the number of times that the hydrogen bonds form and break varies from 2007 times to 6808 time.
the maximum lifetime for hydrogen bonded atom pairs in pmf calculations is between 50 ps and 223 ps.
the average lifetime for atom pairs in pmf calculations is from 6.123 ps to 24.0842 ps.
it is apparent that the hydrogen bonds are constantly breaking and forming, over our simulations which of to 300,000 ps.
unfolding order parameter in order to characterize the state of molecules with respect to folding, an unfolding order parameter, ω, is needed which measures departures of the β roll from its ideal structure.
we here define ω as the number of amino acids that are at an appropriate distance to the neighbor they would have in an ideal β roll structure, e.g., by counting pairs of residues i and i+16, that are within a distance of 4.0 to 6.0 angstroms of each other.
this typical range has been inferred from cmd simulations during which the molecules retain their β roll structure.
when the (gagagagq)10 peptide (which has a total of 80 residues) is in a perfect β roll structure there are 64 pairs (i, i + 16), so that the maximum value of ω is 64. supporting information s1 fig time correlation function of peptide backbone cα-cα bond unit vectors out of plane.
relaxation time of peptide backbone vectors can be estimated from time autocorrelation profile for (a) peptides without fixed atoms and boost n = 2 (b) peptides with partially fixed bottom template and boost n = 2 and (c) peptides with partially fixed bottom template and boost n = 2.5.
(tif) click here for additional data file.
s2 fig unweighted pmf plotted against the distance between the lateral hydrogen bonded atom pairs shown in fig 4 (blue dashed line from amd).
this is for the second set of amd simulations using boost potential n = 2 and partially-fixed bottom template.
(tif) click here for additional data file.
s3 fig unweighted pmf plotted against the distance between the vertical hydrogen bonded atom pairs.
this is for the second set of amd simulations using boost potential n = 2 and partially-fixed bottom template.
(tif) click here for additional data file.
s1 table hydrogen bonding lifetime for lateral and vertical hydrogen-bonded atom pairs.
(xlsx) click here for additional data file.
@highlight
the β roll molecules with sequence (gagagagq)10 stack via hydrogen bonding to form fibrils which have been themselves been used to make viral capsids of dna strands, supramolecular nanotapes and ph-responsive gels.
accelerated molecular dynamics (amd) simulations are used to investigate the unfolding of a stack of two β roll molecules, (gagagagq)10, to shed light on the folding mechanism by which silk-inspired polypeptides form fibrils and to identify the dominant forces that keep the silk-inspired polypeptide in a β roll configuration.
our study shows that a molecule in a stack of two β roll molecules unfolds in a step-wise fashion mainly from the c terminal.
the bottom template is found to play an important role in stabilizing the β roll structure of the molecule on top by strengthening the hydrogen bonds in the layer that it contacts.
vertical hydrogen bonds within the β roll structure are considerably weaker than lateral hydrogen bonds, signifying the importance of lateral hydrogen bonds in stabilizing the β roll structure.
finally, an intermediate structure was found containing a β hairpin and an anti-parallel β sheet consisting of strands from the top and bottom molecules, revealing the self-healing ability of the β roll stack.
