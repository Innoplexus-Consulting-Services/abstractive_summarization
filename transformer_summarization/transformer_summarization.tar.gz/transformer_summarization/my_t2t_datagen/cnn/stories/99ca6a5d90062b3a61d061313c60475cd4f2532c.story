introduction sclerosing mesenteritis is a rare medical condition with just over 1200 cases reported to date in the available literature [1]; however, it is believed that it is more common due to the fact that in most cases, it is discovered incidentally, with a study attributing a prevalence of 0.6% [2].
the term was suggested by emory et al.
[3], reflecting the fibrosis present in the lesions.
sclerosing mesenteritis should not be considered a single entity, but rather a spectrum of idiopathic primary inflammatory and fibrotic processes that affect the mesentery.
primarily, three stages are distinguished (mesenteric lipodystrophy, mesenteric panniculitis, and retractile mesenteritis), all with characteristic histopathologic and imaging features.
among the possible clinical presentations, the most common is abdominal pain (31.9%) followed by weight loss (21.3%), nausea, and vomiting (11.7%) [4].
other symptoms include palpable abdominal mass, change of bowel habits or even signs of gastrointestinal obstruction [5].
it is more common in middle aged men (male to female ratio, 2:1; mean age of diagnosis, 66.6 years) [4].
sclerosing mesenteritis is a condition of unknown origin; nevertheless, its pathogenesis has been associated with tuberculosis, pancreatitis, malignancies, and granulomatous diseases [6], [7], a theory which is supported by the microscopic findings, which suggest it to be the result of injury to fat in the mesentery [8].
most importantly, sclerosing mesenteritis has been linked to malignancy [2], [6], [9], [10]; however, this is controversial [11].
because of the nonspecific signs and symptoms of the condition, diagnosis in the majority of cases is made through a combination of histopathologic and imaging findings.
most available studies present the features of the condition using ct. in the present article, a combination of ct and mri images is used to study a case of an unusually large mass in the abdomen of a patient, with an ultimate goal to provide a deeper understanding of the imaging features of the disease.
case report a 68-year-old male with bouts of biliary colic because of gallstones presents for a scheduled laparoscopic cholecystectomy.
he has a history of arterial hypertension and paroxysmal atrial fibrillation, treated with irbesartan, metoprolol, ramipril, and acenocoumarol.
on admission, he underwent a thorough clinical and laboratory evaluation, which was unremarkable.
during the operation, a sizeable part of the omentum with several enlarged nodes was found to be tightly adhered to the gallbladder, displacing the abdominal viscera to the right.
hence, owing to the increased difficulty in the exposure of the cystic duct and artery, the conversion to the open technique was decided.
the artery and the duct were safely ligated, and the gallbladder was removed with no notable incidences during the operation.
in addition, a 5 × 4 × 2 cm specimen from the omentum was sent for microscopic examination.
based on the macroscopic findings and before the acquisition of the biopsy results, a postoperative evaluation of the mass was decided.
the patient underwent contrast-enhanced abdominal ct and mri scan.
for the latter case, t1 and t2 weighted images were acquired using a 1.5-t scanner.
the recovery of the patient was uneventful with dismissal on postoperative day 9. the patient provided a written informed consent for the release of his case history and of the visual material published in the present article.
the microscopic examination revealed vascular congestion of the omentum.
the enhanced ct scan revealed the presence of an extensive area of a lipomatous density mass that contained linear opacities consistent with the presence of vessels of the mesentery trapped inside the mass (fig.
1).
in addition, ground glass opacity of the mesentery fat was observed (misty mesentery).
the mri that was subsequently performed identified an inhomogeneous, intraperitoneal mass extending from about the middle of the spleen until the left iliac fossa, measuring 34 × 23 × 18 cm (fig.
2), causing a rightward dislocation of the intestine.
no enlarged lymph nodes were identified.
the mass appears with increased signal intensity in t1w and t2w images and with signal suppression in t2w fat saturated images, suggesting the lipomatous composition of the mass.
with the exception of the t1w without contrast, in all the remaining axial images can be identified two round lesions of maximum diameter of 2 cm with well-defined borders inside the mass (arrowheads fig.
3).
these lesions appear with intermediate signal intensity in t1w and increased signal in t2w and are enhanced by the contrast especially in their periphery during late phase.
a third lesion which is visible (fig.
3 arrow) does not present these features.
based on these findings, the diagnosis of sclerosing mesenteritis was made.
no specific treatment was administered.
the patient was reevaluated clinically in postoperative months 3, 6, 9, and with an abdominal mri scan in postoperative month 6, without any significant differentiations.
discussion in the present article, we report the radiologic findings from the systematic investigation of a patient with sclerosing mesenteritis presenting as a large abdominal mass.
depending on the histologic findings, three main subtypes are distinguished.
the first stage (mesenteric lipodystrophy) is characterized predominantly by fat necrosis and infiltration of the mass by lipid-filled macrophages, followed by intense inflammatory reaction with lymphocytic infiltrates and lipid cystic necrosis (mesenteric panniculitis).
finally, in what is regarded as the end stage of the disease (retractile mesenteritis), shortening of the mesentery, diffuse fibrosis with potential calcifications, and giant multinucleated cells are encountered [12], [13].
it is believed that in most cases, all three stages are present simultaneously but to different extents [14].
although the diagnosis is established through histologic examination, there are some radiologic features that can provide adequate evidence for safe recognition of this condition.
these include density of fat tissue in ct, dislocation of bowel loops, preservation of fat around the mesenteric vessels and soft tissue nodules (“fat-ring sign”), soft-tissue surrounding the inflamed mass (“tumoral pseudocapsule”), and scattered lymph nodes throughout the mass [15].
finally, the mass is most frequently located at the left side, corresponding to the jejunal mesentery [2].
moreover, each stage has a different presentation on mri.
mesenteric panniculitis is characterized by hyperintense signal on t2w fat sat, suggesting the presence of edema [16].
in retractile mesenteritis on the other hand, the mass demonstrates intermediate signal density with multiple strands representing the fibrotic retraction of the mesentery on t1w scans and hypointense signal on t2w with delayed hyperenhancement when fibrosis is prevalent [14].
scattered low signal areas correspond to calcification [17].
in our case, abdominal mri demonstrates the presence of a heterogeneous mass with hypo and hyperintense areas and multiple strands, consistent with the presence of vessels of the mesentery trapped inside the mass.
in the t2w images (with and without fat sat), three nodules are apparent, two hypointense and one hyperintense with a central hypointense area that are not visible in the t1w.
interestingly, the two hypointense nodules demonstrate peripheral late phase enhancement, which is suggestive of fibrosis.
in addition, the most dorsal of these nodules presents as a hyperintense nodule with a hypointense halo in t2 fat-suppressed images.
hence, at a given time, more than one subtype of the condition can be present.
when asymptomatic, patients require no treatment either pharmacologic or surgical, as most cases regress spontaneously.
in the rest of cases, corticosteroids alone or in combination with immunosuppressants (e.g., tamoxifen, cyclophosphamide) have demonstrated good efficiency in symptomatic patients [18].
in conclusion, provided that contrast-enhanced ct and t1w mri scans provide inadequate information about the stage of the condition, it is suggested that each case is evaluated with a combination of sequences, primarily t2w and contrast-enhanced t1w mri, which demonstrate a higher sensitivity in the detection of lesions.
@highlight
sclerosing mesenteritis is primarily diagnosed through histologic and radiologic evaluation; however, only a few works provide a systematic description using mri.
this work presents the case of a 68-year-old male, who was admitted for a routine cholecystectomy.
intraoperativly, a large mass was identified dislocating the abdominal viscera.
the microscopic examination revealed vascular congestion of the omentum.
the contrast-enhanced ct and mri scans revealed the presence of a heterogenous, lipomatous mass with lesions visible only in t2w and contrast-enhanced t1w mri.
based on these findings, the diagnosis of sclerosing mesenteritis was made.
according to the available literature, depending on the stage of sclerosing mesenteritis, different radiologic features are encountered; however, it is possible that features from more than one form of the condition coexist in the same lesion.
we therefore suggest that a combination of mri sequences should be acquired for a more accurate staging of the condition.
