introduction combining anaerobic training, specifically resistance training, with aerobic training has been a topic of interest for several years.
research has shown that endurance runners utilizing resistance training tend to have a greater running economy (re), thus allowing less energy to be expended during an endurance event (11, 14, 22, 30, 35).
currently, in the available literature there is a lack of data determining the most effective form of resistance training to utilize with endurance runners.
however, research points toward training the rate of force development (rfd) through explosive-strength training at moderate intensities (11, 22, 25, 30, 35).
explosive-strength training should be effective at decreasing ground contact time during running by improving the stretch-shortening cycle (ssc) which could lead to an improvement in aerobic running performance (15).
explosive-strength training includes olympic weightlifting and various other ballistic and plyometric exercises which include high velocity components.
as stated, plyometric training can be included as an explosive-strength style of training and has been shown to aid in improving aerobic performance (22, 30).
as noted above, there is ample evidence suggesting the importance of resistance training for endurance runners; however, the optimal resistance training method for the enhancement of aerobic performance remains unclear.
therefore, more research is necessary in order to determine the mode of resistance training that is most important for aerobic athletes.
if significant associations can be established between aerobic and anaerobic performance variables, it may serve to guide the conversation on subsequent research on optimal resistance training modalities.
previous research has clearly shown that resistance training can benefit aerobic performance, more specifically through improvements in rfd (11, 22, 25, 30, 35).
therefore, the purpose of this study was to investigate associations between aerobic and anaerobic performance in recreational runners in order to aid in the determination of how to effectively utilize concurrent training.
methods participants recreationally trained runners (n = 11) were recruited for the study.
this included six males and five females.
recreational endurance runners were defined as an individual with a vo2max that fell within the 80th percentile for his or her respective sex and age range according to the acsm guidelines (34).
participants were required to fill out a physical activity readiness questionnaire plus (par-q+) form in order to determine if they were physically able to participate in the study in addition to signing an informed consent approved by the midwestern state university institutional review board (irb).
protocol testing took place over the course of two weeks involving four testing sessions with 72 hours of rest between each testing session.
in order to assess correlation among variables, if any exists, tests were conducted measuring both aerobic and anaerobic performances.
the first testing session involved signing an informed consent, physical activity readiness questionnaire (par-q+), and resting measures.
the next testing session measured aerobic performance, and the final two testing sessions measured anaerobic performance.
the aerobic variables examined included vo2max, ventilatory threshold (vt), and running efficiency (reff).
anaerobic variables included peak power (pp), rate of force development (rfd), peak force (pf), impulse, and power endurance (pe).
participants were also asked about their previous length of endurance and resistance training experience.
the second testing session involved determination of aerobic performance using the bruce treadmill test (quinton medtrack st65, bothell, wa) which has been shown effective at measuring aerobic capacity (4, 8).
a traditional bruce treadmill test was used which began with the speed at 1.7 mph with a 10% grade (34).
every three minute stage the speed was increased at different levels while the grade was increased 2%.
before testing, participants were given five minutes to warmup on the treadmill.
participants were instructed to continue running until voluntary exhaustion at which point the test was terminated.
maximal oxygen consumption, i.e., vo2max (ml·kg−1·min−1) was analyzed with a parvo medics 2300 metabolic cart (sandy, ut).
the metabolic cart was also used in order to determine ventilatory threshold (vt).
ventilatory threshold was determined at the point at which expired carbon dioxide (vco2) increased significantly without a significant increase in oxygen uptake (vo2) utilizing the v-slope method that has proven reliable in the literature reviewed (1, 7).
this test also measured running efficiency (reff), which was measured as the ratio of mechanical power to metabolic power using equation 1 below (12, 18, 21, 28, 33).
equation 1 reff = ( mechanical power / metabolic power ) * 100 to measure reff, the average vo2 during the three minute interval prior to vt was used.
the first test in the third testing session was the counter-movement jump (cmj) which measured peak power (pp) (watts) and relative pp (w·kg) utilizing a 400×800 mm force platform recorded at 1000 hz (advanced mechanical technologies, inc., newton, ma, usa).
prior to testing, participants performed a standardized warmup.
for the test, participants were instructed to place their hands on their hips in order to isolate the legs.
participants were placed in the middle of the force platform and were instructed to jump as high as they could.
participants were given three trials with one minute of rest between trials in order to obtain an accurate pp reading.
the highest value for pp was recorded.
in order to calculate pp from the force plate the sayer’s equation listed as equation 2 below was used (5).
equation 2 pp = ( 60.7 ) * ( jump height , cm ) + 45.3 * body mass - 2 , 055 in order to calculate jump height from the force plate equation 3, listed below, was used: equation 3 jump height = v to 2 / 2 g , where vto was the vertical takeoff velocity (20).
vertical takeoff velocity was calculated via equation 4 as follows: equation 4 v to = gt flight / 2 , where tflight was the time from the instant of takeoff to the instant of landing (20).
the second test on the third testing day was the isometric mid-thigh pull (imtp).
this test was used in order to measure rfd (n·s) and peak force (pf) (newtons).
the imtp test has been shown as an extremely effective method to determine both rfd and pf (2, 17, 31).
rate of force development was measured in the first 250 ms, as this timeframe has been shown to be significantly correlated with anaerobic performance (2).
participants were placed in the mid-thigh clean pull position at which point the hip and knee were placed at a 130° angle and wrist wraps were used to assist participants with maintaining their grip during testing.
the participants were instructed to pull as hard and as fast as they could on an immovable bar for five seconds while receiving verbal encouragement.
participants were given three attempts with a five minute rest period between attempts.
the trial with the highest pf was used for analysis.
the first test in the last testing session was the drop jump (dj) which has been reported as effective for measuring impulse (n-s) (26).
participants once again performed the standardized warmup prior to testing.
participants performed three drop jump trials from a height of 40 cm with a one minute rest between each trial.
participants were instructed to drop from the box and land with both feet simultaneously on the force platform and jump as quickly as possible to minimize ground contact time.
equation 5 below was used to calculate impulse (19): equation 5 impulse = m * g * jump height where; m was body mass in kilograms and g was the acceleration of gravity.
this calculation measured the impulse of the participant at takeoff.
in order to calculate jump height the previous formulas used for calculating jump height in the cmj were used.
the trial with the best flight time was used to calculate impulse.
the final test measured power endurance (pe).
this test was the bosco jump test (bjt) which has been shown to be one of the most effective methods of determining anaerobic muscular endurance (3, 29).
participants were familiarized with a 90° knee flexion position prior to the test.
once participants were familiarized with the starting position they were placed on the force platform to begin the test.
participants were instructed to perform squat jumps from the 90° knee flexion position for 30 seconds.
anytime a participant did not return to the starting position before jumping, they were instructed to increase knee flexion prior to the next jump.
power output (watts) for each participant was assessed for each jump throughout the duration of the test in order to determine pe.
the equations used to measure pp were also used to measure pe for each jump in the 30 second time span.
statistical analysis descriptive means and standard deviation (sd) were established for group demographics.
a pearson product r correlation coefficient was used in order to determine the relationships between aerobic and anaerobic variables.
the criterion alpha level was set a priori at p ≤ .05. cohen’s effect size was also used in order to determine the strength of associations, the equation to find cohen’s d is equation 6, listed below (13).
equation 6 d = 2 r / √ ( 1 - r 2 ) results eleven participants (n = 11, age = 34.1 ± 13 years, height = 175 ± 9.7 cm, weight = 76.1 ± 15.5 kg) volunteered for this study.
participants were asked for endurance training experience (4.7 ± 3.7 years) and resistance training experience (4.1 ± 4.6 years).
aerobic performance and anaerobic performance variables for each participant were obtained and can be seen in tables 1 and 2. the results of the study showed significant correlations between vo2max and rfd (r = 0.68).
however, after further analysis using cohen’s effect size strong associations were found between vo2max and pf (r = 0.52), reff and pp (r = 0.53), reff and relative pp (r = 0.51), and reff and pe (r = 0.53).
the results of this study are shown in table 3. a post hoc analysis was also performed in order to examine any correlation differences between sexes.
the results are shown in tables 4 and 5. discussion the purpose of this study was to investigate the relationship between aerobic and anaerobic performance in recreational runners in order to further determine the most effective method of resistance training for endurance runners.
the primary finding in this study was a significant correlation between vo2max and rfd.
further analyses utilizing cohen’s effect size indicated a strong association between vo2max and pf, reff and pp, relative pp, and pe.
this leads to the notion that utilizing anaerobic training which improves upon rfd, pf, pp, and pe should improve aerobic performance.
however, one must note that those variables which had a strong association via cohen’s effect size had alpha values ranging from p = .08 to p = .11. while these values do not show statistical significance, a greater sample size could have led to a significant correlation.
thus, those variables showing strong associations via cohen’s effect size should still be investigated in future research with larger sample sizes in order to fully understand their implications on aerobic performance.
a post hoc analysis was also performed in order to determine any sex differences in the relationship between aerobic and anaerobic performance.
the results of this analysis did show differences when examining certain variables of aerobic and anaerobic performance.
for the male participants the main findings were a significant correlation between reff and pp, relative pp, impulse, and pe.
also, for the male participants there was a significant negative correlation between vo2max and impulse, and a strong negative association via cohen’s effect size between vo2max and pp and pe.
the negative associations with vo2max and the aforementioned anaerobic variables could be due to the fact that anaerobic performance and vo2max tend to have a negative association with one another, specifically in endurance trained athletes (10, 15, 24, 32).
the main findings for the female participants showed no significant correlations via the pearson product correlation coefficient.
however, there were strong associations via cohen’s effect size between reff and pp, relative pp, pf, rfd, impulse, and pe for the females.
one must note that when taken separately the sample sizes were six for the males and five for the females.
such small sample sizes indicate that a larger sample size could lead to more significant correlations between aerobic and anaerobic performance for both males and females.
the reason for these differences could be due to a number of variables.
for example males tend to have higher power outputs and body mass than females which could lead to variations in the relationship between variables (6, 9).
however, other research has shown that men and women with similar lower body mass will have very similar power outputs (27).
examining the physiological adaptations to training between male and female participants was outside the scope of this study.
however, these results, combined with previous research, suggest that both males and females could benefit from improving power output.
improving an individual’s rfd can be achieved by utilizing explosive-strength, high velocity exercises as has been mentioned.
previous research indicates that participants who utilized simultaneous explosive-strength training, which emphasized rfd, and endurance training should improve aerobic performance without altering their vo2max (23–25).
these studies indicate that both maximal and submaximal strength training should aid in the improvement of aerobic performance through an increase in neuromuscular performance, thus leading to improved rfd and aerobic performance.
one of the most effective explosive-strength training methods for improving rfd is olympic lifting which involves the clean & jerk and snatch exercises (16, 24).
one longitudinal study examined the effect of high intensity weight training, with an emphasis on the olympic lifts, on aerobic capacity over the course of three years (24).
in order to measure strength these authors used maximal lifts on both the clean & jerk and snatch exercises.
the authors concluded that combining olympic weight training and endurance running can improve strength without decreasing vo2max over the course of three years.
the athletes in the previous study utilized both of the olympic lifts in their training program, as well as various power lifts, pulling exercises, pressing exercises, and squatting exercises.
when designing a resistance training protocol for endurance runners olympic lifts should not be the only exercises used, any lifts considered accessory to the olympic lifts, such as squats, deadlifts, presses, etc.
should be included in order to maximize performance improvements in the rfd.
loads between 80 and 90% of 1rm have been suggested as proper intensities to utilize in order to improve the olympic lifts in endurance runners (24).
seeing as how the power variables (pp, relative pp, impulse, and pe) were seen to show significant correlations to reff for male participants one should use exercises which will improve an endurance athletes’ power performance.
the previously mentioned olympic lifts should improve overall power output due to the fact that improvements in power can be achieved using high velocity movements with moderate to high intensities (16).
other high velocity exercises such as plyometric and ballistic style exercises can act to improve pp, relative pp, impulse, and pe and thus aid in improving aerobic performance (16, 22, 30).
these exercises are low to moderate intensity, high velocity movements which will improve the velocity component of power.
typically, only an individual’s body weight is utilized for plyometric training and an emphasis is placed on maximal velocity and reduced ground contact time through various jumping movements.
ballistic training can include body weight training, however, other ballistic exercises involve utilizing low intensities of an individual’s 1rm for certain exercises in order to improve power output (16).
exercises considered ballistic training include various body weight jumping movements as well as throwing movements, tire flips, and resisted jumps.
a combination of high velocity movements utilizing body weight and low intensity loads with explosive-strength movements using moderate to high intensity loads would be the optimal resistance training method for aerobic athletes.
in order for aerobic performance to be at its peak for competition a strength & conditioning professional should combine the previously mentioned exercises in a properly periodized program which allows for both improvements in aerobic and anaerobic performance.
the results of this study did not show that any training will maximize aerobic performance since only correlations were assessed.
however, after examining the correlations found in the present study, one could suggest including anaerobic training with endurance runners.
endurance runners should utilize a training program which improves upon rfd and power output.
olympic lifts, plyometric exercises, and ballistic exercises are anaerobic styles of training which can aid in the improvement of rfd and power output which should lead to improved aerobic performance when combined with aerobic training.
as was seen, there are sex differences present among the participants used in this study.
male participants showed a significant correlation between the power variables (pp, relative pp, impulse, and pe) and reff whereas females had strong correlations via cohen’s effect size with the same variables and rfd.
therefore, future research combining olympic lifts, plyometrics, and ballistic exercises with aerobic training is warranted in order to determine the various physiological adaptations of concurrent training.
also, an examination into the different physiological adaptations between male and female participants using combined aerobic and anaerobic training is warranted.
one must note that the low sample size could have impacted the significance of the results, thus warranting further research with a greater sample size.
@highlight
research has indicated that combined aerobic and anaerobic training (concurrent training) may improve aerobic performance greater than aerobic training alone.
the purpose of this investigation was to establish any associations between aerobic and anaerobic performance.
eleven participants (n = 11, age = 34.1 ± 13 years, vo2max = 58.4 ± 7.8) volunteered for this study.
participants were asked for endurance training experience (4.7 ± 3.7 years) and resistance training experience (4.1 ± 4.6 years).
to meet training status, participants were to have a vo2max in the 80th percentile as per acsm guidelines.
the bruce treadmill test was used to measure aerobic performance.
in order to measure anaerobic performance, several tests were completed utilizing a force platform.
a pearson product r correlation coefficient was calculated to determine correlations between variables.
the results show significant correlation between vo2max and rfd (r = 0.68).
further analyses utilizing cohen’s effect size indicated a strong association between vo2max and peak force, as well as running efficiency and peak power, relative peak power, and power endurance.
these results indicate an existing possibility that anaerobic performance measures such as rfd may have a positive relationship with aerobic performance measures such as vo2max.
therefore, it may be beneficial to integrate specific training components which focus on improving rfd as a method of improving running performance.
