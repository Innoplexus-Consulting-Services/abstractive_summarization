1 introduction alcohol dependence is a chronic relapsing disease that poses a substantial global health problem (rehm et al., 2009).
alcohol and stress-related cues have consistently been shown to increase craving, and relapse rates in recovering alcohol dependent (aud) patients (seo et al., 2013, sinha, 2009).
a better understanding of the neural correlates of alcohol and stress cues that contribute to relapse may lead to better treatment strategies for aud patients.
functional magnetic resonance imaging (fmri) studies have largely converged on the dysregulation of cortico-limbic pathways in response to alcohol and stress cues for alcohol dependence (jasinska et al., 2014).
some authors have hypothesized that these alterations in cortico-limbic regions may trigger attention allocation to and reinforcement of drug-related cues in addicted populations, known as the incentive salience theory (berridge and robinson, 1998).
cortico-limbic regions that are commonly implicated in reward circuitry (haber and knutson, 2010) include the prefrontal cortex (pfc) (filbey et al., 2008, fryer et al., 2013, grüsser et al., 2004, seo et al., 2013), the anterior cingulate cortex (acc) (beck et al., 2012, claus et al., 2011, fryer et al., 2013, seo et al., 2013), the amygdala (fryer et al., 2013, schneider et al., 2001), and the striatum (claus et al., 2011, filbey et al., 2008, fryer et al., 2013).
however, activation-based fmri studies are limited as they only measure the magnitude of activation in a single region, and, thus, provide an incomplete picture of neural dynamics between regions.
functional connectivity methods overcome these limitations by detecting synchrony of activations over time, exposing patterns of correlated brain activity (smith, 2012), and shed light on the functional architecture of both the healthy and diseased brain (constable et al., 2013, sutherland et al., 2012).
recent studies of resting state and task-based connectivity in aud patients point toward the involvement of large-scale brain networks in addiction (camchong et al., 2013a, camchong et al., 2013b, chanraud et al., 2011, müller-oehring et al., 2015).
these networks overlap with previously identified brain regions as well as offer potentially new brain regions of interest in addiction research.
for example, the salience network (sn) is composed of two historically studied regions in addiction literature, the insular cortex and the acc (müller-oehring et al., 2015, seeley et al., 2007).
in contrast, the default mode network (dmn) characteristically includes the medial pfc (mpfc), a previously identified brain region (seo et al., 2013), as well as the posterior cingulate (pcc), a newly emphasized brain region (chanraud et al., 2011) in alcoholism literature.
increasingly, the interplay between these networks is being recognized as an important factor in clinical disorders (lerman et al., 2014, uddin, 2014), suggesting a need to utilize whole brain data-driven approaches in studies of addiction.
however, these studies have examined connections between specific regions of interest (roi) or canonical, large-scale networks requiring a priori knowledge of roi or network boundaries.
an innovative alternative, voxel-wise method, called the intrinsic connectivity distribution (icd) (scheinost et al., 2012), eschews pre-defined regions or networks and examines every voxel's connectivity to every other voxel in the brain.
as voxels are not constrained to a particular roi or network, icd enables characterization of the full range of connectivity for that voxel and may lead to a more complete picture of the neural correlates of alcohol and stress cues for recovering aud patients.
previous studies have also required the definition of an arbitrary tissue connectivity threshold whereas icd characterizes connections across the entire degree curve.
functional connectivity and icd overcome these limitations by investigating spatial and temporal patterns between all voxels in the brain, rather than only focusing on changes in activation.
thus, this measure provides a strong index of the connectivity of any particular brain structure allowing connectivity maps of patients to be compared with healthy controls or to behavioral outcomes such as subsequent time to relapse.
using a well-validated, individualized imagery paradigm (miller et al., 1987, sinha, 2009), we investigated differences in icd associated with alcohol, stress and neutral/relaxing cue scripts in 45 recovering aud patients and associated these differences with relapse.
imagery scripts were developed from recent experiences described by participants with alcohol-related, stressful, or neutral/relaxing content.
in a second study, for group comparison purposes, a subgroup of 30 aud patients was matched for age, sex, and intelligence to 30 healthy control (hc) participants that underwent an identical imagery paradigm.
we hypothesized that our innovative, data-driven analysis would reveal altered patterns of connectivity consistent with classic addiction regions described above, and identify new, less well-characterized networks.
specifically, we hypothesized that the aud group would show altered corticolimbic connectivity during alcohol and stress relative to neutral cue conditions and, icd connectivity in these regions would be associated with relapse.
in the second study, we expected to observe differential connectivity in corticolimbic regions during all script conditions in aud patients relative to healthy controls.
2 materials and methods all study procedures were approved by the human investigation committee of the yale university school of medicine.
all participants signed a written informed consent form.
2.1 participants study 1: forty-five recovering aud patients (10 female, aged 18–50, m = 37.7) and 30 healthy control individuals (9 female, aged 18–50, m = 34.5) participated in this study.
task-based fmri results on this sample and full details on the participants, imagery method and validation, and relapse measures were previously published in (seo et al., 2013).
all aud patients had a current diagnosis of alcohol dependence as determined by a structured clinical interview for dsm-iv, and abstained from alcohol for 4 to 6 weeks (mean = 34 days, se = 1.14) while actively engaged in inpatient non-pharmacological substance abuse treatment.
demographic details are presented in table s1.
tobacco-using aud patients were allowed to smoke prior to initiating the fmri scan and thus, were not nicotine deprived at the time of scan.
patients were scanned in week 5 of treatment and were discharged shortly after and referred to outpatient treatment for aftercare.
all patients were followed-up with in-person interviews conducted at 14, 30, and 90 days post-discharge to evaluate relapse outcomes using urine and breathalyzer samples and the form 90 substance use calendar based on the timeline follow-back method (sobell et al., 1996).
study 2: for group comparisons, 30 hc participants were demographically-matched to 30 (8 female, aged 18–50, m = 36.0) of the 45 aud patients on age, sex, iq, and lifetime prevalence of psychiatric disorders except for alcohol dependence and smoking status.
smoking status was included as a covariate in the group analyses.
we chose to demographically match as many aud patients as possible to the hc participants instead of comparing all 45 aud patients to hc as iq and years of education were significantly lower in the full aud group.
matching allowed us to minimize this potential confound, as the aud subgroup was not significantly different from hc participants in several demographics including age, sex and iq, but was significantly different in number of smokers in the aud versus the hc group (see table s1).
2.2 imagery paradigm all participants engaged in an imagery paradigm composed of individualized 2-min imagery scripts designed to provoke either alcohol, stressful, or neutral/relaxing states.
alcohol and stress scripts relative to neutral have previously been shown to increase craving, anxiety, heart rate and cortisol levels (sinha, 2009).
each 2-min script was based on a personal experience described by the participant and audiotaped for presentation during scanning session (see supplemental material for further information).
six fmri trials (2 per condition) were acquired using a block design.
the order of the 3 script conditions were randomized and counterbalanced across participants.
each script was presented only once for each participant, and scripts of the same condition were not presented consecutively.
each trial lasted 5 min, including a 1.5-min quiet baseline period followed by a continuous 2.5-min imagery period (2-min read imagery, 0.5-min quiet imagery) and a 1-min quiet recovery.
during baseline, participants were instructed to stay still in the scanner without engaging in any mental activity.
to minimize residual craving/anxiety between trials, all subjects were asked to practice 2-min progressive relaxation.
after relaxation, all participants returned to baseline levels of subjective craving and anxiety ratings, before starting the next cue trial, verified by no statistical difference in baseline ratings across trials.
2.3 connectivity preprocessing images were slice-time and motion corrected using spm5 (http://www.fil.ion.ucl.ac.uk).
images were iteratively smoothed until the smoothness for any image had a full width half maximum of approximately 6 mm.
this iterative smoothing has been shown to minimize motion confounds associated with resting-state fmri (scheinost et al., 2014a).
all further analysis was performed using bioimage suite (joshi et al., 2011) unless otherwise specified.
runs were further preprocessed individually for connectivity analysis.
several covariates of no interest were regressed from the data including linear and quadratic drift, six rigid-body motion parameters, mean cerebral-spinal fluid (csf) signal, mean white matter signal, and mean global signal.
finally, the data were temporally smoothed with a zero mean unit variance gaussian filter (cutoff frequency = 0.12 hz).
a gray matter mask was applied to the data so that only voxels in the gray matter were used in the calculation.
finally, for each voxel, time courses were normalized by removing that time course's mean and dividing by that time course's standard deviation.
as previously described (garrison et al., 2016), connectivity analysis was only performed on the continuous 2.5-min imagery period.
the 2-min active imagery period and 0.5-min passive imagery period were extracted from the full dataset and imagery periods of the same cue trial were concatenated for further analysis, resulting in approximately 5 min of data for each cue condition.
the large amount of continuous task data allows us to use novel data-driven connectivity methods usually reserved for resting-state fmri.
standard block design tasks with ~ 30 s blocks or event-related design tasks would not provide a sufficient amount of continuous data for such methods.
as each run was individually processed and normalized, concatenating runs as the same cue trials and performing correlation analysis is the equivalent of performing correlation analysis for each individually and averaging the resulting correlation.
2.4 icd connectivity to investigate cue related differences in connectivity between aud patients, connectivity of each voxel as measured by the intrinsic connectivity distribution (icd) was calculated for each individual participant as described previously (scheinost et al., 2012).
icd represents a generalization of the network theory measure of degree.
in the context of neuroimaging, degree involves correlating the time course for any voxel with every other voxel time course in the brain and is defined as the number of connections to that voxel with correlations greater than an arbitrary threshold (scheinost et al., 2012).
icd calculates degree over all possible arbitrary thresholds and then models the change in degree as the threshold is increased.
by examining all possible arbitrary thresholds, icd is not dependent on a single threshold and eliminates the need to specify an arbitrary threshold.
specifically, for the current voxel, a histogram of all the time series correlations to that voxel was constructed to estimate the distribution of functional connectivity to that voxel.
this distribution of connectivity was converted to a survival function and the survival function was fitted with a stretched exponential with unknown variance, α. as alpha controls the spread of the distribution of connections, a larger alpha indicates a greater number of high correlation connections.
finally, this process is repeated for all voxels in the gray matter resulting in a parametric image of the alpha parameter for each participant.
additionally, each icd map was normalized by subtracting the mean across all voxels and dividing by the standard deviation across all voxels.
this z-score-like normalization does not change the underlying topography of connectivity pattern but allows for each map to be comparably scaled across participants (mitchell et al., 2013).
2.5 statistical analysis icd connectivity maps were warped into common space (see supplemental material) and analyzed using voxel-wise random effects general linear modeling with group modeled as a between subject factor, cue conditions modeled as within subject factors, and subjects as random factors using 3dlme (chen et al., 2013).
imaging results are shown at a cluster-level threshold of p < 0.05 family-wise error (fwe) correction as determined by afni's 3dclustsim program (version 16.0.09) using a cluster forming threshold of p = 0.001, 10,000 iterations, a grey matter mask, and a smoothness estimated using 3dfwhmx with the –acf option.
follow-up seed analyses were based on the icd connectivity defined regions of interest.
anatomical locations were localized using the yale brodmann atlas.
analysis of between group motion and methods used to minimize motion related confounds can be found in supplemental material.
analysis of non-imaging data was performed in r. 2.6 prospective time to relapse analysis relapse was assessed prospectively in the 90 days after completion of inpatient treatment.
the first day of return to alcohol use during this 90-day follow-up period is considered as the target event and cox proportional hazards regression (walters, 1999), similar to a time-to-event survival analyses was conducted, as used in our previous studies (seo et al., 2013, sinha et al., 2011).
cox proportional hazard regression (walters, 1999) was performed to investigate whether connectivity regions showing cue differences in aud patients predicted the time to first alcohol relapse.
average icd values of clusters identified in the whole-brain connectivity analysis were extracted and entered as independent variables.
preliminary analyses indicated that years of nicotine smoking and years of alcohol use were significantly correlated (p < 0.05) with time to relapse such that a greater number of years of smoking or alcohol use were associated with quicker relapse.
thus, these were included as independent variables to evaluate their specific and independent effects.
3 results 3.1 study 1: relapse risk and connectivity in alcohol dependent patients 3.1.1 relapse rates of the 45 aud patients, 44 were successfully followed-up to determine relapse day.
relapse rates were 29.5% (13 of 44) at day 14, 45.5% (20 of 44) on day 30 and 70.5% (31 of 44) on day 90. all 45 aud patients were included in our analyses.
3.1.2 icd connectivity of aud patients with-in group differences in icd connectivity were examined in all 45 aud patients in study 1 under the 3 different cue conditions.
connectivity results indicated that aud patients displayed significantly (p < 0.05 corrected) reduced cingulate cortex connectivity to whole brain for alcohol and stress cue trials compared to neutral cue trials (fig.
1, table s2).
these regions included the anterior, mid, and posterior cingulate cortex.
three rois (acc, mcc, and pcc) were defined on the reference brain based our icd main effects of condition from fig.
1. follow-up seed-to-whole brain connectivity analyses revealing connections from these regions to the whole brain are presented in supplemental material and fig.
s1.
3.1.3 exploratory prospective time to relapse analysis we examined the relationship between average icd values of acc, mcc, and pcc clusters for each cue condition, and subsequent time to relapse using cox proportional hazard regression, after controlling for years of alcohol use and years of nicotine smoking.
for every unit increase of connectivity in the acc (p = 0.03, hazard ratio (hr) = 5.4) or mcc (p = 0.05, hr = 4.5) during the neutral cues, aud patients were approximately 5 times and 4 times more likely to relapse at the subsequent followup period, respectively (table s3, fig.
2).
for every unit increase of the difference in pcc connectivity between alcohol cueing and stress cueing (p = 0.04, hr = 0.04), aud patients were approximately 25 times less likely to relapse at the subsequent followup periods (table s3, fig.
2).
these exploratory results are left un-corrected for multiple comparisons in order to present preliminary findings to aid possible future studies.
3.2 study 2: group differences between alcohol dependent patients and healthy control participants in the second study, we compared a sub-group of 30 aud patients with 30 matched hc participants (table s1) to examine whether patterns of the cingulate cortex connectivity in aud patients were different from those in hc participants.
smoking status was included as a covariate.
functional connectivity results revealed a significant (p < 0.05 corrected) cue by group interaction in the mid and posterior cingulate cortex (table s4).
as shown in fig.
3, this effect was primarily driven by a reduction in cingulate connectivity during the alcohol and stress cue trials for the aud patients compared to the hc participants and compared to the neutral cue.
comparisons between all 45 aud patients and 30 hc participants showed qualitatively similar results in the cingulate cortex (fig.
s2).
4 discussion in two studies, using a well-validated imagery paradigm and a novel voxel-wise connectivity method, we demonstrated differential connectivity responses to alcohol and stress cues in the cingulate cortex for aud patients and their associations with early alcohol relapse, using a prospective clinical outcomes design.
in the first study, 45 aud patients exhibited a significant decrease in cingulate connectivity in responses to alcohol and stress cues compared to neutral cues.
using relapse from a prospective 90-day follow-up period, and cox proportional hazard regression, exploratory analyses suggests weaker connectivity in the acc and mcc during neutral cue exposure were significantly associated with longer period of abstinence which translated to better recovery outcome.
similarly, greater pcc connectivity during alcohol cues compared to stress cue conditions was associated significantly with longer time to relapse.
in the second study, group comparisons between a subset of the aud patients and matched hc participants indicated that cingulate connectivity was significantly different between the groups.
compared to hc participants, aud patients showed reduced cingulate connectivity during the alcohol and stress cue trials and increased cingulate connectivity during the neutral cue trials.
these group difference results are consistent with the cox proportional hazard regression relapse findings in that aud patients who were more similar to healthy controls in showing greater cingulate connectivity during alcohol cue trials or weakened connectivity during the neutral cue trials had more days of abstinence and better recovery period.
our results suggest that cingulate connectivity plays a significant role in the neural response to alcohol and stress cues and may contribute to subsequent relapse.
the cingulate cortex coordinates a vast number of behaviors through anatomical connections to many cortical and subcortical regions of the brain (bush et al., 2000, leech and sharp, 2014).
these behaviors and connections are typically implicated in addiction and relapse.
the vacc is anatomically connected to the ofc, nucleus accumbens, amygdala, hippocampus, and hypothalamus and is involved in affective and emotional processing (bush et al., 2000, leeman et al., 2009).
the dacc is anatomically connected to the lateral prefrontal cortex, parietal cortex, and is involved in external attention, decision-making, and inhibition (bush et al., 2000).
the pcc is anatomically connected to limbic structures (i.e.
hippocampus and parahippocampus), lateral prefrontal cortex, and parietal cortex and is involved in internally directed attention (leech and sharp, 2014).
as alcohol and stress cues are known to engage these circuits and behaviors in aud patients (jasinska et al., 2014, sinha, 2009), it is notable that the cingulate cortex emerged as the key region from our analysis.
the cingulate cortex contributes to a diverse set of large-scale functional networks.
the pcc is a node in the dmn, the dacc is a node in the salience network, and middle portions of the cingulate are nodes in the central executive or frontoparietal network (fpn) (yeo et al., 2011).
these three networks have been linked to the competition between internally and externally directed attention (uddin, 2014).
the dmn attends to internal thoughts; whereas, the fpn attends to external stimuli.
the salience network acts as a switch between the two (uddin, 2014).
the scripted cue trials used in this study are internally generated images of external cue contexts designed to provoke internally focused emotions such as anxiety and craving.
our results may reflect alterations in the dynamics of internal and external attention associated with alcohol addiction just as emerging research on nicotine dependence has shown (cole et al., 2010, lerman et al., 2014, sutherland et al., 2012).
consistent with our results, maladaptations of functional response to alcohol and stress cues in the acc are commonly implicated in alcohol dependence and are correlated with relapse (claus et al., 2011, fryer et al., 2013, seo et al., 2013).
functional alterations in the acc are consistent across other addiction subtypes with analogous findings in stimulant (camchong et al., 2014), nicotine (jasinska et al., 2014) and cocaine dependent patients (garavan et al., 2000).
in addition to functional changes, genetic variants in the acc circuitry (hong et al., 2010) and morphological features of the acc (cheetham et al., 2014, mashhoon et al., 2014) can increase relapse risk.
therefore, the observed connectivity difference in the acc for aud patients may represent maladaptations of functional connections from the acc to external and internal attention circuitry described above.
while the acc is a well-studied region in addiction circuitry, emerging evidence suggests that the pcc also plays a role in addiction and relapse (jasinska et al., 2014, ma et al., 2011).
in task-based studies, pcc activity has been shown to differ in response to drug cues (chase et al., 2011, engelmann et al., 2012) and has been linked with relapse in cocaine addicts (kosten et al., 2005) and tobacco users (loughead et al., 2015).
connectivity studies of aud patients compared to controls have also shown altered pcc connectivity (chanraud et al., 2011, müller-oehring et al., 2015).
together, these results provide further evidence that alterations in the pcc are a core component in addiction and relapse.
the pcc plays a crucial role in adjusting behaviors in reward contingencies (pearson et al., 2011) such as the presentation of alcohol cues.
in our study, only the contrasts involving alcohol cues predicted subsequent relapse, whereby smaller differences in pcc connectivity between the alcohol condition and the stress conditions indicated greater risk of relapse (fig.
3).
the pcc connectivity was also reduced in the alcohol compared to neutral condition (fig.
1) in the aud subjects.
this result may indicate an impaired ability to make flexible pcc connections in response to different emotional stimuli and difficulties with adjusting alcohol-related behaviors (e.g., craving, urge to drink) in aud individuals, thereby increasing risk of relapse.
in particular, aud patients appear to have altered cingulate connectivity to the alcohol and stress cue.
our group contrast results from the second study show that aud patients respond to alcohol and stress cues in a different manner than hc participants, but connectivity patterns are similar to hc participants for neutral cue conditions.
alcohol cues elicit reward responses in the brain (gilman et al., 2008).
studies have reported alcohol-related neuroadaptive changes in the brain circuits of alcohol dependent individuals (breese et al., 2011), such that continued alcohol abuse increases incentive salience toward alcohol stimuli by altering the neural connectivity in reward and salience circuits (robinson and berridge, 2008).
together, our findings of reduced cingulate connectivity specific to alcohol cue in aud patients suggest that prolonged alcohol consumption in aud individuals may sensitize and alter cingulate connectivity in response to alcohol cues, probably resulting from their incentive salience to alcohol-associated stimuli.
further, our findings suggest that aud patients with cingulate connectivity most similar to hc participants appear to have the most favorable relapse outcomes, emphasizing the crucial role of intact cingulate connectivity in maintaining alcohol abstinence.
taken together, the current study using the icd analysis sheds new light on the understanding of alcoholism by providing neural connectivity evidence that may underlie brain activity patterns using conventional task-based fmri method.
we report that that altered cingulate connectivity significantly contribute to alcohol-related pathology that is also significant for clinical outcomes of early relapse risk.
our prior task-based study identified hyperactivity in the vmpfc and parietal cortex (including the precuneus) during neutral states as key predictors of early relapse (seo et al., 2013).
the vmpfc and parietal lobes are anatomically interconnected with the cingulate cortex with the former more connected with the acc and the latter with the pcc (beckmann et al., 2009).
excessive connectivity during neutral states in the cingulate cortex may result in increased information transfer and processing, which may lead to hyper-reactivity in these regions.
these results suggest that alcoholism may be characterized by abnormal activity in the medial pfc and precuneus (seo et al., 2013), with underlying altered cingulate connectivity that bridges between these regions.
our finding highlights the importance of using icd in understanding more comprehensive picture of alcohol pathology.
this study has several strengths including well-matched groups, successful prospective follow-up of aud patients 90 days post-discharge from treatment, a well-validated individualized imagery task, and a novel, voxel-wise data-driven connectivity method.
this study also has several limitations including a largely male population, the lack of pre-treatment connectivity data, and the lack of resting-state fmri data.
sex differences in connectivity (scheinost et al., 2015) and cue reactivity (seo et al., 2011) exist in healthy individuals, and, thus, may mask subtle changes in aud connectivity.
research suggests that nicotine use can alter network dynamics of the cingulate in possibly similar ways (cole et al., 2010, lerman et al., 2014, sutherland et al., 2012).
given the extensive comorbidity between alcohol and nicotine addiction found in general and clinical populations as well as in current study, it may be difficult to fully disentangle effects of alcohol dependency from effects of nicotine usage.
however, it should be noted that the current study included smoking status as a covariate, and within the aud group, cingulate connectivity predicted early relapse, suggesting a significant contribution of chronic alcohol abuse over and above nicotine effects with important clinical implication for alcohol addiction pathology.
comparisons of pre- and post-treatment data with paired connectivity methods (scheinost et al., 2014b) could improve connectivity's predictive power of relapse and the assessment of treatment efficacy.
unlike standard block or event-related imagery paradigms, our imagery paradigm included two 2.5-min blocks of continuous imagery data providing a sufficient amount of data for robust data-driven connectivity analyses.
while this approach could be a strength allowing for the exploration of the neurobiology of relapse due to alcohol and stress cues, task-based fmri studies can be limited in a clinical setting (constable et al., 2013).
future studies should additionally examine resting-state connectivity to more comprehensively understand the clinical profile of alcohol addiction.
5 conclusions functional connectivity of the cingulate cortex was identified as a key factor in the neurobiological response to alcohol and stress cues in aud patients and a marker of later relapse.
alterations in the connectivity of the cingulate and future relapse predictions were revealed naturally from this data-driven analysis without the need for a priori seed or network definitions.
our results point to a potentially promising future of voxel-wise connectivity as a marker of relapse and for improving our understanding of this important disorder.
disclosures the authors report that they have no financial conflicts of interest with respect to this manuscript.
@highlight
alcohol dependence is a chronic relapsing illness.
alcohol and stress cues have consistently been shown to increase craving and relapse risk in recovering alcohol dependent (aud) patients.
however, differences in functional connectivity in response to these cues have not been studied using data-driven approaches.
here, voxel-wise connectivity is used in a whole-brain investigation of functional connectivity differences associated with alcohol and stress cues and to examine whether these differences are related to subsequent relapse.
in study 1, 45, 4- to 8-week abstinent, recovering aud patients underwent functional magnetic resonance imaging during individualized imagery of alcohol, stress, and neutral cues.
relapse measures were collected prospectively for 90 days post-discharge from inpatient treatment.
aud patients showed blunted anterior (acc), mid (mcc) and posterior cingulate cortex (pcc), voxel-wise connectivity responses to stress compared to neutral cues and blunted pcc response to alcohol compared to neutral cues.
using cox proportional hazard regression, weaker connectivity in acc and mcc during neutral exposure was associated with longer time to relapse (better recovery outcome).
similarly, greater connectivity in pcc during alcohol-cue compared to stress cue was associated with longer time to relapse.
in study 2, a sub-group of 30 aud patients were demographically-matched to 30 healthy control (hc) participants for group comparisons.
aud compared to hc participants showed reduced cingulate connectivity during alcohol and stress cues.
using novel data-driven approaches, the cingulate cortex emerged as a key region in the disruption of functional connectivity during alcohol and stress-cue processing in aud patients and as a marker of subsequent alcohol relapse.
