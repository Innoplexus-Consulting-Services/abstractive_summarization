1. introduction declines in arctic sea-ice are arguably the most dramatic evidence of the effects of current climate warming on ocean systems.
how such declines reverberate through marine ecosystems is largely unknown [1].
in upper trophic level (utl) species the first discernible effects of changing sea-ice will likely be behavioural either by directly altering ranging patterns [2,3] or indirectly by influencing resource (food, mates, breeding sites) and risk (e.g.
predation) dispersion.
understanding links between changing sea-ice and shifts in behaviour of these utl species has immediate relevance to species management as well as broader import for understanding ecosystem resilience.
here we assess the relationship between changing sea-ice and beluga whale migration and summer residency patterns of a number of populations over two decades of dramatic sea-ice changes in the pacific arctic.
beluga whales predictably return to specific coastal locations each spring and summer [4].
genetic and telemetry studies have identified several discrete populations that follow traditional migratory routes between wintering areas and summering grounds where belugas feed, moult and raise their young (e.g.
[5,6]).
it is not clear how sea-ice influences these migrations and summer habitat use.
climate change has added urgency to determining how environmental factors might shape the behaviour and ecology of this species.
we used genetic data to investigate the population of origin of whales returning to four traditional coastal sites in the alaskan and canadian arctic between 1988 and 2007. we compiled detailed beluga sighting and harvest data for the same period to assess inter-annual variation in timing of return.
finally, we analysed sea-ice data in the bering, chukchi and beaufort seas to determine seasonal and regional patterns of sea-ice from 1979 to 2014. we addressed two specific questions: (i) how does the pattern of annual return to a particular coastal area correlate with inter-annual variation in sea-ice and (ii) do anomalies in beluga migration behaviour correlate with sea-ice anomalies?
2. material and methods tissue samples from 978 beluga whales were collected over a 30-year period from subsistence harvests and from live whales via biopsy.
total dna was extracted from each sample and screened for variation within 410 bp of the mitochondrial genome and for polymorphism within eight hypervariable microsatellite markers, according to previously published methods [5].
population structure and population of origin of individuals were assessed using: (i) homogeneity tests of genetic differentiation in arlequin (v3.5) [7] and (ii) clustering analysis and assignment tests using structure (v2.3.4) [8] and whichrun (v4.1) [9].
minimum estimates of the period of annual return by beluga whales to kasegaluk lagoon and the mackenzie delta (figure 1h) were based on sightings of whales by native hunters and field biologists, from aerial surveys and from the timing of subsistence harvests ([10,11]; electronic supplementary material).
figure 1.regional (n = 7) sea-ice concentration (%) in the bering, chukchi and beaufort seas from 1979 to 2014. positive ice anomaly years are highlighted as blue bars, negative anomaly years as pink bars.
trends are indicated by dashed lines.
variability in sea-ice conditions was examined using passive microwave-derived sea-ice concentration (sic) data [12] for the years 1979–2014.
sea-ice conditions on spatial scales of relevance to the migrations of different beluga populations were assessed by calculating monthly mean sics for seven regions within our study area (figure 1), excluding waters within 25 km of the coast where data may be biased by proximity to land.
to identify years with anomalous ice conditions, months in which beluga typically occupy each region (april–may for regions 1–3; may–june for regions 4, 5 and june–july for regions 6, 7) were examined and anomalous occasions when the monthly sic was 20‰ above or below the 36-year mean were identified.
3. results beluga whales occur in the eastern chukchi sea (sea-ice region 5, figure 1h) near shore waters each summer.
for the years 1988–2007, beluga presence based on sightings ranged from as early as 20 june (1997) to as late as 16 july (1991, 2006) (figure 2a).
mean june sic for this region varied considerably from 5.2% (1997) to 83.7% (2006) and was weakly correlated with the timing of whale sightings near shore (ρ = 0.36, figure 2a).
a consistent genetic profile was found for both mtdna (figure 2b) and ndna (figure 2e) for beluga whales occurring off kasegaluk lagoon in june and july, indicating that the same, distinct population returned at roughly the same time each year over the course of the study despite high inter-annual variation in sea-ice.
similar patterns were found for the mackenzie delta (figure 2e; electronic supplementary material, tables sm1 to sm4).
figure 2.the timing of occurrence and population of origin of beluga whales from a number of locations in the alaskan arctic.
(a) beluga presence (orange bars) and sea-ice trends (grey line) for sea-ice region 5. frequency of mtdna lineages (coloured bars) from whales sampled in (b) kasegaluk lagoon, (c) kotzebue sound and (d) norton sound for the period 1988–2007, compared with total population frequencies.
(e) population cluster membership (coloured bars) of 816 individual whales based on eight microsatellite loci.
individuals dominated (i.e.
q > 0.8) by the same colour profile are considered part of the same population.
black lines demarcate the different locations and grey lines demarcate the different sample years.
only years with more than five samples were included.
prior to 1983, beluga whales returned to kotzebue sound in the southeastern chukchi sea (map, figure 1h) each summer with a peak in mid-june.
the genetic signature across years denoted a distinct kotzebue population (figure 2c).
after 1983, the occurrence of whales in kotzebue sound decreased dramatically.
two exceptions to this occurred in 1996 and 2007 when several hundred whales entered the sound.
the genetic profile of these whales was distinct from the earlier period (figure 2c).
the 1996 event occurred within the same timeframe (10–28 june) as pre-1983 occurrences.
the 2007 event primarily occurred five weeks later (23–28 july).
in norton sound in the eastern bering sea a consistent mtdna profile was observed in most years (figure 2d) except for 1996 when whales from another population entered the northern part of the sound (norton bay) in may.
the microsatellite pattern was less distinct as norton sound does not form a distinct ndna cluster (figure 2e).
the genetic analysis determined that all three atypical events involved whales most likely from the eastern beaufort population which winters in the western bering, migrates through the chukchi and summers in the beaufort sea (figure 2b–e).
both sexes occurred in all three events although the kotzebue sound 2007 event comprised males primarily (more than 90%), differing significantly from a sex ratio of near parity for most other years sampled (p = 0.018).
the springtime sea-ice regime of the northern bering, eastern chukchi and southern beaufort seas is characterized by a northward ice retreat from regions 1 to 7, but there is considerable variability both inter-annually and between regions (figure 1).
in line with arctic-wide trends all regions show a significant negative trend in ice concentration in july (slope = −0.1 to −11.6, p < 0.05) and there are more negative anomaly years in the latter half of the record.
among the years identified as individually anomalous for each region certain years stand out as being anomalous throughout the study area.
for example, 1983 was a positive anomaly in all regions except region 2, while 2003 was a negative anomaly in all regions except region 7.
1996 was a negative anomaly during april and may in regions 1–4, corresponding to an early break-up in norton and kotzebue sounds; whereas 2007 was a negative anomaly from may to july in regions 5–7.
ice conditions in kasegaluk lagoon (region 5) show especially strong inter-annual variability, with 26 out of 36 years being either positive or negative anomalies.
a significant association was found between the atypical whale migration events recorded in norton and kotzebue sounds and negative ice anomalies in the northern bering sea (region 1—norton: r = 0.66, p = 0.05, χ2 p = 0.047; region 1—kotzebue: r = 0.65, p < 0.01, χ2 p = 0.016; region 2—norton: r = 0.66, p = 0.05, χ2 p = 0.047).
4. discussion the relationship between arctic whales and sea-ice is still largely a mystery.
this study revealed that beluga whales are resilient to widely varying ice conditions while perpetuating philopatry each year to discrete coastal locations and suggests that reaching these areas at this time of year is critical.
the detection of behavioural shifts at a number of locations in 1996 and 2007 indicates that belugas can also dramatically alter migration course and summer habitat use.
that these events coincided with anomalous spring and summer sea-ice conditions is suggestive of a link between the two phenomena.
that the wayward whales were up to 1800 km from their normal course indicates that the effect can be substantial.
it should be noted, there were other anomalously low ice years (figure 1) when we either had few or no samples (kasegaluk, norton, kotzebue) or sightings (kotzebue) to assess possible interactions between the cryosphere and whale ranging patterns.
sea-ice patterns in early spring (april–may) in the northern bering sea and in summer (june–july) in the chukchi and beaufort seas could be key.
early break-up should facilitate rather than impede migration of beaufort belugas to their traditional summering area in the mackenzie delta, and indeed no anomalies in the period of occurrence of whales in the delta were detected for 1996 or 2007 [11], which might suggest a population-wide phenomenon.
it thus, appears that some beaufort belugas either remained in the bering and chukchi seas or returned westward from their summering ground in years when ice conditions were atypically low.
that the kotzebue 2007 event comprised mainly males adds to a growing body of evidence of sex segregation in belugas [13] and indicates how changes in ecosystem forcing may affect males and females differently.
unusual sea-ice patterns may have had a more indirect effect where beluga whales altered their behaviour to pursue associated shifts in prey or to avoid changing predation risk.
recent warming is causing changes in fish communities in the arctic [14].
as yet, there is limited information on changes in prey availability for belugas in alaskan waters [15,16].
native hunters have reported recent increases in killer whale sightings in kotzebue sound including the presence of killer whales during the 2007 event when evasive behaviour by the beluga whales and predation by killer whales was observed.
this follows an arctic-wide increase in killer whale sightings which has been linked to decreasing sea-ice [17].
it is possible that other unknown proximate factors, including anthropogenic activities, could have contributed to the altered whale migration patterns.
here we proffer an ecosystem-level, basin-wide perspective of likely ultimate and proximate causes.
our findings reveal a complex relationship between a utl species and the arctic cryosphere, where responses to changing sea-ice are influenced by the changing physical challenges and by biological dictates.
beluga whales exhibit great resolve in reaching critical stationary resources such as coastal moulting and breeding sites.
however, changes in prey availability and predation pressure will require an adjustment in movement and habitat use patterns.
decreasing sea-ice will likely increase predation risk as temperate apex predators including killer whales have easier and longer access to the arctic.
behavioural and ecological responses of beluga whales to all these changes may alter the pattern of return to traditional coastal sites, with possible cascading effects throughout entire marine ecosystems and the subsistence communities that rely on them.
supplementary material o'corry-crowe et al - biology letters - supplementary mat supplementary material o'corry-crowe et al - biology letters - supplementary tables
@highlight
there is increasing concern over how arctic fauna will adapt to climate related changes in sea-ice.
we used long-term sighting and genetic data on beluga whales (delphinapterus leucas) in conjunction with multi-decadal patterns of sea-ice in the pacific arctic to investigate the influence of sea-ice on spring migration and summer residency patterns.
substantial variations in sea-ice conditions were detected across seasons, years and sub-regions, revealing ice–ocean dynamics more complex than arctic-wide trends suggest.
this variation contrasted with a highly consistent pattern of migration and residency by several populations, indicating that belugas can accommodate widely varying sea-ice conditions to perpetuate philopatry to coastal migration destinations.
however, a number of anomalous migration and residency events were detected and coincided with anomalous ice years, and in one case with an increase in killer whale (orcinus orca) sightings and reported predation on beluga whales.
the behavioural shifts were likely driven by changing sea-ice and associated changes in resource dispersion and predation risk.
continued reductions in sea-ice may result in increased predation at key aggregation areas and shifts in beluga whale behaviour with implications for population viability, ecosystem structure and the subsistence cultures that rely on them.
