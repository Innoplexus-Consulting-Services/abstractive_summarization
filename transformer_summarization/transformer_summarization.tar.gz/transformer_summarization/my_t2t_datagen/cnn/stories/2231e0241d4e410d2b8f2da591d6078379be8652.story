milk is recognized by quantity and quality of major nutrients, which contains proteins and inorganic salts such as phosphorus, calcium.
[1] with limited access to modern milk replacers, breastfeeding is essential for the newborn's survival, development, and growth.
[2] prolactin is responsible for milk secretion by stimulation of milk protein synthesis in the epithelial cells and proliferation of secretory cells.
the secretion of prolactin is mainly affected by environmental stimuli, dopamine, and internal milieu like the effect of the chemistry of lactation.
[34] today, low supply of milk is one of the most common reasons for discontinuing breastfeeding.
galactagogues are the medications or substances to assist initiation, maintenance, and augmentation of maternal milk production.
on the basis of safety and potentiality, the plant source is one of the preferred directions of research for galactagogue.
teramnus labialis linn.
(fabaceae) is an annual herb; commonly known as mashavan (hindi) and a famous medicinal plant in the ayurvedic system of medicine.
it is very useful in treating rheumatism, tuberculosis, nerve disorders, paralysis, and catarrhs.
[56] in ayurvedic system of medicine, the root powder is used as an important ingredient in chyawanprash and also helpful in general debility, malnutrition, and fatigue.
[78] earlier scientific investigation suggested that the whole plant, as well as roots, possess as an antioxidant,[9] anti-inflammatory,[10] antihyperglycemic,[11] and hypolipidemic[12] activity.
the major bioactive phytoconstituents are fraxidin and galactomannan.
[10] the fruits of this plant have been used as galactagogue by various traditional practitioners and tribal peoples of india.
[131415] therefore, the present investigation is focused to evaluate the lactogenic activity of methanolic extract of t. labialis fruit (mtlf) on nursing wistar rats.
subjects and methods collection of plant materials the fruits of t. labialis were collected from the local region of ganjam district, odisha, india.
further taxonomic identification and authentification were conducted at the department of botany, berhampur university, ganjam, odisha, india, where a plant specimen was deposited in the herbarium for further reference.
preparation of extract the collected fruits were allowed to air-dry and powdered to coarse consistently in a grinder mill.
then, the coarse powder was passed through forty mesh size and stored in an airtight container at room temperature.
accurately 250 g of coarse powder was weighed and successively extracted with methanol by maceration at room temperature for 72 h, in a conical flask.
then, the extract was filtered and concentrated to dryness at room temperature to avoid decomposition.
the yield of the mtlf was found to be 13.81% w/w and preserved in refrigerator for further use.
experimental animals adult wistar albino rats (200–250 g body weight) of either sex were housed in standard conditions of temperature (22°c ± 2°c) and relative humidity (55% ±5%).
the rats were kept on wood shavings in plastic boxes with wire covers, and the lighting was adjusted with 14 h of lightness (06.00 a.m.–08.00 p.m.) and 10 h of darkness (08.00 p.m.–06.00 a.m.) in a day with standard pellet diet (lipton india ltd., mumbai, india) and water ad libitum.
the experimental protocol was approved by the institutional animal ethical committee as per the guidance of committee for the purpose of control and supervision of experiments on animals, ministry of social justice and empowerment, government of india (regd.
no.
472/cpcsea).
acute toxicity study of methanolic extract of teramnus labialis fruits the animals were fasted overnight before the experiment.
different graded doses of methanolic extract were administered orally to animal groups and were observed continuously for 24 h for any gross behavioral changes, followed any mortality as per the oecd guideline 425.
[16] effect of oral treatment of methanolic extract of teramnus labialis fruits on milk production thirty female rats were procured and mated with male rats.
the rats were allowed to deliver their young and the day of parturition was designated as day 1 of lactation.
all the lactating rats were randomly divided into five groups of six rats each (n = 6).
each mother was adjusted to have only six pups per litter within 48 h. group i treated as control and received distil water; group ii treated as standard and received domperidone (2.5 mg/kg body weight) and group iii, iv, and v treated as test extract and were orally administered with mtlf at 200, 400, and 600 mg/kg body weight, respectively.
the mtlf and domperidone were suspended in vehicle and administered daily using animal feeding tube to lactating mother at 07.00 a.m. starting from 5th to 14th day of lactation period.
the milk productions were measured daily after 12 h of treatment.
the weights of the litters before and after 60 min of suckling were measured to estimate milk yield.
the differences in weight of the litters were considered as the amount of yield.
the milk yields and weight gain of littermates as well as mother rats along the experimental period were measured and compared between the treatment groups and their respective control group.
all the measurements of weight were read with accuracy of 0.01 g using electronic balance.
[17] estimation of serum prolactin and cortisol level on 15th day of parturition, the blood samples collected from lactating rats through retro-orbital plexus.
the blood samples were centrifuged and allowed to separate the serum.
from the serum sample, the prolactin and cortisol level were estimated using enzyme immunoassay.
[18] estimation of glycogen and protein content of mammary gland tissue on 15th day of parturition, the lactating mother rats were euthanized after the blood collection and whole mammary glands were excised.
about 100 mg of mammary tissue was homogenized in distilled water using tissue homogenizer and 30% saturated potassium hydroxide.
then, the reaction mixture was incubated for 30 min at 65°c.
the resulted homogenate was used further for quantitative estimation of glycogen and protein.
[18] for glycogen estimation, 2 ml of 95% ethanol was added to mammary homogenate and centrifuged.
the precipitated glycogen was collected from the alkaline digestate, dissolved in distilled water, and estimated by phenol-sulfuric acid method.
total protein content was estimated using total protein kit.
statistical analysis the result was expressed as mean ± standard deviation.
the differences in mean value among the treatment groups were analyzed by one-way anova followed by tukey–kramer post hoc test (intra coefficient of variation), using statistical package of spss (version 17, spss inc., chicago, il, usa).
values with p ≤ 0.01 and p ≤ 0.05 were considered statistically significant.
results acute toxicity study no mortality and the sign of toxicity were observed at the dose of 2000 mg/kg in case of albino rats.
effect of methanolic extract of teramnus labialis fruits on milk production of lactating rats the milk production of control, domperidone, and the groups of mtlf was measured daily [table 1].
the result showed that there was a significant increase (p < 0.001) of milk yield in mtlf-treated groups as compared to control.
again, mtlf-treated groups were showed dose-dependent increase of total milk yield during 10 days of the lactation period.
during this lactation period, total milk production was the highest in mtlf (600 mg/kg) as compared to standard group.
the mtlf at 200, 400, 600 mg/kg, and standard group produced 22%, 53%, 75%, and 58% increase of milk yield, respectively as compared to control.
the percentage of milk production during 10 days was found significant at p < 0.01 and p < 0.05 in mtlf groups and also indicated the highest quantity of milk during peak lactation time.
table 1 effect of methanolic extract of teramnus labialis fruits on milk production during 10 days of lactation in rat effect of methanolic extract of teramnus labialis fruits on body weight of pups and lactating mother the changes of body weight of the suckling pups during lactation period for all treatment groups were observed [table 2].
daily body weight of all the suckling pups was linearly increased over the period of 10 days of observation.
in mtlf-treated groups, the body weight of pups was nearly doubled at the end of the study period, and the rate of weight gain in mtlf groups was significantly higher than the control and domperidone-treated groups.
similarly, mtlf significantly increased the body weight of lactating mother as compared to the control animals.
table 2 effect of methanolic extract of teramnus labialis fruits on body weight of pups and mother rats effect of methanolic extract of teramnus labialis fruits on the serum prolactin and cortisol level in lactating rats the results obtained in this experiment showed that the mtlf had increased serum prolactin and cortisol level significantly (p < 0.001) in lactating rats [figure 1].
the serum prolactin and cortisol level in mtlf at 400 and 600 mg/kg were found higher as compared to domperidone-treated group.
again, the serum prolactin and cortisol level were increased more than two-fold in mtlf at 600 mg/kg group as compared with control.
figure 1 effect of methanolic extract of teramnus labialis fruits on serum prolactin and cortisol level in lactating dams at day 15. values are expressed as mean ± standard deviation (n = 6).
anova (tukey–kramer post hoc test); untreated control versus methanolic extract of teramnus labialis fruits/domperidone (ap < 0.001;bp < 0.01) effect of methanolic extract of teramnus labialis fruits on total protein and glycogen content of mammary gland tissue the status of milk protein and glycogen were significantly increased in mammary tissue of mtlf-treated mother rats as compared with control [figure 2].
total protein and glycogen content were increased in a dose-dependent manner and found significant at p < 0.01 and p < 0.05 as compared to control.
the total protein and glycogen content were increased by two-fold in mtlf at 600 mg/kg group as compared with control.
figure 2 effect of methanolic extract of teramnus labialis fruits on total protein and glycogen contents from mammary homogenate of lactating dams at day 15. values are expressed as mean ± standard deviation (n = 6).
anova (tukey–kramer post hoc test); untreated control versus methanolic extract of teramnus labialis fruits/domperidone (ap < 0.001;bp < 0.01) discussion in the present era, discontinuation of breastfeeding is a major problem in lactating mothers due to low secretion of milk.
the breastfeeding is influenced by certain nutritional and nonnutritional factors such as endocrinologic imbalance, health, and climate which cumulatively affect milk synthesis and its production.
[19] secretion of prolactin plays a major role during lactation.
the marketed galactagogues are acting by blocking the dopamine receptor and increase the production of prolactin.
[20] in this study, the milk production was significantly increased in mtlf-treated animals than the untreated control.
this increase of milk production in lactating mother was assumed due to the increase of cells proliferation in their mammary gland after interference of mtlf.
galactagogues have a profound effect on the mammary secretory cells proliferation which is used as an indicator of lactogenic activity.
[21] hence, the increase of rate of milk secretion in mtlf could be due to mammary secretory cell population and cellular activity.
[2223] milk consumption is responsible for body maintenance and growth of neonates.
the growth of the pups was strongly influenced by the quantity of the milk available during the suckling time.
the pup growth rate was significantly improved in mtlf as well as domperidone-treated groups as compared to control group.
at early stage of nursing mother, enough feed is required to meet the energy demand of lactation and maintenance requirement.
[24] the result of this study showed the weight gain in lactating rats at termination period which is statistically significant at p < 0.01 and 0.05. it is clearly indicated that mtlf acts as a health promoter to mother rats during lactation period.
in general, galactagogues stimulate the synthesis of lactogenic hormones (prolactin, growth hormone, and cortisol), β-endorphin, and β-casein in the mammary gland.
[25] after parturition, prolactin stimulates the synthesis of milk proteins in the epithelial cells and proliferation of secretory cells.
[26] our studies indicate that mtlf increased the serum prolactin which stimulates the mammary gland development and the differentiation of the lobuloalveolar system from the lobular buds.
these results agreed with the earlier observations of mammary gland development in lactating rats.
[27] again, mtlf increased the protein and glycogen content of mammary gland as compared to untreated control which results improvement of body weight in pups as well as in mother rat.
the cortisol level was also increased in mtlf-treated groups which contribute to the feeling of calm, well-being and maintaining the mood of mother rats during suckling period.
the increase in milk yield in this study is due to the increased serum prolactin level and maintaining the balance of serum cortisol, which encourage the biosynthesis of milk.
[18] conclusion mtlf acts as a promising source of galactagogue by stimulating milk production and prolactin synthesis as well as release in the rat.
these finding would raise confidence among consumers toward its valid use and effectiveness of the extract.
however, further studies are needed to investigate the bioactive agents and their molecular mechanisms for lactogenic activity.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
aim: the objective of the study was to investigate the lactogenic activity of methanolic extract of teramnus labialis (l.) fruit (mtlf) on rats.
subjects and methods: nursing rats (200–250 g) with their suckling pups were selected and were divided into five groups (n = 6).
group i treated as control (distil water); group ii treated as standard (domperidone), and group iii, iv, and v were orally administered with mtlf at 200, 400, and 600 mg/kg body weight, respectively and continued for l4th day of parturition.
milk yield, the pups as well as mother's weight were measured daily.
on 15th day, the total protein/carbohydrate contents from mammary tissue and serum prolactin/cortisol level from blood sample were measured and compared with control.
results: oral administration of mtlf increases the milk yield, body weight of pups as well as mother rat, glycogen, and protein content as well as serum prolactin and cortisol level as compared to the control animals.
in addition, the lactogenic effect of mtlf was followed dose-dependent manner as compared to control.
conclusions: the present study was revealed that the mtlf possesses significant lactogenic activity by enhancing milk production and prolactin concentration in nursing rats.
