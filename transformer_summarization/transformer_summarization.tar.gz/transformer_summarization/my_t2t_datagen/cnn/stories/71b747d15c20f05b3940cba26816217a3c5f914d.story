introduction since immemorial times, animal venoms have been used as potent drugs to cure different disease states[1].
in traditional medical practice, scorpion venoms have been applied for the treatment of various ailments, such as acute and chronic convulsion, epilepsy, subcutaneous nodules and tetanus for more than 2100 years[2].
as written information on chinese herb states, snake and scorpion venoms contain many different biologically active proteins and peptides that have pharmacological activities such as anti-microbial[3], anti-epileptic[4], and channel-blocking activities[5,6].
recently, some possible clinical usages of venoms have also been described[7,8].
hemiscorpius lepturus is an iranian scorpion found in southwest of iran, and its venom contains hemolytic, proteolytic, cytotoxic, anti-cancer and channel blocker compounds with possible therapeutic potency[9-13].
despite the significant success of highly anti-retroviral therapy, aids is still one of the urgent world health problems [14].
although conventional drugs targeting viral components of hiv are widely being used and have shown satisfactory results [15,16], there is a growing demand for the discovery of new therapeutic agents with either natural or synthetic origins.
herpes simplex virus (hsv) is another common virus that causes different types of diseases, with different degrees of severity ranging from mild to severe.
in certain cases, it may possibly lead to life-threatening situation, particularly in immune-compromised patients.
after the primary infection, hsv establishes itself by permanently residing in the ganglia of the host neurons.
nucleoside analogs as well as acyclovir and other nucleoside derivatives, including famciclovir, valaciclovir, and penciclovir have been approved for the treatment of hsv infections[17].
however, the formation of acyclovir-resistant hsv is an increasing problem.
in the last decade, natural derivatives have been considerably used as the popular remedies to prevent or manage the chronic diseases, to improve cognitive function and to increase longevity[18].
natural medicines have reportedly important pharmacological activities and are capable of producing therapeutic effects[19,20].
a large number of natural agents have already been used as anti-viral products, and for some of these compounds, the target molecules and mechanism of action have been identified.
a previous study has described a novel peptide, called p3bv, which had been extracted from the bee venom and inhibited t-tropic, but not m-tropic hiv, through its interaction with cxcr4[21].
it has also been reported that the snake venom administration could decrease the viral load and increase cd4 cells count for one year in a patient with multidrug-resistant hiv, high viral load, and low cd4 count[22,23].
in the field of venomics, emergency medicine has traditionally been most concerned about envenomation syndromes, their treatment and investigative therapeutic strategies of envenomation.
taking an alternative viewpoint, here in this paper, we have evaluated the anti-viral activity of venom from h. lepturus to inhibit the replication of hiv and hsv virions.
we also investigated the anti-viral activity and the cytotoxicity of the crude venom and its purified fractions with phospholipase activity.
furthermore, the virucidal activity of the above mentioned venom was measured to identify its possible mechanism of action.
materials and methods ethics statement all animal experiments, including maintenance, animals’ handling program, and sample collection were approved by institutional animal care and research advisory committee of pasteur institute of iran (research deputy, dated october 2010), based on the specific national ethical guidelines for biochemical research issued in 2005 by the research and technology deputy of ministry of health and medicinal education (mohm) of iran.
venom preparations adult h. lepturus scorpions were collected from khuzestan and housed in well-ventilated wooden cages with food and water, supplied ad libitum.
venom was collected by electrical stimulation of the telson (8 volt), and the collected samples were pooled.
the collected venom was lyophilized and then stored at -20°c[24].
purification the h. lepturus lyophilized venom was weighed, and its protein concentration was measured by bradford’s method[25].
crude venom (6 mg) was dissolved in 0.05% trifluoroacetic acid in hplc grade water and centrifuged at 2×104 g or 10 min.
the clear supernatant was used for purification.
reverse phase hplc was performed in a hplc system (knauer gmbh, germany) at a flow rate of 1 ml/min for 180 min.
the fractions were separated by c18 column (250 mm×4.6 mm), 5 μm particle size, 100ǻ pore size) with a linear gradient of 0.1% trifluoroacetic acid in water (solution a) and acetonitrile (solution b) 5% for 10 min, followed by 5-15% over 20 min, 15-45% over 120 min, and 45-78% over 20 min.
the protein fractions were detected at 214 nm, and collected manually, dried in a vacuum concentrator and stored at -20°c.
phospholipase activity assay serial amounts of the isolated fractions and venom prepared in 100 µl deionized water.
then the substrate solution (100 µl containing lecithin, ethanol, triton x-100, nacl, phenol red, cacl2 and h2o) was added to each well and incubated at 37°c for 15 min.
deionized water was used as negative control and phospholipase a2 from macrovipera lebetina snake venom was used as positive control.
optical density was documented at 550 nm in a microplate spectrophotometer (epoch, biotek, usa).
cells and transfection hela, hek293t, and vero cells were obtained from the cell bank of pasteur institute of iran (tehran) and maintained in dmem medium (gibco, germany) containing 10% fetal calf serum (biosera, iran), 50 u/ml penicillin (gibco, germany), and 50 mg/ml streptomycin (gibco, germany).
plasmids were transfected into hek293t cells using polyfect transfection reagent (qiagen, usa) according to the manual instruction.
briefly, 3.7×105 hek293t cells were seeded in 6-wells plates and transfected after 24 h. hepes at the concentration of 25 nm was added to the culture medium during the transfection.
viruses single cycle replicable (scr) hiv-1 virions pseudotyped with vesicular stomatitis virus surface glycoprotein were produced using transfection[14,26].
a plasmid mixture of pspax2, pmd2g (addgene, germany), and pmznl4-3 (patented vector of pasteur institute of iran) was used for each well, and dna-transfection complex was removed after 8 h[14,27,28].
the virions were harvested at 24, 48, and 72 h post transfection, pooled and kept at 4°c.
the pooled supernatants were clarified by 5-min centrifugation at 2×104 g and filtered through 0.45-µm filters.
the viruses were stored at -80ºc and were then evaluated for their infectious titers[29,30].
hsv-1 (kos strain) was used in this study for the assessment of anti-hsv activity.
to prepare the hsv virus stock, vero cells (4.5×105) were seeded in 6-well plates and infected by hsv virions after 24 h. the cell supernatants were harvested every 24 h after the infection until 96 h. the harvested supernatants were pooled and then clarified using 0.45-µm filters.
the virus stock was stored at -80ºc and tittered for plaque-forming activity.
hiv replication assay hela cells were placed in 96-wells plates (8×103 cells per well) and used as targets of infection.
the venom was added into the culture medium 2 h prior to the infection, and its concentration was maintained for 72 h after the infection.
the cells were infected with 300 ng p24 scr hiv and then incubated for 24 h to absorb the virions.
the infected hela cells were washed twice with phosphate buffered saline 24 h after infection and fed with 200 µl fresh medium.
the plates were incubated for an additional 48 h and then centrifuged at 3.5×103 g for 15 min.
the supernatants were analyzed by p24 capture elisa (biomerieux, france).
the minimal concentration of the venom required to suppress the load of p24 by 50% (ic50) was determined by regression analysis of the dose response curve.
hsv plaque reduction assay the hsv inhibitory effect was evaluated by plaque reduction assay.
vero cells (4×105) were seeded onto 24-well plates and incubated for 24 h to reach at least to 96% confluency.
the vero cell monolayer was infected with 50 pfu of hsv-1 (kos) and after 1 h, it was washed with pre-warmed dmem and overlaid with methylcellulose (1.2%).
the plates were further incubated in the presence of 5% co2 at 37ºc for 72 h. later, the overlay medium was aspirated, and the cell monolayer was precisely washed.
plates were fixed with methanol and then stained with 0.5% crystal violet.
the inhibition percentage of hsv infection was determined by considering the reduction in plaques number.
virucidal effect the direct inhibitory activity of the venom on hiv particles infectivity was evaluated by virucidal effect assay.
the venom (200 µg/ml) was mixed thoroughly with 1.1×103 p24 of hiv in a final volume of 11 µl.
the mixture was incubated at 37ºc for 2.5 h, and then the reaction was stopped by adding 80 µl fresh complete medium.
residual virus infectivity was evaluated by hiv replication assays as mentioned above.
the higher percentage of viral infectivity indicates the lower virucidal efficacy of the venom.
cellular toxicity the cytotoxicity of the venom was tested by xtt (sodium 3’-[1-(phenylaminocarbonyl)-3,4-tetrazolium]-bis (4-methoxy-6-nitro) benzene sulfonic acid assay (roche, germany) according to the manufacture’s instruction.
hela cells (104 in each well of a 96-wells plate) were treated with the venom for 72 h. after that, the medium was aspirated and fresh phenol red-free dmem was added into the wells.
next, xtt solution was added (50 μl) into each well and then plates were incubated for 3 h. the absorbance of the sample was evaluated at 450 nm with a reference wavelength of 630 nm, and the cc50 (50% cytotoxicity concentration) was estimated from the plots.
results anti-viral potential of the crude venom the crude venom of h. lepturus was assessed for its anti-viral activity against hiv and hsv.
the virions were cultured in the presence of 0.2, 2, 20, and 200 µg/ml concentrations of the venom, and the inhibitory effect was monitored by hiv replication and hsv plaque reduction assays.
as shown in figure 1, h. lepturus inhibited 73% infection at 200 µg/ml but did not show any significant activity in lower concentrations.
the crude venom slightly raised the hsv replication at concentrations of more than 20 mg/ml, while it did not demonstrate any significant toxicity for the target hela cells (fig.
1).
fig.
1 does response activity.
the anti-viral and cellular toxicity of h. lepturus venom for hela cells.
the hiv replication and hsv plaque reduction assays were used to investigate the anti-viral activity.
the cytotoxicity was determined by xtt proliferation assay.
the h. lepturus did not show anti-hsv and cytotoxic effect, while it indicated remarkable inhibitory activity against hiv, especially in higher concentrations.
virucidal effect of the venom the neutralizing effect of h. lepturus venom against hiv particles was investigated by virucidal assay.
the virucidal activity of the crude venom was consistent with its anti-replication activity.
the replication capacities of hiv and hsv virions were evaluated after incubation with h. lepturus venom for 2.5 h. the h. lepturus crude venom showed significant activity for neutralizing the hiv particles; however, it did not have any significant effect on hsv virions.
furthermore, the venom neutralized 60.5% of hiv virions at 200 µg/ml, and no remarkable anti-hiv activity was observed in lower concentrations (table 1).
table 1 the neutralizing effect of h. lepturus venom against hiv and hsv particles concentration (mg/ml) percentage control of viral infectivity (%) hiv-1 hsv-1 0.2 101.1±3.6 100.5±8.5 2 97.9±2.8 103.2±8.4 20 87.2±1.9 94.7±14.6 200 39.5±5.3 83.2±5.5 the activity of extracted phospholipases from h. lepturus venom to determine the active components of h. lepturus venom, the venom was fractionated using hplc system.
for this purpose, over 90 fractions were purified from h. lepturus venom.
hemolytic fractions were separated from hplc column at retention time of 155-158 minutes and acetonitrile concentration between 45 and 78% (fig.
2).
the extracted phospholipases were investigated for their hemolytic activity.
hemolytic activity of phospholipase x1, x2, x3, and x4 at concentration 5 µg/µl were 59, 78, 92, and 87%, respectively (fig.
3).
the anti-hiv potential of the fractions was evaluated by replication and cytotoxicity assays.
the x1 and x2 phospholipases inhibited the hiv replication by 43.5 and 22.5%, respectively (fig.
4).
the h. lepturus venom interestingly encompassed a fraction of peptides with less than 10 kda, which showed a high potential for facilitating hiv replication, inasmuch as the p24 load was increased approximately three-folds in the presence of the mentioned fraction (20 µg/ml).
fig.
2 hplc for h. lepturus crude venom.
fig.
3 phospholipase activity of purified fractions.
fig.
4 anti-hiv activity of various fractions of h. lepturus venom.
one of the extracted phospholipases (x1) showed the most anti-hiv activity among fractions extracted from crude venom.
it inhibited about 43.5% of replication at 20 µg/ml concentration.
the h. lepturus venome also encompassed a fraction of small peptides (>10 kda) with considerable activity for facilitating hiv replication.
discussion in the current study, the anti-viral property of scorpion h. lepturus venom was evaluated by hiv replication and hsv plaque reduction assays, while its cytotoxicity was monitored by xtt proliferation assay.
h. lepturus venom showed negligible cytotoxicity for hela cells and had specific impact on the viral replication.
h. lepturus crude venom was shown to be a significant inhibitor against hiv virions (fig.
1).
this venom seems to affect the hiv but not the hsv replication, which demonstrates its specific interference in hiv life cycle.
the analysis of the dose-response curve indicated the difference between the anti-viral effects of h. lepturus at concentrations lower and higher than 20 µg/ml (fig.
2).
h. lepturus venom slightly raised the replication of hiv at 2 µg/ml whereas at higher concentrations (200 µg/ml), it notably inhibited the virions.
the unique activity of h. lepturus against hiv replication, but not hsv, indicates that the venom of this scorpion may contain anti-hiv active components.
the mechanism of anti-hiv activity was investigated by evaluating the direct effect of the venom on hiv particles.
the virucidal effect of h. lepturus venom was similar to its inhibitory effect against hiv and hsv replication (table 1).
these data verified the anti-hiv potential of h. lepturus venom and depicted a possible mode of its anti-hiv action.
the virucidal activity highlights the potential of this venom for neutralizing hiv virions, possibly by affecting the viral envelope protein or interfering in the fusion process.
previous studies have shown that phospholipases (pla) extracted from bees and snakes could inhibit hiv at an early stage during the viral infection[21,31].
hiv enters the target cells by fusion at the plasma membrane.
this process is triggered by the binding of a glycoprotein to cd4 and chemokine receptors on the viral surface.
it is interesting that (or it is notable that) unlike pla isolated from the animal venoms, the human secreted pla does not show any anti-hiv activity in vitro.
the previously suggested mechanism for the in vitro anti-hiv effect of pla extracted from crotalus durissus terrificus was the ability of this enzyme to destabilize the fusion complex on hiv target cells[32].
the h. lepturus venom was subjected to fractionation to extract the venom pla and subsequently verify its anti-hiv activity (figs.
2 and 3).
based on the obtained data, one of the separated pla from h. lepturus had considerable anti-hiv activity (fig.
4).
there is a significant reverse correlation between the anti-hiv and the phospholipase activity of the extracted plas, since x1 with the lowest phospholipase activity was the highest inhibitor against the hiv replication.
according to our data, the h. lepturus venom contains components with the ability to facilitate hiv replication so that a fraction of small peptides (<10 kda) increased the hiv replication three-fold.
based on these data, the h. lepturus venom must contain an anti-hiv component with considerable activity or a certain mode of action that compensates the inducing activity of the low molecular weight (<10 kda) fraction.
the present study reports the anti-hiv activity of h. lepturus venom, which is already known as a hemolytic, cytotoxic, proteolytic and channel blocker agent[9-12].
h. lepturus showed neutralizing activity against hiv virions, implying that the active components of this venom interacted with the viral particles or interfered in the fusion process.
in this respect, the novel putative anti-viral activity of h. lepturus venom will be particularly valuable to be analyzed in the future.
the x1 phospholipase of this venom would be a promising candidate in anti-hiv drug discovery programs.
@highlight
background: during the recent years, significant progress has been achieved on development of novel anti-viral drugs.
natural products are assumed as the potential sources of novel anti-viral drugs; therefore, there are some previous studies reporting the anti-viral compounds from venomous animals.
based on the significant value for tracing of non-toxic anti-viral agents from natural resources, this study was aimed to investigate the anti-viral activity of some hplc purified fractions derived from the venom of iranian scorpion, hemiscorpius lepturus, against human immunodeficiency virus 1 (hiv-1) and herpes simplex virus 1 (hsv-1).
methods: h. lepturus crude venom was subjected to reverse phase hplc analysis to determine its active components precisely where four dominant fractions obtained at retention time of 156-160 minutes.
the phospholipase a2 and hemolytic activities of the purified fractions were first evaluated.
then the anti-viral activity was measured using single cycle hiv (nl4-3) replication and hsv (kos) plaque reduction assays.
results: the h. lepturus crude venom inhibited hiv replication by 73% at the concentration of 200 µg/ml, while it did not show significant anti-hsv activity.
it also inhibited the cell-free viral particles in a virucidal assay, while it showed no toxicity for the target cells in a proliferation assay.
the four hplc fractions purified from h. lepturus inhibited hiv with ic50 of 20 µg/ml.
conclusion: h. lepturus venom contains components with considerable anti-hiv activity insofar as it has virucidal activity that offers a novel therapeutic approach against hiv infection.
our results suggest a promising pilot for anti-hiv drug discovery with h. lepturus scorpion venom.
