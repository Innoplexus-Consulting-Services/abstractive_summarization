introduction the restorative treatment of deep carious lesions in young permanent molars presents a challenge for dentists because complete caries removal can expose the pulp tissue, leading to more complex treatments such as an endodontic procedure.
to avoid this, the treatment protocol has changed significantly over time.
the complete removal of the carious tissue is no longer recommended because partial caries removal[123] or the sealing of the infected dentin tissue,[45] allows dentin repair, prevents unnecessary tissue loss, and permits the conservative treatment of deep carious lesions.
[16] unlike the step-wise excavation technique,[7] a single clinical session (without tooth reopening) is the current trend in carious lesion management.
[891011] after cavity sealing/dental restoration, tissue remineralization,[161213] reduction in bacterial counts,[3141516] and histological dentin reorganization with intertubular dentin thickening and formation of a dense collagen network[6] were reported.
if the glass ionomer cement (gic) is used as a liner, an ion exchange of calcium, phosphate, and fluorine between demineralized dentin occurs.
[171819] this fact generated a discussion about the role of the lining material on the reorganization of the remaining carious tissue.
some authors reported that gic can supply bioactive molecules promoting dentin regeneration,[20] whereas others argued that caries arrestment is not dependent on the cavity liner materials.
[1621] this controversy highlights the need for further investigation.
therefore, this study aimed to evaluate the impact of the liner material on the morphological and mineral changes of carious dentin of permanent teeth after tooth restoration.
methods this study was approved by the ethics committee of the state university of ponta grossa (ponta grossa, paraná, brazil) under protocol #78/2011 and evaluated infected permanent dentin at baseline and 60 days after cavity sealing (60-day), using laser fluorescence (lf) readings and morphological and mineral analysis under scanning electron microscopy (sem).
sample selection and inclusion criteria after an initial screening of 772 children from rural area schools, 35 children of both genders with ages ranging from 7 to 15 years (average = 11.0 ± 2.7) were included in the study.
children with systemic pathologies were excluded from the study.
the participants’ parents or caregivers were informed of the objectives of this study.
parents and children signed a consent form permitting their participation.
the children were subjected to clinical and radiographic examinations for permanent molar selection.
these teeth should present deep active caries, scored as icdas code 06.
[22] the carious lesions should reach the inner portion of dentin (2/3 or more of the dentin thickness).
teeth should not exhibit signs or symptoms of pulp pathology (i.e.
fistula, tooth mobility, periapical alterations, and spontaneous pain).
if any of these signs were observed, the tooth was excluded.
a final sample of 45 teeth was selected.
the teeth were randomly designed to group 1 (n = 23 - gic liner + composite resin restoration) or group 2 (n = 22 - inert material − wax + composite restoration).
clinical procedures each patient attended two clinical sessions to collect dentin samples.
after local anesthesia and rubber dam isolation, teeth were cleaned with a new toothbrush and water, washed thoroughly with air/water spray, and air dried without desiccation.
at baseline, we examined the characteristics of the mesial portion of the tooth, whereas the distal portion was examined 60 days after restoration at the reopening of the tooth.
the research protocol consisted of lf readings (as described later in this session) followed by the removal of the carious dentin; this process was repeated at baseline and at the 60-day follow-up period.
to facilitate the removal of the mesial and distal portions of the dentin, the carious lesion was divided at baseline into two equal portions using a hollenback carver in a buccal-lingual direction.
[2] the dentin samples were removed using a sterile dentin excavator, and immediately after removal, the dentin fragments were processed for morphological and mineral analysis.
the cavity preparation involved only the removal of the carious tissue from the cavosurface margin to promote appropriate cavity sealing.
in the gic group (g1), the pulpal floor of the cavity was covered with high-viscosity gic (ketac molar easymix®, 3m espe, st. paul, mn, usa).
polyacrylic acid was not used to aid cavity reopening 60 days after the procedure.
in the wax group (g2), a piece of utility wax (lysanda, são paulo, sp, brazil) approximately 1 mm thick was placed on the pulpal floor.
all cavities were etched with 37% phosphoric acid gel (villevie, joinville, sc, brazil), rinsed with water and slightly air dried.
a two-step etch-and-rinse adhesive (adper single bond 2, 3m espe) was applied according to the manufacturer's instructions, and the composite resin (llis, fgm, joinville, sc, brazil) was placed in slim increments.
after the composite resin placement, a sealant (fluroshield, dentsply, petrópolis, rj, brazil) was applied on the restoration margins for extra protection.
[23] the light-curing process was performed with a quartz-tungsten-halogen-light under ramped curing (dx turbo led 1200, d-x, ribeirão preto, são paulo, brazil).
the initial light intensity was 450 mw/cm2, with an automatic increase to 1200 mw/cm2 after 10 s. sixty days after the procedure, the marginal integrity of the restorations was evaluated using the united states public health service criteria:[24] (1) cavosurface marginal discoloration, (2) recurrent caries, (3) contour or loss of substance (wear), (4) marginal integrity, and (5) surface texture.
these variables were ranked with the following scores: alpha (no defect clinically detectable, needing only a polish), bravo (clinically acceptable, but repair is needed), and charlie (clinically unacceptable, needs restoration replacement).
if there were signs or symptoms of pulp pathology or restorations defects that compromised cavity sealing, the tooth was excluded.
then, the restorative material was removed with a sterile diamond bur (#1092 - kg sorensen, são paulo, brazil) under water cooling until the gic and wax were reached.
manual instrumentation was used to complete the removal of the material.
lf readings were taken from the distal portion of the cavity.
dentin samples from the distal portion of the tooth were removed for morphological and mineral analysis in the same manner as described for the mesial portion.
after the collection of the dentin samples in both periods, the teeth were restored with composite resin restorations.
all of the clinical procedures were performed by a single operator (eunice kuhn), a trained and experienced pediatric dentist.
laser fluorescence readings dentin lf was measured with diagnodent 2095 (kavo, biberach, germany) following the manufacturer's instructions.
the device was calibrated against a porcelain reference object and recalibrated on a sound surface of each tooth before the examination.
lf values may range from 0 to 99. optimal cutoff limits of the lf device to detect in vivo occlusal caries lesion depth are as follows: 0–14 - sound teeth; 15–21 - enamel lesions; 22–37 - caries lesion in the outer half of the dentin; and >38 - caries lesion in the inner half of the dentin.
[25] three measurements on carious dentin in the mesial (baseline measurement) or distal portion (60 days after tooth restoration) of the cavity were taken, and the mean value from each period was calculated to represent the individual tooth.
morphological and mineral analysis dentin fragments from the mesial (baseline) and distal (60-day sample) portions were stored into a 2% glutaraldehyde solution with a sodium phosphate buffer of 0.1 m (ph 7.4) for 7 days, rinsed thoroughly with 50% sodium phosphate buffer (0.3 m) and distilled water solution (three 30-min rinses), and dehydrated in acetone at 30%, 50%, and 70% for 10 min, 90% for 20 min, 100% for 10 min, and 100% for 20 min.
samples were kept at 37°c for at least 3 days to remove any residual water.
specimens were mounted on stubs and sputter-coated with a 10-nm gold layer.
they were analyzed with sem using secondary electron mode with a voltage of 12 kv.
the same sample was analyzed using dispersive x-ray spectrometry energy to measure the relative percentage of calcium, phosphorus, and fluorine among the 12 most common chemical elements in the dentin substrate.
the weight percentages of calcium, phosphorus, and fluorine before and after tooth restoration were assessed at a magnification of ×200 for 100 s. all of the microphotographs were analyzed by the same examiner (ana claudia rodrigues chibinski), who was blinded to the group to which the specimen belonged.
the characteristics evaluated were the presence of bacteria, the collagen network, and the mineralization of inter- and peri-tubular dentin.
after this analysis, one representative image of each condition was selected for publication.
statistical analysis the tooth was employed as an experimental unit for data analysis.
the software statistical package for social sciences (ibm corporation, spss® 17.0, chicago, illinois, usa) was used for statistical analysis with the significance level set at 0.05. before submitting the data to statistical analysis, kolmogorov–smirnov test was performed to assess the normality of the data, and bartlett's test was used to verify if the assumption of equal variances was valid.
as the data from the lf reading failed in both analysis of variance (anova) assumptions (p < 0.05), we used nonparametric statistics for data analysis.
in each group, the lf readings before and after cavity sealing were compared by wilcoxon signed-rank test.
in each period, the lf readings of the gic and wax groups were statistically analyzed with mann–whitney u-test.
for the mineral data, the anova assumptions were valid (p > 0.05), and therefore, parametric statistics were employed.
for each tooth, the percentage value of each mineral obtained at 60 days was subtracted from the baseline value.
a paired t-test was used to compare the differences in wt% of calcium, phosphorus, and fluorine between the two study groups.
results of the 45 permanent molars at baseline, four teeth were not evaluated in the 60-day assessment.
in g1 (the gic group), the teeth were not evaluated due to pulp necrosis.
[1] in g2 (the wax group), three students did not attend the 60-day recall, so we could not evaluate their teeth.
in addition, after 60 days, one restoration was classified as charlie, so it was not included in the sample.
thus, a total of forty teeth from thirty patients were used for analysis.
laser fluorescence readings no significant difference in lf readings was detected for the gic and wax groups in either period (mann–whitney u-test, p > 0.05).
significant reductions in lf means were detected between periods for both groups (wilcoxon signed-rank test, p < 0.05) [table 1].
table 1 means and standard deviations of laser fluorescence for both groups at baseline and in the 60 days follow-up morphological and mineral analysis baseline samples from both groups showed highly infected tissue and a clearly exposed collagen matrix [figures 1 and 2].
after cavity sealing, fewer bacteria with a more compact arrangement of collagen fibers were seen in both groups [figures 1 and 2].
a similar gain in calcium and phosphorus was detected for both groups (t-test, p > 0.05) [table 2].
an uptake of fluorine was significantly detected only for the gic group (t-test, p = 0.032) [table 2].
figure 1 bacterial aggregates were seen at baseline for both groups (arrows).
after restoration, we observed some dentinal tubules without microorganisms (arrows) for g1 and g2, and a decrease in the bacterial contamination is evident although some microorganisms can still be seen in the intertubular dentin (pointer) figure 2 the demineralized dentin tissue with exposed collagen fibers was observed at baseline for both groups.
the 60-day samples exhibited a more compact tissue, particularly on g1.
however, the remineralization process also occurred on g2 in peri- and inter-tubular dentin (arrows) table 2 means and standard deviations of the 60-day vs. baseline difference in the weight percentage of calcium, fluorine and phosphorus for both groups discussion the clinical success of conservative procedures (step-wise excavation/indirect pulp capping) is achieved when pulp vitality is maintained, and no adverse symptoms are reported after treatment.
in the present study, only one tooth was excluded for pulp necrosis.
therefore, the overall success rate is 98% (95% confidence interval 88%–100%), which is in agreement with other published papers.
[2627] although this study was not pioneering research in demonstrating caries arrestment after dentin carious lesions sealing,[1628] few papers have compared a bioactive versus inert material as a liner.
[162129] this article provided evidence that dentin reorganization and mineral changes were not dependent on the material placed in contact with the carious tissue, suggesting that the carious arrestment is a host-driven process rather than a material-induced process.
[30] the concept that dentin remineralization is a material-driven process was based on the benefits of the fluoride in the enamel remineralization.
[31] some authors believe that fluoride release from gic could favor the remineralization of carious dentin.
[121320] however, if fluoride was necessary for dentin remineralization, we should have detected remineralization (by increased percentage of calcium and phosphorus) only in the gic group, and this was not observed.
the cessation of the caries process allows the biological response of the teeth.
sealing the cavity isolates bacteria from the oral environment and active biofilm,[1332] arresting the carious process, and providing time for the defense mechanism from the pulp-dentin complex.
in general, repair and regeneration in the dentin-pulp complex are similar to natural wound-healing responses seen in many of the body's systems.
[33] to respond to the inflammatory process induced by the caries lesion, odontoblasts produce a reactionary tertiary dentin matrix,[3334] along with high levels of growth factor secretion[33] in an effort to remodel and repair the extracellular matrix damaged by the disease process.
[35] thus, the dense collagen matrix seen 60 days after sealing is the result of tissue remodeling.
[36] considering that we used a destructive method, the images obtained were not from the same area, but the dentin sample collected was from the same tooth (which was reopened after 60 days) and depth.
this was possible because the carious tissue on the cavity floor was divided into two portions (mesial and distal).
[26] the decreased means of lf after restoration are consistent with the bacterial reduction detected in the sem images.
the lower lf readings are associated with the reduction of the bacterial aggregates and their metabolic by-products such as protoporphyrin ix, mesoporphyrin, and coproporphyrin,[33738] but not the mineral content of the dentin.
[39] however, the means of lf in the 60-day sample are still far from those reported for sound dentin (which ranges between 3 and 6) and dentin caries (which ranges between 35 and 40).
[25] a possible explanation is that the residual metabolic products are still readable by an lf device even after cavity sealing.
[3] by no means has the present study suggested the placement of an inert material (such as wax) inside the cavity, which was used only as a negative control for research purposes.
the selection of the liner/provisional or definitive restorative material should consider its biocompatibility, longevity and ability to bond to the dental structures.
conclusion caries arrestment with dentin reorganization occurs regardless of the lining material placed in contact with the infected dentin.
financial support and sponsorship this work was supported by a grant (no.
525/10) from the brazilian research agency, the araucaria foundation for supporting scientific and technological development of paraná, brazil.
conflicts of interest there are no conflicts of interest.
@highlight
aim: this study evaluated the impact of liner material on the fluorescence, morphological and mineral characteristics of permanent carious dentin after cavity sealing.
methods: thirty children (11.0 ± 2.7 years old) presenting at least one active deep carious lesion in permanent molars were selected.
fragments of carious dentin were removed from teeth before lining the cavity (baseline samples) with high-viscosity glass ionomer cement (g1) or an inert material (wax - g2).
cavities were restored with composite resin and reopened 60 days later, and other fragments were removed (60-day sample).
the laser fluorescence (lf) readings and morphological and mineral changes of both groups were compared.
results: after 60 days, forty teeth were available for evaluation.
lower lf means were obtained (wilcoxon signed-rank test; p < 0.05), and enhanced calcium and phosphorus levels were detected for both groups (t-test, p < 0.05).
an uptake of fluorine was observed only in g1 (t-test; p < 0.05).
regardless of the group, baseline samples exhibited clear signs of bacterial invasion, and the collagen fibers were exposed; the 60-day samples showed a better-organized tissue with a more compact intertubular dentin.
conclusion: caries arrestment with dentin reorganization occurs regardless of the lining material placed in contact with the infected dentin.
