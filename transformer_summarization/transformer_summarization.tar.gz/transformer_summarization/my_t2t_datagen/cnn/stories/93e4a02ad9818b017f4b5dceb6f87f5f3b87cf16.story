introduction tarsal coalition is the congenital bridging of two or more tarsal bones of the foot and has an incidence of approximately 1% in the general population.123 the vast majority of tarsal coalitions are either talocalcaneal (tc) (48.1%) or calcaneonavicular (cn) (43.6%),3 although this may differ in some populations.
taniguchi et al.4 reported that tc coalitions (83%) were the most common form of coalition, followed by cn (14%) and navicular-cuneiform (4%).
these percentages greatly differ from reports in western countries, where tarsal coalitions are divided almost equally between tc and cn coalitions.4 the differences may be due to racial peculiarities.56 in english literature, involvement of the middle facet in tc coalitions is the most common, followed by the posterior facet.7891011 however, there is some controversy with regard to the affected parts as taniguchi et al.4 reported that the frequency of tc coalition on the posterior subtalar facet was higher than that on the middle subtalar facet.
the optimal operative management of tc coalition has yet to be determined.
the primary operative options are resection of the coalition and arthrodesis.
because verifying the exact location of the lesion is important when operating, identifying the location of the tc coalition is inevitable.
the complex anatomy of the subtalar joint makes it difficult to visualize the tc coalition on plain radiographs.
as a result, errors in diagnosing this disorder are frequent.121314 in 1972, cowell reported that tomography was useful in the diagnosis of this disorder.15 in the 1990s, magnetic resonance imaging (mri) began to be used, and its clinical value has frequently been compared with that of computed tomography (ct) in recent years.141617 despite these advances, plain radiographs remain the primary modality for screening tarsal coalition.
however, no study has used ct or mri to verify the radiological characteristics of tarsal coalition or those of different facet coalitions.
we hypothesized that ct and mri would be more accurate for assessing the location of subtalar coalition than plain radiographs.
this study verified the radiological characteristics that could be used to diagnose tc coalitions and described individually those of different facet coalitions.
materials and methods subjects 51 patients diagnosed with tc coalitions based on clinical examination and plain radiographs between august 2005 and march 2014 in two hospitals were included in this study.
twelve patients who did not undergo ct or mri were excluded.
therefore, this retrospective study evaluated 43 feet in 39 patients who were diagnosed with tc coalition based on ct or mri.
patients consisted of 23 males and 16 females with an average age of 32.95 years (range 9–76 years).
coalition appeared on the right foot in 22 patients, on the left foot in 13 and both feet in 4 patients (both feet were diagnosed based on plain radiographs.
however, only those diagnosed using ct or mri were included in this study).
this study was approved by our institutional review board.
imaging and image evaluation lateral ankle radiographs were obtained for patients who were asked to assume a single legged stance with/without weight bearing posture for imaging.
an x-ray beam was directed from medially to laterally from a distance of 100 cm.
the center of the x-ray beam was located on the medial malleolus.
anteroposterior ankle radiographs were also obtained from patients, who were asked to assume a single-legged with/without weight-bearing posture for imaging.
an x-ray beam was directed from anteriorly to posteriorly from a distance of 100 cm.
the center of the x-ray beam was located on the center of the tibiotalar joint.
the diseased feet were classified based on three subtalar facets (i.e., anterior, middle, and posterior).
the criteria for diagnosis using ct or mri were continuity of adjacent marrow cavities, complete cortical bridging, joint space narrowing, marginal cortical irregularity, irregular hypertrophic cortical reactive bone, or all of these.4 ct or mri was used to verify the location of the tc coalition.
anatomically, the subtalar joint is separated into the middle subtalar facet and posterior subtalar facet by the canalis tarsi, which is located at the subtalar joint facing the anterolaterally side from a posteromedial direction.
thus, canalis tarsi can be identified in the axial plane of a ct or mri image [figure 1].
based on this, the area behind the canalis tarsi can be distinguished as the middle subtalar facet, while the posterior outer side of the canalis tarsi can be distinguished as the posterior subtalar facet.
the locations of the tc coalitions in the test subjects were categorized.
figure 1 the computed tomography axial cuts of subtalar joint.
the subtalar joint is separated into the middle subtalar facet and posterior subtalar facet by the canalis tarsi secondary signs of the presence of a coalition on radiographs are the c-sign [figure 2], talar beak [figure 3], humpback sign [figure 4], and duck-face sign [figure 5].
the typical c-sign is present when a continuous arc is seen on lateral radiographs between the medial cortex of the talus and the inferior cortex of the sustentaculum tali.7 the deformed c-sign consists of an irregular outer margin or osseous protuberance posteriorly.
the c-sign was scored as typical, deformed, or absent.
talar beak, duck-face, and humpback signs were scored as present or absent.
figure 2 c-sign (a) typical c-sign: extends from the talar dome through the coalition component of the posterior talocalcaneal joint to the sustentaculum, (b) deformed c-sign: extends from the medial area to the posterior area along the talocalcaneal joint and involves the posterior edge of the posterior talocalcaneal joint.
comparing typical c-sign, deformed c-sign shows protruding bony figure posteriorly (see the arrow) figure 3 talar beak sign: the arrow shows talar beak sign, which is outer osseous protuberance on talar neck figure 4 humpback sign: the arrow shows humpback sign, which is osseous protuberance on subtalar joint posteriorly figure 5 duck-face sign: refers to osseous protuberance of the medial talocalcaneal joint over half of the medial malleolus.
it resembles a duck beak on face three independent observers (3rd-year resident, clinical assistant professor, associate professor) evaluated the radiographs twice at a 6-week interval to determine inter- and intra-observer reliability.
these observers evaluated the secondary radiography signs listed above and coalition involved facets.
statistical analysis intra- and inter-observer agreements were calculated using cohen-kappa statistics.18 the kappa value measures agreement between pairs of observers over and above what might be expected by chance.
(k = 0 represents no agreement better than chance, k = +1 represents perfect agreement, and k = −1 represents perfect disagreement).
there are no definitions of the acceptable level of agreement, but the guidelines of svanholm et al.19 state that values of 0.75 or more represent excellent agreement, 0.5–0.75 good, and 0.5 or less poor agreement.
fisher's exact test was used for evaluation of categorical variables.
all statistical analyses were conducted using sas version 9.3 (sas institute, cary, nc, usa).
the value p < 0.05 was taken as statistically significant.
all hypothesis tests were two-sided.
results the interobserver correlation coefficients were determined for the first and second evaluations [table 1].
the interobserver reliability was excellent for the talar beak, humpback, and duck-face signs in both evaluations; the c-sign and involved facet reliabilities were good in one assessment and excellent in another.
the talar beak, humpback, and duck-face signs had excellent intraobserver reliability as did the involved facet criterion.
the means differed significantly for the c-sign (range 0.46–0.86) indicating poor-to-excellent intraobserver reliability [table 2].
table 1 interobserver reliability table 2 intraobserver reliability each secondary radiographic sign related to the facet in terms of occurrence and clinical application was assessed separately.
c-sign presented as both typical and deformed forms in the middle facet.
one observer noted its absence in 20% of cases in the first assessment and in half of the cases in the second assessment.
when c-sign occurred in the middle and posterior facets, there was better agreement among observers, with approximately half of the cases being typical and half deformed.
when the posterior facet was involved, the c-sign was mostly deformed and typical or absent in only a small number of cases.
when the middle facet was involved, the talar beak sign was found in radiography images by only one observer during the first evaluation, although it was absent in the second.
there was a greater correlation between middle and posterior facet involvement and talar beak, being present in approximately 35% of cases.
talar beak was not observed in most cases of posterior facet involvement.
when the middle facet was involved, no humpback sign was observed.
it also was not present in most cases of middle and posterior facet involvement.
when the posterior facet was involved, it was present in approximately two out of five cases.
the duck-face sign was not present when the middle facet was involved and mostly absent when the middle and posterior facets were involved but were generally present when the posterior facet was involved [table 3].
in ct or mri evaluation, the posterior facet is most frequently involved, followed by the middle and posterior facets.
the anterior facet is not involved.
the rates of involvement, based on the observations in this study, were as follows: middle facet 5%, middle and posterior facets 27%, and posterior facet 68% [table 4].
table 3 correlation with facet involvement and c-sign, talar beak, humpback sign, duck-face sign table 4 facet involvement percentage discussion according to our study, majority of cases of tc coalition were either limited to the posterior subtalar facet or appeared on both the posterior subtalar facet and middle subtalar facet.
cases in which tc coalition appeared on the middle subtalar facet, which is the most typical location, were rather small in number.
this suggests that a considerable number of tc coalitions may arise at the posterior subtalar facet.
in english literature [table 5], existing tc coalitions can be seen most clearly at the middle subtalar facet, while it is rarely seen at the posterior subtalar facet.
however, there is some controversy with regard to the affected area; taniguchi et al.4 reported that cases occurred more frequently at the posterior subtalar facet, and our study also showed that tc coalition appeared more frequently in the posterior subtalar facet, contradicting existing reports [table 5].
these results indicate that previous studies may have incorrectly assessed tc coalitions of the posterior subtalar facet as involving the middle subtalar facet because ct or mri was not used for the evaluation.
another possibility is ethnic variation, i.e., the fact that posterior facet tc coalition is more frequent in asians, based on a report by taniguchi et al.4 and the results from this study.
there were few cases with typical c-sign and talar beak at the dorsal talus in the plain radiographs seen in our study.
instead, the deformed c-sign and duck-face signs were present in a considerable number of patients.
furthermore, these two signs, especially in cases in which the tc coalition was seen at the posterior subtalar facet, were present in 74.8% and 62.7% of cases, respectively.
thus, the deformed c-sign and duck-face sign are considered to have high correlations with tc coalitions on the posterior subtalar facet.
with regard to middle facet coalitions, in our study, the c-sign was usually present as the typical form, although it was occasionally deformed.
only the c-sign was useful for diagnosis of coalitions on the middle and posterior facets.
it was present in all cases involving the middle and posterior facets in our study but was deformed in half of them.
other signs were always or almost always absent.
table 5 literature review many studies have examined the location of tc coalitions.
we reviewed english literature on tarsal coalitions published from 1983 to 2013 in pubmed.101120212223242526272829303132333435 articles mentioning coalition type and diagnostic methods were selected, as well as those that included involved facet data [table 5].
based on these reports, the coalition rates were as follows: 54.9% tc, 33.5% cn, 8.8% multiple, 1.4% naviculocuboid, 0.4% naviculocuneiform, and 0.4% talonavicular.
this review included both western and eastern countries, although majority were from the west.
these rates are close to the real-world situation, although a more accurate review is necessary.
all of the studies used radiographic images as the first approach to diagnosis, so it is important to determine the most reliable secondary signs of the involvement of different facets.
although the location of coalition is important, most articles did not focus on the involved facets, which obscured the true rate.
this study had some limitations.
first, it did not clarify the proportions of fibrous, cartilaginous, and bony types.
mri can detect fibrous types more readily than ct. second, power analysis was not performed.
although no other study has examined this, a larger sample size is better for a good outcome.
third, few talar beak, humpback, or duck-face signs were seen for middle facet coalitions, although there were few such coalitions; consequently, our findings may not reflect the actual prevalence.
fourth, although we checked consecutive patients, we included only patients undergoing ct or mri, which resulted in some selection bias.
fifth, the subjects spanned a wide range of ages, so the population was not homogeneous and this could have affected the results.
this study shows that the posterior facet has the highest prevalence of involvement in tc coalitions, and the c-sign is useful for determining all types of tc coalitions.
the typical c-sign is generally present in middle facet coalitions, whereas the deformed c-sign is prevalent in posterior facet coalitions.
humpback and talar beak signs were not very useful and were found in only a small number of cases.
the duck-face sign was found for posterior facet tc coalitions.
financial support and sponsorship this study was supported by soonchunhyang university research fund.
conflicts of interest there are no conflicts of interest.
@highlight
background: verifying the exact location of talocalcaneal (tc) coalition is important for surgery, but the complicated anatomy of the subtalar joint makes it difficult to visualize on radiographs.
no study has used computed tomography (ct) or magnetic resonance imaging (mri) to verify the radiological characteristics of tc coalition or those of different facet coalitions.
therefore, this study verified the radiological findings used to identify tc coalitions and those of different facet coalitions using ct and mri.
materials and methods: plain with/without weight bearing anteroposterior and lateral radiographs, ct, and mri of 43 feet in 39 patients with tc coalitions were reviewed retrospectively.
ct or mri was used to verify the location of the tc coalition.
secondary signs for the presence of a coalition in the anteroposterior and lateral plain radiographs, including talar beak, humpback sign, duck-face sign, and typical or deformed c-sign, were evaluated.
three independent observers evaluated the radiographs twice at 6-week intervals to determine intraobserver reliability.
they examined the radiographs for the secondary signs, listed above, and coalition involved facets.
results: the average rates from both assessments were as follows: middle facet 5%, middle and posterior facets 27%, and posterior facet 68%.
the deformed c-sign is more prevalent in posterior facet coalitions.
the posterior facet has the highest prevalence of involvement in tc coalitions, and the deformed c-sign and duck-face sign have high correlations with tc coalitions in the posterior subtalar facet.
conclusion: a posterior facet is the most prevalent for tc coalition, and the c-sign is useful for determining all types of tc coalition.
