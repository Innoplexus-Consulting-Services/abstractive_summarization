introduction in india, dialysis is the more common mode of renal replacement therapy.
however, a majority of patients withdraw from dialysis within 3 months, because it is not a cure, has to be continued for life, and is financially draining.
[1] that transplantation is the preferred renal replacement therapy has been borne out by observation and research.
[2] the disproportion between the demand and supply of kidneys for transplantation has stimulated discussion among the transplant community in an attempt to explore newer alternatives to bridge this gap, bringing to the fore ethical and controversial issues.
international literature has focused on the attitude of medical personnel toward relevant ethics-related and controversial issues in transplantation, such as incentives to donors/donor families,[345] kidney vending,[6] compulsory organ donation after death,[7] and the allocation of scarce resources if the outcome is anticipated to be marginally positive.
[8] in the indian context, there has been research conducted on knowledge and attitude of healthcare workers toward organ donation,[910] but these researches have not addressed controversial issues in transplantation.
one study[11] found that family physicians in mumbai feared that rich people would get priority for transplantation, echoing the sentiments expressed by the nephrologists in ghahramani et al.‘s study,[5] where exploitation of the poor was a concern.
in addition, two-third of the nephrologists were in favor of making kidney donation compulsory as it would save lives, the latter point being reiterated by epstein.
[12] the dearth of indian research regarding the attitude of medical professionals toward controversial issues related to kidney transplantation served as an impetus for the current study.
methods one hundred and eighty doctors were initially contacted, via the method of convenience sampling, to respond to a questionnaire, which had been previously pilot-tested on 20 doctors.
the face-to-face questionnaire, formulated in english, which presented 8 controversial issues related to kidney donation/transplantation, to be answered in an agree/disagree format with supporting reasons (open-ended), was filled in by these doctors.
the statements tapped the issues such as incentives to live donors, eligibility of recipients with medical problems, priority of kidney allocation to previous donors, autonomy for organ donation irrespective of cost to self, priority based on higher socioeconomic status, legalization of kidney selling, compulsory possession of a donor card and compulsory kidney donation after death.
identification data were elicited, namely name (initials only) age, sex, religion, education and employment.
the research was exploratory and the data were analyzed both quantitatively and qualitatively (theme extraction).
results of the 180 doctors contacted, 26 declined to participate in the research due to time constraints and 14 who participated in the research, but submitted incomplete questionnaires, were excluded.
the final sample consisted of 140 doctors (males = 44.3%, females = 55.7%) from mumbai representing a wide age group, namely 21–80 years (mean = 38.09, standard deviation ± 17.95) and three major religions, namely hinduism (69.3%), islam (21.4%), and christianity (9.3%).
the doctors were interns, residents, or family physicians.
of the 140 participants, 18 worked in a government hospital, 45 in a private hospital, and 77 in a private clinic.
their work experience ranged from 1 year to 58 years.
the responses to the controversial issues are indicated below live donors should be given incentives for donating their kidney some (47.1%) agreed with this statement and advanced the reason that incentives served as an impetus for others to donate (27.9%).
a few indicated that donors from the lower class would obtain a much needed monetary benefit (5.7%) and that there was a need to reward donors as they were sacrificing an important organ (5%).
quite a few of those not in favor of live donors being given incentives (52.9%) either feared that this would lead to commercialization/illegal activities/malpractice (23.6%) or believed that donation was a philanthropic act and that there should be no expectation of any kind of incentive (22.1%).
those with medical ailments, such as hiv/hepatitis, should not be considered eligible to receive a transplant some (52.9%) agreed with this statement.
varied reasons were given for the same, namely lesser life expectancy (17.9%), low transplantation success (11.4%), risk of infection to others (6.4%), and preference to be given to healthier individuals (3.6%).
of those who disagreed with the statement (47.1%), some championed the right of these individuals to a transplant (17.9%), others felt that the overall poorer health status should be the determining factor for transplantation (8.6%) whereas a few (3.6%) were optimistic that despite their medical conditions, the outcome for these patients would be successful.
those who have been donors should be given priority if they are in need of an organ in the future a substantial majority (90.7%) agreed with the statement, citing reasons of the need to reward and recognize selfless and humane acts (47.1%), to motivate others to donate (12.1%), and to bring satisfaction to the donor.
(3.6%).
those who disagreed (9.3%) maintained that it was unfair/unjust to give preferential treatment to those who have donated a kidney (2.9%) and that priority should be given to those who have an urgent medical condition (2.9%).
an individual should be permitted to donate if he/she chooses, irrespective of consequences to self more were not in favor of the same (61.6%) and strongly believed that individuals should be discouraged from donating if they are not medically healthy (21.4%), if they are putting their own life at risk (17.1%), or if they have not made an informed decision (10%).
those in favor (38.4%) argued that everyone has a free will to donate (23.6%) and that donation helps to save lives (2.1%).
individuals who belong to the higher socioeconomic strata should be given preference for kidney transplantation a majority (91.4%) were against this idea, with quite a few (63.9%) contending that the value of life was the same for all individuals and as such there should be no discrimination/disparity among them.
others not in favor believed that preference should be assigned according to medical urgency (15.7%) or possible outcomes (2.1%).
a few (5%) were of the opinion that the preference, in fact, should be given to the lower class as they could not afford an organ.
the few (8.6%), in favor of individuals belonging to the higher socioeconomic strata getting a preference for a kidney transplant, pointed out to the assets of the higher socioeconomic class, namely their financial reserves which enabled them to afford a transplant and spend on needed medication.
kidney selling should be legalized most were not in favor (77.1%) of kidney selling being legalized fearing that this would lead to commercialization (11.4%) or worse still corruption, black marketeering, and criminal activities (41.4%).
a few were apprehensive that the poor would be disadvantaged because of the nonaffordability of a kidney (7.1%) or victimized on account of being coerced into selling their kidneys (5.2%).
those supporting the legalization of kidney selling (22.9%) felt that this practice would make available more kidneys to save lives (7.9%) and that it would curb malpractice/illegal activities (6.4%).
a few, however, cautioned that kidney selling should be conducted under strict government rules and regulations (5%).
possession of a donor card should be made compulsory in institutions of education/employment those who agreed (56.4%) with the statement advanced reasons, namely facilitating the registration and identification of donors (10.7%), increasing awareness of transplantation (8.6%), and making more donors available (7.1%).
of those who disagreed (43.6%), most argued that donation should be voluntary and that it was an individual's choice to sign or not sign the donor card (33.6%).
kidney donation should not be made compulsory after death a substantial number of those who agreed (55.7%) with this statement contended that it is an individual's choice to donate and that it is unethical to coerce anyone into donating (44.3%).
moreover, a few were of the opinion that choices and wishes of family members should be respected (8.6%).
of those who disagreed (44.3%), quite a few believed that making kidney donation compulsory after death could help save the lives of individuals (26.4%) and a few felt that this would reduce the kidney deficit by making more donors available (9.3%).
discussion in the current study, about 60% of the respondents who agreed that live donors should be given incentives for donating their kidney felt that these incentives would lead to increased donation.
in ghahramani et al.‘s study,[5] 66% of the nephrologists agreed with this view.
rather than direct payment, other avenues of compensation have been spelt out by various researchers, such as medical leave and special donor insurance,[13] subsidized education, health, and other benefits.
[14] the quantum of incentives should not lead to commercialization/malpractice, a fear expressed by approximately a quarter of the respondents in the current study.
in tong et al.‘s[3] comprehensive study on transplant nephrologists and surgeons from 12 countries, what emerged was that removal of disincentives for living kidney donors was largely deemed acceptable.
however, provision of financial rewards raised concerns about working against the principles of benevolence and violating human dignity.
that altruistic donation need not be rewarded was indeed a sentiment also expressed by about one-fifth of the respondents in the current study.
patients with medical ailments such as hiv/hepatitis were considered ineligible for a transplant by half of the respondents, as transplantation success was anticipated to be low.
similarly, in mazlan and engkasan's study,[8] more than two-thirds of rehabilitation doctors would not allocate scarce rehabilitation resources if the functional outcome was marginally positive.
indeed, gaston et al.
[15] proposed that patients who developed contraindications to transplantation be removed from the list and not kept for reasons of compassion.
those who championed the cause of these patients with hiv/hepatitis felt that they should not be discriminated against.
olbrisch[16] also questions whether those with comorbidities cannot be made suitable for transplantation by appropriate treatment, an opinion also shared by gaston et al.,[15] who maintained that those on remedial contraindication should be kept on hold and not ruled out for transplantation.
that previous organ donors should be recognized and rewarded by a priority organ allocation was the view maintained by a substantial majority of respondents in the current study, who felt that there was a need to reward selfless/humane acts.
this finding is supported by other researchers.
[15] the few in the current study who disagreed, maintained that it was unjust and unfair to give previous donors priority which, in fact, should be given to those with an urgent medical condition.
quite a few of the respondents in the current study felt that individuals should be discouraged from donating if they are not medically healthy/at risk of developing problems, a view, however, not supported by some of the other respondents who were in favor of individuals having a free will to donate.
olbourne[17] maintains that ethical grounds are weak in denying an individual the right to dispose of a kidney in any way he/she seems fit, as long as the informed consent process for the donor is rigorous.
in india, due to lack of awareness about organ donation, individuals should be made completely aware about the benefits and risks of donation, before consenting to the same.
shrestha[18] comments about the power gradient between recipient and donor, such as from poor to rich which counteracts the principles of justice, autonomy, and sanctity of life.
a substantial majority of respondents in the current study were also against transplantation preference being given to individuals belonging to the higher socioeconomic strata as they felt that all individuals should have equal rights.
the few who were in favor of richer individuals getting a preference for a kidney transplant, pointed out to the advantages accruing from their financial assets.
indeed, ramachandran and jha[19] question the validity of transplantation for patients in india who belong to the lower socioeconomic strata as expenses associated with transplantation can drive individuals into the grips of poverty.
most were not in favor of kidney selling becoming legalized because of the fear of commercialization and criminal activities, a finding supported by piccoli et al.
[6] epstein,[12] on the other hand, felt that the cons of kidney selling were weak and highlights the points in favor, such as it is morally wrong to let people die when they are so many organs that can be harvested, the market would adhere to regulations for the protection of recipients and both donor and recipient will have equal benefits.
cohen[20] suggests that individuals should sign contracts to sell organs after death as this proposal would not exploit the poor as it is limited to cadaveric organs and it will not favor the rich because all harvested organs would be done by a government/voluntary agency.
interestingly, those against kidney selling becoming legalized voiced fears of commercialization and criminalization while some of those favoring kidney selling cautioned that it should be conducted under strict government rules and regulations.
thus, transparency and accountability should be paramount in the event of kidney selling becoming legalized.
some were against the possession of a donor card being made compulsory in institutions of education/employment as they felt that it was an individual's choice to sign or not sign the donor card.
a study[21] revealed that though the vast majority of the intensive care personnel supported organ donation, less than half of the respondents had an organ donor card.
finally, just over half of the respondents were against kidney donation being made compulsory after death as they were against coercion.
the findings of a research[7] indicated that the majority of physicians in the study disagreed with the idea of using organs from a dead person who had a negative opinion toward organ donation.
conclusion there is indeed a dire need of kidneys and it becomes practical and logical to suggest different alternatives for rectifying this problem.
this study can benefit transplant healthcare personnel in that they can embark on the first step toward developing newer and more relevant policies and strategies for kidney donation/transplantation, based on the opinion of these medical professionals.
platforms where these issues can be further and more comprehensively addressed and deliberated upon, not only in india but also globally, is the need of the hour.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
there is a dire need to evaluate new strategies to bridge the wide kidney demand–supply gap.
the current study examined the attitude of medical professionals regarding controversial issues pertaining to transplantation.
a questionnaire, presenting controversial issues related to kidney transplantation, in an agree–disagree format with supporting reasons, was employed.
the research was exploratory.
data were analyzed quantitatively and qualitatively.
the sample comprised 140 doctors from mumbai (mean = 38.1 years, standard deviation = 17.95; males = 44.3%, females = 55.7%).
whereas 47.1% of the participants felt that live donors should be given incentives for kidney donation, others (52.9%) disagreed, fearing commercialization and illegal activities.
the eligibility of patients with hiv/hepatitis for a transplant was denied by 52.9% because of poor outcomes, with the others (47.1%) maintaining that these individuals too had a right to live.
a substantial majority (90.7%) of the participants maintained that organ donors should be given priority in the event of a future need for an organ because their previous humane act should be rewarded (47.1%).
most of the participants (91.4%) felt that individuals from the higher socioeconomic strata should not receive preference for kidney transplantation.
a majority (77.1%) of them were also against kidney selling getting legalized.
compulsory possession of a donor card elicited mixed responses, with some accepting (56.4%), but others rejecting (43.6%) this idea as donation was perceived to be a voluntary act (33.6%).
while compulsory kidney donation found favor with 44.3%, it found disfavor with others (55.7%).
this study will benefit transplant healthcare personnel to formulate new policies in relation to kidney donation/transplantation.
