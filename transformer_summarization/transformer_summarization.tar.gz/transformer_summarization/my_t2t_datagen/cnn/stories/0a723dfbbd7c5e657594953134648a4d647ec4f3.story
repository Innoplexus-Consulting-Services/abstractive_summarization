1. introduction and related work 1.1. sna and email networks social network analysis (sna) has received growing attention on different areas.
sna aims to obtain relational data from social systems to identify leaders, roles, and communities in order to model profiles or predict a specific behavior in users’ network.
sna is built-in with nodes (individuals or organizations) within the network and ties representing relationships among the nodes.
social relationships may be in the form of real world offline social networks (like friendship, communications, transactions, etc.)
or it may be online social networks (like facebook, twitter, etc.).
sna has been applied in information science [1], financial crimes [2], political science [3], sociological studies [4], biology [5], economics [6], and intelligence analysis [7].
with regard to the properties and structures on the network, sna has been applied to study the structure of internet graph topologies [8], telecommunication graphs [9], emails and social networks [10,11,12].
analysis of incomplete social networks where some nodes or edges are missing and only a sample of them is available is a field studied in [13,14].
a particular issue in this field is link prediction where, given some information about present nodes and links, the challenge is to fill or predict missing links in the network.
see [15,16] for two surveys on link prediction.
the main contribution of this article is focused on email networks, as a subdomain of social networks.
studies of email networks cover spam analysis [14,17,18], virality studies [12], community characteristics [10], structure and properties analysis [8,12], and studies on the temporal evolution of email data [19].
1.2. privacy in communication networks social networks, and in particular email networks, need to be anonymized in order to preserve privacy of actors.
anonymity can be compromised by disclosing senders’ or receivers’ identity, message content, or sender-receiver relationships.
anonymity systems provide mechanisms to enhance user privacy and to protect computer systems.
research in this area focuses on developing, analyzing, and executing anonymous communication networks attacks and defenses.
mixes [20] are considered the base for building high latency anonymous communication systems.
a mix network aims to hide the correspondences between the items in its input and those in its output, changing the incoming packets’ appearance through cryptographic operations.
babel [21], mixmaster [22], mixminion [23], and onion routing [24] are other anonymous communication designs.
the attacks against mix systems aim to reduce the anonymity by linking senders with the messages that they send, receivers with the messages that they receive or linking senders with receivers.
there are intersection attacks based on traffic analysis.
one of the first models to appear was called the disclosure attack [25].
in this first version the disclosure of links between users of a network was limited to relationships of one specific user with the rest of users in the domain, under an optimization approach.
using the restrictive assumptions set in [25], the statistical disclosure attack (sda) was presented in [26].
in this attack, the information retrieved by the attacker is obtained through several rounds of communications, and statistical methods are employed to infer links between users.
other forms and derivations of the statistical disclosure attack are presented in works [27,28,29,30].
in [31,32] a new statistical disclosure attack is presented that overcomes the restrictions usually considered in other methods and can be used under very general assumptions.
this article addresses the research problem of obtaining global and node characteristics of an anonymized email network through the application of a statistical disclosure attack.
the techniques developed in [31,32] are used to infer email network characteristics under strongly incomplete information.
it is shown that the attack can lead to obtain moderately accurate estimators for measures such as average degree, power law coefficient, betweenness coefficient or small-world-ness coefficient.
these estimations can be used to study temporal evolution of the network, identifying substantial changes over time, compare different networks, or identify important users or clusters of users.
the database used, that comprises many networks, allows study of the scope and limitations of the method under a broad statistical perspective, observing patterns, error rates, and possible biases in the estimations.
this is a novelty, since there is not previous statistical disclosure attack (sda) research on estimating global network characteristics or node based measures; generally sda existing research focuses on a limited number of users and establishes very restricted hypotheses about a priori knowledge of the network or users behavior.
most often analysis of email networks are restricted to only one email network; studies that treat many networks usually consider besides email data, social network data, patents data, etc.
when characteristics of email networks such as small-world-ness coefficient, density or degree distribution parameter are studied for only one network, it is difficult to obtain information about the real range and variability of these parameter values.
in this context, statistical variability between different small email networks can only be estimated from an ‘article to article’ perspective.
parameter variability can then be due to the different sources.
there could be also a bias due to it being easier to publish papers that agree with the range of parameters in previous literature.
in this case, variability could be underestimated.
also, with only one network, relationships between parameters cannot be studied.
in this article, there is not one, but a range of small email networks, each one collected at a different faculty in the same university.
it allows not only to study if the parameter behavior agree with previous research but also to study the range and variability of parameters, as well as relationships between them.
this is an important novelty with respect to previous research on email network data.
the rest of the article is structured as follows: section 2 presents structural properties and measures of social networks, focusing on the particular case of email networks and their scale free or small-world characteristics.
a new email database of 29 email local university networks is introduced to explore the consistency of theory.
section 3 presents the problem of retrieving network characteristics under the situation of strongly incomplete information.
a statistical disclosure attack method is used to estimate the network and node measures.
the method is applied to the university email database in order to study its performance.
section 4 provides conclusions and future work.
2. social networks and email network properties: email database the most significant structural properties of social networks are first introduced.
social networks can be directed or undirected, weighted or unweighted.
an email network can be set as directed and weighted; for simplicity, some characteristics can be computed as for an undirected and/or unweighted network.
measures of interest of a network can be divided into node centered measures and global measures.
at node level the most important measures are: degree: the centrality degree of a node is the number of users or nodes that are directly related to it.
two nodes of a graph are adjacent or neighbors if there is a branch that connects them.
in the case of directed graphs, there are two types of degrees: the input degree of a node is the number of arcs that end in it.
the output degree of a node is the number of arcs that originate from it.betweenness centrality measure: it is equal to the number of shortest paths from all vertices to all others that pass through that node.
the computation of shortest paths in a network algorithms such as floyd-warshall or johnson’s.
a node with high betweenness centrality has a large influence on the transfer of items-messages through the network.clustering coefficient: it is a metric that measures the extent to which the neighbors of a node are also interconnected.
here the watts and strogatz ([33]) local clustering coefficient is used.
the clustering coefficient of a node v is defined as (1)cv=2evkv(kv−1) where, kv denotes the number of neighbors of v, kv(kv−1)2 the maximum number of edges that can exist between the neighbors, and ev the number of the edges that actually exist.closeness: the degree of closeness is the ability of a node to reach all others in the network.
a node is important if it is close to all others.
the sum of the shortest path distance from the node ni to all the others is computed.
the inverse of this sum is the closeness coefficient of node ni: (2)cc(ni)=[∑j=1gd(ni,nj)]−1 where d(ni,nj) is the shortest path distance between nodes i and j. while betweenness coefficient measures the role of the node ni as a bridge between nodes, a normalized closeness coefficient (the coefficient above multiplied by the number of nodes n − 1) may be seen as the inverse of the average shortest path distance between the node ni and all the nodes connected to ni.
at network level, the most important measures are: degree distribution: the degree distribution p(k) of a network is the fraction of nodes in the network with degree k. in a power law distribution, the fraction of nodes with degree k is p(k) ∝ k − α where α is a constant exponent.
networks characterized by such degree distribution are called scale-free networks.
many real networks such as the internet topology [8], the web [9] and on-line social networks [10] are often scale free.
average path length: in small-world networks, any two nodes in the network are likely to be connected through a short sequence of intermediate nodes, and the network diameter shrinks as the network grows [19].average clustering coefficient of a network: the average clustering coefficient of a social network shows to what extent friends of a person are also friends with each other [33].density: the density d of a network is defined as a ratio of the number of edges e to the number of possible edges, given by (3)d=2en(n−1) where n is the number of nodes in undirected graph, and d=en(n−1) in directed graphs.small-world-ness coefficient: the concept of “small-world-ness” as a property is exposed in [33], and characterizes networks with a high clustering coefficient (meaning by “high” as much higher than its equivalent in a random erdos-renyi network) and mean shortest path length similar to its equivalent in a random erdos-renyi network.
email users tend to form groups and the average shortest distance is small, leading to the small-world property.
in [34], a coefficient for measuring the small-world-ness of a network is presented and used as reference in this work.
this small-world-ness coefficient is expressed as the ratio between γg and λg, where γg is the ratio between the average clustering network coefficient and the clustering coefficient of the network under the equivalent random erdos-renyi network, and λg is the ratio between the average shortest path length of the network and the average shortest path length of the equivalent random erdos-renyi network.
the behavior of email networks have been generally claimed to be scale free, that is, the degree distribution follows a power law distribution.
see for example [12,19,35].
the scale free nature of email data implies that a few ranges of nodes have high degrees (many friends) while many nodes have small degrees.
in order to assess the scale free model for the degree distribution, log-log graphs or estimation of the power constant followed by a goodness of fit test are used.
in this article, the goodness of fit method, through the use of a kolmogorov smirnov statistic, is applied.
there are several email network studies in the literature.
in [35], scale-free and small-world properties of an email network at kiel university are studied.
the enron email database structure is studied in [18].
in [17], an email network from national taiwan university is analyzed to study the temporal evolution of the email network of an eu research institution.
in [19], we also see a focus on the temporal evolution of a large us university email network.
the email database used in this study is a group of 29 independent email networks from madrid complutense university.
this is the same as used in [32].
each network is related to a university faculty, and contains anonymized emails retrieved over one year between users of the department.
institutional emails, and emails going out of the faculty network or coming from outside from the faculty are not considered.
only time of sending and senders’ and receivers’ anonymized id are kept.
the textual content of email and headers are deleted.
studies on email network data may restrict the problem to a closed domain (considering only messages sent and received within a domain) or be open in the sense that messages outgoing from the domain and received from outside are also considered.
most studies (see for example [18,19,35,36]) belong to the first category; others also consider out-domain emails ([19]).
most studies come from university or research institution servers.
our study follows the norm; each network is restricted to the closed domain and data comes from a university server.
the contribution here is that there are many separate similar networks (one per faculty), allowing for studying patterns and contrast previous research on this kind of data from a broader statistical view.
for simplicity and in order to avoid ambiguity, graph construction follows [16,19], creating an undirected and unweighted graph.
table 1 presents the main measures of the 29 faculty networks.
the smallest network has only 8 nodes and 23 edges, and the biggest has 622 nodes and 8839 edges.
the average degree goes from 2.88 to 14.5. a 96% of the networks have an average degree > 4, in concordance with previous research on small-world networks, that reveals that the average degree is higher than 4. the average betweenness is in the range of (4.71, 2865).
it is shown in [34,37] that as density increases clustering coefficient increases and mean shortest path length approaches the equivalent random erdos-renyi network mean shortest path length.
thus high density networks would be trivially small-world under the ws concept.
it is advisable that small-world behavior and coefficients should take into consideration the density concept for comparisons between networks.
as [37] remarks, density should be lower than 0.4 in order to consider small-world-ness properties without the confounding effect of high density.
here the density range is very low, 80% of the networks show a density coefficient lower than 0.10, laying in the range of the other email networks studied in the literature.
in figure 1, the relationship between nodes and edges is represented.
when transforming to log scale the relation is approximately linear, almost proportional, showing that (4)log(edges)∝k×log(nodes) that is edges=nodesk.
with the data presented here, k can be estimated by regression without intercept, giving k = 11.14, with regression r2 = 0.85. scale free behavior of the networks is evident.
a kolmogorov smirnov test using bootstrap data presented in [38], is applied in order to check if the degree distribution in each network follows a power distribution.
the null hypotheses of power distribution is only rejected for networks 11, 15, 22 and 27. the other 25 networks fit well to a power distribution, that is, p(k)=k−∝.
the estimation of ∝ is achieved through maximum likelihood, following [38].
the estimate range is (1.43, 2.1).
these values are similar to those found in [19], where data is limited to internal nodes of the closed network.
figure 2 and table 2 show the degree distribution in log scale for faculty 6, and how it fits to a line.
small-world behavior small-world networks are characterized by a high cluster coefficient cg with respect to the equivalent random erdos-renyi network coefficient cr, and similar path length lg to the equivalent random erdos-renyi network lr.
gamma and lambda values measure the quotients between each pair of coefficients.
if the email networks considered here are small-world networks, it is to expect lambda values near 1 and high gamma values.
in [34] a small-world-ness coefficient is presented constructed as the quotient between gamma and lambda values.
a network can be considered small-world if this coefficient is higher than 2, what happens in 27 of the 29 faculties.
in [34] it is pointed out that there is a linear relationship between small-world-ness coefficient and number of nodes.
figure 3a illustrates this fact.
also, it can be seen in table 3 and figure 3a that the faculties with smallest small-world-ness coefficient are those with less nodes, and it suggests that their small coefficient is due overall to their size and not to their structure in terms of shortest path and clustering.
figure 3b allows also to detect in this case the network 22, which has an unusual behavior (higher lg than expected).
this network is also the one with highest shortest path, clustering coefficient, and small-world-ness coefficient.
figure 3c shows that mean shortest path and clustering coefficient have a special relationship.
this seems to be increasing until a certain clustering coefficient and then decreasing when number of nodes is small and clustering coefficient is higher.
it is possible that the clustering coefficient cg has a special behavior when the number of nodes is too small.
the regression slope (with case 22 deleted) for cg < 0.35 is positive, b = 1.55 while the regression slope for cg > 0.35 is negative, b = −4.29.
previous results on this relationship have not been found in literature.
faculty 22 is a special case (outlier), as it has been clear in other figures and tables.
other characteristics are proportional to the number of nodes.
figure 3b shows that (5)lg∝k×log(nodes) 3. estimation of email network characteristics through statistical disclosure attacks privacy in communication networks can be compromised by statistical disclosure attacks.
in this section it is shown how the method developed in [31,32] can be used to disclose user relationships (that is, existing and non-existing edges) in the network structure.
departing from very limited information, edges are inferred and users’ centrality measures and network global measures are estimated.
this allows to detect high centrality nodes and characteristics of the network and establish the basis for studying network evolution with respect to global measures such as density, average degree, or average betweenness, and also node-based measures, when the attack is repeated at different time points.
the framework is habitual in statistical disclosure attacks in network communications: the information retrieved by the attacker is the number of messages sent and received by each user.
this information is obtained in rounds that can be determined by equal length intervals of time, or alternatively by equal-sized batches of messages.
method is restricted, at this moment, to simple mix, where messages are grouped in batches at each round and then anonymously relayed, but can easily be extended to random threshold, where the batch size can be random, or pool mixes, where some messages are randomly selected and not relayed in each round.
no restriction is made from before about the number of friends any user has, or about the distribution of messages sent.
both are considered unknown.
attacker controls all users in the system.
in our real data application, we aim at all email users of each network domain.
in each round, the attacker obtains a contingency table that represents messages sent from each user (rows) to each receiver (columns).
marginal row and column totals are known, and they represent the total number of messages sent and received by each user.
however, the attacker does not know the pair (sender-receiver) for each message.
table 4 represents a simplified version of one of these tables, retrieved in one round.
there are many solutions for filling the table elements, that sum up to the marginals.
optimization algorithms (branch and bound) are generally slow and result in a very limited range of solutions.
a very fast algorithm based on iterative random generation is used in [31] in order to obtain a large number of solutions (if not all) for each round.
this information is used to order pairs of users from highest to lowest probability of relationship and finally obtain a classification result that aims to detect if one pair of users have had communication.
in [32], a refinement of the method based on the use of the em (expectation-maximization) algorithm that significantly improves the relationship predictions, is used.
in the network paradigm, the objective is to reconstruct the global network in the horizon of study, where nodes represent users and edges represent existing communication between pairs of users.
the information employed to estimate the whole network is the incomplete information obtained in each round that can be seen itself as corresponding to a partial network with incomplete information.
the method leads to a final estimated network with its own measures and characteristics, that can be used as estimates of the real network measures.
besides, each user’s centrality measures can also be estimated.
as it was explained in [31,32], the performance of the attack is affected by the following aspects: (1)the number of nodes.
as the number of nodes increases, the complexity of round tables and the number of feasible tables increases, so that it negatively affects the performance of the attack.
(2)the percentage of existing edges over possible edges.
as communication increases (more edges), the attack precision decreases.
(3)the mean frequency of messages per round (sum of weights in the round associated weighted network): this is directly related to the batch size, and when it increases, the performance is negatively affected.
(4)the number of rounds: as the number of rounds increases, this improves the performance of the attack, since more information is available.
(5)the number of feasible tables generated by round: this affects computing time, and it is necessary to study to what extent it is useful to obtain too many tables.
this number can be variable.
usually once a high number of tables is generated (about 300,000 tables per round in our proofs), there is no gain in generating more tables.
the problem of estimating network characteristics departing from network incomplete data is often addressed in scientific literature under the subtitle ‘link prediction’.
personal information about individuals is generally used to predict relationships.
there are seldom studies where only structural information is used.
an exception is [13], where network characteristics are estimated in networks where only some nodes and links are known.
it is a different context than the one addressed here, where all links are unknown and information is obtained in a multiple round framework.
the data presented in section 2 allows us to study the precision and behavior of the attack when estimating users and network measures.
since there are 29 networks, homogeneous to some extent, estimators sensitivity to scale (number of edges) and other factors can also be observed.
for each of the faculty domains, construction of the attack follows the pattern below: (1)structure data in rounds.
messages are ordered by time and grouped by batch size b, forming rounds (each group of b messages is a round, that leads to a table similar to table 4).
in a real situation, this is the information the attacker is able to obtain.
(2)develop the version of the attack algorithm presented in [32] and obtain an estimate of the adjacency matrix of the network; that is, an estimate of the whole network.
(3)compute node centrality measures and network characteristics for the estimated network.
in order to develop this pattern a batch size needs to be decided on, as do the number of generated tables for each round, and number of iterations of the em algorithm.
here a batch size of 15 is used, 500,000 tables per round are generated, and 5 em iterations are developed.
centrality measures are computed for each node of each faculty network.
estimation error increases with size: error in degree or betweenness estimation is higher for nodes with higher degree or betweenness.
figure 4 represents the relationship between estimates of betweenness and node degree and their relative true values.
in general, estimates are within the expected range.
there is a slight but clear bias in both estimations: node degrees are slightly overestimated by the attack estimates, whereas betweenness is slightly underestimated.
uncertainty in round tables leads to the overestimation of edges (relationships) in the network and this has as a consequence higher degree values.
figure 5 represents graphically the relationships between estimates and the true global values, for number of edges, average degree, and average betweenness.
a line y = x is also represented to study possible biases.
some observations can be made: estimation error, as it was expected, increases generally with network size (number of nodes).number of edges for each network is slightly overestimated.average degree is slightly overestimated, in concordance with user degree estimations.average betweenness is slightly underestimated.
with respect to scale free behavior, the estimates of the power distribution parameter are slightly overestimated but within the true range, as is illustrated in figure 6a.
small-world characteristics are also estimated.
figure 6b–d present the relationship between the estimates and respective true values for lg, cg, and small-world coefficient.
mean shortest path lg is slightly underestimated, whereas cg and small-world-ness coefficient are slightly overestimated for large networks.
with respect to the cutpoint of 2 for a small-world-ness coefficient, the estimator declares as small-world the same networks as the true value.
as it has been observed, estimation have often some bias.
however, this bias is not so high and overall estimation error is accurate to a certain extent.
it is known that the mean squared error (mse) of an estimator can be decomposed in two quantities: (6)mse=bias2(est)+var(est) if both values are low in terms of the scale of the estimated quantity, the estimator is considered accurate.
in table 5 mean bias is computed for each network and parameter, as the mean of differences between the estimate and true value.
also, mean absolute error (mae) and cv are computed, cv representing mae in percent over the mean value of the quantity estimated.
estimation has much higher error at node level.
at network level, estimators are satisfactory in general, within a controlled range of the quantity of interest.
it is necessary to remark the limitations of the information used (all links are unknown a priori).
at the network level, small-world-ness coefficient has the highest error in percent.
as it was pointed out, batch size significantly affects the performance of the attack.
the attacker is limited to the number of times he can access information in batches.
figure 7 shows how the error in estimating the number of edges increases with batch size for all the faculties.
as the number of edges is linearly or log-linearly related to most of the network measures, this has a direct consequence on the estimators’ errors.
4. conclusions email networks are a particular case of interest in the field of social networks.
although these networks can share some characteristics with other social net systems, they have specific behaviors.
in this work, a group of email networks with small size and low density are treated.
it is usual in literature to mix network of different types in the same analysis, and sometimes the relationships between characteristics studied can be masked.
with the data used in this article, homogeneity makes the findings about found relationships and characteristics more reliable.
while most of them are already known it is interesting to observe them in a controlled context.
some observed findings are: exponential relationship between edges and nodes, scale free behavior of almost all the email networks, small-world-ness behavior of almost all the email networks, linear relationship between small-world-ness and number of nodes, and linear relationship between shortest path and number of nodes.
compromising the privacy of network communications is the aim of statistical disclosure attacks.
attacks can be developed to address information at multiple levels.
in previous work, the aim of attack was to obtain diagnostics for relationships between each pair of users, detect communications, and classify each pair of users as linked or not.
this work aims to obtain global characteristics of each node (centrality measures) that can be defined as a second level of privacy, and global characteristics of the network, as a third level of privacy.
the utility of obtaining these measures can be exploited in two aspects: static information about special groups of nodes or comparing networks in different but homogeneous domains, and dynamic successive estimations over time.
characteristic measures of nodes and global network measures can be estimated at different points of time and will serve to study evolutions of nodes or networks.
accuracy of the estimations is moderate, with some controlled bias in some measures.
estimators of the user characteristics have a higher error.
in general, the range of estimations is similar to the objective range and results are considered encouraging due to the very limited information used.
the attack is very affected by the batch size used; as batch size increases, accuracy decreases.
the method used here in order to disclose and estimate network characteristics under very limited information may be improved if further information is available.
if, for example, some links are already known, this information can be incorporated under the bayesian paradigm to the basic algorithm results in order to refine estimations.
the same approach could be used if one or more rounds are completely known in advance.
this added information can also be used to apply bias correction to estimates that are slightly biased, such as average between and average degree estimates.
even if there is no more information available, there is still space for improvement.
there are other statistical disclosure methods such as the least squares method ([39]) that can be combined with the algorithm adopted here in order to refine results and correct biased estimates.
also, studying the network evolution over time may help to understand the estimation of network characteristics.
finally, the disclosure attack used here should be extended to more complex anonymous systems such as onion routing.
@highlight
social network analysis aims to obtain relational data from social systems to identify leaders, roles, and communities in order to model profiles or predict a specific behavior in users’ network.
preserving anonymity in social networks is a subject of major concern.
anonymity can be compromised by disclosing senders’ or receivers’ identity, message content, or sender-receiver relationships.
under strongly incomplete information, a statistical disclosure attack is used to estimate the network and node characteristics such as centrality and clustering measures, degree distribution, and small-world-ness.
a database of email networks in 29 university faculties is used to study the method.
a research on the small-world-ness and power law characteristics of these email networks is also developed, helping to understand the behavior of small email networks.
