introduction paraplegic flexion contracture of the hip is not a very rare entity.
congenital, traumatic or extrinsic causes can lead to paraplegia; some of these are potentially reversible and others are not.
paraplegia can cause hip flexion contracture and consequently, pressure sores, scoliosis, and hyperlordosis.
scientific literature contains many studies about children with hip flexion related to neurological diseases, mainly caused by cerebral palsy; only few papers focus on this complication in adults.1 in this study, we report our experience on surgical treatment of a 20-year-old female with paraplegic fixed flexion deformity of both hip joints of 15 years duration secondary to an irrecoverable spinal cord disease, with complete motor and sensory loss and multiple pressure sores.
case report a 20 year old college going female student was admitted in our institution with a gradual onset of longstanding flexion deformity of 120° of both hip joints.
she was paraplegic for last 15 years due to irrecoverable spinal cord disease with complete motor and sensory loss.
the patient had grade zero power in both her lower limbs with complete anesthesia of both the lower limbs.
she was unable to sit and lie on her back, slept on her legs [figure 1a].
she wanted to sit straight and lie on her back.
she had multiple pressure sores in her body.
the pressure sores were mainly on the weight bearing areas, which included the knees and the lateral part of the upper thigh in this case.
grade two pressure sores were present.
the knee joint was flail with a full passive range of motion.
the patient underwent bilateral proximal femoral resection [figure 1b (a)].
we did not encounter any difficulties intraoperatively and postoperatively whatsoever.
we also did not encounter any complications in the postoperative period.
femur was ressected and shortened till the hips were straight.
figure 1a clinical photographs showing (a) patient cannot lie on her back (b) patient rests on her chest and elbow (c) pressure sores at the back of knee (d) patient is unable to lie on her back figure 1b clinical photograph (a) x-ray pelvis with both hips and pelvis after surgery showing proximal femoral resection (b) clinical photograph immediate postoperative showing patient lying supine (c) clinical photograph showing comfortable wheelchair life (d) clinical photograph showing sitting balance restored the resection was done adequately through posterior approach without anesthesia.
both the hips were done in one sitting alternatively in right and left lateral positions.
the resection was approximately about 4 inches on the both sides, which was assessed intraoperatively till the deformity was corrected.
in postoperative period, no splints or plaster was used, and the patient was immediately put on her back and in wheelchair after removal of stitches that is, 2 weeks [figure 1b (b-c).
in short time, she started sitting on her buttocks, led a comfortable wheelchair life with a sitting balance [figure 1b (d)].
there was no recurrence of flexion deformity in either hip up at 6 weeks, 3 months, 6 months, 1 year, 2 years, and 3 years followup.
discussion hip flexion contracture beyond 90° in adult paraplegic patient is a relatively difficult condition to treat because of the marked contracture of hip flexors in addition to blood vessels and nerves anterior to hip.
there is no definite consensus on the type of treatment to be offered.
a judicial combination of surgery and meticulous physiotherapy holds the key to success.
five cases of flexion contracture of the hip in adults have been reported by nicodemo et al.1 in their study, which were either treated by girdlestone or replacement arthroplasty or by myoarthrolysis.
ackerly et al.
in their study reported their experience with proximal femoral resection in 12 paraplegic children with spastic and painful dislocation of hip.2 our study is unique because our patient had painless flaccid paraplegia with complete sensory-motor loss with a longstanding flexion contracture of both hip joints.
michaelis3 had good results with iliopsoas and obliquus externus myotomy; graham et al.4 described 3 cases of recurrent dislocation of the hip in adult paraplegics successfully treated with open reduction and bone block augmentation of the acetabulum; becker et al.5 focused on periarticular ossification in paraplegics, reporting the results of six patients treated with a total hip replacement.
he recommends avoiding femoral head resection in favor of total hip arthroplasty even in complete paraplegia, as the former has the risk of posterior trochanteric dislocation and consequent formation of pressure sores.
however, on the other hand, in case of hip replacement, high dislocation rates, risk of infection (especially in presence of pressure sores), osteoporosis, loosening risk, and blood loss must be taken into account.
in all these cases, flexion contracture was <90°.
ackerly et al.2 in their study reported their experience with proximal femoral resection in seven quadriplegic nonambulatory children with spastic painful dislocation of hip.2 the operative technique of castle and schneider (1978) was employed.
the proximal femur was exposed through a lateral approach, extraperiosteally dissected, and resected below the level of the lesser trochanter.
the capsule was sutured over the acetabulum and femoral stump was closed by suturing the vastus lateralis over it.
he performed this technique due to pain secondary to dislocation of the hips and through lateral approach with minimal resection below the lesser trochanter.
we are reporting a case of a young college going girl who presented with longstanding flexion contracture of both hip joints due to irrecoverable spinal cord disease with complete motor and sensory loss.
she was unable to sit and lie on her back, slept on her legs.
she wanted to sit straight and lie on her back.
she had multiple pressure sores in her limbs and body.
she underwent bilateral proximal femoral resection through posterior approach without anesthesia.
in our patient, proximal femoral resection, until fully straight hip joint, was accomplished through posterior approach without anesthesia.
both hip joints were straight immediately after the operation, and she could lie on her back.
after 2 weeks she started sitting on her buttocks, led a comfortable wheelchair life with a good sitting balance.
there is no incidence of proximal femoral migration or heterotopic ossification.
proximal femoral resection thus offered a sound solution to an apparently difficult orthopedic condition of flaccid paraplegic acute hip flexion contracture, never reported before.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
paraplegic flexion contracture of hip joints beyond 90° is a difficult condition to treat for any orthopedic surgeon.
there is no fixed protocol of treatment described, by and large it is individualized.
a 20 year old female presented with paraplegia for last 15 years due to irrecoverable spinal cord disease with complete sensory and motor loss of both lower extremities and was admitted with acute flexion contracture of both hip joints with trunk resting on thighs.
she underwent bilateral proximal femoral resection.
both hip joints were straight immediately after surgery and patient could lie on her back.
in a course of time, she started sitting on her buttocks, led a comfortable wheelchair life with a sitting balance.
proximal femoral resection is an effective method to treat long standing irrecoverable paraplegic acute flexion deformity of the hip joint.
