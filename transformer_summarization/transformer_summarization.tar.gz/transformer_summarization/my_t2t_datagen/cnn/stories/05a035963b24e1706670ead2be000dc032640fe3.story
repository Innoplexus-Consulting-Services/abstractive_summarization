introduction the antimicrobial activity of plant essential oils and extracts has been recognized for many years (1).
production of essential oils by plants is believed to be a defense mechanism against pathogens (1).
essential oils have several advantages, which include lower bioaccumulation and toxicity, rapid decomposition and having very broad- antifungal spectrum compared to the conventional fungicides (2).
despite the mentioned advantages, using the essential oil has some limitations, including instability, evaporation, and decomposition against environmental and chemical conditions (light, oxygen, and humidity) (3).
nanoencapsulation has been proposed as one such technology that has great potential to solving this problem.
nanoencapsulation referred to as nano carriers to encapsulate substances or bioactive molecules (1).
they can increase the antimicrobial potential of bioactive compounds like essential oils by increasing cellular interactions between nanoparticles and the microorganisms as a result of the very small size that enhances cellular uptake.
in this regard, wu et al (4) encapsulated the thymol and carvacrol in nanoparticles of the protein of corn and enhanced the antimicrobial properties of these compounds.
nanoencapsulation in solid lipid nanoparticles (slns) is a promising strategy to facilitate the applicability of essential oils as antimicrobials (5).
slns have been introduced as a novel drug-delivery system for pharmaceutical drugs and cosmetic active ingredients due to their advantages over conventional formulations (6, 7).
slns offer unique properties such as small size, large surface area and high drug loading.
their size varies between 50 and 1000 nm.
slns are able to enhance the stability and solubility of essential oil in water (8), protect the essential oil against environmental factors; such as, oxygen, light, moisture and acidity, enhancing the bioavailability of entrapped bioactive and improve the controlled release of the essential oil (2).
in this regard, lai et al (9) reported decreased volatility and evaporation of the artemisia arborescens l. essential oil using slns.
moghimipour et al (10) also formulated z. multiflora essential oil using slns with different method and characterization.
z. multiflora (labiatae) grows in pakistan, iran and afghanistan (11) and has several traditional uses such as treatment of pertussis, laryngitis, gastrointestinal disorders, asthma and it also has antiseptic, antispasmodic, antibacterial and antifungal properties (12).
researches carried out in iran and around the world are focused on encapsulating the essential oil of medicinal plants with pharmaceutical and food industry and health-related objectives.
on the other hand, few studies have dealt with the effect of slns on plant pathogens (4, 13).
the aim of this research is to encapsulate z. multiflora l. essential oil (zeo) using slns and enhancing its efficiency using in controlling post-harvest the fungal pathogens of aspergillus ochraceus, aspergillus niger, aspergillus flavus, alternaria solani, rhizoctonia solani, and rhizopus stolonifer.
materials and methods essential oil analysis the essential oil of z. multiflora was supplied by barij essence pharmaceutical company (kashan, iran).
the compounds of the essential oil were then identified by gas chromatography-mass spectrometry (gc-ms).
according to the previse study, gc-ms spectrometry analysis was carried out in a varian 3400 gc/ms (california, usa) system equipped with a db-5 fused silica column (30m × 0.25mm i.d., film thickness 0.25 μm; j and w scientific).
the temperature of oven was raised from 50 to 240 °c at a rate of 4 °c min−1, the transfer line temperature was 260 °c, the carrier gas was helium at a linear velocity of 31.5 cm s−1, the split ratio was 1: 60, the ionization energy was 70 ev (14).
preparation of fungal strains the strains of a. ochraceu, a. niger, a. flavus, a. solan, r. solani, and rh.
stolonifer were provided by the phytopathology research sector of agricultural and natural resources research center of razavi khorasan.
preparation of slns high-shear homogenization and ultrasound methods were used to prepare sln formulations.
glyceryl mono stearate (gms, gattefossé, france) and precirol® ato 5 (gattefossé, france) (5%) was melted by heating at 70 °c and then different amounts of essential oil of z. multiflora were added to the lipid phase at the end of the melting process to prevent evaporation of essential oils.
the aqueous phase was prepared by dissolving tween 80 (sigma, germany) or poloxamer 188 (uniqema, belgium) together (2.5%) in double-distilled water up to 20 ml, then heated up to the melting point temperature of the lipid phase.
hot aqueous and molten lipid phases were mixed together and homogenized by a diax 900 homogenizer (heidolph, germany) for 5 min.
the temperature was kept at 5°c above the melting point of the lipid.
the obtained emulsion was ultrasonicated by a probe sonicator (bransonic, usa).
the sonication was performed at 6 cycles with 30 sec of sonication separated by intervals of 15 sec.
samples were then cooled to room temperature and slns were obtained (13).
characterization of sln particle size and zeta potential the mean particle size (z-average diameter), polydispersity index and zeta potential of the slns formulations were assessed by dynamic light scattering (dls) (zetasizer nano-zs; malvern instruments ltd., united kingdom) method (15).
encapsulation efficacy (ee) calibration curve was resulted using gas chromatography technique.
thymol (the major component of z. multiflora oil as an index) solutions were prepared at concentrations of 0.25, 0.5, 1, 2, 3, 4 and 5 mg/ml.
calibration curve was drawn in triplicate.
the encapsulation efficacy (ee%) was determined by measuring the concentration of entrapped thymol after purification (16).
to purify the sln-essence, 500 µl of the slns dispersion was transferred to the upper chamber of an ultrafilter (amicon ultra-15, plhk ultracel-pl membrane, 100 kda, millipore).
amicon tubes were centrifuged at 10,000 rpm for 30 min.
the filtrate was analyzed for encapsulated thymol using gas chromatography method after suitable dilution with chloroform: methanol (2:1 v/v).
twenty µl of transparent solution was injected into the gas chromatography and the real concentration of thymol in the sample was detected using calibration curve of height.
then, the percent of entrapment was determined using the following equation 1. differential scanning calorimetry (dsc) dsc scans of zeo and ze-slns were carried out in a mettler dsc 821e (mettler toledo, germany).
approximately, 5 mg of the samples were filled in aluminum oxide pans, sealed, and analyzed.
an empty aluminum pan served as reference.
dsc was done at 25 to 250 °c temperature range by the rate of 5 °c/min under n2 flow and the melting point of slns dispersions was compared to the bulk lipid (17).
transmission electron microscopy (tem) the morphology properties of slns formulations was characterized with transmission electronmicros-copy (tem; cem 902a; zeiss, oberkochen, germany).
briefly, the slns were diluted 50 fold with water and placed on a carbon-coated copper grid for 30 sec the excess water was wiped off with filter paper.
then 20 μl of 2% uranyl acetate in water was placed on slns and after 30 sec were wiped off by another filter paper.
the grid was dried at room temperature and assessed by tem (18).
evaluation of slns loaded with z. multiflora under in vitro conditions antifungal activity was studied using a contact assay (in vitro) that produced hyphal growth inhibition.
the assay was previously used for essential oil treatment on potato dextrose agar (pda) medium by the ‘solution method’ (sm).
briefly, the essential oils were dissolved in 50 ml l−1 tween 80/water solution and the required amounts of these solutions were added to individual petri dishes containing 20 ml of pda medium at 45 °c.
then a 0.5 mm disc of mycelium was placed on the pda medium in each dish.
the treated media were incubated at 24 °c and mycelia growth was measured daily.
the inhibitory percentage (ip) was determined from the formula ip = [(dc − dt)/dc] × 100, where dc is the mycelium diameter in the control petri dish and dt is the mycelium diameter in the essential oil-treated petri dish (19).
statistical analysis statistical analysis was done by mstatc software and the comparison of the means was conducted through dunken multi-domain test of the probability level of 5%.
the figures were then plotted using microsoft excel.
results slns characteristics the particle size and its distribution are the most important parameters associated with quality, influencing other macroscopic properties.
the particle size of slns is affected by various parameters, including the formulation compound, methods of production, and environmental conditions (such as time, temperature, pressure, the number of cycles, and equipment) (19).
in this experiment, particle size, based on z-average, was about 255.5±3 nm, the polydispersity index (pdi) was 0.369±0.05, and the zeta potential was -37.8±0.8 mv.
figure 1 shows particle size of zeo- slns through 4 months of storage in 4 °c.
figure 1 z-average (nm) of z. multiflora essential oil-loaded solid lipid nanoparticles prepared by probe sonication technique through 4 months of storage at 4 °c encapsulation efficacy (ee) ee is a very important characteristic for judging the quality of slns.
thymol (the major component of zeo) was selected as indexed components to evaluate the ee from a microscopic point of view.
according to gas chromatography assay results, encapsulation efficacy was 84±0.92% (n=3).
therefore, a high incorporation capacity of slns was observed, because of the high lipophilicity of zeo and its good compatibility with gms and precirol® ato 5. thermal analysis of ze-slns thermal analysis of bulk lipids used in slns, zeo and ze-slns were carried out by dsc (figures 2, 3, 4 and 5).
it can be observed that gms and precirol® ato 5 formed a basic structure in which zeo was entrapped in a crystalline state.
melting point for precirol® ato5 and gms appeared sharply at 56 to 57 °c (figure 3 and 4).
also, a small peak at about 82 °c can be observed for zeo (figure 2) which is probably due to oxidative degradation of the essential oil in this area.
ze-slns had a peak at 55.5 °c that is related to gms and precirol® ato 5 mixture.
this formulation has led to omission of zeo peak at 82 °c in slns structure.
figure 2 differential scanning calorimetry (dsc) thermogram of z. multiflora essential oil prepared by high shear homogenization and ultra sound technique.
5 mg of sample was used in each run figure 3 differential scanning calorimetry (dsc) thermogram of precirol ato5 5mg of lyophilized powder was used in each run figure 4 differential scanning calorimetry (dsc) thermogram of glyceryl mono stearate (gms) 5mg of lyophilized powder was used in each run figure 5 differential scanning calorimetry (dsc) thermogram of z. multiflora essential oil-loaded solid lipid nanoparticles prepared by 5 cycles of high shear homogenization and ultra sound technique.
5 mg of sample was used in each run transmission electron microscopy (tem) the results obtained from the images of electron microscopy showed that the shape of particles is almost spherical (figure 6) and the particle size was ranged from 50 to 300 nm, which corresponds with the particle size analyzing data.
the image also shows that the nanoparticles are not homogenous.
the results of the particle size analyzing also shows the nanoparticles are not homogenous (pdi 0.369).
figure 6 electron microscopy images of tem from z. multiflora essential oil-loaded solid lipid nanoparticles antifugal evaluation of ze-slns under in vitro conditions the results of in vitro antifungal studies showed that the antifungal activity of ze-slns is significantly (p≤0.01) more than zeo alone (table 1).
on average, the zeo had 54% inhibition and ze-slns had 79% inhibition on the growth of the experiment’s fungi (figure 7).
table 1 the results of the comparison of the mean of the effect of various concentrations (ppm) on the percentage of inhibiting the growth of the fungal pathogens alternaria solani rhizoctonia solani rhizopus stolonifer aspergillus niger aspergillus ochraceus aspergillus flavus concentration (ppm) formulation 77 22 69 0 30 0 20 83 44 67 0 41 0 50 83 65 89 0 50 11 100 essential oil 100 100 100 100 78 78 200 54 67 70 48 42 9 20 87 100 100 69 69 16 50 the essential oil-loaded slns 100 100 100 86 92 83 100 100 100 100 100 100 100 200 lsd (0.05)= 4.3 above columns indicate significant differences according to duncan’s multiple range tests at p≤0.01) figure 7 comparison of the effect of z. multiflora essential oil-loaded solid lipid nanoparticles and from z. multiflora essential oil on the percentage of inhibiting the growth of the fungal pathogens (different letters above columns indicate significant differences according to duncan’s multiple range tests at p≤0.01) the effect of essential oil was significant (p≤0.01) in slns loaded with the essential oil of z. multiflora on the fungal pathogens, where the zeo and the ze-slns had the highest inhibition on rh.
stolonifer (87%) and lowest on a. flavus (37%) (figure 8).
figure 8 the effect of the z. multiflora essential oil-loaded solid lipid nanoparticles and the z. multiflora essential oil on inhibition of the growth of the fungal pathogens (different letters above columns indicate significant differences according to duncan’s multiple range tests at p≤0.01) the minimum inhibition concentration (mic) of the zeo for the pathogens of the strains of r. solani, rh.
stolonifer, a. solani, a. flavus, a. achraceus and a. niger was 300, 200, 300, 200, 200, and 200 ppm, respectively (table 1 and figure 9).
figure 9 the minimum inhibition concentration (mic) (ppm) of the z. multiflora essential oil and z. multiflora essential oil-loaded solid lipid nanoparticles on the percentage of inhibiting the growth of the fungal pathogens (extracted from table 1) different letters furthermore, the mic for the ze-slns in these pathogens was 200, 200, 200, 100, 50, and 50 ppm, respectively (table 1 and figure 9).
these results indicate that ze-slns are more effective than zeo alone for the experimented fungi and kill the fungi at very lower concentrations, which could be due the interaction of vehicle (sln) with fungi and efficient delivery of zeo.
discussion essential oils (eos) are volatile, natural, aromatic oily liquids that can be obtained from several parts of the plants and are important in several fields, from food chemistry to pharmaceutics.
in fact, the large bioactivity of eos has being confirmed by several studies, including antibacterial, antiviral, anti-inflammatory, antifungal, antimutagenic, anticarcinogenic, and antioxidant as well as other miscellaneous activities (5).
the main problem in using essential oils is their instability against light, air, humidity, and high volatility.
this can lead to easy evaporation and thus decreased efficiency (20).
in order to improve their stability, some new delivery systems have been developed among these are the slns.
in several studies, the antibacterial and antifungal activities of z. multiflora have been investigated (11).
gc-ms analysis of the essential oil of z. multiflora contained different constituents such as thymol, cymene, carvacrol, terpenes and linalol.
it has been previously reported that the essential oil of z. multiflora has different components (10, 14).
we prepared and characterized ze-slns and evaluated its efficacy on fungal pathogens.
in some studies, it has been observed that the use of gms in the lipid phase results in increased encapsulation of the active ingredient (21).
in this study, gms and precirol® ato 5 were used as a lipid.
according to our results, loading essential oil in slns was 84 ± 0.92 in this formulation.
the high encapsulation efficacy of zeo was known that zeo is a lipid soluble molecule that could disperse in lipid mixture easily (22).
the particle size of lipid nanoparticles is affected by various parameters, including the formulation compound, methods of production, and environmental conditions (20).
the particle size average was lower than 300 nm through 4 weeks but it showed increasing after this period (figure 1), the polydispersity index (pdi) was around 0.369 and the zeta potential was approximately -40 mv which can produce particle repulsion and would inhibit aggregations.
the sln with zeta potential higher than ± 30 mv are normally considered physically stable (23).
the dsc studies were performed to assess the extent of crystallinity (figure 5).
dsc curves showed that the dsc pick of zeo is not visible in ze-sln.
these results could suggest the oil incorporation and dissolution to the lipid matrix.
it seems that slns prevent the evaporation of zeo.
tem image supports particles size of around 100 nm and proved spherical particle shape (figure 4).
the sphericity of the slns causes them to have the highest ability for controlled-release and protection against encapsulated essential oil.
this is because, spherical shape has the longest route for the movement of essential oil encapsulated in the nanoparticles and the lowest contact area with the aqueous medium of the dispersed phase, when compared with other forms of nanoparticles (24).
moghimipour et al (10) also formulated zeo using slns, but in their study, the particle size (650 nm) was larger and the encapsulation percentage (38.66%) was lower.
based on the results of this research, slns, as a carrier, have a major role on the effectiveness of essential oil, such that the results of the ze-slns have a significant difference with the results of the zeo (figure 8).
the mic results of the ze-slns when compared with the zeo showed that this has led to a remarkable decrease in mic against the fungal pathogens (figure 9).
in justifying the relatively better effectiveness of the encapsulated essential oil-loaded formulations when compared with the zeo, the level of slns in contact with microorganisms is noticeable.
indeed, with respect to their larger size than the microorganism, slns can well cover their surface and fully surround the cell.
on the other hand, slns inhibit evaporation of the essential oil.
because the essential oil inside these colloidal delivery systems has been encapsulated and thus its evaporation rate drops.
therefore, it has a greater opportunity to get in contact with microorganism and thus can demonstrate a better influence when compared with the zeo.
in fact, many other studies indicated that the slns are suitable carriers for essential oil, and a number of essential oils have been successfully incorporated in slns (10).
based on the study by li et al (25) in the formulation of slns loaded with thymol against escherichia coli and salmonella, suitable antibacterial activity was observed.
in the study by wattanasatcha et al (26), nanoparticles loaded with thymol was shown to have favorable antibacterial activities against staphylococcus aureus, pseudomonas aeruginosa, and e. coli.
due to the fact that their size is lower than the cells, slns may give rise to increased passive cellular absorption mechanism and thereby diminishing transfer resistance and raising antimicrobial activity.
as was reported by effert and koch (27), the nano carriers give protection to the active compounds of the essential oil from enzymatic degradation by the pathogen.
on the other hand, slns protect the essential oil from environmental factors, such as light, humidity, and acidity.
they also develop more nano-sized carriers, easily enhance the essential oil bioavailability, and improve controlled release of the essential oil (2).
conclusion ze-slns had higher efficacy than zeo in controlling the mentioned fungal pathogens under in vitro tests.
it can be concluded that slns prepared in this study was appropriate carriers for the zeo and is a promising strategy to facilitate the applicability of essential oils as antimicrobials.
@highlight
objective(s): the aim of the present study was to prepare, characterize, and evaluate solid lipid nanoparticles (slns) containing zataria multiflora essential oil (zeo).
materials and methods: in this study, z. multiflora essential oil-loaded solid lipid nanoparticles (ze-slns) were prepared to improve its efficiency in controlling some fungal pathogens.
slns containing z. multiflora essential oil were prepared by high shear homogenization and ultra sound technique.
zeo-slns contained 0.03% zeo in 5% of lipid phase (glyceryl monostearate-gms and precirol® ato 5).
tween 80 and poloxamer 188 (2.5% w/v) were used as surfactant in the aqueous phase.
the antifungal efficacy of ze-slns and zeo was compared under in vitro conditions.
results: the particle size of ze-slns was around 255.5±3 nm with pdi of 0.369±0.05 and zeta potential was about -37.8±0.8 mv.
encapsulation efficacy of ze-slns in crystalline form was 84±0.92%.
the results showed that the zeo and ze-slns had 54 and 79% inhibition on the growth of fungal pathogens, respectively.
the minimum inhibitory concentration (mic) under in vitro conditions for the zeo on the fungal pathogens of aspergillus ochraceus, aspergillus niger, aspergillus flavus, alternaria solani, rhizoctonia solani, and rhizopus stolonifer was 300, 200, 300, 200, 200 and 200 ppm, respectively, for ze-slns, it was 200, 200, 200, 100, 50 and 50 ppm.
the antifungal efficacy of ze-slns was significantly more than zeo.
conclusion: our results showed that the slns were suitable carriers for z. multiflora essential oil in controlling the fungal pathogens and merits further investigation.
