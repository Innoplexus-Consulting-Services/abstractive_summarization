breast cancer is frequently diagnosed cancer and a leading cause of cancer-related mortality in women worldwide, with 1.7 million cases and 521,900 deaths in 2012.
[1] it occurs due to progressive transformation of a normal cell into cancerous entity.
estrogen plays a major role in the growth of mammary epithelium thereby implying estrogen action and breast cancer.
targeting the estrogen receptor (er) action can be a major approach for synthesis of drug against breast cancer.
[2] tamoxifen (tam) is an antiestrogen, approved by food and drug administration for the treatment of breast cancer; however, long-term tam administration results into resistance to the drug and increases the risk of endometrial carcinoma, thrombosis, etc.
[3] in this context, centchroman (cc) or ormeloxifene34-trans-2,2-dimethyl-3-phenyl-4-p-(β-pyrrolidinoethoxy) phenyl-7-methoxy chroman] is a promising agent for breast cancer.
cc is a nonsteroidal oral contraceptive used in india.
[4] it modulates er, being antagonistic in ovary, uterus and breast and agonist in bone.
our laboratory initially demonstrated its antineoplastic activity in vitro in mcf-7/mda mb-231 cells through g0/g1 phase cell cycle arrest and caspase-dependent apoptosis.
[567] it has also been found to be effective in patients of benign breast diseases such as mastalgia and fibroadenoma.
[8] in head and neck cancer cells, it inhibits cellular proliferation by modulating pi3k/mtor pathway.
cc induces g0/g1 arrest and erk-mediated apoptosis in chronic myloid leukemia.
[9] recently, cc has been found to efficiently inhibit ovarian and pancreatic cancer growth.
[1011] epidemiological studies have shown that asian women consuming phytoestrogen-rich diet have lower risk of breast cancer compared to the western women.
however, asian women migrated to western nations have similar risk of breast cancer as their caucasian counterparts.
this supports the fact that lifestyle modifications including dietary changes play a pivotal role in carcinogenesis.
phytoestrogens are the plant-derived phenolics, structurally similar to mammalian 17-β estradiol.
[12] isoflavone, genistein (gn) is the most commonly ingested and widely studied phytoestrogen, often found in soy products.
it has the ability to influence cellular functions by interaction with human ers.
gn selectively binds with erβ inducing an association with coactivators and activation of downstream gene transcription.
gn is a potent inhibitor of protein tyrosine kinase and topoisomerase ii, the important actors of cellular proliferation.
[13] higher dose of gn attenuates dna synthesis and cell cycle arrest at g2/m stage.
[14] when drugs with different modes of action are combined, each drug can be used with at its optimal dose with minimal side effects.
previously, we reported that cc in combination with phytochemicals such as resveratrol and curcumin has higher anticancerous potential as compared to each drug alone in mcf-7/mda mb-231 human breast cancer cell lines (hbccs).
[15] in this study, we sought to determine the combination of cc with gn in various breast cancer cell lines such as er −ve mda mb-231/mda mb-468 and er +ve mcf-7/t-47d along with nontumorigenic human mammary epithelial cell (hmec) mcf-10a.
the central idea is to explore the feasibility of gn being employed as an adjunct to cc since soy in diet is increasingly being emphasized.
collective effect of cc and gn was calculated using compusyn software to characterize the drug interactions (synergistic, additive, and antagonistic).
materials and methods chemicals dulbecco's modified eagle's medium (dmem), rpmi-1640, ethylenediaminetetraacetic acid, gentamicin sulfate, streptomycin sulfate, penicillin g, trypsin, sodium bicarbonate, phosphate buffered saline, cholera toxin, insulin, sulforhodamine b (srb), trichloroacetic acid (tca), hydrocortisone, epidermal growth factor (egf), sodium bicarbonate, and gn were procured from sigma chemical co., (st. louis, mo, usa).
horse serum and fetal bovine serum (fbs) were from gibco (life technologies).
cc was obtained from csir – central drug research institute (cdri), lucknow, uttar pradesh, india.
cell culture mda mb-231, mcf-7, mda mb-468, and t-47d cells were procured from the national centre for cell sciences, pune and maintained in our laboratory.
mcf-10a cells were procured from american type culture collection.
mda mb-231, mda mb-468, and mcf-7 cells were cultured and maintained in dmem/f-12 ph 7.4, containing penicillin (100 u/ml), gentamicin (50 µg/ml), streptomycin (200 µg/ml), supplemented with 10% fbs, and 10 mm hepes.
t-47d cells were cultured in rpmi media containing penicillin (100 u/ml), gentamicin (50 µg/ml), streptomycin (200 µg/ml), supplemented with 10% fbs, and 10 mm hepes.
hmec mcf-10a were maintained in dmem/f-12 medium supplemented with 5% horse serum, 10 µg/ml of human insulin, 20 ng/ml of egf, 100 ng/ml of cholera endotoxin, 100 µg/ml of hydrocortisone, penicillin (100 u/ml), gentamicin (50 µg/ml), streptomycin (200 µg/ml).
all the cells were maintained in a humidified 5% co2 incubator at 37°c.
cell growth inhibition study using sulforhodamine b srb assay was performed to ascertain the cytostatic/proliferative/toxic potential of cc/gn separately and together with estrogen/progesterone receptor (er/pr) +ve mcf-7 and t-47d and er/pr −ve mda mb-231/468 hbccs and non-tumorigenic hmecs (mcf-10a).
previous studies by our group have reported the antineoplastic action of cc using various doses (1–25 µm) and the ic50 was found to be 10 and 20 µm in mcf-7 and mda mb-231 cells, respectively.
[57] besides, in this study, we also have used t-47d, mda mb-468, mcf-10a cells, and therefore, for these cells, 1–30 µm cc concentration was employed for optimization and determination of ic50.
researchers have shown that when tested by itself, gn at lower doses (<10 µm) has proliferative action on cancer cells and inhibitory action at higher (up to 1 mm) doses.
[1617] therefore, we selected 10–200 µm of gn for dose optimization studies.
when two ligands were administered together, the range of values chosen was 5/10 µm for cc and 25/50 µm for gn-the specific combination being 5 µm cc plus 25 µm gn; 5 µm cc plus 50 µm gn; 10 µm cc plus 25 µm gn; 10 µm cc plus 50 µm gn.
the basic premise for selecting these values was to reduce the dose of cc (5/10 µm) through supplementation with gn (25/50 µm) while maintaining/improving the extent of apoptotic potential.
briefly, we halved the ic50 of cc and also for gn for these studies to determine synergism among these molecules with reduction of doses for various cell types.
for ic50 determination, 1 × 104 cells were seeded in 96-welled plate in phenol-red free dmem for 24 h and exposed with cc (1–30 µm) and gn (10–200 µm) separately and together (cc 5/10 µm plus gn 25/50 µm) for further 24 and 48 h. after incubation with drugs, the cells were fixed with 50% tca for 1 h at 4°c, supernatant aspirated, plates washed with chilled deionized water 3 times, and air dried.
100 µl of 0.4% (w/v) srb was added to each well and incubated for 30 min at room temperature.
unbound srb was removed by 3 washes with 1% acetic acid and the plates were air dried.
200 µl of 10 mm tris base, ph 10.5 was added for extracting the bound stain and absorbance measured at 560 nm in spectramaxm2e elisa microplate reader (molecular devices inc.).
[18] combination index analysis drug combination relationship was studied using compusyn (version 1.0) software (t. c. chou and n. martin, memorial sloan-kettering cancer center, new york).
cc and gn were added separately and together in the above stated doses in a non-constant ratio.
treatment effect was expressed between 0 and 1, where 0 represents no effect and 1 represents 100% effect.
the parameters, combination index (ci), and dose reduction index (dri) were generated through compusyn, which represents drug synergism, additivity, or antagonism.
[19] statistical analysis all experiments were carried out in triplicate and the results expressed as mean ± standard deviation.
for the analysis of bonferroni's multiple comparison test, one-way analysis of variance was used.
a statistically significant difference was defined as p < 0.05. results cell growth inhibition induced by centchroman and genistein alone to evaluate the cytotoxicity of cc and gn alone, different breast cancer cells (mda mb-231, mda mb-468, mcf-7, t-47d) and mcf-10a as control were assayed with various doses of cc and gn through srb assay for 24 and 48 h. the results illustrate cc and gn mediated dose-dependent decline in viability of respective cell types [figure 1].
ic50 after 24 h could not be calculated from the observed data.
however, the ic50 of cc for mda mb-231, mda mb-468, mcf-7, and t-47d were 18, 36, 16, and 25 µm, respectively, after 48 h, whereas that of gn was 92, 89, 85, 150 µm, respectively.
in the nontumorigenic hmec-mcf-10a, no significant cytotoxicity of cc and gn was observed after 24 and 48 h. figure 1 cellular cytotoxicity evaluation of centchroman and genistein alone in mda mb-231, mda mb-468, mcf-7, t-47d human breast cancer cell lines versus human mammary epithelial cell-mcf-10a through sulforhodamine b assay.
data shown are the mean ± standard deviation of one of the three similar experiments each performed in triplicate.
a statistically significant difference was defined as p < 0.05 combination of centchroman and genistein in mda mb-231, mda mb-468, mcf-7, t-47d, and mcf-10a combination of cc with gn was evaluated through srb assay in hbccs and hmec after 48 h. when breast cancer cells were treated with 5/10 µm cc and 25/50 µm gn separately, ~70%–80% cell viability was found.
however, when cells were exposed with 5/10 µm cc plus 25/50 µm gn, percent viability was diminished to ~ 40%.
in nontumorigenic mammary epithelial cells mcf-10 a, no significant alteration was observed in combination as compared to cc/gn alone [figure 2].
figure 2 combination of centchroman with genistein in mda mb-231, mda mb-468, mcf-7, t-47d, and mcf-10 a cell lines.
data shown are the mean ± standard deviation of one of the three similar experiments each performed in triplicate.
*p < 0.05; **p < 0.01; ***p < 0.001, calculated compared to control.
$p < 0.05; $$p < 0.01; $$$p < 0.001 with respect to centchroman alone and #p < 0.05; ##p < 0.01; ###p < 0.001 with respect to genistein alone genistein potentiates the cytotoxic effect of centchroman in human breast cancer cell lines isobologram was plotted to calculate the ci using compusyn software.
isobologram is a graph which indicates the equipotent combinations of different doses of two drugs.
it is used to illustrate synergism, additive effect, or antagonism.
[19] ci shows the drug interaction, namely, synergism (ci < 1), additive (ci = 1), or antagonism (ci > 1).
in this experiment, all the combinations of cc and gn have ci values <1 suggesting synergism with mda mb-231, mda mb-468, mcf-7, and t-47d cell lines.
however, 10 µm cc plus 25 µm gn displays antagonism (ci = 1.063) in mda mb-468 cells [figure 3 and table 1].
dri value above 1 (dri > 1) is favorable and shows synergistic drug combination.
in our study, for all the combinations, this value was found to be >1, which indicates that the combinations of cc plus gn were favorable for hbccs [figure 4 and table 2].
figure 3 isobologram plots for combination treatments of centchroman and genistein in mda mb-231, mda mb-468, mcf-7, and t-47d cell lines.
on the lower left of the hypotenuse synergism, on the hypotenuse additive effect, and on the upper right of the hypotenuse antagonism table 1 combination index values for combined treatments of centchroman and genistein in human breast cancer cells figure 4 dose reduction index of centchroman/genistein combination in mda mb-231, mda mb-468, mcf-7, and t-47d human breast cancer cell lines table 2 dose reduction index of centchroman and genistein combination in human breast cancer cells discussion breast cancer is the most prevalent cancer and a major global cause of mortality in women.
despite advancement in therapy, it remains one of the most lethal forms of cancer worldwide.
combination of cyclophosphamide, methotrexate, 5-fluorouracil or doxorubicin, and cyclophosphamide are the most commonly used chemotherapeutic agents, but multi-drug resistance is the most common disadvantage of chemotherapy.
[20] tam is the antiestrogen used for the treatment of both early and advanced er +ve breast cancer; however, long-term tam therapy increases the risk of developing endometrial cancer and thromboembolic disorders.
[21] hence, there is a need of development of more effective and less cytotoxic chemotherapeutic strategies.
in this context, combination therapy can be a potentially viable option.
the main aim of combination therapy is to obtain synergistic therapeutic effect, reduction of dose and toxicity, and to minimize the induction of drug resistance.
[22] in the present study, we hypothesize that gn potentiates the cc-induced antineoplasticity in hbccs.
cc is a nonsteroidal oral contraceptive, widely used in india, under the trade names saheli, novex, and novex ds.
it is once a week oral pill (30 mg dose weekly), having long serum half-life with very few or no side effects.
cc has mild estrogenic and strong anti-estrogenic activity at lower and higher doses, respectively.
it has the ability to interact with both erα and erβ but has higher affinity for the former (8%) compared to latter (3%).
[9] we demonstrated its novel antineoplastic potential in mcf-7/mda mb-231 cells where it was found that cc induces g0/g1 arrest and caspase-dependent apoptosis in these cells.
[567] we further demonstrated the enhanced antineoplasticity of cc when administered with resveratrol and curcumin.
[15] singh, in an exhaustive review on cc, has collated the repertoire of anti-estrogenic actions for the molecule including that for phase ii/iii clinical trials.
[423] moreover, it possesses anticancer activity against a number of other cancers such as ovarian, head and neck cancer, and chronic myloid leukemia.
[9] here, we demonstrate the combination of cc with gn in er −ve (mda mb-231/mda mb-468) and er +ve (mcf-7/t-47d) cell lines employing nontumorigenic hmec mcf-10a as control.
gn is a phytoestrogen, categorized under isoflavones, and has binding affinity with ers.
gn at less/more than 10 µm exerts estrogenic/antiestrogenic action including regulation of ps2 gene in tumor cells.
[16] several studies have demonstrated that it has anti-cancerous potential in breast, colon, prostate, and cervical cancer.
[24] however, on the contrary, caution has been suggested for employing gn as an adjunct for breast cancer therapy in murine model suggesting thereby that more studies are warranted in this area.
[25] in this study, the combination of cc and gn was evaluated in er +ve mcf-7/t-47d, er −ve mda mb-231/mda mb-468, and hmec mcf-10a cell lines through srb assay.
the combination was found to be more potent as compared to each drug alone in hbccs [figures 1 and 2].
moreover, the combination failed to affect mcf-10a kinetics demonstrating its safety.
ci and dri were calculated with the help of compusyn software.
ci represents the quantitative measure of degree of drug interaction in terms of synergistic, additive, or antagonistic effect at a particular dose.
ci value generated through isobologram with smaller, equal to, or more reflects synergism, additive effect, or antagonism, respectively.
[19] compusyn analysis of cc plus gn combinations in mda mb-231, mda mb-468, mcf-7, and t-47d revealed that interactive effects may vary depending on both, the cell type and dose of the compound.
for all the combinations, ci values were found to be <1 in mda mb-231, mcf-7, and t-47d which are indicative of synergistic cytotoxic effect of cc/gn combination in these cell lines [figure 3 and table 1].
in mda mb-468 cells also, cc/gn combination was synergistic in all combinations except 10 µm cc plus 25 µm gn in which ci value was 1.063. dri plot denotes the degree of measure of how many folds the dose of each drug can be reduced when used in combination compared to using it alone.
dri value >1 (dri > 1) is desirable in such cells, signifying synergism.
[19] dri value of the cc and gn combination was >1 (~1.65–14.36) for all the cell types [figure 4 and table 2].
the results, therefore, indicate that the dose of cc can be reduced 14-fold when used in combination with gn.
the data suggest that the combination of cc with gn deserves further evaluation.
more importantly, it was found that the combination of cc with gn has selective cytotoxic effect for hbccs.
hmec were found to be unaffected, a critical factor for possible therapeutic applications.
conclusion we can conclude therefore that combination of cc with gn has synergistic anticancer potential in hbccs and represents a novel therapeutic regimen for breast cancer.
further studies are needed to delineate the underlying pathways.
financial support and sponsorship the work has been supported by the funds from mlp-0750.
conflicts of interest there are no conflicts of interest.
@highlight
objectives: despite the progress in the diagnosis and treatment of breast cancer, it remains a major health problem in women.
natural flavones along with chemotherapeutic agents enhance therapeutic response and minimize toxicity of chemical agents.
centchroman (cc) colloquially called as ormeloxifene, is a nonsteroidal oral contraceptive categorized as selective estrogen receptor modulator with anti-breast cancer activity.
genistein (gn), an isoflavone found mainly in soy products possesses anti-cancerous potential against a number of cancers including breast.
the present study aims at investigating the combination of cc and gn in human breast cancer cell lines (hbccs).
materials and methods: cytotoxic effect of cc and gn separately and in combination were assessed by sulforhodamine b (srb) assay in mda mb-231, mda mb-468, mcf-7, t-47d hbccs, and nontumorigenic human mammary epithelial cell (hmec) mcf-10a.
the drug interaction was analyzed using compusyn software through which combination index and dose reduction index were generated.
results: combination of cc plus gn exerts significantly higher cytotoxicity compared to each drug per se in hbccs, whereas hmec-mcf-10a remains unaffected.
conclusion: on an overall basis, the drugs in combination enhanced cell killing in malignant cells.
therefore, the combination of cc with gn may offer a novel approach for the breast cancer.
