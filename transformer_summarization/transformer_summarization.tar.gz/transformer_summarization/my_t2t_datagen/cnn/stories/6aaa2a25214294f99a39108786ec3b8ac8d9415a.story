introduction for decades, endodontically treated teeth with significant coronal tissue loss were restored with cast metal post and core.
[1] despite the high retention rate and thin layer of cement, metal posts have been associated with irreparable root fractures.
[1] this is primarily due to the modulus of elasticity of metal being higher than that of root dentin.
[2] the ability to offer a faster treatment, modulus of elasticity similar to dentin, esthetic properties, lack of corrosion, and hypersensitivity are the factors mainly responsible for the current success of fiber posts.
[3] the high flexural strength and modulus of elasticity similar to that of dentin reduce the transmission of fatigue to dentin walls and the possibility of fracture.
[3] however, fiber posts have a passive restraint in the root canal, thus resin cements are needed to increase postretention.
furthermore, the lack of a perfect fit of the fiber post in the root canal space is certainly another important limitation to their use.
[4] the cementation procedure is subject to one limitation, which is the difficulty of photoactivation and subsequent polymerization in the apical region.
[5] therefore, the manufacturers are investing in the development of translucent posts.
the studies have shown that translucent posts really do increase the efficiency of photoactivation in the intraradicular dentin.
[6] nevertheless, other studies have shown that it is possible to obtain the same performance with opaque posts, even in the apical third.
[7] photopolymerizable resin cements require light energy as a trigger to initiate the polymerization reaction.
hence, if the light does not reach the root portions, and the energy is not sufficient to promote polymerization, the retention provided by resin cement and post may be lost and fail.
finally, the structure of the root canal is also an important factor that should be taken into account in cementation of fiber posts with resin cements.
[8] the anatomical and histological characteristics, such as orientation and number of dentinal tubules in the different root thirds, are important factors that may influence the adhesive cementation.
[9] thus, the aim of this study was to compare the bond strength of different translucent fiber posts with an opaque fiber postcemented with self-adhesive cement in the different root thirds.
two null hypotheses were formulated: the type of post (translucent or opaque) would have no influence on the root dentin bond strength and the root third region (cervical, middle or apical) would have no influence on the results.
materials and methods sixty single-rooted human teeth extracted for therapeutic reasons were selected (institutional research ethics committee, protocol number [0439/11]).
the inclusion criteria were the absence of caries and/or endodontic treatment, root length of at least 14 mm, and straight single root with a single canal.
preparation of the roots the teeth were sectioned below the cemento-enamel junction with a diamond blade (isomet 2000, buehler, lake bluff, il, usa) under water cooling.
the roots were randomly assigned into 5 groups (n = 12) according to the fiber post used [table 1].
coronal access was made with a k-file #15 (dentsply maillefer, ballaigues, switzerland) inserted into the canals until it was visible at the apical foramen.
then, the working length was set 1 mm short of this length.
k files 15–40 were used for making the stop at 1 mm from the apical foramen.
the canals were instrumented with k-files #15–40 and irrigated with 5 ml of 5% naclo and 5 ml of 17% ethylenediaminetetraacetic acid and finally irrigated with 5 ml of distilled water.
table 1 mean push-out bond strength values and standard deviations in mpa of the fiber posts evaluated in cervical, middle, and apical thirds of root canal the root canals were flared with a largo drill system (1, 2 and 3) with 0.7, 0.9, and 1.1 mm in diameter, respectively, at a distance of 4 mm from the apical foramen.
after that, the low-speed drill provided by the respective manufacturer was used.
then, the root canals were gently dried with paper points.
each post was cleaned with alcohol, dried, and coated with a silane layer (relyx ceramic primer, 3m espe dental products, st paul, mn, usa).
the self-adhesive resin cement (relyx u100, 3m espe) was dispensed on a glass plate, mixed for 20 s, applied onto the surface of each post, and inserted into the root canal.
the extravasated cement was removed with a microbrush.
after 60 s, the resin cement was light-activated using a light-emitting diodes (led) unit (irradiance 900 mw/cm2 [radii-cal led; sdi, são paulo, sp, brazil]) through the post for 40 s. push-out bond strength test after 24 h maintaining the roots in distilled water in an incubator at 37°c, they were sectioned transversely.
six slices of each root, generating three 1 mm thick specimens per root, were cut with a diamond steel disc (extec model 12205, extec corporation, enfield, ct, usa) in a cutting machine (isomet 1000, buehler ltd., lake bluff, il, usa) under water-cooling at a speed of 200 rpm.
the first cut was made at 1 mm from the enamel-cement junction obtaining 3 slices per tooth: cervical, middle, and apical third, respectively.
each sample was placed in a metal matrix with a central opening larger than the postdiameter, with the coronary portion facing down.
to this, a cylindrical tip 0.6 mm in diameter connected to a universal testing machine (emic, são josé dos pinhais, pr, brazil) was applied at a speed of 1.0 mm/min.
a digital caliper (mitutoyo corporation, aurora, il, usa) was used to measure the thickness of the slices (h), the largest (r), and smallest radius (r) of the dentin/postinterface.
then, the bonding surface was calculated using the formula of a frustoconical shape: the bond strength (σ) was finally obtained by the formula σ = c/a, where c = load for rupture of the specimen (kgf) and a = interfacial area (mm2).
failure mode analysis all debonded specimens were evaluated using a light optical microscope at 40x magnification.
two independent operators evaluated and classified the failure modes into four categories: (a) adhesive failure between fiber post and cement; (b) adhesive failure between cement and dentin, (c) cohesive fracture of the post, and (d) mixed failure (when more than one classification appeared in the same specimen).
statistical analysis the bond strength (mpa) data were analyzed using the graphpad prism 5 (graphpad software, san diego, ca, usa).
statistical analysis was performed by two-way analysis of variance followed by bonferroni's post hoc test (p < 0.05).
results the results demonstrated no significant difference (p > 0.05) between the different root thirds evaluated, which confirmed the first null hypothesis suggested.
however, the performance of the posts demonstrated a significant difference.
since radix showed the worst performance in the apical third (p < 0.05).
yet, no statistical difference in bond strength was shown between translucent and opaque posts.
thus, the second null hypothesis was also accepted [table 1].
the evaluation of the failure pattern revealed that there was a predominance of the adhesive type of fracture between the self-adhesive resin cement and root dentin, and a much lower percentage of mixed failures, which clearly shows that this was the weakest interface of the entire system [table 2].
table 2 distribution of type of failure occurred in each group in percentage discussion the results demonstrated that translucent posts were not able to produce higher bond strength in any of the root thirds evaluated when compared with the opaque post used as a control.
thus, the null hypothesis that the type of post has no influence on the root dentin bond strength was accepted.
the bond strength results presented are in agreement with those of other studies that also did not show a better performance of the translucent posts in comparison with opaque posts.
[1011] in a recent study was demonstrated that the posttranslucence was not capable of increasing the tensile bond strength when compared to opaque posts (white and black), independent of the resin luting agent used (dual-polymerized or self-adhesive).
[12] instead, it is possible to find studies showing even poorer performance for translucent posts.
[11] however, as luting agent, these studies used relyx arc, a conventional dual-polymerized resin luting agent that requires previous acid etching of root dentin.
in such cases, it is believed that the effectiveness of acid etching of root dentin in the different thirds may significantly influence the results,[12] since some studies have reported the presence of a residual smear layer, especially in the apical third.
[13] salas et al.
[13] also showed that the viscosity of acid etching could influence the etching pattern obtained in root dentin and consequently affect the bond strength.
the liquid phosphoric acid produced higher bond strength in the apical region when compared with phosphoric acid gel, in the same concentration of 37%.
furthermore, no statistically significant difference was observed between root thirds evaluated.
the type of resin cement used (self-adhesive) may have significantly affected the results.
other researches have shown that the self-adhesive cement relyx u100 presented the same performance in the three different root thirds evaluated (apical, middle, and cervical), producing a uniform bond strength throughout the root.
[14] giachetti et al.
[15] and monticelli et al.
[16] hypothesized that this may occur due to the close adaptation of the post along the canal walls provided by the custom drills of the postsystems.
in addition, this may be influenced by the slight manual pressure applied on the posts during the cementation, which may have further improved the postadaptation,[7] since it is known that the friction along the canal walls also contributes to postretention.
[16] on the other hand, there is no consensus in the literature about the use of calibrated drills to decrease the thickness of the resin cement and hence increase the bond strength between posts and root dentin.
perdigão et al.
[17] showed that the diameter of the space between the post and root dentin did not influence the push-out bond strength values.
factors such as channels with elliptical shape and the presence of residual gutta-percha after preparation also can negatively influence the bond strength values.
the studies have shown that the predominant failure mode in restorations using fiber posts was the loss of retention.
[123] this is an important characteristic since the failure mode involved in metal posts and casts is predominantly catastrophic and often leads to tooth extraction.
[18] santos et al.
[19] in a finite element analysis reported that the fiber post reduced the occurrence of root fractures when compared with cast metal posts.
this tendency is explained by the lower resistance and elasticity modulus of the cement, fiber post, and composite core when compared with that of the tooth root.
moreover, this study reported that fiber posts only reduced the stresses in the tooth root if they were bonded to dentin.
self-adhesive resin cements are relatively new to the market and have gained much popularity mainly because of their ease of application.
[20] however, there are few studies about their chemical composition and actual indications, which may often cause confusion during the selection of the resin cement by the dentist.
[20] the self-adhesive resin cements have functional monomers with acidic characteristics, which generate their interaction with calcium of the enamel and dentin.
however, there are few studies that assess the longitudinal performance of self-adhesive resin cements and the time periods evaluated are very short.
to the best of our knowledge, there are no longitudinal clinical studies evaluating the use of self-adhesive resin cements for the cementation of fiber posts.
the self-adhesive resin cement relyx unicem has been clinically evaluated for bonding of ceramic inlays and showed an excellent survival rate of 95% after 4 years.
[21] on the other hand, articles evaluating the clinical performance of restorations supported by fiber posts are more common.
in a recent study, naumann et al.
[21] reported the clinical performance after 10 years of resin restorations retained by fiber posts.
the authors reported a high annual failure rate (4.6%) mainly caused by postfracture and loss of postretention.
[22] different results are found in short evaluation periods.
in a clinical evaluation of 45 months, the success rate was 95.45% for oval-shaped glass fiber posts cemented in premolars and restored with all-ceramic crowns.
[23] conclusion translucent fiber posts did not show superior bond strength in comparison with the opaque fiber post in any of the root thirds evaluated.
thus, demonstrating that translucent fiber posts do not guarantee better performance when self-adhesive resin cement is used.
financial support and sponsorship nil.
conflicts of interest there are no conflicts of interest.
@highlight
purpose: evaluate the bond strength of different translucent fiber posts in the cervical, middle, and apical root thirds cemented with self-adhesive resin cement.
materials and methods: sixty single-rooted teeth were randomly divided into five groups according to the fiber post used: reforpost (opaque [control]), exacto, white post, radix, and macro-lock illusion x-ro.
the roots were subjected to chemomechanical preparation and cemented with self-adhesive resin cement.
the teeth were sectioned into slices of the different root thirds and tested for bond strength (push-out).
two-way analysis of variance and bonferroni test were used to verify statistical differences between groups (p < 0.05).
results: no significant difference between the root thirds was detected (p > 0.05).
however, the performance of the posts demonstrated a significant difference (p < 0.05).
rdx had a lower performance in the apical third (p < 0.05).
the other fiber posts had the same performance irrespective of the root third evaluated.
the predominant failure pattern was adhesive between resin cement and root dentin.
conclusion: in general, the different translucent fiber posts showed the same performance.
yet, translucent fiber posts did not show superior bond strength compared with the opaque fiber post in any of the root thirds evaluated.
