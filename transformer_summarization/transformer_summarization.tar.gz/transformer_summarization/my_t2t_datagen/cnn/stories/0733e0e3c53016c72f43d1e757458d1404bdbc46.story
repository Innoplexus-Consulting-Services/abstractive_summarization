introduction excessive consumption of ethanol, often referred in the literature as "binge drinking", is considered a risk for the cardiovascular system.
binge drinking is associated with an increased risk of cardiovascular events, such as atherosclerosis, stroke and myocardial infarction.1-3 the exact mechanism underlying the cardiovascular dysfunction induced by binge drinking is not totally understood; but changes on vascular function may play a key role.4-6 one important mechanism by which ethanol leads to vascular damage is by increasing the generation of reactive oxygen species (ros).
ethanol-mediated generation of superoxide anion (o2-) and hydrogen peroxide (h2o2) is associated with vascular dysfunction.7,8 the enzyme nicotinamide adenine dinucleotide phosphate [nad(p)h] oxidase is the main source of ros in endothelial and vascular smooth muscle cells (vsmc),9 and a an essential factor in ethanol-induced vascular dysfunction.10 the activation of nad(p)h oxidase is a complex process , but translocation of the cytosolic subunit p47phox to the membrane, with further association with the cytochrome b558, is a decisive step for the activation of the enzyme .11 recent findings from our laboratory have shown that acute ethanol intake increases the generation of nad(p)h oxidase-derived ros in resistance arteries.12 ros activate downstream signaling targets, including mitogen-activated protein kinases (mapk) and rhoa/rho kinase, which are considered important mediators of vascular dysfunction.
activation of these redox-sensitive pathways regulates vascular cell growth, inflammation and contraction.13 importantly, acute ethanol intake induces nad(p)h oxidase activation and mapk phosphorylation in resistance arteries.12 additionally, the rapid inactivation of nitric oxide (no)14 induced by o2-, and changes in no synthesis and/or bioavailability have been implicated in the development of clinically significant vascular events.
in the present study, we sought to investigate whether acute ethanol intake activates the vascular rhoa/rho kinase pathway in resistance arteries and the role of nad(p)h oxidase-derived ros on such response.
additionally, we evaluated the requirement of p47phox translocation for the activation of nad(p)h oxidase induced by ethanol and the effect of ethanol-induced ros on no production.
ascorbic acid (vitamin c) was chosen as the antioxidant since it has been described to reduce oxidative stress in the vasculature.15,16 methods acute ethanol administration a dose of 1g/kg of ethanol (10 ml/kg of 13% ethanol diluted in water) was administered by gavage to 20 male wistar rats (200-250 g) fasted for 12 h.12,16 blood ethanol levels using this model of ethanol administration are within the range of 20-24 mmol/l.12,16,17 rats from the control group (n=20) received water (gavage).
some rats were treated with vitamin c at a dose of 250 mg/kg (gavage) for 5 days,16,18,19 before administration of water (n=18) or ethanol (n=19).
the sample size was based on previous studies.12,16,17 the mesenteric arterial bed (mab) was isolated from the rats 30 min after ethanol administration.17 all experiments were in accordance with the principles and guidelines of the animal ethics committee of the university of são paulo (#10.1.235.53.0).
detection of o2- in the rat mab lucigenin-derived chemiluminescence assay was performed to measure o2- production in the rat mab as previously described.12 luminescence was measured in a luminometer (orion ii luminometer, berthold detection systems, pforzheim, germany) and the results are expressed as relative light units per mg of protein.
protein concentrations in the samples were measured using the method of lowry (bio-rad laboratories, hercules, ca, usa).
detection of h2o2 in the rat mab in order to measure h2o2 concentration in the rat mab, amplex red® (#a22188, invitrogen, carlsbad, ca, usa) was used as previously described.20 results are expressed as nmol h2o2/mg protein detection of basal nitrate in the rat mab baseline nitrate concentrations of supernatants from mab homogenates was evaluated using a sievers chemiluminescence analyzer (nitric oxide analyser, noatm 280, sievers instruments, co, usa) as previously described.12 results are expressed as µmol/l per mg of protein.
evaluation of superoxide dismutase (sod) and catalase (cat) activities in the rat mab the activity of sod in the rat mab was evaluated using a commercially available kit (#19160, sigma-aldrich, st. louis, mo, usa).
sod activity is expressed as inhibition rate % per mg of protein.
the activity of cat was determined as previously described.12 one cat unit (u) was defined as the amount of enzyme required to decompose 1 µmol of h2o2/min.
evaluation of reduced glutathione (gsh) concentration in the rat mab the concentration of gsh in the rat mab was determined as previously described.12 results are expressed as µg gsh per mg of protein.
evaluation of thiobarbituric acid reactive substances (tbars) in the rat mab the concentration of tbars in the rat mab was determined using a commercially available kit (#10009055, cayman chemical, ann arbor, mi, usa).
results are expressed as nmol per mg of protein.
immunoblotting the rat mab was homogenized in a lysis buffer composed of 50 mmol/l tris-hcl (ph 7.4), np-40 (1%), sodium deoxycholate (0.5%) and sds (0.1%).
samples were centrifuged at 5,000 × g for 10 min (4ºc).
forty micrograms of protein were separated by electrophoresis on a 10% polyacrylamide gel, and transferred onto a nitrocellulose membrane.
skimmed milk 5% diluted in tris-buffered saline solution with tween 20 was used to block nonspecific binding sites (1 h at 24ºc).
membranes were then incubated overnight at 4ºc with the following primary antibodies: p-enos (ser1177) (diluted 1:1000, 9571, cell signaling, danvers, ma, usa), p-enos (thr495) (diluted 1:1000, 9574, cell signaling), total enos (diluted 1:1000, 9572, cell signaling), p-protein kinase b (p-akt) (ser473) (diluted 1:1000, 4058, cell signaling) and total akt (diluted 1:1000, 9272, cell signaling).
membranes were then incubated with secondary antibodies for 90 min at room temperature.
signals were revealed with chemiluminescence and quantified densitometrically.
the results are expressed as the non-phospho/total proteins ratio.
cytosol/membrane fractionation the rat mab was homogenized in lysis buffer containing 50 mmol/l tris-hcl (ph 7.4), 2.5 mmol/l edta, 5 mmol/l egta, and protease inhibitor.
homogenates were centrifuged at 100,000 × g for 1 h, at 4ºc.
the supernatant (cytosolic fraction) was collected.
the pellet, containing the particulate fraction, was resuspended in lysis buffer containing 1% triton x-100 and centrifuged at 10,000 × g for 10 min at 4 °c.
membranes were then incubated with specific antibodies for rhoa (diluted 1:1000, sc-418, santa cruz biotechnology, dallas, tx, usa) or p47phox (diluted 1:500, santa cruz biotechnology) as previously published.21 vascular reactivity experiments male wistar rats were anesthetized with urethane (1.25 g/kg, i.p., sigma-aldrich, st. louis, mo, usa) and killed by aortic exsanguination.
segments of third-branch mesenteric arteries, measuring about 2 mm in length, were mounted in a small vessel myograph (danish myo tech, model 620m, a/s, århus, denmark) as previously described.22 arteries were maintained in krebs henseleit solution [(in mmol/l) 130 nacl, 4.7 kcl, 1.18 kh2po4, 1.17 mgso4, 14.9 nahco3, 5.5 glucose, 0.03 edta, 1.6 cacl2)], at a constant temperature of 37°c, ph 7.4 and gassed with a mixture of 95% o2 and 5% co2.
concentration-response curves to phenylephrine (0.1 nmol/l-100 µmol/l) were performed in endothelium-intact and endothelium-denuded arteries.
the curves for acetylcholine (0.1 nmol/l-10 µmol/l) were performed in endothelium-intact arteries, pre-contracted with phenylephrine (1 µmol/l).
concentration-response curves were fitted using a nonlinear curve fitting program (graph pad prism 3.0; graphpad software inc., san diego, ca).
two pharmacological parameters were analyzed: pd2 (negative logarithm of the molar concentration of the drug producing 50% of the maximum response) and emax (maximum effect elicited by the agonist).
cell culture and stimulation vsmc derived from the mab of male wistar-kyoto rats were isolated and characterized as previously described.23 cells at passages 4 to 8 isolated from at least 5 different primary cell cultures were used.
vsmc were stimulated with ethanol (50 mmol/l, 5 min) in the absence or in the presence of apocynin, a nad(p)h oxidase inhibitor (10 µmol/l, 30 min), tiron (o2- scavenger, 10 µmol/l, 30 min), 4-methylpyrazole (4-mp,10 µmol/l, 30 min), a selective alcohol dehydrogenase (adh) inhibitor, or vitamin c (100 µmol/l, 24 h).
the concentration and period of exposition to ethanol and antioxidants were based on previous studies.12,24 superoxide anion production was measured by lucigenin-enhanced chemiluminescence as described above, and is expressed as percentage increase from baseline values.
statistical analysis data are presented as mean ± standard error of the mean (sem).
groups were compared using one-way analysis of variance (anova) followed by bonferroni's multiple comparison test.
data followed a normal distribution.
results of statistical tests with p<0.05 were considered as significant.
statistical analysis was carried out using the program graph pad prism 3.0 (graphpad software inc., san diego, ca, usa).
results blood ethanol levels as we had previously reported,12,16,17 in this model of ethanol administration, blood ethanol levels vary from 20-24 mmol/l, which are within the range found in the bloodstream of humans after a binge drinking episode.25 effect of acute ethanol intake on o2-, h2o2, tbars, nitrate and gsh levels and sod and cat activities in the rat mab the effect of acute ethanol intake on ros generation and lipid peroxidation in the rat mab was evaluated by assessing the generation of o2 - and h2o2 and the concentration of tbars.
lucigenin-derived luminescence was significantly higher in the mab from ethanol-treated rats, and such response was prevented by treatment with vitamin c (figure 1a).
no changes in h2o2 levels were observed after treatment with ethanol (figure 1b).
vitamin c prevented the increase on tbars concentration induced by acute ethanol intake (figure 1c).
since increased oxidative stress is associated with reduced no bioavailability, we evaluated the effect of acute ethanol intake on nitrate concentration in the rat mab.
ethanol treatment did not alter the baseline levels of nitrate in the rat mab (figure 1d).
in order to evaluate the effect of ethanol on the vascular antioxidant status, sod and cat activities as well as gsh concentrations were determined in the rat mab.
our results showed that treatment with ethanol had no effect on these parameters (figure 2).
figure 1effects of acute ethanol intake on o2-, h2o2 and nitrate levels in the rat mesenteric arterial bed .
vascular levels of o2- (a) and nitrate (d) were determined by chemiluminescence.
vascular h2 o 2 levels were measured fluorometrically (b).
thiobarbituric acid reactive substances (tbars) concentration was determined colorimetrically (c).
results are presented as means ± sem of 6-9 experiments.
*compared to control, control plus vitamin c and ethanol plus vitamin c (p<0.05, anova).
figure 2effects of acute ethanol intake on superoxide dismutase (sod) and catalase (cat) activities and reduced glutathione (gsh) levels in the rat mesenteric arterial bed.
sod and cat activities (a and b) and gsh levels (c) were determinate colorimetrically.
results are presented as means ± sem of 6-8 experiments.
effect of ethanol on o2- generation in cultured mab vsmc the antioxidant effect of vitamin c was tested in cultured mab vsmc.
vitamin c prevented the increase on o2- generation induced by ethanol (50 mmol/l, 5 min) in cultured vsmc.
to test the role of an ethanol metabolite on ethanol-induced o2- generation, the cells were incubated with 4-mp, an adh inhibitor.
4-mp prevented ethanol-induced o2- generation in cultured vsmc.
apocynin and tiron also prevented the generation of o2- induced by ethanol (figure 3).
figure 3effect of tiron, apocynin, 4-mp and vitamin c on ethanol-induced o2- generation in cultured vsmc of the rat mesenteric arterial bed .
cells were stimulated with ethanol (50 mmol/l, 5 min) in the absence or after incubation with tiron (10 µmol/l, 30 min), apocynin (10 µmol/l, 30 min), 4-methylpyrazole (4-mp) (10 µmol/l, 30 min) or vitamin c (100 µmol/l, 24 h).
the bars represent the mean ± sem of 7-11 experiments.
* compared to vehicle (p<0.05, anova).
evaluation of akt and enos phosphorylation in the rat mab our findings showed no alteration in the phosphorylation of akt at ser473 residue or enos at ser1177 and thr495 residues after acute ethanol intake or treatment with vitamin c (figure 4).
figure 4effects of acute ethanol intake on protein kinase b (akt) and endothelial nitric oxide synthase (enos) phosphorylation in the rat mesenteric arterial bed .
top panels: representative immunoblots for akt and enos protein phosphorylation and expression.
bottom panels: corresponding bar graphs showing densitometric data for phosphorylation of akt at ser473 residue (a), enos at ser1177 residue (b) and enos at thr495 residue (c).
results are presented as mean ± sem of 4-6 experiments.
evaluation of p47phox and rhoa translocation in the rat mab since nad(p)h oxidase is the major source of ros in the vasculature, and nad(p)h-derived ros induce activation of the rhoa/rho kinase signaling pathway, we evaluated the effect of ethanol on p47phox and rhoa translocation.
mab from ethanol-treated rats displayed a significant increase in the membrane/cytosol fraction ratio of p47phox (figure 5a) and rhoa expression (figure 5b), indicating the translocation of the proteins.
treatment with vitamin c prevented the increase in p47phox and rhoa translocation induced by ethanol.
figure 5effects of acute ethanol intake on p47phox and rhoa translocation in the rat mesenteric arterial bed (mab).
bar graph represents translocation of p47phox and rhoa as a ratio of membrane/cytosol expression (a and b) in the rat mab.
top panels: representative immunoblots.
results are presented as mean ± sem of 5-7 experiments.
*compared with control, control plus vitamin c and ethanol plus vitamin c (p<0.05, anova).
experiments on vascular reactivity of mesenteric artery ethanol treatment did not affect acetylcholine-induced relaxation (emax: 98.3 ± 1.5%; pd2: 8.2 ± 0.2, n=6), when compared to control (emax: 100.3 ± 2.3%; pd2: 8.1 ± 0.4, n=6), control plus vitamin c (emax: 98.6 ± 1.8%; pd2: 8.1 ± 0.2, n=4) and ethanol plus vitamin c (emax: 99.8 ± 0.4%; pd2: 7.8 ± 0.3, n=5) groups (figure 6) .
in endothelium-intact arteries, acute ethanol intake had no effect on contraction (% kcl 120 mmol/l) induced by phenylephrine (emax: 138.8 ± 10.4%; pd2: 5.9 ± 0.3, n=5), when compared to control (emax: 136.3 ± 10.3%; pd2: 6.3 ± 0.2, n=4), control plus vitamin c (emax: 112.9 ± 2.4%; pd2: 6.3 ± 0.1, n=4) and ethanol plus vitamin c (emax: 122.3 ± 7.7%; pd2: 6.1 ± 0.1, n=6) groups.
similarly, ethanol treatment did not alter the contraction induced by phenylephrine in endothelium-denuded arteries (emax: 135.1 ± 7.2%; pd2: 6.1 ± 0.1, n=6), when compared to control (emax: 120.7 ± 5.5%; pd2: 6.1 ± 0.3, n=5), control plus vitamin c (emax: 116.3 ± 3.5%; pd2: 5.7 ± 0.1, n=4) and ethanol plus vitamin c (emax: 144.3 ± 10.4%; pd2: 6.1 ± 0.3, n=5) groups.
figure 6effects of acute ethanol intake on vascular reactivity to acetylcholine and phenylephrine.
concentration-response curves for acetylcholine were performed in endothelium-intact third branch mesenteric arteries (a).
concentration-response curves for phenylephrine were obtained in endothelium-intact (endo+, b) or endothelium-denuded (endo-, c) arteries.
results are presented as means ± sem of 4 to 6 experiments.
discussion the present findings show that acute ethanol intake induces rhoa translocation and nad(p)h oxidase activation by promoting p47phox translocation in resistance arteries.
despite increasing ros generation, acute ethanol intake does not affect no synthesis or bioavailability in resistance arteries.
the relevance of our findings is strengthened by previous studies of our group that showed that using this same model of ethanol administration, plasma ethanol levels are within the range of 20-24 mmol/l12,16,17 which corresponds to that found in humans after a "binge drinking" session ,25 and in rats 30 min after oral administration of ethanol.26 our findings demonstrated that ethanol increased o2- generation in the rat mab, which is in accordance with previous results from our laboratory.12 additionally, increased lipid peroxidation was observed in the rat mab after ethanol intake.
the lucigenin-derived chemiluminescence assay is based on the enzymatic action of the enzyme nad(p)h oxidase.27 in this sense, the increase in chemiluminescence here described suggests that the enzyme nad(p)h oxidase is an important source of acute ethanol-induced o2- generation in resistance arteries.
this idea is supported by the fact that apocynin inhibited ethanol-induced o2- generation in cultured vsmc.
vitamin c is an effective scavenger of o2-28 and in our model it decreased ethanol-induced o2- generation and lipid peroxidation in resistance arteries.
the antioxidant property of vitamin c is also associated with decreased activation of nad(p)h oxidase.15 in cultured vsmc, vitamin c prevented ethanol-induced o2- generation, suggesting that the inhibition of nad(p)h oxidase by vitamin c may also be implicated in diminishing ethanol-induced vascular o2- generation.
adh is an ethanol-metabolizing enzyme that is functionally active in the vasculature.29 we have previously described that ethanol metabolites are involved in the vascular effects elicited by ethanol.30 in order to determine a possible role for ethanol metabolites on o2- generation induced by ethanol in resistance arteries, we evaluated the effect of 4-mp on this process.
inhibition of ethanol metabolism mediated by adh led to a decrease in ethanol-induced o2- generation in cultured vsmc.
thus, we present evidence that an ethanol metabolite, possibly acetaldehyde, is responsible for ros generation in resistance arteries.
nad(p)h oxidase is the major source of ros in the vasculature.
the prototypical phagocytic nox comprises five subunits: three cytosolic regulatory subunits, p40phox, p47phox and p67phox and two membrane-associated components named gp91phox (nox2) and p22phox.
the enzymatic complex is dissociated in resting cells but it is rapidly activated upon cellular stimulation.
phosphorylation of p47phox at a serine residue initiates the activation of the enzyme, triggering the formation of a complex composed by the cytosolic subunits.
this response is followed by translocation of the cytosolic complex to the membrane and association with gp91phox and p22phox subunits (cytochrome b558).
nad(p)h oxidase components are expressed in endothelial and vsmc, and translocation of the p47phox subunit has been shown to be essential for ros production in these cells.31 in our study, the translocation of p47phox was increased in mab from ethanol-treated rats, and this effect was inhibited by vitamin c, suggesting that oxidative stress is involved in ethanol-induced p47phox translocation and nad(p)h oxidase activation.
moreover, this observation strengthens our initial idea that nad(p)h oxidase is implicated in ethanol-induced o2- generation in the rat mab.
the inhibitory action of vitamin c on p47phox translocation has been previously described.32 mechanisms whereby vitamin c inhibits the translocation of p47phox are ill defined, but may involve the inhibition of nad(p)h oxidase activators.
a large number of proteins are involved in nad(p)h oxidase assembly.
these include rac gtpases, protein kinase c (pkc) and c-src.11 papparella et al.32 showed that vitamin c inhibited pkc activation with subsequent reduction in p47phox translocation and ros generation.
the current study did not address the exact mechanism whereby ethanol modulates nad(p)h oxidase activity.
different stimuli, such as endothelin-1, angiotensin ii, catecholamines, thrombin and growth factors (eg.
: epidermal and growth factor and platelet-derived growth factors ) acutely activate nad(p)h oxidase in the vasculature.33 we have previously shown that losartan, an antagonist of at1 receptors, did not prevent ethanol-induced ros generation in the rat mab,12 ruling out a role for angiotensin ii in ethanol-induced nad(p)h activation here described.
future studies designed to address how acute ethanol intake induces p47phox translocation and ros generation in resistance arteries are of interest.
superoxide anion is a highly unstable molecule that is reduced by sod to h2o2.34 in our study, the antioxidant action of vitamin c was not related to an increase in sod activation, since no difference on sod activity was observed in the mab after treatment with the vitamin .
in addition , since ethanol treatment did not alter sod activity , the ethanol-induced increase in o2- levels seems not to be related to decreased dismutation of o2- by sod.
although both o2- and h2o2 act as signaling molecules, h2o2 is considered the main signaling compound because of its relative stability and sub-cellular localization.34 for example, h2o2 activates redox-signaling sensitive pathways such as mapk and rho kinase.35 h2o2 is tightly regulated by intracellular and extracellular enzymes, including cat, which converts h2o2 into water and o2.
our findings showed that acute ethanol intake did not alter either h2o2 levels or cat activity in the rat mab.
endothelial dysfunction is caused by an increase in ros generation and a reduction of endothelial no bioavailability, by increasing the oxidative inactivation of no and/or by decreasing its synthesis.
in the vascular endothelium no is synthesized by enos.
akt, a serine/threonine kinase, phosphorylates enos thereby activating the enzyme.36 phosphorylation of enos at ser1177 residue is a critical requirement for enos activation, whereas phosphorylation at thr495 residue leads to inactivation of the enzyme.36 here we demonstrated that ethanol had no effect on the akt/enos phosphorylation, which corroborated the observation that ethanol intake did not alter the concentration of nitrate in the rat mab.
ethanol induces a transient increase in the activity of both sod and cat and this response can shift the balance ros/no towards no levels.37 in this regard , ethanol-induced increase in antioxidant defenses could explain the lack of effect of ethanol on nitrate levels in the rat mab.
however, acute ethanol intake did not alter gsh levels or sod and cat activities in the rat mab, indicating that the treatment did not affect the cellular antioxidant capacity.
nad(p)h oxidase-derived ros in the vasculature activate redox-sensitive targets such as rhoa/rho kinase.
superoxide anion and h2o2 activate the rhoa/rho kinase pathway, which represents an important class of redox-regulated signaling molecules in the cardiovascular system.13 the rhoa/rho kinase pathway regulates many intracellular signaling pathways in the vasculature.
rho cycles between the gdp-bound inactive form located in the cytoplasm and the gtp-bound active form in the cell membrane,38 and rhoa translocation to the membrane is associated with its activation.
the present findings showed that ethanol intake increased rhoa translocation, further suggesting an activation of the rhoa/rho kinase pathway.
also , the fact that vitamin c prevented ethanol-induced rhoa translocation suggests that this response is mediated by ros.
this result is in agreement with previous findings showing that ros, most notably o2 - and h2o2, are linked to the activation of the rhoa/rho kinase pathway.39 to the best of our knowledge, this is the first study demonstrating a direct interaction among ethanol intake, nad(p)h oxidase-derived ros and the activation of the rhoa/rho kinase signaling pathway.
rhoa is abundantly expressed in vsmc and participates in vasoconstriction via phosphorylation of myosin light chain and sensitization of contractile proteins to calcium.
additionally, increased rhoa activation has been linked to endothelial dysfunction, increased peripheral vascular resistance and hypertension.40 despite the activation of the rhoa/rho kinase signaling pathway, acute ethanol intake did not affect the contractile response induced by phenylephrine or the endothelium-dependent relaxation induced by acetylcholine in the mesenteric artery.
these results suggest that rhoa activation here described probably occurs before the onset of severe functional abnormalities.
some limitations for the present study should be considered.
in our study, all parameters were evaluated when ethanol reached its maximal plasma concentration.
the period of action of ethanol in the vasculature after a single dose was not evaluated.
thus, studies on the time-course effect of a single dose administration of ethanol are of interest.
another point that should be considered is that while "binge drinking" in humans is broadly defined as the consumption of a large amount of ethanol (4-5 standard drinks) in a two-hour period, in our study the total amount of ethanol (1g/kg) was administered in a single dose.
activation of nad(p)h oxidase with subsequent increase in ros generation and activation of redox-sensitive signalling pathways, such as the rhoa/rho kinase pathway, are important events linked to vascular dysfunction and are described to play a role in the pathophysiology of several cardiovascular diseases.9,11,13 binge drinking is associated with a heightened risk of cardiovascular events, such as stroke, sudden death, myocardial infarction, increased mortality after myocardial infarction,2-4 and with progression of carotid atherosclerosis.1 importantly, changes in vascular biology are key mechanisms underlying the increased risk of adverse cardiovascular events induced by binge drinking.6 thus, our findings raise the possibility that not only chronic ethanol intake is a risk factor for cardiovascular events, but also acute ethanol intake may increase the risk for vascular injury by increasing ros generation and activation of redox-sensitive pathways.
altogether, these responses trigged by ethanol could predispose to the development of cardiovascular diseases.
conclusions in summary, the major new finding of the present study is that acute ethanol intake induces activation of the rhoa/rho kinase pathway by a mechanism that involves ros generation.
additionally, we first demonstrated that ethanol activates nad(p)h oxidase by induction of p47phox translocation and by redox-sensitive mechanisms in resistance arteries.
@highlight
background the mechanism underlying the vascular dysfunction induced by ethanol is not totally understood.
identification of biochemical/molecular mechanisms that could explain such effects is warranted.
objective to investigate whether acute ethanol intake activates the vascular rhoa/rho kinase pathway in resistance arteries and the role of nad(p)h oxidase-derived reactive oxygen species (ros) on such response.
we also evaluated the requirement of p47phox translocation for ethanol-induced nad(p)h oxidase activation.
methods male wistar rats were orally treated with ethanol (1g/kg, p.o.
gavage) or water (control).
some rats were treated with vitamin c (250 mg/kg, p.o.
gavage, 5 days) before administration of water or ethanol.
the mesenteric arterial bed (mab) was collected 30 min after ethanol administration.
results vitamin c prevented ethanol-induced increase in superoxide anion (o2-) generation and lipoperoxidation in the mab.
catalase and superoxide dismutase activities and the reduced glutathione, nitrate and hydrogen peroxide (h2o2) levels were not affected by ethanol.
vitamin c and 4-methylpyrazole prevented the increase on o2- generation induced by ethanol in cultured mab vascular smooth muscle cells.
ethanol had no effect on phosphorylation levels of protein kinase b (akt) and enos (ser1177 or thr495 residues) or mab vascular reactivity.
vitamin c prevented ethanol-induced increase in the membrane: cytosol fraction ratio of p47phox and rhoa expression in the rat mab.
conclusion acute ethanol intake induces activation of the rhoa/rho kinase pathway by a mechanism that involves ros generation.
in resistance arteries, ethanol activates nad(p)h oxidase by inducing p47phox translocation by a redox-sensitive mechanism.
