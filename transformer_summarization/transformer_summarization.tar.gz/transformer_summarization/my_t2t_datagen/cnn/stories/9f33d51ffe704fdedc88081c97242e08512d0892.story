1. background it was first suggested in the 1980s that dna could be used to build nanostructures through self-assembly of oligonucleotides by complementary base pairing [1].
in a dna nanostructure, the base sequence of each dna strand is designed to ensure that it binds in the correct position and performs its intended function.
static dna nanostructures described in the literature include polyhedra [2–4], tiles [5], solid blocks [6] and twisted or curved shapes [7].
dna can also be used to make dynamic nanomachines that are capable of undergoing a change of state or conformation.
many such devices are driven by toehold-mediated strand displacement [8–10].
for this process, the initial state (figure 1a) consists of a double-stranded dna construct with a short single-stranded toehold domain, and a single-stranded dna invader that is complementary to the longer of the two strands in the main construct.
the toehold-binding domain of the invader binds to the toehold, and then branch migration occurs.
eventually, the invading strand displaces the incumbent, leading to a final state that consists of a complete double helix and a shorter single-stranded molecule.
figure 1.
(a) toehold-mediated strand displacement.
an invader binds to the toehold (blue) and displaces the shorter incumbent via branch migration.
(b) the underlying principle of the rotary motor concept described in this paper.
the motor consists of two ‘wheels’ (grey squares); each wheel has a ‘tape’ wrapped round it.
the two tapes are mainly complementary and are designed to displace each other from the wheels.
this is intended to exert torque on the wheels, causing them to turn.
(c) the dna structures and devices studied in this paper.
from left to right: linear construct, triangle, rotary motor (based on two squares).
the motor is shown with the brake applied.
the brake consists of a pair of blocking strands (bright blue) and it is released through displacement of the blocking strands by the unblocking strands (lilac).
for clarity, parts of the motor that are irrelevant to the operating mechanism are not shown.
the motor is illustrated in more detail in figure 4 and the electronic supplementary material.
(d) operation of a quartz crystal microbalance with dissipation monitoring.
the piezoelectric crystal oscillates, driven by an applied voltage.
the generated acoustic wave propagates into solution through a layer of surface-immobilized molecules.
the frequency and energy dissipation of the wave reflect the mass and structure of the layer.
this exchange of strands can be used to operate molecular machinery, such as ‘dna tweezers’ that open and close [11] and bipedal ‘walkers’ [12].
in some dna motors, restriction enzymes are an integral part of the operating mechanism, and may be used in combination with strand displacement reactions to control molecular motion [13].
strand displacement has been studied extensively in solution [8–10], and the effect of surface immobilization on the phenomenon has also been investigated [14].
the design of synthetic motors made from dna is often inspired by their naturally occurring protein counterparts, such as kinesin.
however, most synthetic dna motors move linearly, rather than in a rotary manner, despite the presence in nature of highly efficient rotary machines such as atp synthase [15].
several non-autonomous dna rotary motors have been presented, but these require external intervention to drive them from one state to the next.
for instance, yan et al.
described a dna machine consisting of a tile that underwent a conformational change involving rotation when particular strands were added [16], whereas rajendran et al.
presented a device in which the transition between right-handed and left-handed forms of dna was used to induce rotation [17].
it has also been shown that it is possible to make a dna rotary motor based on a catenane, a molecule consisting of interlocked rings [18].
in 2004, tian and mao presented a device that consisted of two counter-rotating wheels made from dna [19], but this was not capable of autonomous operation, because dna strands needed to be added to the reaction mixture in a particular order to drive rotation.
by contrast, the machine presented here can rotate independently and does not require external intervention after the initial brake has been released.
in 2016, ketterer et al.
reported the synthesis of a ‘nanoscale rotary apparatus formed from tight-fitting three-dimensional dna components’ [20]; in that work, the rotation was not driven and occurred at random simply as a result of brownian motion.
it has been suggested that coordinated opening and closing of hairpins could be used to drive an autonomous rotary dna motor [21], but this idea has not been tested experimentally.
in addition, the mechanism is likely to be affected significantly by unintended ‘leak’ reactions, processes that result from unintended molecular interactions and disrupt the operation of the system.
this paper describes the experimental study of the putative mechanism of an autonomous rotary dna motor, through a series of experiments in which the underlying principles were tested and a prototype of the motor was examined.
the motor is designed to be driven by sequential strand displacement reactions, and the concept is explained in the methods section, in which the experimental procedures are also described.
dna molecules immobilized on a gold surface were studied using a quartz crystal microbalance with dissipation monitoring, and gel electrophoresis was used to provide complementary tests on the solution-phase motor.
the experimental results were consistent with the motor operating as intended, but the methods used here did not allow rotation to be seen directly.
the aims of the present study were: (i) to validate the hypothesis that sequential strand displacement reactions could catalyse significant structural rearrangement in a folded dna construct on a surface; and (ii) to construct a rotary motor prototype based on this idea, confirming that it undergoes a structural transition as a result of strand displacement.
further experiments on an enhanced motor design may build on this work by imaging rotation with single-molecule resolution, and this is discussed towards the end of the paper.
2. methods 2.1. motor concept the rotary motor mechanism described in this paper is based on two wheels that counter-rotate autonomously, driven by sequential strand displacement reactions in which complementary domains of two tapes become hybridized.
this concept is illustrated in figure 1b.
in its most general form, the motor features two ‘tapes’, each of which is wrapped around a ‘wheel’ and held in place by base pairing between complementary domains.
the centres of the two wheels are at fixed positions, and the ends of the tapes are hybridized, such that the two wheels are connected via the tapes.
the two tapes are mainly complementary, and the hybridized ends will subsequently act as a remote toehold [22] for the reaction in which the tapes mutually displace each other from the wheels.
the tapes do not hybridize spontaneously owing to the presence of short non-complementary sections and associated blocking strands adjacent to the toeholds.
this ‘brake’ mechanism is not shown explicitly in figure 1b, but is illustrated in figure 1c.
when the brake is released, strand displacement can commence, through branch migration.
as the tapes proceed to bind to each other, they unwrap themselves from the wheels.
this causes torque to be exerted, and the wheels turn in opposite directions.
the joint through which a wheel is attached to a substrate must be able to accommodate rotation.
to address this, the design features a polythymine linker, which is flexible and will not form significant secondary structure motifs.
despite the flexibility of this linker, it is desirable to avoid a situation in which the centres of the two wheels need to move closer together during rotation, as would occur if the tape were to be arranged in a flat spiral configuration.
this problem can be eliminated by the use of three-dimensional wheels, where the diameter of the wheels does not change significantly during rotation.
here, the wheel is a multilayer structure, and tape is unrolled from one layer in each rotation.
inspection of the sketch in figure 1b reveals that the underlying mechanism of rotation in this motor is a series of strand displacement reactions.
consecutive domains of a long strand are displaced in order as branch migration occurs.
to test this principle in isolation, the linear construct shown in figure 1c was examined.
the reaction observed in this case differs from conventional strand displacement only in that there are two nicks in the molecule, where a nick is a break in one of the sugar–phosphate backbones of the duplex (figure 2a).
to ascertain whether this reaction also occurred successfully in a molecule that was folded into a geometrically constrained configuration, the triangle structure (figure 1c, centre) was probed.
the culmination of the work described in this paper was the study of the motor prototype shown in figure 1c (right-hand side).
figure 2.sequential strand displacement in a linear complex.
(a) representation of the process to be examined, showing presence of nicks in the duplex backbone.
cs is the capture strand.
‘block’ strands block certain domains in x, where x is the target for the invader.
the ‘block’ strands are displaced from x by the invader, and block-3 remains attached to cs at the end of the reaction.
(b) qcm-d data for assembly of test construct and application of a single invader that displaces multiple strands.
sketches show the expected nature of the surface-immobilized molecules at the time the corresponding plateau is reached.
the experimental techniques used in this investigation are described below.
2.2. quartz crystal microbalance with dissipation monitoring a quartz crystal microbalance with dissipation monitoring (qcm-d) [23] was used to study the behaviour of the dna constructs.
the qcm-d apparatus can measure small changes in the mass of a layer of surface-immobilized molecules and is based on a sensor consisting of a piezoelectric quartz crystal with a gold electrode on either side.
application of an ac voltage causes the crystal to oscillate, with the result that an acoustic wave propagates into the solution above it.
the crystal is driven at its resonant frequencies or overtones, of which there are typically several.
an increase in oscillation frequency indicates that mass has been removed from the crystal surface, while a decrease in frequency implies a mass increase.
to measure the energy dissipated as the acoustic wave propagates through the molecular layer and into solution, the driving voltage is switched off and the decay of the amplitude is measured.
the dissipation is related to the time constant of the decay.
generally, high dissipation implies a rather viscoelastic layer, while low dissipation implies that the layer is rigid.
this paper focuses primarily on the frequency measurements, which mainly reflect changes in surface-immobilized mass.
the dissipation measurements provide some limited additional insight.
for this investigation, all experiments were performed in a buffer of 1×te with 1m nacl.
unless otherwise stated, the pump flow rate was kept at 20 μ l min−1 except when the pump was switched off during sample changing.
a q-sense e4 system was used (best sensitivity 0.5 ng cm−2), with gold-coated sensors (qsx301, fundamental frequency 5 mhz), all supplied by biolin scientific.
sensors were cleaned immediately before each experiment using the procedure described in [14].
2.3. gel electrophoresis agarose gel electrophoresis was performed using a gel containing 2% w/v agarose (promega), with 1×tae buffer (made from 10× stock), using a multisub midi gel kit from scientific laboratory supplies with a bio-rad powerpac basic.
before cooling, sybr safe dye (invitrogen) was added to the molten gel for staining and after running the gel was scanned with a bio-rad chemidoc mp imager.
the gel was run at 75 v for 45 min.
polyacrylamide gel electrophoresis was performed using a bio-rad precast gel (10%, tbe) and mini protean kit with 1×tbe buffer from fisher scientific.
the gel was run at 100 v for 60 min on a laboratory bench, with two ice packs attached to the gel tank to prevent overheating.
staining was performed for a few minutes using sybr safe stain from invitrogen (1×, diluted with ultrapure milliq water) and the gel was scanned using a bio-rad chemidoc mp imager.
the two techniques used here are complementary—qcm-d provided time-resolved measurements of motors immobilized on a surface, whereas gel electrophoresis was used to examine the static configuration of the molecular machines before and after operation in solution.
qcm-d is a very powerful technique and can be used to measure continuously for hours with very high time resolution.
both are ensemble measurements, and both are label-free, avoiding the question of whether the addition of a label could affect the behaviour of the device under investigation.
qcm-d and gel electrophoresis both allow multiple samples to be studied in parallel, and only a minimal amount of prior information is needed to design the experiments, which is extremely useful for the study of a molecular machine that has never previously been tested.
little data processing is required for either experiment.
gel electrophoresis is well established in dna nanotechnology, but qcm-d is less widely known in this area.
recent studies have suggested that qcm-d has considerable potential for the study of dna structures and machines [14,24] and this work provides further evidence for this.
2.4. materials all chemicals were acquired from sigma aldrich unless otherwise stated.
dna oligonucleotides were purchased from integrated dna technologies.
they were resuspended in 1×te, typically to a concentration of 100 μm, and usually stored thereafter at −20°c.
sequences of individual strands and further details are given in the electronic supplementary material, together with the recipes used to prepare all of the samples.
3. results and discussion 3.1. sequential strand displacement in a linear complex to test the hypothesis that a single long invader could displace multiple strands from an immobilized target complex, the system depicted in figure 2a was studied using qcm-d. the first stage of the experiment involved immobilization of a ‘capture complex’ via chemical bonds made between the gold surface and a thiol modification at one end of the complex.
the capture complex itself comprised two strands, called cs and block-3.
as the capture complex was immobilized, the frequency decreased (figure 2b), owing to the increase in the mass attached to the sensor.
in the second step, the dna molecule x was added, where x had the correct sequence to bind to the capture complex, leaving a long single-stranded overhang, as illustrated.
next, two more dna strands were added, and these bound to the overhang, leaving only a short single-stranded toehold.
further decreases in frequency were observed (figure 2b), corresponding to additional increases in mass.
the final step was the addition of an invading strand, which bound to the toehold and displaced all three of the blocking strands from the long strand in the immobilized complex, resulting in loss of the strands x, block-2 and block-1 from the surface.
the frequency change observed during the displacement reaction was approximately 55% of that measured during binding of the strands x, block-2 and block-1.
this implies that the sequential strand displacement process was not 100% efficient, as expected—surface-specific phenomena interfere with processes that occur in immobilized molecules, and decrease the efficiency of the reaction.
however, the final baseline was higher than the value observed (at around 70–90 min) for the plateau corresponding to the construct comprising cs, block-3 and x, which would not be possible if only block-1 had been displaced from the immobilized constructs.
the data were therefore consistent with the hypothesis that a single invader can displace multiple targets within the same surface-immobilized molecule, justifying the subsequent experiments and development of a motor based on this concept.
3.2. sequential strand displacement in a folded structure qcm-d experiments were also performed on a geometrically constrained structure, formed by using two 23 nt oligonucleotides to fold a 73 nt oligonucleotide (t) into a triangular configuration (figure 3a).
the shorter strands were named ‘staples’, following the convention of dna origami [5].
surface-immobilization of this structure was achieved via hybridization of the triangle strand with a pre-immobilized capture strand (cs), as shown in figure 3a.
figure 3.observing strand displacement in a folded nanostructure.
(a) schematic diagram of the triangle structure.
the long strand t had six domains (t, d, c, b, a, rc-cs), separated with t triplets where necessary.
the long strand t was folded into a triangular conformation by means of two shorter strands (bd-staple) and (ac-staple) and the triangle could be immobilized through attachment to the cs strand.
(b) qcm-d data which illustrate immobilization of strand cs and either isothermal on-surface assembly of triangles (t+s) or attachment of pre-folded triangles (f(t)).
control strands were used to test whether the triangle had assembled correctly.
(c) strand displacement in the nanotriangles.
the immobilized triangles were exposed to unfolded or folded reverse complements, which bound to their targets and induced displacement.
red lines: smoothed data (50 point adjacent average filter).
(d) dissipation changes as a function of frequency changes for the time period shown in part (c).
a 20 point adjacent-averaging smoothing filter was used.
figure 3b presents the overtone-normalized frequency shifts observed with qcm-d during the assembly of a triangle in situ on the surface (in part 1) and immobilization of pre-folded triangles (in parts 2 and 3), followed by the application of control strands designed to bind to free domains in the immobilized structures.
the bottom two panels of figure 3b show the application of the same molecules in parallel.
the first phase of all three experiments performed was the immobilization of cs alone, corresponding to a frequency decrease of 3–5 hz.
the variation observed is attributable to uncontrollable minor differences between the sensors.
the top panel of figure 3b relates to the experiment in which the triangle was folded isothermally on the surface.
after immobilization of cs, the strand t was supplied, leading to a decrease in frequency as t hybridized to cs.
for rigid layers immobilized on the surface of a qcm-d sensor, the sauerbrey equation (commonly used in analysis of qcm data [23]) predicts that the overtone-normalized frequency shift should be directly proportional to the change in the surface mass density.
however, it will be seen that δf13/13 did not scale with the molecular mass of the oligonucleotides added; the strand t contains 73 nt and its addition induced a shift of approximately 8.5 hz, which is just over half of what would be expected based on the shift of approximately 3.5 hz observed for the 16 nt strand cs.
this implies either that not all of the cs oligonucleotides captured a t or that the sauerbrey equation does not apply here, which would be unsurprising owing to the non-rigid nature of the surface-immobilized layer of biomolecules.
the addition of the staple strands resulted in a further frequency decrease, corresponding to an additional increase in immobilized mass.
this was associated with an increase in dissipation, indicative of conformational change.
control experiments (described below) suggested that no triangle domains were left single-stranded and no staples were half-bound, consistent with proper folding of the triangle.
these results are interesting in their own right because they suggest that it is possible to assemble a complex structure on the surface isothermally.
it is likely that the staples cooperate during folding, because the binding of one staple will bring into closer proximity the binding sites for the next, which will then be able to bind more easily [25,26].
after folding, the dissipation values were comparatively high, approaching two units for the cs-t complex, and this implies that the sauerbrey equation should not be used here because the layer is viscoelastic rather than rigid [27].
in fact, the shift in frequency resulting from addition to the staples was higher than would be predicted from the sauerbrey equation.
if a linear relationship existed between frequency changes and mass, the results would imply that 1.25 copies of each staple had bound to each t molecule, and because that is impossible, this result represents a further indication that the sauerbrey equation does not apply in this regime.
this is to be expected for a layer of biological molecules, which have a complex three-dimensional structure and dissipate acoustic energy, displaying viscoelastic behaviour.
the data presented in the bottom two panels of figure 3b show immobilization of a pre-folded triangle by hybridization with cs.
the frequency shift will be seen to be greater in magnitude than the combined shifts induced by application of t and s in the top panel, suggesting that the use of pre-folded triangles may lead to a higher-density molecular layer.
in all cases, it was necessary to test whether the triangle structures had folded completely.
two primary folding ‘errors’ are conceivable.
either a staple could be ‘half-bound’, where one domain is attached to the triangle and the other is single-stranded, or it could be missing completely.
in all three experiments, to test for these errors, control strands were applied after the supposed formation of a surface-immobilized layer of folded triangles (figure 3b, all graphs, section marked ‘controls’).
the sensor was supplied in turn with a series of control samples containing strands that should either bind to a free domain of a staple, or a free domain of the t strand.
in all cases, minimal frequency shifts were observed, attributable to changes in the mixture of molecules passing over the sensors rather than the binding of any strand to the surface-immobilized constructs.
this suggested that all structures were indeed completely folded, including the triangle folded isothermally in situ on the surface.
use of the online analysis package nupack [28] confirmed that 96% or more of the control strands should hybridize to their target domains, if available, and although this simulation uses the energy parameters established for solution-phase reactions, it provides a good indication that this control experiment is sound.
strand t* was complementary to strand t, and the exposure of folded triangles to t* resulted in some unfolding of t (figure 3c, left and centre panels).
the data show a drop in frequency that corresponds to binding of t*, followed by an increase as staples are displaced and t unfolds.
the same effect was observed for the application of t* strands that had been folded up into triangles in the same way as t. in all cases, the loss of mass resulting from unfolding was significant although comparatively small, and the timescale was long (many tens of minutes).
the amount of mass lost appeared to vary between the three cases.
the data presented here do indicate that strand displacement is possible in a structure that is geometrically constrained, an important result for the rotary motor concept.
however, the results also suggest that the efficiency of the reaction can be quite low.
this may be associated with molecular crowding effects, which are known to have an effect on strand displacement on surfaces [14].
importantly, it was necessary for t* to displace at least three staple domains before any staples could be lost, and this means that at least some of the triangles were partly or entirely unfolded by t*.
it would not have been possible for displacement of any domain to be initiated prematurely by the interaction between aaa and ttt domains in the t and t* strands, because at-rich toeholds 3 nt in length do not permit displacement in surface-immobilized dna machines [14].
figure 3d shows that dissipation and frequency changes are not perfectly correlated.
this is an interesting result because it implies that the structure of the molecules is changing independently of the changes in mass, which is exactly what would be expected from unfolding of triangles.
it has been demonstrated that the acoustic ratio (δd/δf) can be used as a measure of the conformation of dna molecules on surfaces [24], but it is difficult to use this a priori without any reference structures.
3.3. rotary motor the rotary motor prototype is shown in figures 1c and 4a.
it was assembled in stages in solution from a number of oligonucleotides, as described in the electronic supplementary material.
it consisted of two squares (a and b), made from ‘tape’ strands and staples that held the tape strands in place.
the design principles are the same as for the triangle presented in the previous section.
the two squares were linked, as shown.
the domains adjacent to the linked sections were not complementary and were hybridized to blocking strands.
release of the blocking strands allowed the hybridized domains to act as a remote toehold for initiation of strand displacement, driving rotation of the motor.
each tape actually consisted of a series of three oligonucleotides, joined together by hybridization of connecting domains that protruded from the wheels like spokes.
for clarity, these spokes are not shown in the figures because they are irrelevant to the reaction mechanism, but they are illustrated in the electronic supplementary material.
the spokes remained double-stranded and did not change partners throughout motor operation.
they were not expected to interfere with rotation because each spoke could pass over or around the other wheel.
figure 4.the rotary motor.
(a) schematic diagram of the motor which shows how it was constructed.
the staple strand names begin with ‘st’ or ‘str’.
the tape for square a is made from three strands (squarea_1, squarea_2 and squarea_3) as is the tape for square b (squareb_1 or squareb_1mmwa, squareb_2 and squareb_3).
in each square, these strands are connected through connection domains (not shown here) that protrude like spokes from the motor.
as described in the text, the connection domains are irrelevant to the motor mechanism because they remain inert throughout operation, but they are shown explicitly in the electronic supplementary material.
apart from the connection domains and the domains marked in red, the tapes are complementary to each other.
(b) the structure used to immobilize a square.
(c) agarose gel which shows the assembly of the surface connector illustrated in (b), the two folded squares and an unfolded square (made from only the tape strands, without any staples).
(d) polyacrylamide gel which shows the most important bands for the indicated samples: unfolded square of type b, folded squares of both types and assembled motor—‘before’ and ‘after’ operation.
(e) qcm-d data which show strand displacement in motor components or the operation of the motor.
note that the graphs have different y-axis scales but all show the same time window.
the labels at the bottom of the figure show what structure was immobilized on the surface, and the coloured bands above the plots indicate what was applied to the sensors, where ‘unbl’ refers to an unblocking strand.
the sections of the plot shaded in yellow correspond to mass loss from the surface, resulting from displacement.
binding and unblocking events are marked.
red lines: smoothed data (100-point adjacent average filter).
(c–e) samples are described using simplified sketches and abbreviations—f denotes ‘folded’, u denotes ‘unfolded’, open square denotes ‘square’, ‘unbl’ denotes ‘unblocking strand’.
the squares were immobilized on a surface via the structure shown in figure 4b, which includes the thiolated strand cs.
the assembly of the tapes from their constituent parts, the surface-immobilization connector and the squares themselves was confirmed prior to immobilization using agarose gel electrophoresis (figure 4c).
it was not feasible to test assembly using qcm-d in the same way as for the triangle, because, in this case, the incorporation of one of the staples was necessary for immobilization, and the greater complexity of the design would have significantly increased the required number of control strands.
the surface-immobilization connector produces one clear band in the gel, which indicates that this structure has assembled correctly.
similarly, there is one dominant band in the lane corresponding to the unfolded square (assembled tape), although some smearing of the band is apparent.
the squares were folded as described in the electronic supplementary material.
the staples were present in excess, which means that the presence of the lower band in the lanes marked f□a and f□b does not imply poor assembly.
however, it is not possible to distinguish between the unfolded and folded constructs using agarose gel electrophoresis, and a polyacrylamide gel was therefore used to provide higher resolution (figure 4d), showing both assembly and operation of the motor.
in this gel, there is a distinct difference between the position of the band identified as unfolded square b (lane 5), and that identified as folded square b (lane 6), indicating that folding was successful.
folded square a (lane 7) runs slightly further than folded square b, owing to the asymmetry in the positions of the spokes mentioned above.
lane 8 shows the motor before operation, obtained by hybridization of folded square a and folded square b. at this stage, the brake of the motor was applied, which means that the blocking strands were attached, preventing the unrolling of the tapes.
the highest molecular weight band in lane 8 is postulated to be the assembled motor.
some of the squares did not connect with another square.
lane 9 shows the motor after incubation with the unblocking strands, which was intended to remove ‘sqblocka’ and ‘sqblockbmmwa’ by displacement.
this was expected to release the brake, allowing strand displacement to proceed.
comparing lanes 8 and 9 reveals that the unblocking process induced a significant structural rearrangement in the motor, which is the expected result.
however, gel electrophoresis is not conclusive and provided information only on static structures.
by contrast, the subsequent qcm-d experiments allowed structural changes to be measured in real time.
in addition to probing the operation of the motor, these measurements provided a further indication that folding had been successful, because the observation of any changes corresponding to operation of the motor or unfolding of squares would have been highly unlikely if folding had been incomplete.
qcm-d experiments were performed to investigate motor operation in more detail.
in contrast to the previous qcm-d measurements, dna was co-immobilized with the backfilling agent mercaptohexanol, which competes with the thiolated dna for access to the surface.
the aim of this was to reduce the density of machines on the surface and consequently decrease any inhibitory effects arising from intermolecular interactions.
the results of the qcm-d experiments are shown in figure 4e.
the first panel shows the effect of supplying an unfolded square of type b to an immobilized square of type a. this is directly analogous to the experiments in which t* was applied to folded triangles.
in the same way, the binding of the unfolded square gave rise to a decrease in frequency.
this was followed shortly thereafter by a slow increase, suggesting that the immobilized square unfolded and lost mass.
the second panel shows the result of a similar experiment, but in this case the immobilized square was initially blocked with a blocking strand, and was unblocked before the unfolded square was applied.
removal of the blocking strand is expected to cause a small reduction in mass, and the data do show a corresponding frequency increase.
the result of applying the unfolded square was qualitatively similar to the case in which the immobilized square had not been blocked, but the frequency shift corresponding to unfolding was small.
this may be attributable to incomplete unblocking in a surface-immobilized molecular layer consisting of only one type of square.
to investigate whether one folded square could induce unfolding in another, a fully folded square of type b was applied to an immobilized folded square of type a. this resulted in a frequency decrease, followed by a significantly delayed frequency increase.
the former was attributable to binding of the square, whereas the latter was consistent with unfolding of the squares and release of staples.
these experiments indicated that strand displacement reactions occurred as intended in the square constructs.
the full motor was assembled by the connection of two squares, and immobilized on the surface with mercaptohexanol.
unblocking strands were supplied to release the brake, and a slow frequency increase was observed thereafter, as expected to result from strand displacement, rotation and release of waste strands.
this result is therefore consistent with the correct operation of the motor on the surface.
the data suggest that rotation is initiated before the second unblocking strand has been supplied.
alternative displacement pathways may exist, and it is not clear what effect this could have on the operation of the motor.
it is possible that these pathways could be eliminated with an alternative motor design based on components made using dna origami methods, as discussed below.
3.4. further work for further study, single-molecule biophysical experiments could be used to directly observe the dynamic functional operation of prototype rotary machines, but these measurements are beyond the scope of this paper, which represents a proof-of-concept study.
further work on the motor would comprise the development of an enhanced model (as described below), which would enable the use of techniques such as atomic force microscopy to visualize intermediate states.
direct tracking of rotation could be achieved using time-resolved super-resolution microscopy [29], which would involve tracking the position of a single fluorescent molecule (or group of them).
single-molecule fluorescence microscopy on this system poses significant challenges, such as: attaching the fluorescent label to the motor, compensating for microscope drift over the long timescale of this experiment, correcting for two-dimensional diffusion of the motor at the end of its tether and avoidance of excessive fluorophore photobleaching on the timescale of the rotation.
pursuit of such challenging single-molecule experiments could form the basis of a subsequent study, following on from the work presented here.
in future studies, the design of the rotary motor could also be enhanced, in three main respects.
first, in the present implementation, the motor is only capable of performing 1.5 rotations, and this could be increased by a straightforward extension of the design.
second, the operation of the motor leads to disassembly of the motor, and the structure remaining on the surface is comparatively insubstantial.
third, it would be difficult to use the existing design in a single-molecule experiment because it is difficult to identify where a fluorescent label could be placed.
these last two issues could be addressed simultaneously by constructing the wheels of the motor using dna origami, a very popular technique for assembling dna nanostructures [5,30,31].
recent studies have explored the dna origami folding process [25,26,32,33], and the results will allow more sophisticated origami structures to be assembled [34], including devices such as the enhanced motor suggested here.
alternatively, other dna nanostructure assembly methods could be used [35–38].
4. conclusion this paper has described an experimental study of the putative mechanism of a prototype synthetic rotary motor made from dna.
the motor was designed to be driven by strand displacement and to be capable of autonomous operation after the brake was released.
results were also reported from experiments in which the phenomenon underlying the motor mechanism was investigated extensively, building on previous studies of strand displacement in surface-immobilized dna nanomachines.
ensembles of dna rotary motors were examined using two complementary techniques: gel electrophoresis and qcm-d. the former was used to probe static motors in solution before and after operation, whereas the latter provided time-resolved data on surface-immobilized motors.
single-molecule measurements were beyond the scope of this study, but future work on an enhanced rotary motor design could involve a combination of the biophysical approaches of single-molecule fluorescence microscopy and structural imaging methods such as atomic force microscopy and cryoelectron microscopy.
for the investigation described here, qcm-d and gel electrophoresis had a number of advantages.
the data in this paper represent promising experimental results that were consistent with the operation of the rotary motor as designed, and further work could enable the properties of the motor or an enhanced model to be exploited for real-world applications, such as manipulation of molecules, translocation of cargo through a nanopore, nanoswimmer propulsion, biosensors, hybrid photonic-biomolecular systems [39], and biomolecular computing.
supplementary material supplementary information: an experimental study of the putative mechanism of a synthetic autonomous rotary dna nanomotor this file contains dna sequences, detailed experimental procedures, results of nupack simulations and additional schematic diagrams of the motor.
@highlight
dna has been used to construct a wide variety of nanoscale molecular devices.
inspiration for such synthetic molecular machines is frequently drawn from protein motors, which are naturally occurring and ubiquitous.
however, despite the fact that rotary motors such as atp synthase and the bacterial flagellar motor play extremely important roles in nature, very few rotary devices have been constructed using dna.
this paper describes an experimental study of the putative mechanism of a rotary dna nanomotor, which is based on strand displacement, the phenomenon that powers many synthetic linear dna motors.
unlike other examples of rotary dna machines, the device described here is designed to be capable of autonomous operation after it is triggered.
the experimental results are consistent with operation of the motor as expected, and future work on an enhanced motor design may allow rotation to be observed at the single-molecule level.
the rotary motor concept presented here has potential applications in molecular processing, dna computing, biosensing and photonics.
