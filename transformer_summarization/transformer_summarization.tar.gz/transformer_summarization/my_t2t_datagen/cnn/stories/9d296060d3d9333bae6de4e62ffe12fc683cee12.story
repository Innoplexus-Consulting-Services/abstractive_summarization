introduction breast cancer (bc) is the most commonly diagnosed cancer and the leading cause of cancer-related death in women worldwide.
during the past 25 years, breast cancer death rates have been increasing in economically developing countries1: about 60% of the deaths are estimated to occur in those countries1.
for a long time, researchers have focused on the beneficial effects of consumption of vegetables and fruits (vf) on the prevention of cancers, including breast cancer2, 3. according to the 2007 wcrf/aicr second expert report followed by the updated breast cancer 2010 report, no conclusions can be reached for the evidence of fruits and vegetables consumption and breast cancer incidence4.
with a growing number of breast cancer survivors, some studies have investigated the association between consumption of vf and breast cancer survival5–14.
the majority of these studies6, 7, 9, 11, 12 have reported a non-significant inverse association between vf intake and overall (os) or breast cancer-specific survival (bcss).
however, two studies8, 10 reported inverse associations of consumption of vegetables and fruits with all-cause mortality, and a trend for this relationship was observed in another study5.
one study10 also found the inverse association with breast cancer-specific mortality.
the 2014 report of the world cancer research fund/american institute for cancer research (wcrf/aicr) systematic analysis on surviving breast cancer15 showed that no significant associations were found between intake of vfs and breast cancer prognosis.
the 2014 report presented results of studies published until 30th june, 2012. the purpose of this study was to summarize results on the association between consumption of vfs and breast cancer survival.
in this report, we updated the literatures search up to september 30, 2016 and performed quality assessment in detail.
we conducted several subgroup analyses according to menopausal state, intake dose and adjustments; and specifically, we conducted analysis for intake of cruciferous vegetables (cvs).
results study selection process the flow chart summarizing the process of study selection is shown in fig.
1. according to the search criteria, we identified a total of 4,068 articles (3,023 from pubmed, 1,021 from embase, and 24 from reference lists).
among these 4068 articles, 757 duplicates were identified and removed.
after reviewing the title and abstract of the remaining 3,311 articles, 3,270 were excluded from the meta-analysis.
forty-one studies were evaluated in detail.
after excluding studies that did not meet the inclusion criteria (see the methods section), a total of 10 articles were included in the meta-analysis (table 1 ).
the most common reasons for exclusion were a lack of data on intake of vf or breast cancer prognosis (n = 23 studies).
one study16 was excluded because its data duplicated in other articles.
another study17 modeled vf intake as a continuous variable.
three studies were excluded because no hazard ratios (hrs) and corresponding 95% confidence intervals (cis) were reported or no information was used to calculate these estimates.
three studies18–20 were excluded because they reported dietary patterns or score.figure 1flow diagram representing systematic literature search on vegetables and fruits intake and breast cancer survival.
table 1characteristics of the included studies.author/year/countrycohort size age, follow-updiet assessmentexposure (highest vs. lowest)primary event (n)adjustmentsholmes/1999/usa5 nhsffq,v: 4.2 vs. ≤2.12 servings/dos, n = 378age, diet interval, year of diagnosis, bmi, oral contraceptive use, menopausal status, postmenopausal hormone use, smoking, age at first birth and parity, number of metastatic lymph nodes, tumor size, caloric intake.n = 1982after diagnosisf: q4 vs. q1mean age, 54 yearsfollow-up: 12.1 yearssauvaget/2003/uk6 lssmailedv: daily vs. 0–1/weekos, n = 76age, radiation dose, city, bmi, smoking status, alcohol habits, education level, age at menarche, age at first birth, parity, breast-feeding, menopausal status, history of breast adenoma, family historymean age, 56 years (range 34–103 years)ffqf: daily vs. 0–1/weekfollow-up: 16 yearsbefore diagnosisfink/2006/usa7 libcspinterviewvf: 46 + vs. 0–18 servings/wkos n = 186age, energy intaken = 1235ffqv:24 + vs. 0–8 servings/wkbcss n = 125invasive breast cancerbefore diagnosisf: 24 + vs. 0–6 servings/wkage, 25–98 yearsfollow-up: 1996–2004 (range)mceligot/2006/usa8 n = 516self-administered ffq-100, before diagnosisv:3.1 vs. 0 servings/dos, n = 96age, stage of disease, bmi, parity, hrt, alcohol use, multivitamin use, energy intakemean age, 64.8 years (9.3 years)f: 2 vs. 0 servings/dfollow-up: 6.6 yearspierce/2007/usa9 wheldietary recalls telephonevf: >8.92 vs. ≤ 4.94 servings/dos, n = 315age, tumor stage, clinic site, antiestrogen use, oophorectomy statusrct: n = 3088after diagnosisv: >4.8 vs. ≤2.55 servings/dmean age, 53.3 (8.9) yearsf: >4.38 vs. ≤1.76 servings/dearly stage (i-iiia)follow-up:7.3 yearsdal maso/2008/italy10 n = 1453in-person interviewsvf: <4 vs. >6 servings/dos, n = 503age, region of residence, year of diagnosis, tnm stage and er/pr status62.7% tnm stage iii-ivffq-78bcss, n = 398median age, 55 years (range 23–74 years) follow-up:12.6 yearsbefore diagnosisbuck/2011/german12 n = 2653 >80% non-metastasisin-person interviewsv:183 vs 79 g/dos, n = 321age, tumor size, nodal status, metastasis, grade, er/pr status, breast cancer detection type, diabetes, hrt, study centre, energy intakemedian age, 63 years (range 50–74 years); follow-up: 6.4 yearsffq-176f: 259 vs. 79 g/dbcss, n = 235before diagnosisbeasley/2011/usa11 cwls, n = 4441mailedv: 2.5 vs. 0.4 servings/dos, n = 525age, state of residence, menopausal status, smoking, stage, alcohol, hrt, interval between diagnosis and diet assessment, energy intake, breast cancer treatment, bmi, physical activitymean age, 53.6 (range 20–79 years)ffq-126, after diagnosisf: 2.5 vs. 0.1 servings/dbcss, n = 137follow-up: 5.5 yearsnechuta/2013/usa13 abcpp, n = 11390; mean age, 51.1–64.5 yearsffq, after diagnosiscv: >78 vs. <39 g/dos, n = 1725age at diagnosis, er/pr status, tnm stage, chemotherapy, surgery, radiotherapy, hormonal therapy, smoking, bmi, exercise, menopausal status, race/ethnicity, and education.follow-up: 9.0 yearsmccullough/2016/usa14 cps-ii, n = 4452mailedvf: t3 vs. t1os n = 1204age at diagnosis, diagnosis year, tumor stage, tumor grade, er/pr, initial treatment, bmi, smoking status, physical activity, energy intake, dietary factorsmean age, 70.7 (7.2 years)ffq-68bcss n = 398follow-up: 9.8 yearsbefore and after diagnosisabbreviations: v, vegetable; f, fruit; vf, vegetable and fruit; bmi, body mass index; lss, life span study; libcsp, long island breast cancer study project; whel, the women’s healthy eating and living randomized trial; cwls, collaborative women’s longevity study; cps-ii, cancer prevention study-ii nutrition cohort; abcpp, the after breast cancer pooling project.
characteristics of studies table 1 summarizes the characteristics of these 10 articles (9 cohort studies5–8, 10–14 and 1 randomized control trial [rct]9).
overall, 10 articles reported on os5–14 and 5 on bcss7, 10–12, 14. during a median follow-up duration of 6.6 years, there were a total of 5,329 total deaths (ranged from 76 to 1,725) and 1,293 (ranged from 125 to 398) breast cancer specific mortality cases among 31,210 women with breast cancer.
articles were published between 1999 and 2016. studies were conducted in the following geographic regions: 7 from the united states, 3 from europe (uk, italy and germany).
five studies6–8, 10, 12 collected information on dietary intake before diagnosis.
in one study7, diet was assessed on average 3 months after diagnosis when 2/3 of the patients had not started chemotherapy treatment.
one study6 assessed the average frequency of intake over the previous year, and two studies8, 10 assessed dietary intake within 1 year of diagnosis.
four studies5, 9, 11, 13 collected information on dietary intake after diagnosis, and one study14 before and after diagnosis.
the quality scores of each study were summarized in supplementary table 1. the quality scores ranged from 7 to 9 for cohort studies and were 3 for one rct study.
all of included studies were of high quality (nos score ≥7 and jadad score ≥3).
pre-diagnostic dietary consumption and breast cancer os high vs. low analyses as shown in fig.
2a, three studies7, 8, 10 reported an association between pre-diagnostic intake of vegetables and fruits combined and os among breast cancer patients, and a non-significant association was found (summary hr = 1.08, 95% ci, 0.88–1.33; pheterogeneity = 0.183, i2 = 41.1%).
four studies6–8, 12 reported associations between pre-diagnostic intake of vegetables and fruits and os, respectively, with a combined hr of 0.96 (95% ci, 0.71–1.30; pheterogeneity = 0.121, i2 = 48.4%) for vegetables alone, and 0.83 (95% ci, 0.67–1.02; pheterogeneity = 0.685, i2 = 0) for fruits alone.figure 2relative risks for the association between pre-diagnostic intake of vegetables and fruits and all-cause mortality in breast cancer patients.
(a) high vs. low analysis; (b) dose-response analysis for intake in increment of 1 serving/day.
squares indicated study-specific risk estimates (size of square reflects the study-statistical weight, i.e.
inverse of variance); horizontal lines indicate 95% confidence intervals; diamond indicates summary relative risk estimate with its corresponding 95% confidence interval.
dose–response analyses as shown in fig.
2b, two studies7, 10 were part of this dose-response analysis for the association between pre-diagnostic intake of vegetables and fruits and os.
the summary hr per 1 serving/day increment was 0.98 (95% ci: 0.95–1.01), with evidence of moderate heterogeneity (i2 = 46.8%, pheterogeneity = 0.170).
three studies7, 8, 12 were included in the dose–response analysis for pre-diagnostic intake of vegetables and fruits and os, respectively, with a summary hr of 0.93 (95% ci: 0.79–1.10; pheterogeneity = 0.010, i2 = 78.5%) intake of vegetables only and 0.95 (95% ci: 0.89–1.01; pheterogeneity = 0.337, i2 = 8.1%;) intake of fruits only.
post-diagnostic dietary consumption and breast cancer os high vs. low analyses as shown in fig.
3a, two studies9, 14 reported an association between post-diagnostic intake of vegetables and fruits combined and os among breast cancer patients, and a non-significant association was found (summary hr = 0.95, 95% ci, 0.73–1.24; pheterogeneity = 0.273, i2 = 16.6%).
three studies5, 9, 11 reported associations between post-diagnostic intake of vegetables and fruits and os, respectively, with a combined hr of 1.08 (95% ci, 0.75–1.55; pheterogeneity = 0.098, i2 = 56.9%) for vegetables alone, and 1.04 (95% ci, 0.77–1.42; pheterogeneity = 0.186, i2 = 40.6%) for fruits alone.figure 3relative risks for the association between post-diagnostic intake of vegetables and fruits and all-cause mortality in breast cancer patients.
(a) high vs. low analysis; (b) dose-response analysis for intake in increment of 1 serving/day.
squares indicated study-specific risk estimates (size of square reflects the study-statistical weight, i.e.
inverse of variance); horizontal lines indicate 95% confidence intervals; diamond indicates summary relative risk estimate with its corresponding 95% confidence interval.
dose–response analyses as shown in fig.
3b, one study9 was part of this dose-response analysis for the association between intake of vegetables and fruits and os, with a hr per 1 serving/day increment of 1.00 (95% ci: 0.97–1.03).
three studies5, 9, 11 were included in the dose–response analysis for intake of vegetables only, with the summary hr of 1.00 (95% ci: 0.94–1.06; i2 = 55.7%, pheterogeneity = 0.105).
two studies9, 11 were included in the dose–response analysis for intake of fruits only, with the summary hr of 0.99 (95% ci: 0.97–1.02; i2 = 0, pheterogeneity = 1.00; fig.
3b).
subgroup, meta-regression and sensitivity analyses subgroup and meta-regression analyses are presented in table 2. overall, no significant associations were observed between pre-diagnostic intake of vegetables and fruits and os in all of the strata.
for pre-diagnostic intake of vegetables alone, a stratified analysis by intake dose produced a non-significant summary hr for studies using low dose (summary hr = 1.12; 95% ci, 0.85–1.48) and high dose (summary hr = 0.79; 95% ci, 0.43–1.45).
combining studies with adjustments for tumor stages, treatment, bmi, smoking led to a non-significant association (for example: adjustments for tumor stages: summary hr = 0.81; 95% ci, 0.41–1.53; adjustments for treatment: summary hr = 1.28; 95% ci, 0.64–2.55).
for pre-diagnostic intake of fruits alone, combining studies with adjustments for clinical tumor stage led to a borderline significant association (hr = 0.77, 95% ci: 0.59–1.01).
non- significant associations were observed for studies using low dose (hr = 0.92, 95% ci: 0.72–1.16) and high dose (hr = 0.79, 95% ci: 0.55–1.05).table 2stratified meta-analyses of vegetables and fruits intake and all cause mortality in breast cancer cases.pre-diagnosispost-diagnosisnhr (95% ci)ph, i2 (%)pd nhr (95% ci)ph, i2 (%)pd vegetables intake all40.96 (0.71–1.30)0.121, 48.631.08 (0.75–1.55)0.098, 56.9 menopausal status pre-menopausal11.40 (0.71–2.76)—0.4080postmenopausal30.86 (0.59–1.25)0.092, 58.10 intake dose* low21.12 (0.85–1.48)0.676; 00.40111.44 (0.91–2.27)—0.438high20.79 (0.43–1.45)0.053; 73.420.94 (0.65–1.36)0.184, 43.3 adjustments clinical characteristics20.81 (0.43–1.53)0.029, 79.00.48331.08 (0.75–1.55)0.098, 56.9—treatment11.28 (0.64–2.55)—0.56021.31 (0.95–1.82)0.569, 00.286bmi11.28 (0.64–2.55)—0.56021.05 (0.60–1.85)0.042, 75.70.852smoking11.28 (0.64–2.55)—0.56021.05 (0.60–1.85)0.042, 75.70.852physical activity011.44 (0.91–2.27)—0.438 fruits intake all40.83 (0.67–1.02)0.685, 031.04 (0.77–1.42)0.186, 40.6 menopausal status premenopausal11.10 (0.48–2.52)—0.5430postmenopausal30.80 (0.64–1.01)0.582, 00 intake dose* 0.432low20.85 (0.64–1.14)0.826, 00.79511.38 (0.88–2.17)—high20.79 (0.55–1.05)0.245, 26.220.94 (0.68–1.30)0.232, 29.9 adjustments clinical characteristics20.77 (0.59–1.02)0.348, 00.51731.04 (0.77–1.42)0.186, 40.6—treatment10.91 (0.48–1.72)—0.79021.03 (0.57–1.84)0.068, 70.00.487bmi10.91 (0.48–1.72)—0.79021.17 (0.90–1.53)0.372, 00.355smoking10.91 (0.48–1.72)—0.79021.17 (0.90–1.53)0.372, 00.355physical activity011.38 (0.88–2.17)—0.432 *high, the highest level of vegetable/fruit intake: ≥3.1 servings/d; low, the highest level of vegetable/fruit intake >1.8 servings/d.
p h, p values for between-study heterogeneity; p d, p values for the differences between subgroups.
likely, no significant associations were observed between post-diagnostic intake of vegetables and fruits and os in all of the strata.
for post-diagnostic intake of vegetables alone, non-significant associations were observed for studies using low dose (hr = 1.44, 95% ci: 0.91–2.27) and high dose (hr = 0.94, 95% ci: 0.65–1.36).
combining studies with adjustments for tumor stages, treatment, bmi, smoking led to non-significant associations (for example: adjustments for treatment: summary hr = 1.31; 95% ci, 0.95–1.82; adjustments for bmi: summary hr = 1.05; 95% ci, 0.60–1.85).
meta-regression analysis showed that no variables were significant factors for the association between pre- and post-diagnostic intake of vegetable and fruits and os in women with breast cancer.
in the leave-one-out sensitivity analysis, the pooled hr and 95% ci were not significantly altered (supplementary fig.
1a–d), which confirmed the robustness of the findings.
breast cancer-specific survival pooling two studies10, 14 led to a null association between pre- diagnostic intake of vegetables and fruits combined and bcss, with the summary hr of 1.18 (95% ci: 0.94–1.17; i2 = 0, fig.
4).
one studies12 presented null risk associations of bcss for pre-diagnosis intake of vegetables and fruits, and another study11 for post-diagnosis intake of vegetables and fruits.figure 4relative risks for the association between pre-diagnostic intake of vegetables and fruits and breast cancer specific survival (high vs. low).
squares indicated study-specific risk estimates (size of square reflects the study-statistical weight, i.e.
inverse of variance); horizontal lines indicate 95% confidence intervals; diamond indicates summary relative risk estimate with its corresponding 95% confidence interval.
cvs and breast cancer survival two studies11, 13 presented results for os with post-diagnosis intake of cvs, with the summary hr (high vs. low) of 1.03 (95% ci, 0.90–1.00; i2 = 0, fig.
5).
one study11 presented no significant association between post-diagnosis intake of cvs and bcss (hr = 0.95, 95% ci: 0.59–1.54; p for trend = 0.86).
another study7 showed a null association between pre-diagnosis intake of cvs and os for both pre- and post-menopausal women with breast cancer.figure 5relative risks for the association between post-diagnostic intake of cruciferous vegetables and breast cancer overall survival (high vs. low).
squares indicated study-specific risk estimates (size of square reflects the study-statistical weight, i.e.
inverse of variance); horizontal lines indicate 95% confidence intervals; diamond indicates summary relative risk estimate with its corresponding 95% confidence interval.
discussion we have evaluated the association between intake of vegetables and fruits and breast cancer outcomes using a meta-analysis of previously published studies.
overall, results of this meta-analysis suggest that intake of vegetables and fruit is not significantly associated with total and specific death from breast cancer.
in subgroup meta-analysis, a borderline reduced risk of total death was observed for pre-diagnosis intake of fruits alone among women with breast cancer.
in addition, intake of cruciferous vegetables was not associated with death from breast cancer.
as early diagnosis and treatments for breast cancer improve, breast cancer prognosis becomes good in most of the developed countries, with a five-year survival rate of more than 85% in women with localized and regional disease21.
lifestyle factors become increasingly important, which may help to lower the risk of dying from the disease.
however, researches exploring the science behind surviving breast cancer are relatively scarce.
the evidence from well-conducted rcts may be stronger than that from cohort studies.
the women’s healthy eating and living (whel) rct9 observed that women in the intervention arm who consumed 5 vegetable servings, 16 oz vegetable juice, 3 fruit servings, 15–20% of energy, and 30 g fiber per day did not lower risk of recurrence and death from breast cancer.
a few cohort studies5–8, 10–14 have examined the effects of dietary factors on mortality outcomes in breast cancer survivors with inconsistent results.
the 2014 breast cancer survivors report from wcrf/aicr15 suggested that a higher consumption of vf may not be related to surviving breast cancer.
in the current study, we found pre-diagnosis intake of fruits alone was associated with borderline decrease in risk of total death among women with breast cancer, which also were confirmed according to dose-response analysis.
however, only four studies were included for pre-diagnosis intake of fruits alone among women with breast cancer, we should be caution that this relationship was only due to chance, because we could not exclude a type ι error.
several potential mechanisms might explain a protective effect of vegetables and fruits on breast cancer prognosis, which may be through high intakes of fiber, micronutrients, including vitamins c, e, folate and carotenoids22, 23. in cell culture and animal studies, carotenoids have retinoid-like effects on cellular differentiation and apoptosis and also exhibit inhibitory effects on mammary cell growth24, 25. vitamin c exhibits antioxidant actions including the neutralisation of free radicals, which may impact cancer progression26, 27. furthermore, dietary intake of folate was associated with a reduced death by inducing incorporation of uracil into dna and inducing altered gene expression of critical tumor suppressor and proto-oncogenes via its role in dna methylation28–30.
epidemiological studies31 and clinical trial32 have suggested that a high fiber intake was related to reductions in blood levels of estrogen.
recent study has indicated that higher preoperative serum estrogen level had a negative prognostic effect in postmenopausal women with breast cancer, especially in the er-negative subgroup33.
strengths of this analysis include independent search and data abstraction by two researchers experienced in conducting systematic reviews; performing quality assessment in detail; exploring the aforementioned associations according to pre- and post-diagnosis, respectively; examining both high vs. low and dose–response relationships; conducting several subgroup and meta-regression analyses.
this meta-analysis has limitations.
first, some misclassification of vegetables and fruits intake is likely.
to reduce the errors in assessment of dietary intake, we included studies evaluating all fruits or vegetables.
however, populations from different regions, ethnicities and time periods may have differences in their classifications and types consumed.
dietary intake was assessed with a food frequency questionnaire (ffq) in all but one study which could have introduced measurement errors due to poor recall.
one study9 included in our meta-analysis used 24 h-diet recalls, which are often considered more robust dietary assessment methods.
previous studies34, 35 have suggested the relatively low correlation in report their intake of vegetables or fruit (spearman’s correlation coefficients of 0.6 for fruit consumption and 0.4 for vegetable consumption).
however, it was assessed before the outcome of interest (mortality) and thus is most likely non-differential.
in addition, analyses of the highest vs. the lowest intake are limited because they do not account for true differences among studies.
for example, the definition of the lowest exposure ranged from 08 to <2.559 servings/d of vegetables intake, and the highest intake levels of vegetables ranged from 183 g/d (about 1.8 servings/d)12 to >4.89 servings/d.
although statistically not significant, subgroup analyses demonstrated that os was improved when the meta-analysis was restricted to high dose intakes of vegetables/fruits subgroup.
the non-significant results might be due to low statistical power since only two studies were included in the high dose categories.
more studies with larger sample size and long duration of follow-up are warranted.
second, since not all potential confounders were adjusted for in the individual studies, there remains the possibility of residual or unmeasured confounding.
for example, not all studies were adjusted for clinical characteristics and cancer treatments, both of which are the most important prognostic factors.
our meta-analysis found no associations between intake of vegetable and fruit and total mortality among breast cancer across studies whether or not with adjustments for clinical characteristics.
in one of the included studies5, the authors found there was significant association with intakes of vegetables and reduced mortality among women without metastatic lymph nodes (hr = 0.62, 95% ci: 0.36–1.07, p for trend = 0.02), but no significant association among women with metastatic lymph nodes (hr = 0.90, 95% ci: 0.60–1.33, p for trend = 0.53).
therefore, further investigations on vegetables and fruits intake and breast cancer prognosis by clinical tumor characteristics are needed.
on the other hand, disease detection (clinical or screening) is another potential confounder because screen-detected cases show lower stage and longer survival than cancer found incidentally36, 37. however, data on mode of detection were not available in the study.
higher consumption of fruit and vegetables may be a marker for generally “healthier” dietary and lifestyle patterns, such as drinking less alcohol, a lower prevalence of overweight/obesity and cigarette smoking, and being physically active38, 39. a healthy lifestyle may lower the occurrence of breast cancer.
although the evidence available is limited15, 40–42, cigarette smoking, overweight/obesity and being physical inactivity (before and after a diagnosis) are suggested to be linked to increased total and specific cause of mortality in women with breast cancer.
stratified and meta-regression analyses indicated that risk of death for consumption of fruits and vegetables were not significantly changed by adjustment for bmi, smoking, and physical activity.
however, only a few studies employed adjustments for these factors.
hence, we cannot fully exclude the possibility of residual confounding.
third, studies included in this meta-analysis were major conducted in western countries (7 from the united states, 3 from europe) and in middle-aged and older person; so, the results should be extrapolated to other populations with caution.
in addition, the number of studies included in the meta-analysis was small, reducing the power of the meta-analysis and thereby reduced the generalizability of our findings.
the clinical behavior of er-positive and er-negative breast cancers differ significantly.
we did not carry out stratified analysis by er/progesterone receptor (pr) status because few studies provided the necessary data.
one study10 reported that high vegetables and fruits intake significantly improved disease prognosis among er/pr-negative breast cancer patients.
therefore, further investigations on vegetables and fruits intake and breast cancer prognosis by er/pr status are needed.
finally, publication bias should always be considered in a meta-analysis of published data, because the results of large cohort studies (even null results) are more likely to be published.
however, we could not perform such an analysis due to the small studies included.
in conclusion, intake of vegetables alone was not significantly associated with overall survival of breast cancer, however, intake of fruit alone might has, if any, a small effect on the overall survival among women with breast cancer.
considering the limited number of included studies, further studies with larger sample size, well-controlled confounding factors, long enough follow-up time, and more accurate assessment of dietary intake are warranted.
methods search strategy and study selection we (hjj and gyt) conducted a literature search using the medline (http://www.ncbi.nlm.nih.gov/pubmed/, from january 1, 1966) and embase (http://www.embase.com/, from january 1, 1974) databases.
the following search terms were used: 1) breast cancer or breast neoplasm or breast carcinoma; 2) mortality or survival or prognosis or disease progression or outcome or death; and 3) nutrition or diet or lifestyle or fruit or vegetable.
all results were updated on september 30, 2016. in addition, we carried out manual searches of the reference lists from retrieved articles to identify additional studies.
only full-length original articles published in english were considered, and no attempt was made to include abstracts or unpublished data.
this meta-analysis was planned, conducted, and reported according to the preferred reporting items for systematic reviews and meta-analyses (prisma) statement28.
in the present meta-analysis, we included the studies evaluating fruit and/or vegetable groups classified as “all” or “total”.
we did not include exposures presented as raw vegetables, green-yellow vegetables, cooked vegetables, green leaf vegetables, other vegetables, citrus fruit, or other specific types of fruits.
but we included studies which reported “fresh vegetables” or “fresh fruit”, because fresh vegetables or fruit accounts for a very high proportion of the total consumption43.
to be included in the meta-analysis, the following criteria had to be met: (1) the exposure of interest was consumption of vegetable and/or fruits assessed before or after diagnosis (≥12 months); (2) the outcome of interest was bcss or os among women with breast cancer; and (3) reported hrs (95% cis) or information to calculate these estimates (e.g., the number of cases and person-years of follow-up or number of noncases).
two authors (hjj and gyt) independently assessed titles and abstracts of the references identified by the search strategy according to the selection criteria.
any differences in opinion with regard to eligibility were resolved by a third investigator (zsj).
when unclear from the title or abstract whether the paper fulfilled the criteria, or when there is disparity among authors, a full text copy were obtained.
we did not assess breast cancer recurrence as endpoints of the meta-analysis, given that the definition used for recurrence varied across studies.
we excluded studies assessing the association for nutrients provided by vegetables and fruit, such as fiber, carotenoids and vitamin c. case reports, reviews, animal studies, and in-vitro studies were also excluded.
when two or more studies presented possible overlap, the one of better quality or with more detailed data were included.
data extraction the following data were extracted using a standardized data collection form: author’s name, publication year, country or region, name of study, number of participants, age, number of breast cancer cases and number of deaths (os and/or bcss), timing of data collection (before or after diagnosis) and type of diet assessment, range of exposure and adjustments.
we used the maximally adjusted results when several risk estimates with various adjustments were reported.
data were extracted independently by two investigators (hjj and gyt).
discrepancies were resolved by discussion and repeated examination of the studies to reach a consensus.
quality assessment of individual studies for the assessment of the study quality of cohort studies, we used the newcastle-ottawa scale (nos) checklist44, which assesses the quality of case control and cohort studies against three parameter: selection (four items, with each being awarded one star), comparability (one item, which can be awarded up to two stars), and exposure/outcome (three items, with each being awarded one star).
a score of ≥7 stars is indicative of a high quality study.
for the assessment of the study quality of one rct9, we used the five-point jadad scale of randomisation (0 or 1), double-blinding (0, 1 or 2), treatment of withdrawals and dropouts (0 or 1), and allocation concealment (0 or 1)45, 46. studies were categorized as low quality (score ≤ 2) or high quality (score at least 3)46, 47. statistical analysis all statistical analyses were performed using stata, version 11.0 (stata, college station, tx, usa) statistical software.
a two-tailed p value of <0.05 represents significance.
the primary outcome analyzed was os, and another point of interest was bcss.
adjusted hr estimates were pooled for the highest vs. lowest level and linear dose-responses using random effects meta-analysis, which considers both within- and between-study variation and provides more conservative estimates than a fixed-effects model48.
the study from dal maso et al.10 did not use the lowest category as a reference, we therefore recalculated the rr and its 95% ci.
we also reported results for intake of cvs.
when estimates were available specifically for both pre- and post-menopausal women with breast cancer7, they were combined according to a fixed effects model to obtain an overall estimate.
the summary measures were presented as forest plots where the size of data markers (squares) corresponds to the inverse of the variance of the natural logarithm of rr from each study, and the diamond indicates pooled rr.
heterogeneity among articles was estimated using the i 2-statistics and p values associated with q statistics.
p value of <0.10 represents statistically significant heterogeneity.
i 2 values explain the amount of total variation among studies that is due to heterogeneity.
i 2 value of >50% signify severe heterogeneity while a value of <25% represents no significant heterogeneity49.
we explored heterogeneity between studies using three strategies.
first, stratified analyses were carried out to estimate the effects of the following variables on outcomes: intake dose (the highest level of vegetable intake: ≥3.1 servings/d vs. >1.8 servings/d), menopausal status, confounding including clinical tumor stage, receiving treatment, bmi, physical activity and cigarette smoking.
because of the small number of studies reporting on bcss, the stratified analyses were carried out only for os.
second, we carried out stepwise meta-regression analyses.
third, we re-ran the meta-analysis removing studies once at a time to determine whether a particular study accounted for the heterogeneity.
the dose–response results in the forest plots are presented in one serving/day increment, which was according to the method of generalized least-squares trend estimation (glst) developed by greenland and orsini50, 51. dose–response analysis is performed on the basis of the data for categories of intake levels on median dose, number of cases and participants and adjusted logarithm of the hr with its se.
lack of this information led us to estimate the dose-response slopes using variance-weighted least squares (vwls) regression analysis50, 51. we then combined the glst-estimated study-specific slopes with studies that reported slope estimates to derive an overall average slope.
this analysis was restricted to the studies reporting three or more exposure levels.
in the absence of such median intake value, we used the midpoint of each category.
for an open-ended upper category of intake, we assumed the size of the interval to be the same as the previous category.
if the lowest category was open-ended, the lower boundary was assumed to be zero.
when studies used different measurement units (e.g.
grams per day), we standardized fruits and vegetables intake into servings per day using a standard portion size of 106 g52.
publication bias was not evaluated due to the small number of studies included.
electronic supplementary material supple.
@highlight
we aimed to conduct a meta-analysis investigating the association between consumption of vegetables and fruits and breast cancer survival.
a comprehensive search of the pubmed and embase was performed from the inception to september 30, 2016. the summary hazard ratios (hrs) and 95% confidence intervals (cis) were estimated using a random effects model.
ten studies, with a total of 31,210 breast cancer cases, were included in the meta-analysis.
the summary hrs (95% cis) of overall survival (highest vs. lowest) were 1.08 (0.88–1.33; i2 = 41.1%) for pre-diagnostic intake of vegetables and fruits combined, 0.96 (0.71–1.30; i2 = 48.4%) for vegetables alone, and 0.83 (0.67–1.02; i2 = 0) for fruit alone.
no significant risk associations of overall survival were found for post-diagnostic intake of vegetables and fruits.
line dose-response analyses indicated the likely results for both pre- and post- diagnostic dietary intake.
no significant association was found between intake of vegetables and fruits and breast cancer-specific mortality.
in addition, intake of cruciferous vegetables was not associated with death from breast cancer.
our findings indicated a borderline inverse association between pre-diagnostic intake of fruit and overall survival of breast cancer, whereas intake of vegetables was not associated with survival.
