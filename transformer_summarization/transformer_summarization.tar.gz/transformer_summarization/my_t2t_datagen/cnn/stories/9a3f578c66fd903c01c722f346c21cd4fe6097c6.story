strengths and limitations of this study a whole population-based study on long-term dispensing and adherence/persistence patterns of evidence-based medications for heart failure.
time-series medication data from an administrative source allows estimation of medication adherence and persistence.
longitudinal patient-level linked administrative data will assess comorbidities and use of medical services that may impact on medication dispensing, subsequent hospitalisations and death.
the effect of underusage and medication adherence on late clinical outcomes will be determined.
the study cohort was restricted to age 65 years or older to capture the relevant drugs recorded in the pharmaceutical benefits scheme database.
drug doses are not recorded in the pharmaceutical benefits scheme database, so the quantity taken per day is unknown.
distinguishing between heart failure with reduced ejection fraction and preserved ejection fraction was not possible.
introduction heart failure (hf) is a chronic, debilitating and progressive condition which is associated with high mortality, morbidity and disability.1 evidence-based medications (ebms) are the cornerstone in managing patients with hf.2–12 clinical trials have shown that ace inhibitors (acei), angiotensin receptor blockers (arb) and β-blockers (bb) have significantly decreased the overall mortality and morbidity for hf with reduced ejection fraction (hfref).
international and national guidelines1 13 recommend the use of acei (or arb if intolerant to acei) and bb as first-line therapy in patients with symptomatic hfref.
mineralocorticoid receptor antagonists (mra) are generally reserved for patients with hfref and persistent symptoms despite treatment with an acei and bb.1 14–16 digoxin may also be considered as it reduces the risk of hf rehospitalisation in patients with sinus rhythm and worsening hf despite acei and bb.1 17 18 in hf, uptake and adherence of ebms are associated with a decrease in the rates of rehospitalisation and death.19–21 patients with good adherence to ebm have better outcomes than those who stop their long-term therapy.22 23 although 1-year adherence to bb and acei has improved over time in patients discharged after their first hospitalisation for hf,24 poor adherence to ebm remains a significant barrier to enhancing effectiveness of current treatment.25 medication non-adherence is a growing concern in the light of evidence of its high prevalence and association with adverse outcomes and increased healthcare costs.26 to date, there are limited data on the adherence or persistence of hf medications in the general population.
a better understanding of factors affecting adherence/persistence of ebm, which are amenable to interventions, is crucial to improving outcomes in hf.
accordingly, the aim of our study is to use linked data from state and commonwealth administrative data sets to evaluate trends in dispensing of hf ebms, medication adherence and persistence, and outcomes in people aged 65–84 years following hospitalisation for hf in western australia (wa).
the specific research objectives are: to investigate trends in prescription uptake and long-term adherence and persistence of ebms in 30-day survivors following discharge for hf between 2003 and 2008.to assess determinants of dispensing and adherence/persistence of ebms.to investigate the association between adherence/persistence to ebms for hf and subsequent clinical outcomes including hf rehospitalisation and death.
methods and analysis this is a population-based retrospective cohort study of people aged 65–84 years with a discharge diagnosis of hf in wa between 2003 and 2008, and who survived 30 days postdischarge.
data sources the study will use statutory government-held administrative data of person-linked health information (table 1).27 this includes data from the: (1) hospital morbidity data collection (hmdc) and death registry, which are two of the core data sets of the wa data linkage system,27 and (2) pharmaceutical benefits scheme (pbs), which is from the commonwealth department of health in australia.
the hmdc contains information on people admitted to any hospital in wa, both public and private.
the pbs data set includes information on medications dispensed from australian pharmacies.
fields include age and sex, dates of prescription and supply, quantity supplied, broad prescriber specialty group, derived patient category, pbs item code and anatomic therapeutic chemical (atc) code.28 the pbs provides medicines to the australian population at a subsidised cost, making them more affordable.
people who have a healthcare concession card are eligible to obtain their pbs-subsidised medications at a reduced cost.
the combination of linked data from state and commonwealth sources will allow us to assess, at the individual level, hospital admissions, medication dispensing, an estimate of medication adherence and persistence, and associations with subsequent clinical outcomes.
table 1 information available from the various data sources in the study data set fields period covered hmdc demographic data, diagnosis, comorbidities and history, procedures, dates of admission and discharge 1980–2014 death data set cause of death and date of death 1980–2014 pbs date of prescription and supply, pbs item code,* atc code, quantity supplied, number of scripts, derived patient category 1 july 2002 to 30 june 2011 *pbs item code identifies the drug and strength dispensed.
atc, anatomic therapeutic chemical; hmdc, hospital morbidity data collection; pbs, pharmaceutical benefits scheme.
study cohort the study cohort consists of residents of wa aged 65–84 years with a hospital discharge diagnosis of hf in wa during 2003–2008 and who had pbs records.
we excluded very elderly patients aged 85 years or older because of an expected low short-term survival.
in addition, 30-day death after admission for hf can be as high as 20%,29 so we excluded people who died within 30 days of the hf admission.
the cohort selection process is summarised in figure 1. figure 1 selection process for the hf cohort from hmdc, death and pbs data sets.
asome patients had more than one excluded conditions.
bnon-concession card (general) patients are those who do not qualify for a concession card in australia.
hmdc, hospital morbidity data collection; hf, heart failure; ihd, ischaemic heart disease; pbs, pharmaceutical benefits scheme; wa, western australia.
the pbs data set contains complete recording of all dispensed medications approved for hf in concession card holders, comprising 96% of the total hf cohort.
our pbs data were available from mid-2002 to mid-2011, so we limited the study cohort to 2003–2008 to allow inclusion of pbs data for 6 months before and at least 2.5 years after this period.
identifying hf hf was identified from the discharge diagnosis fields of the hmdc using codes from the international classification of diseases (icd), 9th revision (icd-9, including the clinical modification icd-9-cm) and 10th revision australian modification (icd-10-am).
an admission for hf was defined as: (1) hf as principal discharge diagnosis (icd-9-cm codes 428, icd-10-am codes i50); or (2) hf as the secondary discharge diagnosis where ischaemic heart disease (icd-10-am codes i20-i25) was the principal diagnosis.
patients were excluded if they had a history of valvular heart disease in any diagnosis field, or heart valve surgery or renal dialysis in any procedure field (icd codes listed in online supplementary table 1).
10.1136/bmjopen-2016-014397.supp1 supplementary tables the coding of hf as principal discharge diagnosis in the hmdc has been validated using the boston diagnostic criteria, with a positive predictive value of 92.4% for definite hf and 98.8% for a combined definite or possible hf.30 definition of comorbidity comorbidities will be identified from their relevant icd codes from any of the discharge diagnosis fields in the hmdc by applying a fixed 20-year look-back period from the initial (index) hf admission.
comorbidities include ischaemic heart disease, hypertension, atrial fibrillation, diabetes mellitus, chronic kidney disease, renal failure, hypertension, chronic obstructive pulmonary disease, peripheral vascular disease, stroke, peptic ulcer disease and gastrointestinal bleeding (icd codes in online supplementary table s1).
similarly, a charlson comorbidity index31 will be calculated as a composite measure of comorbidity for each index case using a fixed look-back period.
some patients in the study cohort may have pre-existing hf and some may be new cases, so we will identify those with a history of hf using a fixed 20-year look-back period.
dispensing patterns of evidence-based drugs for hf the ebms for hf are shown in table 2. trends in drug dispensing patterns will be assessed based on fixed periods of 30 days, 6 months, 1, 2 and 3 years after hospital discharge.
dispensing patterns will be assessed by drug groups and combinations (eg, any acei/arb, any bb, any mra, acei/arb+bb, acei/arb+bb+mra).
we will determine the proportion of patients who are dispensed these drugs at each time point as well as determine trends in the whole study period.
the continuity of drug dispensing (adherence/persistence) will be assessed for the cohort for periods of up to 3 years to estimate the proportion of continuous use over time (patients identified in the second half of 2008 will have 2.5–3 years of drug data postdischarge).
landmark analysis will be used to develop models of association between drug persistence and outcomes, with landmark times of 6 months, 1 and 2 years (a 3-year landmark will also be investigated in the 2003–2007 cohort, because some patients in 2008 will not have 3 years of postdischarge pbs data).
in addition, using our person-based linked file, we can identify the impact of the more serious adverse effects of drugs (eg, renal failure).
since we have time-series pbs data, we will also be able to identify any change of drug groups (eg, acei to arb).
finally, we can explore and identify possible clinical conditions that may impact on use of specific ebm drugs, such as renal failure and chronic respiratory conditions (see icd codes in online supplementary table s1).
table 2 evidence-based medications for heart failure drug or drug group atc code generic name ace inhibitors c09aa captopril, enalapril, fosinopril, lisinopril, perindopril, ramipril, trandolapril arb c09ca valsartan, losartan, candesartan, irbesartan, olmesartan, telmisartan, eprosartan β-blockers c07ab propranolol, atenolol, metoprolol tartrate, metoprolol succinate, nebivolol, carvedilol, bisoprolol mra c03da spironolactone, eplerenone cardiac glycoside c01aa digoxin arb, angiotensin receptor blockers; atc, anatomic therapeutic chemical; mra, mineralocorticoid receptor antagonist.
adherence and persistence to medications based on dispensing data there are different methods for quantifying the consumption of medications, including subjective methods (eg, self-report) and objective methods (eg, adherence/persistence, blood tests).
adherence and persistence are the main methods for describing a patient's propensity to take medications for the appropriate length of time at the appropriate doses.32 for this study, we will define adherence as the proportion of prescribed doses of the medication taken by the patient over a specific period,32 and the persistence as the duration of time from initiation to discontinuation of therapy.32 in the pbs data set, we do not have data on dose, which is required for accurate estimation of the duration of use, which is required in estimating adherence and persistence.
hence, we will investigate several methods to estimate this.
first, there is the defined daily dose published by the who,28 and a similar prescribed daily dose from the bettering the evaluation and care of health (beach) data collection.33 the latter is from a sample of australian general practitioners and would be a more accurate representation of average daily dose in australian clinical practice.
in addition, we will estimate the duration of use from the 75th centile of the distribution of time to next supply date.34 since there is no gold standard for measuring adherence in administrative data, we will apply two common methods:32 (1) medication possession ratio (mpr) and (2) proportion of days covered (pdc).32 each has strengths and limitations as detailed in online supplementary table s2.35–38 these methods calculate adherence as the proportion of days supplied from the first and last pharmacy fill dates in a specific observation period, with variations on the start and end dates.
values range from 0% (non-adherence) to 100% (complete adherence), although the mpr value may exceed 100%, indicating an oversupply of medication.
both results can be presented as categorical or continuous variables.
although these methods provide a similar result when calculating the adherence for a single drug, in a comparative study by nau,35 the pdc provided a more conservative estimate of adherence when there was frequent drug switching and concomitant therapy with polypharmacy.
likewise, there is no universal agreement for calculating persistence.
as a result, we will use the refill-sequence method,39 which is widely used in health research.
the strengths and limitations of this are described in the online supplementary table s2.19 39 40 the refill-sequence model calculates persistence by determining if a patient has refilled a prescription within a predefined number of days.
the results from this model can be presented as a binary variable (eg, <80% persistence, ≥80% persistence).
the pbs data set also does not include medications received by inpatients at most hospitals in wa or at discharge during the study period.
hence, for patients who were admitted to hospital or had holidays during the study period, dispensing records will be absent from the pbs.
additional periods of absence, or gaps, in treatment can occur for other reasons, such as patients not refilling their prescriptions for a short period of time after they have finished their current supply.
these gaps will be considered when calculating adherence and persistence, such as when the gaps are concordant with hospitalisations identified from the hospital morbidity data set.
statistical analyses the cochran-armitage trend test will be used to evaluate trends for dispensing of medications and adherence using the calculations of mpr and pdc.
follow-up will be to 30, 180 days, 1, 2 and 3 years from discharge date of the index hf admission and first ebm supply date, respectively.
kaplan-meier methods will be used to assess the proportion of patients still dispensed medications over time following the first supply of ebm (persistence).
multivariable logistic regression models will be used to investigate determinants of the dispensing of ebms.
factors to be investigated include sociodemographic (eg, sex, age and hospital type), clinical (eg, comorbidities, charlson score) and medication (eg, number of ebms, interaction of common drugs, adverse effects requiring hospitalisation (hmdc data) and other interaction effects (eg, gender×medications, age×medications)).
cox regression models will be used to investigate the determinants (listed above) of persistence to treatment such as time to first discontinuation.
tests for violation of the cox proportional hazards assumption will be ascertained prior to running the main models.
multivariable logistic regression models based on major sociodemographic and clinical factors will be developed to estimate the propensity to be initially dispensed medications.
propensity score methods41 will be used to control for measured and unmeasured confounders when assessing the associations between adherence to ebms and subsequent outcomes.
multivariable cox regression models will also be used to examine the association between medication adherence/persistence and clinical outcomes.
the primary outcomes will be death, readmission for hf as a principal diagnosis and the composite of these.
secondary outcomes are non-elective (emergency) readmission for any cause and cardiovascular-related deaths.
in the models, we can investigate adherence thresholds and see how they affect outcomes at different threshold levels.
we can also model the reduction in persistence over time and compare groups with varying levels of reduction.
given that the change in persistence is expected to have a more gradual effect on outcomes (eg, over at least 6 months), we will use the landmark analysis method to model the association between reduction in persistence and outcomes.42 43 the landmark time points will be at 6-month intervals, and we will model the risk over the next 6 months against the average level of persistence over the previous 6 months for a total follow-up period of 3 years.
dissemination results of this study will be published in relevant medical journals.
results will also be presented at relevant national and international conferences.
additional communication of our results will occur through our collaboration with the national prescribing service (nps medicinewise, http://www.nps.org.au) and health practitioners.
discussion despite advances in medical therapy, the morbidity and mortality associated with hf remain high.
non-adherence to ebm in hf remains a major barrier to enhancing effectiveness of current treatments and leads to poorer outcomes.22 26 this population-based study will use contemporary data to examine patterns of ebm uptake and adherence/persistence of treatment in a ‘real-world’ hf population.
the pbs data set provides information about dispensing of medication rather than prescribing, and although we are not able to determine true prescribing patterns in the population, the dispensing data are a reasonable indicator of prescribing.
the findings will allow us to identify current evidence–treatment gaps and determinants of underprescription and adherence/persistence of ebms, and suggest strategies whereby the burden of hf can be reduced by more optimal therapy.
observational studies of evidence-based therapies in the general population are valuable because they reflect prescribing patterns and consumer adherence in the ‘real world’ in contrast to the ideal conditions of clinical trials.
further, patients included in trials are generally much younger and with less comorbidity than is encountered in clinical practice.
hf registries such as improve hf44 that include patient samples from participating clinical practices have been able to demonstrate a positive association of hf process-of-care measures (such as ebm use) and survival, but this needs to be confirmed in whole population-based studies.
patients included in our study are aged 65 years and older with hospitalised hf, and therefore represent the more advanced spectrum of hf cases in the community.
however, these patients are also more likely to derive survival benefit from optimal prescription of evidence-based therapies.
previous studies have estimated the adherence/persistence to ebms for hf.
however, results are variable, ranging from 10% to 94%.19 45 subjective methods of measuring medication adherence/persistence contribute to the variability.
a majority of studies used self-reported questionnaires to determine the adherence/persistence.46 47 however, this method is often poorly concordant with more objective measures of adherence/persistence.48 while objective measurements, such as pill count and medication event monitoring systems,49 50 are widely used in clinical trials, these methods require direct patient contact, and are not feasible when applied to a population-based study.
gislason et al19 used the refill-sequence method to evaluate persistence.
however, hospital data were lacking, and the persistence may have been underestimated from gaps in the pharmacy data set due to hospitalisations.
population-based linked data provide a novel and more precise way to estimate adherence/persistence.
using pbs data, we can estimate these two measurements to cardiac medications for nearly all persons aged 65 years or older who were admitted to hospital in wa.
we can check if gaps in pbs data for individual patients relate to hospitalisation periods (by checking in the hmdc data).
if patients are hospitalised during the gaps in pbs data, we can assume that the patient persists in taking the medications.
data are scarce and variable on optimal thresholds for medication adherence/persistence in patients with hf.50 51 our data will allow the estimation of thresholds of adherence/persistence below which outcomes become suboptimal.
finally, our linked data allow the estimation of long-term adherence/persistence and cause-specific and all-cause morbidity and mortality as a function of adherence/persistence.
further, this analysis will account for comorbidities that may confound the association between drug adherence/persistence and outcomes.
as far as we know, there are no previous studies to estimate this for hf in a population-based setting in australia, and evidence linking adherence/persistence with long-term outcomes is also scarce internationally.
strengths and limitations previously we have reported that dispensing rates of proven cardiac preventive drugs in wa are similar to other states in australia, suggesting that results in wa can be generalised to the australian population.52 a population-based study reduces the likelihood of a ‘healthy adherer effect’, encountered in some studies investigating drug adherence and outcomes.
the limitations of this study are first we are unable to distinguish between hf with reduced and preserved ejection fraction using the hmdc data set.
second, pbs data do not provide information on drug dose and frequency, nor reasons for prescribing the medications.
however, we can use the hospitalisation data to identify comorbidities and this will provide a list of possible indications for drugs that may have dual use.
also, hospitalised patients with hf aged <65 years were excluded, but this represents a minority (∼20%) of all patients with incident hf hospitalisation in wa during the study period.29 finally, medication usage in aboriginal west australians is largely under-recorded in the pbs.
conclusion this population-based study will estimate the association between dispensing and adherence/persistence to ebms for hf and subsequent clinical outcomes.
it will address the problems around the effectiveness of these drugs in the real-world population, accounting for sociodemographic factors and comorbidities.
the results will inform on possible interventions and strategies for health policymakers and healthcare providers to improve the rate of ebm use in the population, and to ensure adequate long-term adherence/persistence by consumers.
@highlight
introduction heart failure (hf) is a chronic, debilitating and progressive disease associated with high morbidity and mortality.
evidence-based medications (ebms) are the cornerstone of management of patients with hf.
in australia, these ebms are subsidised by the commonwealth government under the pharmaceutical benefits scheme.
suboptimal dispensing and non-adherence to these ebms have been observed in patients with hf.
our study will investigate trends in dispensing patterns, as well as adherence and persistence of ebms for hf.
we will also identify factors influencing these patterns and their impact on long-term clinical outcomes.
methods and analysis this whole population-based cohort study will use longitudinal data for people aged 65–84 years who were hospitalised for hf in western australia between 2003 and 2008. linked state-wide and national data will provide patient-level information on medication dispensing, medical visits, hospitalisations and death.
drug dispensing trends will be described, drug adherence and persistence estimated and the association with all-cause/cardiovascular death and hospitalisations reported.
ethics and dissemination this project has received approvals from the western australian department of health human research ethics committee and the western australian aboriginal health ethics committee.
results will be published in relevant cardiology journals and presented at national and international conferences.
