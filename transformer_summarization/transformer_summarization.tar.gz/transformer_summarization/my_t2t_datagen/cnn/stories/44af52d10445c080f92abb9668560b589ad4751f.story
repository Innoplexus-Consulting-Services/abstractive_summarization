introduction to roots and root system architecture roots are essential for plant productivity and serve a variety of functions, such as water and nutrient uptake, forming symbioses with other microorganisms in the rhizosphere, anchoring the plant to the soil, and acting as storage organs.
the different interactions of a root with its environment depend on its organization and structure, from the cellular to whole-plant level.
the root contains a stele, comprised of the xylem, the phloem, and the pericycle (smith and de smet, 2012).
the stele is encircled by concentric layers of epidermal, cortical, and endodermal tissues.
the root apical meristem forms the basic stem cell pool from which other cell types develop.
this root apical meristem also holds the quiescent center (qc), with rarely dividing cells that signals the surrounding cells to organize and maintain the initial stem cells (dolan et al., 1993).
there are generally two types of roots: (i) those that are formed in the embryo, such as the primary and seminal roots in maize (hochholdinger, 2009), tap or primary root in common bean (lynch and brown, 2012); (ii) those formed post-embryonically from consecutive nodes on shoots, normally referred to as adventitious roots (ars).
these include basal roots in beans, nodal roots in maize, ars of sweetpotato, potato, cassava, as well as yam, and lateral roots (lrs; lynch and brown, 2012).
lrs are formed post-embryonically from the pericycle of all root classes through auxin-dependent cell cycle activation.
this cell cycle forms the lr founder cells that undergo several rounds of cell division to initiate lrs (overvoorde et al., 2010).
the elongation, growth angles from the main axis, lateral branching and longevity of all root classes forms the root system which is determined by genetic, physiological, and environmental factors (lynch and brown, 2012).
root system architecture (rsa) therefore refers to the spatial configuration of the root system or the explicit deployment of root axes (lynch, 1995).
under poorly understood genetic control, rsa exhibits plasticity and responds to external environmental conditions such as soil moisture, nutrients, temperature, ph, and microbial communities (bao et al., 2014).
the study of rsa is important for agricultural productivity because most soils have uneven distribution of resources and/or localized depletions that make spatial distribution of the root system an important determinant of a plant’s ability to exploit these resources (lynch, 1995).
progress in the study of rsa in agricultural crops has consequently been realized, especially for cereals, and evidence for the genetic control of rsa and its relationship to increased productivity under stress is currently well-documented.
despite these achievements, information on rsa in root and tuber crops (rtcs), which form the second largest group of crops for global food security after cereals, is still lacking.
a recent review by villordon et al.
(2014b) on root architecture and rtc productivity clearly indicates this gap.
in the current review, we discuss rsa with special reference to rtcs, the genetic control of rsa, the relationship between rsa and abiotic stresses, and how rsa can be manipulated to confer tolerance to abiotic stresses.
we then draw conclusions on the way forward for rsa studies in rtcs.
root system architecture in root and tuber crops understanding rsa and the mechanisms of its development will allow manipulation and exploitation of different root traits to improve plants’ adaptation to changing climates and increase yields for the growing global human population (smith and de smet, 2012).
vegetatively propagated rtcs such as potato (solanum tuberosum), sweetpotato (ipomoea batatas), cassava (manihot esculenta), and yam (dioscorea spp.)
provide food security for vast populations, especially in sub-saharan africa where many resource-poor small holder farmers provide the majority of food.
of the four major rtcs, cassava and sweetpotato are storage roots, while potato and yam are tubers.
little literature is specifically targeted to root growth and development in rtcs compared to cereals.
the little literature available also mainly focuses on the growth and development of the storage root or tuber, primarily at harvest and post-harvest evaluations, rather than the entire root system.
in this section we describe the root systems in the four major rtcs, based on available literature (figure 1).
figure 1 root system architecture of cassava, sweetpotato, yam, and potato showing different root types (potato and sweetpotato figures adapted from villordon et al., 2014b).
cassava, potato, sweetpotato, and yam have ars originating from the shoot or subterranean stem, in contrast with the primary root in seed-propagated crops which originates from the embryo.
in sweetpotato and cassava, rsa is composed of ars, lrs and storage roots (srs), whereas in potato, the ars can be divided into basal (ars in figure 1) and stolon roots (str).
in yam, the ars root system is the most pronounced.
the simple recognition of the main ar axis and its spatial and temporal relationship to lrs and their initiation in rtcs would enable systematic investigations to further understand the mechanisms that trigger lr emergence and morphogenesis.
root architecture in root and tuber crops: the current state of knowledge a comparative survey of reports published in the last 25 years on the subject of root architecture among cassava, potato, sweetpotato, and yam is shown in table 1. in general, current knowledge is at the level of classical morphology, with relatively little on the genetic, hormonal, and molecular control of root architecture development among rtcs.
the first available documented attempt to specifically describe rsa development of several vegetable species, including sweetpotato, across different developmental stages was by weaver and bruner (1927).
in sweetpotato, the pericyclic development of lrs and its connection to protoxylem poles, where the number of protoxylem poles correspond to the number of lrs on enlarged storage roots, was made in the early 1900s (hayward, 1938).
yasui (1944) later reported that the protoxylem in ars of sweetpotato was generally either pentarch or hexarch, and that adventitious buds arose from five or six longitudinal rows of lr “scars.” relatively recent work documenting the pericyclic origin of cassava lrs noted that xylem poles ranged from four to eight and lrs developed from the pericycle opposite the xylem pole (medina et al., 2007; bonfim et al., 2011).
chaweewan and taylor (2015) found that the roots developing from stem cut end of cassava (basal ars) did not develop into storage roots.
such roots were also initiated from the cambium.
however, roots developing from buried nodes (nodal ars) at the boundary between the xylem and the stele had the capacity to develop into storage roots.
only one reference was found for yams, the second most important root crop in sub-saharan africa1, which described two distinct well-organized root systems: the seminal root system and the adventitious, more definitive root system (charles-dominique et al., 2009).
other studies in yam only focused on root morphology at crop harvest stage in response to fertilization (melteras et al., 2008; o’sullivan, 2008; hgaza et al., 2012).
iwama et al.
(1977) specifically analyzed root systems and the relationship between root systems and tuber yield in potato (iwama et al., 1981).
the effect of environment on rsa has been examined from different angles, for example asfary et al.
(1983) measured average root length under different nitrogen (n) fertilization, vos and groenwold (1986) studied root growth of potato on a marine clay soil, while parker et al.
(1989) studied the properties of subsoil loosening and irrigation on soil physical characteristics, root distribution, and water uptake in potato.
more recently, iwama (2008) studied the physiology and morphology of potato roots, specifically root length distribution, and examined their relationship with tuber growth.
table 1 summary of articles published within the last 25 years that address root architecture development in cassava, sweetpotato, potato, and yams.
subject crop species reference morphological description potato wishart et al., 2013 cassava el-sharkawy, 2004 sweetpotato none found yam charles-dominique et al., 2009 functional anatomy potato none found cassava bonfim et al., 2011 sweetpotato none found yam none found genetic and hormonal control potato xie et al., 2011; roumeliotis et al., 2012 cassava none found sweetpotato ku et al., 2008 yam none found environmental signals potato dechassa et al., 2003; busse and palta, 2006; palta, 2010 cassava pardales and esquibel, 1996; pardales and yamauchi, 2003; subere et al., 2009 sweetpotato pardales and yamauchi, 2003; villordon et al., 2012, 2013 yam none found breeding potato iwama, 2008; wishart et al., 2013 cassava pardales and yamauchi, 2003 sweetpotato pardales and yamauchi, 2003 yam none found the link between root architecture and yield in root and tuber crops in sweetpotato, storage root formation is marked by the formation of cambia around the protoxylem and secondary xylem elements, but lignification in the stele region reduces storage root formation (togari, 1950; wilson and lowe, 1973).
the first evidence of a link between sweetpotato lr development and storage root yield suggested that lrs may be essential in supplying “internal growth elements” for storage root formation (koshimizu and nishida, 1949).
recent work demonstrated the link between lr development and lignification.
in ars with a prevalence of arrested or non-emerged lr primordia, the adjacent stelar tissue becomes lignified thus rendering it incapable of undergoing swelling due to the absence of vascular and anomalous cambia development (villordon et al., 2012).
the precise relationship between stele lignification and lr development is still not clear in sweetpotato.
however, proteomics work with maize lrt1 (lateral rootless1) mutants showed the detection of proteins associated with lignin metabolism in the primary root, providing evidence that lrs influenced the proteome of the primary root (hochholdinger et al., 2004).
these findings suggest that intrinsic and external stimuli which promote lr development preclude stele lignification, rendering the juvenile ar competent for storage root formation.
in cassava, lrs are responsible for root system plasticity during the critical storage root formation stage (pardales and yamauchi, 2003).
there is currently a lack of evidence to suggest a relationship between lr development and the capacity of an ar to become a storage root.
early work describing anatomical changes associated with storage root formation in cassava did not mention lrs (indira and kurian, 1977).
related work examined the branching pattern of lrs and reported that lrs increased root surface area and compensated for the decrease in the main root length (izumi et al., 1999).
it was concluded that roots with a well-developed branching pattern likely absorbed water and essential nutrients for storage root growth better.
in potato, root mass is positively correlated with shoot mass and tuber bulking, but negatively correlated with early tuber bulking.
final tuber yield is related to rsa component traits such as specific root length of basal roots and total root weight for various root classes of potato under field grown conditions.
basal roots are important for water uptake and anchorage, whereas stolon roots are connected with nutrient acquisition and tuber formation (wishart et al., 2013).
despite these efforts, the link between storage root/tuber yield and the carbon partition to other root types as well as the regulatory networks involved in rtcs is yet to be established.
understanding the genetic, physiological and environmental factors influencing these components of rsa in rtcs is therefore critical in adapting genotypes to changing climates.
hormonal and genetic control pathways for root system architecture most genetic studies on rsa have been carried out using ‘model’ plant arabidopsis and a few ‘model’ cereals including maize and rice.
in this section we review the hormonal/genetic control of rsa as reported in arabidopsis and/or cereals followed by what is known in rtcs for storage root and tuber development.
formation of lrs as an important aspect of rsa which is a result of cell division of a specific subset of pericyle cells (casimiro et al., 2001).
the cell division process is under the control of both root- and shoot-derived auxin, where cellular levels of auxin contribute to the regulation of gene expression, which then impacts root branching (overvoorde et al., 2010).
auxin activates cyclin-dependent-kinases (cdks) (himanen et al., 2002) and d-type cyclin (cycd) (nieuwland et al., 2009).
these two are cell-cycle genes involved in pericycle division during the lr initiation process and whose inhibition leads to a reduced number of lrs.
also related to the cell cycle initiation is the e2fa/dpa transcription factor, which promotes the g1-s transition by controlling the expression of genes required for dna replication (boudolf et al., 2004).
however, initiation of the cell cycle alone is not enough to initiate lr formation but, as vanneste et al.
(2005) showed, lr initiation requires fine tuning by both negative and positive mechanisms regulating auxin homeostasis and signal transduction in the pericycle.
these processes are under the control of auxin-responsive genes dependent on auxin/indole-3-acetic acid-auxin response factors (aux/iaa-arfs) auxin signaling pathways.
genes containing auxin-responsive elements (ares) in the promoter region are directly regulated by arfs.
in the absence of auxin, the arfs combine with aux/iaa proteins (aux/iaa-arfs) and are therefore not active.
in the presence of auxin, however, the aux/iaa proteins are degraded by auxin-receptor proteins tir1 and afbs through the scf tir1/afbs complexes and 26s proteasomes (goh et al., 2012).
this degradation leaves the arfs active to either positively or negatively regulate auxin responsive transcription.
there are several of these aux/iaa-arf modules which are proposed to successively coordinate different developmental processes by regulating distinct targets (de smet et al., 2010).
the exact number of such modules involved in lr development is however still unknown.
de smet et al.
(2010) showed a bimodal auxin response where they found that in addition to the solitary root/indole-3-acetic acid14 – auxin response factors7 and 19 (slr/iaa14-arf7-arf19), the bodenlos/indole-3-acetic acid12/monopteros-auxin response factor5 (bdl/iaa12/mp-arf5), acting downstream of slr/iaa14, was required to guarantee organized lr patterning.
goh et al.
(2012) listed several modules responsible for different stages of lr initiation, including the iaa28-arfs module, which regulates the specification of lr founder cells; the slr/iaa14-arf7-arf19, which regulates nuclear migration and asymmetric cell division of the lr founder cells for lr initiation and the bdl/iaa12/mp-arf5, which regulates lr initiation and organogenesis; the short hypocotyl2/iaa3-arf (shy2/iaa3-arf), which regulates primordia development and emergence after slr/iaa14-arf dependent lr initiation, and which also inhibits lr initiation.
each of these modules have target genes.
okushima et al.
(2007), for example, showed that the slr/iaa14-arf7-arf19 module regulates lr formation by directly activating lateral organ boundaries domain/ asymmetric leaves2-like (lbd/asl) genes.
many other hormones interact with the auxin signaling pathways during lr initiation cytokinin (ck) and exogenous abscisic acid (aba) negatively affect lr development whereas brassinosteroid (br) positively affects lr formation.
the pericycle founder cell cycling is blocked in the g2 to m transition phase by ck thereby inhibiting lr formation.
in the presence of exogenous aba, emergence of lr primordia from the parent root is inhibited before the lr meristem is activated.
despite this negative regulation of lr development by exogenous aba, aba signaling also has cross talks with auxin action via the aba insensitive 3 (abi3) and the enhanced response to aba 1 (era1) genes which enhance auxin-regulated lr formation.
cross-talk is also indicated between br and auxin-dependent lr formation, where it is thought to promote acropetal auxin transport (reviewed by fukaki and tasaka, 2009).
although most of these studies were carried out in arabidopsis, orman-ligeza et al.
(2013) compared some of these molecular control pathways in cereals and arabidopsis and found that the aux/iaa-arf and the lbd/asl regulatory pathways were conserved.
several reviews on genetic and hormonal control of rsa are available.
smith and de smet (2012) have reviewed the genetic control of root branching, giving insights from arabidopsis and cereals.
jung and mccouch (2013) also provide a comprehensive review on the genetic and hormonal control of rsa.
in sweetpotato, the only study found specifically referring to genetic control of rsa is by villordon et al.
(2014a) who showed evidence that orthologs of genes associated with rsa in model crops were present in sweetpotato.
they found increased expression of a putative nitrogen transporter and deceased expression of a high affinity nitrogen transporter as well as decreased expression of a mad-box gene under low nitrogen (n) conditions.
a substantial amount of information is however available for storage root formation which is part of rsa in sweetpotato and cassava.
cytokinin is important in regulating storage root development in sweetpotato (hashizume et al., 1982).
zeatin riboside (zr), trans-zeatin riboside (t-zr) and 9-glucosyl-n-6-2-isopentenyl adenosine (i6ado) are the major ck involved in developing and activating the primary cambium.
besides hormones, several genes are involved in storage root formation and development in sweetpotato.
tanaka et al.
(2005) found srf1 through srf10 developmentally regulated genes to be involved in storage root formation.
srf1, srf2, srf3, srf5, srf6, srf7, and srf9 were upregulated while srf4, srf8, and srf10 were downregulated during storage root formation.
tanaka et al.
(2008) showed that knotted1-like homeobox (knox1) genes, ibkn1, ibkn2 and ibkn3, are associated with storage root development in sweetpotato.
ibkn1 and ibkn2 were upregulated in developing and mature storage roots relative to fibrous roots.
ibkn1 is homologous to shoot meristemless (stm) gene of arabidopsis whose overexpression leads to higher ck levels, while ibkn2 and ibkn3 are homologous to brevipedicellus gene of arabidopsis which negatively regulates lignin biosynthesis.
a group of mad-box genes, ibmads genes such as ibmads3, ibmads4, and ibmads79 are also found in fibrous roots before thickening, mainly in the vascular cambium region where rapid cell division occurs during storage root thickening (kim et al., 2002).
noh et al.
(2010) found that a mads-box protein copy dna, srd1 enhances the proliferation of the metaxylem and cambium cells during the auxin-dependent initial thickening and growth of storage roots.
storage root development in sweetpotato is enhanced when an expansin gene (ibexp1) is down-regulated (noh et al., 2012), but lignin biosynthesis is inhibited as starch biosynthesis is enhanced during early storage root formation (firon et al., 2013).
details on the molecular regulation of storage root formation in sweetpotato have been reviewed by ravi et al.
(2009, 2014).
no literature was available on the genetic control of ars and lrs in cassava.
however, de souza et al.
(2004) showed overexpression of the mec1 gene which codes for a pt2l4 glutamic acid-rich protein and a ring zinc finger and lea protein genes in the secondary xylem tissue of storage roots relative to fibrous roots.
based on a correlation network, the relationship between knox1 genes, phytohormone biosynthesis and phytohormone-signaling genes was established, and it was hypothesized that phytohormones are involved in the initiation of storage root development in cassava (sojikul et al., 2015).
both potato and cassava storage organs have been substantially studied, but not the genetic and hormonal control of rsa for either crop.
in addition to hormones, signaling components, and transcription factors, micro-interfering rnas (mirnas) and small-interfering rnas (sirnas) have been shown to affect rsa in plants, as reviewed by meng et al.
(2010) and khan et al.
(2011).
the mirnas and sirnas are thought to be involved in auxin signaling, nutrition metabolism and stress response by mediating signal interactions.
they have been identified in embryonic root development, radial patterning, formation of ars and lrs.
however, their role in rtcs has not yet been studied.
the relationship between root system architecture and abiotic stresses root system architecture has a central role in crop plants’ response to abiotic stresses.
since roots grow underground, they are the first to sense abiotic stresses and adjust their genetic program for post-embryonic development to survive the stress (lynch, 1995).
plant roots obtain water and nutrients from the soil, which is a complex system with intrinsic properties, abiotic and biotic interactions.
modulation of rsa is therefore affected when changes in the plant nutritional status and external nutrient supply over time are perceived and integrated into the intrinsic root development program.
the degree of root plasticity is based on variations in the number, extension, placement, and growth direction of individual components of the root system (giehl et al., 2014).
these changes in rsa consequently affect the growth and development of above-ground biomass (paez-garcia et al., 2015) by altering carbon allocation to shoots and/or triggering signaling pathways involving hormones, proteins, rnas, among others (dovale and fritsche-neto, 2015).
in this case therefore, roots indirectly regulate leaf stomatal conductance and affect leaf blade posture and photosynthetic rate when exposed to abiotic stress.
different abiotic stresses affect rsa in varied ways.
table 2 summarizes the root traits necessary for adaptation to different abiotic stresses.
deeper roots are associated with increased acquisition of water and mobile nutrients like n that may leach to lower soil layers (lynch and wojciechowski, 2015).
lrs, the main determinants of ultimate rsa, are influenced strongly by moisture and nutrient distribution in the soil (postma et al., 2014).
deak and malamy (2005) showed that lr formation from lr primordia in arabidopsis is repressed under drought stress when aba and lateral root development (lrd2) gene, interact with auxin.
since aba, lrd2 and auxin are also involved in rsa even without drought stress, it appears that such genes like lrd2 regulate the formation of lrs through promotive and repressive hormone signaling pathways depending on the environmental conditions.
repression of lr development under abiotic stress is of particular importance in root crops.
in sweetpotato for example, the final storage root yield depends on the capacity of a genotype to develop lrs on the main ars.
those with arrested or non-emerged lrs develop lignified steles, which inhibit localized swelling into storage roots (villordon et al., 2012).
other important contributors to rsa include single-cell projections from root epidermal cells referred to as root hairs (tanaka et al., 2014).
a high density of both root hairs and lrs is associated with increased nutrient uptake, especially in the top soil (postma et al., 2014) but increased metabolic costs is a trade-off here (zhan et al., 2015).
there are other trade-offs associated with crop adaptation to individual abiotic stresses.
primary root length is inhibited under low-soil phosphorus (p) conditions, while lr development is promoted thereby leading to a shallower root system.
this has negative effects under drought stress where deeper roots are necessary in order to have better access to water (wasson et al., 2012).
reduced frequency of lr branching improves n uptake where genotypes with fewer but longer lrs have greater axial root elongation, deeper roots and better n uptake than those with a higher number of lrs (zhan and lynch, 2015).
on the other hand, a larger number of lrs is required under p-limited conditions for topsoil foraging (lynch and brown, 2001).
since abiotic stresses normally occur in combination under field conditions, it is therefore evident that there is ‘no size fits all’ if adaptation to abiotic stress conditions is done considering each stress individually.
table 2 a summary of relevant phenotypes and required traits under different abiotic stresses.
desired phenotypes required traits ref.
general ref.
rtcs drought • deeper root systems• redistribution of branch root density from surface to depth• increased radial hydraulic conductivity at depth• reduced metabolic costs • longer primary roots• larger root tip diameter• steeper, abundant and longer lateral roots• reduced cortical cell file number• larger root cortical aerenchyma• gravitropism •wasson et al., 2012•uga et al., 2013•lynch, 2013•lynch et al., 2014•comas et al., 2013 •wishart et al., 2014• pardales and yamauchi, 2003 nutrient deficiency • top soil foraging• rhizosphere modification• reduced metabolic costs • abundant and longer root hairs• abundant and longer lateral roots• shallow and abundant adventitious roots• exudation of organic anions• association with microbes• larger root cortical aerenchyma• reduced root respiration • lynch and brown, 2001• richardson et al., 2009•forde, 2014•gruber et al., 2013•lynch, 2015• walch-liu et al., 2006• postma and lynch, 2011•nielsen et al., 1998•nielsen et al., 2001 • melteras et al., 2008•hgaza et al., 2012•o’sullivan, 2008•wishart et al., 2013 salinity • water extraction efficiency• ion exclusion • reduction in main root elongation• redistribution of root mass between main and lateral roots• reduction in sodium transport to shoots• compartmentalization of sodium ions into the root steles and vacuoles • munns and tester, 2008• julkowska et al., 2014•roy et al., 2013•rus et al., 2006•katori et al., 2010• gupta and huang, 2014 • none in rtcs, it is known that the root system is made up of ars and lrs which presumably are involved in water and nutrient uptake and hence respond to abiotic stress.
however, some rtcs have complex rsa because the harvestable part is also underground with several root classes, e.g., in potato, which may have different functions with regard to adaptation to abiotic stress.
the potato root system is known to be shallow, with poor ability to penetrate soils thereby being drought susceptible (porter et al., 1999).
despite having a shallow root system, potato is still not efficient in p and n uptake because the larger root system has a respiration carbon cost (balemi and schenk, 2009).
furthermore, most findings studied the root system as a whole without identifying possible roles for different root classes.
an attempt at this was done by wishart et al.
(2013) who reported genetic variation for potato root traits without any specific abiotic stress.
they suggested that basal roots were responsible for water uptake and anchorage while stolon roots were responsible for nutrient uptake and tuberization.
cassava and sweetpotato have less root classes compared to potato because the harvestable part is also a root.
pardales et al.
(1999) studied the effects of high root zone temperature on root systems of cassava and sweetpotato.
they showed a reduction in the total length of ars, number and total length of first order lrs, under high root zone temperature in both crops.
pardales and yamauchi (2003) also showed a suppression of ar and lr formation and development under drought stress in both sweetpotato and cassava.
recent studies in sweetpotato indicate direct influence on rsa of spatial and temporal availability of water and n availability similar to model systems (villordon et al., 2014a).
in yam, hgaza et al.
(2012) found no fertilizer response of tuber yield but a positive correlation between thinner, longer roots with tuber yield.
manipulating root system architecture for abiotic stress tolerance the aim of carrying out rsa studies in crop plants is to understand areas of interest within the root system and incorporate this information in crop improvement programs.
several approaches may be applied in manipulating rsa in order to adapt crops to changing climates.
combined-stress versus single-stress selection most of the reported studies above were carried out for stress-specific responses.
however, stresses always occur in combination, with different scenarios and complexity, to which responses are also varied.
in this case therefore, combined stress scenarios may be considered in relation to rsa.
the complexity of the root growing environment and the limitations associated with studying only one trait could be lessened by ideotype or trait-based breeding, originally proposed by donald (1968).
ideotype breeding requires consideration of relationships between multiple traits in addition to each individual trait (rasmusson, 1987).
a potato root ‘ideotype’ as summarized by wishart et al.
(2013) for example, is hypothesized to be one which is architecturally plastic, long, deep, and thin, as well as being able to self-protect against parasites and pathogen.
such a system should ideally be responsive to water deficits, able to transport aba to shoots, enable efficient stomatal closure, and have minimum carbon costs, either by producing aerenchyma or increasing specific root length, increasing root surface area, or desirable root exudates and symbioses in the rhizosphere.
in sweetpotato, villordon and clark (2014) found an association among rsa, virus resistance and availability of n thereby indicating the necessity of a more systematic approach toward determining and managing yield constraints.
they showed that ar and lr formation was decreased by about 51% under deficiency and virus infection.
on the other hand, storage root formation is known to fail under excess moisture and high n as more biomass is partitioned to above-ground biomass (villordon et al., 2012).
an ideotype for sweetpotato therefore, in addition to being efficient in water and mineral uptake and utilization, and being pathogen resistance as indicated above for potato, should also be tolerant to excess moisture and have balanced biomass partitioning between storage root and above-ground biomass.
trait -based breeding does not always result in accumulation of additive effects, rather synergies among traits need to be considered.
it is proposed to incorporate root phenes into breeding programs targeting rsa.
a phene, which has variants referred to as phene states, is the basic functional unit of a phenotype, with a phenotype being defined as the particular combination of states of all phenes of an individual (york et al., 2013).
with regard to rsa, lynch and brown (2012) propose ‘elementary’ and ‘unique’ root phenes which cannot be decomposed further and which are a result of only one set of genes and processes.
root growth angle may for example be considered one of the phenes of root depth as it is only one of the factors determining root depth, while root depth is referred to as a phene aggregate, being a result of several phenes.
a group of interacting phenes that may be selected together are referred to as a phene module.
york et al.
(2013) proposed hypotheses for integrating root phenes in a breeding program.
they considered synergies within a phene module which increase as the number of positively acting phene-state combination increases.
metabolic costs are to be expected with such synergies except in metabolically neutral, positively acting, phene-state combinations.
the interactions between phenes within plants, between plants and with the environment are expected to result in genetic variation in rsa.
model-assisted phenotyping in breeding approaches such as ideotype or phene-integrated, structural-functional plant modeling and simulation may offer a robust way of understanding the complexity of the non-linear signals and transduction pathways involved in the roots’ responses to multiple abiotic stresses.
this is expected to provide new mechanistic insights into the regulation of root growth and development (chickarmane et al., 2010).
in addition to advances in high-throughput phenotyping techniques that allow rapid evaluation of a large number of genotypes, model-assisted phenotyping enhances prediction of difficult traits such as those that vary with environmental conditions.
it also allows precise prediction of genotype × environment × management interaction over a large number of environments thereby allowing the estimation of comparative advantage of a given phene state in different environments (tardieu and tuberosa, 2010).
multi-scale modeling which examines behavior at subcellular, cellular, tissue, organ, and whole organism states may allow the prediction of the effect of a given phene, phene state, phene module, or phenotype in a complex abiotic stress environment (band et al., 2012).
leitner et al.
(2014) showed that functional-structural root models were appropriate to better comprehend the role of roots in whole-plant adaptation to diverse drought scenarios, in addition to their contribution to distinct drought scenarios.
using a dynamic root architecture model and root xylem hydraulic properties model, they showed that plants which transpired more had root axes which matched the available water distribution.
they also found that water saving genotypes had lower root conductance than the water spending genotypes.
despite these advantages, encouragement for the adoption of root models needs to be accompanied with realistic and more explicit plant regulatory networks, in addition to integration with phenomic databases (dunbabin et al., 2013) in order to be more representative and applicable to actual field performance of genotypes.
this approach has not been applied in rtcs yet.
genomics-based approaches manipulating root traits has been carried out in several crops through the use of molecular markers.
several specific genes related with rsa were identified in crop plants, either from gene mutants with quantifiable characteristics, or from qtl analyses.
the genetic control of lr formation as reviewed above was elucidated based on gene mutants with quantifiable characteristics.
in rice, a gene controlling root angle, deeper rooting 1 (dro1), was identified using qtl mapping and introgressed into an elite line through backcrossing, whereas phosphorus starvation 1 (pstol1), a pup-1-specific protein kinase gene confers early root growth for p-acquisition in rice (gamuyao et al., 2012) and sorghum (hufnagel et al., 2014).
however, information on how these genes/qtl affect the phenotypes and/or their performance in different genetic backgrounds and/or different environments is still largely lacking.
this is because rsa response to environmental conditions is normally quite different under field conditions, given the broader spectrum of stresses the roots find themselves in rich and watt (2013).
extrapolating results obtained from a response to a specific abiotic stress is not therefore adequate (jung and mccouch, 2013).
most of these qtls are small-effect qtls, i.e., they are normally conditioned by a single gene and therefore not stable across environments.
kitomi et al.
(2015) for example, established that genotypes having the same functional allele of dro1 could have different rooting angles.
small-effect qtls therefore are assumed to be part of a set of minor qtls.
in such cases, it is necessary to carry out comparative data analysis and integration across controlled environments and field studies to establish target variants for further investigation and introgression into genotypes of interest.
alternatively, identification of large-effect qtls which are more stable across environments and genetic backgrounds seems to be the most promising way of ensuring impact from genomics-assisted breeding methods.
dixit et al.
(2015) confirmed the multi-genic and multi-environment effectiveness of qdty12.1, a large-effect qtl identified on chromosome 12 of the rice genome.
they confirmed the central role of the no apical meristem (osnam12.1) transcription factor in the activity of qdty12.1 together with promoters of six intra-qtl genes with nam binding sites as well as three co-localized and/or partially co-expressed genes of osnam12.1.
these findings suggested that identification and proper analysis of large-effect qtls together with their component genes could lead to a more efficient breeding process for complex traits such as those involved in adaptation and abiotic stress tolerance.
these reports are mainly based on arabidopsis and cereal crops with simple genetic make-ups.
most rtcs on the other hand are polyploid with very complex genetic backgrounds.
genetic analysis of these crops is complicated by multiple alleles and loci, mixed inheritance patterns, association between ploidy and variation in mating system, among others (dufresne et al., 2014).
marker-based procedures developed in diploid species therefore present difficulty to apply in most polyploid rtcs and adoption of these approach is not therefore straight forward.
application of the most commonly used genotyping methods, including new generation sequencing techniques, in rtcs present problems in allele dosage determination, presence of null alleles, distinguishing orthologs from paralogs, and copy number variation (dufresne et al., 2014).
as a consequence, although new techniques such as genomic selection offer great potential in marker-based breeding, they are currently still difficult to adopt.
additive, dominant and epistatic genetic effects are all important in rtcs due to heterozygosity (ceballos et al., 2015) while models developed for genomic selection in cereals mainly consider additive genetic effects.
marker-based approaches in this class of crops therefore require re-thinking on the methods and pipelines available so far.
in addition to identifying qtls and genes of interest from a species, another approach for adapting roots to abiotic stress is through transgenic technology.
for example, spermidine synthase genes (fspd1) confer higher antioxidant enzyme activities to plants.
under abiotic stress, plants with higher antioxidant enzyme activities are generally more tolerant, as they are better able to remove by-product reactive oxygen species (ros) that are harmful to the plant if allowed to accumulate.
using transgenic technology, sweetpotato transformation with spermidine synthase genes (fspd1) from cucurbita ficifolia increased their multiple stress tolerance, with a higher concentration of fspd1 in leaves and storage roots (kasukabe et al., 2006).
estrada-melo et al.
(2015) used a 9-cis-epoxycarotenoid dioxygenase gene from tomato (lenced1) overexpressed in petunia and confirmed that nced increased drought resistance of the transgenic plants.
a calcium-dependent protein kinase (oscdpk7) conferred tolerance to cold and salt/drought in rice transgenics.
two distinct pathways for cold and salt/drought tolerance using a single cdpk were implied which showed that manipulation of cdpk has great potential to adaptation and abiotic stress tolerant crop improvement.
‘gene stacking,’ a form of ideotype breeding, could be a good alternative to transgenic technology that relies on a single gene.
however, this has only been successful in pest control engineering such as the bt toxin resistance (york et al., 2013).
gene stacking for complex traits is therefore still a challenge due to trait interaction.
genome editing, a new approach that involves targeted dna sequence modification through creation of double-strand breaks using sequence specific nucleases, provides possibilities to change a protein’s amino acid sequence through specific nucleotide substitutions, delete genes or chromosome segments, and introduce foreign dna at desired genomic regions (voytas, 2013).
several nucleases are available for targeted genome engineering (reviewed by esvelt and wang, 2013), but the system receiving most attention recently is crispr/cas9, which involves the use of a guided rna to create targeted mutations in candidate genes of key pathways in order to identify their effects and create new variation within a relatively short time (cong et al., 2013), among other potential uses.
these methods are gaining application in crop plants including rtcs.
clasen et al.
(2016) used a talens approach to improve cold storage and processing traits in potato.
the vacuolar invertase (vinv)gene (vinv) encoding a protein that breaks down sucrose to glucose and fructose was silenced in order to minimize the accumulation of reducing sugars which turn into anti-nutrients upon processing.
no matter which manipulation method is followed, proper phenotypic evaluation prior to and after such manipulations is important in order to realize and quantify genetic gains from rsa manipulation in a breeding program.
phenotyping root system architecture traits: available technologies/challenges since roots grow below ground, studying the entire root system naturally requires digging it out, a complex process in itself, and it is difficult to extract the entire system without breaking off the finer parts.
for this reason, studies have mainly dwelled on above-ground traits related to abiotic stress tolerance.
however, given the pressures on crop productivity caused by global climate change, with the associated abiotic stresses, and the notion that food production needs to double in the next few years to accommodate the growing global population, root manipulation seems to hold the key toward sustainable food production.
villordon et al.
(2014a) suggested that a paradigm shift toward rsa studies would enable a truly inclusive green revolution and allow food-insecure, resource-poor farmers who depend on rtcs in developing countries to also benefit.
with this mindset, plant biologists, geneticists, and breeders have now shifted some focus toward studying of root traits.
due to the aforementioned complexity of studying roots under the soil, plant scientists are now set on finding minimally intrusive, non-destructive, whole-root system evaluating platforms.
hydroponics and gels are the most widely used systems to phenotype root systems (jung and mccouch, 2013).
although, they offer a simple way to study different root traits and have given insight into root growth and development, both are controlled and do not represent actual field environments, and correlation of the findings from such experiments with actual performance of a plant in its natural environment are limited.
to address this bottleneck, plant scientists are continually seeking to develop methods that will allow study of rsa in a more natural environment.
several methods have been proposed and applied in various studies including ‘shovelomics’ (trachsel et al., 2011), soil coring (wasson et al., 2014), rhizolysimeters (eberbach et al., 2013) and minirhizotrons (maeght et al., 2013), which are all soil-based.
however, these methods are also low throughput, slow, and not amenable to large numbers of genotypes like those required for genome-wide association mapping studies.
image-based systems have also been developed and proposed to study roots in their natural environments, including x-ray computed tomography (tracy et al., 2010) where x-rays are used to acquire 3-d cross-sectional images of the roots within the soil, laser (braga et al., 2009) which allows collection of bio-speckle patterns of gel-grown roots, nuclear magnetic resonance (nmr: menzel et al., 2007), ground penetrating radar (gpr; hirano et al., 2012), infra-red (ir) imaging (dokken and davis, 2007), and near-infra-red (nir) imaging (tirlapur and könig, 1999), among others.
however, application of some of these methods is still limited by the costs involved and to a few genotypes.
another bottleneck associated with imaging methods is image analysis.
several root image analysis platforms have been developed to address this limitation2.
with these large numbers of imaging and image analysis platforms, the need for sharing and use of data requires establishment of trait ontology across them to allow development of root ideotypes for different environments.
efforts by lobet et al.
(2015) to develop a unified root architecture development language are therefore right on time.
this, combined with scaling up of the image analysis methods mentioned above, will be able to provide further knowledge required to adapt crops to their highly variable environments.
conclusion the increasing global population requires increased food production on the same or even less agricultural land as used currently, if the effects of climate change render some of the available marginal lands unfit for agricultural production.
most of the present and past crop improvement efforts have focused on above-ground traits to adapt crop plants to different production constraints.
although great progress has been made, and food production significantly increased, by manipulating above-ground traits, an estimated 800 million people are still food insecure, whereas yields, especially in cereal, have reached their yield potential and are plateauing in certain regions of the globe.
it is therefore time for crop scientists to tap into un-explored and less exploited diversity within rsa traits to ensure rapid genetic gains, and stable and enhanced productivity of agricultural systems for future environmental conditions and climate change scenarios.
due to the quantitative nature of rsa traits and complex interaction of several underlying pathways that control them, response of rsa to multiple individual stresses or combination of stresses is variable.
modeling of the responses of root traits to multiple stress scenarios in a combination of high-throughput root-trait phenotyping techniques, alongside a robust database and data analytical pipeline, could be a way to go.
this proposed strategy is applicable to all crops, but is more urgent in rtcs, as the second largest source of food security after cereals, mainly growing in marginal areas where many cereals cannot survive.
also, for rtcs, the harvestable organs are part of the rsa.
it is recommended to increase focus on rsa research by investing more resources.
rtcs can learn from what has been found so far in cereals and adopt some of their methods, while developing high-throughput techniques to quantify rsa traits under optimal and stressful conditions.
author contributions review was conceptualized and written by mk, dg, and av.
conflict of interest statement the authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.
@highlight
the challenge to produce more food for a rising global population on diminishing agricultural land is complicated by the effects of climate change on agricultural productivity.
although great progress has been made in crop improvement, so far most efforts have targeted above-ground traits.
roots are essential for plant adaptation and productivity, but are less studied due to the difficulty of observing them during the plant life cycle.
root system architecture (rsa), made up of structural features like root length, spread, number, and length of lateral roots, among others, exhibits great plasticity in response to environmental changes, and could be critical to developing crops with more efficient roots.
much of the research on root traits has thus far focused on the most common cereal crops and model plants.
as cereal yields have reached their yield potential in some regions, understanding their root system may help overcome these plateaus.
however, root and tuber crops (rtcs) such as potato, sweetpotato, cassava, and yam may hold more potential for providing food security in the future, and knowledge of their root system additionally focuses directly on the edible portion.
root-trait modeling for multiple stress scenarios, together with high-throughput phenotyping and genotyping techniques, robust databases, and data analytical pipelines, may provide a valuable base for a truly inclusive ‘green revolution.’ in the current review, we discuss rsa with special reference to rtcs, and how knowledge on genetics of rsa can be manipulated to improve their tolerance to abiotic stresses.
