electrocardiographic report1-4 descriptive report analysis of the rhythm and quantification of the heart rate (hr).
analysis of the duration, amplitude and morphology of the p wave, and duration of the pr interval.
determination of the electrical axis of p, qrs, and t. analysis of the duration, amplitude, and morphology of the qrs complex.
analysis of ventricular repolarization and description of st-t, qt, and u changes, when present.
conclusive report - synthesis of the diagnoses listed in these guidelines.
analysis of the cardiac rhythm sinus rhythm (sr) - rhythm observed by the occurrence of positive p waves in the d1, d2, and avf leads.
cardiac arrhythmia - change in frequency, formation, and/or conduction of the electrical impulse across the myocardium.
supraventricular arrhythmia - rhythm that originates above the junction between the atrioventricular (av) node and the bundle of his.
ventricular arrhythmia - rhythm that originates below the bifurcation of the bundle of his, usually visualized as a widened qrs.
frequency and rhythm of the sinus p wave - normal hr range: 50-100 bpm.4 sinus bradycardia (sb) - heart rate under 50 bpm.
sinus tachycardia - heart rate above 100 bpm.
sinus arrhythmia (sa) - usually physiological, depends on the autonomous nervous system and is characterized by a variation in the pp intervals.
normal ventricular activation definition of normal qrs - duration < 120 ms and amplitude between 5 and 20 mm (frontal plane) and between 10 and 30 mm (precordial leads), with normal orientation of the electrical axis.5 normal electrical axis in the frontal plane - normal limits of the electrical axis (frontal plane): between -30° and +90°.
normal ventricular activation in the horizontal plane - characteristic: transition from the rs morphology, characteristic of v1, to a typical qr in v6, with r progressively increasing to the maximum in v5.4 ventricular repolarization - this ecg analysis is extremely complex, as it represents the interaction of various systems that are expressed in the segments and in the electrical waves.
normal ventricular repolarization - period between the end of the qrs to the end of the t wave or the u wave, when present.
within this period, analyze: j point - end point of the qrs when intersecting with the st segment.
st segment - portion of the ecg between the qrs complex and the t wave.
t wave - asymmetric wave with slow onset and fast ending, positive in almost all leads.
u wave - last and smallest deflection in the ecg; when present, it occurs soon after the t wave and before the p wave of the next cycle, with the same polarity as the t wave.
qt interval (qt) and corrected qt interval (qtc) 6 qt - measurement from the beginning of the qrs to the end of the t wave; represents the total duration of the ventricular electrical activity.
qtc - since the qt varies according to the hr, it is usually corrected (qtc) by the bazett's formula, where: * qt measured in milliseconds and rr distance measured in seconds.
variants of ventricular repolarization: e arly repolarization pattern - characterized by a j-point elevation ≥ 1 mm, leading to a lack of coincidence between the qrs and the baseline, generating an st segment with an upper concavity in at least two contiguous precordial leads, with values also ≥ 1 mm.7-10 analysis of supraventricular arrhythmias supraventricular arrhythmias presence of sinus p wave sinus arrest(sa) - a pause in sinus activity > 1.5 times the basic pp cycle.
second-degree sinoatrial block - leads to a lack of registration of the p wave in a cycle.
type i sinoatrial block (sab i) is characterized by pp cycles progressively shorter until the blockade occurs.
type ii sinoatrial block (sab ii) shows no difference between the pp cycles and the pause corresponds to two previous pp cycles.
first-degree sinoatrial blocks are not visible on standard ecg.
third-degree blocks are observed as an atrial or junctional escape rhythm.
interatrial blocks - conduction delay between the right and left atria, which can be of first degree (p-wave duration ≥ 120 ms), third degree or advanced (p-wave duration ≥ 120 ms, biphasic or with a plus-minus morphology in the inferior wall, related to supraventricular arrhythmias, bayés syndrome), and second degree, when these patterns appear transiently.11 pauses - tracing pauses may be related to the occurrence of sinus arrest, nonconducted atrial extrasystole, sinoatrial block, and av block.
occurrence of a non-sinus p wave before the qrs complex ectopic atrial rhythm - originates in the atrium but in a different location than that of the anatomic region of the sinus node.
multifocal atrial rhythm - originates in multiple atrial foci, with an hr < 100 bpm, recognized in the ecg by the presence of ≥ 3 p-wave morphologies.
atrial escape beat - beat of atrial origin consequent to a temporary inhibition of the sinus node, generated to compensate for the absence of sinus activity.
atrial extrasystole(ae) - early atrial ectopic beat.
blocked atrial extrasystole - ectopic beat originating in the atrium which cannot be conducted to the ventricle; therefore, a qrs complex is not generated.
atrial tachycardia - atrial rhythm originating in a region other than the sinus node, characterized by the occurrence of a different p wave than that of the sinus, with an atrial rate > 100 bpm.
multifocal atrial tachycardia - presents the same characteristics as those of multifocal atrial rhythm, with an atrial rate > 100 bpm.
absence of an antegrade p wave atrial fibrillation(af) - disorganized atrial electrical activity, with an atrial rate between 450 and 700 cycles/min and a variable ventricular response.
the baseline can be isoelectric, with fine or coarse irregularities, or a combination of these changes ("f" waves).
atrial flutter - organized atrial electrical activity; the most common type has a counterclockwise direction with frequencies between 240 and 340 bpm (type i) and a characteristic "f" wave pattern with a sawtooth pattern, which is negative in the inferior leads and generally positive in v1.
junctional rhythm - supplementary or replacement rhythm originating in the av junction, with a similar morphology and duration of the baseline rhythm.
junctional extrasystole - early ectopic beat originating in the av junction.
typical av nodal reentrant tachycardia (avnrt) -12 arises in the av node secondary to nodal reentry, and the circuit uses a fast retrograde pathway and a slow antegrade pathway.
if the baseline qrs is normal and narrow, we may observe pseudo "s" waves in the inferior wall and an rsr' (pseudo r') morphology in v1 during tachycardia.
atypical av nodal reentrant tachycardia - the origin location and the circuit are similar to those of typical avnrt, but the direction of the activation is reversed.
orthodromic atrioventricular reentrant tachycardia - uses the normal conduction system in the anterograde direction and an accessory pathway in the retrograde direction.
the qrs is generally narrow, and the p wave is retrograde, usually located in the st segment.
supraventricular arrhythmias with a wide qrs complex aberrant conduction - supraventricular stimulus with compromised regional propagation in the conduction system, generating a qrs complex with a bundle-branch block morphology.
atrial extrasystole with aberrant conduction - atrial beat with a p wave followed by a qrs with a bundle-branch block morphology.
supraventricular tachycardia with aberrant conduction - generic denomination for the aforementioned tachycardias presenting with aberrant conduction.
antidromic atrioventricular reentrant tachycardia - uses an accessory pathway in an anterograde direction and the conduction system in a retrograde direction; aberrant qrs; is characterized by the morphologic pattern of preexcitation evident in qrs complexes.
criteria to differentiate wide qrs complex tachycardias -(13 )the diagnosis of ventricular tachycardia (vt) includes the presence of an av dissociation, with greater ventricular than atrial rate, or the presence of fusion and capture beats, as well as the presence of tachycardia with wide qrs in the occurrence of a prior acute myocardial infarction.
when these signs are absent, algorithms such as those by brugada and vereckei, are available to help differentiate these tachycardias.14,15 analysis of ventricular arrhythmias ventricular arrhythmias ventricular parasystole - beat that originates in a ventricular focus and competes with the physiological heart rhythm (a parallel pacemaker with a permanent entry block and an occasional exit block).
idioventricular escape rhythm - rhythm that originates in the ventricle, with an hr < 40 bpm, replacing anatomically higher rhythms that are temporarily inhibited.
ventricular escape beat(s) - beat(s) originating in the ventricle as a consequence of temporary inhibition of anatomically higher rhythms; occur late, since they are subsidiary.
idioventricular accelerated rhythm (ivar) - originates in the ventricle (wide qrs), with an hr > 40 bpm, as a result of increased automaticity.
ventricular extrasystole (ve) -( 16) beat originating early in the ventricle, with a postextrasystole pause when the rr interval recycles.
fusion beat - originates in the ventricle and merges with beats from the physiological cardiac rhythm.
conducted supraventricular beat(s) during ventricular rhythm - originates in the atrium, manages to overcome the (anatomical or functional) conduction block in the av junction and partially or entirely depolarize the ventricle.
sustained monomorphic ventricular tachycardia (smvt) - ventricular rhythm with at least three successive beats, uniform morphology, and a rate > 100 bpm.
polymorphic ventricular tachycardia - ventricular rhythm with a qrs of variable morphology and a rate > 100 bpm.
torsades de pointes ventricular tachycardia (tdp)- wide qrs polymorphic tachycardia, generally self-limited, with a qrs that "rotates" around the baseline.
bidirectional tachycardia -17 tachycardia of ventricular origin where the right branch (or rarely the left branch) is constantly blocked while conducting across the ventricle, with alternating blockade of the anterosuperior and posteroinferior divisions of the left branch, beat by beat.
ventricular fibrillation (vf)- characterized by bizarre and chaotic waves, with variable amplitude and frequency.
this rhythm may be preceded by vt or tdp that degenerated into vf.
atrioventricular conduction normal atrioventricular relations - the period from the beginning of the p wave to the beginning of the qrs complex determines the pr interval, a moment when the atrial activation and the physiological retardation in the av junction occur, with a duration of 120 ms to 200 ms. delayed atrioventricular conduction -18,19 occurs when the atrial impulses experience a delay or fail to reach the ventricles.
first-degree atrioventricular block - pr interval > 200 ms in adults with an hr between 60 and 90 bpm.
type i second-degree atrioventricular block (mobitz type i) - the av conduction gradually slows down in this condition (wenckebach phenomenon).
there is a progressive increase in the pr interval, with gradually shorter increases, until the av conduction is blocked and the atrial beat is unable to conduct.
type ii second-degree atrioventricular block (mobitz type ii) - sudden failure in the av conduction.
it is observed as a 1:1 av conduction with a fixed pr interval and a sudden p-wave block.
2:1 atrioventricular block - for every two beats originating in the atrium, one is conducted and depolarizes the ventricle, while the other is blocked and unable to depolarize it.
advanced or high-degree atrioventricular block - the av conduction occurs in less than half of the atrial beats, in a proportion of 3:1, 4:1, or greater.
third-degree or total atrioventricular block (tavb) - stimuli originating in the atrium are unable to reach and depolarize the ventricles; thus, a focus below the blocked region takes over the ventricular rhythm.
as a result, there is no correlation between atrial and ventricular electrical activity rates, which translates as p waves unrelated to qrs complexes.
the frequency of the atrial rhythm is greater than that of the escape rhythm.
paroxysmal atrioventricular block - sudden and unexpected occurrence of a succession of blocked p waves.
preexcitation ventricular preexcitation - characteristics of the classic pattern include a pr interval < 120 ms during sinus rhythm in adults and < 90 ms in children; a notch in the initial portion of the qrs complex (delta wave) interrupting the p wave or appearing immediately after its end; qrs duration > 120 ms in adults and > 90 ms in children; secondary changes in st and t. other mechanisms of changes in the normal av relationship atrioventricular dissociation - occurrence of two dissociated rhythms, one of atrial origin (usually a sinus rhythm with a regular pp) and the other of junctional or ventricular origin.
the frequency at both foci may be similar (isorhythmic dissociation).20 retrograde atrial activation - the atrium is activated by a ventricular stimulation that is conducted retrogradely, usually through the av node or an anomalous track.
a wide qrs (of ventricular origin) is observed, followed by a negative p wave in the inferior leads.
overload of the cardiac chambers atrial overloads left atrial overload (lao) - increase in p wave duration ≥ 120 ms, associated with the emergence of a notch in d2, and a p wave with an increased negative component in the v1 lead (morris index).
right atrial overload (rao) - p wave with peak and amplitude greater than 0.25 mv or 2.5 mm and, in the v1 lead, a positive initial portion > 0.15 mv or 1.5 mm.
biatrial overload (bao) - an association of the lao and rao criteria.
ventricular overloads left ventricular overload (lvo) 21-23 romhilt-estes criteria -24 according to these criteria, an lvo occurs when five or more points are reached in the following scores: three-point criteria - increased qrs amplitude; a strain pattern of repolarization in the absence of digitalis influence; and the morris index.
two-point criteria - deviation of the qrs electrical axis beyond -30º.
one-point criteria - increase in the ventricular activation time (vat) or intrinsicoid deflection greater than 40 ms; increased qrs duration (> 90 ms) in v5 and v6; and a strain pattern under digitalis influence.
sokolow-lyon index -22 considered positive when the sum of the amplitude of the s wave in the v1 lead with the amplitude of the r wave in the v5/v6 leads is > 35 mm.
cornell index - when the sum of the amplitude of the r wave in the avl lead with the amplitude of the s wave in v3 is > 28 mm in men and > 20 mm in women.
changes in ventricular repolarization - flat t wave in the left leads (d1, avl, v5, and v6) or a strain pattern (st depression with negative and asymmetric t wave).
right ventricular overload (rvo) 25 axis - electrical axis of the qrs complex in the frontal plane located to the right of +110(o) in adults.
wide r wave - presence of a high-voltage r wave in v1 and v2, and deep s waves in v5 and v6.
qr or qrs morphology - a qr or qrs morphology in v1, or v1 and v2, is one of the most specific signs of rvo.
rsr' morphology - a triphasic pattern (rsr'), with a more prominent r' wave in the right precordial leads v1 and v2.
t wave - positive t waves in v1 after 3 days of life and up to the age of 6 years, when the r/s ratio in this lead is greater than 1. ventricular repolarization - a strain pattern of repolarization in the right precordial leads.
index - a > 10.5 mm sum of r in v1 + s in v5-v6.
biventricular overload qrs electrical axis in the frontal plane deviated to the right, associated with voltage criteria for lvo.
ecg typical of rvo associated with one or more of the following elements: b.1) deep q waves in v5 and v6, and in the inferior leads.
b.2) r voltage increased in v5 and v6.
b.3) s in v1 and v2 + r in v5 and v6 with positive sokolow criteria.
b.4) intrinsicoid deflection in v6 ≥ 40 ms. wide, isodiphasic, r/s type qrs complexes in intermediate precordial leads from v2 to v4.
analysis of intraventricular blocks (delay, conduction delay) intraventricular blocks -26 changes in the intraventricular propagation of electrical impulses, changing the form and duration of the qrs complex, which can be frequency-dependent and fixed or intermittent.
left bundle-branch block27,28 wide qrs with a duration ≥ 120 ms as an essential condition.
absence of "q" in d1, avl, v5, and v6; variants may have a "q" wave in avl only.
wide r waves with notches and/or mid-terminal slurring in d1, avl, v5, and v6.
"r" wave with slow growth from v1 to v3, with possible occurrence of qs.
wide s waves with thickening and/or notches in v1 and v2.
intrinsicoid deflection in v5 and v6 ≥ 50 ms. qrs electrical axis between -30° and +60°.
st depression and asymmetrical t in opposition to the mid-terminal delay.
left bundle-branch block in association with lvo29 left atrial enlargement.
qrs duration > 150 ms. r wave in avl > 11 mm.
s waves > 30 mm in v2 and > 25 mm in v3.
sâqrs beyond - 40°.
presence of a sokolow-lyon index ≥ 35 mm.
left bundle-branch block in association with rvo low voltage in the precordial leads.
prominent r wave in avr.
r/s ratio lower than 1 in v5.
right bundle-branch block wide qrs with a duration ≥ 120 ms as an essential condition.
slurred s waves in d1, avl, v5, and v6.
qr waves with slurred r in avr.
rsr' or rsr' with thickened r' in v1.
variable qrs electrical axis, tending to the right in the frontal plane.
asymmetrical t wave opposed to a delay at the end of the qrs.
end conduction delay - this expression may be used when the conduction disturbance in the right branch is very subtle.
left fascicular blocks30,31 left anterosuperior fascicular block (lafb) 32 qrs electrical axis ≥ -45°.
rs in d2, d3, and avf with an s3 greater than s2; qrs duration < 120 ms. s wave in d3 with an amplitude greater than 15 mm (or an equivalent area).
qr in d1 and avl with an intrinsicoid deflection time greater than 50 ms or qrs with a minimal "s" in d1.
qr with slurred r in avl.
slow r wave progression from v1 to v3.
presence of s from v4 to v6.
left anteromedial fascicular block (lafb) 33,34 r wave ≥ 15 mm in v2 and v3 or starting in v1, increasing towards the intermediary precordial leads and decreasing from v5 to v6.
"r" wave with sudden growth jump from v1 to v2 ("rs" in v1 to r in v2).
qrs duration < 120 ms. absence of a qrs electrical axis deviation in the frontal plane.
t waves generally negative in the right precordial leads.
qr morphology in v1 to v4.
left posteroinferior fascicular block (lpifb) qrs electrical axis in the frontal plane oriented to the right > +90°.
qr in d2, d3, and avf with r3 > r2 and an intrinsicoid deflection > 50 ms. r wave in d3 > 15 mm.
intrinsicoid deflection duration increased in avf, v5-v6 greater than or equal to 50 ms. rs in d1 with a duration < 120 ms; slower progression of "r" may occur from v1-v3.
s wave from v2 to v6.
right fascicular blocks right superior fascicular block rs in d2, d3, and avf with an s2 > s3.
rs in d1 with an s wave > 2 mm, rs in d1 or d1, d2 and d3 (s1, s2, s3) with a duration < 120 ms. slurred s in v1 - v2/v5 - v6 or, eventually, rsr' in v1 and v2.
qr with a slurred r in avr.
right inferior fascicular block r wave in d2 > r wave in d3.
rs in d1 with a duration < 120 ms. qrs electrical axis in the frontal plane oriented to the right > +90°.
slurred s in v1-v2/v5-v6 or, eventually, rsr' in v1 and v2.
qr with slurred r in avr.
special situations involving intraventricular conduction peri-infarction block - 35 increased duration of the qrs complex in the presence of an abnormal q wave due to myocardial infarction in the inferior or lateral leads, with an increased final portion of the qrs complex directed opposite to the q wave (i.e., qr complex).
peri-ischemia block - 35 transient increase in the duration of the qrs complex accompanied by an st-segment deviation seen in the acute phase.
fragmentation of the qrs complex (fqrs) - 36 presence of notches in the r or s wave in two contiguous leads in the absence of bundle-branch block or, when the block is present, the finding of more than two notches.
atypical left bundle-branch block - 37 occurrence of infarction in a patient with a prior left bundle-branch block.
in this condition, we have the presence of wide and deep q waves, qs pattern in v1-v4, and qr in v5-v6, with qrs fragmentation.
parietal or purkinje/muscle intraventricular block - 38 when the dromotropic disturbance is located between the purkinje fibers and the muscle, observed in severe hypertrophy and cardiomyopathies.
analysis of electrically inactive areas definition of an electrically inactive area (eia) - an eia is considered when the ventricular activation does not occur as expected and does not suggest an intraventricular conduction disturbance.
it is characterized by the presence of pathological q waves in two contiguous leads.
topographic analysis of ischemic manifestations topographic analysis of ischemic manifestations on the ecg anteroseptal wall - v1, v2, and v3 leads.
anterior wall - v1, v2, v3, and v4 leads.
localized anterior wall - v3, v4 or v3-v5 leads.
anterolateral wall - v4 to v5, v6, d1, and avl leads.
extensive anterior wall - v1 to v6, d1, and avl.
low lateral wall - v5 and v6 leads.
high lateral wall - d1 and avl.
inferior wall - d2, d3, and avf.
the terms "posterior wall" and "dorsal wall" should no longer be used.39 infarctions in special locations right ventricular myocardial infarction - st-segment elevation in right precordial leads, particularly with an elevation of the st segment above > 1 mm in v4r.
atrial infarction - visible in the presence of > 0.5 mm pr segment elevation or depression.
diagnostic criteria for myocardial ischemia presence of ischemia subendocardial ischemia: presence of a positive, symmetric, and peaked t wave.
subepicardial ischemia: presence of a negative, symmetric, and peaked t wave; this finding is currently attributed to a reperfusion pattern.
secondary changes in the t wave - are those not fitting within the definition of ischemic waves.
diagnostic criteria for the presence of a lesion subepicardial lesion: j point and st-segment elevation, with a superior concavity or convexity (more specific) in two contiguous leads that explore the involved region, of at least 1 mm in the frontal plane and left precordial leads.
for the precordial leads v1 to v3, consider st-elevations as ≥ 1.5 mm in women, ≥ 2.0 mm in men older than 40 years, and ≥ 2.5 mm in men younger than 40 years.40 subendocardial lesion: 40 depression of the j point and st segment, horizontal or down-sloping ≥ 0.5 mm in two contiguous leads that explore the regions involved, measured 60 ms after the j point.
differential diagnoses subepicardial ischemia - must be distinguished from secondary alterations in ventricular repolarization in lvo or bundle-branch blocks.
acute myocardial infarction with st elevation - must be distinguished from the following situations: early repolarization.
pericarditis and myocarditis.
prior acute myocardial infarction with a dyskinetic area and persistent elevation.
acute abdominal conditions.
hyperkalemia.
catecholaminergic syndromes.
association of myocardial infarction with bundle-branch blocks myocardial infarction in the presence of right bundle-branch block (rbbb) - the presence of an rbbb usually does not prevent the recognition of an associated myocardial infarction.
myocardial infarction in the presence of left bundle-branch block (lbbb) - the presence of an lbbb hinders the recognition of an associated myocardial infarction.
the occurrence of st-segment elevation or depression may allow identification of a recent myocardial infarction, according to the criteria defined by sgarbossa et al.
:41 st-segment elevation ≥ 1.0 mm in agreement with the qrs/t.
st-segment depression ≥ 1.0 mm in v1, v2, and v3.
st-segment elevation ≥ 5.0 mm in disagreement with the qrs/t.
rules on clinical suspicion of acute ischemic disease - a normal ecg does not rule out the presence of coronary heart disease, and the recommendations of specific guidelines for acute coronary syndromes must be followed.42,43 artificial cardiac pacing artificial cardiac pacing (acp) - the recognition of an impaired antibradycardia function is feasible and necessary.
the standardization of the terms used to describe the operations of the acp systems follows an international standardization developed by the north american society of pacing and electrophysiology (naspe) and the british pacing and electrophysiology group (bpeg).
therefore, some of the established terms are used in english.
five letter code first letter: chamber paced o: none a: atrium v: ventricle d: atrium and ventricle second letter: chamber sensed o: none a: atrium v: ventricle d: atrium and ventricle third letter: response to sensing o: none i: inhibited t: triggered d: inhibited and triggered fourth letter: rate modulation o: none r: rate response sensor enabled fifth letter: multisite pacing o: none a: atrium v: ventricle d: atrium and ventricle basic terminology spike: a graphic representation of the electrical stimulation produced by the acp system.
capture: artificial tissue depolarization (caused by the occurrence of the spike).
basic rate: frequency in which the pacemaker stimulates the heart (atrium and/or ventricle) without the interference of spontaneous beats.
atrioventricular interval (avi): interval between a spontaneous atrial activity (perceived) or stimulated and the ventricular stimulation.
hysteresis: time interval above the basic rate, triggered by a spontaneous event.
maximum rate (mr): maximum stimulation rate.
sensitivity: ability to recognize atrial or ventricular spontaneous electrical events.
normal inhibition: absence of spike emission by the pulse generator when the atrial or ventricular channel "feels," respectively, a p wave or a spontaneous qrs.
analysis of the electrocardiographic characteristics of acp systems normofunctioning acp system: normal capture and sensitivity.
acp system with a minimal role of ventricular stimulation: in av systems, there is an increase in the avi or periodic change to the aai operating mode, with the aim of seeking a spontaneous av conduction.
loss of atrial and/or ventricular capture (intermittent or persistent): inability of a spike to trigger depolarization of the paced chamber.
sensitivity failure: d.1) excessive sensitivity (oversensing): exaggerated sensitivity, resulting in misidentification of an electrical signal that does not correspond to the depolarization of the related chamber (electromagnetic interference, myopotentials, t wave, etc.).
d.2) decreased sensitivity (undersensing): inability to recognize spontaneous depolarization.
it may occur due to inadequate planning or modifications in the capture of intrinsic signal (in which the system does not "see" the p wave or the qrs complex).
fusion beats: correspond to the artificial activation of the cardiac tissue simultaneously to the spontaneous depolarization, causing complex hybrids.
pseudofusion beats: spontaneous activation of the cardiac tissue simultaneous to the emission of the spike of the pacemaker, which has no effect on the qrs complex or p wave (ventricular and atrial pseudofusion, respectively).
pacemaker-mediated tachycardia: arrhythmia restricted to the av stimulation systems, characterized by ventricular triggering from a retrograde p wave.
pacemaker-conducted tachycardia: tachyarrhythmia that involves the av stimulation systems, characterized by the presence of supraventricular arrhythmia that when perceived by the atrial channel triggers ventricular captures in higher frequencies, maintaining certain characteristics of spontaneous arrhythmia.
pacemaker-induced tachycardia: changes in sensitivity or electromagnetic interference causing arrhythmias.
criteria for characterization of pediatric electrocardiograms analysis of pediatric electrocardiograms -44,45 difficulties in establishing normal electrocardiographic standards in children arise from various aspects that should always be considered in the analysis of pediatric ecgs: the characteristics of the electrocardiographic tracing should be assessed according to the age of the child.
the existence of a thoracic deformity or poor cardiac position limits the interpretation of the ecg.
the ecg of newborns reflects the hemodynamic repercussions on the right ventricle occurring during the intrauterine life and the anatomic and physiological changes deriving from the transition of the fetal circulation to the neonatal circulation.
the ecg in children shows the progressive reduction in the right ventricle domain until it reaches the characteristic pattern of physiological left ventricular predominance, as observed in the ecg in adults.
table 1, elaborated by davignon et al.,44 presents the reference values of the electrocardiographic parameters in children at various ages.
it shows the main ecg changes in the first year of life, particularly in the neonatal period (from day 1 to 30).
special considerations in the analysis of pediatric electrocardiograms definition of situs - it is based on the location of the sinus node.
in situssolitus, the p wave axis is around +60°, while in situs inversus, the p axis is +120°, with a consequently negative p wave in d1.
"q" waves - the presence of a "q" wave in v1 is always considered pathological, while in v6, it is present in 90% of the children above the age of 1 month.
t wave - it may be negative in d1 and positive in avr in the first hours of life.
in the first 48 hours of life, the t wave tends to be positive in v1, becoming negative after 3 to 7 days and becoming then again positive in pre-adolescence.
the ecg in channelopathies and other genetic alterations genetics and the electrocardiogram - an innovative field in cardiology that emerged in recent years was the report of potentially fatal clinical conditions that present a characteristic electrocardiographic pattern, and the improvement in genetic mapping techniques.
channelopathies - cardiac channelopathies result from genetic mutations or acquired malfunctioning of ion channels responsible for triggering changes in depolarization or repolarization in the action potential phases of the cell.
congenital long qt syndrome -46 its main characteristic is the prolongation of the qtc interval on the ecg, with values > 460 ms. clinically, the presence of syncope or cardiac and respiratory arrest triggered by emotional and physical stress should raise the hypothesis of long qt (lqt) syndrome.
ecg characteristics: lqt1: normal t wave with a wide base and late start.
lqt2: t wave with low amplitude.
lqt3: late t wave, after a long and straight st. short qt syndrome -47 recently described entity (2000) characterized by the finding of a short qt interval associated with af and sudden cardiac death.
the genetic defect in this condition is an increased functioning of potassium channels, which operate in the third phase of the action potential, shortening the qt interval.
the syndrome is mainly related to the kcnh2, kcnq1, and kcnj2 genes.
ecg findings include a short qtc interval (< 370 ms) and a distance between the j point and the peak of the t wave < 120 ms. brugada syndrome -48,49 channelopathy expressed by a defect in sodium channels in the right ventricle (rv) epicardium.
this syndrome affects mainly men and individuals with a family history of sudden death.
it is transmitted by autosomal dominant inheritance and is responsible for 20% of the sudden deaths with a normal heart at autopsy.
it is genetically heterogeneous, involving at least 13 genes.
on the ecg, it is characterized by a j-point elevation in the v1 and v2 leads, with two possible presentations: type 1 pattern: coved st-segment elevation ≥ 2 mm, followed by t-wave inversion, with a significantly slow r' decline.
type 2 pattern: saddle-shaped st elevation with a ≥ 2 mm peak and ≥ 1 mm base.
catecholaminergic tachycardia -50 the following characteristics should raise suspicion of this condition: history of sudden death in the family with reports of syncope starting during childhood and adolescence, associated with ventricular extrasystoles with an hr between 110 and 130 bpm (generally isolated, intermittent, bigeminal and paired), which are usually interrupted by an increased hr.
approximately 30% of the individuals may present qt intervals between 460 ms and 480 ms. between 50 to 60% of the cases of catecholaminergic polymorphic vt (pvt) derive from inherited or sporadic mutations in ryanodine channels, which are responsible for regulating the intracellular calcium.
genetic diseases with primary cardiac involvement arrhythmogenic right ventricular dysplasia-51 genetic disease with primary involvement of the rv (replacement of myocytes with fibrofatty tissue), associated with arrhythmias, heart failure, and sudden death.
the ecg is characterized by the presence of a delay in the conduction of the qrs, with a low voltage and longer duration (epsilon wave, present in 30% of the cases), associated with rounded and asymmetrical negative t waves in v1 to v4 leads.
association with extrasystoles originating in the rv.
hypertrophic cardiomyopathy - 52 a primarily cardiac disease of genetic basis with autosomal dominant inheritance, with 23 described genetic mutations.
it occurs with severe segmental or diffuse left ventricular hypertrophy.
the ecg is altered in at least 75% of the patients, with a good sensitivity for the pediatric age group.
it is characterized by rapid and deep q waves in inferior and/or precordial leads, generally associated with classical signs of lvo and accompanied by characteristic st-t changes.
genetic diseases with secondary cardiac involvement muscular dystrophy -53 the most common electrocardiographic findings are the presence of a wide r wave (ratio r/s > 1) in v1 and v2; deep q wave in v6, di, and avl; right bundle-branch conduction delay; qs complexes in i, avl, d1, d2, and d3; and ventricular repolarization changes.
electrocardiographic alterations in athletes the importance of the electrocardiogram of athletes - 54,55 it is currently necessary to understand the "athlete's ecg," i.e., electrocardiographic changes arising from high-performance training, without a necessary presence of anatomical and/or structural changes, considered as part of the "athlete's heart."
common electrocardiographic changes or related to training: sinus bradycardia.
sinus phasic or respiratory arrhythmia.
increased pr interval.
increased voltage of the r or s waves between 30 to 35 mm.
change in ventricular repolarization, of the early repolarization type.
right bundle-branch conduction delay.
second-degree av block, mobitz i type.
ventricular overload pattern by voltage criteria only (sokolow-lyon).
characterization of special clinical/systemic situations clinical conditions that alter the electrocardiogram digitalis action - st-t depression with superior concavity ("spooned" t wave); decreased qtc interval.
in digitalis intoxication, several arrhythmias may occur, predominantly ventricular extrasystole.
drug-induced st-t changes - increased qtc interval.
electrical alternans - presence of qrs with alternately higher and lower amplitudes in successive qrs complexes.
t-wave alternans - characterized by a variation in t-wave amplitude, shape, and orientation, beat by beat.
these variations may be episodic or permanent.
atrial septal defect - delay in the end conduction through the right branch and possible association with rvo.
pericardial effusion - low qrs voltage, sinus tachycardia, and electrical alternans.
dextrocardia with situs inversus totalis - p wave negative in d1 and positive in avr; negative qrs complexes in d1 and avl, and progressively lower from v1 to v6.
dextroposition - may manifest with a negative or plus-minus p wave in d1, deep q wave in d1 and avl, and qrs complexes in right precordial leads.
electrolyte disorders hyperkalemia - the changes depend on the serum potassium concentrations; occur in a sequence: t wave with increased amplitude, symmetric, and with a narrow base; decreased qtc interval; intraventricular conduction disturbance; decreased p wave amplitude until disappearance, with the presence of sinoventricular conduction.
hypokalemia - increased u wave amplitude; st segment and t-wave depression; increased qtu interval.
hypocalcemia - straightening and increased duration of the st segment with a consequent increase in the qtc interval.
hypercalcemia - shortening and eventual disappearance of the st segment.
chronic obstructive pulmonary disease - rightward shift of the p wave axis (close to +90(o)); low qrs voltage; rightward shift of the qrs axis; posterior deviation of the transition precordial qrs zone to the left (rs from v1 to v6).
low qrs voltage - low voltage of the qrs complex across the tracing (< 0.5 mv in the frontal plane leads and < 1.0 mv in the precordial leads).
pulmonary embolism- sinus tachycardia, end conduction delay in the right branch, acute deviation of the qrs axis to the right, and negative t waves in the anterior wall of the lv.
ashman (or gouaux-ashman) phenomenon- aberrant conduction that occurs in a beat that immediately follows a short cycle after a long cycle, due to an increased refractory period in the conduction system, found more frequently in af.
hypothermia- bradycardia, presence of j or osborn wave.
hypothyroidism- bradycardia and low qrs voltage.
chronic renal failure- association of the hyperkalemia and hypocalcemia alterations.
acute impairment of the central nervous system- giant negative t waves simulating subepicardial ischemia (cerebral t wave); increased qtc interval.
pericarditis - the inflammatory process arising from underlying epicarditis in the ventricles is responsible for the following electrocardiographic changes: t wave: slightly increased and symmetrical in the initial phase.
characteristically, it is not inverted in the presence of manifestations of st elevation.
st segment: diffuse elevation with upper concavity.
pr segment depression.
criteria for technical evaluation of the tracings calibration of the electrocardiograph - in modern computerized equipment with digitized tracings, the calibrator pattern is verified automatically.
the normal pattern must have 1 mv (10 mm).
positioning of the electrodes swapped limb electrodes - show d1 leads with negative waves and avr with positive waves.
right lower limb electrode swapped with one from the superior limbs - small wave amplitudes in d2 (right arm) or d3 (left arm).
swapped precordial electrodes - change in the normal progression of the r wave from v1 to v6.
misplacement of the v1 and v2 electrodes - v1 and v2 electrodes positioned incorrectly above the second intercostal space may produce an rsr' pattern simulating an end conduction delay, or an rs morphology from v1 to v3, and negative p wave in v1, simulating an lao.
alterations resulting from improper operation of software and systems for the acquisition of computerized electrocardiographic signs - the use of data acquisition by computerized systems has begun to reveal specific new problems that are not yet fully known.
other interferences muscle tremors - muscle tremors can interfere with the baseline, mimicking electrocardiographic changes such as af and vf in patients with parkinson's disease.
neurostimulation - patients with disorders of the central nervous system requiring the use of artificial electrical stimulation devices may present artifacts that mimic the spike of a cardiac pacemaker.
cold, fever, hiccups, and psychomotor agitation - also produce artifacts in the baseline.
large precordial electrode - the application of the conductive gel in a continuous strip in the precordium results in similar tracings from v1 to v6, corresponding to the average of the electrical potentials in these leads.2 automated reports - metric and vectorial measurements are not recommended, neither reports obtained with these systems, since the report is a medical act.
reports via the internet - tele-ecg56 systems register electrocardiographic tracings obtained remotely by using different means and data transfer technologies able to accurately reproduce the examination conducted with 12 simultaneous leads following national and international guidelines.
@highlight
the third version of the guidelines covers recently described topics, such as ion channel diseases, acute ischemic changes, the electrocardiogram in athletes, and analysis of ventricular repolarization.
it sought to revise the criteria for overloads, conduction disorders, and analysis of data for internet transmission.
