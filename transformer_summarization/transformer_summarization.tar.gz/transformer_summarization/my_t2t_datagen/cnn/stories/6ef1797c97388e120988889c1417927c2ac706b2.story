introduction testicular cancer is the most common solid malignancy in men between the ages of 15 and 40 years, representing 2–3% of all male cancers, with 3–6 new cases occurring per 100,000 males/per year in western countries.
testicular germ-cell tumours, seminomas (sgct) and non-seminomas (nsgct), are the most frequent, with a peak incidence occurring in the fourth decade of life for pure seminoma and in the third decade of life for non-seminoma [1].
the incidence of bilateral testicular tumours, which is estimated to be around 2–5%, is rare [2, 3].
approximately 65–75% of these bilateral tumours are metachronous [4, 5].
the majority are seminomas, and they are histologically almost always identical [6–8].
patients with bilateral testicular tumours, synchronous or metachronous, present with different problems requiring careful management to permit a good quality of life.
here we review the literature on oncological outcome and management of synchronous bilateral testis cancer (sbtc), with specific emphasis on epidemiology, risk factors, and long-term sequelae in survivors.
material and methods in 1988 dieckmann et al.
[6], after a revision of the literature, reported a total of 151 cases of bilateral synchronous cancer, and 114 of these (75.5%) demonstrated seminoma in both testicles.
by contrast, other authors reported an inversion of the incidence in the last years [4, 9].
in a review of cancer registries of the national cancer institute’s surveillance, epidemiology, and end results (seer) program [5] for testis cancer, the authors estimated a prevalence of 0.6% (175 of 29,515) for synchronous bilateral testicular cancer.
in 45% (61 of 135) of those in which the extent of the disease was known there was a regional or distant localisation, with a 10-year overall survival rate in 85% of all patients.
in this article the incidence of bilateral seminoma was 50% (88 of 175) with 34% (59 of 175) of patients having discordant histology.
this data is confirmed in other series [3, 4, 6, 9, 10].
additionally, synchronous tumours were metastatic at presentation [2, 3, 5, 9].
the studies by holzbeierlein et al.
[4] and by the national institute of oncology in hungary [11] represent an exception because they report that most patients in the synchronous tumour group presented with low-stage disease, respectively, 60% (6 of 10) and 68% (13 of 19).
in the literature bilateral synchronous testis cancer are reported as isolated case reports or small series.
we performed a pubmed search for all english language publications with the following quest terms: bilateral testicular cancer, bilateral testicular germ cell tumour, and bilateral testicular neoplasm.
inclusion criteria comprise: series with more than three patients and containing relevant information about clinical and oncological features in relation to histology and stage.
we identified 13 studies with more than three cases of sbtc [2–5, 9, 10, 12–18], but only 10 of them [2–4, 9, 10, 13, 15, 16, 18] described separately the different outcomes of sbtc with distinction based on histology and stage.
the major series reported in the literature and their results can be seen in table 1. table 1 major series reported in the literature author histology stage follow up (months) akdogan et al.
[2](1980–2005) 1 ss2 nsns (ter/ter)3 mx all stage iii nedminimum follow up 41 klatte et al.
[3](1982–2007) 4 ss2 mx 2 stg i2 stg ii1 stg ii1 stg iii 24 & 70 ned191 & 118 ned205 ned124 ned holzbeierlein et al.
[4](1950–2001) 3 ss7 mx 2 stg i1 stg ii4 stg i2 stg ii1 stg iii nedmedian follow up 60 hentrich et al.
[9](1979–2003) 4 ss3 nsns7 mx 2 stg 12 stg ii3 stg iii3 stg i3 stg ii1 stg iii 6 & 46 ned47 ned; 29 dod0.5 & 24 & 32 dod22 & 7 & 76 ned67 & 4 & 31 ned40 ned coogan et al.
[10] 3 ss1 nsns (ter/ter)1 mx 2 stg i1 stg iistg iiistg ii 22 & 9 ned20 ned168 ned113 ned che et al.
[12] (1978–1999) 3 ss1 mx (s/ca emb) 3 stg istg iii 27 & 27 & 18 ned41 dod tomita et al.
[13] (1988–2005) 5 ss1 nsns (ca emb/ca emb) 3 stg i2 stg iistg iii 86 &82 & 24 ned23 & 24 ned11 dod redmond et al.
[15](1947–1993) 3 ss1 nsns3 mx 2 stg i1 stg iistg iii3 stg ii 36 & 72 ned78 ned12 dod24 & 48 & 6 ned heidenreich et al.
[16] (1974–1991) 2 ss1 nsns (ter/ter)1 mx (s/ca emb)1 bil leydig cell tumour 2 stg istg istg iistg i 145 & 59 ned45 ned45 ned42 ned ferretti et al.
[18](1984–2013) 5 ss2 nsns2 mx (1ns/ epid cyst)1 bil leydig cell tumour 5 stg i2 stg ii2 stg i1 stg i 32 & 10& 95 & 14 & 20 62 &120 all9 &69 ned106 s – seminoma; ns – non seminoma; mx – mixt; ter – teratoma; ca emb – embryonal carcinoma; epid cyst – epidermoid cyst; ned – no evidence of disease; dod – dead of disease akdogan et al.
[2] reviewed patients treated for bilateral testicular cancer in two tertiary centres in turkey with six cases of synchronous cancer.
two of these had seminoma histology on both sides, the remaining had non-seminoma histology.
all six patients had metastatic disease at presentation (stage iii).
they were treated with chemotherapy, and no evidence of disease was found at the last follow-up with a minimum length of 41 months.
klatte et al.
[3] reported six patients with synchronous bilateral testicular cancer.
four patients presented with synchronous seminoma, two stage i, and two stage ii (retroperitoneal lymph nodes), three underwent radiotherapy, and the fourth (stage i) developed lymph nodes retroperitoneal recurrence after 18 months and received chemotherapy.
the two discordant histology cases were seminoma and mixed germ cell tumour with stage ii and iii (retroperitoneal lymph nodes and lung metastasis, respectively), both treated with chemotherapy and retroperitoneal lymph node dissection.
all patients were alive after a median follow-up of 121 months.
holzbeierlein et al.
[4] reviewed the experience of the memorial sloan kettering cancer centre with 10 cases of synchronous bilateral tumours.
only in three cases histology was concordant (bilateral seminoma).
retroperitoneal lymph node dissection was performed in four patients with discordant histology (three stage i, one stage ii); chemotherapy in three patients (two stage ii, one stage iii), one with bilateral seminoma (stage ii), radiotherapy in two seminoma (stage i), and one patient preferred surveillance protocol (stage i).
after a median follow up of 29.5 months no patient had had a recurrence.
hentrich et al.
[9] reported 14 cases of synchronous testis cancer.
concordant histology was present in seven cases (four seminoma, three non-seminoma).
radiotherapy was performed in three bilateral seminoma (one stage i and two stage ii) with one case of stage ii relapsing after 28 months, being treated with chemotherapy but dying after one month.
the remaining bilateral seminoma (stage i) was treated with chemotherapy and he was alive after 46 months.
six patients with discordant histology were treated with only chemotherapy, one patient (stage iii) died after 40 months for neutropenic sepsis, while at a median follow up of 28.5 months the remaining bilateral sgct had no evidence of disease.
the other case with discordant histology in stage i, underwent retroperitoneal lymph node dissection and was still alive after 76 months.
the three non-seminomas concordant histology were all in stage iii disease, they received chemotherapy but died after a median of 18.8 months (range 0.5–32).
in the series of indiana university, reviewed in 1998 [10], there were five cases of synchronous testis cancer, three bilateral seminoma (two stage i treated with radiotherapy and one stage ii treated with chemotherapy) with no evidence of disease after a median follow-up of 17 months, one bilateral stage iii teratoma, who underwent post-chemotherapy retroperitoneal lymph node dissection and was still alive after 168 months and one case with stage ii discordant histology, with no evidence of disease after chemotherapy.
the anderson cancer centre reported in 2002 [12] four cases of synchronous bilateral germ cell tumours, with one case of discordant histology in stage iii treated with chemotherapy dying after 41 months, the remaining cases were bilateral seminoma in stage i undergoing post-orchiectomy radiotherapy and being alive after 18 and 27 months, respectively.
tomita et al.
[13] in 2007 described six cases, all of whom had concordant histology with five bilateral seminoma; three out of five (two stage i and one stage ii) were treated with conservative chemotherapy (three cycles of bleomycin, etoposide, and cisplatin) with one testis preservation, no evidence of disease was revealed after 82 months and two years, respectively.
the other two (stage i and ii) underwent bilateral orchiectomy and chemotherapy with the same regimen, and no evidence of disease was observed after 86 and 23 months, respectively.
the only bilateral stage iii non-seminoma died after 11 months.
a multicentre review reported seven cases [15]: three bilateral seminoma (two stage i and one stage ii), who received radiotherapy, both stage i were alive after six and three years, whereas the stage ii case developed metastatic recurrence after 6.5 years and died; one case of bilateral non-seminoma, stage iii disease died after one year; three cases with discordant histology, all of them being stage ii, one of these underwent retroperitoneal lymph node dissection and was alive after two years, the other two received chemotherapy with no evidence of disease after one and four years.
in 1995 heidenreich et al.
[16] presented their experience with testis-sparing surgery in bilateral testicular cancer.
in their series there were five synchronous tumours.
in three cases they performed a conservative approach.
two of them had discordant histology (stage i and ii), while the concordant histology cases were bilateral seminoma in two cases (stage i) and bilateral teratoma in one (stage i).
all the patients had no evidence of disease with a median follow-up of 67 months (range 42–145 months).
the last article in order of time is reported by ferretti et al.
[18], who described their results in 11 patients with sbtc undergoing testis-sparing surgery, of whom one was lost to follow-up.
in their series four cases underwent subsequent radical orchiectomy (massive tin, positive surgical margin, rete testis invasion, recurrence after two years).
lymphadenectomy and chemotherapy were performed in the two patients with bilateral nsgct stage ii.
in two patients with bilateral seminoma scrotal radiotherapy was performed, and three were treated with chemotherapy (two bilateral seminoma and one mixed histology).
after a mean follow-up of 53.7 months, all patients are free from any recurrence with no need of hormonal substitution.
in summary, from a total of 73 patients were recorded, with the exclusion of two cases of bilateral leydig cell tumour, 60.5% (44/71) had a concordant histology.
of these, 75% (33/44) were bilateral seminoma.
in most cases (69.7%, 23/33) bilateral sgct was diagnosed at stage with an overall survival of 100% (median follow-up 45.4 months, range 6–145).
the 72.7% (8/11) of bilateral nsgct are stage iii, with 62.5% (5/8) mortality for disease progression.
the mixed form has a heterogeneous stage presentation: 44.4% (12/27) stage i, 29.6% (8/27) stage ii, and 26% (7/27) stage iii.
only one death for disease was reported in patients with stage iii (seminoma + embrional carcinoma).
results epidemiology and risk factors the incidence of testicular cancer appears to be increasing, while the age at which it develops seems to be decreasing [7, 19].
however, the causes of this trend remain unclear [20].
in the last two decades several studies reported an incidence of bilateral testicular cancer of between 2 and 5% [2, 3].
synchronous bilateral tumours can be estimated to represent 0.5–1% of all new testicular cancer cases [3, 7].
risk factors for bilateral testis cancer, either synchronous or metachronous, are the same as for testis cancer: atrophy of the testis, infertility, klinefelter’s syndrome, a family history of testicular cancer, and a history of cryptorchidism or undescended testis (testicular dysgenesis syndrome) [21–23].
this risk is greater when two or more factors are present.
it was proposed that 25% to 33% of all patients have a genetic predisposition [24].
the influence of molecular and genetic risk factors has also not been established.
it is well known that primordial germ cells or gonocytes play a key role in the pathogenesis of testicular germ cell carcinoma [25].
their migration and survival depends on the c-kit protein, a receptor protein kinase expressed in intratubular neoplastic germ cells and in seminoma.
two studies detected a point mutation in the c-kit codon 816 in the majority of the bilateral testis cancer [25, 26].
however, more recent reports are not in agreement with these early studies [19–28].
other genetic changes, gene mutations on chromosomes 4, 5, 6, 9, 12, and 17, have been described in patients with testicular cancer [29–32].
the implication of these risk factors is not clear in patients with synchronous testis cancer, unless organ-preserving surgery is indicated.
in this case we have to consider the presence of tin (testicular intraepithelial neoplasia), now commonly known as intratubular germ cell neoplasia (itgcn) [33, 34], or stem cell factor receptor c-kit [25] in the surgical multiple biopsies taken from the remaining parenchyma, as some authors advise [35].
it is especially important to pay attention to the presence of itgcn because it is considered a premalignant lesion.
its incidence is higher in patients with the same risk factors of bilateral testis cancer.
in the literature it is well reported that if itgcn is present on testicular biopsy and is left untreated, the developing risk of malignancies in the testis is 50% within five years and 70% within seven years [36].
despite the fact that testicular biopsy in testis cancer is not routinely performed in clinical practice, it should be regularly considered in bilateral testis cancer and in cases of testis-sparing surgery [37].
however, it must be considered that treatment decisions for patients with synchronous tumours were formulated on the basis of risk stratification, as defined by the international germ cell consensus classification (igcccg) [38].
treatment bilateral radical orchiectomy is considered the standard of care in cases of synchronous testis cancer with impaired pre-operative testosterone levels, when tumour volume is more than 30% of the testicular volume, in spite of collateral effects such as erectile dysfunction, infertility, and psychological distress.
furthermore, when testosterone concentration does not remain within the normal limit for endocrine failure, its lifelong substitution is mandatory [39].
testis-sparing surgery has been developed as an alternative to radical orchiectomy, with the advantage that androgen production, body image, and fertility can all be preserved [40, 41].
in patients with bilateral testicular cancer heidenrich et al.
[42] described testis-sparing surgery to avoid lifelong androgen replacement and preserve fertility.
other authors report patients with a better quality of life and with a disease-free survival rate comparable with radical orchiectomy [17, 18, 43].
the surgical technique is nowadays codified [44].
some authors suggest partial testicular resection in cold ischaemia [44, 45].
organ preserving surgery can be performed if the tumour is < 2 cm in diameter, confined to the testis (or at least smaller than 30% of the testicular volume), and preoperative serum levels of both testosterone and luteinising hormone (lh) are normal [46].
as previously declared, a major problem of this surgery is the presence of itgcn in the adjacent parenchyma.
biopsy of the remaining parenchyma in all patients who have undergone conservative surgery is recommended to establish the presence of these premalignant lesions and multifocality of the tumours.
in fact, itgcn was proven as a risk factor to developing a tumour in 50% of men within 5 years [36].
heidenreich et al.
[45] reported the presence of tin in 82% of 73 patients with bilateral or solitary tumour.
all patients were treated with testis-sparing surgery and adjuvant scrotal radiotherapy (18 gy).
none of them had any sign of local relapse, with 85% of normal testosterone levels at long-term follow-up.
therefore, if itgcn is discovered, irradiation therapy must be administrated, although the optimal radiotherapy schedule is still controversial.
currently the standard radiation dose is 20 gy [47], with evidence of leydig cell function being affected at doses of 14–20 gy [48, 49].
a low radiation dose can compromise oncological outcome despite there having been few cases of radiation failure [48–52].
a survey of the german testicular cancer study group reported a 2.5% failure rate after radiotherapy with a 30.8% of post-treatment hypogonadism, even if 22% of them had received additional chemotherapy [53].
giwercman et al.
[54] reported no evidence of local recurrence after a median follow up period of 30 months (range 3–36) in patients treated with a 20-gy schedule.
nevertheless, 25% of them required hormone supplementation because of leydig cell dysfunction.
as an alternative to bilateral surgery, a recent report suggests that synchronous bilateral seminoma can be successfully treated with unilateral orchiectomy for the larger tumour, followed by three courses of chemotherapy with cis-platinum, etoposide, and bleomycin [13].
however, this protocol, which must be considered as experimental, did not take into account that recurrence can be seen even after chemotherapy, which is inactive on intraepithelial neoplasia [53, 55].
this aspect is the major drawback and limitation of this study.
furthermore, after organ-preserving surgery chemotherapy and radiation treatment can also impair fertility.
in patients in the reproductive age group, if descendants are desired, pre-treatment fertility assessment (testosterone, lh, and follicle-stimulating hormone [fsh] levels) should be performed, and semen analysis and cryopreservation should be offered.
if cryopreservation is desired, it should be preferably obtained before orchiectomy, and in any case prior to chemotherapy treatment [56–58].
hormonal replacement in case of bilateral orchiectomy or post-radio-chemotherapy damage of leyding cells, testosterone substitution is important in an attempt to minimise the long-term adverse effects and risks associated with low levels of testosterone, such as osteoporosis.
furthermore, testosterone insufficiency in older men is associated with an increased risk of death over the subsequent 20 years [59].
low testosterone levels have also been linked to metabolic syndrome and type ii diabetes, with both conditions being associated with cardiovascular disease, and shown to predict elevated overall and cardiovascular-related mortality in middle-aged and older men [60, 61].
for these reasons testosterone replacement is mandatory after bilateral orchiectomy.
on the other hand, testosterone replacement causes polycythaemia and an increase in cardiac risk profile because of greater blood viscosity, changes in lipoproteins, and insulin resistance.
additionally, it is important to choose a suitable way of administration.
in fact, oral testosterone is not recommended for complete hypogonadism, such as would occur after bilateral orchiectomy.
intramuscular testosterone injections frequently result in fluctuating levels of testosterone outside the physiological range at least 50% of the time, with serum testosterone levels that are initially supra-physiological and then sub-therapeutic.
these abnormal testosterone serum levels cause a considerable variation in the scores for sexual functioning and physical well-being; furthermore, all patients found the injections tiresome and painful.
transdermal patches release testosterone more physiologically but can cause skin irritation, which is the main adverse effect, annoying enough to stop treatment in 10 to 50% [62–64].
subcutaneously implanted testosterone pellets release testosterone slowly, thus achieving physiological testosterone levels for up to 4–6 months.
complications such as dislodgement and infection occur in 10% of cases, but patient acceptance is high.
survival with regard to oncological results, in a recent systematic review [65] the synchronous tumour had a lower five-year overall survival and five-year disease-specific survival than the metachronous tumour.
at the statistical analysis the patients with a higher clinical stage and discordant histology had a worse prognosis, but when patients with the same clinical stage are compared, no difference in terms of five-year overall survival and five-year disease-specific survival was recorded between the two groups.
however, these conclusions did not take into account the different histology of bilateral testis cancer.
considering previously reported series, patients with bilateral seminoma presented with a low stage at diagnosis and they had a good overall survival, whereas cases with bilateral nsgct have poor prognosis and high stage at presentation.
the outcome of patients with advanced non-seminomatous synchronous bilateral testis cancer is dependent on igcccg prognostic categories.
the presence of non-pulmonary visceral metastases, elevated tumour marker levels, vascular/lymphatic in- or peri-tumoural invasion, proliferation rate > 70%, and percentage of embryonal carcinoma > 50% are negative prognostic factors [38].
follow-up the follow-up schedule is the same for patients with unilateral testis cancer.
life-long follow-up may be advocated because of a small risk for late relapse.
close clinical control, with ultrasound of the testis, may therefore be recommended for patients undergoing testis-preserving surgery.
patients with sbtc must be followed-up not only for oncological issues but also for the risk of psychosocial and physical effects due to curative treatment (surgery alone or plus radio-chemotherapy) and hormonal replacement therapy [39, 66, 67].
in conclusion, with modern therapeutic options and the introduction of cis-platinum chemotherapy, most patients with synchronous bilateral testicular germ cell tumours will become long-term survivors with the same overall survival and disease specific survival than metachronous patients.
consequently, short- and long-term morbidity and psychosocial difficulties may become the major problems.
cancer can be cured in long-term survivors only if their quality of life after treatment can be restored to the previous level.
testis-sparing surgery must be performed whenever possible.
patients with germ cell tumours require a lifelong follow-up.
@highlight
synchronous bilateral testis cancer (sbtc) is a rare event.
it represents only 0.5–1% of all new cases of testicular cancer.
patients with this disease require careful management for psychological, oncological, and medical problems.
we performed a pubmed search for all series that reported sbtc.
we considered only articles in english, reporting on more than three cases.
we also performed an analysis of the reported evidence regarding testosterone replacement and surgical treatment.
we found 10 studies satisfying inclusion criteria for a total of 73 patients.
the majority are bilateral seminoma, which present with a low stage at diagnosis, and mixed histology tumours, both with a good overall survival.
on the other hand, cases with bilateral non-seminoma histology are associated with poor prognosis and high stage at presentation.
testis-sparing surgery should be an eligible choice in selected cases, to preserve fertility and avoid testosterone deficiency.
multiple biopsies are recommended in these patients, and in the case of intratubular germ cell neoplasia (itgcn) presence, scrotal radiotherapy is mandatory.
subcutaneous testosterone pellets guarantee higher patient acceptance and physiological testosterone levels.
lifelong follow-up and psychological support, with special care for infertility and erectile dysfunction, must be considered in this cohort of patients.
