mayaro virus (mayv; genus alphavirus, family togaviridae) is a single-stranded positive rna virus that was first isolated in trinidad in 1954 (1) and is one of the viruses that comprise the semliki forest virus complex (2).
its transmission cycle is thought to occur mainly through mosquito vectors, especially those of genus haemagogus (3), but aedes spp.
mosquitoes may also be competent vectors (4,5).
the natural reservoirs of mayv have been reported to be sylvatic vertebrates, mainly nonhuman primates but also birds and reptiles (3).
since may 2014, when chikungunya virus (chikv) swept across the island of hispaniola, researchers at the university of florida (gainesville, fl, usa) have studied alphavirus and flavivirus transmission in haiti in collaboration with the christianville foundation.
this foundation operates 4 schools in the gressier/leogane region of haiti (≈20 miles west of port-au-prince) that serve ≈1,250 students from prekindergarten to grade 12 (6).
the university of florida has protocols in place for the collection of diagnostic blood samples from children seen at the school clinic with acute undifferentiated febrile illness (i.e., febrile illness with no localizing signs, such as would be expected with pneumonia, urinary tract infections, etc.).
from may 2014 through february 2015, blood samples were obtained from 177 children who met the criteria for acute undifferentiated febrile illness.
the protocol for sample collection was approved by the university of florida institutional review board and the haitian national institutional review board.
written parental informed consent was obtained from parents or guardians of all study participants.
plasma samples were screened by reverse transcription pcr (rt-pcr) for chikv and dengue virus (denv); samples that were negative for chikv were cultured by using cell lines and conditions as previously described (7).
zika virus and enterovirus d68 have been previously isolated from members of this school cohort (7,8).
we report detection of mayv in a child as part of this screening process.
the case on january 8, 2015, an 8-year-old boy was examined at the school clinic because of fever and abdominal pain.
his temperature was 100.4°f, lung sounds were clear, and his abdomen was soft and not tender.
he had no rash and no conjunctivitis.
on the basis of this clinical presentation, the clinic physician empirically diagnosed typhoid and administered co-trimoxazole.
a blood sample was collected, and rna was extracted from plasma by using rt-pcr primers and the procedure described by santiago et al.
(9).
the sample was negative for chikv but positive for denv-1 (cycle threshold 26).
in vero e6 cells, which had been inoculated with the specimen, diffuse cytopathic effects typical for denv-1 developed but at a much later time than for denv-1–positive plasma specimens from other patients; this finding raised the possibility that denv-1 had either mutated to reduced replication fitness or that the cells were co-infected with >2 incompatible viruses that were interfering with the replication of each other.
denv-1 viral rna was detected by rt-pcr in the spent cell media of the plasma-inoculated cells but not in the spent media from noninoculated cells (negative control; technical appendix).
furthermore, no chikv- or zika virus–specific amplicons were amplified from the spent media.
however, apart from denv-1, an alphavirus amplicon corresponding in size to that expected for mayv was detected in viral rna extracted from infected vero cells.
sequencing confirmed that the amplicon corresponded to mayv (genbank accession no.
kx496990).
the mayv genome from haiti was aligned with all mayv strains available in genbank, and a neighbor-joining tree was inferred from pairwise genetic distances estimated with the best fitting nucleotide substitution model (general time reversible plus gamma), as previously described (7).
the phylogeny clearly shows 2 major and well-supported (bootstrap >90%) clades (figure).
the first clade includes strains sampled over the past 60 years from several south american countries (peru, bolivia, venezuela, trinidad and tobago, and french guiana); the second clade clusters the new haiti strain with isolates from brazil sampled during 1955–2014.
figure neighbor-joining tree of full-genome mayaro virus sequences.
the tree was inferred from pairwise distances estimated with the best fitting nucleotide substitution model (general time reversible plus gamma).
the tree includes the isolate from haiti identified in this study (in boldface) and all full-genome sequences with known country of origin and sampling date downloaded from genbank.
branches are drawn according to the scale bar at the bottom, which indicates nucleotide substitutions per site.
an asterisk along a branch indicates bootstrap support >90% for the subtending clade.
conclusions although mayv was originally isolated in trinidad in 1954, subsequent reports of illness associated with this virus have tended to be associated with small, occasional outbreaks (30–100 cases) in northern south america (10,11), within and close to the amazon forest.
signs and symptoms reported in association with mayv infection include arthralgias, eye pain, fever, headache, myalgias, rash, and occasionally nausea and vomiting, photophobia, abdominal pain, cough, diarrhea, sore throat, and bleeding gums (12).
a fatal infection associated with hemorrhagic fever has been reported (13).
mayv infections are probably underdiagnosed because of confusion with other mosquitoborne virus infections, especially dengue fever, which is endemic to the same areas.
the emergence of chikv has further added to this confusion, especially because prolonged arthralgia is reportedly associated with chikv and mayv infections (3).
our findings suggest that mayv is actively circulating in the caribbean region and that there may be a link between the strain circulating in haiti and the strains that have been circulating in brazil since isolation of the virus in the 1950s.
the patient from whom we isolated the organism had fever and abdominal pain but no rash or arthralgia.
however, given that the patient was co-infected with denv-1, it is difficult to separate out symptoms that are specific for mayv infection.
of note, the clinic physician empirically diagnosed typhoid and treated the patient accordingly.
the patient was from a rural/semi-rural area of haiti, reflecting an ecologic setting that differs greatly from sylvan amazon regions where many of the other reported mayv infections have occurred.
little is known about vectors for mayv in haiti; potential animal reservoirs, if any, remain to be identified.
the recent emergence of zika virus infection in the caribbean region, and its identification as a major cause of birth defects, has brought a great deal of attention to arboviruses.
our findings highlight the multiplicity of arbovirus species in haiti and the evolutionary relatedness among the viruses in haiti and those circulating in brazil, in keeping with prior work on zika virus (7).
findings also underscore the complexity of the interactions among different species and the apparent proclivity for zika virus/denv (7) and mayv/denv co-infections.
although a better understanding of zika virus infection is clearly needed, careful studies of other arboviruses (and their vectors and possible reservoirs) in these same geographic regions are correspondingly needed.
we do not know if mayv has epidemic potential; however, in light of recent observations with chikv, denv, and zika virus and the potential for transmission of mayv by aedes and haemagogus spp.
mosquitoes, inclusion of mayv in studies of arbovirus transmission seems to be indicated.
technical appendix additional methods used for virus isolation and sequencing.
@highlight
mayaro virus has been associated with small outbreaks in northern south america.
we isolated this virus from a child with acute febrile illness in rural haiti, confirming its role as a cause of mosquitoborne illness in the caribbean region.
the clinical presentation can mimic that of chikungunya, dengue, and zika virus infections.
