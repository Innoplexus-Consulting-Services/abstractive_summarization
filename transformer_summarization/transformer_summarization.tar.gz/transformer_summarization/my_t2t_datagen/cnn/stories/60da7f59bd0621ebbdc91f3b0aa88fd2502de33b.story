what is new?
key findings • most studies using routinely collected health data (rcd) are insufficiently reported.
for example, it is frequently impossible to know which exposure or intervention is associated with which outcome in which population or minimal prerequisites for replication/assessment of scientific validity are often lacking.
what this adds to what was known?
• even years after introducing reporting guidelines for observational studies, many studies from various clinical and epidemiologic areas are poorly reported.
what is the implication and what should change now?
• specific reporting guidelines for studies using rcd are necessary to address specific characteristics of such research.
• authors, peer reviewers, and editors need training to apply both novel and established reporting guidelines to ensure better and more complete research reporting.
1 introduction routinely collected health data (rcd) are defined as data collected for purposes other than research [1], [2].
examples include health administrative data, electronic health records, and disease or clinical registries.
increased ability to store, process, and quickly access large amounts of such data led to increasing collection and usage for health research.
using such novel data sources involves unique challenges for research reporting, for example, the description of database characteristics or record linkage methodology [3].
poor reporting wastes efforts and resources [4].
guidelines such as the strengthening the reporting of observational studies in epidemiology (strobe) statement have been developed and endorsed by many journals to improve reporting of biomedical research [5].
inadequate or incomplete reporting has been shown in observational studies on general medical interventions that were published before introduction of strobe [6] and in more recent evaluations that addressed specific research areas, including cancer [7], hand surgery [8], dermatology [9], plastic surgery [10], or magnetic resonance imaging [11].
we analyzed the reporting of any type of observational study using rcd in a randomly selected sample of studies published in 2012 which were identified in pubmed.
we focused on reporting domains that are central with regard to the study's design, its research question, and basic prerequisites for study results replication.
we selected items addressing these reporting domains in strobe, and we developed a set of new items deemed specifically important for reporting of research using rcd.
this new set included items that directly correspond to the selected strobe items and items that focus on selected specific characteristics of rcd research.
using a sample of recent publications, we systematically evaluated these reporting items.
in ancillary analyses, we explored if reporting affects both low- and high-impact journals and if better reporting is associated with more citations.
we aimed to assess the present state of reporting and provide a first empirical estimate of its quality to inform the development of a specific reporting guideline for rcd studies by the reporting of studies conducted using observational routinely collected health data (record) working committee [12].
record has recently been published as an extension of the strobe guidelines and aims to enhance transparency of research reporting and provide guidance to adequately report methods and findings of research using rcd [13].
2 methods 2.1 eligibility of studies we selected a sample of english language studies that used rcd and reported outcomes related to the health status of persons or a population, such as mortality or morbidity.
for example, we included publications detailing epidemiologic research on incidence and prevalence of diseases or risk factors or comparative effectiveness research studies measuring treatment effects.
we did not consider studies on outcomes such as costs or care processes.
we included nonexperimental studies in humans based on any type of health data that were routinely collected, that is, for purposes other than research.
we also included analyses based on registries, albeit registries characteristically comprise at least one actively collected data element [14].
there were no restrictions with respect to characteristics of study participants.
2.2 literature search we searched pubmed for studies published in 2012 (search date june 6, 2013) using terms related to rcd, including constructs for “database,” “registries,” “electronic health records,” and “administrative data/routine data” (webappendix 1 at www.jclinepi.com).
we integrated the search strategy for electronic health records provided by the national library of medicine into our strategy [15].
an information specialist formally peer reviewed the strategy [16].
2.3 study selection the 24,929 hits in pubmed were exported to microsoft excel (microsoft corporation, redmond, wa, usa) and ranked in random order.
two independent reviewers (l.g.h.
and one of e.i.b., s.m.l., e.v.e.)
screened titles and abstracts in this order and excluded studies obviously not meeting eligibility criteria.
any disagreements were resolved by discussion.
we obtained full texts of the first 150 potentially eligible references.
the sample size was determined arbitrarily based on our experience with similar projects [9].
we determined eligibility of full texts in teams of independent reviewers (two of l.g.h., e.i.b., s.m.l., m.b., b.k., j-.m.j., e.h., e.v.e.).
any disagreements were resolved by consensus among the larger group.
2.4 extraction of study characteristics for each eligible rcd study, we extracted the study characteristics including rcd type, area of research (epidemiology, e.g., risk factors of diseases; clinical/medical, e.g., comparative effectiveness of medical treatments), type of disease/condition of participants, and characteristics of reported analyses.
we classified types of rcd as shown in webappendix 2 at www.jclinepi.com.
data were extracted by teams of two reviewers (two of l.g.h., e.i.b., s.m.l., m.b., b.k., j-.m.j., e.h., e.v.e.).
any disagreements were resolved by consensus among the two reviewers or with a third reviewer (l.g.h.).
one reviewer recorded if journals endorsed the strobe statement according to information on the strobe website (l.g.h.)
[17].
to compare the citation impact metrics of adequately and inadequately reported studies (per reporting item), bibliographic information was extracted from isi web of knowledge, that is, the 2012 impact factor (if) of the publishing journal and the number of citations (all databases) up to february 2015 that a study has received.
this was extracted by one researcher and verified by another.
2.5 evaluation of reporting quality 2.5.1 selection and development of reporting items we evaluated five selected reporting items based on the strobe checklist [5] (s1–s5) and eight newly developed items (r1–r8) for rcd research (table 1; the prefix “s” denotes items based on strobe; the prefix “r” denotes newly developed items deemed important specifically for rcd studies.
further details and examples of reporting are shown in webappendix 3 at www.jclinepi.com) we aimed to reflect the reporting of the study design and research question, study replication, and rcd specifics.
selection of strobe items and development of new rcd items was based on expert opinion of the authors (l.g.h., e.i.b., s.m.l., e.v.e.)
without a formalized development process.
we operationalized all items into dedicated questions that can be clearly answered with “yes,” “partly,” or “no,” indicating adequate (“yes”) or inadequate (“no”) reporting.
we used the “partly” answer when not all aspects were adequately reported, for example, when several eligibility criteria existed, but some were described and others were not.
we accepted references to other publications as adequate descriptions.
we tested the item operationalization and developed rules and detailed extraction instructions in a small pilot study using a selected sample of three articles that were extracted and assessed by the larger group of the authors.
we then assessed 40% of the 150 full texts and formally calibrated extractions of eligible articles among reviewers.
we clarified the operationalization of the reporting items by specifying the wording of extraction instructions before we completed our extractions for the remaining 60% of the sample.
2.5.2 reporting items first, we evaluated if the study title and abstract allowed a basic classification of the design of the study and indicated the use of routine data (s1 and r1).
second, we assessed if sufficient details of the evaluated population, exposures or interventions (or risk factors, predictors, effect modifiers, and so forth), and outcomes were reported (s2–s4).
transparent reporting of these items is crucial for research translation to health care, and specifically in a medical context, this information would allow framing of a focused pico question on the medical problem (pico: population, intervention, control, outcome) [19].
third, we assessed codes and classification algorithms and other basic requirements for replication of analyses (r2–r5, s5a, s5b).
we assessed if sufficient details were reported on the population, intervention/exposure, and outcomes (r2–r4) as prerequisite to facilitate repetition of the analyses in the same or another data set (for simplicity, we do not differentiate between replication and reproduction).
rcd studies typically require an exact operationalization of the same items that are used for framing a focused research question in the previous domain.
for example, when administrative data such as diagnostic codes are used to define a population with type 2 diabetes, this would require an exhaustive list of all codes used to define this disease in the specific study context (e.g., international classification of diseases e11); when electronic medical records are used to identify these patients, a list of specific terms indicating the disease would be required (e.g., “diabetes mellitus type 2” or “t2dm”).
we evaluated these code-related items (i.e., r2–r4) only for studies using administrative data or electronic health or medical records because in this context, the retrospective identification of the population, exposures or intervention, or outcomes usually requires such codes and/or classification algorithms.
in studies using registry data, codes may be less relevant, for example, when patients are actively recruited or outcomes are specifically measured for the purpose of the registry.
we also evaluated whether the description of the analyzed databases was clear enough to assess the generalizability of the results and to replicate the findings in other contexts (r5).
then, we evaluated the description of variables and models in statistical analyses (s5a, s5b), but we only assessed multivariable analyses as they are the most frequently used statistical method in this research field.
fourth, we evaluated rcd specifics (r6–r8), that is, the reporting of methods for linkage of multiple databases (where applicable); any statements about data sharing issues or the availability of the used data set for other researchers; and any statements about the validation of coding or classification algorithms used for identification of patients, interventions or exposures, or outcomes were made.
we analyzed this item in all studies using electronic health or medical records or administrative data for the reasons outlined above (items r2–r4).
2.6 statistical analysis citation metrics of studies with adequate and inadequate reporting were compared per reporting item using the mann–whitney u test.
we used stata 13.1 (stata corp, college station, tx, usa) for statistical analysis.
p-values are two tailed.
3 results 3.1 selection and characteristics of studies of 150 articles evaluated as full texts, 26 articles were excluded (21 were no rcd studies and 5 reported no health-related outcomes).
we included 124 eligible articles for further analysis.
most studies used registry data (n = 70; 56.5%) or administrative health data (n = 40; 32.3%) (table 2).
a single data source was used in 74 studies (59.7%) and two data sources in 24 studies (19.4%).
epidemiologic questions were addressed in 91 studies (73.4%) and clinical questions in 25 studies (20.2%).
most studies reported multivariable models (n = 81; 65.3%) and five studies (4.0%) used propensity scores.
3.2 reporting quality the study design was not clearly described in the title or abstract of most studies (inadequate reporting for s1: 62.9%), but many studies were there clearly described as using rcd (adequate reporting for r1: 71.8%; table 3).
many studies clearly reported the evaluated population, exposures or interventions, or outcomes according to strobe (adequate reporting for s2: 74.2%; s3: 77.5%; s4: 75.7%; table 3), but only 51 studies (41.1%) reported all of the three items adequately.
most studies did not adequately report the coding or classification algorithm (inadequate reporting for r2: 53.2%; r3: 58.2%; r4: 42.6%; table 3).
in 44 studies, replication would require coding or classification information for all three items because they used administrative data or electronic medical/health records to describe the population, exposures or interventions, and outcomes.
only 9 of these 44 studies (20.5%) reported all three items adequately, whereas 17 (38.6%) reported all items inadequately, as would be required to frame a focused research question.
across 81 studies using multivariable analyses, 54 studies provided a complete list of used variables (s5a adequate: 66.7%), but only 34 studies sufficiently reported basic details required for replication (s5b adequate: 42%).
the analyzed databases were clearly described for most studies (r5 adequate: 60.5%), but the majority of studies did not clearly report the methods used for database linkage (r6 inadequate 68.3%), did not make statements on data sharing or availability of data sets (r7 inadequate: 96%), or about the validation of classification algorithms (r8 inadequate: 75.8%).
the agreement between both reviewers across all 14 items was 74.1% (median agreement per item).
3.3 association with journal if and citation count the journal if was higher for studies that clearly reported details on the statistical analyses (s5a: if 3.5 vs. 3.2; p = 0.027. s5b: if 3.7 vs. 3.2, p = 0.013), provided sufficient details on the study outcomes (s4: if 3.4 vs. 2.6; p = 0.047), and clearly described the coding and classification of participants (r2: if 3.6 vs. 2.5; p = 0.006) (table 4).
we found no significant association between journal if and other reporting domains or between reporting quality and number of citations.
4 discussion our systematic analysis of 124 studies reveals a number of deficiencies in the reporting of research using rcd.
most studies were insufficiently reported as they have substantial reporting deficits specifically concerning their particular methodology for using rcd (e.g., database linkage or used codes and their accuracy and validity).
this underlines the necessity to establish specific reporting guidelines for rcd studies, such as the reporting of studies conducted using observational routinely collected health data (record) statement [13] and the importance of adequate implementation by journals, peer reviewers, and funding agencies.
we also found substantial reporting deficits that concern observational studies in general.
they relate to areas of reporting that are already addressed by established reporting guidelines (strobe).
we found that less than half of the evaluated studies provided complete information to frame a focused research question, that is, it was frequently impossible to know which exposure or intervention was associated with which outcome and in which population.
the descriptions of statistical analyses in most studies lacked minimal prerequisites for replication and assessment of scientific validity: about one-third of studies that used multivariable models did not provide a complete list of the variables used for modeling; basic details on how the variables were used were provided in less than half of the studies.
journal if was associated with quality of reporting in few areas, underlining that insufficient reporting is a ubiquitous problem and affects both low- and high-impact journals.
we found no relationship between reporting and citation counts, in contrast to a recent study that evaluated reporting of systematic reviews and meta-analyses in one medical field (radiology) [20].
since only few articles were published in journals endorsing strobe, we did not evaluate the association of strobe endorsement and reporting quality.
a recent lancet series corroborated the fact that poor reporting of key information is endemic in various areas of health research and affects any study type, including randomized trials, observational studies, laboratory research, and animal studies [4].
our analysis is consistent with previous work on other forms of observational studies [6], [7], [8], [9], [10], [11].
even years after publication of the strobe guideline, reporting of observational research is still deficient.
our work has some limitations.
first, we explored only a small number of reporting items that reflect information which we deemed essential for rcd studies and there are further and more expanded items in the record guideline [13].
other relevant issues remain unaddressed in our analysis.
for example, when we evaluated the replicability of statistical analyses, we addressed only obvious aspects of reporting of multivariable analyses.
according to the international committee of medical journal editors, statistical methods should be described “with enough detail to enable a knowledgeable reader with access to the original data to judge its appropriateness for the study and to verify the reported results” [21].
we did not evaluate other details that a reader would likely require for replication, such as the availability of statistical code, but we found that almost all articles lacked a statement about access to the original data.
second, our sample drawn from publications of the year 2012 in english language from journals indexed in medline is only a fraction of the entire literature.
however, it is unlikely that reporting quality has substantially changed in the meantime and it remains speculative if our findings also apply to studies reported in other journals or languages.
third, we searched the literature using terms that might have enriched the sample with studies mentioning rcd terms in title or abstract.
thus, the finding that titles or abstracts of rcd studies often indicate the use of routine data might be overly optimistic.
however, we used a peer-reviewed search strategy that was deemed accurate and complete for the identification of observational rcd studies.
therefore, we believe the sample of included studies allows generalizing the findings to the larger rcd literature.
fourth, we assessed the reporting by two independent reviewers using their best subjective judgment.
however, all involved researchers had training in research reporting, used standardized and piloted electronic extraction forms with detailed instructions, and we systematically calibrated our extractions during the process resulting in an overall interreviewer agreement of 74.1% across all items.
the experience from the consensus process ultimately informed the discussion and item operationalization during the record guideline development.
finally, modern database analyses may frequently use study designs that do not clearly fit into traditional study design classifications such as “cohort study” or “case–control study.” authors of such research may find the strobe recommendation to “indicate the study's design with a commonly used term” as inappropriate.
this issue should be considered in future versions of the reporting guidelines.
our finding with respect to reporting of the study design should not be overrated and cautiously interpreted.
our results suggest that poor reporting of key study information is prominent in rcd research and may limit its further use, for example, by limiting the assessment of its scientific validity or hindering its replication.
the incomplete or imprecise description of research questions in most studies may waste research resources, for example, by unnecessary replication efforts or misguided funding decisions in their research fields [4].
generally, reporting deficits may lead to inefficient, misguided, or haphazard translation of research findings to public health actions or medical care.
this study provides a benchmark for the reporting quality of rcd studies.
preliminary findings of this project were presented to the working committee of record and informed the guideline development.
areas discovered by this study to be poorly reported have been emphasized in the record guideline [13].
authors, peer reviewers, and editors need training to apply both novel and established reporting guidelines to ensure better and more complete research reporting.
we believe that adoption of such guidelines and education on their use is particularly urgent to improve the utility of research using rcd.
@highlight
objectives to assess reporting quality of studies using routinely collected health data (rcd) to inform the reporting of studies conducted using observational routinely collected health data (record) guideline development.
study design and setting pubmed search for observational studies using rcd on any epidemiologic or clinical topic.
sample of studies published in 2012. evaluation of five items based on the strengthening the reporting of observational studies in epidemiology (strobe) guideline and eight newly developed items for rcd studies.
results of 124 included studies, 39 (31.5%) clearly described its design in title or abstract.
complete information to frame a focused research question, that is, on the population, intervention/exposure, and outcome, was provided for 51 studies (41.1%).
in 44 studies where definitions of codes or classification algorithms would be necessary to operationalize such a research question, only nine (20.5%) reported all items adequately.
in 81 studies describing multivariable analyses, 54 (66.7%) reported all variables used for modeling and 34 (42.0%) reported basic details required for replication.
database linkage was reported adequately in 12 of 41 studies (29.3%).
statements about data sharing/availability were rare (5/124; 4%).
conclusion most rcd studies are insufficiently reported.
specific reporting guidelines and more awareness and education on their use are urgently needed.
