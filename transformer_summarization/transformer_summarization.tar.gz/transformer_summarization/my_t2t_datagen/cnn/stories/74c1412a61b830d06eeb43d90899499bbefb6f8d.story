1. introduction in a highly globalized world, goods and services are frequently not consumed in the same place in which they are produced.
the geographical separation of production and consumption leads to a shift in energy consumption and associated environmental pressures among countries.
this shift has been convincingly demonstrated with regard to energy use, land use, greenhouse gases and other ecological issues [1–5].
similarly, local air pollution problems associated with demands for products and services from other countries should be given sufficient attention.
among the pollutants highlighted for adverse effect on human health, fine particulate matter (pm2.5) has been given particular attention [6–8].
ambient pm2.5 is contributed by primary emissions from coal combustion, diesel vehicles and industrial processes, as well as the secondary sources from oxidation of precursors such as sulfur dioxide (so2), nitrogen oxides (nox) and volatile organic compounds (vocs) [9].
although secondary aerosols account for a large fraction of ambient pm2.5, their production is strongly dependent on the nonlinear chemistry of atmospheric oxidants, making it difficult to precisely trace the origin of pm2.5 [10,11].
in addition, oxidation of gas-phase pollutants is on a timescale from hours to days, leading to a larger spatial mismatch between the precursors' emission site and the formation of secondary pm2.5 aerosols, when compared with primary pm2.5 [12–14].
hence, in this study, we focus only on the primary pm2.5 emissions.
an assessment of the impact of primary pm2.5 on human health and the environment must begin with emission quantification [15–19].
global anthropogenic primary pm2.5 emissions were estimated at 40 tg in 2007, of which 87.7% originated in developing countries such as china [15].
in the past 50 years, pm2.5 emissions from developed countries have decreased dramatically owing to the implementation of a variety of air quality improvement regulations [20,21], whereas in certain developing countries, such as china and india, primary pm2.5 emissions have increased substantially owing to the rapid expansion of coal-based industries.
economic growth and rapid industrialization are clearly the drivers of pm2.5 emissions in emerging markets [22].
however, it has been found that export of products or services is the only final demand category that drives primary pm2.5 emission growth between 1997 and 2010 in china [23,24].
linking the consumers to the producers may, therefore, provide us valuable insights into effectively mitigation.
a traditional bottom-up inventory accounts for pm2.5 emissions directly released within territorial boundaries and based on activity rates and technological data [15,17,18].
these inventories attribute the emissions to where they were generated, without considering the place in which the related commodities were ultimately consumed [25].
production-based accounting is an essential input for global atmospheric models that can assess related local and downwind air quality and climate impact [26,27]; this type of accounting allows for mitigation of end-of-pipe emissions in the production of commodities, but fails to trace the final consumers of the commodities, which ultimately initiate the production [28].
given this shortcoming, the ‘consumption-based accounting’ (also referred to as ‘footprint’ calculation) [29] is used in this study to trace pm2.5 emissions to the final consumer of the applicable commodities [2,30–32].
tele-connection is a concept from atmospheric sciences relating the climate phenomena to each other at large distances [33].
recently, this idea has been used to represent the link between production and consumption in diverse location [34–36].
consumption-based measurement permits tele-connecting both the direct and indirect emissions generated throughout the worldwide supply chain to the goods or services consumed [23,37,38].
it has been used to investigating the environmental issues such as energy consumption, [39] co2 emissions [2], material consumption [40], biodiversity [3], mercury emissions [41,42], nitrogen pollution [43], water [44,45] and land use [34,46].
consumption-based emissions of china [28,38] and emissions embodied in china's interprovincial and international trade have been calculated [23,24,47–49].
takahashi et al.
[50] also quantified the consumption-based pm2.5 carbonaceous aerosols in nine asian countries and regions.
however, analyses cover the global supply chain network and a spatially explicit consumption-based primary pm2.5 assessment for the entire world covering the global supply chain do not exist.
this study traces the flow of primary pm2.5 emissions along international trade from original sources of pollution to the regions of final consumption, using a global trade database for 134 countries and 57 economic sectors [51].
the objective of this study is to understand the final consumption of products related to the local primary pm2.5 emissions from the perspective of consumption specifically with regard to where and for what purpose the related products are consumed.
in addition, by quantifying the emissions transferred by international trade, this study suggests complementary policy insights for the future development of the lrtap convention and other frameworks whose objective is cross-boundary pollution control.
2. material and methods (a) multi-region input–output analysis multi-region input–output (mrio) analysis is emerging as a means of linking final demand with the associated environmental pressure across the world—as set against the backdrop of globalization and recent interest in a life cycle perspective [29,52,53].
in this framework, we first conducted a production-based pm2.5 emission inventory (fpr) using 134 countries/regions (electronic supplementary material, table s1) and 57 industry sectors (electronic supplementary material, table s2) on the basis of previous studies [15,54].
thereafter, by allocating the direct and indirect pm2.5 emissions to final consumer demand, we derived a global consumption-based pm2.5 emission inventory for 2007. the pm2.5 emission intensities for each of the 134 countries and 57 industry sectors were also calculated.
these results illustrate the differences in pm2.5 emissions (direct and indirect) embodied in one unit of product [55,56].
notably, we traced all the emissions associated with consumed goods back to the original source of the emissions even when the products were transferred through other countries/regions or were intermediate constituents in a multi-regional supply chain.
in this vein, we also quantified the virtual pm2.5 emission flow throughout international trade in primary and manufactured products and services.
the difference between production- and consumption-based emissions represent the net effect of emissions embodied in trade, which equals emissions embodied in exports minus emissions embodied in imports.
a positive value indicates the net export of pm2.5 emissions, whereas a negative value indicates the net import of emissions.
the mrio table is essential for investigations into final consumption attributions of emissions caused by national final demands for products and services [2,32,57–59] and can identify the virtual flow of emissions throughout international trade [4,60].
we constructed a fully coupled mrio table in 2007 based on the global trade analysis project (gtap) database [61].
the mrio table covers the entire economic structure—including multiple regions (most regions in the present analysis are individual countries, as described in electronic supplementary material, table s1), multiple sectors and monetary flows between industrial sectors and regions [61,62].
for the global economy with m regions and n industries in each region, zijrs (r, s = 1, 2, … m; i, j = 1, 2 … n) represents an intermediate product sold from industry i in country r to industry j in country s. yirs (r, s = 1, 2, … m; i = 1, 2 … n) represents the finished goods (opposite to raw materials and intermediate goods) sold from industry i in country r to final consumers in country s. xir is the total output of industry i in country r. as a result, for industry i in country r, we have 2.1xir=∑s=1m∑j=1nzijrs+∑s=1myirs.
a technical coefficient aijrs=zijrs/xjs is defined as the proportion of input (in monetary unit) from sector i in region r to produce one unit of output from sector j in region s. then, equation (2.1) can be formulated as 2.2x=ax+y, where x = (xir), a = (aijrs), and y = (yirs).
by incorporating a vector of emission intensity, a t × t emission multiplier matrix e can be calculated as (t = m × n) 2.3e=h^(1−a)−1=h^l, where h^ is a diagonal vector representing sector-specific pm2.5 emissions per unit of economic output, which is defined as the direct emission intensity; i is the identity matrix and a is the matrix shown in equation (2.2).
l is the leontief matrix which captures both direct and indirect economic inputs to produce one unit of final demand in monetary value; similarly, an element ec,dr,s (r, s = 1, 2, … m; c, d = 1, 2, … t) in matrix e is the emissions in sector c of region r instigated by the unit final demand in sector d of region s. any column vector of the matrix e, e:,d:,s (denoting all sectors in column (s − 1) * t + d) measures emissions from all sectors that have been embodied in the unit final consumption of goods in sector d of region s and is referred to as the embodied emission intensity (eei) of sector d in region s. the e:,d:,s along the global supply chain also follows 2.4e:,d:,s=[e11∂1,d1,s+e21∂2,d1,+⋯+ei1∂n,d1,s]+[e12∂1,d2,s+e22∂2,d2,s+⋯+ei2∂n,d2,s]+⋯+[e1m∂1,dm,s+e2m∂2,dm,s+⋯+eim∂n,dm,s] where eir is the element of h^ (sector i in region r), ∂c,dr,s is the element of l (row (r − 1) × n + c and column (s − 1) × n + d), representing inputs required for sector d in region s from sector c in region r. in equation (2.4), when r = s, [e1r∂1,dr,s+e2r∂2,dr,s+⋯+eir∂n,dr,s] is the emissions generated domestically owing to unit final demand in sector d in region s, the remaining part representing the emissions generated outside region s. therefore, each eei links to emissions both domestically and outside the region.
the fundamental principle used to assess the pm2.5 emissions embodied in final goods is to multiply the eei by the final demand in each sector.
the pm2.5 emissions associated with final consumption in region r (fcr) may be calculated as 2.5fr=h(i−a)−1y⋅r=ey⋅r, where h is a row vector represents direct emission intensity, y⋅r=(y1ry2ry3r⋯ymr)t, is the final demand vector of region r. yrr is the domestic final consumption of region r. the mrio model endogenously calculates not only the domestic output, but also the output in all other regions resulting from international trade in intermediate products.
in addition, consumption-based emissions (fr ∗) with inclusion of direct residential emissions (fh) in the region r can be calculated as 2.6fr ∗=ey⋅r+fh.
from this framework, pm2.5 emission transfers from region r to region s are calculated as 2.7fsr=h~s(i−a)−1y⋅r=ey⋅r, when r = s, frr is a vector with its elements representing emissions related to final consumption produced locally; when r ≠ s, frs denotes emissions released in region r related to cross-regional final products consumed in region s. h~s is a vector of the corresponding direct emission intensity for region s but zero for all other regions.
(b) production-based pm2.5 emission inventory the global production-based pm2.5 emission inventory was derived from peking university's pm2.5 inventory for 2007 (pku-pm-2007) [15] (http://inventory.pku.edu.cn/home.html).
pku-pm-2007 is a bottom-up emission inventory with high spatial resolution (0.1° × 0.1°) that was built on the basis of a global fuel combustion dataset (pku-fuel-2007, covering 64 fuel combustion processes and 14 industrial processes in 233 countries/territories) and updated pm2.5 emission factors [15,54].
in this study, the production-based industrial pm2.5 emissions (including both fossil fuel combustion and industrial processes) were based on the pku-pm-2007 inventory, but converted into 57 sectors and 134 regions according to the country and sector information in v. 8.1 of the gtap (see details in electronic supplementary material).
previous studies generally built global primary pm2.5 emission inventories with high spatial resolution, we first built the economic sector-based emission inventory from both the production and consumption perspectives.
energy consumption by sector, gdp and population data of each region were all derived from the gtap database.
further details to the development of pku-pm-2007 and comparison with other inventories can be found in our previous studies [15,54,63].
3. results (a) consumption-based pm2.5 emissions the sources of primary pm2.5 emissions in this study consist of industrial primary pm2.5 emission sources directly emitted from energy combustion and industrial processes, as well as direct residential emissions (e.g.
cooking and heating).
we use ‘industrial pm2.5 emissions’ to describe emissions from all economic sectors (i.e.
agriculture, industrial activity, power generation, transportation and non-transportation services).
this classification is different from what has been used in previous studies that divide pm2.5 emissions into four categories: industrial, power, transportation and residential [15,64,65].
this study focuses on primary industrial emissions and primary residential emissions that amount to 24 and 15.6 tg, respectively.
(b) regional pm2.5 emissions production-based pm2.5 emissions denote emissions resulting from fuel combustion, industrial processes and residential life, mainly generated in china (14.4 tg), india (5.3 tg), the usa (1.5 tg), indonesia (1.2 tg) and russia (0.98 tg) (figure 1).
however, from a consumption perspective, the top pm2.5 emitters were still among the world's largest economies, i.e.
china (11.9 tg), india (5.1 tg), the usa (2.6 tg), indonesia (1.2 tg) and russia (0.86 tg; detailed information is provided in electronic supplementary material, figure s1 and table s3).
these five countries also occupied the top five positions for consumption-based co2 emissions in 2004 [2].
notably, the pattern of consumption-based emission for pm2.5 is different from that of co2, which the consumption-based co2 emission has been widely studied by previous literature.
based on global production-based emission inventory [15] and mrio table derived from gtap database [66], china's consumption-based pm2.5 emissions is found to more than four times the usa's in 2007, whereas china's consumption-based co2 emissions amounted to only 61% of those of the usa in the same year [2].
this difference stemmed from the larger difference in emission factor, sectoral emission intensity and substantial residential emissions across regions.
on a per capita basis, high per capita consumption-based emissions in some developed countries were highlighted (e.g.
16.2 and 13.1 kg person−1 in luxembourg and finland, respectively; figure 2).
conversely, per capita consumption-based emissions are lowest in the regions characterized with less developed economy, mainly in africa and asia (e.g.
kyrgyzstan, guinea).
this distribution pattern is very similar to per capita consumption-based co2 emissions and can be attributed to the remarkable disparity in living standards between countries [2].
figure 1.production-based (industrial emissions and direct residential emissions) versus consumption-based (government consumption, household consumption, capital investment and direct residential emissions) pm2.5 emissions in 2007 in different countries.
the difference between production-based emissions and consumption-based emissions represents the net emission transfer via trade and a positive value indicate that emissions embodied in exports are less than that in imports and thus a net importer of emissions.
(online version in colour.)
figure 2.per capita consumption-based emissions (g pm2.5 per capita).
(online version in colour.)
from the sectors in terms of consumption-based industrial emissions, final demand by consumers consisted of three categories (i.e.
household consumption, government consumption and investment), which contributed 51, 7 and 42% of global pm2.5 emissions, respectively.
the composition of final demand was closely linked to income and associated expenditure patterns and lifestyles [67].
figure 1 shows the composition of consumption-based pm2.5 emissions in the top 20 countries, which were responsible for approximately 80% of the global total.
in developing countries, a significant portion of pm2.5 emissions (e.g.
60% in china and 40% in india) were related to capital investment (particularly in construction) [23,38], suggesting that investment contributed to an even greater proportion of pm2.5 emissions than the proportion in their gdps.
construction drives pm2.5 emissions by creating an increasing market demand for the large-scale production expansion of cement, steel and other emission-intensive material, which has much larger emission intensity than the same products in other developed regions (more details in the following sections).
until the vast difference between the emission intensities of chinese industries and that in developed regions is reduced, pm2.5 emissions in china is difficult to cut down.
however, household consumption (i.e.
demands by households for finished goods and services) was the dominant contributor for developed countries (e.g.
the usa (65%), brazil (62%), western europe (61% in total), russia (49%) and japan (50%)).
particularly, a substantial portion of usa and western europe's pm2.5 emissions associated with household consumption, i.e.
33 and 26%, respectively, were embodied in non-transportation services (i.e.
trade, insurance, dwelling, see details in electronic supplementary material, table s2).
in summary, for developing countries, rationally controlling the expansion of construction and shifting investment to tertiary industries (e.g.
technological innovation), as well as lowering emission intensity (such as improving the energy mix) and tightening environmental standards will yield benefits that lower pm2.5 emissions [68].
in contrast, for developed countries, promoting green consumption is a viable approach to reducing pm2.5 emissions.
(c) pm2.5 emissions for industrial sectors figure 3 presents a comparison of sectoral pm2.5 emissions from both the production and consumption perspectives for the selected regions.
the sectoral contribution differs significantly between the two perspectives and across the regions.
from a production perspective, global pm2.5 emissions derived mainly from mineral products (38.5%), power generation (20.6%) and agriculture (17%).
by allocating global primary pm2.5 emissions to countries and industrial sectors according to the final demand of consumers for finished goods, the consumption pattern indicated that 29.7, 11.9 and 9.6% of total industrial pm2.5 emissions are driven by the final demand for products in construction, service and machinery and equipment sectors, respectively.
notably, construction generally contributed a higher proportion of pm2.5 emissions in developing countries (24–37%), whereas services were responsible for higher emissions in developed countries.
in general, developing countries are undergoing rapid urbanization, which requires large amounts of cement, steel and electricity and, therefore, considerable energy consumption.
in addition to construction, services also contributed substantial pm2.5 emissions in both developing and developed countries (such as china and the usa, respectively).
although services release minimal emissions onsite, they require electricity, transport and other emission-intensive products and services as inputs along the entire supply chain, resulting in substantial indirect pm2.5 emissions [69].
figure 3.comparison of sectoral contribution to production-based and the consumption-based pm2.5 emissions for selected countries.
(online version in colour.)
(d) embodied pm2.5 intensity in industrial sectors emission intensity is frequently used as an indicator to represent the technology level.
the direct and indirect pm2.5 emissions related to final demand for goods or services in each particular industry are referred to as ‘eei’ [55,56].
according to equation (2.4), such eei reflects energy intensity (energy consumed per dollar of final demand), emission factor (pm2.5 emissions per unit of energy consumed) and trade structure of intermediate goods.
average eeis varied considerably across sectors (figure 4), from 0.09 g per $ in dwellings to 9.8 g per $ in mineral products.
moreover, a large disparity in eeis was observed for the same sector in different regions.
figure 4 depicts the mean eeis of 57 sectors in china, the usa and western europe.
the eeis in china were approximately two to 10 times higher than the corresponding eeis in the usa and western europe because of the high emission intensity of china's domestic supply chain.
western european countries usually have much lower domestic eeis than other countries, mainly because of the high proportion of nuclear and hydropower (e.g.
france and sweden) and advanced clean production technologies.
in contrast, 75% of china's primary energy source was supplied by coal in 2007, the highest level among major energy-consuming countries [68].
emissions in power sector are found to enhance almost all sectors' eei in china, because more than 80% of the economic sectors in china follow a similar manner in requiring the material or electricity input in their supply chain [37].
the high eei in china was also underpinned by the low production efficiency and low environmental standards compared with developed regions.
previous study has shown that the life cycle co2 emissions per unit mass of each product (similar to the eei) for chinese products was on average 4.4 times higher than the same products made in europe [68].
the emission factor of pm2.5 is more dependent on technology and end-of-pipe control measures, thus the difference of embodied emission intensities across regions is much larger than co2.
figure 4.mean embodied pm2.5 emission intensity (g per $) for 57 sectors (electronic supplementary material, table s2) of the world, china the usa and western europe.
embodied intensity includes contributions from domestic and rest of the world (row) supply chains.
(online version in colour.)
moreover, owing to the great differences in emission intensity across different countries, importing/exporting commodities exerts influences beyond the domestic scale.
for instance, the eei of machinery and equipment was 2.11 g per $ in china (1.98 domestically and 0.13 abroad) and 0.24 g per $ in the usa (0.11 domestically and 0.13 abroad).
if producing one piece of equipment requires a 10 000 dollar input, then 2.4 kg pm2.5 (1.1 kg domestically and 1.3 kg abroad) was released if it was produced within the usa as opposed to 21.1 kg (19.8 kg domestically and 1.3 kg abroad) in china.
thus, international trade may significantly change the magnitude and distribution of global pm2.5 emissions.
(e) pm2.5 emissions embodied in trade globally, nearly 30% of pm2.5 emissions (7.2 tg) were linked to the production of goods or services consumed outside the boundaries of the producing country in 2007 on the basis of equation (2.6).
figure 5 further illustrates the interregional flows of pm2.5 embodied in trading goods and services.
note that the direction of the virtual pm2.5 flow is the same with the flow of the commodities, as previous studies did [2,70].
certain developed countries, including the usa (1058 gg), japan (248 gg), germany (278 gg), the united kingdom (272 gg), italy (203 gg) and france (22 gg), had the measurable pm2.5 emissions embodied in imports, which contributed 40–70% to their consumption-based pm2.5 emissions (figure 1).
by contrast, countries such as china (6948 gg), india (2782 gg), south africa (240 gg), ukraine (191 gg), and russia (116 gg) exported 10–115% (india–ukraine) of their total consumption-based pm2.5 emissions via exporting commodities in 2007. figure 5.production-based pm2.5 emissions linked to foreign consumption.
(a) the largest interregional flow of emissions embodied in trade (gg per year) from dominant net exporting countries (blue) to the dominant importing countries (red).
flows to and from western europe are aggregated and include the united kingdom, germany, france, switzerland, italy, spain, sweden, luxembourg and the netherlands; (b) the interregional flow pattern of pm2.5 emissions embodied in the global trade system (gg per year) among 20 aggregated regions.
the flow from each region represents pm2.5 emissions embodied in exported commodities to the other end of the link, and the link colour corresponds to the regions with greater exports.
(online version in colour.)
figure 5a also shows the key interregional links from the largest net importing countries (red) to the largest net exporting countries (blue).
the dominant pattern is that 27, 29 and 26% of consumption-based pm2.5 emissions in the usa, japan and western europe, respectively, were linked to emissions in the production of exports in china in 2007. notably, the usa imported more embodied pm2.5 emissions than any other country by importing products from china (622 gg), india (85 gg) and brazil (35 gg).
by contrast, approximately 30% or 2.7 tg of pm2.5 emissions in china were linked to consumption in foreign countries/regions, which accounts for 38% of the global total of traded emissions (7.2 tg).
the emissions imported by developed countries from emerging countries reinforced the already large global disparity in the spatial heterogeneity of pm2.5 emissions.
the consumers in one country typically tele-connect pm2.5 emissions in foreign countries by importing a wide variety of goods and services for final consumption purposes.
further exploration of the commodity content of trade activities (electronic supplementary material, figure s2) shows that pm2.5 emissions embodied in the usa imports exceed those of any other country or region and were primarily embodied in machinery and equipment (131 gg), unclassified manufactured goods (43 gg), clothing (36 gg), mineral products (23 gg), leather products (23 gg) and intermediate goods (875 gg).
these imports were offset by additional emissions in usa exports of machinery and equipment (18 gg), agricultural products (11 gg) and intermediate goods (148 gg).
the patterns were similar in japan and western europe (uk, germany, france, switzerland, italy, spain, sweden, luxembourg and the netherlands) with substantial emissions embodied in imports to meet demand for machinery and equipment, clothing, food products and chemical, rubber and plastic products.
net exporters of emissions—such as china—with vast exports tended to generate much domestic pm2.5 emissions for trade purposes.
the emissions from production of exports from china were mainly caused by exporting commodities such as machinery and equipment, unclassified manufactured goods, clothing, mineral products and intermediate goods (electronic supplementary material, figure s2), which drove pm2.5 emissions generated from the production of mineral products (1126 gg), power generation (624 gg), agriculture (277 gg) and petroleum and coal products (258 gg).
figure 6 shows china's sectoral pm2.5 emissions, which were divided into four categories based on final demand.
the top three sectors—mineral products (2.5 tg), electricity (1.9 tg) and ferrous metals (1.5 tg)—together contributed two-thirds of china's total pm2.5 emissions; 21, 32 and 36%, respectively, were instigated by demand from foreign countries (figure 6).
more importantly, the embodied emission intensities of products in these three sectors in china were more than 10-fold of the same products made in europe and usa.
there is a considerable opportunity to reduce primary pm2.5 emissions in china by focusing on these sectors where more energy efficiency or end-of-pipe technologies can be installed and shifting the energy mix towards cleaner energy sources.
such improvements can be supported by both domestic and international efforts to facilitate technology transfer into these critical sectors.
stricter regulation, particularly in these sectors, is also crucial in reducing primary pm2.5 emissions.
furthermore, in nine of the 57 sectors, emissions resulting from domestic demand were even smaller than those from foreign demand.
in particular, nearly three-quarters of the emissions from the production of electronic equipment, textiles and plant-based fibres were emitted during the production of export-related products.
similarly, china's stark imbalance of co2 emissions embodied in trade was also embodied in exports of machinery and equipment, clothing and textiles and substantial exports of intermediate goods [71].
as the production process requires vast amounts of energy and inputs from other sectors, the results drive both co2 and pm2.5 emissions in sectors such as electricity and ferrous metals.
figure 6.sectoral pm2.5 emission in china related to domestic demand (grey) and the demand from western europe (yellow), the usa (orange) and the rest of the world (blue).
(online version in colour.)
4. discussion international policies to address transboundary air pollution are still in development, such as the convention on long-range transboundary air pollution (lrtap) and the task force on hemispheric transport of air pollution (tf htap), despite the significant role of international trade.
the tf htap is organized under the auspices of the unece lrtap convention and aims to understand how emissions in an outside region affect the air quality, health and climate in a given region [72].
however, these policies are limited by identification of only physical transport [73].
these indirect, trade-induced primary emissions efficiently elevate pm2.5 concentrations in the receptor regions, which are 20–200 times larger than the concentration enhancement resulting from intercontinental transport, particularly between north american (na) and european (eu) sources and east asian (ea) and south asian (sa) receptors (table 1; electronic supplementary material, table s4 and toc art) [26,27].
even for a much smaller region (i.e.
china), trade-induced intraregional transfer of emissions is also found to be more important than atmospheric transport of pollution from one province to another [47].
it is therefore clear that a furthering of the understanding of both the international atmospheric transport and virtual transport could improve science cooperation at the international scale and work towards mitigation of relevant emission sources [24,47,50,74].
table 1.virtual pm2.5 emissions flow from a net importer of products (source region of pm2.5) to a net exporter of products (receptor).
the contributions of a region to itself (referred to ‘domestic’) are shown in italics (unit: gg).receptor regionsource regionnaeusaeana1343.255.0100.8800.7eu74.11008.5126.0716.7sa6.67.22577.582.2ea57.629.959.27666.5 the analysis of consumption-based emission enables the evaluation of emission transfers between countries [2,4] and demand-side policy options [75], and facilitates the exchanges of information between the producers and final consumers.
developed regions with more emissions embodied in imports and mature technical capabilities could provide other developing regions with assistance on emissions estimation, monitoring methodology, modelling techniques, management and control programme implementation, and enforcement.
developing regions, in return, could provide better information about the sources, character and reduce emissions attributed to developed regions' consumption.
given the rapid growth of international trade [76,77], such policies must also have a global coverage and reach.
to achieve it, comprehensive information on the global primary pm2.5 transfers from original emission sources to regions of consumption must be available, and this is the main contribution of our study.
the consumption-based primary pm2.5 accounting shares concepts and methods with consumption-based co2 [2], material [40], biodiversity [3], mercury [41,78], nitrogen pollution [43] and water [44,45].
therefore, debates about countries' responsibility for the environmental impact of their imports apply equally to the primary pm2.5: consumption-based pm2.5 policies can enforce controls on pm2.5 leakage and trade regulation, just as demand-side abatement of carbon emissions, but it would also face different obstacles in world trade agreements due to primary pm2.5's short atmospheric lifetime.
yet, the appeal of the consumption-based accounting is that it enables consumers to create competition among producers in a race to the top, particularly in the current globalized world with far-reaching supply chains.
more environmentally aware consumers might also push firms to differentiate their domestic and international suppliers on the basis of eeis.
in addition to regulating local emissions and adopting pm2.5 removal technologies, additional efforts might also be made by consuming countries to weigh eeis more heavily in selecting their key trading partners, with the goal of obtaining lower overall consumption-based emissions and reducing the international pollution disparity from globalized consumption.
the uncertainties in the consumption-based emission inventory arise mainly from the biases when compiling the production-based pm2.5 emission inventory [15], and the uncertainties associated in the mrio table.
a detailed description of the major uncertainties in production-based pm2.5 emission inventory has been given by huang et al.
[15].
basically, biases in emission factors and technology split could significantly enlarge the uncertainty range of emission inventory.
for the mrio table, sector aggregation may cause substantial uncertainties in consumption-based accounting [61].
however, the gtap database includes 57 sectors, and can provide sufficient details to link pm2.5 emissions to each individual economic sector [79].
consequently, the gtap database has been widely used in the environmental mrio analyses [4,29,71,80].
therefore, even with those uncertainties, the results in this study may provide valuable insights into pm2.5 emissions management.
in addition, the redistribution of pm2.5 emissions may cause increased/decreased morbidity or mortality associated with pm2.5 exposure, which highly relates to the spatio-temporal distribution of pm2.5 concentrations and population density [50,81].
in our follow-up studies, we extend the framework developed here and use the three-dimensional chemical transport model in conjunction with the tracers tagging technique to explicitly compare the health impacts of pm2.5 exposure caused by atmospheric movement and virtual transport via trade [47].
in addition, the precursors (such as vocs, sox, nh3 and nox) can be incorporated into a chemical transport model to evaluate the contribution of secondary aerosols.
supplementary material supporting tables and figures
@highlight
globalization pushes production and consumption to geographically diverse locations and generates a variety of sizeable opportunities and challenges.
the distribution and associated effects of short-lived primary fine particulate matter (pm2.5), a representative of local pollution, are significantly affected by the consumption through global supply chain.
tele-connection is used here to represent the link between production and consumption activity at large distances.
in this study, we develop a global consumption-based primary pm2.5 emission inventory to track primary pm2.5 emissions embodied in the supply chain and evaluate the extent to which local pm2.5 emissions are triggered by international trade.
we further adopt consumption-based accounting and identify the global original source that produced the emissions.
we find that anthropogenic pm2.5 emissions from industrial sectors accounted for 24 tg globally in 2007; approximately 30% (7.2 tg) of these emissions were embodied in export of products principally from brazil, south africa, india and china (3.8 tg) to developed countries.
large differences (up to 10 times) in the embodied emissions intensity between net importers and exporters greatly increased total global pm2.5 emissions.
tele-connecting production and consumption activity provides valuable insights with respect to mitigating long-range transboundary air pollution and prompts concerted efforts aiming at more environmentally conscious globalization.
