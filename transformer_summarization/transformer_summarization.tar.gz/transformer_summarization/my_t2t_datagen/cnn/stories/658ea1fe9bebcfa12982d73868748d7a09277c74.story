introduction lung cancer is the leading cause of cancer mortality worldwide, and approximately 85% of cases are non-small cell lung cancer (nsclc)1. despite major advances in therapeutic strategies, the prognosis for nsclc patients remains poor; the 5-year survival rate is less than 15%2.
a growing number of molecular alterations and specific gene expression signatures have been implicated in nsclc carcinogenesis, including kras, egfr mutations, eml4-alk rearrangements, and vegf and thymidylate synthase expression levels, among others3–5.
however, the detailed molecular pathogenesis of nsclc is far from fully understood.
the farnesoid x receptor (fxr) is a member of the nuclear receptor superfamily that is predominantly expressed in the liver, intestines, kidneys, and adrenal glands6, 7. as a bile acid (ba)-activated transcription factor, fxr maintains ba homeostasis by controlling the transcription of numerous genes involved in ba synthesis, conjugation, and transportation8.
small heterodimer partner (shp), a well-characterized fxr target gene, mediates many of fxr’s pleiotropic functions, such as repressing the transcription of the ba synthetase cyp7a1 9. emerging evidence supports an important role for fxr in tumorigenesis, as either an oncogene or a tumor suppressor gene.
fxr deficiency in mice has been reported to cause activation of the wnt/β-catenin pathway in the liver and ultimately to generate spontaneous liver tumors10, 11. other studies have revealed increased colon cell proliferation and small intestine adenocarcinoma formation in fxr−/− mice; fxr expression is inversely correlated with human colorectal cancer progression12, 13. several other studies have demonstrated a causative role for fxr in the carcinogenesis of organs other than the liver-intestine system.
fxr has been found to be associated with a higher tumor grade, greater tumor size and lymph node metastasis in esophageal adenocarcinomas, and fxr knockdown has been shown to suppress tumor cell growth both in vitro and in vivo 14. in estrogen receptor (er)-positive breast cancer, increased fxr levels were correlated with a proliferation marker, ki-67, and lymph metastasis in postmenopausal women15.
therefore, the precise contribution of fxr to carcinogenesis in different cancer types is controversial.
we previously reported that fxr was increased in idiopathic pulmonary fibrosis (ipf) lungs16.
beyond that, knockdown of fxr restrained ba-induced epithelial-mesenchymal transition and lung fibroblast activation, indicating a detrimental role of fxr in ipf pathogenesis.
however, the expression and potential biological function of fxr in nsclc have never been investigated yet.
here, we firstly showed that fxr was upregulated in nsclc tissues, and its expression levels were positively correlated with poor clinical outcomes.
we identified an oncogenic role of fxr in nsclc development by uncovering a mechanistic link to cyclin d1.
furthermore, fxr-cyclin d1 signaling was found to predict a poor prognosis for nsclc patients.
this finding may permit the stratification of nsclc in a novel way and may subsequently provide an intervention option.
results fxr is upregulated in nsclc and predicts poor patient outcomes we first assessed the fxr expression level by immunohistochemical (ihc) staining in 160 pairs of nsclc and matched normal lung tissues.
intense nuclear fxr staining was observed in tumor cells but was rare in normal cells (fig.
1a).
we found that fxr protein was significantly upregulated in carcinous, compared to pericarcinous, lung tissues (fig.
1b).figure 1fxr is upregulated in nsclc and predicts poor outcomes for patients.
ihc was performed in 160 pairs of nsclc and matched normal lung tissues.
(a) representative images of fxr high or low expression in nsclc tissues (upper panel), and images of fxr expression in corresponding pericarcinous lung tissues (lower panel) are shown.
isotype control: the primary antibody was replaced by nonspecific rabbit igg.
(b) ihc score of fxr in these paired samples (p < 0.001).
(c) kaplan-meier analysis of 160 nsclc patients showing that “fxr high” patients (n = 98) have a shorter os than “fxr low” patients (n = 62) (p = 0.0032).
hepg2 and five nsclc cell lines were lysed and collected.
(d) western blot was performed to evaluate the fxr protein expression.
the band for fxr was indicated by an arrow.
(e) quantitative rt-pcr analysis of fxr mrna expression in these cell lines.
in hepg2, the expression level of fxr mrna was set at 1. all experiments were repeated at least three times.
β-actin was used as an internal control.
for further analysis, the nsclc specimens were separated into two groups, defined as “fxr high” (scores of 6–12) and “fxr low” (0–4).
consistent with the previous observations, the proportion of “fxr high” specimens in nsclc was significantly higher than that in matched normal lung tissues (61.2% vs. 0.6%, p < 0.001) (table 1).
statistical data showed that high fxr expression was positively associated with a more advanced pathological stage (p = 0.012) and t status (p = 0.025), as well as a larger tumor size (p = 0.03) (table 2), indicating the possible involvement of fxr in tumor growth and nsclc progression.table 1protein expression levels of fxr and cyclin d1 in nsclc and pericarcinous lung tissues.tissue sampleno.
of patientsfxr p-valuecyclin d1 p-valuelow (%)high (%)low (%)high (%)nsclc16062 (38.8)98 (61.2)<0.001a 69 (43.1)91 (56.9)<0.001a peri-cancer160159 (99.4)1 (0.6)152 (95.0)8 (5.0) adata were analyzed using chi-square test.
table 2clinicopathologic characteristics according to fxr and cyclin d1 protein expression in nsclc.variablesno.
of patientsfxr p-valuecyclin d1 p-valuelow (%)high (%)low (%)high (%)gender male11544 (38.3)71 (61.7)0.839a 52 (45.2)63 (54.8)0.393a  female4518 (40.0)27 (60.0)17 (37.8)28 (62.2)age (year) ≤606125 (41.0)36 (59.0)0.649a 25 (41.0)36 (59.0)0.668a  >609937 (37.4)62 (62.6)44 (44.4)55 (55.6)stage i-iia7336 (49.3)37 (50.7)0.012a 42 (57.5)31 (42.5)0.001a  iib-iv8726 (29.9)61 (70.1)27 (31.0)60 (69.0)tumor size (cm) ≤3.05126 (51.0)25 (49.0)0.03a 29 (56.9)22 (43.1)0.016a  >3.010936 (33.0)73 (67.0)40 (36.7)69 (63.3)t status t13017 (56.7)13 (43.3)0.025a 18 (60.0)12 (40.0)0.038a  t2/t3/t413045 (34.6)85 (65.4)51 (39.2)79 (60.8)n status n07936 (45.6)43 (54.4)0.156a 36 (45.6)43 (54.4)0.537a  n1/n2/n38128 (34.6)53 (65.4)33 (40.7)48 (59.3)m status m015861 (38.6)97 (61.4)1b 68 (43.0)90 (57.0)1b  m121 (50.0)1 (50.0)1 (50.0)1 (50.0)no.
of positive lymph nodes mean1.612.220.221c 1.882.050.721c  sd2.913.643.183.51 adata were analyzed using chi-square test.
bdata were analyzed using fisher’s exact test.
cdata were analyzed using mann-whitney u test.
the prognostic implication of fxr in nsclc was subsequently analyzed.
kaplan-meier survival curves showed that the overall survival (os) was significantly worse in “fxr high” nsclc patients than in those with low expression (p = 0.0032) (fig.
1c).
multivariate cox regression analysis revealed that an “fxr high” pattern [hazard ratio (hr) 1.71, 95% confidence interval (ci) 1.108–2.637; p = 0.015], as well as advanced stage (hr 1.773, 95% ci 1.171–2.685; p = 0.007), were independent predictors for poor os in nsclc (table 3).table 3univariate and multivariate cox regression analysis for os in nsclc.variableunivariate analysismultivariate analysishr95% ci p-valuehr95% ci p-valuegender male1 female1.2830.845–1.9470.242age (year) ≤601 >601.110.737–1.6690.618stage i-iia11 iib-iv1.9271.279–2.9050.0021.7731.171–2.6850.007tumor size (cm) ≤3.01 >3.01.5891.02–2.4760.041fxr expression low11 high1.8751.222–2.8790.0041.711.108–2.6370.015cyclin d1 expression low1 high1.6781.116–2.5210.013 fxr promotes the proliferation of nsclc cells, and knockdown inhibits tumor growth in vivo the fxr expression level in five nsclc cells was evaluated by western blot and quantitative real-time pcr (rt-pcr).
h1975 and h1299 had higher fxr protein and mrna expression compared with h1650, h460 or hcc4006 cells (fig.
1d and e).
hcc4006 had the lowest fxr expression.
as the fxr expression level was correlated with poor clinical outcomes, we hypothesized that fxr might act as an oncogene in nsclc.
we used the downstream target, shp, as an indicator of alterations in fxr activity with treatment9.
the fxr antagonist z-guggulsterone inhibited the proliferation of higher-fxr-expressing cell lines, h1975 and h1299, in a dose-dependent manner (fig.
2a and b).
fxr knockdown resulted in decreased proliferation of h1975 and h1299 cells (fig.
2c and d).
by contrast, enforced fxr in endogenous lowest-fxr-expressing cells hcc4006 significantly accelerated cell proliferation compared to a mock group, which was reversed by z-guggulsterone (fig.
2e).
ki-67 is a universal biomarker for proliferating cells17.
our immunofluorescence data showed that fxr silencing in h1975 compromised the intensity and proportion of ki-67-positive cells, while ectopic fxr expression in hcc4006 had the opposite effects (fig.
2f and g).figure 2fxr promotes the proliferation of nsclc cells in vitro.
h1975 and h1299 cells were treated with z-guggulsterone (z-gu, 20, 30, and 40 μm) (a and b), or were transfected with nc- or fxr-sirna sequences (c and d).
hcc4006 stable cell lines were treated with z-guggulsterone (40 μm) (e).
the fxr and shp protein expression levels in each cell line were determined by western blot two days later (upper graph).
cell proliferation was determined after the indicated treatment by using srb assay at different time points (lower curve).
representative images of immunofluorescent staining of ki-67 in h1975 cells transfected with nc- or fxr-sirna sequences (f), and hcc4006 stable cell lines treated with z-guggulsterone (40 μm) (g) at × 60 magnification.
the nuclei were stained with dapi.
all experiments were repeated at least three times.
*p < 0.05, compared with the control, nc, or mock group, respectively; † p < 0.05, compared with the fxr-overexpressed hcc4006 cell group.
next, we evaluated the effect of fxr knockdown on nsclc xenograft growth in vivo.
h1975 cells that were transfected with fxr- or nc-shrna were subcutaneously injected into nude mice.
figure 3a reveals significantly slower tumor growth according to the volumes in fxr knockdown groups compared to the control group.
however, no marked difference in body weight was observed (fig.
3b).
after 32 days, tumors were isolated.
we found that tumors derived from fxrshrna-transfected h1975 cells had a significantly smaller tumor size and tumor weight compared to those from control cells (fig.
3c and d).
these data indicated that fxr had proliferation-promoting properties in nsclc.figure 3fxr knockdown inhibits nsclc tumor growth in vivo.
stable h1975 cell lines with nc- or fxr-shrna sequences were subcutaneously injected into the right flanks of nude mice.
the tumor volume (a) and body weight (b) in each group (n = 6) were monitored twice a week after implantation.
after 32 days, tumors were isolated to be photographed (c) and weighed (d).
the data are shown as the mean ± sd.
*p < 0.05, compared with the nc group.
suppression of fxr causes g0/g1 cell cycle arrest and cyclin d1 reduction, independent of shp in nsclc cell cycle arrest and apoptosis are considered two primary approaches in proliferation inhibition.
we examined the effects of fxr on cell cycle and apoptosis in nsclc cells.
both z-guggulsterone and fxrsirnas increased the proportion of h1975 cells in the g0/g1 phase, and decreased the proportion in the s and g2/m phases (fig.
4a and b).
similar trends were found in h1299 cells that underwent the same treatment (supplementary fig.
s1a and b), indicating a critical role for fxr in the g1/s transition.
however, no apparent change in apoptosis was observed in h1975 and h1299 cells upon either z-guggulsterone or fxrsirnas treatment (supplementary fig.
s1g and h).figure 4effects of fxr on cell cycle distribution and cell cycle regulators, independent of shp in nsclc.
the cell cycle profile of h1975 cells was analyzed by flow cytometry two days after treatment with z-guggulsterone (z-gu, 40 μm) (a), or transfection with nc- or fxr-sirna sequences (b).
western blot analysis was performed to evaluate the expression of fxr, shp, cyclin d1, cyclin e1, cdk2, cdk4, cdk6, p21cip1, p27kip1, and p-rb in h1975 cells that were treated with z-guggulsterone (40 μm) (c) or transfected with nc- or fxr-sirna sequences (d) as well as in hcc4006 stable cell lines that were treated with z-guggulsterone (40 μm) (e).
quantitative rt-pcr was performed to evaluate the fxr, shp, and cyclin d1 mrna abundance in h1975 cells that were treated with z-guggulsterone (40 μm) (f) or transfected with nc- or fxr-sirna sequences (g) as well as in hcc4006 stable cell lines that were treated with z-guggulsterone (40 μm) (h).
the cell proliferation rate of h1975 (i) and h1299 (j) cells was determined by the srb assay three days after transfection with nc- or shp-sirna sequences.
western blot analysis was performed to evaluate the expression of shp, fxr, cyclin d1, and p-rb in h1975 (k) and h1299 (l) cells that were transfected with nc- or shp-sirna sequences.
the data are presented as the mean ± sd of at least three independent experiments.
*p < 0.05, compared with the control, nc, or mock group, respectively; † p < 0.05, compared with the fxr-overexpressed hcc4006 cell group.
certain regulators acting in the cell cycle g1/s transition were subsequently evaluated by western blot analysis18.
as shown, the cyclin d1, cdk2, cdk4, cdk6, and phosphorylated rb (p-rb) protein levels were remarkably reduced in h1975 cell that were treated with z-guggulsterone, while only cyclin d1 and p-rb proteins were down-regulated by fxrsirnas (fig.
4c and d).
similar changes were also found in h1299 cells (supplementary fig.
s1c and d).
in contrast, ectopic fxr expression in hcc4006 increased the cyclin d1 and p-rb protein levels (fig.
4e).
as a result, the influences of z-guggulsterone on cdk2, cdk4, and cdk6 expression could be considered nonspecific19.
quantitative rt-pcr analysis demonstrated consistent results that both z-guggulsterone and fxrsirnas reduced the cyclin d1 mrna level in h1975 (fig.
4f and g) and h1299 cells (supplementary fig.
s1e and f), whereas overexpression of fxr increased the cyclin d1 abundance in hcc4006 (fig.
4h).
since cyclin d1 is required for rb phosphorylation by cdk4/6 in cell cycle initiation20, we speculated that fxr might function as a positive regulator of cyclin d1 transcription and g1/s transition.
furthermore, we addressed whether the effects of fxr in nsclc depend on its downstream effector, shp9.
there was no detectable change in either in vitro proliferation or cyclin d1 and p-rb expression in h1975 and h1299 cells that were transfected with shpsirnas (fig.
4i–l).
these findings imply that fxr induces cell proliferation and cyclin d1 expression through a mechanism that is independent of shp in nsclc.
fxr is recruited to the cyclin d1 promoter and promotes its transcription fxr is a transcription factor that controls target gene transcription through binding to an fxr-responsive element (fxre)21. gene sequence analysis revealed that the −2000/+209 region of the human ccnd1 promoter contains a putative inverted repeat-0 fxre sequence (gggtaattacccc) at nucleotide −1539 from the transcription initiation site.
to confirm the hypothesis that fxr might transactivate ccnd1, a chromatin immunoprecipitation (chip) assay was performed.
its results showed that clear bands could be amplified from dna samples immunoprecipitated by anti-fxr antibody in h1975 and h1299 cells, while no band was amplified in the negative controls (nc, isotype igg) (fig.
5a–c), indicating that fxr can directly bind to the putative motif in the ccnd1 promoter.figure 5fxr is recruited to the cyclin d1 promoter and promotes its transcription.
a chip assay was performed in h1975 and h1299 cells with anti-human fxr mouse monoclonal antibody and primer sets described in the “materials and methods” section.
the isotype igg was used as a negative control (nc), and the input chromatin sample was used as a positive control.
(a) representative pcr amplification products are shown.
enrichment of fxr protein in the putative motif of ccnd1 promoter in h1975 (b) and h1299 (c) cells was determined relative to input samples, respectively.
(d) schematic representation of a wild-type ccnd1 reporter plasmid (pgl3-ccnd1 fxre-wt) and an fxre-deleted ccnd1 reporter plasmid (pgl3-ccnd1 fxre-deleted).
(e) h1975 cells were transfected with ncsirna or fxrsirna-2; (f) hcc4006 stable cell lines were treated with or without z-guggulsterone (z-gu, 40 μm).
one day later, all cells were transfected with the indicated reporter plasmids and then collected for measurements of the luciferase activities at 24 h post-transfection.
the data were presented as the mean ± sd of at least three independent experiments.
*p < 0.05. we performed a luciferase reporter assay using luciferase reporter plasmids harboring the ccnd1 promoter region with or without a wild-type fxre sequence (fig.
5d).
to achieve more effective knockdown of fxr expression, only fxrsirna-2 was used.
we observed that wild-type ccnd1 promoter activity was significantly higher than that of the fxre-deleted ccnd1 promoter in h1975 cells (fig.
5e).
fxr knockdown in h1975 significantly reduced wild-type ccnd1 promoter activity without reducing fxre-deleted ccnd1 promoter activity.
conversely, ectopic overexression of fxr in hcc4006 increased the wild-type ccnd1 promoter activity by approximately 100% compared to the mock group, whereas deletion of the fxre motif repressed this elevation (fig.
5f).
z-guggulsterone retained the activity of the wild-type ccnd1 promoter, rather than the fxre-deleted ones, in fxr-overexpressed hcc4006 cells.
these findings corroborated the contribution of fxr in directly activating cyclin d1 transcription in nsclc.
overexpression of cyclin d1 rescues nsclc cells from the antiproliferative effects induced by fxr suppression to examine the functional relevance of fxr and its target cyclin d1, rescue experiments were conducted.
3flag-tagged cyclin d1 was forcefully expressed into h1975 and h1299 cells treated with either z-guggulsterone or fxrsirnas, respectively; the effects on cell cycle distribution and in vitro proliferation were determined.
western blot analysis showed that cyclin d1 and p-rb, both substantially reduced in z-guggulsterone or fxrsirnas treated h1975 (fig.
6a and b) and h1299 cells (supplementary fig.
s2a and b), respectively, were increased in cells ectopically expressing cyclin d1.
as depicted, overexpression of cyclin d1 partially reversed the delayed g1/s transition and the impaired in vitro proliferation induced by z-guggulsterone in h1975 cells (fig.
6c and e).
similar changes were also found in h1299 upon the same treatment (supplementary fig.
s2c and e).
moreover, fxrsirnas-induced g0/g1 arrest and cell proliferation inhibition in h1975 and h1299 cells were almost completely abrogated in cells transfected with cyclin d1-3flag, compared to vector control (fig.
6d,f, and supplementary fig.
s2d, f).
these results clearly demonstrated that upregulation of cyclin d1 expression was responsible for the proliferation-promoting function of fxr in nsclc.figure 6overexpression of cyclin d1 rescues cell proliferation defects in fxr-suppressed nsclc cells.
western blot analysis was performed to evaluate the expression of fxr, shp, endogenous and ectopic cyclin d1, 3flag, and p-rb in h1975 cells that were treated with z-guggulsterone (z-gu, 40 μm) (a) or transfected with nc- or fxr-sirna sequences (b), in addition to the transfection with vector or cyclin d1-3flag plasmid.
3flag expression represented ectopic cyclin d1 expression.
the cell cycle profile of h1975 cells was analyzed by flow cytometry two days after the treatment with z-guggulsterone (40 μm) with or without transfection of cyclin d1-3flag (c), or the cotransfection with fxrsirnas and/or cyclin d1-3flag plasmid (d).
the cell proliferation rate of h1975 cells was determined after the treatment with z-guggulsterone (40 μm) with or without transfection of cyclin d1-3flag (e), or the cotransfection with fxrsirnas and/or cyclin d1-3flag plasmid (f) by using srb assay at different time points.
all experiments were repeated at least three times.
the data were shown as the mean ± sd.
*p < 0.05, compared with the control + vector or nc + vector group, respectively; † p < 0.05, compared with the z-guggulsterone (40 μm) + vector or fxrsirnas + vector group.
correlation analysis of fxr and cyclin d1 expression in nsclc specimens to further confirm the association between fxr and cyclin d1 in nsclc, we assessed cyclin d1 expression by ihc in the same cohort of specimens.
we detected significantly higher cyclin d1 levels in nsclc compared to corresponding pericarcinous lung tissues (supplementary fig.
s3a).
kaplan-meier analysis revealed a significantly shorter os in “cyclin d1 high” (scores 6–12) nsclc patients than in “cyclin d1 low” (0–4) patients (p = 0.0113) (supplementary fig.
s3b), which was consistent with previous reports22, 23. additionally, cyclin d1 protein was increased in “fxr high” tumors (fig.
7a and b), and chi-square analysis demonstrated a positive correlation between fxr and cyclin d1 expression in nsclc specimens (p < 0.001) (table 4).
notably, a combinatorial expression pattern of “fxr high” and “cyclin d1 high” predicted the worst os in nsclc patients (p = 0.0077) (fig.
7c).figure 7fxr and cyclin d1 expression are positively correlated in nsclc samples.
cyclin d1 expression was assessed by ihc in the same cohort of specimens.
(a) the ihc score of cyclin d1 is increased in “fxr high” tumors compared to “fxr low” tumors (p = 0.0002).
(b) representative images of high (upper panel) or low (lower panel) expression of fxr and cyclin d1 in serial sections of nsclc specimens.
(c) kaplan-meier analysis showing that patients with both fxr and cyclin d1 high expression have the worst os (p = 0.0077).
table 4correlation analysis between fxr and cyclin d1 protein expression in nsclc.nsclc samplescyclin d1correlation coefficient p-valuelowhighfxr low39230.318<0.001a fxr high3068 adata were analyzed using chi-square test.
discussion in this study, we identified fxr as a novel proto-oncogene that is markedly upregulated in nsclc.
our data indicated that fxr contributes to tumor growth via directly transactivating ccnd1 and then promoting cell cycle progression.
furthermore, the expression of fxr and cyclin d1 was found to be positively correlated in nsclc samples and could cooperatively contribute to patient sub-stratification.
to the best of our knowledge, this study is the first to comprehensively analyze the expression of fxr in nsclc, as well as assess the functional role in carcinogenesis.
fxr, an essential regulatory nuclear receptor for maintaining ba homeostasis, is deregulated in many malignancies8.
it is well established that fxr deficiency leads to spontaneous liver tumors and increased colon cell proliferation in mice as well as increased small intestine adenocarcinoma formation in apcmin mice, supporting a tumor-suppressive role of fxr in these cancer types10, 12. however, guan et al.
reported that fxr is overexpressed in esophageal adenocarcinomas, and that knockdown of fxr causes tumor cell growth inhibition both in vitro and in vivo 14. research on breast cancer has demonstrated that activation of fxr promotes cell proliferation within er-positive cancer cells, indicating that this receptor likely has an oncogenic function15.
in the present study, we provide compelling clinical evidence that in nsclc, fxr is significantly increased and independently predicts poor outcomes.
additionally, fxr promoted nsclc cell proliferation and tumorigenicity in both cultured cells and animal models, indicating that fxr could act as an oncogene in nsclc development.
these findings further highlight a dual role of fxr as either a tumor-suppressor or an oncogenic protein, suggesting the need to dissect its precise roles in different cancer types.
the genetic and environmental cues are believed to be critical to determine the function of fxr in a defined context.
specific ways by which fxr exerts proliferation-promoting functions in nsclc were subsequently explored.
cell cycle arrest and apoptosis are considered two primary approaches underlying proliferation inhibition in cancer cells.
we found that either pharmacological inhibition or knockdown of fxr delayed the nsclc cell cycle g1/s transition.
interestingly, no detectable change in apoptosis was noted.
since the fxr antagonist guggulsterone was reported to induce cell apoptosis in esophageal cancer, pancreatic cancer, and head and neck cancer, among others, such discordance might be ascribed to the specific intrinsic characteristics across different tumor types14, 24, 25. further experiments have been performed to assess the involvement of cell cycle regulators in the fxr-driven g1/s transition18.
cyclin d1, encoded by ccnd1, is a well-documented regulator of the g1/s transition through activating cdk4/6 kinase and subsequently phosphorylating rb20, that was dramatically reduced at both the protein and mrna levels in the fxr-knockdown nsclc cells, while it was increased in ectopic fxr-overexpressing cells.
our results support a reasonable mechanism that fxr facilitates nsclc cell cycle g1/s transition via upregulation of cyclin d1 transcription.
in accordance with our findings, cyclin d1 expression was concomitantly lower in hepatocyte-specific fxr knockout mice than in wild-type mice after partial hepatectomy in a previously published study26.
however, we found that knockdown of shp, a well-known fxr target gene mediating several major functions of fxr8, 9, neither affected nsclc cell proliferation nor caused changes in cyclin d1 or p-rb expression, indicating, at least in this context, that fxr-induced cell proliferation is shp independent.
as a transcription factor, fxr regulates target gene expression by binding, either as a monomer or as a heterodimer with rxrα, to an fxre sequence27.
many fxr target genes have been characterized, and they are involved in a variety of pathophysiological processes, including tumorigenesis28–31.
in this study, we demonstrated for the first time that fxr is recruited to the ccnd1 promoter in nsclc cells and activates its transcription.
furthermore, overexpression of cyclin d1 in fxr-suppressed nsclc cells restored the cell cycle progression and in vitro proliferation, suggesting that fxr promotes nsclc cell growth via the upregulation of cyclin d1 expression.
notably, we observed a positive correlation between the expression of fxr and cyclin d1 in nsclc samples, and the shortest os was observed in patients with both high fxr and high cyclin d1 expression, indicating a potential mechanistic link.
in agreement with our findings, ccnd1 is a well-recognized oncogene, as well as a poor prognostic indicator, that is overexpressed in many cancers, including nsclc22, 23. here, we provide a new biomarker, fxr, which, in combination with cyclin d1, more effectively sub-stratifies nsclc patients.
moreover, recent research has shown that the therapeutic outcomes of targeted drugs are largely determined by the response of downstream effectors to the corresponding treatments32–34.
this study supports the development of fxr-targeted therapies for nsclc and enables the downstream effector cyclin d1 to act as a candidate probe for response or resistance to fxr-based treatments.
altogether, we found that fxr acts as a novel proto-oncogene in nsclc via the target gene ccnd1, driving cell cycle progression and tumor growth.
the current study extends our understanding of the function for fxr in nsclc tumorigenesis, providing a promising prognostic biomarker and therapeutic approach.
materials and methods patients and tissue microarray primary nsclc and corresponding pericarcinous lung tissues were consecutively collected from the department of pathology in ren ji hospital (shanghai, china) between 2008 and 2010. tissue microarrays (tmas) were constructed as previously described35.
for each sample, two cores with a 1.6-mm diameter were obtained from the original paraffin block.
clinicopathological information was retrospectively reviewed.
the histology was determined according to the criteria of the world health organization, and pathological stages were classified according to the seventh edition of the lung cancer staging system36.
survival data were recorded on the basis of follow-up clinic visits or telephone calls.
patients who had incomplete clinical or follow-up data or who had received neoadjuvant chemotherapy or radiotherapy were excluded.
in total, 160 patients were included.
this study was approved by the ethics committee of ren ji hospital, and informed consent was obtained from all participants.
all methods were performed in accordance with the approved guidelines of school of medical graduate shanghai jiao tong university.
immunohistochemical (ihc) analysis ihc staining for fxr and cyclin d1 expression in tmas was performed as described4.
anti-bile acid receptor (nr1h4) antibody (abcam, cambridge, ma) and anti-cyclin d1 antibody (cell signaling technology, beverly, ma) were applied at 1:100 and 1:50, respectively.
concentration-matched nonspecific rabbit igg was used as a isotype control.
two trained pathologists viewed the ihc staining results and reached a final consensus.
the scoring for the staining intensity was as follows: negative (0), weak (1), moderate (2) and intense (3).
the scoring for the percentage of positive cells was as follows: 0% (0), 1–25% (1), 26–50% (2), 51–75% (3) and 76–100% (4).
the final fxr or cyclin d1 ihc score was obtained by multiplying the intensity and percentage scores, which were defined as low (including scores of 0–4) or high (6–12) expression.
cell culture and cell proliferation assays human nsclc cell lines (h1650, h460, hcc4006, h1975 and h1299), and a hepatoma cell line (hepg2) were purchased from the american type culture collection (atcc).
all cells were cultured in rpmi-1640 or dmem-f12 (invitrogen corporation, carlsbad, ca) supplemented with 10% fbs.
the in vitro cell proliferation was assessed by sulforhodamine b (srb) assay as previously described37.
the absorbance was measured at 560 nm in a microplate reader.
western blot western blot analysis was performed according to previously described procedures16.
we used primary antibodies, including anti-bile acid receoptor (nr1h4) antibody, anti-shp antibody (santa cruz, ca), anti-phospho-rb antibody, anti-cyclin d1 antibody, anti-cyclin e1 antibody, anti-cdk2 antibody, anti-cdk4 antibody, anti-cdk6 antibody, anti-p21waf1/cip1 antibody, anti-p27kip1 antibody, and anti-β-actin antibody (cell signaling technology) according to the manufacturer’s recommended dilutions.
quantitative real-time pcr (rt-pcr) analysis quantitative rt-pcr was performed as previously described16.
primers were designed as follows: fxr forward, 5′-gattgctttgctgaaagggtc-3′; reverse, 5′-cagaatgcccagacggaag-3′; shp forward, 5′-aggcctccaagccgcctcccacattgggc-3′; reverse, 5′-gcaggctggtcggaaacttgagggt-3′; cyclin d1 forward, 5′-cgtgggctctaagatgaagg-3′; reverse, 5′-tgcggatgatctgtttgttc-3′; β-actin forward, 5′-ttgctgatccacatctgct-3′; reverse, 5′-gacaggatgcagaaggagat-3′.
transfection cells were transfected with sirna by using lipofectamine rnaimax reagent (invitrogen corporation) according to the manufacturer’s instructions.
the target sequences of double-stranded nucleotides used in sirna transfection were 5′-ggaccatgaagaccagatt-3′(fxrsirna-1) and 5′-gtagcagagatgcctgtaa-3′(fxrsirna-2) for fxr knockdown, 5′-ggaatatgcctgcctgaaa-3′(shpsirna-1) and 5′-tcgccctatcattggagat-3′(shpsirna-2) for shp knockdown, and 5′-ttctccgaacgtgtcacgt-3′ as a negative control (nc) (ribobio, guangzhou, china).
to perform rescue experiments, cells were transfected with pcdna3.1(+)-cyclin d1-3flag plasmids, constructed with obio biotechnology (shanghai, china), by using lipofectamine 2000 (invitrogen corporation) according to the manufacturer’s protocol.
empty pcdna3.1(+)-3flag plasmid was used as control.
construction of lentiviral vectors and cell infection lentiviral vectors were constructed with obio biotechnology (shanghai, china), using either pcmv-nr1h4-pgk-puror plasmids, which carry the full-length nr1h4 coding sequence (genbank accession nm_005123.3), or pcmv-g&pr-u6-shrna plasmids, which generate shrna targeting fxr or ncshrna as described above.
the detailed methodology for cell infection is provided in the supplementary information.
confocal immuofluorescence after treatment, cells were grown on cover-slips with 1% gelatin for 24 h. confocal immuofluorescence was performed as previously described16.
anti-human ki-67 antibody (spring bioscience, fremont, ca) was applied at 1:100. tumorigenicity assays in nude mice the animal experiments were performed in accordance with the guidelines of the experimental animal ethics committee of shanghai jiao tong university.
all experimental procedures were approved by the experimental animal ethics committee of shanghai jiao tong university.
the detailed methodology is provided in the supplementary information.
cell cycle and apoptosis analysis by flowcytometry for cell cycle analysis, cells were collected 48 h after treatment.
the cell cycle distribution was measured using a flow cytometer (bd bioscience, san jose, ca).
for apoptosis analysis, cells were harvested with edta-free trypsin 72 h after treatment and stained using a fitc annexin v apoptosis detection kit (bd bioscience) according to the manufacturer’s instructions.
the stained cells were examined with a flow cytometer.
luciferase reporter assay luciferase reporter plasmids carrying either wild-type or fxre-deleted ccnd1 promoter sequence were generated by obio biotechnology (shanghai, china).
the detailed methodology is provided in the supplementary information.
chromatin immunoprecipitation (chip) assay the chip assay was conducted using a simplechip plus enzymatic chromatin ip kit (cell signaling technology) according to the manufacturer’s instructions.
the detailed methodology is provided in the supplementary information.
primers used in quantitative rt-pcr were as follows: cyclin d1 promoter, forward 5′-taggtgctccctgctggggc-3′; reverse 5′-acctttcagggtgaattcctccc-3′.
statistical analysis comparisons between groups were performed using student’s t test or the mann-whitney u test.
correlational analyses were conducted using the chi-square test or fisher’s exact test.
survival data were analyzed by the kaplan-meier method (log-rank test).
a multivariate cox regression model was used to identify independent predictors.
statistical analyses were performed using spss 17.0 (spss inc., usa).
a value of p < 0.05 was considered statistically significant.
electronic supplementary material supplementary information
@highlight
farnesoid x receptor (fxr), a nuclear receptor for maintaining bile acid homeostasis, has been recognized as a tumor suppressor in enterohepatic tissues.
however, its expression and functional role in non-small cell lung cancer (nsclc) remain unclear.
we report that fxr is significantly increased in nsclc and that it predicts poor clinical outcomes in nsclc patients.
fxr knockdown in nsclc cells inhibited in vitro cell proliferation, blocked xenograft growth in nude mice, and delayed the g1/s transition of the cell cycle, whereas ectopic overexpression of fxr promoted nsclc cell proliferation.
mechanistic analysis demonstrated that fxr could directly bind to an inverted repeat-0 sequence in the ccnd1 promoter and activate its transcription.
cyclin d1 overexpression rescued nsclc cells from the delayed g1/s transition and the impaired cell proliferation induced by fxr knockdown.
importantly, a positive correlation between the expression of fxr and cyclin d1 was confirmed in nsclc samples, and patients with high expression of both fxr and cyclin d1 had the worst prognosis.
in summary, our results suggest that fxr has oncogenic potential in nsclc development, providing mechanistic insights that could be exploited for both prognostic and therapeutic purposes.
