i. introduction mast cells (mcs) are haematopoietic cells widely distributed in vascularized tissues, at the interface with the external environment.
unlike other immune cells, mcs normally circulate through the vascular system as immature progenitors and undergo the terminal stages of their differentiation and/or maturation locally, after migration into vascularized tissues or serosal cavities, in a process regulated by multiple local factors [1].
the main factors that influence mcs number and phenotype include c-kit ligand stem-cell factor (scf) [2] and the chief survival and/or developmental factors for the mcs, il-3 and t helper type 2 (th2)-associated cytokines such as il-4 and il-9, but the complete list comprises a wide panel of other growth factors, cytokines and chemokines [1].
mcs abound especially near surfaces exposed to the environment, including the gastrointestinal and airways tract and skin, where pathogens, allergens and other environmental agents are frequently encountered [3–5].
due to their specific anatomical location, mcs have numerous functions; in particular they are responsible for the first line of defence against external pathogens and other environmental insults [6].
mcs are well known for their versatile role in allergic responses through the binding of specific antigens to the fcɛri-ige complex [1].
however, in recent years, it has been demonstrated that mcs contribute to a variety of non-allergic immunoregulatory reactions.
mcs infiltrate the sites of chronic inflammation [7]; increased numbers of mcs have been found in the synovial tissues and fluids of patients with rheumatoid arthritis (ra), and at sites of cartilage erosion [8].
it has been reported that mc density is increased at the margins of various tumors in humans [9, 10], modulating many aspects of the tumor natural history [11–13] and correlating with angiogenesis through the synthesis and release of a wide spectrum of angiogenic factors, such as vascular endothelial growth factor-a (vegf-a) and vascular endothelial growth factor-b (vegf-b), [14,15] and tumor invasion by releasing cytokines and proteases [12].
the urokinase-type plasminogen activator receptor (upar, cd87) is a gpi-anchored protein that functions as the receptor for urokinase (upa) [16].
upar, expressed by a wide variety of cells, including monocytes, macrophages, neutrophils and basophils [17,18], is formed by three homologous domains (di, dii, diii) [19].
the upar can be cleaved within the di/dii linker region by several proteolytic enzymes, including upa itself [20,21].
the cleavage causes the release of di from the molecule.
therefore, upar can exist on the cell surface in either a three-domain form (di-dii-diii-upar), which is capable of binding upa, or a two-domain form (dii-diii-upar), which does not bind upa [20].
upar has important roles in both physiological and pathological processes; in addition to its regulatory role in fibrinolysis and inflammation, it has been implicated in tumor invasion, metastasis, fibrosis, and in the development of protective immunity in infections.
in particular, upar is strongly up-regulated in several cancers where represents a negative prognostic factor [22].
upar traditional role was considered the focusing of proteolytic upa activity on the cell membrane, however upar also binds vitronectin (vn), a component abundant in tumor-associated ecm [23], and interacts with various integrins regulating their activity.
in addition upar mediates upa-dependent cell migration and is required for chemotaxis induced by fmet-leu-phe (fmlf), a potent leukocyte chemoattractant.
through a specific site corresponding to amino acids 88–92 (srsry), located in the region linking upar domain 1 (di) to upar domain 2 (dii), the cell-surface upar functionally interacts with the n-formyl peptide receptors (fprs) [24].
fprs are a family of pattern recognition receptors.
it is now well known that, by interacting with several structurally diverse pro- and anti-inflammatory ligands, fprs seem to possess important regulatory effects in multiple pathological conditions, including inflammation and cancer.
fprs are expressed in abundance on cells of the host defense system; in addition, all fprs expressed on epithelia seem to be required for wound repair and restitution of barrier integrity, by facilitating epithelial cell migration, proliferation, and neo-angiogenesis [25].
three variants of fprs have been identified in humans: the high and low affinity receptors, fpr1 and fpr2, and the fpr3, which does not bind fmlf [26].
recently, new insight on the diversity of mc products, signalling mechanisms, and interactions with other cell types has led to many attractive hypotheses about the diverse potential effector and immunoregulatory roles of mcs in physiological and pathological conditions.
in particular, several authors focused their attention on the role of mcs in tumor growth, starting from the observation that mast cell deficient mice show a reduced cancer infiltration [27].
based on such evidences, in this study we investigated whether mcs, by expressing and modulating the fprs and the upa/upar system, could represent a novel target in several inflammatory and neoplastic diseases.
ii.
methodology peptides and chemicals the following were purchased: di-isopropyl fluorophosphate (dfp; fluka, buchs, switzerland); fmlf was from calbiochem (la jolla, ca); the peptide upar84–95 was synthesized by primm (milan, italy), the 59-(n-ethylcarboxamido) adenosine (neca) was from sigma-aldrich (st. louis, mo, usa), the phorbol myristate acetate (pma) was obtained from lc services (woburn, ma), human upa and the upa n-terminal fragment (atf) were from sekisui diagnostics (lexington, ma, usa); pe-labeled anti-ige abs (caltag laboratories, burlingame, ca); fitc-labeled goat anti-rabbit igg (abcam, cambridge, u.k.).
for chemotaxis assay 8-mm-pore polycarbonate membranes (nucleopore, pleasanton, ca), trizol solution was from invitrogen fischerscientific (illkirch, france), and dna ladder and moloney leukemia virus reverse transcriptase were from promega (madison, wi).
protein concentration was estimated with a modified bradford assay (bio-rad laboratories).
ecl plus was from ge healthcare (buckinghamshire, uk).
the mixture of protease and phosphatase inhibitors was from calbiochem.
rabbit polyclonal anti-upar and monoclonal anti-upa antibodies were from sekisui diagnostics, rabbit anti-actin was from sigma-aldrich (st. louis, mo).
secondary anti-mouse and anti-rabbit abs coupled to hrp were from bio-rad (munchen, germany).
rantes was from peprotech ec ltd (london, uk) and scf was from recombinant human stem cell factor (scf) from amgen (thousand oaks, ca).
cell culture human mast cell line hmc-1 was kindly donated by dr. j.h.
butterfield (mayo clinic, rochester, mn); cells were maintained in suspension culture at a density of 3–9 × 105 cells/ml of imdm supplemented with 10% fcs, 2 mm l-glutamine, 1.2 mm monothioglicerol.
the thp-1 monocyte-like cell line was grown in rpmi 1640 medium supplemented with 10% heat-inactivated fcs [17,18].
isolation and purification of human lung mast cells (hlmc) lung tissue was obtained from patients undergoing thoracotomy and lung resection, after obtaining their informed consent according to the guidelines of the institutional review board.
macroscopically normal parenchyma was dissected free from pleura, bronchi, and blood vessels and minced into a single-cell suspension as previously described [28].
yields ranged between 3×106 and 18×106 mast cells, and purity was between 1 and 8%.
lung mast cells were purified by countercurrent elutriation (j2/21; beckman) and then by discontinuous percoll density gradient as previously described.
mast cells were further purified to near homogeneity by positive selection: incubation with anti-fcɛri (igg1) was followed by the exposure to magnetic beads coated with macs goat anti-mouse igg.
labeled cells were enriched by positive selection columns (macs system; miltenyi biotec).
the final preparations contained >95% viable cells, as assessed by the trypan blue exclusion method, and purity was >98% mast cells.
rna purification and analysis total cellular rna was isolated by lysing cells in trizol solution, according to the supplier’s protocol [29].
rna was precipitated and quantitated by spectroscopy.
five micrograms of total rna was reversely transcribed with random hexamer primers and 200 u murine moloney leukemia virus reverse transcriptase.
one microliter of reverse-transcribed dna was then amplified for fpr1, fpr2, fpr3, upa, upar and gapdh using specific primers.
the primers for fpr1 were 5′-atggagacaaattcctctctc (sense) and 3′-cacctctgcagaaggtaaagt (antisense); for fpr2 were 5′-cttgtgatctgggtggctgga (sense) and 3′cattgcctgtaactcagtctc (antisense); and for fpr3 were 5′agttgctccacaggaatcca (sense) and 3′-gccaatattgaagtggaggatcaga (antisense), for upa were 5′-aaaatgctatgtgctgctgacc (sense) and 3′ccctgccctgaagtcgttagtg (antisense) [24], for upar were 5′ctgcggtgcatgcagtgtaag (sense) and 3′ggtccagaggagagtgcctcc (antisense) [18], for vegf-a were 5′tcttcaagccatcctgtgtg (sense) and 3′gcctcggcttgtcacatc (antisense) [30].
the primers for gapdh were 5′gccaaagggtcatcatctc (sense) and 3′-gtagaggcagggatgatgttc (antisense).
pcr products, together with a dna ladder as a size standard, were separated on a 1% agarose gel, stained with ethidium bromide, and quantified with the image analysis system chemidoc xrsn (bio-rad laboratories).
western blot immunoblotting experiments were performed according to standard procedures [31].
briefly, cells were harvested in lysis buffer (50 mm hepes, 150 mm nacl, 10% glycerol, 1% triton x-100, 1 mm egta, 1.5 mm mgcl2, 10 mm naf, 10 mm sodium pyrophosphate, and 1 mm na3vo4) supplemented with a mixture of proteases and phosphatases inhibitors.
the protein content was measured by a colorimetric assay.
fifty micrograms of protein was electrophoresed on a 10% sds-page under non reducing conditions and transferred onto a polyvinylidene fluoride membrane.
the membrane was blocked with 5% nonfat dry milk and probed with specific abs: mouse anti-upa (1μg/ml), rabbit anti upar (1μg/ml), and rabbit anti-β-actin (0.5 μg/ml).
finally, washed filters were incubated with hrp-conjugated anti-rabbit or antimouse abs.
the immunoreactive bands were detected by a chemiluminescence kit and quantified by densitometry (chemidoc xrs, biorad).
flow cytometric analysis of surface molecules flow cytometric analysis of cell surface molecules was performed as previously described [18].
briefly, after saturation of non specific binding sites with total rabbit igg, cells were incubated for 20 min at +4°c with specific or isotype control antibodies.
for indirect staining this step was followed by a second incubation for 20 min at +4°c with an appropriate anti-isotype-conjugated antibody.
finally, cells were washed and analyzed with a facscalibur cytofluorometer using cell quest software (becton & dickinson, san fernando, ca).
a total of 104 events for each sample were acquired in all cytofluorimetric analyses.
chemotaxis assay human lung mast cell (hlmc) chemotaxis was performed using a modified boyden chamber technique as previously described [18].
briefly, 25 μl of pacgm buffer or various concentrations of the chemoattractants in the same buffer were placed in triplicate in the lower compartment of a 48-well microchemotaxis chamber (neuroprobe, cabin john, md).
the lower compartments were covered with polycarbonate membranes with a two-filter sandwich constituted by 5-μm (lower) and 8-μm (upper) pore size polycarbonate membranes (nucleopore, pleasanton, ca).
fifty microliters of the cell suspensions (5×104/well) resuspended in pacgm was pipetted into the upper compartments.
the chemotactic chamber was then incubated for 3 h at 37°c in a humidified incubator with 5% co2 (automatic co2 incubator, model 160 ir, icn/flow laboratories).
at the end of the incubation the upper polycarbonate filter was discarded, while the lower nitrate cellulose filter was fixed in methanol, stained with alcian blue, and then mounted on a microscope slide with cytoseal (stephen scientific, springfield, nj).
hlmc chemotaxis was quantitated microscopically by counting the number of cells attached to the surface of the 5-μm cellulose nitrate filter.
in each experiment 10 fields/triplicate filter were measured at × 40 magnification.
the results were compared with buffer controls.
check board analysis was performed to discriminate between chemotaxis and nondirected migration (chemokines) of hlmc.
in these experiments mast cells were placed in the upper chambers, and various concentrations of stimuli or buffer were added into the upper or lower wells or both.
spontaneous migration (chemokinesis) was determined in the absence of chemoattractant or when stimuli were added to both lower and upper chambers.
the mast cell migratory responses to the stimuli were largely due to chemotaxis and not to chemokinesis.
indeed, a check board analysis, in which chemoattractants above and below the filters were varied, resulted in significant migration only when there was a gradient of the factor below the filters (data not shown).
elisa for vegf-a vegf-a content in cell lysates and in culture supernatants of human mast cells was measured in duplicate determinations with a commercially available elisa (r&d systems) [32].
inactivation of upa the upa was inactivated by incubation with 10 mm dfp for 2 h at 4°c [18].
iii.
results expression of upar and fprs in the human mast cell line hmc-1 in several conditions, such as in the fibroblast-to-myo fibroblast transition involved in the pathogenesis of inflammatory and neoplastic disorders, the upa/upar system acts through the structural and functional interaction with fprs [24].
to investigate the existence of a functional interaction between the upa-upar system and fprs in mcs, we first evaluated the expression at mrna and protein level of upa and upar in hmc-1 cells.
upa and upar mrnas were detected by rt-pcr analysis of rnas from hmc-1 cells and thp-1 monocyte-like cells, used as a positive control (fig.
1a).
western blot analysis of hmc-1 cell lysates with a monoclonal anti-upa antibody confirmed the production of upa.
the same analysis with a polyclonal anti-upar antibody demonstrated that hmc-1 cells expressed upar in the intact (di-dii-diii-upar) and cleaved (dii-diii-upar) forms (fig.
1b).
this result was previously described in other cell types, including monocyte-like thp-1 cells [18].
dii-diii-upar can interact with fprs through its srsry chemotactic domain, exposed at the n-terminus [21,33].
moreover, upon binding upa, intact upar can expose the same chemotactic domain, located in the di-dii linker region, through a conformational modification [18].
then, we examined fprs expression in hmc-1 cells by rt-pcr analysis.
electrophoresis in agarose gel showed the presence of mrnas for all three receptors: fpr1, fpr2 and fpr3 (fig.
1c).
these experiments demonstrated that mcs synthesized upa and its specific receptor upar as well as fprs, most important mediators of upa/upar-induced cell responses in cancer and inflammation [16,22,24,31].
effects of dfp-upa and upar84–95 on vegf-a expression and production in the hmc-1 human mast cell line it has been reported that human mast cells can express and synthesize vegf-a and vegf-b, as well as vascular endothelial growth factor-c (vegf-c) and vascular endothelial growth factor-d (vegf-d) [14, 15].
thus, we evaluated whether upa, both directly and/or by inducing upar interaction with fprs, could stimulate vegf-a expression and production by hmc-1 cells.
to this aim, hmc-1 cells were stimulated for 2 hours with dfp inactivated-upa (10−8 m), able to bind upar but devoid of enzymatic activity, and with the upar84–95 peptide (10−9 m), containing the srsry chemotactic sequence of upar and able to bind fprs.
rt-pcr analysis of vegf-a mrna expression showed that hmc-1 cells synthetized mrna for vegf-a after 2 hours stimulation with both ligands (fig.
2a).
to evaluate whether dfp-upa and upar84–95 also induced vegf-a production, we investigated the kinetics of vegf-a release from hmc-1 cells.
both dfp-upa and upar84–95 induced a time-dependent release of vegf-a in hmc-1 cells (not shown) that was significant after 6 hours of stimulation (fig 2b).
effect of dfp-upa, and upar84–95 on primary human lung mast cells (hlmc) chemotaxis we demonstrated that upa can induce human basophil chemotaxis through upar functional interaction with fprs [18].
thus, we the studied upar expression and the existence of a functional interaction with fprs also in primary human mcs.
to this aim, human lung mast cells (hlmc) were purified from normal subjects and analyzed by flow cytometry with a polyclonal anti-upar antibody or with purified control igg, then stained with fitc-conjugated goat anti-rabbit igg and pe-conjugated anti-ige.
the vast majority (80–94%) of hlmc showed upar expression on the cell surface (fig.
3a).
in order to elucidate the potential interaction of cell-surface upar and fprs, we tested the effects of dfp-inactivated upa (10−9–10−8 m) and of different concentrations of the upar-derived chemotactic peptide upar84–95 (10−9–10−8 m) on purified hlmc chemotaxis.
both dfp-upa and upar84–95 caused hlmc migration (fig.
3b, c).
both the chemokine rantes (10 and 100 ng/ml) and the major chemotactic factor scf (10 and 100 ng/ml), used as a positive control, showed to be potent factors in hlmc migratory activity (fig.
3b, c).
to determine whether migration of hlmc resulted from chemotaxis or chemokinesis, checkerboard analysis was performed and showed that both stimuli in a dose dependent manner induced hlmc migration when added to the lower wells of the chemotaxis chamber.
an optimal concentration of the stimuli added with the cells to the upper wells or to both compartments did not induce directional hlmc migration.
thus, dfp-upa and upar84–95-induced migration of hlmc resulted from chemotaxis, rather than from chemokinesis (data not shown).
in addition, experiments with different concentration of atf (aa 1–143) (10−9–10−8 m), which consists only of the upar-binding region of upa and is devoid of enzymatic activity [18], demonstrated that this peptide retained its chemotactic properties (fig.
3d).
taken together, these results indicated that upa induced mcs migration by binding upar and stimulating its interaction with fprs, most probably through the exposure of the upar84–95 epitope; indeed, the enzymatic activity of upa was not primarily responsible for inducing hlmc chemotaxis.
iv.
discussion a straight relation between cancer and flogosis has been extensively described, starting from the consideration that inflammatory cells are localized all around tumors [9, 34–36].
the interaction between cancer cells and their microenvironment are multiple and can result in both progression and arrest of tumor growth [37].
however tumor microenvironment is constituted not only by cells of the innate and adaptive immune system but also from stromal cells [38].
it has been described that stromal cells, from different tumors, are able to synthetize mrna for diverse molecules, for example collagenase, matrix metalloproteases and proteases, such as plasmin, all responsible of the early stages of tumor growth through the degradation of the extracellular matrix components (ecm) that is one of the mechanisms that neoplastic cells use to invade the interstitial tissue [39].
furthermore stromal cells, by producing chemoattractant molecules, recruit inflammatory cells into tumor sites, influencing them in a way that ultimately promotes cancer progression and prognosis [38,40,41].
in these context the detection of mcs within the tumor argues for their role in the modulation of neoplasia biology and hypothize a possible cross-talk with stromal cells localized within the tumor [27].
the three n-formyl receptors named fpr1, fpr2 and fpr3 are innate immune receptors belonging to the pattern recognition receptors and associated to g-proteins.
beside their involvement in inflammatory disorders fprs have been described as regulating receptors involved in wound healing [42], angiogenesis [25], and myofibroblast activation occurring in the context of fibrotic disorders [24].
the involvement of fprs in tumors has been studied by few authors and in some animal models where their role seems to differ in relation of the ligands or of the affected tissue [25].
we have recently showed that fprs, as previously demonstrated in epithelial cells, could be involved in the pathogenesis of ssc, an autoimmune disease, through different mechanisms, including the interaction with the upa-upar system [24].
in this paper we describe for the first time the expression of all the three fprs in the human mast cell line hmc-1 (fig.
1).
the upa-upar system is an important and complex cellular recognition system that mediates different activities such as fibrinolysis, cell adhesion and migration, and tissue remodeling.
in particular upa, upar and the plasminogen activator inhibitor type-1 (pai-1) are not only strongly upregulated in a wide variety of cancer types but their biological levels correlate with a poor neoplastic outcome and a more rapid tumor progression [22,43].
nielsen and colleague described through in situ hybridization and immunohistochemical studies of invasive ductal breast cancer tissue that upa, upar and pai-1 are expressed in stromal cells immediately surrounding the invasive cancer cells [44].
we therefore studied the expression, at mrna and protein levels, of upa and upar in hmc-1 cells.
hmc-1 cells, differently from basophils, synthetized upa and expressed upar both in the intact and in a cleaved form (dii-diii-upar), which is able to bind fprs through the srsry sequence (residues 88–92) (fig.
1).
interestingly, upa itself can cleave upar in the di-dii linker region, thus exposing the srsrysequence.
moreover, by cytofluorimetric analysis using hlmc isolated from donors undergoing thoracotomy and lung resection, we confirmed that upar was expressed on the cell surface of the vast majority of hlmc (80–94%).
we also found that enzymatically inactive upa (dfp-upa) and atf, which is devoid of enzymatic activity, were potent chemoattractants for hlmc as well as the upar-derived peptide upar84–95, containing the srsry sequence (fig.
3).
thus, upa released by mcs can act in an autocrine fashion both by cleaving upar and exposing the srsry sequence than, similarly to what happens in basophils, by triggering upar conformational changes able to mediate binding to fprs and the transmission of signals from the cell surface to the inner domains involved in mcs chemotaxis.
we have previously demonstrated that the h. pylori-derived peptide hp(2–20) stimulated eosinophil migration through the engagement of fpr2 and fpr3, and also induced production of vegf-a and tgf-beta, two key mediators of tissue remodeling [32].
thus, we evaluated the possibility that fprs stimulation through upa and upar84–95 triggering was able to induce synthesis and release of the vascular endothelial growth factor-a (vegf-a).
vegf-a is the most potent proangiogenic mediator known so far, involved in endothelial proliferation, migration, and survival.
it also acts as a proinflammatory cytokine [45].
both dfp-upa and the upar84–95 peptide proved to be potent stimuli for vegf-a synthesis and release.
it has been demonstrated that, in murine models of glioma and meningioma, upar and cathepsin b knock-out inhibited angiogenesis by disrupting the jak/stat pathway-dependent vegf expression [46,47].
thus, upar could represent a useful target to inhibit vegf-a mediated angiogenesis both in neoplastic and inflammatory diseases [48].
v. conclusion our work suggests the possibility that mcs, through the expression of the upa/upar system and its interaction with fprs, can be responsible of chronic inflammation, tumor progression and angiogenesis.
moreover, it can be hypothesized that stromal cells, by secreting chemotactic factors, can additionally contribute to the recruitment of mcs, for example, in the tumor surroundings.
finally, the results described in this study may have practical implications in inflammatory and neoplastic disorders where mcs infiltration play a prominent role.
in fact, several author recently suggested that the crosstalk between mcs and other tumor-infiltrating cells could be a potential target for anticancer therapies [13], or it is conceivable that agents acting on upar-mediated chemotaxis (i.e., by blocking the chemotactic epitope) may be used to modify the mcs driven inflammatory and tumor promoting reactions.
@highlight
mast cell and basophils express the high affinity receptor for ige (fcɛri) and are primary effector cells of allergic disorders.
the urokinase (upa)-mediated plasminogen activation system is involved in physiological and pathological events based on cell migration and tissue remodelling, such as inflammation, wound healing, angiogenesis and metastasis.
upa is a serine protease that binds upar, a high affinity glycosyl-phosphatidyl-inositol (gpi)-anchored receptor.
upar focuses upa activity at the cell surface and activates intracellular signaling through lateral interactions with integrins, receptor tyrosine kinases and the g-protein-coupled family of fmlf chemotaxis receptors (fprs).
we investigated the expression of the upa-upar system and its functional interaction with fprs in human mast cells (mcs).
differently from basophils, mcs produced upa that was able to induce their chemotaxis.
indeed, mcs also expressed upar, both in the intact and in a cleaved form (dii-diii-upar) that can expose, at the n-terminus, the srsry sequence, able to interact with fprs and to mediate cell chemotaxis.
mcs also expressed mrnas for fprs that were functionally active; indeed, upa and a soluble peptide (upar84–95), containing the srsry chemotactic sequence of upar and able to interact with fprs, were able to induce mcs chemotaxis.
thus, upa is a potent chemoattractant for mcs acting through the exposure of the chemotactic epitope of upar, that is an endogenous ligand for fprs.
the same mechanism could be involved in vegf-a secretion by human mcs, also induced by upa and upar84–95 stimulation.
