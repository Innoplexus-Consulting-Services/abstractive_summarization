introduction the posterior maxilla represents a unique challenge when planning implant prosthetic rehabilitation of edentulous sites.
common problems facing the clinician are the lack of bone volume due to resorption of the alveolar process and pneumatization of the maxillary sinuses as well as poor bone quality.
sinus lift surgery is the most common procedure in use today in conjunction with implant placement in the posterior maxilla with reported similar outcomes of implant placed with or without sinus floor augmentation [1].
implants placed in augmented sinuses had a survival rate range of 98.6% - 93.5% after 3-5 years of loading [2-4].
schneiderian membrane perforation during sinus lift surgery has been reported to occur in 10-60% of all procedures [5-7].
it may lead to an increase in surgical challenges, time and postoperative complications.
careful preoperative treatment planning can reduce the risk of membrane perforation.
anatomical factors like the presence, location and direction of the maxillary septum, the thickness, and angles of maxillary sinus walls and the thickness of the schneiderian membrane need to be carefully identified and examined in conventional and three-dimensional radiographic images.
however, even careful preparation, reflection and mobilization of the membrane along anatomical irregularities, cannot always prevent perforation [8].
underwood septa are osseous projections often present in the maxillary sinus and divide the sinus into smaller compartments.
septa’s main function is to act as masticatory force carrying struts during the dentate phase in life [9].
the term “interfering septa” is used to identify a septum lying directly above the alveolar ridge where sinus lift surgery was planned, and thus “interfered” during the preparation of the osseous window and/or the reflection of the schneiderian membrane [10].
overall, the prevalence of septa reported in the literature at the sinus level is between 16% and 48% [11-17].
although a reduced implant survival following sinus membrane perforations has been reported, [5, 18] none of the studies have specifically investigated the relationship between the orientation of maxillary sinus septa and the occurrence of intra-surgical complications, such as sinus membrane perforation, as well as postoperative complications, such as the development of graft necrosis and persistent sinusitis.
in addition, none of them evaluated long-term implant marginal bone loss following such complications.
while a variety of techniques have been discussed with respect to the intra-surgical management of perforation [19-21], surgical abandonment has also been documented, particularly in cases of large perforations [6].
for these reasons, an increased understanding of the risks posed by interfering sinus septa is of high value to both the surgeon and the patient.
the primary objectives of the present study were to propose a classification system based on the orientation of sinus septa and to assess the prevalence and severity of sinus membrane perforation complications as they relate to the presence of sinus septa and this classification.
secondary objectives included the evaluation of the impact of membrane perforation on post-operative complications and marginal bone loss during the first year of loading as measured on intraoral radiographs.
materials and methods study design: this study is a retrospective chart review of consecutive patients who underwent lateral window sinus lift procedure.
sinus lift and implant surgeries were performed in partially dentate and edentulous patients, in the posterior maxillary arch, utilizing either a one- or two-stage sinus lift approach.
residual ridge height was 0.8-8 mm.
all partially dentate patients had either been previously treated for periodontal disease and were receiving maintenance therapy, or did not show any signs or symptoms of periodontal disease.
the inclusion criteria for this study were: patients who had at least one direct sinus lift surgery performed by one experienced periodontist (t.i) and in patients who also received implant therapy, the availability of periapical radiographs representing implants with clearly discernible threads during placement as well as during follow-up appointments.
surgical procedure all procedures were carried under local anesthesia.
the flap design included a mid crestal incision over the edentulous ridge and divergent vertical incisions to allow for a passive flap approximation at the end of the procedure.
osseous lateral window was created using a combination of rotary burs and piezo electrical tips.
an oval shaped – rounded corners window of adequate size and width to allow appropriate use of sinus elevation instrument was created.
the detecting of interfering septa in the preoperative ctcb required the modification of the window to resemble a w or a kidney.
once access to the sinus has been gained, a combination of piezo electrical tips and hand instruments was used for the careful reflection of the schneiderian membrane.
identification of a sinus septum required a careful and gentle elevation of the membrane around and off the bony septum.
membrane integrity was assessed visually and by asking the patients to blow their nose gently to detect the free movement of the membrane.
if a perforation was detected, it was classified based on size into small (<5 mm) or large (≥5 mm).
the perforation was repaired using an internally placed membrane (neomem by citagenix inc, canada) following a parachute technique [10].
one of the four bone grafts was compacted into the sinus.
dental implants were placed simultaneously only in cases where implant stability could be achieved (> 3 mm of initial alveolar bone height).
otherwise, implant placement was delayed and done at a separate procedure.
resorbable membrane was used to cover the lateral window (bio-gide by geistlich, switzerland).
flap edges were approximated and a passive primary closure of the area was achieved.
all patients received postoperative antibiotic (amoxicillin 500 mg tid for 7 days or clindamycin 300 mg tid for 7 days).
patient follow-up: all patients were seen initially 7-10 days postoperatively and then a monthly follow-up visit was conducted.
delayed implant placement was done 6-9 months after the sinus augmentation and patients were followed up monthly during the healing period.
at the integration check, osseointegration was verified radiographically, and implant stability was checked by resonance frequency analysis (osstell isq by osstell, sweden) or a manual reverse torque test (<20 ncm torque applied in a counterclockwise direction) when ossstell was not available.
patients were then referred to the restorative dentist for the final prosthetic rehabilitation and were placed on an annual recall program.
data collection patient charts were audited for patient’s demographic data, smoking and medical history.
significant medical history included: type i and type ii diabetes mellitus, osteoporosis on bisphosphonate medication and sinusitis.
intra-operative notes documenting the steps of the surgical procedure and the presence of interfering septa, the occurrence of sinus membrane perforation, the size of the perforation, the type of bone graft used and the timing of implant placement and the type of implant used were reviewed.
post-operative notes documenting the healing period, and the occurrence of any postoperative complication like bleeding, infection including infected grafts, the development of persistent sinusitis for more than two months postoperatively, altered sensation, and soft tissue numbness or pain were analyzed.
preoperative cone beam computed tomography (cbct) images were evaluated using kodak 3d imaging v 2.4 software for the presence and the orientation of interfering septa.
interfering septa are defined as osseous projections located directly above the alveolar ridge where sinus lift surgery was planned and extended more than 2mm.
intraoral radiographs taken at implant placement and during follow-up appointments were scanned and measured using image j v1.46 software (national institutes of health, maryland, usa).
the coronal margin of the implant collar as well as the most coronal aspect of the bone-to-implant contact were used as reference points for linear measurements of marginal bone loss.
measurements of mesial and distal marginal bone levels adjacent to each implant were performed according to piao, et al.
[22].
the amount of bone resorption, which is the difference between the initial bone level and the bone level at the latest follow-up examination, was calculated and mesial and distal bone loss was determined for each implant.
thresholds of 1.5 mm and 1.0 mm of averaged marginal bone loss were selected for comparisons during the latest follow-up.
one examiner who was not involved in the treatment of patients evaluated all intraoral radiographs.
intra-examiner reliability was assessed in a sample of 25 randomly selected, and recordings of marginal bone loss at the latest follow-up were measured twice, once at baseline and after 3months.
these duplicate recordings were highly correlated, with pearson correlation coefficients of 0.988 (p<0.001) and 0.993 (p<0.001) at the mesial and distal measurements, respectively.
descriptive statistics were used for all evaluated parameters.
patient and sinus characteristics were summarized in terms of frequencies and percentages for all variables assessed.
this includes, at patient level: age, gender, medical & smoking history, and at sinus level: septal class, size of perforation, type of bone graft used and if implants were placed simultaneously or not.
the independent samples t-test and fisher’s exact test were used to assess relationships between patient, bone grafting, implant placement timing, and intra-surgical related factors and outcome variables including marginal bone loss, the occurrence of sinus membrane perforation, and postoperative complications.
the p-value of <0.05 was considered to be statistically significant.
results there were 79 direct sinus lifts done in 67 patients (62.7% females and 37.3% males) aged 55 ± 12.6 years.
only eight patients were current smokers.
twelve patients received bilateral sinus lift.
simultaneous sinus lift and dental implant placement were performed in 31 sinuses, while delayed implant placement was performed in 48 sinuses.
a total of 107 implants were placed (table 1).
of the implants placed, eleven were nobel replace straight groovy, forty-seven were nobel replace tapered groovy, one was nobel replace select straight, seven were nobel replace select tapered, six were nobel replace conical connection, six were nobel active, nine were straumann bone level sand-blasted, large grit, acid-etched (sla), eighteen were astra osseospeed tx straight, and two mis seven implants.
one patient did not return for the completion of treatment following implant placement.
therefore, only 105 implants received an integration check.
for one-stage implants, the integration check was done at a pre-determined time point after implant placement.
for two-stage implants, the integration check was done at the time of the second stage surgery, and osseointegration was verified radiographically and by either an osstell isq (n=73) or a manual reverse torque test (n=32).
all implants that received an integration check had successfully osseointegrated, resulting in an overall survival rate of 100%.
average implant follow-up period after integration check was 12.8 months (1-37 m).
incidence of septum an evaluation of preoperative cbct images revealed that interfering septa were recognized in 48.1% of sinuses.
interfering septa were further classified according to their direction into class i: septum oriented in a buccal-lingual direction (medial-lateral sinus direction or coronal plane).
class ii: septum oriented in a mesial-distal direction (anterior-posterior sinus direction or sagittal plane).
class iii: septum in a horizontal (shelf-like; transverse plane) orientation (off one of the medial or lateral walls).
class iv: septum of a combination of class i, ii, or iii.
(fig.
1).
the most common septal orientation identified was class i septum in 34.2% (n=27) sinuses, the second most common were class ii and class iv in 5.1% (n=4) sinuses.
the least common was class iii, which was identified in 3.8% (n=3) sinuses.
the incidence of different classes of septa is shown in table 2. it is important to notice that of all sinuses with septa identified on cbct, 71.1% of them had class i septum.
intra-operative perforation the overall occurrence of sinus membrane perforation was 22.8%, regardless of whether or not an interfering septum was visualized on the pre-operative cbct image.
the incidence of small (<5 mm) and large (≥5 mm) membrane perforations were 12.7% (n=10) and 10.1% (n=8), respectively of all sinus lift procedures.
in sinuses where an interfering septum was visualized radiographically, the incidence of sinus membrane perforation was 44.7% and small and large perforation occurred in 26.3% and 18.4% of the cases, respectively.
in sinuses where an interfering septum was not visualized radiographically, only one perforation occurred, leading to an incidence of 2.4%.
the distribution of all perforations, both small and large, according to septal class is presented in table 2. an outline of clinical consideration is presented in table 3. due to the relatively small occurrence of radiographic class ii, iii, and iv septum, a separate analysis of septal classes and the occurrence of sinus membrane perforations was not possible.
however, the presence of an interfering radiographic septum on the pre-operative cbct scan was found to be significantly associated with the occurrence of a sinus membrane perforation (p < 0.001) (table 2).
post-operative complications post-operative complications occurred in only eight sinuses out of the 79 sinus treated, resulting in an occurrence rate of 10%.
the majority of the complications relate to postoperative graft infection (5%).
the incidence of other complications was 1.3%.
infection was treated with appropriate antibiotic.
only two cases had intra-surgical membrane perforation followed by other complications; therefore, intra-surgical membrane perforation was not associated with the occurrence of postoperative complications (p=1.000).
one patient had severe post-operative pain that radiates to the ipsilateral ear and was managed by pain medication.
another patient complained of facial asymmetry at the side of the procedure.
however, facial symmetry improved as the soft tissue healing progressed.
none of the complications resulted in the failure of the sinus augmentation.
there were four types of bone graft material used in sinus lifts: injectable paste allograft (n=26), particulate allograft (n=25), biooss particulate xenograft (n=9), and particulate alloplast (n=19).
when comparing the type of graft material used for the incidence of complications, it was found that injectable paste graft was significantly associated with a higher incidence of complications compared to particulate grafts (p=0.014).
patient and procedure’s factors related to membrane perforation and post-operative complications the study population was divided into three age groups: those younger than 45 years (n=12), those aged 45-64 (n=37), and those aged 65 years or older (n=18).
the incidence of membrane perforation among different age groups is presented in table 1. although the oldest age group experienced the highest proportion of small and large perforations, this difference was not statistically significant (p=0.422).
the youngest age group experienced the smallest proportion of other complications and the difference was only minimal and not statistically significant (p=1.000).
female patients showed a larger proportion of major complications; however, the difference was not statistically significant (p=0.700).
no gender difference was discovered with respect to the occurrence of membrane perforations.
smokers had a higher occurrence of membrane perforations and nonsmokers had a higher occurrence of postoperative complications.
however, the difference was not statistically significant (p=0.672) and (p=0.582), respectively.
the presence of one significant medical history (type i and type ii diabetes mellitus, osteoporosis on bisphosphonate medication and sinusitis) was not associated with the occurrence of membrane perforation or postoperative complications (p=0.760) and (p=0.424) respectively.
out of the 79 sinuses evaluated in this study, 48 sinuses did not have sufficient bone for immediate implant placement and were augmented in a staged approach.
the membrane perforation and postoperative complication rates in this group were 18.8% and 10.4%, respectively.
simultaneous implant placement with the sinus lift was found to be associated with an increased proportion of sinus membrane perforations when compared to staged approach, although the results were not statistically significant (p=0.410).
both groups were, in fact, found to be associated with equal proportions of postoperative complications, 9.7% and 10.4%, respectively (p=1.000) (table 1).
implant marginal bone loss the mean implant marginal bone loss for sinuses that did not experience a membrane perforation was 0.6±0.8 mm, compared with 0.9 ± 0.9 mm for sinuses that did experience a perforation (p=0.325) (fig.
2).
at both the 1.5 mm and 1.0 mm thresholds, the occurrence of a sinus membrane perforation was associated with an increased occurrence of marginal bone loss.
however, neither result was statistically significant (p=0.410, p=0.215 respectively) (table 4).
discussion the prevalence of interfering septa at the sinus level within this study was 48.1%.
as previously discussed, the overall prevalence of septa reported in the literature at the sinus level is between 16% and 48% [17, 23, 24] with a higher occurrence in edentulous subjects as compared to dentulous subjects [24].
the study confirms that careful preoperative evaluation of a three dimensional radiograph is important in preventing membrane perforation during the sinus lift procedure.
membrane perforation occurred only in 17 sinuses of the 38 sinuses in which septa were identified preoperatively.
however, the presence of an interfering radiographic septum on the preoperative cbct scan was significantly associated with the occurrence of a sinus membrane perforation.
the overall membrane perforation in relation to the presence of septa was 44.7% in this study and is in agreement with previously reported data [18, 25, 26].
of these studies, only malkinson and irinakis [10] retrospectively assessed the presence of interfering septa on preoperative cbct scans of 52 direct sinus lift procedures.
a statistically significant association between the presence of interfering septa and membrane perforations was not found at that time [10].
however, in their study, a high percentage of membrane perforation occurred in sinuses that did not have interfering septa (10.8%) as compared to the sinuses that had septa (13%).
schwarz, et al.
[26] identified the presence of sinus septa and residual ridge height of <3.5 mm as main risk factors for membrane perforation in sinus lift surgery.
identification and management of interfering septa are essential to predict and avoid complications during sinus augmentation procedure.
therefore, there is a need for the development of a classification system that fosters easy communication between practitioners and provides a prospective on the difficulty of the management of any particular case.
the ideal classification system has to be comprehensive, practical and simple and it should provide a clinical recommendation on the management and /or the prognosis of the case.
the proposed system is based on the orientation of the maxillary septum as identified in the ctcb scans.
the different classes were assigned based on the prevalence of different orientation of the maxillary septa as reported in the literature, meaning that class i septa is more prevalent than class ii or iii.
we also incorporated a class iv that included septa which have a combination of orientation.
in addition to the prevalence, we also considered the difficulty of the surgical management based on the incidence of complications.
the majority of sinuses in this study with interfering septa contained class i septa (coronal plane), or septa with a buccal-lingual orientation that divided the sinus cavity into anterior and posterior compartments.
this is in agreement with what was reported previously in studies that evaluated cadaver specimens and cbct images [13, 14, 23, 24].
park, et al.
[23] evaluated cbct images of 400 sinuses and found that out of the 111 sinuses that had septa, 106 of them had septa oriented in a buccal-palatal direction (coronal plane), four sinuses had septa in a sagittal direction, and one sinus had a septum in a transverse direction.
on the other hand, rosano, et al.
[17] in a cadaver study evaluating 60 sinuses found that 70% of maxillary septa were in a sagittal direction.
a systematic review by pommer, et al.
[27] evaluated the morphology of maxillary sinus and in 87% of the cases, the septa had a buccal-palatal orientation.
however, sagittal orientation was found in 11.1%, and horizontal septa were observed in 1.3% of cases.
in this study, the incidence of class ii septa (sagittal) was 5.1%, and class iii (horizontal shelve) was 3.1%.
interestingly, we found that 5.1% of the cases had a combination of the different orientations of the septa and, therefore, were classified as class iv.
a similar finding has been reported by sakhadri, et al.
who found a small number of their subjects (1%) to have 2 or three septa directed in different orientations [28].
the surgical manipulation of class v has been difficult and resulted in membrane perforation in all of the cases.
to our knowledge, the only proposed classification for maxillary septa was by wen, et al.
[9] and it was based on the degree of difficulty of the surgical manipulation of the case.
cases were categorized into easy, moderate or difficult class and each of the cases were sub-classified into a, b and c based on factors like the location, number, orientation and size of the septa.
a proposed clinical guideline into how to manage different cases was given.
however, in this classification, only septa that have a mediolateral or antero-posterior direction were included, and septa oriented in other directions were not considered.
although the incidence of class iii and class iv septa is relatively small, those cases are considered a real challenge to the implant surgeon and require an advanced level of skills and experiences to manage them.
the incidence of postoperative complications in this study was low and was not associated with membrane perforation.
the incidence of reported infection following sinus lift surgery has ranged from 0 to 12.5% [25, 29, 30].
there has been conflicting information regarding the association between membrane perforation and the development of sinusitis.
nolan, et al.
[7] found that 85% of sinuses developing sinusitis and secondary infection had intra-surgical membrane perforation.
others had argued that the occurrence of sinusitis is not associated with the occurrence of membrane perforations [31, 32].
four types of bone grafts material were available and the selection of which graft is used during the procedure was based on the clinical judgment of the operator.
injectable paste material has the advantage of reducing operating time with a clinically acceptable result [33].
however, in this study, it was associated with a higher incidence of postoperative complication rate.
this has to be interpreted with caution due to the limited number of sinuses and the retrospective nature of the study.
in the literature, an association between the type of bone graft material used during sinus lift surgery and the occurrence of postoperative complications has not been found [34].
postoperative pain in the sinus and infraorbital area is common and could last up to 3 weeks [35].
soft tissue dehiscence results from poor flap management and may result in graft loss [35].
the occurrence of a sinus membrane perforation was related to implant marginal bone loss at the latest follow-up.
however, this association was not found to be statistically significant.
karabuda, et al.
[36] assessed the effect of sinus membrane perforation on the success of implants placed in augmented sinuses in 91 patients using 259 implants.
both one and two stage direct sinus lifts were included.
a statistically significant difference was not detected in the peri-implant resorption rate between implants placed in sinuses with or without membrane perforations [36].
although some evidence in the literature points to a relationship between sinus membrane perforations and reduced implant survival [5, 18] the majority of research on this topic points to the lack of such an association [2, 6].
the trend of sinus membrane perforations causing increased marginal bone loss following implant placement, even if clinically relevant, may never prove to be statistically significant because the actual increase in marginal bone loss caused by a perforation is likely to be very small relative to the overall success of implant therapy in the posterior maxilla.
insufficient bone level is a frequent problem encountered during the restoration of posterior maxilla.
several sinus augmentation techniques i.e.
lateral window and crestal approach, the use of autogenous bone graft or bone substitute or the use of short dental implant have been proposed.
to date, there is no conclusive evidence in the literature on the superiority of one technique over the others in terms of prosthetic or implant success [37].
short dental implants or crestal approach might offer an alternative to lateral window approach when residual bone height is 4-9 mm with lower complications rate [37].
however, when advanced resorption of alveolar ridge is encountered, lateral window sinus augmentation is a reliable and well documented technique providing that careful evaluation of the risk factors and technical details are considered.
this study has several limitations being a retrospective review of a limited number of sinus augmentation procedures.
although all procedures were carried out by one clinician, different types of bone grafts were used.
bone loss was measured from radiographs taken at implant placement and at follow up but due to the relatively short follow-up period following integration check, the detection of significant differences or correlations between contributing factors and marginal bone loss was made difficult.
in addition, the restoration of dental implants plays a significant role in their overall success.
factors such as the creation of hygienic implant restoration contours as well as proper occlusal adjustment are critical to their long-term success.
the majority of patients in this study returned to their referring dentists for implant restoration, and thus the confounding variable of multiple operators with different skill levels may also have affected the results observed.
conclusion sinus septa should not be considered as a contraindication to sinus lift surgery.
septa should be identified, classified and managed with a meticulous attention to technical details.
a classification based on the septal orientation is proposed since the orientation of the septa can complicate the surgical procedure and requires modification of the surgical technique.
in this study, the identification of interfering septa on preoperative cbct scans was significantly associated with the occurrence of intra-surgical sinus membrane perforations.
however, sinus membrane perforations were not significantly associated with major post-operative complications or implant marginal bone loss.
@highlight
purpose: a new classification of maxillary sinus interfering septa based on its orientation is presented along with its relationship to the prevalence and severity of sinus membrane perforations.
additionally, the impact of membrane perforation on post-operative complications and marginal bone loss during the first year of loading is evaluated.
materials & methods: retrospective chart review of 79 consecutive sinus lift procedures with lateral window technique and 107 implants.
preoperative cone beam computed tomography (cbct) images were evaluated for the incidence and the direction of maxillary septa.
chart notes were examined for the incidence of membrane perforation and postoperative complications.
measurements of mesial and distal marginal bone levels and average bone resorption adjacent to each implant were calculated in intraoral radiographs taken at implant placement and during follow up appointments.
results: interfering septa were identified in 48.1 percent of sinuses.
71.1 percent of them had the septum oriented in a buccal-lingual direction (class i).
the overall incidence of membrane perforation was 22.8 percent, and the presence of an interfering septum on cbct scan was found to be significantly associated with the occurrence of a sinus membrane perforation (p<0.001).
the mean implant marginal bone loss for sinuses, which did not experience a membrane perforation, was 0.6±0.8mm, compared with 0.9 ± 0.9 mm for the sinuses that did experience a perforation (p = 0.325).
conclusion: septa should be identified, classified and managed with a meticulous attention to technical details.
a classification based on the septal orientation is proposed since the orientation of the septa can complicate the surgical procedure and requires modification of the surgical technique.
