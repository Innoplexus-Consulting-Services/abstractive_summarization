introduction the quantitative characterization of neuronal morphologies from histological digital neuronal reconstructions represents a primary resource to investigate anatomical comparisons and morphometric analysis of cells (kalisman et al., 2003; ascoli et al., 2007; scorcioni et al., 2008; schmitz et al., 2011; ramaswamy et al., 2012; oswald et al., 2013; muralidhar et al., 2014).
it often represents the basis of modeling efforts to study the impact of a cell’s morphology on its electrical behavior (insel et al., 2004; druckmann et al., 2012; gidon and segev, 2012; bar-ilan et al., 2013) and on the network it is embedded in (hill et al., 2012).
many different frameworks, tools and analysis have been developed to contribute to this effort (schierwagen and grantyn, 1986; ascoli et al., 2001, 2007; ascoli, 2002a,b, 2006; van pelt and schierwagen, 2004; halavi et al., 2008; scorcioni et al., 2008; cuntz et al., 2011; guerra et al., 2011; schmitz et al., 2011; hill et al., 2012), such as the carmen project, framework focusing on neural activity (jessop et al., 2010), neuromorpho.org, repository of digitally reconstructed neurons (halavi et al., 2008) or the trees toolbox for morphological modeling (cuntz et al., 2011).
in spite of over a century of research on cortical circuits, it is still unclear how many classes of cortical neurons exist.
neuronal classification remains a challenging topic since it is unclear how to designate a neuronal cell class and what are the best features to define them by (defelipe et al., 2013).
recently, quantitative methods using supervised and unsupervised classifiers have become standard for neuronal classification based on morphological, physiological, or molecular characteristics.
they provide quantitative and unbiased identification of distinct neuronal subtypes, when applied to selected datasets (cauli et al., 1997; karube et al., 2004; ma, 2006; helmstaedter et al., 2008; karagiannis et al., 2009; mcgarry et al., 2010; defelipe et al., 2013).
however, more robust classification methods are needed for increasingly complex and larger datasets.
as an example, traditional cluster analysis using ward’s method has been effective, but has drawbacks that need to be overcome using more constrained algorithms.
more recent methodologies such as affinity propagation (santana et al., 2013) outperformed ward’s method but on a limited number of classes with a set of interneurons belonging to four subtypes.
one important aspect of classifiers is the assessment of the algorithms, crucial for the robustness (rosenberg and hirschberg, 2007), particularly for unsupervised clustering.
the limitations of morphological classification (polavaram et al., 2014) are several: the geometry of individual neurons that varies significantly within the same class, the different techniques used to extract morphologies such as imaging, histology, and reconstruction techniques that impact the measures; but also inter-laboratory variability (scorcioni et al., 2004).
neuroinformatics tools, computational approaches, and openly available data such as that provided by neuromorpho.org enable development and comparison of techniques and accuracy improvement.
the objectives of this paper were to improve our knowledge on automatic classification of neurons and to develop and integrate, based on existing tools, a pipeline that goes from morphological features extraction using l-measure (scorcioni et al., 2008) to cell classification.
the accuracy of machine learning classification algorithms was assessed and compared.
algorithms were trained on 430 digitally reconstructed neurons from neuromorpho.org (ascoli et al., 2007), subjectively classified into layers and/or m-types using young and/or adult development state population of the somatosensory cortex in rats.
this study shows the results of applying unsupervised and supervised classification techniques to neuron classification using morphological features as predictors.
materials and methods data sample the classification algorithms have been trained on 430 digitally reconstructed neurons (figures 1 and 2) classified into a maximum of 22 distinct layers and/or m-types of the somatosensory cortex in rats (supplementary datasheet s1), obtained from neuromorpho.org (halavi et al., 2008) searched by species (rat), development (adult and/or young) and brain region (neocortex, somatosensory, layer 2/3, layer 4, layer 5, and layer 6).
established morphological criteria and nomenclature created in the last century were used.
in some cases, the m-type names reflect a semantic convergence of multiple given names for the same morphology.
we added a prefix to the established names to distinguish the layer of origin (e.g., a layer 4 pyramidal cell is labeled l4_pc).
forty-three morphological features1 were extracted for each neuron using l-measure tool (scorcioni et al., 2008) that provide extraction of quantitative morphological measurements from neuronal reconstructions.
figure 1 data sample of the 430 neurons with layer 2/3, 4, 5 and 6 as l23, l4, l5 and l6 and m-type basket, bipolar, bitufted, chandelier, double bouquet, martinotti, pyramidal, and stellate cells as bc, bpc, btc, chc, dbc, mc, pc, and sc.
figure 2 glimpse of two layer 4 pyramidal cell from neuromorpho.org provided by wang et al.
(wang et al., 2002) and visualized through the animation tool provided by neurophormo.org with neuron c140600c-p3 (a) 366°, (b) 184°, and (c) standard image; and with neuron c200897c-p2 (d) 356°, (e) 194°, and (f) standard image.
data preprocessing the datasets were preprocessed (supplementary figure s1) in order to deal with missing values, often encoded as blanks, nans or other placeholders.
all the missing values were replaced using the mean value of the processed feature for a given class.
categorical features such as morphology types were encoded transforming each categorical feature with m possible values into m binary features.
the algorithms were implemented using different normalization methods depending on the algorithm used.
they encompass for scaling feature values to lie between 0 and 1 in order to include robustness to very small standard deviations of features and preserving zero entries in sparse data, normalizing the data using the l2 norm [-1,1] and standardizing the data along any axis.
supervised learning in supervised learning, the neuron feature measurements (training data) are accompanied by the name of the associated neuron type indicating the class of the observations.
the new data are classified based on the training set (vapnik, 1995).
the supervised learning algorithms which have been compared are the following: – naive bayes (rish, 2001; russell and norvig, 2003a,b) with gaussian naïve bayes algorithm (gnb) and multinomial naïve bayes (mnb) – k-nearest neighbors (cover and hart, 1967; hart, 1968; coomans and massart, 1982; altman, 1992; terrell and scott, 1992; wu et al., 2008) – radius nearest neighbors (bentley et al., 1977) – nearest centroid classifier (ncc) (tibshirani et al., 2002; manning, 2008; sharma and paliwal, 2010) – linear discriminant analysis (lda) (fisher, 1936; friedman, 1989; martinez and kak, 2001; demir and ozmehmet, 2005; albanese et al., 2012; aliyari ghassabeh et al., 2015) – support vector machines (svm) (boser et al., 1992; guyon et al., 1993; cortes and vapnik, 1995; vapnik, 1995; ferris and munson, 2002; meyer et al., 2003; lee et al., 2004; duan and keerthi, 2005) including c-support vector classification (svc) with linear and radial basis functions (rbf) kernels (svc-linear and svc–rbf) – stochastic gradient descent (sgd) (ferguson, 1982; kiwiel, 2001; machine learning summer school and machine learning summer school, 2004) – decision tree (dt) (kass, 1980; quinlan, 1983, 1987; rokach, 2008) – random forests classifier2 (ho, 1995, 1998; breiman, 2001) – extremely randomized trees2 (shi et al., 2005; geurts et al., 2006, shi and horvath, 2006; prinzie and van den poel, 2008) – neural network (mcculloch and pitts, 1943; farley and clark, 1954; rochester et al., 1956; fukushima, 1980; dominic et al., 1991; hoskins and himmelblau, 1992) : multilayer perceptron (mlp) (auer et al., 2008) and radial basis function network (park and sandberg, 1991; schwenker et al., 2001) – classification and regression tree (c&r tree) (breiman et al., 1984) – chi-squared automatic interaction detector (chaid) (kass, 1980) – exhaustive chaid (biggs et al., 1991) – c5.0 (patil et al., 2012).
the algorithm for neuron classification using supervised classifier is shown in algorithm 1. algorithm 1: neuron supervised classification 1. normalize each of the neuron feature values 2. instantiate the estimator 3. fit the model according to the given training data and parameters 4. assign to all neurons the class determined by its exemplar 5. compute the classification accuracy (cf.
classification assessment) the normalization has been chosen regarding the requirements of the classification methods and/or providing the best results.
unsupervised learning ten unsupervised (clustering and dimension reduction) algorithms were implemented and assessed.
in unsupervised learning classification, the class labels of training data are unknown and the aim is to establish the existence of classes or clusters in the data given a set of measurements.
the unsupervised learning algorithms which were compared are the following: – k-means (macqueen, 1967; lloyd, 1982; duda, 2001; kanungo et al., 2002; mackay, 2003; jain, 2010; vattani, 2011; cordeiro de amorim and mirkin, 2012; de amorim and hennig, 2015) – mini batch k-means (sculley, 2010) – the k-means algorithm has been also used on pca-reduced data (ding and he, 2004) – ward (ward, 1963; everitt, 2001; de amorim, 2015) with and without connectivity constraints – mean shift (fukunaga and hostetler, 1975; cheng, 1995; comaniciu and meer, 2002) the algorithm for the classifiers described above is shown in algorithm 2. algorithm 2: unsupervised classification 1. normalize each of the neuron feature values using the l2 norm [-1,1] 2. instantiate the estimator 3. fit the model according to the given training data and parameters 4. assign to all neurons the corresponding cluster number 5. algorithm assessment (cf.
classification assessment) we also used the affinity propagation algorithm (frey and dueck, 2007; vlasblom and wodak, 2009; santana et al., 2013) which creates clusters by sending messages between pairs of samples until convergence.
two affinity propagation algorithms have been computed.
the first one is based on the spearman distance, i.e., the spearman rank correlation measures the correlation between two sequences of values.
the second one is based on the euclidian distance.
for both, the similarity measure is computed as the opposite of the distance or equality.
the best output was kept.
the preference value for all points is computed as the median value of the similarity values.
several preference values have been tested including the minimum and mean value.
the parameters of the algorithm were chosen in order to provide the closest approximation between the number of clusters from the output and the true classes.
the affinity propagation algorithm is shown in algorithm 3. algorithm 3: affinity propagation 1. normalize each of the neuron feature values to values [0,1] 2. similarity values between pairs of morphologies using spearman/euclidian distance 3. calculate the preference values for each morphology 4. affinity propagation clustering of morphologies 5. assign to all neurons the corresponding copy number 6. algorithm assessment (cf.
classification assessment) for all the clustering algorithms, the exemplar/centroids/cluster number determines the label of all points in the cluster, which is then compared with the true class of the morphology.
principal component analysis (pca; hotelling, 1933; abdi and williams, 2010; albanese et al., 2012) has been also tested.
hardware and software the algorithms were implemented in python 2.73 using the scikit-learn4 open source python library.
scikit-learn is an open source tool for data mining and data analysis built on numpy, a package for scientific computing with python5 and scipy, an open source software package for mathematics, science and engineering6.
morphological features7 were extracted for each neuron using l-measure tool (scorcioni et al., 2008) allowing extracting quantitative morphological measurements from neuronal reconstructions.
the pipeline described above, featuring extraction with l-measure and classification algorithms, was implemented and tested on power 8 from ibm (s822lc+gpu (8335-gta), 3.8 ghz, rhel 7.2).
the code of the pipeline is avalaible in github at https://github.com/xaviervasques/neuron_morpho_classification_ml.git.
classification assessment for supervised algorithm assessment, accuracy statistics have been computed for each algorithm: (1) accuracy = corrected   labels total   samples .
the accuracy ranges from 0 to 1, with 1 being optimal.
in order to measure prediction performance, also known as model validation, we computed a 10 times cross validation test using a randomly chosen subset of 30% of the data set and calculated the mean accuracy.
this gives a more accurate indication on how well the model is performing.
supervised algorithms were tested on neurons gathered by layers and m-types in young and adult population, by layers and m-types in young population, by m-types in young and adult population, by m-types in young population, and by layers of pyramidal cells in young population.
we also performed the tests by varying the percentage of train to test the ratio of samples from 1 to 80%.
we provided the respective standard deviations.
we included in the python code not only the accuracy code which is shown in this study but also the recall score, the precision score and the f-measure scores.
we also built miss-classification matrices for the algorithm providing the best accuracy for each of the categories with the true value and predicted value with the associated percentage of accuracy.
in order to assess clustering algorithm, the v-measure score was used (rosenberg and hirschberg, 2007).
the v-measure is actually equivalent to the normalized mutual information (nmi) normalized by the sum of the label entropies (vinh et al., 2009; becker, 2011).
it is a conditional entropy-based external cluster measure, providing an elegant solution to many problems that affects previously defined cluster evaluation measures.
the v-measure is also based upon two criteria, homogeneity and completeness (rosenberg and hirschberg, 2007) since it is computed as the harmonic mean of distinct homogeneity and completeness scores.
the v-measure has been chosen as our main index to assess the unsupervised algorithm.
however, in order to facilitate the comparison between supervised and unsupervised algorithms, we computed additional types of scores4 including: – homogeneity: each cluster contains only members of a single class.
– completeness, all members of a given class are assigned to the same cluster.
– silhouette coefficient: used when truth labels are not known, which is not our case, and which evaluates the model itself, where a higher silhouette coefficient score relates to a model with better defined clusters.
– adjusted rand index: given the knowledge of the ground truth class assignments and our clustering algorithm assignments of the same samples, the adjusted rand index is a function that measures the similarity of the two assignments, ignoring permutations and including chance normalization.
– adjusted mutual information: given the knowledge of the ground truth class assignments and our clustering algorithm assignments of the same samples, the mutual information is a function that measures the agreement of the two assignments, ignoring permutations.
we used specifically adjusted mutual information.
the pca have been assessed using the explained variance ratio.
results supervised algorithms assessment the assessment of the supervised algorithms is shown in figure 3. the results showed that lda is the algorithm providing the best results in all categories when classifying neurons according to layers and m-types with adult and young population (accuracy score of 0.9 ± 0.02 meaning 90% ± 2% of well classified neurons), layers and m-type with young population (0.89 ± 0.03), m-types with adult and young population (0.96 ± 0.02), m-types with young population (0.95 ± 0.01), and layers on pyramidal cells with young population (0.99 ± 0.01).
comparing the means between lda algorithm and all the other algorithms using t-test showed a significant difference (p < 0.001) and also for c&r tree algorithm using the wilcoxon statistical test (p < 0.005).
we also performed the tests by varying the percentage of train to test the ratio of samples from 1 to 80% showing a relative stability of the lda algorithm through its accuracy scores and respective standard deviations (figure 4).
table 1 shows mean precision, recall and f-scores of the lda algorithm with their standard deviations for all the categories tested.
we also built miss-classification matrices for the lda algorithm which provided the best accuracy for each of the categories (figure 5).
figure 3 the mean accuracy scores with their respective standard deviation of the supervised algorithms.
the mean accuracy scores have been computed 10 times using a randomly chosen 30% data subset to classify morphologies according to layers and m-types, m-types, and layers only.
figure 4 tests varying the percentage of train to test the ratio of samples from 1 to 80% showing a relative stability of the linear discriminant analysis (lda) algorithm.
the figure shows the mean accuracy scores with their respective standard deviation for each of the category tested.
table 1 mean precision, recall and f-scores of the linear discriminant analysis (lda) algorithm with their respective standard deviations for all the categories tested.
mean scores precision recall f-score layers, m-types : young and adult 0.9 ± 0.02 0.91 ± 0.015 0.9 ± 0.022 layers, m-types: young 0.87 ± 0.03 0.88 ± 0.03 0.86 ± 0.03 m-types: young and adult 0.95 ± 0.02 0.94 ± 0.03 0.94 ± 0.03 m-types: young 0.94 ± 0.02 0.94 ± 0.01 0.94 ± 0.01 layer, pyramidal cells: young 0.98 ± 0.01 0.98 ± 0.01 0.98 ± 0.01 figure 5 miss-classification matrices for the lda algorithm providing the best accuracy for each of the categories with the true value and predicted value and the associated percentage of accuracy for the following categories: (a) combined layers and m-types in young and adult population, (b) combined layers and m-types in young population, (c) m-types in young and adult population, (d) m-types in young population, and (e) layers and pyramidal cells in young population.
unsupervised algorithms assessment the results of the unsupervised clustering algorithm assessment are shown in figure 6. the algorithms providing slightly better results are the affinity propagation (spearman) and the ward.
the results showed that affinity propagation with spearman distance is the algorithm providing the best results in neurons classified according to layers and m-types with young and adult population (v-measure of 0.44, 36 clusters), layers on pyramidal cells with young population (v-measure of 0.385, 22 clusters) and also layers and m-types with young population (v-measure of 0.458, 28 clusters).
the results showed that ward algorithms provide the best results on two categories, namely the classification of morphologies according to m-types with young and adult population (v-measure of 0.562, 8 clusters), and m-types with young population (v-measure 0.503, 8 clusters).
affinity propagation with euclidean distance has been the second best for all the categories except neurons classified according to layers and m-types with young and adult population.
figure 6 v-measures comparison of the unsupervised clustering algorithms classifying morphologies according to layer and m-type, m-type and layer in young an/or adult population.
the figure shows also homogeneity scores, completeness scores, adjusted rand index, adjusted mutual information, and silhouette coefficient.
discussion neuron classification remains a challenging topic.
however, increasing amounts of morphological, electrophysiological (sills et al., 2012) and molecular data will help researchers to develop better classifiers by finding clear descriptors throughout a large amount of data and increasing statistical significance.
in line with this statement, data sharing and standardized approaches are crucial.
neuroinformatics plays a key role by working on gathering multi-modal data and developing methods and tools allowing users to enhance data analysis and by promoting data sharing and collaboration such as the human brain project (hbp) and the blue brain project (bbp; markram, 2012, 2013).
one of the hbp’s objectives, in particular the neuroinformatics platform, is to make it easier for scientists to organize and access data such as neuron morphologies, and the knowledge and tools produced by the neuroscience community.
on the other hand, neuron classification is an example of data increase rendering classification efforts harder rather than easier (defelipe et al., 2013).
nowadays, different investigators use their own tools and assign different names for classification of the same neuron rendering classification processes difficult, despite existing initiatives for nomenclature consensus (defelipe et al., 2013).
recently, quantitative methods using supervised and unsupervised classifiers have become standard for classification of neurons based on morphological, physiological, or molecular characteristics.
unsupervised classifications using cluster analysis, notably based on morphological features, provide quantitative and unbiased identification of distinct neuronal subtypes when applied to selected datasets.
recently, santana et al.
(2013) explored the use of an affinity propagation algorithm applied to 109 morphologies of interneurons belonging to four subtypes of neocortical gabaergic neurons (31 bc, 23 chc, 33 mc, and 22 non-mc) in a blind and non-supervised manner.
the results showed an accuracy score of 0.7374 for the affinity propagation and 0.5859 for ward’s method.
mcgarry et al.
(2010) classified somatostatin-positive neocortical interneurons into three interneuron subtypes using 59 gfp-positive interneurons from mouse.
they used unsupervised classification methods with pca and k-means clustering assessed by the silhouette analysis measures of quality.
tsiola et al.
(2003) used pca and cluster analysis using euclidean distance by ward’s method on 158 neurons of layer 5 neurons from mouse primary visual cortex.
muralidhar et al.
(2014) and markram et al.
(2015) applied classification methodologies on layer 1 dac (16), hac(19), sac (14), lac (11), and ngc (17 ngc-da and 16 ngc-sa) using objective (pca and lda), supervised and unsupervised methodologies on the developing rat’s somatosensory cortex using multi-neuron patch-clamp and 3d morphology reconstructions.
the study suggested that objective unsupervised classification (using pca) of neuronal morphologies is currently not possible based on any single independent feature of neuronal morphology of layer 1. the lda is a supervised method that performs better to classify the l1 morphologies where cell classes were distinctly separated.
additional algorithms can be included in the pipeline presented in our study such as nearest neighbor methods, feature decisions based methods, or those using metric learning that might be more robust for the given problem in low numbers of training samples.
the algorithms in the literature are often applied to small amounts of data, few classes and are often specific to a layer.
in our study, we assess and compare accuracy of different classification algorithms and classified neurons according to layer and/or m-type with young and/or adult development state in an important training sample size of neurons.
we confirm that supervised with lda is an excellent classifier showing that quality data are mandatory to predict the class of the morphology to be classified.
subjective classification by a neuroscientist is crucial to improve models on curated data.
the limitations of morphological classification (polavaram et al., 2014) are well known, such as the morphometric differences between laboratories, making the classification harder.
further challenges are the geometry of individual neurons which varies significantly within the same class, the different techniques used to extract morphologies (such as imaging, histology, and reconstruction techniques) which impact the measures, and finally, inter-laboratory variability (scorcioni et al., 2004).
neuroinformatic tools, computational approaches and their open availability, and data such as neuromorpho.org make it possible to develop and compare techniques and improve accuracy.
all unsupervised algorithms applied to a larger number of neurons showed, as expected, lower results.
one limitation of these algorithms is that results are strongly linked to parameters of the algorithm that are very sensible.
the current form of affinity propagation suffers from a number of drawbacks such as robustness limitations or cluster-shape regularity (leone et al., 2007), leading to suboptimal performance.
pca gives poor results confirming the conclusion of muralidhar et al.
(2014) that pca could not generate any meaningful clusters with a poor explained variance in the first principal component.
objective unsupervised classification of neuronal morphologies is currently tricky even using similar unsupervised methods.
supervised classification seems the best way to classify neurons according to previous subjective classification of neurons.
data curation is critically important.
brain modeling efforts will require huge volumes of standardized, curated data on the brain’s different levels of organization as well as standardized tools for handling them.
one important aspect of classifiers is the evaluation of the algorithms to assess the robustness of classification methods (rosenberg and hirschberg, 2007), especially for unsupervised clustering.
the silhouette analysis measure of quality (rousseeuw, 1987) is one of them.
more recently, the use of v-measure, an external entropy based cluster evaluation measure, provides an elegant solution to many problems that affect previously defined cluster evaluation measures (rosenberg and hirschberg, 2007).
features selection would show important features to classify morphologies.
taking into account only the significant features to classify morphologies will increase the accuracy of classification algorithms.
features selection is a compromise between running time by selecting the minimum sized subset of features and classification accuracy (tang et al., 2014).
the combination of different types of descriptors is crucial and can serve to both sharpen and validate the distinction between different neurons (helmstaedter et al., 2008, 2009; druckmann et al., 2012).
we propose that the appropriate strategy is to first consider each type of descriptor separately, and then to combine them, one by one, as the data set increases.
independently analyzing different types of descriptors allows their statistical power to be clearly examined.
a next step of this work will be to combine morphology data with other types of data such as electrophysiology and select the significant features which help improve classification algorithms with curated data.
the understanding of any neural circuit requires the identification and characterization of all its components (tsiola et al., 2003).
neuronal complexity makes their study challenging as illustrated by their classification and nomenclature (bota and swanson, 2007; defelipe et al., 2013), still subject to intense debate.
while this study deals with morphologies obtainable in optic microscope it would be useful to know how the electron microscopic features can also be exploited.
integrating and analyzing key datasets, models and insights into the fabric of current knowledge will help the neuroscience community to face these challenges (markram, 2012, 2013; kandel et al., 2013).
gathering multimodal data is a way of improving statistical models and can provide useful insights by comparing data on a large scale, including cross-species comparisons and cross datasets from different layers of the brain including electrophysiology (menendez de la prida et al., 2003; czanner et al., 2008), transcriptome, protein, chromosome, or synaptic (kalisman et al., 2003; hill et al., 2012; wichterle et al., 2013).
author contributions xv is the main contributor of the article from the development of the code to results, study of the results, and writing article.
lc supervised and wrote the article.
lv and gv did code optimization.
conflict of interest statement the authors declare that the research was conducted in the absence of any commercial or financial relationships that could be construed as a potential conflict of interest.
@highlight
classification and quantitative characterization of neuronal morphologies from histological neuronal reconstruction is challenging since it is still unclear how to delineate a neuronal cell class and which are the best features to define them by.
the morphological neuron characterization represents a primary source to address anatomical comparisons, morphometric analysis of cells, or brain modeling.
the objectives of this paper are (i) to develop and integrate a pipeline that goes from morphological feature extraction to classification and (ii) to assess and compare the accuracy of machine learning algorithms to classify neuron morphologies.
the algorithms were trained on 430 digitally reconstructed neurons subjectively classified into layers and/or m-types using young and/or adult development state population of the somatosensory cortex in rats.
for supervised algorithms, linear discriminant analysis provided better classification results in comparison with others.
for unsupervised algorithms, the affinity propagation and the ward algorithms provided slightly better results.
