introduction soft tissue sarcomas (sts) are neoplasms that can originate in any tissue of mesenchymal origin, and they are localised to limbs in approximately half of the cases [1].
the addition of radiotherapy (rt) to surgery in adjuvant or neoadjuvant setting yields a local control of 85–92% [2].
however, when distant metastasis is a concern, the addition of chemotherapy (ctx) is supposed to improve metastasis-free survival and overall survival (os).
most clinical trials of adjuvant ctx have demonstrated improved disease-free survival (dfs), but the impact on os is much less clear [3].
patients with large (> 5 cm), deep, and high-grade extremity sts are known to be at significant risk for distant metastasis and sarcoma-related death [4, 5].
previously aggressive regimens of preoperative ctx consisting of mesna, adriamycin, ifosfamide, and dacarbazine (maid) and external beam radiation therapy (ebrt) have yielded five-year os rates of up to 70% and local control rates of up to 92% [6, 7].
utilising this regimen, the multi-institutional phase ii study by radiation therapy oncology group (rtog) demonstrated distant dfs and os rates of 56.1% and 71.2%, respectively, with 7.7 years of follow-up [8].
several neoadjuvant ctx regimens and rt schedules have been experienced in different studies so far [9, 10].
istanbul university institute of oncology has been a referral centre for many high-risk sarcomas for a number of years.
in the absence of a prospective trial comparing neoadjuvant sequential chemoradiotherapy (crt) or rt alone, retrospective analyses can provide insight about the efficacy of these modalities.
therefore, we conducted a retrospective analysis of high-risk extremity sts treated at a single institute and investigated the treatment-related outcomes as compared to neoadjuvant sequential crt and rt alone.
material and methods study design and eligibility criteria the patient database at istanbul university institute of oncology was retrospectively searched, and 82 consecutive patients with high-risk extremity sts treated with neoadjuvant sequential crt or rt between january 2006 and january 2011 were identified.
fifteen patients who were lost to follow-up after neoadjuvant treatment were excluded from the analysis.
selection for neoadjuvant treatment required a world health organisation (who) performance score of (0–2) and appropriate bone marrow (absolute neutrophil count > 1500/µl, and platelet count > 100.000/µl, cardiac, renal, and hepatic function).
high-risk tumour was defined as primary tumour size ≥ 8 cm or ≥ 4 cm and grade 2 or 3 according to the national cancer institute (nci) three-tier grading system.
locally recurrent and limited metastatic tumours treated with neoadjuvant modalities were not included in the analysis.
patients with rhabdomyosarcoma, primitive neuroectodermal tumours, extraosseous ewing sarcoma, chondrosarcoma, osteosarcoma, kaposi sarcoma, and sarcoma of the head and neck or trunk were also excluded.
all patients had pretreatment imaging of primary tumours with magnetic resonance imaging (mri) or computed tomography (ct).
for patients with evaluable imaging studies before and after neoadjuvant treatment, radiologic response was recorded according to response evaluation criteria in solid tumours (recist) [11].
baseline evaluation of the patients consisted of medical history, physical examination, complete blood count, biochemistry tests, urinalysis, electrocardiogram, and determination of left ventricular ejection fraction with echocardiogram.
each patient had baseline evaluation of the primary site with ct or mri and chest ct to detect metastatic disease.
follow-up after surgery included physical examination and imaging studies involving the primary site and chest with ct scan or x-ray every 3–4 months during the first two years, then every six months for 3–5 years, and annually thereafter.
the study was approved by the institutional review board of istanbul university, institute of oncology.
chemotherapy the neoadjuvant ctx regimen consisted of 2–3 cycles of doxorubicin at a dose of 75 mg/m2 by intravenous (iv) bolus on day 1, followed by ifosfamide given as a four-hour infusion at dose of 2 g/m2 on days 1–3.
total mesna dose to be administered is calculated as 3/4 of the daily ifosfamide dose; 1/3 is given with ifosfamide as a four-hour infusion and the rest is administered alone as an eight-hour infusion following ifosfamide on days 1–3.
all the patients received filgrastim 5 µg/kg/day on days five to nine as primary prophylaxis.
ctx cycles were repeated at 21-day intervals.
intravenous hydration and antiemetics were administered as per institutional standards.
the number of ctx cycles was determined by the medical oncologist as two or three depending on the clinical response of the tumour.
radiotherapy and surgery external beam radiation therapy was initiated three weeks after the second or third ctx cycle and consisted of 28 grays (gy) administered as eight fractions of 3500 cgy each for 10 days.
the target volume of rt included the site of the primary lesion and the tissues suspected of involvement by microscopic disease to a clinically significant probability.
computed tomography or mri in conjunction with physical examination was used in order to define the target volume.
for patients with positive surgical margins postoperative rt boost was administered, which consisted of 12 gy given in six daily fractions of 2 gy to the bed of the residual tumour with a surgical margin of 1 cm.
the boost was administered beginning two weeks after resection after satisfactory healing of the surgical wound.
surgery was performed within 2-3 weeks following the last rt dose by a specialised team in istanbul university, istanbul medical faculty, department of orthopaedics.
dissection was performed through normal tissue planes, and the surgeon aimed to obtain negative surgical margins with wide excision.
during surgery frozen sections from the closest sites were evaluated to confirm negative margins.
when limb sparing surgery was not technically feasible amputation was performed.
statistical analysis os was defined as the timed elapsed from the date of pathologic diagnosis to death of any cause.
dfs was calculated as the time between diagnosis and detection of first local, regional, or distant recurrence.
local recurrence-free survival (lrfs) and distant recurrence-free survival (drfs) were calculated as the time between date of diagnosis and date of first local/regional and distant recurrence, respectively.
patterns of recurrence were grouped as locoregional failure, local and distant failure, and isolated distant metastasis.
statistical analysis was performed with spss 16.0 software (spss inc., released 2007 for windows, version 16.0., chicago, spss inc.).
for group comparison of categorical variables, χ2 tests were used and for comparison of continuous variables such as age and tumour size mann-whitney u test was used.
the kaplan-meier method was used for estimation of survival distribution, and differences in survival were evaluated by log-rank statistics.
a p-value ≤ 0.05 was considered significant.
results patient and tumour characteristics a total of 67 patients who were admitted to istanbul university, institute of oncology between january 2006 and january 2011 were included in the analysis.
the median age of the whole patient group was 47 years (range: 18–79 years).
central pathology review for histology was accomplished for 52 (77.6%) patients.
malignant fibrous histiocytoma (mfh) (or undifferentiated pleomorphic sarcoma) constituted the majority (n = 30, 44.8%) of the histologic subtype of the tumours.
the second most common histology was synovial sarcoma (n = 16, 23.9%) (table 1).
the median largest tumour size measured clinically or radiologically (ct or mri) was 9.6 cm (range: 4–26 cm).
histological grade was available for only 34% of the patients, for which 26.9% (n = 18) were grade 3 (equally dispersed among the two groups) and 7.5% (n = 5) were grade 2 tumours.
table 1 histological subtypes of extremity sarcomas involved in the analysis histological subtypes n % mfh 30 44.7 synovial sarcoma 16 23.8 liposarcoma 13 19.4 leiomyosarcoma 2 2.9 malignant schwannoma 1 1.4 alveolar soft part sarcoma 1 1.4 epithelioid sarcoma 1 1.4 fibroblastic sarcoma 1 1.4 dermatofibrosarcoma protuberans 1 1.4 clear cell tenosynovial sarcoma 1 1.4 total 67 100 mfh – malignant fibrous histiocytoma, undifferentiated pleomorphic sarcoma treatment thirty-four patients were treated with neoadjuvant sequential crt, and 33 patients were treated with neoadjuvant rt alone.
the distribution of gender, performance status, histological subtypes, and tumour size were similar across the two treatment groups (table 2).
twenty-seven patients (79%) in the ctx arm received two cycles of ctx while seven (21%) patients received three cycles.
in general ctx was well-tolerated.
leucopaenia was observed in 55% in the sequential treatment arm; however, grade 4 toxicity occurred only in 26% of the patients.
the most common non-haematological adverse events were nausea and/or vomiting (all patients).
dose reductions were applied for 35% (n = 12) of the cases, mostly due to febrile neutropaenia and grade 4 thrombocytopaenia.
in each arm, all the patients were able to complete the planned rt schedule.
there was no toxic death in either group.
during follow-up, two patients presented with second primary tumours (papillary thyroid cancer and breast cancer), which were not attributed to the treatment protocol.
table 2 comparison of clinical and pathologic characteristics of the two groups (neoadjuvant chemoradiotherapy vs. radiotherapy alone) variables crt (n = 34) rt (n = 33) p age 42.5 (18–66) 52 (18–79) 0.14 gender female, n (%) male, n (%) 15 (44.1)19 (55.9) 14 (42.4)19 (57.6) 0.88 tumour size (cm)  median (range) 10 (4–21) 8.7 (4–26) 0.32 r0 resection (%) 88.2 96.9 0.21 progression, n (%) yes no 17 (50)17 (50) 11 (33.3)2 (66.7) 0.12 crt – chemotherapy and radiotherapy; rt – radiotherapy response to ctx was assessed clinically and radiologically for only 20% (n = 13) in the sequential therapy arm.
none of the patients had complete remission, while eight patients had partial response to therapy.
one patient had progressive disease during treatment, and the rest (n = 4) had stable disease.
all the patients had undergone surgery after neoadjuvant treatment.
wide excision or compartmental resection of the tumour with preservation of the limb was possible for all of the patients except for one who underwent amputation due to rapid progression under neoadjuvant rt.
sixty-two patients (92.5%) had r0 resections, and the other five patients (four in the crt and one in the rt arm) had microscopic residual tumour (r1 resection).
survival and patterns of failure at a median follow-up time of 37 months (interquartile range: 11–66 months) 39 patients (58.2%) were alive without any disease failure.
a total of 16 deaths have been recorded so far.
the estimated three-year os and dfs rate for the whole patient group was 79% (95% ci: 67.0–86.4) and 57.9% (95% ci: 46.3–69.0), respectively.
three-year os rates for neoadjuvant sequential crt and rt arms were 74.1% and 90.0%, respectively (p = 0.44).
three-year dfs, lrfs, and drfs rates also did not differ significantly for each treatment arm (for sequential crt and rt; 50.5% vs. 65.7%, p = 0.33; 77.1% vs. 76.3%, p = 0.86; 70.1% vs. 86.1%, p = 0.12, respectively) (figs.
1, 2).
there were no statistically significant predictors of os and dfs.
low event rates and the small size of the groups precluded comparison of outcomes.
although not statistically significant there was a tendency for better os and dfs for female, elderly, and smaller primary tumour (≤ 10 cm) group (table 3).
three-year drfs and lrfs rates for the whole group were estimated as 77.7% (95% ci: 70.0–91.0) and 74.2% (95% ci: 63.4–86.1).
sites of progression did not show statistically significant differences with respect to the neoadjuvant treatment modality received (table 4).
in total, 25 patients (37.3%) had disease progression: 11 (16.4%) patients had isolated distant metastasis; 10 (14.9%) had locoregional failure; and four had failure at both local and distant sites.
the most common site of metastasis was lung (n = 13).
one patient with malignant schwannoma had disease progression in both lungs and bone.
upon progression, 13 patients had undergone surgery; metastasectomy was performed for four patients.
excluding amputations (n = 3) local recurrences were managed with limb-preserving surgery and rt for six cases.
five patients who had not received neoadjuvant ctx were administered chemotherapy consisting of doxorubicin and ifosfamide after surgery for disease progression.
six patients who had undergone surgery for progressive disease were alive at the time of analysis.
median os for those who were operated for disease progression (metastasectomy and/or surgery for local recurrence) was 46.1 months (95% ci: 19.5–72.8).
fig.
1 comparison of kaplan-meier survival curves for overall survival according to neoadjuvant treatment modalities fig.
2 comparison of kaplan-meier survival curves for disease-free survival according to neoadjuvant treatment modalities table 3 kaplan-meier 3-year overall and disease-free survival rates for different clinical variables and treatment modalities variables 3-year dfs (%) p 3-year os (%) p age ≤ 50 >50 50.071.2 0.25 83.291.8 0.33 gender female male 72.047.7 0.19 96.077.0 0.36 tumour size  ≤ 10 cm > 10 cm 61.439.9 0.09 92.384.8 0.59 neoadjuvant treatment modality  crt rt 50.666.6 0.08 86.783.5 0.64 crt – chemotherapy and radiotherapy; rt – radiotherapy table 4 sites of progression according to neoadjuvant treatment modalities sites of progression crt n (%) rt n (%) p isolated distant metastasis 8 (53.3) 3 (30.0) 0.51 locoregional failure 5 (33.3) 5 (50.0) local + distant failure 2 (13.3) 2 (20.0) discussion for high-risk extremity sts, combined local treatment (surgery with rt) is the standard of care [12, 13].
in this study, which compared the impact of two different neoadjuvant modalities, the three-year os rates for sequential crt and rt arms were 74.1% and 90.0%, respectively (p = 0.44).
three-year dfs, lrfs, and drfs rates also did not differ for each treatment arm.
the hypofractionated rt schedule utilised in our institute for both treatment arms consisted of 28-gy external beam radiation administered over eight fractions.
eilber et al.
were the first to publish the results of a prospective trial using this regimen combined with intra-arterial or intravenous adriamycin [14].
os rates were reported to be 70%, and local recurrence rates were 14%.
similarly, one of the early regimens included intra-arterial doxorubicin and sequentially delivered hypo-fractionated rt (35 gy in 3.5-gy fractions), followed by limb-sparing surgery [15].
all of the patients involved in this study avoided amputation and only 3% recurred locally.
however, complications of the regimen were frequent (23% requiring reoperation), prompting modifications of rt dose.
subsequently, neoadjuvant 28 gy hypofractionated rt with diverse intravenous ctx regimens have been tested in different studies [10, 16].
a retrospective trial from a single institute by macdermed et al.
[17] reported 85% wide excision rates with 100% negative surgical margins, and reoperation was required for wound complications in 17.2% of patients.
in our study, wide excision or compartmental resection of the tumour with limb preservation was accomplished for all of the patients except for one, and approximately 92% of the patients had r0 resections.
none of the patients required reoperation due to wound complications.
although rt is a fairly standard adjunct of surgery for high-risk extremity sts, there is substantial controversy regarding the role of adjuvant or neoadjuvant ctx.
a statistically significant, albeit limited, benefit for adjuvant ctx has been demonstrated in a meta-analysis by the sarcoma meta-analysis collaboration (smac) [3].
since the patient cohort included various risk and histologic subtypes, a pre-planned subgroup analysis revealed that high-grade extremity sarcomas were most likely to benefit, with a statistically significant 7% improvement in survival rate (p = 0.029).
since the publication of this meta-analysis, additional randomised trials using different dosing schedules have failed to demonstrate improvement in survival with adjuvant doxorubicin- or ifosfamide-based ctx [18–20].
long-term follow-up results of adjuvant ctx from the memorial sloan-kettering cancer centre (mskcc) and m. d. anderson cancer centre demonstrated that the benefit of adjuvant doxorubicin-based ctx in patients with high-risk sts was not sustained beyond one year [7].
the controversial results from adjuvant ctx trials pursued the outcomes of neoadjuvant trials.
seeking a beneficial effect of neoadjuvant ctx, grobmyer et al.
[21] compared neoadjuvant ctx with surgery versus surgery alone and pointed out a dfs advantage for only patients with tumours > 10 cm.
thereafter, a phase ii trial by rtog evaluated the efficacy and toxicity of neoadjuvant mesna, doxorubicin, ifosfamide, and dacarbazine (maid) ctx with split course rt (44 gy) and adjuvant maid ctx [22].
estimated three-year dfs and os rates were 56.6% and 75.1%, respectively, which were comparable with the survival rates of the sequential crt arm in our study.
however, the early toxicity profile of the rtog trial was severe; there were three treatment-related deaths and 78% of patients experienced grade 4 haematological toxicity.
fifty-nine per cent of the whole patient group were able to complete all planned ctx.
the high frequency of toxicity was attributed to the high dose of ifosfamide (7.5 g/m2) in the maid regimen.
the total ifosfamide dose in our study was 6 g/m2, and doxorubicin doses were identical in both studies (75 mg/m2).
in our study, there were no fatal toxicities, and all of the patients had completed at least the planned two cycles of ctx.
in addition to the higher ifosfamide dose, dacarbazine included in the maid regimen of the rtog trial is thought to contribute to the high rates of haematological toxicity.
currently there are no data directly comparing the maid regimen and doxorubicin-ifosfamide (ai) regimen in terms of efficacy.
the only evidence pointing to the advantage of adding dacarbazine to ai is in the metastatic setting, particularly in terms of response, rather than survival [23].
although ifosfamide dose was lower than the rtog trial and patients received apparently fewer courses of ctx in our study, the survival rates were similar questioning the necessity of such a toxic therapy in the neoadjuvant setting.
nevertheless, in the current study, when compared with neoadjuvant rt alone, the os and dfs rates were lower for the sequential crt arm, although not statistically significantly (for os; 74.1% vs. 90.0%, p = 0.44, for dfs 50.5% vs. 65.7%, p = 0.33).
this study is certainly subject to interventional selection biases, in which clinicians preferentially select more intense treatment (crt) for patients with clinically more aggressive tumours.
thus, our findings are probably impacted by the retrospective nature of the study, leading to uneven distribution of patient characteristics among the two treatment arms.
although there was statistically no significant difference between the two groups with respect to tumour and patient features, the median size of the tumour was apparently higher in the sequential crt arm (10 vs. 8.7 cm, p = 0.32).
moreover, histological grading of the tumour was available for only 34% of the patients; thus, we could not conclude about a well-balanced distribution for the histological grading of the tumours.
therefore, we assume that the higher frequency of poorly differentiated tumours in the crt arm might have contributed to the worse outcomes for this treatment modality.
to our knowledge, this is the second retrospective study comparing neoadjuvant crt to rt for extremity sts.
the previous study evaluated the outcomes of three treatment arms (neoadjuvant crt, rt, and surgery alone) and did not report an improvement in survival with the addition of either rt or crt to surgery [24].
however, the study did not specifically include high-risk sts patients, and the median tumour size was markedly higher in the neoadjuvant crt arm.
this study has several limitations, which are mostly attributed to its retrospective nature, as outlined above.
inclusion of diverse histological subtypes with varying chemosensitivity was inevitable due to the limited number of sarcoma patients.
we conclude that preoperative hypofractionated rt alone or in combination with a modified dose of ifosfamide and doxorubicin results in high rates of limb salvage and acceptable toxicity.
the addition of ctx to rt in the neoadjuvant setting does not seem to provide any survival benefit.
however, given the small sample size and uneven distribution of patients across the treatment arms, this study is not statistically powered to detect small to intermediate beneficial effects of ctx for a specific subgroup.
the literature concerning the use of neoadjuvant ctx is also inconclusive with regard to efficacy and toxicity issues.
during the last decade efforts to identify new therapeutic targets to improve response and survival rates have not yielded satisfactory results.
randomised rather than retrospective trials comparing neoadjuvant rt to crt with traditional chemotherapeutic agents may provide a better insight regarding the beneficial effect of ctx.
@highlight
aim of the study patients with large and high-grade extremity soft-tissue sarcoma are at significant risk for distant metastasis and sarcoma-related death.
there is no randomized trial comparing chemoradiotherapy to radiotherapy in the neoadjuvant setting for high risk extremity soft-tissue sarcoma.
the aim of this study is to evaluate the outcomes of patients treated with two different modalities (neoadjuvant sequential chemoradiotherapy vs. radiotherapy alone) in a single center.
material and methods data of 67 patients were analyzed retrospectively.
thirty-four patients received neoadjuvant sequential chemoradiotherapy (2–3 cycles of doxorubicin (75 mg/m2) and ifosfamide (6 g/m2) followed by radiotherapy of 28 grays (gy) administered as 8 fractions of 35 gy) and 33 patients received radiotherapy alone.
r0 resection rates and 3-year survival estimates were evaluated.
results median follow-up time was 37 months.
the estimated 3-year overall and disease-free survival rates for the whole patient group were 79% (95% ci: 67.0–86.4) and 57.9% (95% ci: 46.3–69.0), respectively.
the most common side effects were nausea and leucopenia.
three-year overall, disease-free, local recurrence-free and distant recurrence-free survival rates did not differ significantly.
all patients except one underwent wide excision or compartmental resection.
r0 resection rate for the whole patient group was 92.5% (n = 62).
sites of progression were similar across both treatment arms.
conclusions preoperative hypofractionated radiotherapy alone or sequentially with chemotherapy result in high rates of limb salvage and acceptable toxicity.
our study results did not show a statistically significant treatment effect regarding survival and patterns of failure.
